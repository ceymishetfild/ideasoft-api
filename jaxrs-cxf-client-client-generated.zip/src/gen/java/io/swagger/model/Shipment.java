package io.swagger.model;

import io.swagger.model.Order;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Shipment  {
  
  @ApiModelProperty(example = "123", value = "Teslimat nesnesi kimlik değeri.")
 /**
   * Teslimat nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "12345678ASD", value = "Teslimat barkodu.")
 /**
   * Teslimat barkodu.  
  **/
  private String barcode = null;
  @ApiModelProperty(example = "A-1002", value = "Teslimat fatura numarası.")
 /**
   * Teslimat fatura numarası.  
  **/
  private String waybillNo = null;
  @ApiModelProperty(example = "A-1231", value = "Teslimat irsaliye makbuzu numarası.")
 /**
   * Teslimat irsaliye makbuzu numarası.  
  **/
  private String invoiceKey = null;
  @ApiModelProperty(example = "Üsküdar", value = "Teslimatın kargo şubesi")
 /**
   * Teslimatın kargo şubesi  
  **/
  private String cargoOffice = null;
  @ApiModelProperty(example = "KOD123456", value = "Teslimat kodu. Kargo takip kodu.")
 /**
   * Teslimat kodu. Kargo takip kodu.  
  **/
  private String code = null;
  @ApiModelProperty(example = "deliveryType", value = "Teslimat tipi")
 /**
   * Teslimat tipi  
  **/
  private String deliveryType = null;

@XmlType(name="InvoiceIncludedEnum")
@XmlEnum(String.class)
public enum InvoiceIncludedEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    InvoiceIncludedEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static InvoiceIncludedEnum fromValue(String v) {
        for (InvoiceIncludedEnum b : InvoiceIncludedEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", value = "Faturanın pakete dahillik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Dahil.<br><code>0</code> : Dahil değil.<br></div>")
 /**
   * Faturanın pakete dahillik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Dahil.<br><code>0</code> : Dahil değil.<br></div>  
  **/
  private InvoiceIncludedEnum invoiceIncluded = null;
  @ApiModelProperty(example = "5.0", value = "Kapıda ödeme hizmeti bedeli.")
 /**
   * Kapıda ödeme hizmeti bedeli.  
  **/
  private Float payAtDoorAmount = null;
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Teslimat nesnesinin oluşturulma zamanı.")
 /**
   * Teslimat nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;

@XmlType(name="StatusEnum")
@XmlEnum(Integer.class)
public enum StatusEnum {

@XmlEnumValue("0") NUMBER_0(Integer.valueOf(0)), @XmlEnumValue("1") NUMBER_1(Integer.valueOf(1));


    private Integer value;

    StatusEnum (Integer v) {
        value = v;
    }

    public Integer value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", required = true, value = "Teslimat nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
 /**
   * Teslimat nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>  
  **/
  private StatusEnum status = null;
  @ApiModelProperty(value = "")
  private Order order = null;

 /**
   * Teslimat nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Shipment id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Teslimat barkodu.
   * @return barcode
  **/
  @JsonProperty("barcode")
  public String getBarcode() {
    return barcode;
  }

  public void setBarcode(String barcode) {
    this.barcode = barcode;
  }

  public Shipment barcode(String barcode) {
    this.barcode = barcode;
    return this;
  }

 /**
   * Teslimat fatura numarası.
   * @return waybillNo
  **/
  @JsonProperty("waybillNo")
  public String getWaybillNo() {
    return waybillNo;
  }

  public void setWaybillNo(String waybillNo) {
    this.waybillNo = waybillNo;
  }

  public Shipment waybillNo(String waybillNo) {
    this.waybillNo = waybillNo;
    return this;
  }

 /**
   * Teslimat irsaliye makbuzu numarası.
   * @return invoiceKey
  **/
  @JsonProperty("invoiceKey")
  public String getInvoiceKey() {
    return invoiceKey;
  }

  public void setInvoiceKey(String invoiceKey) {
    this.invoiceKey = invoiceKey;
  }

  public Shipment invoiceKey(String invoiceKey) {
    this.invoiceKey = invoiceKey;
    return this;
  }

 /**
   * Teslimatın kargo şubesi
   * @return cargoOffice
  **/
  @JsonProperty("cargoOffice")
  public String getCargoOffice() {
    return cargoOffice;
  }

  public void setCargoOffice(String cargoOffice) {
    this.cargoOffice = cargoOffice;
  }

  public Shipment cargoOffice(String cargoOffice) {
    this.cargoOffice = cargoOffice;
    return this;
  }

 /**
   * Teslimat kodu. Kargo takip kodu.
   * @return code
  **/
  @JsonProperty("code")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public Shipment code(String code) {
    this.code = code;
    return this;
  }

 /**
   * Teslimat tipi
   * @return deliveryType
  **/
  @JsonProperty("deliveryType")
  public String getDeliveryType() {
    return deliveryType;
  }

  public void setDeliveryType(String deliveryType) {
    this.deliveryType = deliveryType;
  }

  public Shipment deliveryType(String deliveryType) {
    this.deliveryType = deliveryType;
    return this;
  }

 /**
   * Faturanın pakete dahillik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Dahil.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Dahil değil.&lt;br&gt;&lt;/div&gt;
   * @return invoiceIncluded
  **/
  @JsonProperty("invoiceIncluded")
  public String getInvoiceIncluded() {
    if (invoiceIncluded == null) {
      return null;
    }
    return invoiceIncluded.value();
  }

  public void setInvoiceIncluded(InvoiceIncludedEnum invoiceIncluded) {
    this.invoiceIncluded = invoiceIncluded;
  }

  public Shipment invoiceIncluded(InvoiceIncludedEnum invoiceIncluded) {
    this.invoiceIncluded = invoiceIncluded;
    return this;
  }

 /**
   * Kapıda ödeme hizmeti bedeli.
   * minimum: 0
   * @return payAtDoorAmount
  **/
  @JsonProperty("payAtDoorAmount")
  public Float getPayAtDoorAmount() {
    return payAtDoorAmount;
  }

  public void setPayAtDoorAmount(Float payAtDoorAmount) {
    this.payAtDoorAmount = payAtDoorAmount;
  }

  public Shipment payAtDoorAmount(Float payAtDoorAmount) {
    this.payAtDoorAmount = payAtDoorAmount;
    return this;
  }

 /**
   * Teslimat nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Teslimat nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public Integer getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Shipment status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Get order
   * @return order
  **/
  @JsonProperty("order")
  public Order getOrder() {
    return order;
  }

  public void setOrder(Order order) {
    this.order = order;
  }

  public Shipment order(Order order) {
    this.order = order;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Shipment {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    barcode: ").append(toIndentedString(barcode)).append("\n");
    sb.append("    waybillNo: ").append(toIndentedString(waybillNo)).append("\n");
    sb.append("    invoiceKey: ").append(toIndentedString(invoiceKey)).append("\n");
    sb.append("    cargoOffice: ").append(toIndentedString(cargoOffice)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    deliveryType: ").append(toIndentedString(deliveryType)).append("\n");
    sb.append("    invoiceIncluded: ").append(toIndentedString(invoiceIncluded)).append("\n");
    sb.append("    payAtDoorAmount: ").append(toIndentedString(payAtDoorAmount)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    order: ").append(toIndentedString(order)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

