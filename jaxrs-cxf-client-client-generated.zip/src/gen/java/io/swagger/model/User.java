package io.swagger.model;

import io.swagger.model.MemberGroup;
import io.swagger.model.ShopUserlevels;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class User  {
  
  @ApiModelProperty(example = "123", value = "Yönetici nesnesi kimlik değeri.")
 /**
   * Yönetici nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "John", value = "Yöneticinin ismi.")
 /**
   * Yöneticinin ismi.  
  **/
  private String firstname = null;
  @ApiModelProperty(example = "Doe", value = "Yöneticinin soy ismi.")
 /**
   * Yöneticinin soy ismi.  
  **/
  private String surname = null;
  @ApiModelProperty(example = "johndoe@ideasoft.com.tr", required = true, value = "Yöneticinin e-mail adresi.")
 /**
   * Yöneticinin e-mail adresi.  
  **/
  private String email = null;
  @ApiModelProperty(example = "yonetici", required = true, value = "Yöneticinin kullanıcı adı.")
 /**
   * Yöneticinin kullanıcı adı.  
  **/
  private String username = null;
  @ApiModelProperty(example = "+90 (555) 555 55 55", value = "Yöneticinin telefon numarası.")
 /**
   * Yöneticinin telefon numarası.  
  **/
  private String phoneNumber = null;

@XmlType(name="StatusEnum")
@XmlEnum(Integer.class)
public enum StatusEnum {

@XmlEnumValue("0") NUMBER_0(Integer.valueOf(0)), @XmlEnumValue("1") NUMBER_1(Integer.valueOf(1)), @XmlEnumValue("2") NUMBER_2(Integer.valueOf(2));


    private Integer value;

    StatusEnum (Integer v) {
        value = v;
    }

    public Integer value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", required = true, value = "Yöneticinin aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br><code>2</code> : Askıya alınmış.<br></div>")
 /**
   * Yöneticinin aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br><code>2</code> : Askıya alınmış.<br></div>  
  **/
  private StatusEnum status = null;

@XmlType(name="IsOwnerEnum")
@XmlEnum(String.class)
public enum IsOwnerEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    IsOwnerEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static IsOwnerEnum fromValue(String v) {
        for (IsOwnerEnum b : IsOwnerEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", value = "Yöneticinin site sahibi olma durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Site sahibi.<br><code>0</code> : Site sahibi değil.<br></div>")
 /**
   * Yöneticinin site sahibi olma durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Site sahibi.<br><code>0</code> : Site sahibi değil.<br></div>  
  **/
  private IsOwnerEnum isOwner = null;
  @ApiModelProperty(value = "İlgili üye grubu.")
 /**
   * İlgili üye grubu.  
  **/
  private List<MemberGroup> membergroups = new ArrayList<MemberGroup>();

@XmlType(name="SmsApprovedEnum")
@XmlEnum(String.class)
public enum SmsApprovedEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    SmsApprovedEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static SmsApprovedEnum fromValue(String v) {
        for (SmsApprovedEnum b : SmsApprovedEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", value = "Yöneticinin SMS verifikasyonu yapılma bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : SMS verifikasyon yapılmış.<br><code>0</code> : SMS verifikasyon yapılmamış.<br></div>")
 /**
   * Yöneticinin SMS verifikasyonu yapılma bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : SMS verifikasyon yapılmış.<br><code>0</code> : SMS verifikasyon yapılmamış.<br></div>  
  **/
  private SmsApprovedEnum smsApproved = null;
  @ApiModelProperty(value = "")
  private ShopUserlevels userlevel = null;

 /**
   * Yönetici nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public User id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Yöneticinin ismi.
   * @return firstname
  **/
  @JsonProperty("firstname")
  public String getFirstname() {
    return firstname;
  }

  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }

  public User firstname(String firstname) {
    this.firstname = firstname;
    return this;
  }

 /**
   * Yöneticinin soy ismi.
   * @return surname
  **/
  @JsonProperty("surname")
  public String getSurname() {
    return surname;
  }

  public void setSurname(String surname) {
    this.surname = surname;
  }

  public User surname(String surname) {
    this.surname = surname;
    return this;
  }

 /**
   * Yöneticinin e-mail adresi.
   * @return email
  **/
  @JsonProperty("email")
  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public User email(String email) {
    this.email = email;
    return this;
  }

 /**
   * Yöneticinin kullanıcı adı.
   * @return username
  **/
  @JsonProperty("username")
  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public User username(String username) {
    this.username = username;
    return this;
  }

 /**
   * Yöneticinin telefon numarası.
   * @return phoneNumber
  **/
  @JsonProperty("phoneNumber")
  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public User phoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
    return this;
  }

 /**
   * Yöneticinin aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Askıya alınmış.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public Integer getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public User status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Yöneticinin site sahibi olma durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Site sahibi.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Site sahibi değil.&lt;br&gt;&lt;/div&gt;
   * @return isOwner
  **/
  @JsonProperty("isOwner")
  public String getIsOwner() {
    if (isOwner == null) {
      return null;
    }
    return isOwner.value();
  }

  public void setIsOwner(IsOwnerEnum isOwner) {
    this.isOwner = isOwner;
  }

  public User isOwner(IsOwnerEnum isOwner) {
    this.isOwner = isOwner;
    return this;
  }

 /**
   * İlgili üye grubu.
   * @return membergroups
  **/
  @JsonProperty("membergroups")
  public List<MemberGroup> getMembergroups() {
    return membergroups;
  }

  public void setMembergroups(List<MemberGroup> membergroups) {
    this.membergroups = membergroups;
  }

  public User membergroups(List<MemberGroup> membergroups) {
    this.membergroups = membergroups;
    return this;
  }

  public User addMembergroupsItem(MemberGroup membergroupsItem) {
    this.membergroups.add(membergroupsItem);
    return this;
  }

 /**
   * Yöneticinin SMS verifikasyonu yapılma bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : SMS verifikasyon yapılmış.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : SMS verifikasyon yapılmamış.&lt;br&gt;&lt;/div&gt;
   * @return smsApproved
  **/
  @JsonProperty("smsApproved")
  public String getSmsApproved() {
    if (smsApproved == null) {
      return null;
    }
    return smsApproved.value();
  }

  public void setSmsApproved(SmsApprovedEnum smsApproved) {
    this.smsApproved = smsApproved;
  }

  public User smsApproved(SmsApprovedEnum smsApproved) {
    this.smsApproved = smsApproved;
    return this;
  }

 /**
   * Get userlevel
   * @return userlevel
  **/
  @JsonProperty("userlevel")
  public ShopUserlevels getUserlevel() {
    return userlevel;
  }

  public void setUserlevel(ShopUserlevels userlevel) {
    this.userlevel = userlevel;
  }

  public User userlevel(ShopUserlevels userlevel) {
    this.userlevel = userlevel;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class User {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    firstname: ").append(toIndentedString(firstname)).append("\n");
    sb.append("    surname: ").append(toIndentedString(surname)).append("\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    isOwner: ").append(toIndentedString(isOwner)).append("\n");
    sb.append("    membergroups: ").append(toIndentedString(membergroups)).append("\n");
    sb.append("    smsApproved: ").append(toIndentedString(smsApproved)).append("\n");
    sb.append("    userlevel: ").append(toIndentedString(userlevel)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

