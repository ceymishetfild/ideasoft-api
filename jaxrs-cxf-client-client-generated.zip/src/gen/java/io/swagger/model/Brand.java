package io.swagger.model;

import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Brand  {
  
  @ApiModelProperty(example = "123", value = "Marka nesnesi kimlik değeri.")
 /**
   * Marka nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "Idea Kalem", required = true, value = "Marka nesnesi için isim değeri.")
 /**
   * Marka nesnesi için isim değeri.  
  **/
  private String name = null;

  @ApiModelProperty(example = "idea-kalem", value = "Slug değeri ilgili nesnenin Url değeridir.")
 /**
   * Slug değeri ilgili nesnenin Url değeridir.  
  **/
  private String slug = null;

  @ApiModelProperty(example = "999", value = "Marka nesnesi için sıralama değeri.")
 /**
   * Marka nesnesi için sıralama değeri.  
  **/
  private Integer sortOrder = null;


@XmlType(name="StatusEnum")
@XmlEnum(String.class)
public enum StatusEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    StatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", required = true, value = "Marka nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
 /**
   * Marka nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>  
  **/
  private StatusEnum status = null;

  @ApiModelProperty(example = "Super Tedarik", value = "Markanın tedarikçisi.")
 /**
   * Markanın tedarikçisi.  
  **/
  private String distributor = null;

  @ApiModelProperty(example = "kalem.jpg", value = "Marka nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF")
 /**
   * Marka nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF  
  **/
  private String imageFile = null;

  @ApiModelProperty(example = "Üst içerik metni.", value = "Marka nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir.")
 /**
   * Marka nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir.  
  **/
  private String showcaseContent = null;


@XmlType(name="DisplayShowcaseContentEnum")
@XmlEnum(String.class)
public enum DisplayShowcaseContentEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    DisplayShowcaseContentEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static DisplayShowcaseContentEnum fromValue(String v) {
        for (DisplayShowcaseContentEnum b : DisplayShowcaseContentEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", value = "Marka nesnesi üst içerik metninin gösterim durumu.")
 /**
   * Marka nesnesi üst içerik metninin gösterim durumu.  
  **/
  private DisplayShowcaseContentEnum displayShowcaseContent = null;

  @ApiModelProperty(example = "kırmızı, kalem, kırtasiye", value = "Arama motorları tarafından tespit edilebilecek anahtar kelimeler.")
 /**
   * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.  
  **/
  private String metaKeywords = null;

  @ApiModelProperty(example = "Kaliteli kırtasiye ürünleri.", value = "Arama motorları tarafından tespit edilebilecek açıklama yazısı.")
 /**
   * Arama motorları tarafından tespit edilebilecek açıklama yazısı.  
  **/
  private String metaDescription = null;

  @ApiModelProperty(example = "Kırmızı Kalem", value = "Marka nesnesinin etiket başlığı.")
 /**
   * Marka nesnesinin etiket başlığı.  
  **/
  private String pageTitle = null;

  @ApiModelProperty(example = "Buraya example gelecek.", value = "Marka nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.")
 /**
   * Marka nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.  
  **/
  private String attachment = null;

  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Marka nesnesinin oluşturulma zamanı.")
 /**
   * Marka nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;

  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Marka nesnesinin güncellenme zamanı.")
 /**
   * Marka nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;
 /**
   * Marka nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Brand id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Marka nesnesi için isim değeri.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Brand name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Slug değeri ilgili nesnenin Url değeridir.
   * @return slug
  **/
  @JsonProperty("slug")
  public String getSlug() {
    return slug;
  }

  public void setSlug(String slug) {
    this.slug = slug;
  }

  public Brand slug(String slug) {
    this.slug = slug;
    return this;
  }

 /**
   * Marka nesnesi için sıralama değeri.
   * minimum: 0
   * maximum: 999
   * @return sortOrder
  **/
  @JsonProperty("sortOrder")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public Brand sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

 /**
   * Marka nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Brand status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Markanın tedarikçisi.
   * @return distributor
  **/
  @JsonProperty("distributor")
  public String getDistributor() {
    return distributor;
  }

  public void setDistributor(String distributor) {
    this.distributor = distributor;
  }

  public Brand distributor(String distributor) {
    this.distributor = distributor;
    return this;
  }

 /**
   * Marka nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF
   * @return imageFile
  **/
  @JsonProperty("imageFile")
  public String getImageFile() {
    return imageFile;
  }

  public void setImageFile(String imageFile) {
    this.imageFile = imageFile;
  }

  public Brand imageFile(String imageFile) {
    this.imageFile = imageFile;
    return this;
  }

 /**
   * Marka nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir.
   * @return showcaseContent
  **/
  @JsonProperty("showcaseContent")
  public String getShowcaseContent() {
    return showcaseContent;
  }

  public void setShowcaseContent(String showcaseContent) {
    this.showcaseContent = showcaseContent;
  }

  public Brand showcaseContent(String showcaseContent) {
    this.showcaseContent = showcaseContent;
    return this;
  }

 /**
   * Marka nesnesi üst içerik metninin gösterim durumu.
   * @return displayShowcaseContent
  **/
  @JsonProperty("displayShowcaseContent")
  public String getDisplayShowcaseContent() {
    if (displayShowcaseContent == null) {
      return null;
    }
    return displayShowcaseContent.value();
  }

  public void setDisplayShowcaseContent(DisplayShowcaseContentEnum displayShowcaseContent) {
    this.displayShowcaseContent = displayShowcaseContent;
  }

  public Brand displayShowcaseContent(DisplayShowcaseContentEnum displayShowcaseContent) {
    this.displayShowcaseContent = displayShowcaseContent;
    return this;
  }

 /**
   * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.
   * @return metaKeywords
  **/
  @JsonProperty("metaKeywords")
  public String getMetaKeywords() {
    return metaKeywords;
  }

  public void setMetaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
  }

  public Brand metaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
    return this;
  }

 /**
   * Arama motorları tarafından tespit edilebilecek açıklama yazısı.
   * @return metaDescription
  **/
  @JsonProperty("metaDescription")
  public String getMetaDescription() {
    return metaDescription;
  }

  public void setMetaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
  }

  public Brand metaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
    return this;
  }

 /**
   * Marka nesnesinin etiket başlığı.
   * @return pageTitle
  **/
  @JsonProperty("pageTitle")
  public String getPageTitle() {
    return pageTitle;
  }

  public void setPageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
  }

  public Brand pageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
    return this;
  }

 /**
   * Marka nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
   * @return attachment
  **/
  @JsonProperty("attachment")
  public String getAttachment() {
    return attachment;
  }

  public void setAttachment(String attachment) {
    this.attachment = attachment;
  }

  public Brand attachment(String attachment) {
    this.attachment = attachment;
    return this;
  }

 /**
   * Marka nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Marka nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }



  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Brand {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    slug: ").append(toIndentedString(slug)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    distributor: ").append(toIndentedString(distributor)).append("\n");
    sb.append("    imageFile: ").append(toIndentedString(imageFile)).append("\n");
    sb.append("    showcaseContent: ").append(toIndentedString(showcaseContent)).append("\n");
    sb.append("    displayShowcaseContent: ").append(toIndentedString(displayShowcaseContent)).append("\n");
    sb.append("    metaKeywords: ").append(toIndentedString(metaKeywords)).append("\n");
    sb.append("    metaDescription: ").append(toIndentedString(metaDescription)).append("\n");
    sb.append("    pageTitle: ").append(toIndentedString(pageTitle)).append("\n");
    sb.append("    attachment: ").append(toIndentedString(attachment)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

