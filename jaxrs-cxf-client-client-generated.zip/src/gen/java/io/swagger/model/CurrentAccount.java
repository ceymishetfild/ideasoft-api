package io.swagger.model;

import io.swagger.model.Member;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CurrentAccount  {
  
  @ApiModelProperty(example = "123", value = "Cari hesap nesnesi kimlik değeri.")
 /**
   * Cari hesap nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "cari-hesap-kod-ornegi", value = "Cari hesap için düzenlenebilir bir kod değeri.")
 /**
   * Cari hesap için düzenlenebilir bir kod değeri.  
  **/
  private String code = null;

  @ApiModelProperty(example = "Cari Hesap Başlığı", required = true, value = "Cari hesap nesnesinin başlığı.")
 /**
   * Cari hesap nesnesinin başlığı.  
  **/
  private String title = null;

  @ApiModelProperty(example = "155.5", value = "Cari hesabın bakiyesi.")
 /**
   * Cari hesabın bakiyesi.  
  **/
  private Float balance = null;

  @ApiModelProperty(example = "155.5", value = "Cari hesap için belirlenmiş risk limiti.")
 /**
   * Cari hesap için belirlenmiş risk limiti.  
  **/
  private Float riskLimit = null;

  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Cari hesap nesnesinin oluşturulma zamanı.")
 /**
   * Cari hesap nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;

  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Cari hesap nesnesinin güncellenme zamanı.")
 /**
   * Cari hesap nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;

  @ApiModelProperty(required = true, value = "Üye nesnesi.")
 /**
   * Üye nesnesi.  
  **/
  private Member member = null;
 /**
   * Cari hesap nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public CurrentAccount id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Cari hesap için düzenlenebilir bir kod değeri.
   * @return code
  **/
  @JsonProperty("code")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public CurrentAccount code(String code) {
    this.code = code;
    return this;
  }

 /**
   * Cari hesap nesnesinin başlığı.
   * @return title
  **/
  @JsonProperty("title")
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public CurrentAccount title(String title) {
    this.title = title;
    return this;
  }

 /**
   * Cari hesabın bakiyesi.
   * @return balance
  **/
  @JsonProperty("balance")
  public Float getBalance() {
    return balance;
  }

  public void setBalance(Float balance) {
    this.balance = balance;
  }

  public CurrentAccount balance(Float balance) {
    this.balance = balance;
    return this;
  }

 /**
   * Cari hesap için belirlenmiş risk limiti.
   * minimum: 0
   * @return riskLimit
  **/
  @JsonProperty("riskLimit")
  public Float getRiskLimit() {
    return riskLimit;
  }

  public void setRiskLimit(Float riskLimit) {
    this.riskLimit = riskLimit;
  }

  public CurrentAccount riskLimit(Float riskLimit) {
    this.riskLimit = riskLimit;
    return this;
  }

 /**
   * Cari hesap nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Cari hesap nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }


 /**
   * Üye nesnesi.
   * @return member
  **/
  @JsonProperty("member")
  public Member getMember() {
    return member;
  }

  public void setMember(Member member) {
    this.member = member;
  }

  public CurrentAccount member(Member member) {
    this.member = member;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CurrentAccount {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    balance: ").append(toIndentedString(balance)).append("\n");
    sb.append("    riskLimit: ").append(toIndentedString(riskLimit)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    member: ").append(toIndentedString(member)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

