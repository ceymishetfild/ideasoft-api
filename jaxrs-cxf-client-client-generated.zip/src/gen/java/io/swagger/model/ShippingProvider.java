package io.swagger.model;

import io.swagger.model.ShippingProviderSetting;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ShippingProvider  {
  
  @ApiModelProperty(example = "123", value = "Teslimat hizmeti sağlayıcısı nesnesi kimlik değeri.")
 /**
   * Teslimat hizmeti sağlayıcısı nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "idea", required = true, value = "Teslimat hizmeti sağlayıcısı kodu. Benzersiz olmalıdır.")
 /**
   * Teslimat hizmeti sağlayıcısı kodu. Benzersiz olmalıdır.  
  **/
  private String code = null;

  @ApiModelProperty(example = "Idea Cargo", required = true, value = "Teslimat hizmeti sağlayıcısı nesnesi için isim değeri.")
 /**
   * Teslimat hizmeti sağlayıcısı nesnesi için isim değeri.  
  **/
  private String name = null;

  @ApiModelProperty(example = "http://www.ideacargo.com/bilgi-servisleri/sayfalar/kargom-nerede.aspx", required = true, value = "Kargo takip url.")
 /**
   * Kargo takip url.  
  **/
  private String trackingUrl = null;


@XmlType(name="TrackingFormMethodEnum")
@XmlEnum(String.class)
public enum TrackingFormMethodEnum {

@XmlEnumValue("get") GET(String.valueOf("get")), @XmlEnumValue("post") POST(String.valueOf("post"));


    private String value;

    TrackingFormMethodEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static TrackingFormMethodEnum fromValue(String v) {
        for (TrackingFormMethodEnum b : TrackingFormMethodEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "get", value = "Kargo takip formu almak için kullanılacak method.<div class='idea_choice_list'><code>get</code> : GET methodu.<br><code>post</code> : POST methodu.<br></div>")
 /**
   * Kargo takip formu almak için kullanılacak method.<div class='idea_choice_list'><code>get</code> : GET methodu.<br><code>post</code> : POST methodu.<br></div>  
  **/
  private TrackingFormMethodEnum trackingFormMethod = null;

  @ApiModelProperty(example = "q={tracking_code}&val=1", value = "İlgili kargo takip formu almak için kullanılacak yük.")
 /**
   * İlgili kargo takip formu almak için kullanılacak yük.  
  **/
  private String payload = null;

  @ApiModelProperty(value = "Teslimat hizmeti sağlayıcısı için ayarlar.")
 /**
   * Teslimat hizmeti sağlayıcısı için ayarlar.  
  **/
  private List<ShippingProviderSetting> settings = null;
 /**
   * Teslimat hizmeti sağlayıcısı nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ShippingProvider id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Teslimat hizmeti sağlayıcısı kodu. Benzersiz olmalıdır.
   * @return code
  **/
  @JsonProperty("code")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public ShippingProvider code(String code) {
    this.code = code;
    return this;
  }

 /**
   * Teslimat hizmeti sağlayıcısı nesnesi için isim değeri.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public ShippingProvider name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Kargo takip url.
   * @return trackingUrl
  **/
  @JsonProperty("trackingUrl")
  public String getTrackingUrl() {
    return trackingUrl;
  }

  public void setTrackingUrl(String trackingUrl) {
    this.trackingUrl = trackingUrl;
  }

  public ShippingProvider trackingUrl(String trackingUrl) {
    this.trackingUrl = trackingUrl;
    return this;
  }

 /**
   * Kargo takip formu almak için kullanılacak method.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;get&lt;/code&gt; : GET methodu.&lt;br&gt;&lt;code&gt;post&lt;/code&gt; : POST methodu.&lt;br&gt;&lt;/div&gt;
   * @return trackingFormMethod
  **/
  @JsonProperty("trackingFormMethod")
  public String getTrackingFormMethod() {
    if (trackingFormMethod == null) {
      return null;
    }
    return trackingFormMethod.value();
  }

  public void setTrackingFormMethod(TrackingFormMethodEnum trackingFormMethod) {
    this.trackingFormMethod = trackingFormMethod;
  }

  public ShippingProvider trackingFormMethod(TrackingFormMethodEnum trackingFormMethod) {
    this.trackingFormMethod = trackingFormMethod;
    return this;
  }

 /**
   * İlgili kargo takip formu almak için kullanılacak yük.
   * @return payload
  **/
  @JsonProperty("payload")
  public String getPayload() {
    return payload;
  }

  public void setPayload(String payload) {
    this.payload = payload;
  }

  public ShippingProvider payload(String payload) {
    this.payload = payload;
    return this;
  }

 /**
   * Teslimat hizmeti sağlayıcısı için ayarlar.
   * @return settings
  **/
  @JsonProperty("settings")
  public List<ShippingProviderSetting> getSettings() {
    return settings;
  }

  public void setSettings(List<ShippingProviderSetting> settings) {
    this.settings = settings;
  }

  public ShippingProvider settings(List<ShippingProviderSetting> settings) {
    this.settings = settings;
    return this;
  }

  public ShippingProvider addSettingsItem(ShippingProviderSetting settingsItem) {
    this.settings.add(settingsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShippingProvider {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    trackingUrl: ").append(toIndentedString(trackingUrl)).append("\n");
    sb.append("    trackingFormMethod: ").append(toIndentedString(trackingFormMethod)).append("\n");
    sb.append("    payload: ").append(toIndentedString(payload)).append("\n");
    sb.append("    settings: ").append(toIndentedString(settings)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

