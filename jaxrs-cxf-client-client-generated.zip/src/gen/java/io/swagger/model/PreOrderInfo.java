package io.swagger.model;

import io.swagger.model.Country;
import io.swagger.model.Location;
import io.swagger.model.MemberAddress;
import io.swagger.model.ShippingCompany;
import java.util.Date;
import org.joda.time.LocalDate;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PreOrderInfo  {
  
  @ApiModelProperty(example = "123", value = "Sipariş öncesi bilgisi nesnesi kimlik değeri.")
 /**
   * Sipariş öncesi bilgisi nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "oibtkn9rspcdbmphf8iceondg1", required = true, value = "Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri.")
 /**
   * Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri.  
  **/
  private String sessionId = null;
  @ApiModelProperty(example = "John", value = "Müşterinin ismi.")
 /**
   * Müşterinin ismi.  
  **/
  private String customerFirstname = null;
  @ApiModelProperty(example = "Doe", value = "Müşterinin soy ismi.")
 /**
   * Müşterinin soy ismi.  
  **/
  private String customerSurname = null;
  @ApiModelProperty(example = "johndoe@ideasoft.com.tr", value = "Müşterinin e-mail adresi.")
 /**
   * Müşterinin e-mail adresi.  
  **/
  private String customerEmail = null;
  @ApiModelProperty(example = "John", required = true, value = "Teslimat yapılacak kişinin ismi.")
 /**
   * Teslimat yapılacak kişinin ismi.  
  **/
  private String shippingFirstname = null;
  @ApiModelProperty(example = "Doe", required = true, value = "Teslimat yapılacak kişinin soy ismi.")
 /**
   * Teslimat yapılacak kişinin soy ismi.  
  **/
  private String shippingSurname = null;
  @ApiModelProperty(example = "Cumhuriyet Mah. Libadiye Cad. Çimen Sok. No:2", required = true, value = "Teslimat adresi bilgileri.")
 /**
   * Teslimat adresi bilgileri.  
  **/
  private String shippingAddress = null;
  @ApiModelProperty(example = "+90 (216) 326 04 77", required = true, value = "Teslimat yapılacak kişinin telefon numarası.")
 /**
   * Teslimat yapılacak kişinin telefon numarası.  
  **/
  private String shippingPhoneNumber = null;
  @ApiModelProperty(example = "+90 (555) 555 55 55", required = true, value = "Teslimat yapılacak kişinin mobil telefon numarası.")
 /**
   * Teslimat yapılacak kişinin mobil telefon numarası.  
  **/
  private String shippingMobilePhoneNumber = null;
  @ApiModelProperty(example = "İstanbul", required = true, value = "Teslimat şehri.")
 /**
   * Teslimat şehri.  
  **/
  private String shippingLocationName = null;
  @ApiModelProperty(example = "Üsküdar", required = true, value = "Teslimat ilçesi.")
 /**
   * Teslimat ilçesi.  
  **/
  private String shippingTown = null;

@XmlType(name="DifferentBillingAddressEnum")
@XmlEnum(String.class)
public enum DifferentBillingAddressEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    DifferentBillingAddressEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static DifferentBillingAddressEnum fromValue(String v) {
        for (DifferentBillingAddressEnum b : DifferentBillingAddressEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.<div class='idea_choice_list'><code>1</code> : Var<br><code>0</code> : Yok<br></div>")
 /**
   * Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.<div class='idea_choice_list'><code>1</code> : Var<br><code>0</code> : Yok<br></div>  
  **/
  private DifferentBillingAddressEnum differentBillingAddress = null;
  @ApiModelProperty(example = "John", required = true, value = "Fatura kesilen kişinin ismi.")
 /**
   * Fatura kesilen kişinin ismi.  
  **/
  private String billingFirstname = null;
  @ApiModelProperty(example = "Doe", required = true, value = "Fatura kesilen kişinin soy ismi.")
 /**
   * Fatura kesilen kişinin soy ismi.  
  **/
  private String billingSurname = null;
  @ApiModelProperty(example = "Cumhuriyet Mah. Libadiye Cad. Çimen Sok. No:2", required = true, value = "Fatura adresi bilgileri.")
 /**
   * Fatura adresi bilgileri.  
  **/
  private String billingAddress = null;
  @ApiModelProperty(example = "+90 (216) 326 04 77", required = true, value = "Fatura kesilen kişinin telefon numarası.")
 /**
   * Fatura kesilen kişinin telefon numarası.  
  **/
  private String billingPhoneNumber = null;
  @ApiModelProperty(example = "+90 (555) 555 55 55", required = true, value = "Fatura kesilen kişinin mobil telefon numarası.")
 /**
   * Fatura kesilen kişinin mobil telefon numarası.  
  **/
  private String billingMobilePhoneNumber = null;
  @ApiModelProperty(example = "İstanbul", required = true, value = "Fatura adresi şehri")
 /**
   * Fatura adresi şehri  
  **/
  private String billingLocationName = null;
  @ApiModelProperty(example = "Üsküdar", required = true, value = "Fatura adresi ilçesi.")
 /**
   * Fatura adresi ilçesi.  
  **/
  private String billingTown = null;

@XmlType(name="BillingInvoiceTypeEnum")
@XmlEnum(String.class)
public enum BillingInvoiceTypeEnum {

@XmlEnumValue("individual") INDIVIDUAL(String.valueOf("individual")), @XmlEnumValue("corporate") CORPORATE(String.valueOf("corporate"));


    private String value;

    BillingInvoiceTypeEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static BillingInvoiceTypeEnum fromValue(String v) {
        for (BillingInvoiceTypeEnum b : BillingInvoiceTypeEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "individual", required = true, value = "Fatura tipini belirtir.<div class='idea_choice_list'><code>individual</code> : Bireysel<br><code>corporate</code> : Kurumsal<br></div>")
 /**
   * Fatura tipini belirtir.<div class='idea_choice_list'><code>individual</code> : Bireysel<br><code>corporate</code> : Kurumsal<br></div>  
  **/
  private BillingInvoiceTypeEnum billingInvoiceType = null;
  @ApiModelProperty(example = "11111111111", value = "Fatura kesilen kişinin TC kimlik numarası.")
 /**
   * Fatura kesilen kişinin TC kimlik numarası.  
  **/
  private String billingIdentityRegistrationNumber = null;
  @ApiModelProperty(example = "Üsküdar", value = "Fatura kesilen kişi/kurumun vergi dairesi.")
 /**
   * Fatura kesilen kişi/kurumun vergi dairesi.  
  **/
  private String billingTaxOffice = null;
  @ApiModelProperty(example = "9325912620", value = "Fatura kesilen kişi/kurum vergi numarası.")
 /**
   * Fatura kesilen kişi/kurum vergi numarası.  
  **/
  private String billingTaxNo = null;

@XmlType(name="IsEinvoiceUserEnum")
@XmlEnum(String.class)
public enum IsEinvoiceUserEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    IsEinvoiceUserEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static IsEinvoiceUserEnum fromValue(String v) {
        for (IsEinvoiceUserEnum b : IsEinvoiceUserEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", value = "Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div>")
 /**
   * Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div>  
  **/
  private IsEinvoiceUserEnum isEinvoiceUser = null;

@XmlType(name="UseGiftPackageEnum")
@XmlEnum(String.class)
public enum UseGiftPackageEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    UseGiftPackageEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static UseGiftPackageEnum fromValue(String v) {
        for (UseGiftPackageEnum b : UseGiftPackageEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div>")
 /**
   * Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div>  
  **/
  private UseGiftPackageEnum useGiftPackage = null;
  @ApiModelProperty(example = "Doğum günün kutlu olsun.", value = "Hediye notu bilgisi.")
 /**
   * Hediye notu bilgisi.  
  **/
  private String giftNote = null;
  @ApiModelProperty(example = "kalem.jpg", value = "Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif")
 /**
   * Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif  
  **/
  private String imageFile = null;
  @ApiModelProperty(example = "2018-02-21T18:30:00+0000", value = "Müşterinin teslimatın gerçekleşmisini istediği tarih.")
 /**
   * Müşterinin teslimatın gerçekleşmisini istediği tarih.  
  **/
  private LocalDate deliveryDate = null;
  @ApiModelProperty(example = "18:00-19:00", value = "API bu değeri otomatik oluşturur.")
 /**
   * API bu değeri otomatik oluşturur.  
  **/
  private String deliveryTime = null;
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı.")
 /**
   * Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Sipariş öncesi bilgisi nesnesinin güncellenme zamanı.")
 /**
   * Sipariş öncesi bilgisi nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;
  @ApiModelProperty(value = "")
  private Country billingCountry = null;
  @ApiModelProperty(value = "")
  private Location billingLocation = null;
  @ApiModelProperty(value = "")
  private ShippingCompany shippingCompany = null;
  @ApiModelProperty(value = "")
  private Country shippingCountry = null;
  @ApiModelProperty(value = "")
  private Location shippingLocation = null;
  @ApiModelProperty(value = "")
  private MemberAddress memberShippingAddress = null;
  @ApiModelProperty(value = "")
  private MemberAddress memberBillingAddress = null;

 /**
   * Sipariş öncesi bilgisi nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public PreOrderInfo id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri.
   * @return sessionId
  **/
  @JsonProperty("sessionId")
  public String getSessionId() {
    return sessionId;
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  public PreOrderInfo sessionId(String sessionId) {
    this.sessionId = sessionId;
    return this;
  }

 /**
   * Müşterinin ismi.
   * @return customerFirstname
  **/
  @JsonProperty("customerFirstname")
  public String getCustomerFirstname() {
    return customerFirstname;
  }

  public void setCustomerFirstname(String customerFirstname) {
    this.customerFirstname = customerFirstname;
  }

  public PreOrderInfo customerFirstname(String customerFirstname) {
    this.customerFirstname = customerFirstname;
    return this;
  }

 /**
   * Müşterinin soy ismi.
   * @return customerSurname
  **/
  @JsonProperty("customerSurname")
  public String getCustomerSurname() {
    return customerSurname;
  }

  public void setCustomerSurname(String customerSurname) {
    this.customerSurname = customerSurname;
  }

  public PreOrderInfo customerSurname(String customerSurname) {
    this.customerSurname = customerSurname;
    return this;
  }

 /**
   * Müşterinin e-mail adresi.
   * @return customerEmail
  **/
  @JsonProperty("customerEmail")
  public String getCustomerEmail() {
    return customerEmail;
  }

  public void setCustomerEmail(String customerEmail) {
    this.customerEmail = customerEmail;
  }

  public PreOrderInfo customerEmail(String customerEmail) {
    this.customerEmail = customerEmail;
    return this;
  }

 /**
   * Teslimat yapılacak kişinin ismi.
   * @return shippingFirstname
  **/
  @JsonProperty("shippingFirstname")
  public String getShippingFirstname() {
    return shippingFirstname;
  }

  public void setShippingFirstname(String shippingFirstname) {
    this.shippingFirstname = shippingFirstname;
  }

  public PreOrderInfo shippingFirstname(String shippingFirstname) {
    this.shippingFirstname = shippingFirstname;
    return this;
  }

 /**
   * Teslimat yapılacak kişinin soy ismi.
   * @return shippingSurname
  **/
  @JsonProperty("shippingSurname")
  public String getShippingSurname() {
    return shippingSurname;
  }

  public void setShippingSurname(String shippingSurname) {
    this.shippingSurname = shippingSurname;
  }

  public PreOrderInfo shippingSurname(String shippingSurname) {
    this.shippingSurname = shippingSurname;
    return this;
  }

 /**
   * Teslimat adresi bilgileri.
   * @return shippingAddress
  **/
  @JsonProperty("shippingAddress")
  public String getShippingAddress() {
    return shippingAddress;
  }

  public void setShippingAddress(String shippingAddress) {
    this.shippingAddress = shippingAddress;
  }

  public PreOrderInfo shippingAddress(String shippingAddress) {
    this.shippingAddress = shippingAddress;
    return this;
  }

 /**
   * Teslimat yapılacak kişinin telefon numarası.
   * @return shippingPhoneNumber
  **/
  @JsonProperty("shippingPhoneNumber")
  public String getShippingPhoneNumber() {
    return shippingPhoneNumber;
  }

  public void setShippingPhoneNumber(String shippingPhoneNumber) {
    this.shippingPhoneNumber = shippingPhoneNumber;
  }

  public PreOrderInfo shippingPhoneNumber(String shippingPhoneNumber) {
    this.shippingPhoneNumber = shippingPhoneNumber;
    return this;
  }

 /**
   * Teslimat yapılacak kişinin mobil telefon numarası.
   * @return shippingMobilePhoneNumber
  **/
  @JsonProperty("shippingMobilePhoneNumber")
  public String getShippingMobilePhoneNumber() {
    return shippingMobilePhoneNumber;
  }

  public void setShippingMobilePhoneNumber(String shippingMobilePhoneNumber) {
    this.shippingMobilePhoneNumber = shippingMobilePhoneNumber;
  }

  public PreOrderInfo shippingMobilePhoneNumber(String shippingMobilePhoneNumber) {
    this.shippingMobilePhoneNumber = shippingMobilePhoneNumber;
    return this;
  }

 /**
   * Teslimat şehri.
   * @return shippingLocationName
  **/
  @JsonProperty("shippingLocationName")
  public String getShippingLocationName() {
    return shippingLocationName;
  }

  public void setShippingLocationName(String shippingLocationName) {
    this.shippingLocationName = shippingLocationName;
  }

  public PreOrderInfo shippingLocationName(String shippingLocationName) {
    this.shippingLocationName = shippingLocationName;
    return this;
  }

 /**
   * Teslimat ilçesi.
   * @return shippingTown
  **/
  @JsonProperty("shippingTown")
  public String getShippingTown() {
    return shippingTown;
  }

  public void setShippingTown(String shippingTown) {
    this.shippingTown = shippingTown;
  }

  public PreOrderInfo shippingTown(String shippingTown) {
    this.shippingTown = shippingTown;
    return this;
  }

 /**
   * Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yok&lt;br&gt;&lt;/div&gt;
   * @return differentBillingAddress
  **/
  @JsonProperty("differentBillingAddress")
  public String getDifferentBillingAddress() {
    if (differentBillingAddress == null) {
      return null;
    }
    return differentBillingAddress.value();
  }

  public void setDifferentBillingAddress(DifferentBillingAddressEnum differentBillingAddress) {
    this.differentBillingAddress = differentBillingAddress;
  }

  public PreOrderInfo differentBillingAddress(DifferentBillingAddressEnum differentBillingAddress) {
    this.differentBillingAddress = differentBillingAddress;
    return this;
  }

 /**
   * Fatura kesilen kişinin ismi.
   * @return billingFirstname
  **/
  @JsonProperty("billingFirstname")
  public String getBillingFirstname() {
    return billingFirstname;
  }

  public void setBillingFirstname(String billingFirstname) {
    this.billingFirstname = billingFirstname;
  }

  public PreOrderInfo billingFirstname(String billingFirstname) {
    this.billingFirstname = billingFirstname;
    return this;
  }

 /**
   * Fatura kesilen kişinin soy ismi.
   * @return billingSurname
  **/
  @JsonProperty("billingSurname")
  public String getBillingSurname() {
    return billingSurname;
  }

  public void setBillingSurname(String billingSurname) {
    this.billingSurname = billingSurname;
  }

  public PreOrderInfo billingSurname(String billingSurname) {
    this.billingSurname = billingSurname;
    return this;
  }

 /**
   * Fatura adresi bilgileri.
   * @return billingAddress
  **/
  @JsonProperty("billingAddress")
  public String getBillingAddress() {
    return billingAddress;
  }

  public void setBillingAddress(String billingAddress) {
    this.billingAddress = billingAddress;
  }

  public PreOrderInfo billingAddress(String billingAddress) {
    this.billingAddress = billingAddress;
    return this;
  }

 /**
   * Fatura kesilen kişinin telefon numarası.
   * @return billingPhoneNumber
  **/
  @JsonProperty("billingPhoneNumber")
  public String getBillingPhoneNumber() {
    return billingPhoneNumber;
  }

  public void setBillingPhoneNumber(String billingPhoneNumber) {
    this.billingPhoneNumber = billingPhoneNumber;
  }

  public PreOrderInfo billingPhoneNumber(String billingPhoneNumber) {
    this.billingPhoneNumber = billingPhoneNumber;
    return this;
  }

 /**
   * Fatura kesilen kişinin mobil telefon numarası.
   * @return billingMobilePhoneNumber
  **/
  @JsonProperty("billingMobilePhoneNumber")
  public String getBillingMobilePhoneNumber() {
    return billingMobilePhoneNumber;
  }

  public void setBillingMobilePhoneNumber(String billingMobilePhoneNumber) {
    this.billingMobilePhoneNumber = billingMobilePhoneNumber;
  }

  public PreOrderInfo billingMobilePhoneNumber(String billingMobilePhoneNumber) {
    this.billingMobilePhoneNumber = billingMobilePhoneNumber;
    return this;
  }

 /**
   * Fatura adresi şehri
   * @return billingLocationName
  **/
  @JsonProperty("billingLocationName")
  public String getBillingLocationName() {
    return billingLocationName;
  }

  public void setBillingLocationName(String billingLocationName) {
    this.billingLocationName = billingLocationName;
  }

  public PreOrderInfo billingLocationName(String billingLocationName) {
    this.billingLocationName = billingLocationName;
    return this;
  }

 /**
   * Fatura adresi ilçesi.
   * @return billingTown
  **/
  @JsonProperty("billingTown")
  public String getBillingTown() {
    return billingTown;
  }

  public void setBillingTown(String billingTown) {
    this.billingTown = billingTown;
  }

  public PreOrderInfo billingTown(String billingTown) {
    this.billingTown = billingTown;
    return this;
  }

 /**
   * Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt;
   * @return billingInvoiceType
  **/
  @JsonProperty("billingInvoiceType")
  public String getBillingInvoiceType() {
    if (billingInvoiceType == null) {
      return null;
    }
    return billingInvoiceType.value();
  }

  public void setBillingInvoiceType(BillingInvoiceTypeEnum billingInvoiceType) {
    this.billingInvoiceType = billingInvoiceType;
  }

  public PreOrderInfo billingInvoiceType(BillingInvoiceTypeEnum billingInvoiceType) {
    this.billingInvoiceType = billingInvoiceType;
    return this;
  }

 /**
   * Fatura kesilen kişinin TC kimlik numarası.
   * @return billingIdentityRegistrationNumber
  **/
  @JsonProperty("billingIdentityRegistrationNumber")
  public String getBillingIdentityRegistrationNumber() {
    return billingIdentityRegistrationNumber;
  }

  public void setBillingIdentityRegistrationNumber(String billingIdentityRegistrationNumber) {
    this.billingIdentityRegistrationNumber = billingIdentityRegistrationNumber;
  }

  public PreOrderInfo billingIdentityRegistrationNumber(String billingIdentityRegistrationNumber) {
    this.billingIdentityRegistrationNumber = billingIdentityRegistrationNumber;
    return this;
  }

 /**
   * Fatura kesilen kişi/kurumun vergi dairesi.
   * @return billingTaxOffice
  **/
  @JsonProperty("billingTaxOffice")
  public String getBillingTaxOffice() {
    return billingTaxOffice;
  }

  public void setBillingTaxOffice(String billingTaxOffice) {
    this.billingTaxOffice = billingTaxOffice;
  }

  public PreOrderInfo billingTaxOffice(String billingTaxOffice) {
    this.billingTaxOffice = billingTaxOffice;
    return this;
  }

 /**
   * Fatura kesilen kişi/kurum vergi numarası.
   * @return billingTaxNo
  **/
  @JsonProperty("billingTaxNo")
  public String getBillingTaxNo() {
    return billingTaxNo;
  }

  public void setBillingTaxNo(String billingTaxNo) {
    this.billingTaxNo = billingTaxNo;
  }

  public PreOrderInfo billingTaxNo(String billingTaxNo) {
    this.billingTaxNo = billingTaxNo;
    return this;
  }

 /**
   * Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt;
   * @return isEinvoiceUser
  **/
  @JsonProperty("isEinvoiceUser")
  public String getIsEinvoiceUser() {
    if (isEinvoiceUser == null) {
      return null;
    }
    return isEinvoiceUser.value();
  }

  public void setIsEinvoiceUser(IsEinvoiceUserEnum isEinvoiceUser) {
    this.isEinvoiceUser = isEinvoiceUser;
  }

  public PreOrderInfo isEinvoiceUser(IsEinvoiceUserEnum isEinvoiceUser) {
    this.isEinvoiceUser = isEinvoiceUser;
    return this;
  }

 /**
   * Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt;
   * @return useGiftPackage
  **/
  @JsonProperty("useGiftPackage")
  public String getUseGiftPackage() {
    if (useGiftPackage == null) {
      return null;
    }
    return useGiftPackage.value();
  }

  public void setUseGiftPackage(UseGiftPackageEnum useGiftPackage) {
    this.useGiftPackage = useGiftPackage;
  }

  public PreOrderInfo useGiftPackage(UseGiftPackageEnum useGiftPackage) {
    this.useGiftPackage = useGiftPackage;
    return this;
  }

 /**
   * Hediye notu bilgisi.
   * @return giftNote
  **/
  @JsonProperty("giftNote")
  public String getGiftNote() {
    return giftNote;
  }

  public void setGiftNote(String giftNote) {
    this.giftNote = giftNote;
  }

  public PreOrderInfo giftNote(String giftNote) {
    this.giftNote = giftNote;
    return this;
  }

 /**
   * Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif
   * @return imageFile
  **/
  @JsonProperty("imageFile")
  public String getImageFile() {
    return imageFile;
  }

  public void setImageFile(String imageFile) {
    this.imageFile = imageFile;
  }

  public PreOrderInfo imageFile(String imageFile) {
    this.imageFile = imageFile;
    return this;
  }

 /**
   * Müşterinin teslimatın gerçekleşmisini istediği tarih.
   * @return deliveryDate
  **/
  @JsonProperty("deliveryDate")
  public LocalDate getDeliveryDate() {
    return deliveryDate;
  }

  public void setDeliveryDate(LocalDate deliveryDate) {
    this.deliveryDate = deliveryDate;
  }

  public PreOrderInfo deliveryDate(LocalDate deliveryDate) {
    this.deliveryDate = deliveryDate;
    return this;
  }

 /**
   * API bu değeri otomatik oluşturur.
   * @return deliveryTime
  **/
  @JsonProperty("deliveryTime")
  public String getDeliveryTime() {
    return deliveryTime;
  }

  public void setDeliveryTime(String deliveryTime) {
    this.deliveryTime = deliveryTime;
  }

  public PreOrderInfo deliveryTime(String deliveryTime) {
    this.deliveryTime = deliveryTime;
    return this;
  }

 /**
   * Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Sipariş öncesi bilgisi nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }


 /**
   * Get billingCountry
   * @return billingCountry
  **/
  @JsonProperty("billingCountry")
  public Country getBillingCountry() {
    return billingCountry;
  }

  public void setBillingCountry(Country billingCountry) {
    this.billingCountry = billingCountry;
  }

  public PreOrderInfo billingCountry(Country billingCountry) {
    this.billingCountry = billingCountry;
    return this;
  }

 /**
   * Get billingLocation
   * @return billingLocation
  **/
  @JsonProperty("billingLocation")
  public Location getBillingLocation() {
    return billingLocation;
  }

  public void setBillingLocation(Location billingLocation) {
    this.billingLocation = billingLocation;
  }

  public PreOrderInfo billingLocation(Location billingLocation) {
    this.billingLocation = billingLocation;
    return this;
  }

 /**
   * Get shippingCompany
   * @return shippingCompany
  **/
  @JsonProperty("shippingCompany")
  public ShippingCompany getShippingCompany() {
    return shippingCompany;
  }

  public void setShippingCompany(ShippingCompany shippingCompany) {
    this.shippingCompany = shippingCompany;
  }

  public PreOrderInfo shippingCompany(ShippingCompany shippingCompany) {
    this.shippingCompany = shippingCompany;
    return this;
  }

 /**
   * Get shippingCountry
   * @return shippingCountry
  **/
  @JsonProperty("shippingCountry")
  public Country getShippingCountry() {
    return shippingCountry;
  }

  public void setShippingCountry(Country shippingCountry) {
    this.shippingCountry = shippingCountry;
  }

  public PreOrderInfo shippingCountry(Country shippingCountry) {
    this.shippingCountry = shippingCountry;
    return this;
  }

 /**
   * Get shippingLocation
   * @return shippingLocation
  **/
  @JsonProperty("shippingLocation")
  public Location getShippingLocation() {
    return shippingLocation;
  }

  public void setShippingLocation(Location shippingLocation) {
    this.shippingLocation = shippingLocation;
  }

  public PreOrderInfo shippingLocation(Location shippingLocation) {
    this.shippingLocation = shippingLocation;
    return this;
  }

 /**
   * Get memberShippingAddress
   * @return memberShippingAddress
  **/
  @JsonProperty("memberShippingAddress")
  public MemberAddress getMemberShippingAddress() {
    return memberShippingAddress;
  }

  public void setMemberShippingAddress(MemberAddress memberShippingAddress) {
    this.memberShippingAddress = memberShippingAddress;
  }

  public PreOrderInfo memberShippingAddress(MemberAddress memberShippingAddress) {
    this.memberShippingAddress = memberShippingAddress;
    return this;
  }

 /**
   * Get memberBillingAddress
   * @return memberBillingAddress
  **/
  @JsonProperty("memberBillingAddress")
  public MemberAddress getMemberBillingAddress() {
    return memberBillingAddress;
  }

  public void setMemberBillingAddress(MemberAddress memberBillingAddress) {
    this.memberBillingAddress = memberBillingAddress;
  }

  public PreOrderInfo memberBillingAddress(MemberAddress memberBillingAddress) {
    this.memberBillingAddress = memberBillingAddress;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PreOrderInfo {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    sessionId: ").append(toIndentedString(sessionId)).append("\n");
    sb.append("    customerFirstname: ").append(toIndentedString(customerFirstname)).append("\n");
    sb.append("    customerSurname: ").append(toIndentedString(customerSurname)).append("\n");
    sb.append("    customerEmail: ").append(toIndentedString(customerEmail)).append("\n");
    sb.append("    shippingFirstname: ").append(toIndentedString(shippingFirstname)).append("\n");
    sb.append("    shippingSurname: ").append(toIndentedString(shippingSurname)).append("\n");
    sb.append("    shippingAddress: ").append(toIndentedString(shippingAddress)).append("\n");
    sb.append("    shippingPhoneNumber: ").append(toIndentedString(shippingPhoneNumber)).append("\n");
    sb.append("    shippingMobilePhoneNumber: ").append(toIndentedString(shippingMobilePhoneNumber)).append("\n");
    sb.append("    shippingLocationName: ").append(toIndentedString(shippingLocationName)).append("\n");
    sb.append("    shippingTown: ").append(toIndentedString(shippingTown)).append("\n");
    sb.append("    differentBillingAddress: ").append(toIndentedString(differentBillingAddress)).append("\n");
    sb.append("    billingFirstname: ").append(toIndentedString(billingFirstname)).append("\n");
    sb.append("    billingSurname: ").append(toIndentedString(billingSurname)).append("\n");
    sb.append("    billingAddress: ").append(toIndentedString(billingAddress)).append("\n");
    sb.append("    billingPhoneNumber: ").append(toIndentedString(billingPhoneNumber)).append("\n");
    sb.append("    billingMobilePhoneNumber: ").append(toIndentedString(billingMobilePhoneNumber)).append("\n");
    sb.append("    billingLocationName: ").append(toIndentedString(billingLocationName)).append("\n");
    sb.append("    billingTown: ").append(toIndentedString(billingTown)).append("\n");
    sb.append("    billingInvoiceType: ").append(toIndentedString(billingInvoiceType)).append("\n");
    sb.append("    billingIdentityRegistrationNumber: ").append(toIndentedString(billingIdentityRegistrationNumber)).append("\n");
    sb.append("    billingTaxOffice: ").append(toIndentedString(billingTaxOffice)).append("\n");
    sb.append("    billingTaxNo: ").append(toIndentedString(billingTaxNo)).append("\n");
    sb.append("    isEinvoiceUser: ").append(toIndentedString(isEinvoiceUser)).append("\n");
    sb.append("    useGiftPackage: ").append(toIndentedString(useGiftPackage)).append("\n");
    sb.append("    giftNote: ").append(toIndentedString(giftNote)).append("\n");
    sb.append("    imageFile: ").append(toIndentedString(imageFile)).append("\n");
    sb.append("    deliveryDate: ").append(toIndentedString(deliveryDate)).append("\n");
    sb.append("    deliveryTime: ").append(toIndentedString(deliveryTime)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    billingCountry: ").append(toIndentedString(billingCountry)).append("\n");
    sb.append("    billingLocation: ").append(toIndentedString(billingLocation)).append("\n");
    sb.append("    shippingCompany: ").append(toIndentedString(shippingCompany)).append("\n");
    sb.append("    shippingCountry: ").append(toIndentedString(shippingCountry)).append("\n");
    sb.append("    shippingLocation: ").append(toIndentedString(shippingLocation)).append("\n");
    sb.append("    memberShippingAddress: ").append(toIndentedString(memberShippingAddress)).append("\n");
    sb.append("    memberBillingAddress: ").append(toIndentedString(memberBillingAddress)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

