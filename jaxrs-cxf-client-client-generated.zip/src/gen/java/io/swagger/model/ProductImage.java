package io.swagger.model;

import io.swagger.model.Product;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductImage  {
  
  @ApiModelProperty(example = "123", value = "Ürün resmi nesnesi kimlik değeri.")
 /**
   * Ürün resmi nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "ornek-urun-gorseli", required = true, value = "Ürün resminin dosya adı. Uzantı olmadan yazılmalıdır.")
 /**
   * Ürün resminin dosya adı. Uzantı olmadan yazılmalıdır.  
  **/
  private String filename = null;


@XmlType(name="ExtensionEnum")
@XmlEnum(String.class)
public enum ExtensionEnum {

@XmlEnumValue("jpg") JPG(String.valueOf("jpg")), @XmlEnumValue("png") PNG(String.valueOf("png")), @XmlEnumValue("gif") GIF(String.valueOf("gif")), @XmlEnumValue("jpeg") JPEG(String.valueOf("jpeg"));


    private String value;

    ExtensionEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static ExtensionEnum fromValue(String v) {
        for (ExtensionEnum b : ExtensionEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "jpg", required = true, value = "Resim için geçerli dosya uzantıları.<div class='idea_choice_list'><code>jpg</code> : jpg dosyaları için geçerli uzantı.<br><code>png</code> : png dosyaları için geçerli uzantı.<br><code>gif</code> : gif dosyaları için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyaları için geçerli uzantı.<br></div>")
 /**
   * Resim için geçerli dosya uzantıları.<div class='idea_choice_list'><code>jpg</code> : jpg dosyaları için geçerli uzantı.<br><code>png</code> : png dosyaları için geçerli uzantı.<br><code>gif</code> : gif dosyaları için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyaları için geçerli uzantı.<br></div>  
  **/
  private ExtensionEnum extension = null;

  @ApiModelProperty(example = "030", value = "Dosya konumu adı. API otomatik oluşturur.")
 /**
   * Dosya konumu adı. API otomatik oluşturur.  
  **/
  private String directoryName = null;

  @ApiModelProperty(example = "1000", value = "Revision değeri aynı isimle eklediğiniz resimlerin ön bellekten yüklenmesini engellemek için gerekli bir değerdir. Aynı isimle tekrardan resim yüklenirken bir önceki resimden farklı bir değer almalıdır.")
 /**
   * Revision değeri aynı isimle eklediğiniz resimlerin ön bellekten yüklenmesini engellemek için gerekli bir değerdir. Aynı isimle tekrardan resim yüklenirken bir önceki resimden farklı bir değer almalıdır.  
  **/
  private String revision = null;

  @ApiModelProperty(example = "1", required = true, value = "Resmin sıralama değeri. Ürün içerisindeki 8 fotoğraf içinden hangisi olacağını belirler.")
 /**
   * Resmin sıralama değeri. Ürün içerisindeki 8 fotoğraf içinden hangisi olacağını belirler.  
  **/
  private Integer sortOrder = null;

  @ApiModelProperty(required = true, value = "Ürün nesnesi.")
 /**
   * Ürün nesnesi.  
  **/
  private Product product = null;

  @ApiModelProperty(example = "data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAABvJJREFUeNrEV2uMVdUV/va55z5nhnnB8BAmwoAOFSJohBTb0FFSjSFggzFqYmx/VFPbxl8lRGvxj9FE0aCJ0cT4qCaaKIZUkzGhFUUgqfKIaGRAlNIZBmZg3o/7OI/db+1zzp1zZy6JNkFPZs85556z1/r2t7619jpKa42f8rDl3/OLFv2ydcGCvzfmsvWu5/mAukzuNKxEwhovOsUzZ3v+/MczZ941AFoXzH/ntoXz53oDA9CWOFeXbcXK95CcOxt7tPcybwMA9ZlM1um/gPzkJLSacq5iZ6V9+Moy9xbD5ofv/dAAKs7NEkTKtnU5BI7rOm4iAZ+udOgkPqHIc6HkopZOSSGGPV6nUnybINQPZIsLcVUCHg+zmOA3H5484Hq8aQOug75cBmd2Pge1YgW+yeVwevtj8NJpaALRnOfBN+9qBNe6ip2KwTnis8yAZIJvhprBqWMl0HS+Dw0tczHrllsxdGA/1l91NQr9/ciTAZmXIijRjlMswSawQrGIRC7Lp9ZMOelgTpR9hgHfMEBkaiZalwZsJsbI229hfPUq1G3YAOvDTnxHZ4fufwAjjz8OtyaH72Y34793340+hub4vfdCJ214jPWM1YsPWWzIQBBwOnAjENOHEJoh3R/vhbN4CdZuuQNDu3ej9557cONVy9CcziL74J/gZWvQfvvtKFJDS3+zhVpJMs5uVZviS3xOMaAj56gyFErJJFI9PRj98hgyfX0Y7epCy/KfIXX4MI6/8TrQ1CQ0wptgFlFbenKC9nnvX8qmNj7LGhA6HNLlBoKoljyw+fzC4SOYl8/DLRQCBwQGxtx3XRoMtBSIkdqVlWpd1Z5FW36FCL0I7SWyOsx7V9QrZw5tW/CoA5+C0zZTWPRLIE5+wthSId3VAMhz7U1jwJWMu2RZkQTj/wyVXVtrwKQuDsFdvx5uczNw7pzUEiSWLsXExs1oWLQQgwyFYaCKTUujUoQSD1d7M2Il7ygiTZQcMylz7AtMfvIJkrU1yL7yMrzz57CqqRHDO3ei6WwP3P37cXUmA2/XLmiGyQ9XO92u+Io0oCRuu9rbL7alU81OSJcOy22C9P6H5blYVwfLItYijRKQohPlOPCoB0vCwXt57k2MB2f+lszVoDk/ibpUmsgzFRUzyetvi6WBLV1ds8NCRBHSYQRAnCs6/4gTFz+9A+tItQFA50UaNfTpwGYynYLrckVSWaN4W1JvEhg7ehSj2/+G9PCwEWschI5nQYmTHVF1OUYa33LlrU89hV9v3IgBpqAne0WphLbFiyvieWFwEI3z5gSGph/z5+M055x+8A9IskDFRV0KtoJQA0TmxAsF6c1TbNd33IR3H34Y/7h2JTpXrcKeDTdjpKe7wscLmzeju7MzUHdY0uNHY3s73KQUJa9s34ntplYU9EAc4fB9o4Pi6Ch+++STuPbR7biytRW/P3IUY9wbximw7t5ejNLQPKkDY2M41d0d6IHjyKFD6GVmGFBkQITomLoQ2PdiyWFFoqsslwKCEzhZjqGaGowxBKq+Hq/cdx969+3DGw/cj57OD5FumYODL72E99atw8iJE3htxzP4gCV5D0M31NcPTeqnquyUj4inMgCpAfEhEZIKZ0JkVkGd8LqB23NOznynlmMyX0DH1r9g4ZobcPbIYVx8fzd+9+qrKM2Zg/5//RNIJc2GNt2+jveEcitFw4+JJL5jRbulyWtuNq7RTSI4y+8sUEPJFIuRh7pcLT565BEUGL7MrFkmQ6KSrGJbcAQhBKDKDqIWzFAVAgiuA1ZkWKTVt204RlgeVMJiP0BgZGeS+tj06F/Rk83BWbIE9uiIma9iAHToc0qEmLljiWvJbXnZodEi01KcuwzLV3v34vyxY2wwWT8KJZzc9yn6Gf9MTS1sgvum6wTefOghDB48CJ1OVd0RK9pyP6I81gf6UXryPIvxTF5zDTTTc1lHB4bpfMXq1VANDVhw3XUYPH4cS1gtW9aswS9I++dbt+JXy5dj2aZNGD51yuyQ0xmI0tWOKI8Lw2d7leWePs4C5KxciZ/feSd8jiJLb8e2bbBIv1Q12ZZvWbsWCd77UppptO2KK3DlgQOwqQubXdHAZ5/BZVW1crly7vmxjtsup2G8FaDQcnyl+4kn0MKJzW1twZbMkCjLqqhoSnI/NChilXtFQIWREfQxVF8/swOKNuK0q1jraU9RAlR8pkmjefIk/n3XXUg11JsW/Pt+xhlQBFscGjRNqiXFKtbsGFtxACJGr9rOTRCKhkpj4+HD7/kZIkvkn0VRSnZ401pjFatBUVueSkhMqxkinULp//81OPNIGM0hU0bBQrHN8f0f7YvYDTrjZ+MheJEKZnXVjQG4y3oIAXmOHXLzPwEGAGpnmoeyFBLeAAAAAElFTkSuQmCC", required = true, value = "Ürün resminin base64 formatına çevrilmiş resim kodu. Oluşturma(POST) isteği esnasında başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.")
 /**
   * Ürün resminin base64 formatına çevrilmiş resim kodu. Oluşturma(POST) isteği esnasında başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.  
  **/
  private String attachment = null;
 /**
   * Ürün resmi nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductImage id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ürün resminin dosya adı. Uzantı olmadan yazılmalıdır.
   * @return filename
  **/
  @JsonProperty("filename")
  public String getFilename() {
    return filename;
  }

  public void setFilename(String filename) {
    this.filename = filename;
  }

  public ProductImage filename(String filename) {
    this.filename = filename;
    return this;
  }

 /**
   * Resim için geçerli dosya uzantıları.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;jpg&lt;/code&gt; : jpg dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;png&lt;/code&gt; : png dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;gif&lt;/code&gt; : gif dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;jpeg&lt;/code&gt; : jpeg dosyaları için geçerli uzantı.&lt;br&gt;&lt;/div&gt;
   * @return extension
  **/
  @JsonProperty("extension")
  public String getExtension() {
    if (extension == null) {
      return null;
    }
    return extension.value();
  }

  public void setExtension(ExtensionEnum extension) {
    this.extension = extension;
  }

  public ProductImage extension(ExtensionEnum extension) {
    this.extension = extension;
    return this;
  }

 /**
   * Dosya konumu adı. API otomatik oluşturur.
   * @return directoryName
  **/
  @JsonProperty("directoryName")
  public String getDirectoryName() {
    return directoryName;
  }


 /**
   * Revision değeri aynı isimle eklediğiniz resimlerin ön bellekten yüklenmesini engellemek için gerekli bir değerdir. Aynı isimle tekrardan resim yüklenirken bir önceki resimden farklı bir değer almalıdır.
   * @return revision
  **/
  @JsonProperty("revision")
  public String getRevision() {
    return revision;
  }


 /**
   * Resmin sıralama değeri. Ürün içerisindeki 8 fotoğraf içinden hangisi olacağını belirler.
   * minimum: 1
   * maximum: 8
   * @return sortOrder
  **/
  @JsonProperty("sortOrder")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public ProductImage sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

 /**
   * Ürün nesnesi.
   * @return product
  **/
  @JsonProperty("product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public ProductImage product(Product product) {
    this.product = product;
    return this;
  }

 /**
   * Ürün resminin base64 formatına çevrilmiş resim kodu. Oluşturma(POST) isteği esnasında başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
   * @return attachment
  **/
  @JsonProperty("attachment")
  public String getAttachment() {
    return attachment;
  }

  public void setAttachment(String attachment) {
    this.attachment = attachment;
  }

  public ProductImage attachment(String attachment) {
    this.attachment = attachment;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductImage {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    filename: ").append(toIndentedString(filename)).append("\n");
    sb.append("    extension: ").append(toIndentedString(extension)).append("\n");
    sb.append("    directoryName: ").append(toIndentedString(directoryName)).append("\n");
    sb.append("    revision: ").append(toIndentedString(revision)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("    attachment: ").append(toIndentedString(attachment)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

