package io.swagger.model;

import io.swagger.model.SelectionGroup;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Selection  {
  
  @ApiModelProperty(example = "123", value = "Ek özellik nesnesi kimlik değeri.")
 /**
   * Ek özellik nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "Ek Özellik Başlığı", value = "Ek özellik nesnesinin başlığı.")
 /**
   * Ek özellik nesnesinin başlığı.  
  **/
  private String title = null;

  @ApiModelProperty(example = "999", required = true, value = "Ek özellik nesnesi için sıralama değeri.")
 /**
   * Ek özellik nesnesi için sıralama değeri.  
  **/
  private Integer sortOrder = null;

  @ApiModelProperty(required = true, value = "Ek özellik grubu nesnesi.")
 /**
   * Ek özellik grubu nesnesi.  
  **/
  private SelectionGroup selectionGroup = null;
 /**
   * Ek özellik nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Selection id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ek özellik nesnesinin başlığı.
   * @return title
  **/
  @JsonProperty("title")
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public Selection title(String title) {
    this.title = title;
    return this;
  }

 /**
   * Ek özellik nesnesi için sıralama değeri.
   * @return sortOrder
  **/
  @JsonProperty("sortOrder")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public Selection sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

 /**
   * Ek özellik grubu nesnesi.
   * @return selectionGroup
  **/
  @JsonProperty("selectionGroup")
  public SelectionGroup getSelectionGroup() {
    return selectionGroup;
  }

  public void setSelectionGroup(SelectionGroup selectionGroup) {
    this.selectionGroup = selectionGroup;
  }

  public Selection selectionGroup(SelectionGroup selectionGroup) {
    this.selectionGroup = selectionGroup;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Selection {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    selectionGroup: ").append(toIndentedString(selectionGroup)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

