package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ShopPreference  {
  
  @ApiModelProperty(example = "123", value = "Tanımlama nesnesi kimlik değeri.")
 /**
   * Tanımlama nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "company_name", value = "Tanımlama nesnesi için değişken anahtarı.")
 /**
   * Tanımlama nesnesi için değişken anahtarı.  
  **/
  private String varKey = null;

  @ApiModelProperty(example = "Ideasoft Yazılım San. ve Tic. A.Ş.", value = "Tanımlama nesnesi için değişken değeri.")
 /**
   * Tanımlama nesnesi için değişken değeri.  
  **/
  private String varValue = null;
 /**
   * Tanımlama nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ShopPreference id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Tanımlama nesnesi için değişken anahtarı.
   * @return varKey
  **/
  @JsonProperty("varKey")
  public String getVarKey() {
    return varKey;
  }

  public void setVarKey(String varKey) {
    this.varKey = varKey;
  }

  public ShopPreference varKey(String varKey) {
    this.varKey = varKey;
    return this;
  }

 /**
   * Tanımlama nesnesi için değişken değeri.
   * @return varValue
  **/
  @JsonProperty("varValue")
  public String getVarValue() {
    return varValue;
  }

  public void setVarValue(String varValue) {
    this.varValue = varValue;
  }

  public ShopPreference varValue(String varValue) {
    this.varValue = varValue;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShopPreference {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    varKey: ").append(toIndentedString(varKey)).append("\n");
    sb.append("    varValue: ").append(toIndentedString(varValue)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

