package io.swagger.model;

import io.swagger.model.Member;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Payment  {
  
  @ApiModelProperty(example = "123", value = "Ödeme nesnesi kimlik değeri.")
 /**
   * Ödeme nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "John", required = true, value = "Üyenin ismi.")
 /**
   * Üyenin ismi.  
  **/
  private String memberFirstname = null;
  @ApiModelProperty(example = "Doe", required = true, value = "Üyenin soy ismi.")
 /**
   * Üyenin soy ismi.  
  **/
  private String memberSurname = null;
  @ApiModelProperty(example = "johndoe@ideasoft.com.tr", required = true, value = "Üyenin e-mail adresi.")
 /**
   * Üyenin e-mail adresi.  
  **/
  private String memberEmail = null;
  @ApiModelProperty(example = "+90 (216) 326 04 77", value = "Üyenin telefon numarası.")
 /**
   * Üyenin telefon numarası.  
  **/
  private String memberPhone = null;
  @ApiModelProperty(example = "Kredi Kartı", required = true, value = "Ödeme tipi")
 /**
   * Ödeme tipi  
  **/
  private String paymentTypeName = null;
  @ApiModelProperty(example = "IdeaPay", required = true, value = "Ödeme hizmeti sağlayıcısı kodu. Bu değer ön tanımlıdır.")
 /**
   * Ödeme hizmeti sağlayıcısı kodu. Bu değer ön tanımlıdır.  
  **/
  private String paymentProviderCode = null;
  @ApiModelProperty(example = "IdeaPay", required = true, value = "Ödeme hizmeti sağlayıcısı adı. Bu değer ön tanımlıdır.")
 /**
   * Ödeme hizmeti sağlayıcısı adı. Bu değer ön tanımlıdır.  
  **/
  private String paymentProviderName = null;
  @ApiModelProperty(example = "IdeaCard", required = true, value = "Ödeme kanalı adı. Bu değer ön tanımlıdır.")
 /**
   * Ödeme kanalı adı. Bu değer ön tanımlıdır.  
  **/
  private String paymentGatewayName = null;
  @ApiModelProperty(example = "ideacard", required = true, value = "Ödeme kanalı kodu. Bu değer ön tanımlıdır.")
 /**
   * Ödeme kanalı kodu. Bu değer ön tanımlıdır.  
  **/
  private String paymentGatewayCode = null;
  @ApiModelProperty(example = "Idea Bank", value = "Ödeme yapılan banka. Bu değer ön tanımlıdır.")
 /**
   * Ödeme yapılan banka. Bu değer ön tanımlıdır.  
  **/
  private String bankName = null;

@XmlType(name="DeviceTypeEnum")
@XmlEnum(String.class)
public enum DeviceTypeEnum {

@XmlEnumValue("desktop") DESKTOP(String.valueOf("desktop")), @XmlEnumValue("mobile") MOBILE(String.valueOf("mobile")), @XmlEnumValue("tablet") TABLET(String.valueOf("tablet"));


    private String value;

    DeviceTypeEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static DeviceTypeEnum fromValue(String v) {
        for (DeviceTypeEnum b : DeviceTypeEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "desktop", required = true, value = "Ödemenin gerçekleştiği cihaz bilgisi.<div class='idea_choice_list'><code>desktop</code> : Masaüstü<br><code>mobile</code> : Mobil<br><code>tablet</code> : Tablet<br></div>")
 /**
   * Ödemenin gerçekleştiği cihaz bilgisi.<div class='idea_choice_list'><code>desktop</code> : Masaüstü<br><code>mobile</code> : Mobil<br><code>tablet</code> : Tablet<br></div>  
  **/
  private DeviceTypeEnum deviceType = null;
  @ApiModelProperty(example = "192.168.1.1", required = true, value = "Müşterinin IP adresi.")
 /**
   * Müşterinin IP adresi.  
  **/
  private String clientIp = null;
  @ApiModelProperty(example = "{\"TL\":[1,1],\"USD\":[3.7698,3.7766],\"EUR\":[4.6575,4.6659],\"GBP\":[5.2597,5.2872]}", required = true, value = "Kur oranları.")
 /**
   * Kur oranları.  
  **/
  private String currencyRates = null;
  @ApiModelProperty(example = "1.0", required = true, value = "Ödemenin saf fiyatı.")
 /**
   * Ödemenin saf fiyatı.  
  **/
  private Float amount = null;
  @ApiModelProperty(example = "1.0", required = true, value = "Ödemenin son fiyatı.")
 /**
   * Ödemenin son fiyatı.  
  **/
  private Float finalAmount = null;
  @ApiModelProperty(example = "100.0", value = "Ödemeden kazanılan toplam puan.")
 /**
   * Ödemeden kazanılan toplam puan.  
  **/
  private Float sumOfGainedPoints = null;
  @ApiModelProperty(example = "1", required = true, value = "Ödemenin standart taksit sayısı.")
 /**
   * Ödemenin standart taksit sayısı.  
  **/
  private Integer installment = null;
  @ApiModelProperty(example = "1.0", required = true, value = "Ödemenin taksit oranı.")
 /**
   * Ödemenin taksit oranı.  
  **/
  private Float installmentRate = null;
  @ApiModelProperty(example = "0", value = "Ödemenin ekstra taksit sayısı.")
 /**
   * Ödemenin ekstra taksit sayısı.  
  **/
  private Integer extraInstallment = null;
  @ApiModelProperty(example = "TL", required = true, value = "Kur bilgisi.")
 /**
   * Kur bilgisi.  
  **/
  private String currency = null;
  @ApiModelProperty(example = "53072074", value = "Siparişin numarası.")
 /**
   * Siparişin numarası.  
  **/
  private String transactionId = null;
  @ApiModelProperty(example = "Her ayın ikisinde teslimat istiyorum.", value = "Müşterinin ödeme notu.")
 /**
   * Müşterinin ödeme notu.  
  **/
  private String memberNote = null;
  @ApiModelProperty(example = "Her ayın ikisinde gönderilecek.", value = "Yönetici(admin) ödeme notu.")
 /**
   * Yönetici(admin) ödeme notu.  
  **/
  private String userNote = null;

@XmlType(name="StatusEnum")
@XmlEnum(String.class)
public enum StatusEnum {

@XmlEnumValue("deleted") DELETED(String.valueOf("deleted")), @XmlEnumValue("waiting_for_approval") WAITING_FOR_APPROVAL(String.valueOf("waiting_for_approval")), @XmlEnumValue("approved") APPROVED(String.valueOf("approved")), @XmlEnumValue("fulfilled") FULFILLED(String.valueOf("fulfilled")), @XmlEnumValue("cancelled") CANCELLED(String.valueOf("cancelled")), @XmlEnumValue("delivered") DELIVERED(String.valueOf("delivered")), @XmlEnumValue("on_accumulation") ON_ACCUMULATION(String.valueOf("on_accumulation")), @XmlEnumValue("waiting_for_payment") WAITING_FOR_PAYMENT(String.valueOf("waiting_for_payment")), @XmlEnumValue("being_prepared") BEING_PREPARED(String.valueOf("being_prepared")), @XmlEnumValue("refunded") REFUNDED(String.valueOf("refunded")), @XmlEnumValue("personal_status_1") PERSONAL_STATUS_1(String.valueOf("personal_status_1")), @XmlEnumValue("personal_status_2") PERSONAL_STATUS_2(String.valueOf("personal_status_2")), @XmlEnumValue("personal_status_3") PERSONAL_STATUS_3(String.valueOf("personal_status_3")), @XmlEnumValue("failed") FAILED(String.valueOf("failed")), @XmlEnumValue("in_transaction") IN_TRANSACTION(String.valueOf("in_transaction"));


    private String value;

    StatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "waiting_for_approval", required = true, value = "Ödeme durumu.<div class='idea_choice_list'><code>deleted</code> : Silindi<br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br><code>failed</code> : Hatalı Ödemeler<br><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br></div>")
 /**
   * Ödeme durumu.<div class='idea_choice_list'><code>deleted</code> : Silindi<br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br><code>failed</code> : Hatalı Ödemeler<br><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br></div>  
  **/
  private StatusEnum status = null;
  @ApiModelProperty(example = "Limit yetersiz.", value = "Ödemenin hata mesajı.")
 /**
   * Ödemenin hata mesajı.  
  **/
  private String errorMessage = null;
  @ApiModelProperty(example = "ideasave", value = "Kart saklama sistemi.")
 /**
   * Kart saklama sistemi.  
  **/
  private String cardSavingSystem = null;
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Ödeme nesnesinin oluşturulma zamanı.")
 /**
   * Ödeme nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;
  @ApiModelProperty(value = "")
  private Member member = null;

 /**
   * Ödeme nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Payment id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Üyenin ismi.
   * @return memberFirstname
  **/
  @JsonProperty("memberFirstname")
  public String getMemberFirstname() {
    return memberFirstname;
  }

  public void setMemberFirstname(String memberFirstname) {
    this.memberFirstname = memberFirstname;
  }

  public Payment memberFirstname(String memberFirstname) {
    this.memberFirstname = memberFirstname;
    return this;
  }

 /**
   * Üyenin soy ismi.
   * @return memberSurname
  **/
  @JsonProperty("memberSurname")
  public String getMemberSurname() {
    return memberSurname;
  }

  public void setMemberSurname(String memberSurname) {
    this.memberSurname = memberSurname;
  }

  public Payment memberSurname(String memberSurname) {
    this.memberSurname = memberSurname;
    return this;
  }

 /**
   * Üyenin e-mail adresi.
   * @return memberEmail
  **/
  @JsonProperty("memberEmail")
  public String getMemberEmail() {
    return memberEmail;
  }

  public void setMemberEmail(String memberEmail) {
    this.memberEmail = memberEmail;
  }

  public Payment memberEmail(String memberEmail) {
    this.memberEmail = memberEmail;
    return this;
  }

 /**
   * Üyenin telefon numarası.
   * @return memberPhone
  **/
  @JsonProperty("memberPhone")
  public String getMemberPhone() {
    return memberPhone;
  }

  public void setMemberPhone(String memberPhone) {
    this.memberPhone = memberPhone;
  }

  public Payment memberPhone(String memberPhone) {
    this.memberPhone = memberPhone;
    return this;
  }

 /**
   * Ödeme tipi
   * @return paymentTypeName
  **/
  @JsonProperty("paymentTypeName")
  public String getPaymentTypeName() {
    return paymentTypeName;
  }

  public void setPaymentTypeName(String paymentTypeName) {
    this.paymentTypeName = paymentTypeName;
  }

  public Payment paymentTypeName(String paymentTypeName) {
    this.paymentTypeName = paymentTypeName;
    return this;
  }

 /**
   * Ödeme hizmeti sağlayıcısı kodu. Bu değer ön tanımlıdır.
   * @return paymentProviderCode
  **/
  @JsonProperty("paymentProviderCode")
  public String getPaymentProviderCode() {
    return paymentProviderCode;
  }

  public void setPaymentProviderCode(String paymentProviderCode) {
    this.paymentProviderCode = paymentProviderCode;
  }

  public Payment paymentProviderCode(String paymentProviderCode) {
    this.paymentProviderCode = paymentProviderCode;
    return this;
  }

 /**
   * Ödeme hizmeti sağlayıcısı adı. Bu değer ön tanımlıdır.
   * @return paymentProviderName
  **/
  @JsonProperty("paymentProviderName")
  public String getPaymentProviderName() {
    return paymentProviderName;
  }

  public void setPaymentProviderName(String paymentProviderName) {
    this.paymentProviderName = paymentProviderName;
  }

  public Payment paymentProviderName(String paymentProviderName) {
    this.paymentProviderName = paymentProviderName;
    return this;
  }

 /**
   * Ödeme kanalı adı. Bu değer ön tanımlıdır.
   * @return paymentGatewayName
  **/
  @JsonProperty("paymentGatewayName")
  public String getPaymentGatewayName() {
    return paymentGatewayName;
  }

  public void setPaymentGatewayName(String paymentGatewayName) {
    this.paymentGatewayName = paymentGatewayName;
  }

  public Payment paymentGatewayName(String paymentGatewayName) {
    this.paymentGatewayName = paymentGatewayName;
    return this;
  }

 /**
   * Ödeme kanalı kodu. Bu değer ön tanımlıdır.
   * @return paymentGatewayCode
  **/
  @JsonProperty("paymentGatewayCode")
  public String getPaymentGatewayCode() {
    return paymentGatewayCode;
  }

  public void setPaymentGatewayCode(String paymentGatewayCode) {
    this.paymentGatewayCode = paymentGatewayCode;
  }

  public Payment paymentGatewayCode(String paymentGatewayCode) {
    this.paymentGatewayCode = paymentGatewayCode;
    return this;
  }

 /**
   * Ödeme yapılan banka. Bu değer ön tanımlıdır.
   * @return bankName
  **/
  @JsonProperty("bankName")
  public String getBankName() {
    return bankName;
  }

  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  public Payment bankName(String bankName) {
    this.bankName = bankName;
    return this;
  }

 /**
   * Ödemenin gerçekleştiği cihaz bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil&lt;br&gt;&lt;code&gt;tablet&lt;/code&gt; : Tablet&lt;br&gt;&lt;/div&gt;
   * @return deviceType
  **/
  @JsonProperty("deviceType")
  public String getDeviceType() {
    if (deviceType == null) {
      return null;
    }
    return deviceType.value();
  }

  public void setDeviceType(DeviceTypeEnum deviceType) {
    this.deviceType = deviceType;
  }

  public Payment deviceType(DeviceTypeEnum deviceType) {
    this.deviceType = deviceType;
    return this;
  }

 /**
   * Müşterinin IP adresi.
   * @return clientIp
  **/
  @JsonProperty("clientIp")
  public String getClientIp() {
    return clientIp;
  }

  public void setClientIp(String clientIp) {
    this.clientIp = clientIp;
  }

  public Payment clientIp(String clientIp) {
    this.clientIp = clientIp;
    return this;
  }

 /**
   * Kur oranları.
   * @return currencyRates
  **/
  @JsonProperty("currencyRates")
  public String getCurrencyRates() {
    return currencyRates;
  }

  public void setCurrencyRates(String currencyRates) {
    this.currencyRates = currencyRates;
  }

  public Payment currencyRates(String currencyRates) {
    this.currencyRates = currencyRates;
    return this;
  }

 /**
   * Ödemenin saf fiyatı.
   * minimum: 0
   * @return amount
  **/
  @JsonProperty("amount")
  public Float getAmount() {
    return amount;
  }

  public void setAmount(Float amount) {
    this.amount = amount;
  }

  public Payment amount(Float amount) {
    this.amount = amount;
    return this;
  }

 /**
   * Ödemenin son fiyatı.
   * minimum: 0
   * @return finalAmount
  **/
  @JsonProperty("finalAmount")
  public Float getFinalAmount() {
    return finalAmount;
  }

  public void setFinalAmount(Float finalAmount) {
    this.finalAmount = finalAmount;
  }

  public Payment finalAmount(Float finalAmount) {
    this.finalAmount = finalAmount;
    return this;
  }

 /**
   * Ödemeden kazanılan toplam puan.
   * minimum: 0
   * @return sumOfGainedPoints
  **/
  @JsonProperty("sumOfGainedPoints")
  public Float getSumOfGainedPoints() {
    return sumOfGainedPoints;
  }

  public void setSumOfGainedPoints(Float sumOfGainedPoints) {
    this.sumOfGainedPoints = sumOfGainedPoints;
  }

  public Payment sumOfGainedPoints(Float sumOfGainedPoints) {
    this.sumOfGainedPoints = sumOfGainedPoints;
    return this;
  }

 /**
   * Ödemenin standart taksit sayısı.
   * minimum: 0
   * maximum: 12
   * @return installment
  **/
  @JsonProperty("installment")
  public Integer getInstallment() {
    return installment;
  }

  public void setInstallment(Integer installment) {
    this.installment = installment;
  }

  public Payment installment(Integer installment) {
    this.installment = installment;
    return this;
  }

 /**
   * Ödemenin taksit oranı.
   * @return installmentRate
  **/
  @JsonProperty("installmentRate")
  public Float getInstallmentRate() {
    return installmentRate;
  }

  public void setInstallmentRate(Float installmentRate) {
    this.installmentRate = installmentRate;
  }

  public Payment installmentRate(Float installmentRate) {
    this.installmentRate = installmentRate;
    return this;
  }

 /**
   * Ödemenin ekstra taksit sayısı.
   * minimum: 0
   * maximum: 12
   * @return extraInstallment
  **/
  @JsonProperty("extraInstallment")
  public Integer getExtraInstallment() {
    return extraInstallment;
  }

  public void setExtraInstallment(Integer extraInstallment) {
    this.extraInstallment = extraInstallment;
  }

  public Payment extraInstallment(Integer extraInstallment) {
    this.extraInstallment = extraInstallment;
    return this;
  }

 /**
   * Kur bilgisi.
   * @return currency
  **/
  @JsonProperty("currency")
  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public Payment currency(String currency) {
    this.currency = currency;
    return this;
  }

 /**
   * Siparişin numarası.
   * @return transactionId
  **/
  @JsonProperty("transactionId")
  public String getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(String transactionId) {
    this.transactionId = transactionId;
  }

  public Payment transactionId(String transactionId) {
    this.transactionId = transactionId;
    return this;
  }

 /**
   * Müşterinin ödeme notu.
   * @return memberNote
  **/
  @JsonProperty("memberNote")
  public String getMemberNote() {
    return memberNote;
  }

  public void setMemberNote(String memberNote) {
    this.memberNote = memberNote;
  }

  public Payment memberNote(String memberNote) {
    this.memberNote = memberNote;
    return this;
  }

 /**
   * Yönetici(admin) ödeme notu.
   * @return userNote
  **/
  @JsonProperty("userNote")
  public String getUserNote() {
    return userNote;
  }

  public void setUserNote(String userNote) {
    this.userNote = userNote;
  }

  public Payment userNote(String userNote) {
    this.userNote = userNote;
    return this;
  }

 /**
   * Ödeme durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Payment status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Ödemenin hata mesajı.
   * @return errorMessage
  **/
  @JsonProperty("errorMessage")
  public String getErrorMessage() {
    return errorMessage;
  }

  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  public Payment errorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
    return this;
  }

 /**
   * Kart saklama sistemi.
   * @return cardSavingSystem
  **/
  @JsonProperty("cardSavingSystem")
  public String getCardSavingSystem() {
    return cardSavingSystem;
  }

  public void setCardSavingSystem(String cardSavingSystem) {
    this.cardSavingSystem = cardSavingSystem;
  }

  public Payment cardSavingSystem(String cardSavingSystem) {
    this.cardSavingSystem = cardSavingSystem;
    return this;
  }

 /**
   * Ödeme nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Get member
   * @return member
  **/
  @JsonProperty("member")
  public Member getMember() {
    return member;
  }

  public void setMember(Member member) {
    this.member = member;
  }

  public Payment member(Member member) {
    this.member = member;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Payment {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    memberFirstname: ").append(toIndentedString(memberFirstname)).append("\n");
    sb.append("    memberSurname: ").append(toIndentedString(memberSurname)).append("\n");
    sb.append("    memberEmail: ").append(toIndentedString(memberEmail)).append("\n");
    sb.append("    memberPhone: ").append(toIndentedString(memberPhone)).append("\n");
    sb.append("    paymentTypeName: ").append(toIndentedString(paymentTypeName)).append("\n");
    sb.append("    paymentProviderCode: ").append(toIndentedString(paymentProviderCode)).append("\n");
    sb.append("    paymentProviderName: ").append(toIndentedString(paymentProviderName)).append("\n");
    sb.append("    paymentGatewayName: ").append(toIndentedString(paymentGatewayName)).append("\n");
    sb.append("    paymentGatewayCode: ").append(toIndentedString(paymentGatewayCode)).append("\n");
    sb.append("    bankName: ").append(toIndentedString(bankName)).append("\n");
    sb.append("    deviceType: ").append(toIndentedString(deviceType)).append("\n");
    sb.append("    clientIp: ").append(toIndentedString(clientIp)).append("\n");
    sb.append("    currencyRates: ").append(toIndentedString(currencyRates)).append("\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    finalAmount: ").append(toIndentedString(finalAmount)).append("\n");
    sb.append("    sumOfGainedPoints: ").append(toIndentedString(sumOfGainedPoints)).append("\n");
    sb.append("    installment: ").append(toIndentedString(installment)).append("\n");
    sb.append("    installmentRate: ").append(toIndentedString(installmentRate)).append("\n");
    sb.append("    extraInstallment: ").append(toIndentedString(extraInstallment)).append("\n");
    sb.append("    currency: ").append(toIndentedString(currency)).append("\n");
    sb.append("    transactionId: ").append(toIndentedString(transactionId)).append("\n");
    sb.append("    memberNote: ").append(toIndentedString(memberNote)).append("\n");
    sb.append("    userNote: ").append(toIndentedString(userNote)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    errorMessage: ").append(toIndentedString(errorMessage)).append("\n");
    sb.append("    cardSavingSystem: ").append(toIndentedString(cardSavingSystem)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    member: ").append(toIndentedString(member)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

