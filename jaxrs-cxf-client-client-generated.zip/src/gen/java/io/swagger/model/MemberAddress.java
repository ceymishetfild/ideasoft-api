package io.swagger.model;

import io.swagger.model.Country;
import io.swagger.model.Location;
import io.swagger.model.Member;
import io.swagger.model.Town;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class MemberAddress  {
  
  @ApiModelProperty(example = "123", value = "Üye adresi nesnesinin benzersiz rakamsal kimlik değeri.")
 /**
   * Üye adresi nesnesinin benzersiz rakamsal kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "Ev", value = "Üye Adresi adı.")
 /**
   * Üye Adresi adı.  
  **/
  private String name = null;

  @ApiModelProperty(example = "shipping", value = "Üye Adresi tipi.<div class='idea_choice_list'><code>shipping</code> : Teslimat adresi.<br><code>billing</code> : Fatura adresi.<br></div>")
 /**
   * Üye Adresi tipi.<div class='idea_choice_list'><code>shipping</code> : Teslimat adresi.<br><code>billing</code> : Fatura adresi.<br></div>  
  **/
  private String type = null;

  @ApiModelProperty(example = "John", value = "Üyenin ismi.")
 /**
   * Üyenin ismi.  
  **/
  private String firstname = null;

  @ApiModelProperty(example = "Doe", value = "Üyenin soy ismi.")
 /**
   * Üyenin soy ismi.  
  **/
  private String surname = null;

  @ApiModelProperty(example = "Cumhuriyet Mah. Libadiye Cad. Çimen Sok. No:2", value = "Üyenin adres bilgileri.")
 /**
   * Üyenin adres bilgileri.  
  **/
  private String address = null;

  @ApiModelProperty(example = "Üsküdar", value = "İlçe adı.")
 /**
   * İlçe adı.  
  **/
  private String subLocationName = null;

  @ApiModelProperty(example = "+90 (216) 326 04 77", value = "Üyenin telefon numarası.")
 /**
   * Üyenin telefon numarası.  
  **/
  private String phoneNumber = null;

  @ApiModelProperty(value = "Üyenin mobil telefon numarası.")
 /**
   * Üyenin mobil telefon numarası.  
  **/
  private String mobilePhoneNumber = null;

  @ApiModelProperty(example = "11111111111", value = "Üyenin TC kimlik numarası.")
 /**
   * Üyenin TC kimlik numarası.  
  **/
  private String tcId = null;

  @ApiModelProperty(example = "1966712049", value = "Üyenin vergi numarası.")
 /**
   * Üyenin vergi numarası.  
  **/
  private String taxNumber = null;

  @ApiModelProperty(example = "Üsküdar", value = "Üyenin vergi dairesi.")
 /**
   * Üyenin vergi dairesi.  
  **/
  private String taxOffice = null;

  @ApiModelProperty(example = "individual", value = "Fatura tipini belirtir.<div class='idea_choice_list'><code>individual</code> : Bireysel<br><code>corporate</code> : Kurumsal<br></div>")
 /**
   * Fatura tipini belirtir.<div class='idea_choice_list'><code>individual</code> : Bireysel<br><code>corporate</code> : Kurumsal<br></div>  
  **/
  private String invoiceType = null;

  @ApiModelProperty(example = "false", value = "Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div>")
 /**
   * Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div>  
  **/
  private Boolean isEinvoiceUser = null;

  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Tema nesnesinin oluşturulma zamanı.")
 /**
   * Tema nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;

  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Tema nesnesinin güncellenme zamanı.")
 /**
   * Tema nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;

  @ApiModelProperty(value = "Üye nesnesi")
 /**
   * Üye nesnesi  
  **/
  private Member member = null;

  @ApiModelProperty(value = "Ülke nesnesi.")
 /**
   * Ülke nesnesi.  
  **/
  private Country country = null;

  @ApiModelProperty(value = "Şehir nesnesi.")
 /**
   * Şehir nesnesi.  
  **/
  private Location location = null;

  @ApiModelProperty(value = "İlçe nesnesi.")
 /**
   * İlçe nesnesi.  
  **/
  private Town subLocation = null;
 /**
   * Üye adresi nesnesinin benzersiz rakamsal kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public MemberAddress id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Üye Adresi adı.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public MemberAddress name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Üye Adresi tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;shipping&lt;/code&gt; : Teslimat adresi.&lt;br&gt;&lt;code&gt;billing&lt;/code&gt; : Fatura adresi.&lt;br&gt;&lt;/div&gt;
   * @return type
  **/
  @JsonProperty("type")
  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public MemberAddress type(String type) {
    this.type = type;
    return this;
  }

 /**
   * Üyenin ismi.
   * @return firstname
  **/
  @JsonProperty("firstname")
  public String getFirstname() {
    return firstname;
  }

  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }

  public MemberAddress firstname(String firstname) {
    this.firstname = firstname;
    return this;
  }

 /**
   * Üyenin soy ismi.
   * @return surname
  **/
  @JsonProperty("surname")
  public String getSurname() {
    return surname;
  }

  public void setSurname(String surname) {
    this.surname = surname;
  }

  public MemberAddress surname(String surname) {
    this.surname = surname;
    return this;
  }

 /**
   * Üyenin adres bilgileri.
   * @return address
  **/
  @JsonProperty("address")
  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public MemberAddress address(String address) {
    this.address = address;
    return this;
  }

 /**
   * İlçe adı.
   * @return subLocationName
  **/
  @JsonProperty("subLocationName")
  public String getSubLocationName() {
    return subLocationName;
  }

  public void setSubLocationName(String subLocationName) {
    this.subLocationName = subLocationName;
  }

  public MemberAddress subLocationName(String subLocationName) {
    this.subLocationName = subLocationName;
    return this;
  }

 /**
   * Üyenin telefon numarası.
   * @return phoneNumber
  **/
  @JsonProperty("phoneNumber")
  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public MemberAddress phoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
    return this;
  }

 /**
   * Üyenin mobil telefon numarası.
   * @return mobilePhoneNumber
  **/
  @JsonProperty("mobilePhoneNumber")
  public String getMobilePhoneNumber() {
    return mobilePhoneNumber;
  }

  public void setMobilePhoneNumber(String mobilePhoneNumber) {
    this.mobilePhoneNumber = mobilePhoneNumber;
  }

  public MemberAddress mobilePhoneNumber(String mobilePhoneNumber) {
    this.mobilePhoneNumber = mobilePhoneNumber;
    return this;
  }

 /**
   * Üyenin TC kimlik numarası.
   * @return tcId
  **/
  @JsonProperty("tcId")
  public String getTcId() {
    return tcId;
  }

  public void setTcId(String tcId) {
    this.tcId = tcId;
  }

  public MemberAddress tcId(String tcId) {
    this.tcId = tcId;
    return this;
  }

 /**
   * Üyenin vergi numarası.
   * @return taxNumber
  **/
  @JsonProperty("taxNumber")
  public String getTaxNumber() {
    return taxNumber;
  }

  public void setTaxNumber(String taxNumber) {
    this.taxNumber = taxNumber;
  }

  public MemberAddress taxNumber(String taxNumber) {
    this.taxNumber = taxNumber;
    return this;
  }

 /**
   * Üyenin vergi dairesi.
   * @return taxOffice
  **/
  @JsonProperty("taxOffice")
  public String getTaxOffice() {
    return taxOffice;
  }

  public void setTaxOffice(String taxOffice) {
    this.taxOffice = taxOffice;
  }

  public MemberAddress taxOffice(String taxOffice) {
    this.taxOffice = taxOffice;
    return this;
  }

 /**
   * Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt;
   * @return invoiceType
  **/
  @JsonProperty("invoiceType")
  public String getInvoiceType() {
    return invoiceType;
  }

  public void setInvoiceType(String invoiceType) {
    this.invoiceType = invoiceType;
  }

  public MemberAddress invoiceType(String invoiceType) {
    this.invoiceType = invoiceType;
    return this;
  }

 /**
   * Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt;
   * @return isEinvoiceUser
  **/
  @JsonProperty("isEinvoiceUser")
  public Boolean isIsEinvoiceUser() {
    return isEinvoiceUser;
  }

  public void setIsEinvoiceUser(Boolean isEinvoiceUser) {
    this.isEinvoiceUser = isEinvoiceUser;
  }

  public MemberAddress isEinvoiceUser(Boolean isEinvoiceUser) {
    this.isEinvoiceUser = isEinvoiceUser;
    return this;
  }

 /**
   * Tema nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  public MemberAddress createdAt(Date createdAt) {
    this.createdAt = createdAt;
    return this;
  }

 /**
   * Tema nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(Date updatedAt) {
    this.updatedAt = updatedAt;
  }

  public MemberAddress updatedAt(Date updatedAt) {
    this.updatedAt = updatedAt;
    return this;
  }

 /**
   * Üye nesnesi
   * @return member
  **/
  @JsonProperty("member")
  public Member getMember() {
    return member;
  }

  public void setMember(Member member) {
    this.member = member;
  }

  public MemberAddress member(Member member) {
    this.member = member;
    return this;
  }

 /**
   * Ülke nesnesi.
   * @return country
  **/
  @JsonProperty("country")
  public Country getCountry() {
    return country;
  }

  public void setCountry(Country country) {
    this.country = country;
  }

  public MemberAddress country(Country country) {
    this.country = country;
    return this;
  }

 /**
   * Şehir nesnesi.
   * @return location
  **/
  @JsonProperty("location")
  public Location getLocation() {
    return location;
  }

  public void setLocation(Location location) {
    this.location = location;
  }

  public MemberAddress location(Location location) {
    this.location = location;
    return this;
  }

 /**
   * İlçe nesnesi.
   * @return subLocation
  **/
  @JsonProperty("subLocation")
  public Town getSubLocation() {
    return subLocation;
  }

  public void setSubLocation(Town subLocation) {
    this.subLocation = subLocation;
  }

  public MemberAddress subLocation(Town subLocation) {
    this.subLocation = subLocation;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MemberAddress {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    firstname: ").append(toIndentedString(firstname)).append("\n");
    sb.append("    surname: ").append(toIndentedString(surname)).append("\n");
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    subLocationName: ").append(toIndentedString(subLocationName)).append("\n");
    sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
    sb.append("    mobilePhoneNumber: ").append(toIndentedString(mobilePhoneNumber)).append("\n");
    sb.append("    tcId: ").append(toIndentedString(tcId)).append("\n");
    sb.append("    taxNumber: ").append(toIndentedString(taxNumber)).append("\n");
    sb.append("    taxOffice: ").append(toIndentedString(taxOffice)).append("\n");
    sb.append("    invoiceType: ").append(toIndentedString(invoiceType)).append("\n");
    sb.append("    isEinvoiceUser: ").append(toIndentedString(isEinvoiceUser)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    member: ").append(toIndentedString(member)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("    location: ").append(toIndentedString(location)).append("\n");
    sb.append("    subLocation: ").append(toIndentedString(subLocation)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

