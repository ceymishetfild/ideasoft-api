package io.swagger.model;

import io.swagger.model.Product;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductButton  {
  
  @ApiModelProperty(example = "123", value = "Ürün ve stok butonu nesnesi kimlik değeri.")
 /**
   * Ürün ve stok butonu nesnesi kimlik değeri.  
  **/
  private Integer id = null;

@XmlType(name="FastShippingEnum")
@XmlEnum(String.class)
public enum FastShippingEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    FastShippingEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static FastShippingEnum fromValue(String v) {
        for (FastShippingEnum b : FastShippingEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Hızlı gönderi butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Hızlı kargo butonu aktif.<br><code>0</code> : Hızlı kargo butonu pasif.<br></div>")
 /**
   * Hızlı gönderi butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Hızlı kargo butonu aktif.<br><code>0</code> : Hızlı kargo butonu pasif.<br></div>  
  **/
  private FastShippingEnum fastShipping = null;

@XmlType(name="SameDayShippingEnum")
@XmlEnum(String.class)
public enum SameDayShippingEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    SameDayShippingEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static SameDayShippingEnum fromValue(String v) {
        for (SameDayShippingEnum b : SameDayShippingEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Aynı gün kargo butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aynı gün kargo butonu aktif.<br><code>0</code> : Aynı gün kargo butonu pasif.<br></div>")
 /**
   * Aynı gün kargo butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aynı gün kargo butonu aktif.<br><code>0</code> : Aynı gün kargo butonu pasif.<br></div>  
  **/
  private SameDayShippingEnum sameDayShipping = null;

@XmlType(name="ThreeDaysDeliveryEnum")
@XmlEnum(String.class)
public enum ThreeDaysDeliveryEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    ThreeDaysDeliveryEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static ThreeDaysDeliveryEnum fromValue(String v) {
        for (ThreeDaysDeliveryEnum b : ThreeDaysDeliveryEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "3 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 3 günde teslimat butonu aktif.<br><code>0</code> : 3 günde teslimat butonu pasif.<br></div>")
 /**
   * 3 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 3 günde teslimat butonu aktif.<br><code>0</code> : 3 günde teslimat butonu pasif.<br></div>  
  **/
  private ThreeDaysDeliveryEnum threeDaysDelivery = null;

@XmlType(name="FiveDaysDeliveryEnum")
@XmlEnum(String.class)
public enum FiveDaysDeliveryEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    FiveDaysDeliveryEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static FiveDaysDeliveryEnum fromValue(String v) {
        for (FiveDaysDeliveryEnum b : FiveDaysDeliveryEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "5 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 5 günde teslimat butonu aktif.<br><code>0</code> : 5 günde teslimat butonu pasif.<br></div>")
 /**
   * 5 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 5 günde teslimat butonu aktif.<br><code>0</code> : 5 günde teslimat butonu pasif.<br></div>  
  **/
  private FiveDaysDeliveryEnum fiveDaysDelivery = null;

@XmlType(name="SevenDaysDeliveryEnum")
@XmlEnum(String.class)
public enum SevenDaysDeliveryEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    SevenDaysDeliveryEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static SevenDaysDeliveryEnum fromValue(String v) {
        for (SevenDaysDeliveryEnum b : SevenDaysDeliveryEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "7 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 7 günde teslimat butonu aktif.<br><code>0</code> : 7 günde teslimat butonu pasif.<br></div>")
 /**
   * 7 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 7 günde teslimat butonu aktif.<br><code>0</code> : 7 günde teslimat butonu pasif.<br></div>  
  **/
  private SevenDaysDeliveryEnum sevenDaysDelivery = null;

@XmlType(name="FreeShippingEnum")
@XmlEnum(String.class)
public enum FreeShippingEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    FreeShippingEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static FreeShippingEnum fromValue(String v) {
        for (FreeShippingEnum b : FreeShippingEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Kargo bedava butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Kargo bedava butonu aktif.<br><code>0</code> : Kargo bedava butonu pasif.<br></div>")
 /**
   * Kargo bedava butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Kargo bedava butonu aktif.<br><code>0</code> : Kargo bedava butonu pasif.<br></div>  
  **/
  private FreeShippingEnum freeShipping = null;

@XmlType(name="DeliveryFromStockEnum")
@XmlEnum(String.class)
public enum DeliveryFromStockEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    DeliveryFromStockEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static DeliveryFromStockEnum fromValue(String v) {
        for (DeliveryFromStockEnum b : DeliveryFromStockEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Stoktan teslim butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Stoktan teslim butonu aktif.<br><code>0</code> : Stoktan teslim butonu pasif.<br></div>")
 /**
   * Stoktan teslim butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Stoktan teslim butonu aktif.<br><code>0</code> : Stoktan teslim butonu pasif.<br></div>  
  **/
  private DeliveryFromStockEnum deliveryFromStock = null;

@XmlType(name="PreOrderedProductEnum")
@XmlEnum(String.class)
public enum PreOrderedProductEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    PreOrderedProductEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static PreOrderedProductEnum fromValue(String v) {
        for (PreOrderedProductEnum b : PreOrderedProductEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Ön siparişli stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Ön siparişli ürün butonu aktif.<br><code>0</code> : Ön siparişli ürün butonu pasif.<br></div>")
 /**
   * Ön siparişli stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Ön siparişli ürün butonu aktif.<br><code>0</code> : Ön siparişli ürün butonu pasif.<br></div>  
  **/
  private PreOrderedProductEnum preOrderedProduct = null;

@XmlType(name="LimitedStockEnum")
@XmlEnum(String.class)
public enum LimitedStockEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    LimitedStockEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static LimitedStockEnum fromValue(String v) {
        for (LimitedStockEnum b : LimitedStockEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Sınırlı stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Sınırlı stok butonu aktif.<br><code>0</code> : Sınırlı stok butonu pasif.<br></div>")
 /**
   * Sınırlı stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Sınırlı stok butonu aktif.<br><code>0</code> : Sınırlı stok butonu pasif.<br></div>  
  **/
  private LimitedStockEnum limitedStock = null;

@XmlType(name="AskStockEnum")
@XmlEnum(String.class)
public enum AskStockEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    AskStockEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static AskStockEnum fromValue(String v) {
        for (AskStockEnum b : AskStockEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Stok sorunuz butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Stok sorunuz butonu aktif.<br><code>0</code> : Stok sorunuz butonu pasif.<br></div>")
 /**
   * Stok sorunuz butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Stok sorunuz butonu aktif.<br><code>0</code> : Stok sorunuz butonu pasif.<br></div>  
  **/
  private AskStockEnum askStock = null;

@XmlType(name="CampaignedProductEnum")
@XmlEnum(String.class)
public enum CampaignedProductEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    CampaignedProductEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static CampaignedProductEnum fromValue(String v) {
        for (CampaignedProductEnum b : CampaignedProductEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Kampanyalı stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Kampanyalı ürün butonu aktif.<br><code>0</code> : Kampanyalı ürün butonu pasif.<br></div>")
 /**
   * Kampanyalı stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Kampanyalı ürün butonu aktif.<br><code>0</code> : Kampanyalı ürün butonu pasif.<br></div>  
  **/
  private CampaignedProductEnum campaignedProduct = null;
  @ApiModelProperty(value = "")
  private Product product = null;

 /**
   * Ürün ve stok butonu nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductButton id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Hızlı gönderi butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hızlı kargo butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hızlı kargo butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return fastShipping
  **/
  @JsonProperty("fastShipping")
  public String getFastShipping() {
    if (fastShipping == null) {
      return null;
    }
    return fastShipping.value();
  }

  public void setFastShipping(FastShippingEnum fastShipping) {
    this.fastShipping = fastShipping;
  }

  public ProductButton fastShipping(FastShippingEnum fastShipping) {
    this.fastShipping = fastShipping;
    return this;
  }

 /**
   * Aynı gün kargo butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aynı gün kargo butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Aynı gün kargo butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return sameDayShipping
  **/
  @JsonProperty("sameDayShipping")
  public String getSameDayShipping() {
    if (sameDayShipping == null) {
      return null;
    }
    return sameDayShipping.value();
  }

  public void setSameDayShipping(SameDayShippingEnum sameDayShipping) {
    this.sameDayShipping = sameDayShipping;
  }

  public ProductButton sameDayShipping(SameDayShippingEnum sameDayShipping) {
    this.sameDayShipping = sameDayShipping;
    return this;
  }

 /**
   * 3 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 3 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 3 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return threeDaysDelivery
  **/
  @JsonProperty("threeDaysDelivery")
  public String getThreeDaysDelivery() {
    if (threeDaysDelivery == null) {
      return null;
    }
    return threeDaysDelivery.value();
  }

  public void setThreeDaysDelivery(ThreeDaysDeliveryEnum threeDaysDelivery) {
    this.threeDaysDelivery = threeDaysDelivery;
  }

  public ProductButton threeDaysDelivery(ThreeDaysDeliveryEnum threeDaysDelivery) {
    this.threeDaysDelivery = threeDaysDelivery;
    return this;
  }

 /**
   * 5 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 5 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 5 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return fiveDaysDelivery
  **/
  @JsonProperty("fiveDaysDelivery")
  public String getFiveDaysDelivery() {
    if (fiveDaysDelivery == null) {
      return null;
    }
    return fiveDaysDelivery.value();
  }

  public void setFiveDaysDelivery(FiveDaysDeliveryEnum fiveDaysDelivery) {
    this.fiveDaysDelivery = fiveDaysDelivery;
  }

  public ProductButton fiveDaysDelivery(FiveDaysDeliveryEnum fiveDaysDelivery) {
    this.fiveDaysDelivery = fiveDaysDelivery;
    return this;
  }

 /**
   * 7 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 7 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 7 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return sevenDaysDelivery
  **/
  @JsonProperty("sevenDaysDelivery")
  public String getSevenDaysDelivery() {
    if (sevenDaysDelivery == null) {
      return null;
    }
    return sevenDaysDelivery.value();
  }

  public void setSevenDaysDelivery(SevenDaysDeliveryEnum sevenDaysDelivery) {
    this.sevenDaysDelivery = sevenDaysDelivery;
  }

  public ProductButton sevenDaysDelivery(SevenDaysDeliveryEnum sevenDaysDelivery) {
    this.sevenDaysDelivery = sevenDaysDelivery;
    return this;
  }

 /**
   * Kargo bedava butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kargo bedava butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kargo bedava butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return freeShipping
  **/
  @JsonProperty("freeShipping")
  public String getFreeShipping() {
    if (freeShipping == null) {
      return null;
    }
    return freeShipping.value();
  }

  public void setFreeShipping(FreeShippingEnum freeShipping) {
    this.freeShipping = freeShipping;
  }

  public ProductButton freeShipping(FreeShippingEnum freeShipping) {
    this.freeShipping = freeShipping;
    return this;
  }

 /**
   * Stoktan teslim butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Stoktan teslim butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Stoktan teslim butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return deliveryFromStock
  **/
  @JsonProperty("deliveryFromStock")
  public String getDeliveryFromStock() {
    if (deliveryFromStock == null) {
      return null;
    }
    return deliveryFromStock.value();
  }

  public void setDeliveryFromStock(DeliveryFromStockEnum deliveryFromStock) {
    this.deliveryFromStock = deliveryFromStock;
  }

  public ProductButton deliveryFromStock(DeliveryFromStockEnum deliveryFromStock) {
    this.deliveryFromStock = deliveryFromStock;
    return this;
  }

 /**
   * Ön siparişli stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Ön siparişli ürün butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Ön siparişli ürün butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return preOrderedProduct
  **/
  @JsonProperty("preOrderedProduct")
  public String getPreOrderedProduct() {
    if (preOrderedProduct == null) {
      return null;
    }
    return preOrderedProduct.value();
  }

  public void setPreOrderedProduct(PreOrderedProductEnum preOrderedProduct) {
    this.preOrderedProduct = preOrderedProduct;
  }

  public ProductButton preOrderedProduct(PreOrderedProductEnum preOrderedProduct) {
    this.preOrderedProduct = preOrderedProduct;
    return this;
  }

 /**
   * Sınırlı stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sınırlı stok butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sınırlı stok butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return limitedStock
  **/
  @JsonProperty("limitedStock")
  public String getLimitedStock() {
    if (limitedStock == null) {
      return null;
    }
    return limitedStock.value();
  }

  public void setLimitedStock(LimitedStockEnum limitedStock) {
    this.limitedStock = limitedStock;
  }

  public ProductButton limitedStock(LimitedStockEnum limitedStock) {
    this.limitedStock = limitedStock;
    return this;
  }

 /**
   * Stok sorunuz butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Stok sorunuz butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Stok sorunuz butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return askStock
  **/
  @JsonProperty("askStock")
  public String getAskStock() {
    if (askStock == null) {
      return null;
    }
    return askStock.value();
  }

  public void setAskStock(AskStockEnum askStock) {
    this.askStock = askStock;
  }

  public ProductButton askStock(AskStockEnum askStock) {
    this.askStock = askStock;
    return this;
  }

 /**
   * Kampanyalı stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalı ürün butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalı ürün butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return campaignedProduct
  **/
  @JsonProperty("campaignedProduct")
  public String getCampaignedProduct() {
    if (campaignedProduct == null) {
      return null;
    }
    return campaignedProduct.value();
  }

  public void setCampaignedProduct(CampaignedProductEnum campaignedProduct) {
    this.campaignedProduct = campaignedProduct;
  }

  public ProductButton campaignedProduct(CampaignedProductEnum campaignedProduct) {
    this.campaignedProduct = campaignedProduct;
    return this;
  }

 /**
   * Get product
   * @return product
  **/
  @JsonProperty("product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public ProductButton product(Product product) {
    this.product = product;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductButton {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    fastShipping: ").append(toIndentedString(fastShipping)).append("\n");
    sb.append("    sameDayShipping: ").append(toIndentedString(sameDayShipping)).append("\n");
    sb.append("    threeDaysDelivery: ").append(toIndentedString(threeDaysDelivery)).append("\n");
    sb.append("    fiveDaysDelivery: ").append(toIndentedString(fiveDaysDelivery)).append("\n");
    sb.append("    sevenDaysDelivery: ").append(toIndentedString(sevenDaysDelivery)).append("\n");
    sb.append("    freeShipping: ").append(toIndentedString(freeShipping)).append("\n");
    sb.append("    deliveryFromStock: ").append(toIndentedString(deliveryFromStock)).append("\n");
    sb.append("    preOrderedProduct: ").append(toIndentedString(preOrderedProduct)).append("\n");
    sb.append("    limitedStock: ").append(toIndentedString(limitedStock)).append("\n");
    sb.append("    askStock: ").append(toIndentedString(askStock)).append("\n");
    sb.append("    campaignedProduct: ").append(toIndentedString(campaignedProduct)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

