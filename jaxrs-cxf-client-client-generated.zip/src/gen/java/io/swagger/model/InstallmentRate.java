package io.swagger.model;

import io.swagger.model.PaymentGateway;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class InstallmentRate  {
  
  @ApiModelProperty(example = "123", value = "Taksit oranı nesnesi kimlik değeri.")
 /**
   * Taksit oranı nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "3", required = true, value = "Taksit adeti.")
 /**
   * Taksit adeti.  
  **/
  private Integer installment = null;

  @ApiModelProperty(example = "1.2", required = true, value = "Taksit adeti için oran bilgisi.")
 /**
   * Taksit adeti için oran bilgisi.  
  **/
  private Float rate = null;

  @ApiModelProperty(required = true, value = "Ödeme kanalı nesnesi.")
 /**
   * Ödeme kanalı nesnesi.  
  **/
  private PaymentGateway paymentGateway = null;
 /**
   * Taksit oranı nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public InstallmentRate id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Taksit adeti.
   * @return installment
  **/
  @JsonProperty("installment")
  public Integer getInstallment() {
    return installment;
  }

  public void setInstallment(Integer installment) {
    this.installment = installment;
  }

  public InstallmentRate installment(Integer installment) {
    this.installment = installment;
    return this;
  }

 /**
   * Taksit adeti için oran bilgisi.
   * minimum: 0
   * @return rate
  **/
  @JsonProperty("rate")
  public Float getRate() {
    return rate;
  }

  public void setRate(Float rate) {
    this.rate = rate;
  }

  public InstallmentRate rate(Float rate) {
    this.rate = rate;
    return this;
  }

 /**
   * Ödeme kanalı nesnesi.
   * @return paymentGateway
  **/
  @JsonProperty("paymentGateway")
  public PaymentGateway getPaymentGateway() {
    return paymentGateway;
  }

  public void setPaymentGateway(PaymentGateway paymentGateway) {
    this.paymentGateway = paymentGateway;
  }

  public InstallmentRate paymentGateway(PaymentGateway paymentGateway) {
    this.paymentGateway = paymentGateway;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InstallmentRate {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    installment: ").append(toIndentedString(installment)).append("\n");
    sb.append("    rate: ").append(toIndentedString(rate)).append("\n");
    sb.append("    paymentGateway: ").append(toIndentedString(paymentGateway)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

