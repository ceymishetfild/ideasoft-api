package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Error  {
  
  @ApiModelProperty(example = "400", value = "HTTP Hata kodu.")
 /**
   * HTTP Hata kodu.  
  **/
  private Integer code = null;
  @ApiModelProperty(example = "Error message of the subjected error.", value = "Hata mesajı. Hata mesajları İngilizce dilindedir.")
 /**
   * Hata mesajı. Hata mesajları İngilizce dilindedir.  
  **/
  private String errorMessage = null;
  @ApiModelProperty(example = "0", value = "Hata kodu. Eğer ek bir hata kodu varsa bu alanda belirtilir.")
 /**
   * Hata kodu. Eğer ek bir hata kodu varsa bu alanda belirtilir.  
  **/
  private Integer errorCode = null;

 /**
   * HTTP Hata kodu.
   * minimum: 100
   * maximum: 600
   * @return code
  **/
  @JsonProperty("code")
  public Integer getCode() {
    return code;
  }

  public void setCode(Integer code) {
    this.code = code;
  }

  public Error code(Integer code) {
    this.code = code;
    return this;
  }

 /**
   * Hata mesajı. Hata mesajları İngilizce dilindedir.
   * @return errorMessage
  **/
  @JsonProperty("errorMessage")
  public String getErrorMessage() {
    return errorMessage;
  }

  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  public Error errorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
    return this;
  }

 /**
   * Hata kodu. Eğer ek bir hata kodu varsa bu alanda belirtilir.
   * @return errorCode
  **/
  @JsonProperty("errorCode")
  public Integer getErrorCode() {
    return errorCode;
  }

  public void setErrorCode(Integer errorCode) {
    this.errorCode = errorCode;
  }

  public Error errorCode(Integer errorCode) {
    this.errorCode = errorCode;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Error {\n");
    
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    errorMessage: ").append(toIndentedString(errorMessage)).append("\n");
    sb.append("    errorCode: ").append(toIndentedString(errorCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

