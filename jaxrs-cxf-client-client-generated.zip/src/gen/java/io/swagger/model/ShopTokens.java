package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ShopTokens  {
  
  @ApiModelProperty(example = "123", value = "Hediye çeki nesnesi kimlik değeri.")
 /**
   * Hediye çeki nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "HEDIYE2018", value = "Hediye çekinin benzersiz kodu. Admin panelinden düzenlenebilir.")
 /**
   * Hediye çekinin benzersiz kodu. Admin panelinden düzenlenebilir.  
  **/
  private String code = null;
 /**
   * Hediye çeki nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ShopTokens id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Hediye çekinin benzersiz kodu. Admin panelinden düzenlenebilir.
   * @return code
  **/
  @JsonProperty("code")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public ShopTokens code(String code) {
    this.code = code;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShopTokens {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

