package io.swagger.model;

import io.swagger.model.Category;
import io.swagger.model.Product;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductToCategory  {
  
  @ApiModelProperty(example = "123", value = "Ürün kategori bağı nesnesi kimlik değeri.")
 /**
   * Ürün kategori bağı nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "9999", value = "Ürün kategori bağının sıralama değeri. Özel sıra belirtmek istemiyorsanız 9999 olarak iletebilirsiniz.")
 /**
   * Ürün kategori bağının sıralama değeri. Özel sıra belirtmek istemiyorsanız 9999 olarak iletebilirsiniz.  
  **/
  private Integer sortOrder = null;

  @ApiModelProperty(required = true, value = "Ürün nesnesi.")
 /**
   * Ürün nesnesi.  
  **/
  private Product product = null;

  @ApiModelProperty(required = true, value = "Kategori nesnesi.")
 /**
   * Kategori nesnesi.  
  **/
  private Category category = null;
 /**
   * Ürün kategori bağı nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductToCategory id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ürün kategori bağının sıralama değeri. Özel sıra belirtmek istemiyorsanız 9999 olarak iletebilirsiniz.
   * minimum: 0
   * maximum: 9999
   * @return sortOrder
  **/
  @JsonProperty("sortOrder")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public ProductToCategory sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

 /**
   * Ürün nesnesi.
   * @return product
  **/
  @JsonProperty("product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public ProductToCategory product(Product product) {
    this.product = product;
    return this;
  }

 /**
   * Kategori nesnesi.
   * @return category
  **/
  @JsonProperty("category")
  public Category getCategory() {
    return category;
  }

  public void setCategory(Category category) {
    this.category = category;
  }

  public ProductToCategory category(Category category) {
    this.category = category;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductToCategory {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("    category: ").append(toIndentedString(category)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

