package io.swagger.model;

import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Asset  {
  
  @ApiModelProperty(example = "configs/settings_data.json", value = "Tema Dosyası nesnesi anahtar değeri.")
 /**
   * Tema Dosyası nesnesi anahtar değeri.  
  **/
  private String key = null;
  @ApiModelProperty(example = "text/plain", value = "Tema Dosyası içerik tipi. Geçerli bir MIME Content-Type verilmelidir.")
 /**
   * Tema Dosyası içerik tipi. Geçerli bir MIME Content-Type verilmelidir.  
  **/
  private String contentType = null;
  @ApiModelProperty(example = "{   \"display_stock_code\": 1,   \"use_social_links\": 1,   \"use_image_zoom\": 1,   \"display_category_logo\": 0,   \"display_category_subcategories\": 1,   \"display_category_brands\": 1,   \"display_sorting_options\": 1,   \"display_compare_button\": 1,   \"use_shorter_product_label\": 1,   \"display_order_tax_information\": 1,   \"use_lazy_load\": 0,   \"use_facebook_login\": 0,   \"use_google_login\": 0,   \"use_popup_cart\": 0,   \"brand_view_type\": \"name\",   \"showcase_repeat_columns\": 2,   \"use_rich_snippets\": 0,   \"optioned_product_view_type\": \"dropdown\",   \"optioned_product_price_view_type\": \"name_with_tax_string\",   \"quantity_selector_type\": \"dropdown\",   \"display_product_bread_crumb\": 1,   \"display_tax_information_on_showcase\": 1,   \"display_without_tax_price\": 1,   \"allow_product_comments\": 1,   \"display_product_attributes\": 1,   \"product_zoom_size\": 240,   \"display_category_bread_crumb\": 0,   \"display_included_tax_string_on_showcase\": 1,   \"display_retailer_comparison_price\": 0,   \"use_search_auto_complete\": 0,   \"use_lock_right_click\": 0,   \"display_category_or_brand_filter\": 0,   \"display_product_lowest_installment\": 1,   \"nopic_image\": \"\",   \"product_detail_page_tabs\": {  \"display_product_comments\": 1,   \"display_similar_products\": 1,  \"display_payment_options\": 1,  \"display_product_feeds\": 1,  \"display_special_information_area\": 1   },   \"logo\": \"\" }", value = "Tema Dosyası içeriği.")
 /**
   * Tema Dosyası içeriği.  
  **/
  private String attachment = null;
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Tema Dosyası nesnesinin oluşturulma zamanı.")
 /**
   * Tema Dosyası nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Tema Dosyası nesnesinin güncellenme zamanı.")
 /**
   * Tema Dosyası nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;

 /**
   * Tema Dosyası nesnesi anahtar değeri.
   * @return key
  **/
  @JsonProperty("key")
  public String getKey() {
    return key;
  }

  public void setKey(String key) {
    this.key = key;
  }

  public Asset key(String key) {
    this.key = key;
    return this;
  }

 /**
   * Tema Dosyası içerik tipi. Geçerli bir MIME Content-Type verilmelidir.
   * @return contentType
  **/
  @JsonProperty("contentType")
  public String getContentType() {
    return contentType;
  }

  public void setContentType(String contentType) {
    this.contentType = contentType;
  }

  public Asset contentType(String contentType) {
    this.contentType = contentType;
    return this;
  }

 /**
   * Tema Dosyası içeriği.
   * @return attachment
  **/
  @JsonProperty("attachment")
  public String getAttachment() {
    return attachment;
  }

  public void setAttachment(String attachment) {
    this.attachment = attachment;
  }

  public Asset attachment(String attachment) {
    this.attachment = attachment;
    return this;
  }

 /**
   * Tema Dosyası nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(Date createdAt) {
    this.createdAt = createdAt;
  }

  public Asset createdAt(Date createdAt) {
    this.createdAt = createdAt;
    return this;
  }

 /**
   * Tema Dosyası nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(Date updatedAt) {
    this.updatedAt = updatedAt;
  }

  public Asset updatedAt(Date updatedAt) {
    this.updatedAt = updatedAt;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Asset {\n");
    
    sb.append("    key: ").append(toIndentedString(key)).append("\n");
    sb.append("    contentType: ").append(toIndentedString(contentType)).append("\n");
    sb.append("    attachment: ").append(toIndentedString(attachment)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

