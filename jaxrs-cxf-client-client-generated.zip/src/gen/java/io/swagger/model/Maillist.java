package io.swagger.model;

import io.swagger.model.MaillistGroup;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Maillist  {
  
  @ApiModelProperty(example = "123", value = "Mail listesi nesnesi kimlik değeri.")
 /**
   * Mail listesi nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "Mail listesi", required = true, value = "Mail listesi nesnesi için isim değeri.")
 /**
   * Mail listesi nesnesi için isim değeri.  
  **/
  private String name = null;
  @ApiModelProperty(example = "johndoe@ideasoft.com.tr", required = true, value = "Ziyaretçi veya üyenin mail adresi.")
 /**
   * Ziyaretçi veya üyenin mail adresi.  
  **/
  private String email = null;
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "En son e-mail gönderilen zaman.")
 /**
   * En son e-mail gönderilen zaman.  
  **/
  private Date lastMailSentDate = null;
  @ApiModelProperty(example = "192.168.1.1", value = "Mail listesi nesnesini oluşturan kişinin IP adresi.")
 /**
   * Mail listesi nesnesini oluşturan kişinin IP adresi.  
  **/
  private String creatorIpAddress = null;
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", required = true, value = "Mail listesi nesnesinin oluşturulma zamanı.")
 /**
   * Mail listesi nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", required = true, value = "Mail listesi nesnesinin güncellenme zamanı.")
 /**
   * Mail listesi nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;
  @ApiModelProperty(value = "")
  private MaillistGroup maillistGroup = null;

 /**
   * Mail listesi nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Maillist id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Mail listesi nesnesi için isim değeri.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Maillist name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Ziyaretçi veya üyenin mail adresi.
   * @return email
  **/
  @JsonProperty("email")
  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public Maillist email(String email) {
    this.email = email;
    return this;
  }

 /**
   * En son e-mail gönderilen zaman.
   * @return lastMailSentDate
  **/
  @JsonProperty("lastMailSentDate")
  public Date getLastMailSentDate() {
    return lastMailSentDate;
  }

  public void setLastMailSentDate(Date lastMailSentDate) {
    this.lastMailSentDate = lastMailSentDate;
  }

  public Maillist lastMailSentDate(Date lastMailSentDate) {
    this.lastMailSentDate = lastMailSentDate;
    return this;
  }

 /**
   * Mail listesi nesnesini oluşturan kişinin IP adresi.
   * @return creatorIpAddress
  **/
  @JsonProperty("creatorIpAddress")
  public String getCreatorIpAddress() {
    return creatorIpAddress;
  }

  public void setCreatorIpAddress(String creatorIpAddress) {
    this.creatorIpAddress = creatorIpAddress;
  }

  public Maillist creatorIpAddress(String creatorIpAddress) {
    this.creatorIpAddress = creatorIpAddress;
    return this;
  }

 /**
   * Mail listesi nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Mail listesi nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }


 /**
   * Get maillistGroup
   * @return maillistGroup
  **/
  @JsonProperty("maillistGroup")
  public MaillistGroup getMaillistGroup() {
    return maillistGroup;
  }

  public void setMaillistGroup(MaillistGroup maillistGroup) {
    this.maillistGroup = maillistGroup;
  }

  public Maillist maillistGroup(MaillistGroup maillistGroup) {
    this.maillistGroup = maillistGroup;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Maillist {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    lastMailSentDate: ").append(toIndentedString(lastMailSentDate)).append("\n");
    sb.append("    creatorIpAddress: ").append(toIndentedString(creatorIpAddress)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    maillistGroup: ").append(toIndentedString(maillistGroup)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

