package io.swagger.model;

import io.swagger.model.CartItem;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CartItemAttribute  {
  
  @ApiModelProperty(example = "123", value = "Sepet kalemi özelliği nesnesi kimlik değeri.")
 /**
   * Sepet kalemi özelliği nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "Renk", value = "Sepet kalemi özelliği nesnesinin isim değeri. Örneğin, sepet kalemi kalem ise bu değer renk olabilir.")
 /**
   * Sepet kalemi özelliği nesnesinin isim değeri. Örneğin, sepet kalemi kalem ise bu değer renk olabilir.  
  **/
  private String name = null;

  @ApiModelProperty(example = "Kırmızı", value = "Sepet kalemi özelliği nesnesinin değeri. Örneğin, sepet kalemi kalem, isim değeri renk ise bu değer kırmızı olabilir.")
 /**
   * Sepet kalemi özelliği nesnesinin değeri. Örneğin, sepet kalemi kalem, isim değeri renk ise bu değer kırmızı olabilir.  
  **/
  private String value = null;

  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Sepet kalemi özelliği nesnesinin oluşturulma zamanı.")
 /**
   * Sepet kalemi özelliği nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;

  @ApiModelProperty(value = "Sepet kalemi nesnesi.")
 /**
   * Sepet kalemi nesnesi.  
  **/
  private CartItem cartItem = null;
 /**
   * Sepet kalemi özelliği nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public CartItemAttribute id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Sepet kalemi özelliği nesnesinin isim değeri. Örneğin, sepet kalemi kalem ise bu değer renk olabilir.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public CartItemAttribute name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Sepet kalemi özelliği nesnesinin değeri. Örneğin, sepet kalemi kalem, isim değeri renk ise bu değer kırmızı olabilir.
   * @return value
  **/
  @JsonProperty("value")
  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public CartItemAttribute value(String value) {
    this.value = value;
    return this;
  }

 /**
   * Sepet kalemi özelliği nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Sepet kalemi nesnesi.
   * @return cartItem
  **/
  @JsonProperty("cartItem")
  public CartItem getCartItem() {
    return cartItem;
  }

  public void setCartItem(CartItem cartItem) {
    this.cartItem = cartItem;
  }

  public CartItemAttribute cartItem(CartItem cartItem) {
    this.cartItem = cartItem;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CartItemAttribute {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    value: ").append(toIndentedString(value)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    cartItem: ").append(toIndentedString(cartItem)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

