package io.swagger.model;

import io.swagger.model.Order;
import io.swagger.model.OrderItemSubscription;
import io.swagger.model.Product;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderItem  {
  
  @ApiModelProperty(example = "123", value = "Sipariş kalemi nesnesi kimlik değeri.")
 /**
   * Sipariş kalemi nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "Kalem", required = true, value = "Ürünün adı.")
 /**
   * Ürünün adı.  
  **/
  private String productName = null;
  @ApiModelProperty(example = "KAL-1234", required = true, value = "Ürünün stok kodu.")
 /**
   * Ürünün stok kodu.  
  **/
  private String productSku = null;
  @ApiModelProperty(example = "869456789874", value = "Ürünün barkodu.")
 /**
   * Ürünün barkodu.  
  **/
  private String productBarcode = null;
  @ApiModelProperty(example = "15.0", required = true, value = "Ürünün fiyatı.")
 /**
   * Ürünün fiyatı.  
  **/
  private Float productPrice = null;
  @ApiModelProperty(example = "TL", required = true, value = "Ürünün kuru.")
 /**
   * Ürünün kuru.  
  **/
  private String productCurrency = null;
  @ApiModelProperty(example = "1.0", required = true, value = "Ürünün stok tipi cinsinden miktarı.")
 /**
   * Ürünün stok tipi cinsinden miktarı.  
  **/
  private Float productQuantity = null;
  @ApiModelProperty(example = "18", required = true, value = "Ürünün vergisi")
 /**
   * Ürünün vergisi  
  **/
  private Integer productTax = null;
  @ApiModelProperty(example = "5.0", required = true, value = "Ürünün standart indirim değeri.")
 /**
   * Ürünün standart indirim değeri.  
  **/
  private Float productDiscount = null;
  @ApiModelProperty(example = "5.0", required = true, value = "Ürünün havale indirim değeri.")
 /**
   * Ürünün havale indirim değeri.  
  **/
  private Float productMoneyOrderDiscount = null;
  @ApiModelProperty(example = "1.2", required = true, value = "Ürünün ağırlığı.")
 /**
   * Ürünün ağırlığı.  
  **/
  private Float productWeight = null;
  @ApiModelProperty(example = "Adet", required = true, value = "Ürünün stok tipi.<div class='idea_choice_list'><code>Adet</code> : Stok tipi birimi Adet<br><code>cm</code> : Stok tipi birimi Santimetre<br><code>Düzine</code> : Stok tipi birimi Düzine<br><code>gram</code> : Stok tipi birimi Gram<br><code>kg</code> : Stok tipi birimi Kilogram<br><code>Kişi</code> : Stok tipi birimi Kişi<br><code>Paket</code> : Stok tipi birimi Paket<br><code>metre</code> : Stok tipi birimi Metre<br><code>m2</code> : Stok tipi birimi Metre kare<br><code>Çift</code> : Stok tipi birimi Çift<br></div>")
 /**
   * Ürünün stok tipi.<div class='idea_choice_list'><code>Adet</code> : Stok tipi birimi Adet<br><code>cm</code> : Stok tipi birimi Santimetre<br><code>Düzine</code> : Stok tipi birimi Düzine<br><code>gram</code> : Stok tipi birimi Gram<br><code>kg</code> : Stok tipi birimi Kilogram<br><code>Kişi</code> : Stok tipi birimi Kişi<br><code>Paket</code> : Stok tipi birimi Paket<br><code>metre</code> : Stok tipi birimi Metre<br><code>m2</code> : Stok tipi birimi Metre kare<br><code>Çift</code> : Stok tipi birimi Çift<br></div>  
  **/
  private String productStockTypeLabel = null;

@XmlType(name="IsProductPromotionedEnum")
@XmlEnum(String.class)
public enum IsProductPromotionedEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    IsProductPromotionedEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static IsProductPromotionedEnum fromValue(String v) {
        for (IsProductPromotionedEnum b : IsProductPromotionedEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Ürünün promosyon olup olmadığını belirten değer.<div class='idea_choice_list'><code>0</code> : Ürün promosyon değil.<br><code>1</code> : Ürün promosyon.<br></div>")
 /**
   * Ürünün promosyon olup olmadığını belirten değer.<div class='idea_choice_list'><code>0</code> : Ürün promosyon değil.<br><code>1</code> : Ürün promosyon.<br></div>  
  **/
  private IsProductPromotionedEnum isProductPromotioned = null;
  @ApiModelProperty(example = "5.0", required = true, value = "Ürünün hediye çeki indirim değeri.")
 /**
   * Ürünün hediye çeki indirim değeri.  
  **/
  private Float discount = null;
  @ApiModelProperty(value = "")
  private Order order = null;
  @ApiModelProperty(value = "")
  private Product product = null;
  @ApiModelProperty(value = "")
  private OrderItemSubscription orderItemSubscription = null;

 /**
   * Sipariş kalemi nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OrderItem id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ürünün adı.
   * @return productName
  **/
  @JsonProperty("productName")
  public String getProductName() {
    return productName;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

  public OrderItem productName(String productName) {
    this.productName = productName;
    return this;
  }

 /**
   * Ürünün stok kodu.
   * @return productSku
  **/
  @JsonProperty("productSku")
  public String getProductSku() {
    return productSku;
  }

  public void setProductSku(String productSku) {
    this.productSku = productSku;
  }

  public OrderItem productSku(String productSku) {
    this.productSku = productSku;
    return this;
  }

 /**
   * Ürünün barkodu.
   * @return productBarcode
  **/
  @JsonProperty("productBarcode")
  public String getProductBarcode() {
    return productBarcode;
  }

  public void setProductBarcode(String productBarcode) {
    this.productBarcode = productBarcode;
  }

  public OrderItem productBarcode(String productBarcode) {
    this.productBarcode = productBarcode;
    return this;
  }

 /**
   * Ürünün fiyatı.
   * minimum: 0
   * @return productPrice
  **/
  @JsonProperty("productPrice")
  public Float getProductPrice() {
    return productPrice;
  }

  public void setProductPrice(Float productPrice) {
    this.productPrice = productPrice;
  }

  public OrderItem productPrice(Float productPrice) {
    this.productPrice = productPrice;
    return this;
  }

 /**
   * Ürünün kuru.
   * @return productCurrency
  **/
  @JsonProperty("productCurrency")
  public String getProductCurrency() {
    return productCurrency;
  }

  public void setProductCurrency(String productCurrency) {
    this.productCurrency = productCurrency;
  }

  public OrderItem productCurrency(String productCurrency) {
    this.productCurrency = productCurrency;
    return this;
  }

 /**
   * Ürünün stok tipi cinsinden miktarı.
   * minimum: 0.001
   * @return productQuantity
  **/
  @JsonProperty("productQuantity")
  public Float getProductQuantity() {
    return productQuantity;
  }

  public void setProductQuantity(Float productQuantity) {
    this.productQuantity = productQuantity;
  }

  public OrderItem productQuantity(Float productQuantity) {
    this.productQuantity = productQuantity;
    return this;
  }

 /**
   * Ürünün vergisi
   * minimum: 0
   * @return productTax
  **/
  @JsonProperty("productTax")
  public Integer getProductTax() {
    return productTax;
  }

  public void setProductTax(Integer productTax) {
    this.productTax = productTax;
  }

  public OrderItem productTax(Integer productTax) {
    this.productTax = productTax;
    return this;
  }

 /**
   * Ürünün standart indirim değeri.
   * @return productDiscount
  **/
  @JsonProperty("productDiscount")
  public Float getProductDiscount() {
    return productDiscount;
  }

  public void setProductDiscount(Float productDiscount) {
    this.productDiscount = productDiscount;
  }

  public OrderItem productDiscount(Float productDiscount) {
    this.productDiscount = productDiscount;
    return this;
  }

 /**
   * Ürünün havale indirim değeri.
   * minimum: 0
   * @return productMoneyOrderDiscount
  **/
  @JsonProperty("productMoneyOrderDiscount")
  public Float getProductMoneyOrderDiscount() {
    return productMoneyOrderDiscount;
  }

  public void setProductMoneyOrderDiscount(Float productMoneyOrderDiscount) {
    this.productMoneyOrderDiscount = productMoneyOrderDiscount;
  }

  public OrderItem productMoneyOrderDiscount(Float productMoneyOrderDiscount) {
    this.productMoneyOrderDiscount = productMoneyOrderDiscount;
    return this;
  }

 /**
   * Ürünün ağırlığı.
   * minimum: 0
   * @return productWeight
  **/
  @JsonProperty("productWeight")
  public Float getProductWeight() {
    return productWeight;
  }

  public void setProductWeight(Float productWeight) {
    this.productWeight = productWeight;
  }

  public OrderItem productWeight(Float productWeight) {
    this.productWeight = productWeight;
    return this;
  }

 /**
   * Ürünün stok tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Adet&lt;/code&gt; : Stok tipi birimi Adet&lt;br&gt;&lt;code&gt;cm&lt;/code&gt; : Stok tipi birimi Santimetre&lt;br&gt;&lt;code&gt;Düzine&lt;/code&gt; : Stok tipi birimi Düzine&lt;br&gt;&lt;code&gt;gram&lt;/code&gt; : Stok tipi birimi Gram&lt;br&gt;&lt;code&gt;kg&lt;/code&gt; : Stok tipi birimi Kilogram&lt;br&gt;&lt;code&gt;Kişi&lt;/code&gt; : Stok tipi birimi Kişi&lt;br&gt;&lt;code&gt;Paket&lt;/code&gt; : Stok tipi birimi Paket&lt;br&gt;&lt;code&gt;metre&lt;/code&gt; : Stok tipi birimi Metre&lt;br&gt;&lt;code&gt;m2&lt;/code&gt; : Stok tipi birimi Metre kare&lt;br&gt;&lt;code&gt;Çift&lt;/code&gt; : Stok tipi birimi Çift&lt;br&gt;&lt;/div&gt;
   * @return productStockTypeLabel
  **/
  @JsonProperty("productStockTypeLabel")
  public String getProductStockTypeLabel() {
    return productStockTypeLabel;
  }

  public void setProductStockTypeLabel(String productStockTypeLabel) {
    this.productStockTypeLabel = productStockTypeLabel;
  }

  public OrderItem productStockTypeLabel(String productStockTypeLabel) {
    this.productStockTypeLabel = productStockTypeLabel;
    return this;
  }

 /**
   * Ürünün promosyon olup olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;0&lt;/code&gt; : Ürün promosyon değil.&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Ürün promosyon.&lt;br&gt;&lt;/div&gt;
   * @return isProductPromotioned
  **/
  @JsonProperty("isProductPromotioned")
  public String getIsProductPromotioned() {
    if (isProductPromotioned == null) {
      return null;
    }
    return isProductPromotioned.value();
  }

  public void setIsProductPromotioned(IsProductPromotionedEnum isProductPromotioned) {
    this.isProductPromotioned = isProductPromotioned;
  }

  public OrderItem isProductPromotioned(IsProductPromotionedEnum isProductPromotioned) {
    this.isProductPromotioned = isProductPromotioned;
    return this;
  }

 /**
   * Ürünün hediye çeki indirim değeri.
   * minimum: 0
   * @return discount
  **/
  @JsonProperty("discount")
  public Float getDiscount() {
    return discount;
  }

  public void setDiscount(Float discount) {
    this.discount = discount;
  }

  public OrderItem discount(Float discount) {
    this.discount = discount;
    return this;
  }

 /**
   * Get order
   * @return order
  **/
  @JsonProperty("order")
  public Order getOrder() {
    return order;
  }

  public void setOrder(Order order) {
    this.order = order;
  }

  public OrderItem order(Order order) {
    this.order = order;
    return this;
  }

 /**
   * Get product
   * @return product
  **/
  @JsonProperty("product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public OrderItem product(Product product) {
    this.product = product;
    return this;
  }

 /**
   * Get orderItemSubscription
   * @return orderItemSubscription
  **/
  @JsonProperty("orderItemSubscription")
  public OrderItemSubscription getOrderItemSubscription() {
    return orderItemSubscription;
  }

  public void setOrderItemSubscription(OrderItemSubscription orderItemSubscription) {
    this.orderItemSubscription = orderItemSubscription;
  }

  public OrderItem orderItemSubscription(OrderItemSubscription orderItemSubscription) {
    this.orderItemSubscription = orderItemSubscription;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderItem {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    productName: ").append(toIndentedString(productName)).append("\n");
    sb.append("    productSku: ").append(toIndentedString(productSku)).append("\n");
    sb.append("    productBarcode: ").append(toIndentedString(productBarcode)).append("\n");
    sb.append("    productPrice: ").append(toIndentedString(productPrice)).append("\n");
    sb.append("    productCurrency: ").append(toIndentedString(productCurrency)).append("\n");
    sb.append("    productQuantity: ").append(toIndentedString(productQuantity)).append("\n");
    sb.append("    productTax: ").append(toIndentedString(productTax)).append("\n");
    sb.append("    productDiscount: ").append(toIndentedString(productDiscount)).append("\n");
    sb.append("    productMoneyOrderDiscount: ").append(toIndentedString(productMoneyOrderDiscount)).append("\n");
    sb.append("    productWeight: ").append(toIndentedString(productWeight)).append("\n");
    sb.append("    productStockTypeLabel: ").append(toIndentedString(productStockTypeLabel)).append("\n");
    sb.append("    isProductPromotioned: ").append(toIndentedString(isProductPromotioned)).append("\n");
    sb.append("    discount: ").append(toIndentedString(discount)).append("\n");
    sb.append("    order: ").append(toIndentedString(order)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("    orderItemSubscription: ").append(toIndentedString(orderItemSubscription)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

