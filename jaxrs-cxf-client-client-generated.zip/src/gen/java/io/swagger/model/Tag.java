package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Tag  {
  
  @ApiModelProperty(example = "123", value = "SEO+ etiketi nesnesi kimlik değeri.")
 /**
   * SEO+ etiketi nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "ideasoft", required = true, value = "SEO+ etiketi nesnesi için isim değeri.")
 /**
   * SEO+ etiketi nesnesi için isim değeri.  
  **/
  private String name = null;

  @ApiModelProperty(example = "2", value = "SEO+ etiketinin kaç kez kullanıldığı bilgisi.")
 /**
   * SEO+ etiketinin kaç kez kullanıldığı bilgisi.  
  **/
  private Integer count = null;

  @ApiModelProperty(example = "Kırmızı Kalem", value = "SEO+ etiketi nesnesinin etiket başlığı.")
 /**
   * SEO+ etiketi nesnesinin etiket başlığı.  
  **/
  private String pageTitle = null;

  @ApiModelProperty(example = "Kaliteli kırtasiye ürünleri.", value = "Arama motorları tarafından tespit edilebilecek açıklama yazısı.")
 /**
   * Arama motorları tarafından tespit edilebilecek açıklama yazısı.  
  **/
  private String metaDescription = null;

  @ApiModelProperty(example = "kırmızı, kalem, kırtasiye", value = "Arama motorları tarafından tespit edilebilecek anahtar kelimeler.")
 /**
   * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.  
  **/
  private String metaKeywords = null;
 /**
   * SEO+ etiketi nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Tag id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * SEO+ etiketi nesnesi için isim değeri.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Tag name(String name) {
    this.name = name;
    return this;
  }

 /**
   * SEO+ etiketinin kaç kez kullanıldığı bilgisi.
   * minimum: 0
   * @return count
  **/
  @JsonProperty("count")
  public Integer getCount() {
    return count;
  }

  public void setCount(Integer count) {
    this.count = count;
  }

  public Tag count(Integer count) {
    this.count = count;
    return this;
  }

 /**
   * SEO+ etiketi nesnesinin etiket başlığı.
   * @return pageTitle
  **/
  @JsonProperty("pageTitle")
  public String getPageTitle() {
    return pageTitle;
  }

  public void setPageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
  }

  public Tag pageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
    return this;
  }

 /**
   * Arama motorları tarafından tespit edilebilecek açıklama yazısı.
   * @return metaDescription
  **/
  @JsonProperty("metaDescription")
  public String getMetaDescription() {
    return metaDescription;
  }

  public void setMetaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
  }

  public Tag metaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
    return this;
  }

 /**
   * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.
   * @return metaKeywords
  **/
  @JsonProperty("metaKeywords")
  public String getMetaKeywords() {
    return metaKeywords;
  }

  public void setMetaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
  }

  public Tag metaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Tag {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    count: ").append(toIndentedString(count)).append("\n");
    sb.append("    pageTitle: ").append(toIndentedString(pageTitle)).append("\n");
    sb.append("    metaDescription: ").append(toIndentedString(metaDescription)).append("\n");
    sb.append("    metaKeywords: ").append(toIndentedString(metaKeywords)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

