package io.swagger.model;

import io.swagger.model.Product;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductProtection  {
  
  @ApiModelProperty(example = "123", value = "Entegrasyon seçeneği nesnesi kimlik değeri.")
 /**
   * Entegrasyon seçeneği nesnesi kimlik değeri.  
  **/
  private Integer id = null;

@XmlType(name="IsPriceProtectedEnum")
@XmlEnum(String.class)
public enum IsPriceProtectedEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    IsPriceProtectedEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static IsPriceProtectedEnum fromValue(String v) {
        for (IsPriceProtectedEnum b : IsPriceProtectedEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Ürün fiyatının korumalı olup olmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Korumalı.<br><code>0</code> : Korumasız.<br></div>")
 /**
   * Ürün fiyatının korumalı olup olmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Korumalı.<br><code>0</code> : Korumasız.<br></div>  
  **/
  private IsPriceProtectedEnum isPriceProtected = null;

@XmlType(name="IsStockProtectedEnum")
@XmlEnum(String.class)
public enum IsStockProtectedEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    IsStockProtectedEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static IsStockProtectedEnum fromValue(String v) {
        for (IsStockProtectedEnum b : IsStockProtectedEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Ürün stoğunun korumalı olup olmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Korumalı.<br><code>0</code> : Korumasız.<br></div>")
 /**
   * Ürün stoğunun korumalı olup olmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Korumalı.<br><code>0</code> : Korumasız.<br></div>  
  **/
  private IsStockProtectedEnum isStockProtected = null;
  @ApiModelProperty(value = "")
  private Product product = null;

 /**
   * Entegrasyon seçeneği nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductProtection id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ürün fiyatının korumalı olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Korumalı.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Korumasız.&lt;br&gt;&lt;/div&gt;
   * @return isPriceProtected
  **/
  @JsonProperty("isPriceProtected")
  public String getIsPriceProtected() {
    if (isPriceProtected == null) {
      return null;
    }
    return isPriceProtected.value();
  }

  public void setIsPriceProtected(IsPriceProtectedEnum isPriceProtected) {
    this.isPriceProtected = isPriceProtected;
  }

  public ProductProtection isPriceProtected(IsPriceProtectedEnum isPriceProtected) {
    this.isPriceProtected = isPriceProtected;
    return this;
  }

 /**
   * Ürün stoğunun korumalı olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Korumalı.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Korumasız.&lt;br&gt;&lt;/div&gt;
   * @return isStockProtected
  **/
  @JsonProperty("isStockProtected")
  public String getIsStockProtected() {
    if (isStockProtected == null) {
      return null;
    }
    return isStockProtected.value();
  }

  public void setIsStockProtected(IsStockProtectedEnum isStockProtected) {
    this.isStockProtected = isStockProtected;
  }

  public ProductProtection isStockProtected(IsStockProtectedEnum isStockProtected) {
    this.isStockProtected = isStockProtected;
    return this;
  }

 /**
   * Get product
   * @return product
  **/
  @JsonProperty("product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public ProductProtection product(Product product) {
    this.product = product;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductProtection {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    isPriceProtected: ").append(toIndentedString(isPriceProtected)).append("\n");
    sb.append("    isStockProtected: ").append(toIndentedString(isStockProtected)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

