package io.swagger.model;

import io.swagger.model.CartItem;
import io.swagger.model.Member;
import io.swagger.model.ShopCampaigns;
import io.swagger.model.ShopTokens;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Cart  {
  
  @ApiModelProperty(example = "123", value = "Sepet nesnesi kimlik değeri.")
 /**
   * Sepet nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "oibtkn9rspcdbmphf8iceondg1", required = true, value = "Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri.")
 /**
   * Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri.  
  **/
  private String sessionId = null;


@XmlType(name="LockedEnum")
@XmlEnum(String.class)
public enum LockedEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    LockedEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static LockedEnum fromValue(String v) {
        for (LockedEnum b : LockedEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz.")
 /**
   * Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz.  
  **/
  private LockedEnum locked = null;

  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Sepet nesnesinin oluşturulma zamanı.")
 /**
   * Sepet nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;

  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Sepet nesnesinin güncellenme zamanı.")
 /**
   * Sepet nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;

  @ApiModelProperty(value = "Promosyon nesnesi.")
 /**
   * Promosyon nesnesi.  
  **/
  private ShopCampaigns chosenPromotion = null;

  @ApiModelProperty(value = "Üye nesnesi.")
 /**
   * Üye nesnesi.  
  **/
  private Member member = null;

  @ApiModelProperty(value = "Hediye çeki nesnesi.")
 /**
   * Hediye çeki nesnesi.  
  **/
  private ShopTokens chosenToken = null;

  @ApiModelProperty(value = "Sepet kalemi nesnelerini barındıran liste.")
 /**
   * Sepet kalemi nesnelerini barındıran liste.  
  **/
  private List<CartItem> items = null;
 /**
   * Sepet nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Cart id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri.
   * @return sessionId
  **/
  @JsonProperty("sessionId")
  public String getSessionId() {
    return sessionId;
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  public Cart sessionId(String sessionId) {
    this.sessionId = sessionId;
    return this;
  }

 /**
   * Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz.
   * @return locked
  **/
  @JsonProperty("locked")
  public String getLocked() {
    if (locked == null) {
      return null;
    }
    return locked.value();
  }

  public void setLocked(LockedEnum locked) {
    this.locked = locked;
  }

  public Cart locked(LockedEnum locked) {
    this.locked = locked;
    return this;
  }

 /**
   * Sepet nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Sepet nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(Date updatedAt) {
    this.updatedAt = updatedAt;
  }

  public Cart updatedAt(Date updatedAt) {
    this.updatedAt = updatedAt;
    return this;
  }

 /**
   * Promosyon nesnesi.
   * @return chosenPromotion
  **/
  @JsonProperty("chosenPromotion")
  public ShopCampaigns getChosenPromotion() {
    return chosenPromotion;
  }

  public void setChosenPromotion(ShopCampaigns chosenPromotion) {
    this.chosenPromotion = chosenPromotion;
  }

  public Cart chosenPromotion(ShopCampaigns chosenPromotion) {
    this.chosenPromotion = chosenPromotion;
    return this;
  }

 /**
   * Üye nesnesi.
   * @return member
  **/
  @JsonProperty("member")
  public Member getMember() {
    return member;
  }

  public void setMember(Member member) {
    this.member = member;
  }

  public Cart member(Member member) {
    this.member = member;
    return this;
  }

 /**
   * Hediye çeki nesnesi.
   * @return chosenToken
  **/
  @JsonProperty("chosenToken")
  public ShopTokens getChosenToken() {
    return chosenToken;
  }

  public void setChosenToken(ShopTokens chosenToken) {
    this.chosenToken = chosenToken;
  }

  public Cart chosenToken(ShopTokens chosenToken) {
    this.chosenToken = chosenToken;
    return this;
  }

 /**
   * Sepet kalemi nesnelerini barındıran liste.
   * @return items
  **/
  @JsonProperty("items")
  public List<CartItem> getItems() {
    return items;
  }

  public void setItems(List<CartItem> items) {
    this.items = items;
  }

  public Cart items(List<CartItem> items) {
    this.items = items;
    return this;
  }

  public Cart addItemsItem(CartItem itemsItem) {
    this.items.add(itemsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Cart {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    sessionId: ").append(toIndentedString(sessionId)).append("\n");
    sb.append("    locked: ").append(toIndentedString(locked)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    chosenPromotion: ").append(toIndentedString(chosenPromotion)).append("\n");
    sb.append("    member: ").append(toIndentedString(member)).append("\n");
    sb.append("    chosenToken: ").append(toIndentedString(chosenToken)).append("\n");
    sb.append("    items: ").append(toIndentedString(items)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

