package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class MemberGroup  {
  
  @ApiModelProperty(example = "123", value = "Üye Grubu nesnesi kimlik değeri.")
 /**
   * Üye Grubu nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "Üyeler", required = true, value = "Üye Grubu nesnesi için isim değeri.")
 /**
   * Üye Grubu nesnesi için isim değeri.  
  **/
  private String name = null;

  @ApiModelProperty(example = "1", required = true, value = "Üye Grubunun fiyat indisi. Örnek Fiyat 2.")
 /**
   * Üye Grubunun fiyat indisi. Örnek Fiyat 2.  
  **/
  private Integer priceIndex = null;

  @ApiModelProperty(example = "custom", required = true, value = "Üye Grubunun izin verilmiş ödeme kanalları.")
 /**
   * Üye Grubunun izin verilmiş ödeme kanalları.  
  **/
  private String allowedPaymentGateways = null;
 /**
   * Üye Grubu nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public MemberGroup id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Üye Grubu nesnesi için isim değeri.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public MemberGroup name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Üye Grubunun fiyat indisi. Örnek Fiyat 2.
   * minimum: 1
   * maximum: 5
   * @return priceIndex
  **/
  @JsonProperty("priceIndex")
  public Integer getPriceIndex() {
    return priceIndex;
  }

  public void setPriceIndex(Integer priceIndex) {
    this.priceIndex = priceIndex;
  }

  public MemberGroup priceIndex(Integer priceIndex) {
    this.priceIndex = priceIndex;
    return this;
  }

 /**
   * Üye Grubunun izin verilmiş ödeme kanalları.
   * @return allowedPaymentGateways
  **/
  @JsonProperty("allowedPaymentGateways")
  public String getAllowedPaymentGateways() {
    return allowedPaymentGateways;
  }

  public void setAllowedPaymentGateways(String allowedPaymentGateways) {
    this.allowedPaymentGateways = allowedPaymentGateways;
  }

  public MemberGroup allowedPaymentGateways(String allowedPaymentGateways) {
    this.allowedPaymentGateways = allowedPaymentGateways;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MemberGroup {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    priceIndex: ").append(toIndentedString(priceIndex)).append("\n");
    sb.append("    allowedPaymentGateways: ").append(toIndentedString(allowedPaymentGateways)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

