package io.swagger.model;

import io.swagger.model.ShippingProvider;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ShippingProviderSetting  {
  
  @ApiModelProperty(example = "123", value = "Teslimat hizmeti sağlayıcısı ayarı nesnesi kimlik değeri.")
 /**
   * Teslimat hizmeti sağlayıcısı ayarı nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "var-key", required = true, value = "Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken anahtarı.")
 /**
   * Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken anahtarı.  
  **/
  private String varKey = null;

  @ApiModelProperty(example = "var-value", required = true, value = "Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken değeri.")
 /**
   * Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken değeri.  
  **/
  private String varValue = null;

  @ApiModelProperty(value = "Teslimat hizmeti sağlayıcısı nesnesi.")
 /**
   * Teslimat hizmeti sağlayıcısı nesnesi.  
  **/
  private ShippingProvider shippingProvider = null;
 /**
   * Teslimat hizmeti sağlayıcısı ayarı nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ShippingProviderSetting id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken anahtarı.
   * @return varKey
  **/
  @JsonProperty("varKey")
  public String getVarKey() {
    return varKey;
  }

  public void setVarKey(String varKey) {
    this.varKey = varKey;
  }

  public ShippingProviderSetting varKey(String varKey) {
    this.varKey = varKey;
    return this;
  }

 /**
   * Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken değeri.
   * @return varValue
  **/
  @JsonProperty("varValue")
  public String getVarValue() {
    return varValue;
  }

  public void setVarValue(String varValue) {
    this.varValue = varValue;
  }

  public ShippingProviderSetting varValue(String varValue) {
    this.varValue = varValue;
    return this;
  }

 /**
   * Teslimat hizmeti sağlayıcısı nesnesi.
   * @return shippingProvider
  **/
  @JsonProperty("shippingProvider")
  public ShippingProvider getShippingProvider() {
    return shippingProvider;
  }

  public void setShippingProvider(ShippingProvider shippingProvider) {
    this.shippingProvider = shippingProvider;
  }

  public ShippingProviderSetting shippingProvider(ShippingProvider shippingProvider) {
    this.shippingProvider = shippingProvider;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShippingProviderSetting {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    varKey: ").append(toIndentedString(varKey)).append("\n");
    sb.append("    varValue: ").append(toIndentedString(varValue)).append("\n");
    sb.append("    shippingProvider: ").append(toIndentedString(shippingProvider)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

