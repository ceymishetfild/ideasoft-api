package io.swagger.model;

import io.swagger.model.Country;
import io.swagger.model.Location;
import io.swagger.model.Member;
import io.swagger.model.MemberGroup;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Member  {
  
  @ApiModelProperty(example = "123", value = "Üye nesnesi kimlik değeri.")
 /**
   * Üye nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "John", required = true, value = "Üyenin ismi.")
 /**
   * Üyenin ismi.  
  **/
  private String firstname = null;
  @ApiModelProperty(example = "Doe", required = true, value = "Üyenin soy ismi.")
 /**
   * Üyenin soy ismi.  
  **/
  private String surname = null;
  @ApiModelProperty(example = "johndoe@ideasoft.com.tr", required = true, value = "Üyenin e-mail adresi.")
 /**
   * Üyenin e-mail adresi.  
  **/
  private String email = null;

@XmlType(name="GenderEnum")
@XmlEnum(String.class)
public enum GenderEnum {

@XmlEnumValue("male") MALE(String.valueOf("male")), @XmlEnumValue("female") FEMALE(String.valueOf("female"));


    private String value;

    GenderEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static GenderEnum fromValue(String v) {
        for (GenderEnum b : GenderEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "male", value = "Üyenin cinsiyet bilgisi.<div class='idea_choice_list'><code>male</code> : Erkek<br><code>female</code> : Kadın<br></div>")
 /**
   * Üyenin cinsiyet bilgisi.<div class='idea_choice_list'><code>male</code> : Erkek<br><code>female</code> : Kadın<br></div>  
  **/
  private GenderEnum gender = null;
  @ApiModelProperty(example = "1988-02-21T00:00:00+0000", value = "Üyenin doğum tarihi.")
 /**
   * Üyenin doğum tarihi.  
  **/
  private Date birthDate = null;
  @ApiModelProperty(example = "+90 (216) 326 04 77", value = "Üyenin telefon numarası.")
 /**
   * Üyenin telefon numarası.  
  **/
  private String phoneNumber = null;
  @ApiModelProperty(example = "+90 (555) 555 55 55", value = "Üyenin mobil telefon numarası.")
 /**
   * Üyenin mobil telefon numarası.  
  **/
  private String mobilePhoneNumber = null;
  @ApiModelProperty(example = "other-location", value = "Üyenin diğer şehir bilgileri.")
 /**
   * Üyenin diğer şehir bilgileri.  
  **/
  private String otherLocation = null;
  @ApiModelProperty(example = "Cumhuriyet Mah. Libadiye Cad. Çimen Sok. No:2", value = "Üyenin adres bilgileri.")
 /**
   * Üyenin adres bilgileri.  
  **/
  private String address = null;
  @ApiModelProperty(example = "1966712049", value = "Üyenin vergi numarası.")
 /**
   * Üyenin vergi numarası.  
  **/
  private String taxNumber = null;
  @ApiModelProperty(example = "11111111111", value = "Üyenin TC kimlik numarası.")
 /**
   * Üyenin TC kimlik numarası.  
  **/
  private String tcId = null;

@XmlType(name="StatusEnum")
@XmlEnum(String.class)
public enum StatusEnum {

@XmlEnumValue("queue") QUEUE(String.valueOf("queue")), @XmlEnumValue("active") ACTIVE(String.valueOf("active")), @XmlEnumValue("passive") PASSIVE(String.valueOf("passive")), @XmlEnumValue("suspended") SUSPENDED(String.valueOf("suspended"));


    private String value;

    StatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "active", required = true, value = "Üyenin durum bilgisi.<div class='idea_choice_list'><code>queue</code> : Sırada<br><code>active</code> : Aktif<br><code>passive</code> : Pasif<br><code>suspended</code> : Askıda<br></div>")
 /**
   * Üyenin durum bilgisi.<div class='idea_choice_list'><code>queue</code> : Sırada<br><code>active</code> : Aktif<br><code>passive</code> : Pasif<br><code>suspended</code> : Askıda<br></div>  
  **/
  private StatusEnum status = null;
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Üyenin son giriş yaptığı tarih.")
 /**
   * Üyenin son giriş yaptığı tarih.  
  **/
  private Date lastLoginDate = null;
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Üye nesnesinin oluşturulma zamanı.")
 /**
   * Üye nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Üye nesnesinin güncellenme zamanı.")
 /**
   * Üye nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;
  @ApiModelProperty(example = "34704", value = "Üyenin posta kodu.")
 /**
   * Üyenin posta kodu.  
  **/
  private String zipCode = null;
  @ApiModelProperty(example = "Ideasoft Yazılım San. ve Tic. A.Ş.", value = "Üyenin kurumsal adı.")
 /**
   * Üyenin kurumsal adı.  
  **/
  private String commercialName = null;
  @ApiModelProperty(example = "Üsküdar", value = "Üyenin vergi dairesi.")
 /**
   * Üyenin vergi dairesi.  
  **/
  private String taxOffice = null;
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Üyeye gönderilen son e-mail tarihi.")
 /**
   * Üyeye gönderilen son e-mail tarihi.  
  **/
  private Date lastMailSentDate = null;
  @ApiModelProperty(example = "192.168.1.1", value = "Üyenin en son giriş yaptığı IP adresi.")
 /**
   * Üyenin en son giriş yaptığı IP adresi.  
  **/
  private String lastIp = null;
  @ApiModelProperty(example = "10500.0", value = "Üyenin kazandığı puan tutarı.")
 /**
   * Üyenin kazandığı puan tutarı.  
  **/
  private Float gainedPointAmount = null;
  @ApiModelProperty(example = "8500.0", value = "Üyenin harcadığı puan tutarı.")
 /**
   * Üyenin harcadığı puan tutarı.  
  **/
  private Float spentPointAmount = null;

@XmlType(name="AllowedToCampaignsEnum")
@XmlEnum(String.class)
public enum AllowedToCampaignsEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    AllowedToCampaignsEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static AllowedToCampaignsEnum fromValue(String v) {
        for (AllowedToCampaignsEnum b : AllowedToCampaignsEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", value = "Üyenin kampanyalara katılım için izin durumu.<div class='idea_choice_list'><code>1</code> : Kampanyalar için izinli.<br><code>0</code> : Kampanyalar için izinsiz.<br></div>")
 /**
   * Üyenin kampanyalara katılım için izin durumu.<div class='idea_choice_list'><code>1</code> : Kampanyalar için izinli.<br><code>0</code> : Kampanyalar için izinsiz.<br></div>  
  **/
  private AllowedToCampaignsEnum allowedToCampaigns = null;
  @ApiModelProperty(example = "5000.0", value = "Üyenin tavsiye ettiği kişilerden dolayı kazandığı puan.")
 /**
   * Üyenin tavsiye ettiği kişilerden dolayı kazandığı puan.  
  **/
  private Float referredMemberGainedPointAmount = null;
  @ApiModelProperty(example = "Üsküdar", value = "Üyenin ilçesi.")
 /**
   * Üyenin ilçesi.  
  **/
  private String district = null;
  @ApiModelProperty(example = "bilgisayar", required = true, value = "Üyenin kullandığı cihaz tipi.")
 /**
   * Üyenin kullandığı cihaz tipi.  
  **/
  private String deviceType = null;
  @ApiModelProperty(example = "deviceInfo", value = "Üyenin kullandığı cihaz bilgisi.")
 /**
   * Üyenin kullandığı cihaz bilgisi.  
  **/
  private String deviceInfo = null;
  @ApiModelProperty(value = "")
  private Country country = null;
  @ApiModelProperty(value = "")
  private Location location = null;
  @ApiModelProperty(value = "")
  private MemberGroup memberGroup = null;
  @ApiModelProperty(value = "")
  private Member referredMember = null;

 /**
   * Üye nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Member id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Üyenin ismi.
   * @return firstname
  **/
  @JsonProperty("firstname")
  public String getFirstname() {
    return firstname;
  }

  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }

  public Member firstname(String firstname) {
    this.firstname = firstname;
    return this;
  }

 /**
   * Üyenin soy ismi.
   * @return surname
  **/
  @JsonProperty("surname")
  public String getSurname() {
    return surname;
  }

  public void setSurname(String surname) {
    this.surname = surname;
  }

  public Member surname(String surname) {
    this.surname = surname;
    return this;
  }

 /**
   * Üyenin e-mail adresi.
   * @return email
  **/
  @JsonProperty("email")
  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public Member email(String email) {
    this.email = email;
    return this;
  }

 /**
   * Üyenin cinsiyet bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın&lt;br&gt;&lt;/div&gt;
   * @return gender
  **/
  @JsonProperty("gender")
  public String getGender() {
    if (gender == null) {
      return null;
    }
    return gender.value();
  }

  public void setGender(GenderEnum gender) {
    this.gender = gender;
  }

  public Member gender(GenderEnum gender) {
    this.gender = gender;
    return this;
  }

 /**
   * Üyenin doğum tarihi.
   * @return birthDate
  **/
  @JsonProperty("birthDate")
  public Date getBirthDate() {
    return birthDate;
  }

  public void setBirthDate(Date birthDate) {
    this.birthDate = birthDate;
  }

  public Member birthDate(Date birthDate) {
    this.birthDate = birthDate;
    return this;
  }

 /**
   * Üyenin telefon numarası.
   * @return phoneNumber
  **/
  @JsonProperty("phoneNumber")
  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public Member phoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
    return this;
  }

 /**
   * Üyenin mobil telefon numarası.
   * @return mobilePhoneNumber
  **/
  @JsonProperty("mobilePhoneNumber")
  public String getMobilePhoneNumber() {
    return mobilePhoneNumber;
  }

  public void setMobilePhoneNumber(String mobilePhoneNumber) {
    this.mobilePhoneNumber = mobilePhoneNumber;
  }

  public Member mobilePhoneNumber(String mobilePhoneNumber) {
    this.mobilePhoneNumber = mobilePhoneNumber;
    return this;
  }

 /**
   * Üyenin diğer şehir bilgileri.
   * @return otherLocation
  **/
  @JsonProperty("otherLocation")
  public String getOtherLocation() {
    return otherLocation;
  }

  public void setOtherLocation(String otherLocation) {
    this.otherLocation = otherLocation;
  }

  public Member otherLocation(String otherLocation) {
    this.otherLocation = otherLocation;
    return this;
  }

 /**
   * Üyenin adres bilgileri.
   * @return address
  **/
  @JsonProperty("address")
  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public Member address(String address) {
    this.address = address;
    return this;
  }

 /**
   * Üyenin vergi numarası.
   * @return taxNumber
  **/
  @JsonProperty("taxNumber")
  public String getTaxNumber() {
    return taxNumber;
  }

  public void setTaxNumber(String taxNumber) {
    this.taxNumber = taxNumber;
  }

  public Member taxNumber(String taxNumber) {
    this.taxNumber = taxNumber;
    return this;
  }

 /**
   * Üyenin TC kimlik numarası.
   * @return tcId
  **/
  @JsonProperty("tcId")
  public String getTcId() {
    return tcId;
  }

  public void setTcId(String tcId) {
    this.tcId = tcId;
  }

  public Member tcId(String tcId) {
    this.tcId = tcId;
    return this;
  }

 /**
   * Üyenin durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;queue&lt;/code&gt; : Sırada&lt;br&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;suspended&lt;/code&gt; : Askıda&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Member status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Üyenin son giriş yaptığı tarih.
   * @return lastLoginDate
  **/
  @JsonProperty("lastLoginDate")
  public Date getLastLoginDate() {
    return lastLoginDate;
  }

  public void setLastLoginDate(Date lastLoginDate) {
    this.lastLoginDate = lastLoginDate;
  }

  public Member lastLoginDate(Date lastLoginDate) {
    this.lastLoginDate = lastLoginDate;
    return this;
  }

 /**
   * Üye nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Üye nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }


 /**
   * Üyenin posta kodu.
   * @return zipCode
  **/
  @JsonProperty("zipCode")
  public String getZipCode() {
    return zipCode;
  }

  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }

  public Member zipCode(String zipCode) {
    this.zipCode = zipCode;
    return this;
  }

 /**
   * Üyenin kurumsal adı.
   * @return commercialName
  **/
  @JsonProperty("commercialName")
  public String getCommercialName() {
    return commercialName;
  }

  public void setCommercialName(String commercialName) {
    this.commercialName = commercialName;
  }

  public Member commercialName(String commercialName) {
    this.commercialName = commercialName;
    return this;
  }

 /**
   * Üyenin vergi dairesi.
   * @return taxOffice
  **/
  @JsonProperty("taxOffice")
  public String getTaxOffice() {
    return taxOffice;
  }

  public void setTaxOffice(String taxOffice) {
    this.taxOffice = taxOffice;
  }

  public Member taxOffice(String taxOffice) {
    this.taxOffice = taxOffice;
    return this;
  }

 /**
   * Üyeye gönderilen son e-mail tarihi.
   * @return lastMailSentDate
  **/
  @JsonProperty("lastMailSentDate")
  public Date getLastMailSentDate() {
    return lastMailSentDate;
  }

  public void setLastMailSentDate(Date lastMailSentDate) {
    this.lastMailSentDate = lastMailSentDate;
  }

  public Member lastMailSentDate(Date lastMailSentDate) {
    this.lastMailSentDate = lastMailSentDate;
    return this;
  }

 /**
   * Üyenin en son giriş yaptığı IP adresi.
   * @return lastIp
  **/
  @JsonProperty("lastIp")
  public String getLastIp() {
    return lastIp;
  }

  public void setLastIp(String lastIp) {
    this.lastIp = lastIp;
  }

  public Member lastIp(String lastIp) {
    this.lastIp = lastIp;
    return this;
  }

 /**
   * Üyenin kazandığı puan tutarı.
   * minimum: 0
   * @return gainedPointAmount
  **/
  @JsonProperty("gainedPointAmount")
  public Float getGainedPointAmount() {
    return gainedPointAmount;
  }

  public void setGainedPointAmount(Float gainedPointAmount) {
    this.gainedPointAmount = gainedPointAmount;
  }

  public Member gainedPointAmount(Float gainedPointAmount) {
    this.gainedPointAmount = gainedPointAmount;
    return this;
  }

 /**
   * Üyenin harcadığı puan tutarı.
   * minimum: 0
   * @return spentPointAmount
  **/
  @JsonProperty("spentPointAmount")
  public Float getSpentPointAmount() {
    return spentPointAmount;
  }

  public void setSpentPointAmount(Float spentPointAmount) {
    this.spentPointAmount = spentPointAmount;
  }

  public Member spentPointAmount(Float spentPointAmount) {
    this.spentPointAmount = spentPointAmount;
    return this;
  }

 /**
   * Üyenin kampanyalara katılım için izin durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalar için izinli.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalar için izinsiz.&lt;br&gt;&lt;/div&gt;
   * @return allowedToCampaigns
  **/
  @JsonProperty("allowedToCampaigns")
  public String getAllowedToCampaigns() {
    if (allowedToCampaigns == null) {
      return null;
    }
    return allowedToCampaigns.value();
  }

  public void setAllowedToCampaigns(AllowedToCampaignsEnum allowedToCampaigns) {
    this.allowedToCampaigns = allowedToCampaigns;
  }

  public Member allowedToCampaigns(AllowedToCampaignsEnum allowedToCampaigns) {
    this.allowedToCampaigns = allowedToCampaigns;
    return this;
  }

 /**
   * Üyenin tavsiye ettiği kişilerden dolayı kazandığı puan.
   * minimum: 0
   * @return referredMemberGainedPointAmount
  **/
  @JsonProperty("referredMemberGainedPointAmount")
  public Float getReferredMemberGainedPointAmount() {
    return referredMemberGainedPointAmount;
  }

  public void setReferredMemberGainedPointAmount(Float referredMemberGainedPointAmount) {
    this.referredMemberGainedPointAmount = referredMemberGainedPointAmount;
  }

  public Member referredMemberGainedPointAmount(Float referredMemberGainedPointAmount) {
    this.referredMemberGainedPointAmount = referredMemberGainedPointAmount;
    return this;
  }

 /**
   * Üyenin ilçesi.
   * @return district
  **/
  @JsonProperty("district")
  public String getDistrict() {
    return district;
  }

  public void setDistrict(String district) {
    this.district = district;
  }

  public Member district(String district) {
    this.district = district;
    return this;
  }

 /**
   * Üyenin kullandığı cihaz tipi.
   * @return deviceType
  **/
  @JsonProperty("deviceType")
  public String getDeviceType() {
    return deviceType;
  }

  public void setDeviceType(String deviceType) {
    this.deviceType = deviceType;
  }

  public Member deviceType(String deviceType) {
    this.deviceType = deviceType;
    return this;
  }

 /**
   * Üyenin kullandığı cihaz bilgisi.
   * @return deviceInfo
  **/
  @JsonProperty("deviceInfo")
  public String getDeviceInfo() {
    return deviceInfo;
  }

  public void setDeviceInfo(String deviceInfo) {
    this.deviceInfo = deviceInfo;
  }

  public Member deviceInfo(String deviceInfo) {
    this.deviceInfo = deviceInfo;
    return this;
  }

 /**
   * Get country
   * @return country
  **/
  @JsonProperty("country")
  public Country getCountry() {
    return country;
  }

  public void setCountry(Country country) {
    this.country = country;
  }

  public Member country(Country country) {
    this.country = country;
    return this;
  }

 /**
   * Get location
   * @return location
  **/
  @JsonProperty("location")
  public Location getLocation() {
    return location;
  }

  public void setLocation(Location location) {
    this.location = location;
  }

  public Member location(Location location) {
    this.location = location;
    return this;
  }

 /**
   * Get memberGroup
   * @return memberGroup
  **/
  @JsonProperty("memberGroup")
  public MemberGroup getMemberGroup() {
    return memberGroup;
  }

  public void setMemberGroup(MemberGroup memberGroup) {
    this.memberGroup = memberGroup;
  }

  public Member memberGroup(MemberGroup memberGroup) {
    this.memberGroup = memberGroup;
    return this;
  }

 /**
   * Get referredMember
   * @return referredMember
  **/
  @JsonProperty("referredMember")
  public Member getReferredMember() {
    return referredMember;
  }

  public void setReferredMember(Member referredMember) {
    this.referredMember = referredMember;
  }

  public Member referredMember(Member referredMember) {
    this.referredMember = referredMember;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Member {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    firstname: ").append(toIndentedString(firstname)).append("\n");
    sb.append("    surname: ").append(toIndentedString(surname)).append("\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    gender: ").append(toIndentedString(gender)).append("\n");
    sb.append("    birthDate: ").append(toIndentedString(birthDate)).append("\n");
    sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
    sb.append("    mobilePhoneNumber: ").append(toIndentedString(mobilePhoneNumber)).append("\n");
    sb.append("    otherLocation: ").append(toIndentedString(otherLocation)).append("\n");
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    taxNumber: ").append(toIndentedString(taxNumber)).append("\n");
    sb.append("    tcId: ").append(toIndentedString(tcId)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    lastLoginDate: ").append(toIndentedString(lastLoginDate)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    zipCode: ").append(toIndentedString(zipCode)).append("\n");
    sb.append("    commercialName: ").append(toIndentedString(commercialName)).append("\n");
    sb.append("    taxOffice: ").append(toIndentedString(taxOffice)).append("\n");
    sb.append("    lastMailSentDate: ").append(toIndentedString(lastMailSentDate)).append("\n");
    sb.append("    lastIp: ").append(toIndentedString(lastIp)).append("\n");
    sb.append("    gainedPointAmount: ").append(toIndentedString(gainedPointAmount)).append("\n");
    sb.append("    spentPointAmount: ").append(toIndentedString(spentPointAmount)).append("\n");
    sb.append("    allowedToCampaigns: ").append(toIndentedString(allowedToCampaigns)).append("\n");
    sb.append("    referredMemberGainedPointAmount: ").append(toIndentedString(referredMemberGainedPointAmount)).append("\n");
    sb.append("    district: ").append(toIndentedString(district)).append("\n");
    sb.append("    deviceType: ").append(toIndentedString(deviceType)).append("\n");
    sb.append("    deviceInfo: ").append(toIndentedString(deviceInfo)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("    location: ").append(toIndentedString(location)).append("\n");
    sb.append("    memberGroup: ").append(toIndentedString(memberGroup)).append("\n");
    sb.append("    referredMember: ").append(toIndentedString(referredMember)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

