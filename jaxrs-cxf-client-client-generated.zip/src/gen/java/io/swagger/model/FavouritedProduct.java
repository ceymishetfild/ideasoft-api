package io.swagger.model;

import io.swagger.model.Member;
import io.swagger.model.Product;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class FavouritedProduct  {
  
  @ApiModelProperty(example = "123", value = "Favori ürün nesnesi kimlik değeri.")
 /**
   * Favori ürün nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(required = true, value = "Üye nesnesi.")
 /**
   * Üye nesnesi.  
  **/
  private Member member = null;

  @ApiModelProperty(required = true, value = "Ürün nesnesi.")
 /**
   * Ürün nesnesi.  
  **/
  private Product product = null;
 /**
   * Favori ürün nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public FavouritedProduct id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Üye nesnesi.
   * @return member
  **/
  @JsonProperty("member")
  public Member getMember() {
    return member;
  }

  public void setMember(Member member) {
    this.member = member;
  }

  public FavouritedProduct member(Member member) {
    this.member = member;
    return this;
  }

 /**
   * Ürün nesnesi.
   * @return product
  **/
  @JsonProperty("product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public FavouritedProduct product(Product product) {
    this.product = product;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FavouritedProduct {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    member: ").append(toIndentedString(member)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

