package io.swagger.model;

import io.swagger.model.Cart;
import io.swagger.model.CartItemAttribute;
import io.swagger.model.Product;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CartItem  {
  
  @ApiModelProperty(example = "123", value = "Sepet kalemi nesnesi kimlik değeri.")
 /**
   * Sepet kalemi nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "123", value = "Ana ürünün benzersiz rakamsal kimlik değeri.")
 /**
   * Ana ürünün benzersiz rakamsal kimlik değeri.  
  **/
  private Integer parentProductId = null;

  @ApiModelProperty(example = "15.0", required = true, value = "Sepetteki kalem adedi.")
 /**
   * Sepetteki kalem adedi.  
  **/
  private Float quantity = null;

  @ApiModelProperty(example = "123", value = "Sepetteki kaleme ait kategorinin benzersiz kimlik değeri.")
 /**
   * Sepetteki kaleme ait kategorinin benzersiz kimlik değeri.  
  **/
  private Integer categoryId = null;

  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Sepet kalemi nesnesinin oluşturulma zamanı.")
 /**
   * Sepet kalemi nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;

  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Sepet kalemi nesnesinin güncellenme zamanı.")
 /**
   * Sepet kalemi nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;

  @ApiModelProperty(required = true, value = "Sepet nesnesi.")
 /**
   * Sepet nesnesi.  
  **/
  private Cart cart = null;

  @ApiModelProperty(required = true, value = "Ürün nesnesi.")
 /**
   * Ürün nesnesi.  
  **/
  private Product product = null;

  @ApiModelProperty(value = "Sepet kalemi özelliği barındıran liste.")
 /**
   * Sepet kalemi özelliği barındıran liste.  
  **/
  private List<CartItemAttribute> attributes = null;
 /**
   * Sepet kalemi nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public CartItem id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ana ürünün benzersiz rakamsal kimlik değeri.
   * minimum: 0
   * @return parentProductId
  **/
  @JsonProperty("parentProductId")
  public Integer getParentProductId() {
    return parentProductId;
  }


 /**
   * Sepetteki kalem adedi.
   * minimum: 0
   * @return quantity
  **/
  @JsonProperty("quantity")
  public Float getQuantity() {
    return quantity;
  }

  public void setQuantity(Float quantity) {
    this.quantity = quantity;
  }

  public CartItem quantity(Float quantity) {
    this.quantity = quantity;
    return this;
  }

 /**
   * Sepetteki kaleme ait kategorinin benzersiz kimlik değeri.
   * minimum: 0
   * @return categoryId
  **/
  @JsonProperty("categoryId")
  public Integer getCategoryId() {
    return categoryId;
  }


 /**
   * Sepet kalemi nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Sepet kalemi nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }


 /**
   * Sepet nesnesi.
   * @return cart
  **/
  @JsonProperty("cart")
  public Cart getCart() {
    return cart;
  }

  public void setCart(Cart cart) {
    this.cart = cart;
  }

  public CartItem cart(Cart cart) {
    this.cart = cart;
    return this;
  }

 /**
   * Ürün nesnesi.
   * @return product
  **/
  @JsonProperty("product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public CartItem product(Product product) {
    this.product = product;
    return this;
  }

 /**
   * Sepet kalemi özelliği barındıran liste.
   * @return attributes
  **/
  @JsonProperty("attributes")
  public List<CartItemAttribute> getAttributes() {
    return attributes;
  }

  public void setAttributes(List<CartItemAttribute> attributes) {
    this.attributes = attributes;
  }

  public CartItem attributes(List<CartItemAttribute> attributes) {
    this.attributes = attributes;
    return this;
  }

  public CartItem addAttributesItem(CartItemAttribute attributesItem) {
    this.attributes.add(attributesItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CartItem {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    parentProductId: ").append(toIndentedString(parentProductId)).append("\n");
    sb.append("    quantity: ").append(toIndentedString(quantity)).append("\n");
    sb.append("    categoryId: ").append(toIndentedString(categoryId)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    cart: ").append(toIndentedString(cart)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("    attributes: ").append(toIndentedString(attributes)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

