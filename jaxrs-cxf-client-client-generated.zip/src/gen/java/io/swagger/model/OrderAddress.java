package io.swagger.model;

import io.swagger.model.Order;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderAddress  {
  
  @ApiModelProperty(example = "123", value = "Sipariş adresi nesnesi kimlik değeri.")
 /**
   * Sipariş adresi nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "John", required = true, value = "Müşterinin ismi.")
 /**
   * Müşterinin ismi.  
  **/
  private String firstname = null;

  @ApiModelProperty(example = "Doe", required = true, value = "Müşterinin soy ismi.")
 /**
   * Müşterinin soy ismi.  
  **/
  private String surname = null;

  @ApiModelProperty(example = "Türkiye", required = true, value = "Müşterinin ülke bilgisi.")
 /**
   * Müşterinin ülke bilgisi.  
  **/
  private String country = null;

  @ApiModelProperty(example = "İstanbul", required = true, value = "Müşterinin şehir bilgisi.")
 /**
   * Müşterinin şehir bilgisi.  
  **/
  private String location = null;

  @ApiModelProperty(example = "Üsküdar", value = "Müşterinin ilçe bilgisi.")
 /**
   * Müşterinin ilçe bilgisi.  
  **/
  private String subLocation = null;

  @ApiModelProperty(example = "Cumhuriyet Mah. Libadiye Cad. Çimen Sok. No:2", required = true, value = "Müşterinin adres bilgisi.")
 /**
   * Müşterinin adres bilgisi.  
  **/
  private String address = null;

  @ApiModelProperty(example = "+90 (216) 326 04 77", required = true, value = "Müşterinin telefon numarası.")
 /**
   * Müşterinin telefon numarası.  
  **/
  private String phoneNumber = null;

  @ApiModelProperty(example = "+90 (555) 555 55 55", value = "Müşterinin mobil telefon numarası.")
 /**
   * Müşterinin mobil telefon numarası.  
  **/
  private String mobilePhoneNumber = null;

  @ApiModelProperty(value = "Sipariş nesnesi.")
 /**
   * Sipariş nesnesi.  
  **/
  private Order order = null;
 /**
   * Sipariş adresi nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OrderAddress id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Müşterinin ismi.
   * @return firstname
  **/
  @JsonProperty("firstname")
  public String getFirstname() {
    return firstname;
  }

  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }

  public OrderAddress firstname(String firstname) {
    this.firstname = firstname;
    return this;
  }

 /**
   * Müşterinin soy ismi.
   * @return surname
  **/
  @JsonProperty("surname")
  public String getSurname() {
    return surname;
  }

  public void setSurname(String surname) {
    this.surname = surname;
  }

  public OrderAddress surname(String surname) {
    this.surname = surname;
    return this;
  }

 /**
   * Müşterinin ülke bilgisi.
   * @return country
  **/
  @JsonProperty("country")
  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public OrderAddress country(String country) {
    this.country = country;
    return this;
  }

 /**
   * Müşterinin şehir bilgisi.
   * @return location
  **/
  @JsonProperty("location")
  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public OrderAddress location(String location) {
    this.location = location;
    return this;
  }

 /**
   * Müşterinin ilçe bilgisi.
   * @return subLocation
  **/
  @JsonProperty("subLocation")
  public String getSubLocation() {
    return subLocation;
  }

  public void setSubLocation(String subLocation) {
    this.subLocation = subLocation;
  }

  public OrderAddress subLocation(String subLocation) {
    this.subLocation = subLocation;
    return this;
  }

 /**
   * Müşterinin adres bilgisi.
   * @return address
  **/
  @JsonProperty("address")
  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public OrderAddress address(String address) {
    this.address = address;
    return this;
  }

 /**
   * Müşterinin telefon numarası.
   * @return phoneNumber
  **/
  @JsonProperty("phoneNumber")
  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public OrderAddress phoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
    return this;
  }

 /**
   * Müşterinin mobil telefon numarası.
   * @return mobilePhoneNumber
  **/
  @JsonProperty("mobilePhoneNumber")
  public String getMobilePhoneNumber() {
    return mobilePhoneNumber;
  }

  public void setMobilePhoneNumber(String mobilePhoneNumber) {
    this.mobilePhoneNumber = mobilePhoneNumber;
  }

  public OrderAddress mobilePhoneNumber(String mobilePhoneNumber) {
    this.mobilePhoneNumber = mobilePhoneNumber;
    return this;
  }

 /**
   * Sipariş nesnesi.
   * @return order
  **/
  @JsonProperty("order")
  public Order getOrder() {
    return order;
  }

  public void setOrder(Order order) {
    this.order = order;
  }

  public OrderAddress order(Order order) {
    this.order = order;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderAddress {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    firstname: ").append(toIndentedString(firstname)).append("\n");
    sb.append("    surname: ").append(toIndentedString(surname)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("    location: ").append(toIndentedString(location)).append("\n");
    sb.append("    subLocation: ").append(toIndentedString(subLocation)).append("\n");
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
    sb.append("    mobilePhoneNumber: ").append(toIndentedString(mobilePhoneNumber)).append("\n");
    sb.append("    order: ").append(toIndentedString(order)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

