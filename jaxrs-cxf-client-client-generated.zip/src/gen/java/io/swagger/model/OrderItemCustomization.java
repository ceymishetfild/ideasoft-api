package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderItemCustomization  {
  
  @ApiModelProperty(example = "123", value = "Sipariş kalemi özelleştirme kimlik değeri.")
 /**
   * Sipariş kalemi özelleştirme kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "123", value = "Ürün özelleştirme grubu nesnesi kimlik değeri.")
 /**
   * Ürün özelleştirme grubu nesnesi kimlik değeri.  
  **/
  private Integer productCustomizationGroupId = null;

  @ApiModelProperty(example = "productCustomizationGroupName", value = "Ürün özelleştirme grubu nesnesinin grup adı.")
 /**
   * Ürün özelleştirme grubu nesnesinin grup adı.  
  **/
  private String productCustomizationGroupName = null;

  @ApiModelProperty(example = "999", value = "Ürün özelleştirme grubu nesnesinin sıralaması.")
 /**
   * Ürün özelleştirme grubu nesnesinin sıralaması.  
  **/
  private Integer productCustomizationGroupSortOrder = null;

  @ApiModelProperty(example = "123", value = "Ürün özelleştirme nesnesi kimlik değeri..")
 /**
   * Ürün özelleştirme nesnesi kimlik değeri..  
  **/
  private Integer productCustomizationFieldId = null;

  @ApiModelProperty(example = "Kısa Bilgi Alanı", value = "Ürün özelleştirme nesnesinin alan tipi.")
 /**
   * Ürün özelleştirme nesnesinin alan tipi.  
  **/
  private String productCustomizationFieldType = null;

  @ApiModelProperty(example = "productCustomizationFieldName", value = "Ürün özelleştirme nesnesinin alan adı.")
 /**
   * Ürün özelleştirme nesnesinin alan adı.  
  **/
  private String productCustomizationFieldName = null;

  @ApiModelProperty(example = "productCustomizationFieldValue", value = "Ürün özelleştirme nesnesinin değeri.")
 /**
   * Ürün özelleştirme nesnesinin değeri.  
  **/
  private String productCustomizationFieldValue = null;

  @ApiModelProperty(example = "123", value = "Sepet kalemi özelliği nesnesi kimlik değeri.")
 /**
   * Sepet kalemi özelliği nesnesi kimlik değeri.  
  **/
  private Integer cartItemAttributeId = null;
 /**
   * Sipariş kalemi özelleştirme kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OrderItemCustomization id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ürün özelleştirme grubu nesnesi kimlik değeri.
   * @return productCustomizationGroupId
  **/
  @JsonProperty("productCustomizationGroupId")
  public Integer getProductCustomizationGroupId() {
    return productCustomizationGroupId;
  }

  public void setProductCustomizationGroupId(Integer productCustomizationGroupId) {
    this.productCustomizationGroupId = productCustomizationGroupId;
  }

  public OrderItemCustomization productCustomizationGroupId(Integer productCustomizationGroupId) {
    this.productCustomizationGroupId = productCustomizationGroupId;
    return this;
  }

 /**
   * Ürün özelleştirme grubu nesnesinin grup adı.
   * @return productCustomizationGroupName
  **/
  @JsonProperty("productCustomizationGroupName")
  public String getProductCustomizationGroupName() {
    return productCustomizationGroupName;
  }

  public void setProductCustomizationGroupName(String productCustomizationGroupName) {
    this.productCustomizationGroupName = productCustomizationGroupName;
  }

  public OrderItemCustomization productCustomizationGroupName(String productCustomizationGroupName) {
    this.productCustomizationGroupName = productCustomizationGroupName;
    return this;
  }

 /**
   * Ürün özelleştirme grubu nesnesinin sıralaması.
   * @return productCustomizationGroupSortOrder
  **/
  @JsonProperty("productCustomizationGroupSortOrder")
  public Integer getProductCustomizationGroupSortOrder() {
    return productCustomizationGroupSortOrder;
  }

  public void setProductCustomizationGroupSortOrder(Integer productCustomizationGroupSortOrder) {
    this.productCustomizationGroupSortOrder = productCustomizationGroupSortOrder;
  }

  public OrderItemCustomization productCustomizationGroupSortOrder(Integer productCustomizationGroupSortOrder) {
    this.productCustomizationGroupSortOrder = productCustomizationGroupSortOrder;
    return this;
  }

 /**
   * Ürün özelleştirme nesnesi kimlik değeri..
   * @return productCustomizationFieldId
  **/
  @JsonProperty("productCustomizationFieldId")
  public Integer getProductCustomizationFieldId() {
    return productCustomizationFieldId;
  }

  public void setProductCustomizationFieldId(Integer productCustomizationFieldId) {
    this.productCustomizationFieldId = productCustomizationFieldId;
  }

  public OrderItemCustomization productCustomizationFieldId(Integer productCustomizationFieldId) {
    this.productCustomizationFieldId = productCustomizationFieldId;
    return this;
  }

 /**
   * Ürün özelleştirme nesnesinin alan tipi.
   * @return productCustomizationFieldType
  **/
  @JsonProperty("productCustomizationFieldType")
  public String getProductCustomizationFieldType() {
    return productCustomizationFieldType;
  }

  public void setProductCustomizationFieldType(String productCustomizationFieldType) {
    this.productCustomizationFieldType = productCustomizationFieldType;
  }

  public OrderItemCustomization productCustomizationFieldType(String productCustomizationFieldType) {
    this.productCustomizationFieldType = productCustomizationFieldType;
    return this;
  }

 /**
   * Ürün özelleştirme nesnesinin alan adı.
   * @return productCustomizationFieldName
  **/
  @JsonProperty("productCustomizationFieldName")
  public String getProductCustomizationFieldName() {
    return productCustomizationFieldName;
  }

  public void setProductCustomizationFieldName(String productCustomizationFieldName) {
    this.productCustomizationFieldName = productCustomizationFieldName;
  }

  public OrderItemCustomization productCustomizationFieldName(String productCustomizationFieldName) {
    this.productCustomizationFieldName = productCustomizationFieldName;
    return this;
  }

 /**
   * Ürün özelleştirme nesnesinin değeri.
   * @return productCustomizationFieldValue
  **/
  @JsonProperty("productCustomizationFieldValue")
  public String getProductCustomizationFieldValue() {
    return productCustomizationFieldValue;
  }

  public void setProductCustomizationFieldValue(String productCustomizationFieldValue) {
    this.productCustomizationFieldValue = productCustomizationFieldValue;
  }

  public OrderItemCustomization productCustomizationFieldValue(String productCustomizationFieldValue) {
    this.productCustomizationFieldValue = productCustomizationFieldValue;
    return this;
  }

 /**
   * Sepet kalemi özelliği nesnesi kimlik değeri.
   * @return cartItemAttributeId
  **/
  @JsonProperty("cartItemAttributeId")
  public Integer getCartItemAttributeId() {
    return cartItemAttributeId;
  }

  public void setCartItemAttributeId(Integer cartItemAttributeId) {
    this.cartItemAttributeId = cartItemAttributeId;
  }

  public OrderItemCustomization cartItemAttributeId(Integer cartItemAttributeId) {
    this.cartItemAttributeId = cartItemAttributeId;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderItemCustomization {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    productCustomizationGroupId: ").append(toIndentedString(productCustomizationGroupId)).append("\n");
    sb.append("    productCustomizationGroupName: ").append(toIndentedString(productCustomizationGroupName)).append("\n");
    sb.append("    productCustomizationGroupSortOrder: ").append(toIndentedString(productCustomizationGroupSortOrder)).append("\n");
    sb.append("    productCustomizationFieldId: ").append(toIndentedString(productCustomizationFieldId)).append("\n");
    sb.append("    productCustomizationFieldType: ").append(toIndentedString(productCustomizationFieldType)).append("\n");
    sb.append("    productCustomizationFieldName: ").append(toIndentedString(productCustomizationFieldName)).append("\n");
    sb.append("    productCustomizationFieldValue: ").append(toIndentedString(productCustomizationFieldValue)).append("\n");
    sb.append("    cartItemAttributeId: ").append(toIndentedString(cartItemAttributeId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

