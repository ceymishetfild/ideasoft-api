package io.swagger.model;

import io.swagger.model.PaymentProviderSetting;
import io.swagger.model.PaymentType;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PaymentProvider  {
  
  @ApiModelProperty(example = "123", value = "Ödeme altyapısı sağlayıcısı nesnesi kimlik değeri.")
 /**
   * Ödeme altyapısı sağlayıcısı nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "MoneyOrder", required = true, value = "Ödeme altyapısı sağlayıcısı için ön tanımlanmış kod değeri.")
 /**
   * Ödeme altyapısı sağlayıcısı için ön tanımlanmış kod değeri.  
  **/
  private String code = null;

  @ApiModelProperty(example = "Havale", required = true, value = "Ödeme altyapısı sağlayıcısı için isim değeri.")
 /**
   * Ödeme altyapısı sağlayıcısı için isim değeri.  
  **/
  private String name = null;


@XmlType(name="StatusEnum")
@XmlEnum(String.class)
public enum StatusEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    StatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", required = true, value = "Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer.")
 /**
   * Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer.  
  **/
  private StatusEnum status = null;

  @ApiModelProperty(required = true, value = "Ödeme tipi nesnesi.")
 /**
   * Ödeme tipi nesnesi.  
  **/
  private PaymentType paymentType = null;

  @ApiModelProperty(value = "Ödeme altyapısı sağlayıcısı ayarları")
 /**
   * Ödeme altyapısı sağlayıcısı ayarları  
  **/
  private List<PaymentProviderSetting> settings = null;
 /**
   * Ödeme altyapısı sağlayıcısı nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public PaymentProvider id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ödeme altyapısı sağlayıcısı için ön tanımlanmış kod değeri.
   * @return code
  **/
  @JsonProperty("code")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public PaymentProvider code(String code) {
    this.code = code;
    return this;
  }

 /**
   * Ödeme altyapısı sağlayıcısı için isim değeri.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public PaymentProvider name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer.
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public PaymentProvider status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Ödeme tipi nesnesi.
   * @return paymentType
  **/
  @JsonProperty("paymentType")
  public PaymentType getPaymentType() {
    return paymentType;
  }

  public void setPaymentType(PaymentType paymentType) {
    this.paymentType = paymentType;
  }

  public PaymentProvider paymentType(PaymentType paymentType) {
    this.paymentType = paymentType;
    return this;
  }

 /**
   * Ödeme altyapısı sağlayıcısı ayarları
   * @return settings
  **/
  @JsonProperty("settings")
  public List<PaymentProviderSetting> getSettings() {
    return settings;
  }

  public void setSettings(List<PaymentProviderSetting> settings) {
    this.settings = settings;
  }

  public PaymentProvider settings(List<PaymentProviderSetting> settings) {
    this.settings = settings;
    return this;
  }

  public PaymentProvider addSettingsItem(PaymentProviderSetting settingsItem) {
    this.settings.add(settingsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PaymentProvider {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    paymentType: ").append(toIndentedString(paymentType)).append("\n");
    sb.append("    settings: ").append(toIndentedString(settings)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

