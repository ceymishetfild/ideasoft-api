package io.swagger.model;

import io.swagger.model.Category;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Category  {
  
  @ApiModelProperty(example = "123", value = "Kategori nesnesi kimlik değeri.")
 /**
   * Kategori nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "Kırtasiye", required = true, value = "Kategori nesnesi için isim değeri.")
 /**
   * Kategori nesnesi için isim değeri.  
  **/
  private String name = null;
  @ApiModelProperty(example = "kirtasiye", value = "Slug değeri ilgili nesnenin Url değeridir.")
 /**
   * Slug değeri ilgili nesnenin Url değeridir.  
  **/
  private String slug = null;
  @ApiModelProperty(example = "999", value = "Kategori nesnesi için sıralama değeri.")
 /**
   * Kategori nesnesi için sıralama değeri.  
  **/
  private Integer sortOrder = null;

@XmlType(name="StatusEnum")
@XmlEnum(String.class)
public enum StatusEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    StatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", required = true, value = "Kategori nesnesinin aktiflik durumunu belirten değer.")
 /**
   * Kategori nesnesinin aktiflik durumunu belirten değer.  
  **/
  private StatusEnum status = null;
  @ApiModelProperty(example = "1.0", value = "Kategori nesnesinin fiyat katsayısı.")
 /**
   * Kategori nesnesinin fiyat katsayısı.  
  **/
  private Float percent = null;
  @ApiModelProperty(example = "kalem.jpg", value = "Kategori nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF")
 /**
   * Kategori nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF  
  **/
  private String imageFile = null;
  @ApiModelProperty(example = "", value = "Her zaman null değer alır. Pratikte kullanımı yoktur.")
 /**
   * Her zaman null değer alır. Pratikte kullanımı yoktur.  
  **/
  private String distributor = null;
  @ApiModelProperty(example = "1", value = "Kategori nesnesinin üst içerik metninin gösterim durumu.")
 /**
   * Kategori nesnesinin üst içerik metninin gösterim durumu.  
  **/
  private Integer displayShowcaseContent = null;
  @ApiModelProperty(example = "Üst içerik metni.", value = "Kategori nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir.")
 /**
   * Kategori nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir.  
  **/
  private String showcaseContent = null;
  @ApiModelProperty(example = "3", required = true, value = "Kategori nesnesinin üst içerik metninin gösterim tipi.<div class='idea_choice_list'><code>1</code> : Kategori içeriği.<br><code>2</code> : Kategori ve üst kategori içeriği.<br><code>3</code> : Kategori ve tüm üst kategoriler.<br></div>")
 /**
   * Kategori nesnesinin üst içerik metninin gösterim tipi.<div class='idea_choice_list'><code>1</code> : Kategori içeriği.<br><code>2</code> : Kategori ve üst kategori içeriği.<br><code>3</code> : Kategori ve tüm üst kategoriler.<br></div>  
  **/
  private Integer showcaseContentDisplayType = null;

@XmlType(name="HasChildrenEnum")
@XmlEnum(String.class)
public enum HasChildrenEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    HasChildrenEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static HasChildrenEnum fromValue(String v) {
        for (HasChildrenEnum b : HasChildrenEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", value = "Kategori nesnesinin alt kategori barındırma durumu. Bu değer otomatik oluşturulur.")
 /**
   * Kategori nesnesinin alt kategori barındırma durumu. Bu değer otomatik oluşturulur.  
  **/
  private HasChildrenEnum hasChildren = null;
  @ApiModelProperty(example = "kırmızı, kalem, kırtasiye", value = "Arama motorları tarafından tespit edilebilecek anahtar kelimeler.")
 /**
   * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.  
  **/
  private String metaKeywords = null;
  @ApiModelProperty(example = "Kaliteli kırtasiye ürünleri.", value = "Arama motorları tarafından tespit edilebilecek açıklama yazısı.")
 /**
   * Arama motorları tarafından tespit edilebilecek açıklama yazısı.  
  **/
  private String metaDescription = null;
  @ApiModelProperty(example = "Kırmızı Kalem", value = "Kategori nesnesinin etiket başlığı.")
 /**
   * Kategori nesnesinin etiket başlığı.  
  **/
  private String pageTitle = null;
  @ApiModelProperty(value = "")
  private Category parent = null;
  @ApiModelProperty(example = "Buraya example gelecek.", value = "Kategori nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.")
 /**
   * Kategori nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.  
  **/
  private String attachment = null;
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Kategori nesnesinin oluşturulma zamanı.")
 /**
   * Kategori nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Kategori nesnesinin güncellenme zamanı.")
 /**
   * Kategori nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;

 /**
   * Kategori nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Category id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Kategori nesnesi için isim değeri.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Category name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Slug değeri ilgili nesnenin Url değeridir.
   * @return slug
  **/
  @JsonProperty("slug")
  public String getSlug() {
    return slug;
  }

  public void setSlug(String slug) {
    this.slug = slug;
  }

  public Category slug(String slug) {
    this.slug = slug;
    return this;
  }

 /**
   * Kategori nesnesi için sıralama değeri.
   * minimum: 0
   * maximum: 999
   * @return sortOrder
  **/
  @JsonProperty("sortOrder")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public Category sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

 /**
   * Kategori nesnesinin aktiflik durumunu belirten değer.
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Category status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Kategori nesnesinin fiyat katsayısı.
   * minimum: 0
   * @return percent
  **/
  @JsonProperty("percent")
  public Float getPercent() {
    return percent;
  }

  public void setPercent(Float percent) {
    this.percent = percent;
  }

  public Category percent(Float percent) {
    this.percent = percent;
    return this;
  }

 /**
   * Kategori nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF
   * @return imageFile
  **/
  @JsonProperty("imageFile")
  public String getImageFile() {
    return imageFile;
  }

  public void setImageFile(String imageFile) {
    this.imageFile = imageFile;
  }

  public Category imageFile(String imageFile) {
    this.imageFile = imageFile;
    return this;
  }

 /**
   * Her zaman null değer alır. Pratikte kullanımı yoktur.
   * @return distributor
  **/
  @JsonProperty("distributor")
  public String getDistributor() {
    return distributor;
  }

  public void setDistributor(String distributor) {
    this.distributor = distributor;
  }

  public Category distributor(String distributor) {
    this.distributor = distributor;
    return this;
  }

 /**
   * Kategori nesnesinin üst içerik metninin gösterim durumu.
   * @return displayShowcaseContent
  **/
  @JsonProperty("displayShowcaseContent")
  public Integer getDisplayShowcaseContent() {
    return displayShowcaseContent;
  }

  public void setDisplayShowcaseContent(Integer displayShowcaseContent) {
    this.displayShowcaseContent = displayShowcaseContent;
  }

  public Category displayShowcaseContent(Integer displayShowcaseContent) {
    this.displayShowcaseContent = displayShowcaseContent;
    return this;
  }

 /**
   * Kategori nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir.
   * @return showcaseContent
  **/
  @JsonProperty("showcaseContent")
  public String getShowcaseContent() {
    return showcaseContent;
  }

  public void setShowcaseContent(String showcaseContent) {
    this.showcaseContent = showcaseContent;
  }

  public Category showcaseContent(String showcaseContent) {
    this.showcaseContent = showcaseContent;
    return this;
  }

 /**
   * Kategori nesnesinin üst içerik metninin gösterim tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kategori içeriği.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Kategori ve üst kategori içeriği.&lt;br&gt;&lt;code&gt;3&lt;/code&gt; : Kategori ve tüm üst kategoriler.&lt;br&gt;&lt;/div&gt;
   * @return showcaseContentDisplayType
  **/
  @JsonProperty("showcaseContentDisplayType")
  public Integer getShowcaseContentDisplayType() {
    return showcaseContentDisplayType;
  }

  public void setShowcaseContentDisplayType(Integer showcaseContentDisplayType) {
    this.showcaseContentDisplayType = showcaseContentDisplayType;
  }

  public Category showcaseContentDisplayType(Integer showcaseContentDisplayType) {
    this.showcaseContentDisplayType = showcaseContentDisplayType;
    return this;
  }

 /**
   * Kategori nesnesinin alt kategori barındırma durumu. Bu değer otomatik oluşturulur.
   * @return hasChildren
  **/
  @JsonProperty("hasChildren")
  public String getHasChildren() {
    if (hasChildren == null) {
      return null;
    }
    return hasChildren.value();
  }


 /**
   * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.
   * @return metaKeywords
  **/
  @JsonProperty("metaKeywords")
  public String getMetaKeywords() {
    return metaKeywords;
  }

  public void setMetaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
  }

  public Category metaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
    return this;
  }

 /**
   * Arama motorları tarafından tespit edilebilecek açıklama yazısı.
   * @return metaDescription
  **/
  @JsonProperty("metaDescription")
  public String getMetaDescription() {
    return metaDescription;
  }

  public void setMetaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
  }

  public Category metaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
    return this;
  }

 /**
   * Kategori nesnesinin etiket başlığı.
   * @return pageTitle
  **/
  @JsonProperty("pageTitle")
  public String getPageTitle() {
    return pageTitle;
  }

  public void setPageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
  }

  public Category pageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
    return this;
  }

 /**
   * Get parent
   * @return parent
  **/
  @JsonProperty("parent")
  public Category getParent() {
    return parent;
  }

  public void setParent(Category parent) {
    this.parent = parent;
  }

  public Category parent(Category parent) {
    this.parent = parent;
    return this;
  }

 /**
   * Kategori nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
   * @return attachment
  **/
  @JsonProperty("attachment")
  public String getAttachment() {
    return attachment;
  }

  public void setAttachment(String attachment) {
    this.attachment = attachment;
  }

  public Category attachment(String attachment) {
    this.attachment = attachment;
    return this;
  }

 /**
   * Kategori nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Kategori nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }



  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Category {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    slug: ").append(toIndentedString(slug)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    percent: ").append(toIndentedString(percent)).append("\n");
    sb.append("    imageFile: ").append(toIndentedString(imageFile)).append("\n");
    sb.append("    distributor: ").append(toIndentedString(distributor)).append("\n");
    sb.append("    displayShowcaseContent: ").append(toIndentedString(displayShowcaseContent)).append("\n");
    sb.append("    showcaseContent: ").append(toIndentedString(showcaseContent)).append("\n");
    sb.append("    showcaseContentDisplayType: ").append(toIndentedString(showcaseContentDisplayType)).append("\n");
    sb.append("    hasChildren: ").append(toIndentedString(hasChildren)).append("\n");
    sb.append("    metaKeywords: ").append(toIndentedString(metaKeywords)).append("\n");
    sb.append("    metaDescription: ").append(toIndentedString(metaDescription)).append("\n");
    sb.append("    pageTitle: ").append(toIndentedString(pageTitle)).append("\n");
    sb.append("    parent: ").append(toIndentedString(parent)).append("\n");
    sb.append("    attachment: ").append(toIndentedString(attachment)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

