package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PaymentProviderSetting  {
  
  @ApiModelProperty(example = "123", value = "Ödeme altyapısı sağlayıcısı ayarı nesnesi kimlik değeri.")
 /**
   * Ödeme altyapısı sağlayıcısı ayarı nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "agentId", required = true, value = "Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken anahtarı.")
 /**
   * Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken anahtarı.  
  **/
  private String varKey = null;

  @ApiModelProperty(example = "PALIKJXZQ", required = true, value = "Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken değeri.")
 /**
   * Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken değeri.  
  **/
  private String varValue = null;
 /**
   * Ödeme altyapısı sağlayıcısı ayarı nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public PaymentProviderSetting id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken anahtarı.
   * @return varKey
  **/
  @JsonProperty("varKey")
  public String getVarKey() {
    return varKey;
  }

  public void setVarKey(String varKey) {
    this.varKey = varKey;
  }

  public PaymentProviderSetting varKey(String varKey) {
    this.varKey = varKey;
    return this;
  }

 /**
   * Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken değeri.
   * @return varValue
  **/
  @JsonProperty("varValue")
  public String getVarValue() {
    return varValue;
  }

  public void setVarValue(String varValue) {
    this.varValue = varValue;
  }

  public PaymentProviderSetting varValue(String varValue) {
    this.varValue = varValue;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PaymentProviderSetting {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    varKey: ").append(toIndentedString(varKey)).append("\n");
    sb.append("    varValue: ").append(toIndentedString(varValue)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

