package io.swagger.model;

import io.swagger.model.Product;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductDetail  {
  
  @ApiModelProperty(example = "123", value = "Ürün detayı nesnesi kimlik değeri.")
 /**
   * Ürün detayı nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "KAL-1234", value = "Ürünün stok kodu.")
 /**
   * Ürünün stok kodu.  
  **/
  private String sku = null;

  @ApiModelProperty(example = "<div><strong><br /><table style=\"border-collapse:collapse;width:100%;\"><tbody><tr><td>&nbsp;Özellik</td><td>Tipi&nbsp;</td></tr><tr><td>&nbsp;Uç tipi</td><td>&nbsp;2B</td></tr></tbody></table></strong></div><br/>", value = "Detay bilgisi.")
 /**
   * Detay bilgisi.  
  **/
  private String details = null;

  @ApiModelProperty(example = "Ekstra detay.", value = "Ürün ekstra detaylı bilgi.")
 /**
   * Ürün ekstra detaylı bilgi.  
  **/
  private String extraDetails = null;

  @ApiModelProperty(required = true, value = "Ürün nesnesi.")
 /**
   * Ürün nesnesi.  
  **/
  private Product product = null;
 /**
   * Ürün detayı nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductDetail id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ürünün stok kodu.
   * @return sku
  **/
  @JsonProperty("sku")
  public String getSku() {
    return sku;
  }

  public void setSku(String sku) {
    this.sku = sku;
  }

  public ProductDetail sku(String sku) {
    this.sku = sku;
    return this;
  }

 /**
   * Detay bilgisi.
   * @return details
  **/
  @JsonProperty("details")
  public String getDetails() {
    return details;
  }

  public void setDetails(String details) {
    this.details = details;
  }

  public ProductDetail details(String details) {
    this.details = details;
    return this;
  }

 /**
   * Ürün ekstra detaylı bilgi.
   * @return extraDetails
  **/
  @JsonProperty("extraDetails")
  public String getExtraDetails() {
    return extraDetails;
  }

  public void setExtraDetails(String extraDetails) {
    this.extraDetails = extraDetails;
  }

  public ProductDetail extraDetails(String extraDetails) {
    this.extraDetails = extraDetails;
    return this;
  }

 /**
   * Ürün nesnesi.
   * @return product
  **/
  @JsonProperty("product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public ProductDetail product(Product product) {
    this.product = product;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductDetail {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    sku: ").append(toIndentedString(sku)).append("\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("    extraDetails: ").append(toIndentedString(extraDetails)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

