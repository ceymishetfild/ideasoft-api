package io.swagger.model;

import io.swagger.model.Product;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductToCountDown  {
  
  @ApiModelProperty(example = "123", value = "Ürün geri sayım bağı nesnesi kimlik değeri.")
 /**
   * Ürün geri sayım bağı nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Geri sayımın başlangıç tarihi.")
 /**
   * Geri sayımın başlangıç tarihi.  
  **/
  private Date startDate = null;

  @ApiModelProperty(example = "2018-02-26T09:36:03+0300", value = "Geri sayımın bitiş tarihi.")
 /**
   * Geri sayımın bitiş tarihi.  
  **/
  private Date endDate = null;

  @ApiModelProperty(example = "2018-02-26T09:36:03+0300", value = "Geri sayımın ürün için geçersiz olma tarihi.")
 /**
   * Geri sayımın ürün için geçersiz olma tarihi.  
  **/
  private Date expireDate = null;


@XmlType(name="UseCountDownEnum")
@XmlEnum(String.class)
public enum UseCountDownEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    UseCountDownEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static UseCountDownEnum fromValue(String v) {
        for (UseCountDownEnum b : UseCountDownEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", required = true, value = "Geri sayımın aktiflik durumu bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
 /**
   * Geri sayımın aktiflik durumu bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>  
  **/
  private UseCountDownEnum useCountDown = null;

  @ApiModelProperty(required = true, value = "Ürün nesnesi.")
 /**
   * Ürün nesnesi.  
  **/
  private Product product = null;
 /**
   * Ürün geri sayım bağı nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductToCountDown id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Geri sayımın başlangıç tarihi.
   * @return startDate
  **/
  @JsonProperty("startDate")
  public Date getStartDate() {
    return startDate;
  }

  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }

  public ProductToCountDown startDate(Date startDate) {
    this.startDate = startDate;
    return this;
  }

 /**
   * Geri sayımın bitiş tarihi.
   * @return endDate
  **/
  @JsonProperty("endDate")
  public Date getEndDate() {
    return endDate;
  }

  public void setEndDate(Date endDate) {
    this.endDate = endDate;
  }

  public ProductToCountDown endDate(Date endDate) {
    this.endDate = endDate;
    return this;
  }

 /**
   * Geri sayımın ürün için geçersiz olma tarihi.
   * @return expireDate
  **/
  @JsonProperty("expireDate")
  public Date getExpireDate() {
    return expireDate;
  }

  public void setExpireDate(Date expireDate) {
    this.expireDate = expireDate;
  }

  public ProductToCountDown expireDate(Date expireDate) {
    this.expireDate = expireDate;
    return this;
  }

 /**
   * Geri sayımın aktiflik durumu bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return useCountDown
  **/
  @JsonProperty("useCountDown")
  public String getUseCountDown() {
    if (useCountDown == null) {
      return null;
    }
    return useCountDown.value();
  }

  public void setUseCountDown(UseCountDownEnum useCountDown) {
    this.useCountDown = useCountDown;
  }

  public ProductToCountDown useCountDown(UseCountDownEnum useCountDown) {
    this.useCountDown = useCountDown;
    return this;
  }

 /**
   * Ürün nesnesi.
   * @return product
  **/
  @JsonProperty("product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public ProductToCountDown product(Product product) {
    this.product = product;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductToCountDown {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("    endDate: ").append(toIndentedString(endDate)).append("\n");
    sb.append("    expireDate: ").append(toIndentedString(expireDate)).append("\n");
    sb.append("    useCountDown: ").append(toIndentedString(useCountDown)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

