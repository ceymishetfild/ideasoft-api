package io.swagger.model;

import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Theme  {
  
  @ApiModelProperty(example = "123", value = "Tema nesnesi kimlik değeri.")
 /**
   * Tema nesnesi kimlik değeri.  
  **/
  private Integer id = null;


@XmlType(name="PlatformEnum")
@XmlEnum(String.class)
public enum PlatformEnum {

@XmlEnumValue("desktop") DESKTOP(String.valueOf("desktop")), @XmlEnumValue("mobile") MOBILE(String.valueOf("mobile"));


    private String value;

    PlatformEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static PlatformEnum fromValue(String v) {
        for (PlatformEnum b : PlatformEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "desktop", required = true, value = "Temanın kullanılacağı platform.<div class='idea_choice_list'><code>desktop</code> : Masaüstü.<br><code>mobile</code> : Mobil.<br></div>")
 /**
   * Temanın kullanılacağı platform.<div class='idea_choice_list'><code>desktop</code> : Masaüstü.<br><code>mobile</code> : Mobil.<br></div>  
  **/
  private PlatformEnum platform = null;


@XmlType(name="TypeEnum")
@XmlEnum(String.class)
public enum TypeEnum {

@XmlEnumValue("self") SELF(String.valueOf("self")), @XmlEnumValue("standard") STANDARD(String.valueOf("standard"));


    private String value;

    TypeEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static TypeEnum fromValue(String v) {
        for (TypeEnum b : TypeEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "standard", value = "Tema tipi.<div class='idea_choice_list'><code>self</code> : Kişisel Tema.<br><code>standard</code> : Standart Tema.<br></div>")
 /**
   * Tema tipi.<div class='idea_choice_list'><code>self</code> : Kişisel Tema.<br><code>standard</code> : Standart Tema.<br></div>  
  **/
  private TypeEnum type = null;

  @ApiModelProperty(example = "Chalcedon", required = true, value = "Tema adı.")
 /**
   * Tema adı.  
  **/
  private String name = null;

  @ApiModelProperty(example = "", value = "Temanın rengi.")
 /**
   * Temanın rengi.  
  **/
  private String preset = null;

  @ApiModelProperty(example = "tpl-chalcedon", value = "Temanın dizini.")
 /**
   * Temanın dizini.  
  **/
  private String directoryName = null;


@XmlType(name="StatusEnum")
@XmlEnum(String.class)
public enum StatusEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    StatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", required = true, value = "Temanın durumu.")
 /**
   * Temanın durumu.  
  **/
  private StatusEnum status = null;

  @ApiModelProperty(example = "0", value = "Temanın revisionı.")
 /**
   * Temanın revisionı.  
  **/
  private Integer revision = null;

  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Tema nesnesinin oluşturulma zamanı.")
 /**
   * Tema nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;

  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Tema nesnesinin güncellenme zamanı.")
 /**
   * Tema nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;

  @ApiModelProperty(value = "")
  private String attachment = null;
 /**
   * Tema nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Theme id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Temanın kullanılacağı platform.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü.&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil.&lt;br&gt;&lt;/div&gt;
   * @return platform
  **/
  @JsonProperty("platform")
  public String getPlatform() {
    if (platform == null) {
      return null;
    }
    return platform.value();
  }

  public void setPlatform(PlatformEnum platform) {
    this.platform = platform;
  }

  public Theme platform(PlatformEnum platform) {
    this.platform = platform;
    return this;
  }

 /**
   * Tema tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;self&lt;/code&gt; : Kişisel Tema.&lt;br&gt;&lt;code&gt;standard&lt;/code&gt; : Standart Tema.&lt;br&gt;&lt;/div&gt;
   * @return type
  **/
  @JsonProperty("type")
  public String getType() {
    if (type == null) {
      return null;
    }
    return type.value();
  }


 /**
   * Tema adı.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Theme name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Temanın rengi.
   * @return preset
  **/
  @JsonProperty("preset")
  public String getPreset() {
    return preset;
  }


 /**
   * Temanın dizini.
   * @return directoryName
  **/
  @JsonProperty("directoryName")
  public String getDirectoryName() {
    return directoryName;
  }


 /**
   * Temanın durumu.
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Theme status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Temanın revisionı.
   * @return revision
  **/
  @JsonProperty("revision")
  public Integer getRevision() {
    return revision;
  }


 /**
   * Tema nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Tema nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }


 /**
   * Get attachment
   * @return attachment
  **/
  @JsonProperty("attachment")
  public String getAttachment() {
    return attachment;
  }

  public void setAttachment(String attachment) {
    this.attachment = attachment;
  }

  public Theme attachment(String attachment) {
    this.attachment = attachment;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Theme {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    platform: ").append(toIndentedString(platform)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    preset: ").append(toIndentedString(preset)).append("\n");
    sb.append("    directoryName: ").append(toIndentedString(directoryName)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    revision: ").append(toIndentedString(revision)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    attachment: ").append(toIndentedString(attachment)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

