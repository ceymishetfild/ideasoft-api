package io.swagger.model;

import io.swagger.model.Member;
import io.swagger.model.Product;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductComment  {
  
  @ApiModelProperty(example = "123", value = "Ürün yorumu nesnesi kimlik değeri.")
 /**
   * Ürün yorumu nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "Çok kaliteli bir ürün.", required = true, value = "Ürün yorumu başlığı.")
 /**
   * Ürün yorumu başlığı.  
  **/
  private String title = null;

  @ApiModelProperty(example = "Ürünü çok beğendim. Tarif edildiği gibi çıktı ve kargo süreci çok hızlıydı.", required = true, value = "Ürün yorumu içeriği.")
 /**
   * Ürün yorumu içeriği.  
  **/
  private String content = null;

  @ApiModelProperty(example = "false", required = true, value = "Ürün yorumu durumu.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
 /**
   * Ürün yorumu durumu.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>  
  **/
  private Boolean status = null;


@XmlType(name="RankEnum")
@XmlEnum(Integer.class)
public enum RankEnum {

@XmlEnumValue("1") NUMBER_1(Integer.valueOf(1)), @XmlEnumValue("2") NUMBER_2(Integer.valueOf(2)), @XmlEnumValue("3") NUMBER_3(Integer.valueOf(3)), @XmlEnumValue("4") NUMBER_4(Integer.valueOf(4)), @XmlEnumValue("5") NUMBER_5(Integer.valueOf(5));


    private Integer value;

    RankEnum (Integer v) {
        value = v;
    }

    public Integer value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static RankEnum fromValue(String v) {
        for (RankEnum b : RankEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "5", required = true, value = "Ürün yorumunda ürüne verilen puan.<div class='idea_choice_list'><code>1</code> : 1 puan.<br><code>2</code> : 2 puan.<br><code>3</code> : 3 puan.<br><code>4</code> : 4 puan.<br><code>5</code> : 5 puan.<br></div>")
 /**
   * Ürün yorumunda ürüne verilen puan.<div class='idea_choice_list'><code>1</code> : 1 puan.<br><code>2</code> : 2 puan.<br><code>3</code> : 3 puan.<br><code>4</code> : 4 puan.<br><code>5</code> : 5 puan.<br></div>  
  **/
  private RankEnum rank = null;

  @ApiModelProperty(example = "false", required = true, value = "Ürün yorumu yapan kişinin anonim olup olmadığı bilgisi.<div class='idea_choice_list'><code>1</code> : Anonim.<br><code>0</code> : Anonim değil.<br></div>")
 /**
   * Ürün yorumu yapan kişinin anonim olup olmadığı bilgisi.<div class='idea_choice_list'><code>1</code> : Anonim.<br><code>0</code> : Anonim değil.<br></div>  
  **/
  private Boolean isAnonymous = null;

  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Ürün yorumu nesnesinin oluşturulma zamanı.")
 /**
   * Ürün yorumu nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;

  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Ürün yorumu nesnesinin güncellenme zamanı.")
 /**
   * Ürün yorumu nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;

  @ApiModelProperty(value = "Yorumu yapan üye.")
 /**
   * Yorumu yapan üye.  
  **/
  private Member member = null;

  @ApiModelProperty(value = "Yorum yapılan ürün.")
 /**
   * Yorum yapılan ürün.  
  **/
  private Product product = null;
 /**
   * Ürün yorumu nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductComment id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ürün yorumu başlığı.
   * @return title
  **/
  @JsonProperty("title")
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public ProductComment title(String title) {
    this.title = title;
    return this;
  }

 /**
   * Ürün yorumu içeriği.
   * @return content
  **/
  @JsonProperty("content")
  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public ProductComment content(String content) {
    this.content = content;
    return this;
  }

 /**
   * Ürün yorumu durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public Boolean isStatus() {
    return status;
  }

  public void setStatus(Boolean status) {
    this.status = status;
  }

  public ProductComment status(Boolean status) {
    this.status = status;
    return this;
  }

 /**
   * Ürün yorumunda ürüne verilen puan.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 1 puan.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : 2 puan.&lt;br&gt;&lt;code&gt;3&lt;/code&gt; : 3 puan.&lt;br&gt;&lt;code&gt;4&lt;/code&gt; : 4 puan.&lt;br&gt;&lt;code&gt;5&lt;/code&gt; : 5 puan.&lt;br&gt;&lt;/div&gt;
   * @return rank
  **/
  @JsonProperty("rank")
  public Integer getRank() {
    if (rank == null) {
      return null;
    }
    return rank.value();
  }

  public void setRank(RankEnum rank) {
    this.rank = rank;
  }

  public ProductComment rank(RankEnum rank) {
    this.rank = rank;
    return this;
  }

 /**
   * Ürün yorumu yapan kişinin anonim olup olmadığı bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Anonim.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Anonim değil.&lt;br&gt;&lt;/div&gt;
   * @return isAnonymous
  **/
  @JsonProperty("isAnonymous")
  public Boolean isIsAnonymous() {
    return isAnonymous;
  }

  public void setIsAnonymous(Boolean isAnonymous) {
    this.isAnonymous = isAnonymous;
  }

  public ProductComment isAnonymous(Boolean isAnonymous) {
    this.isAnonymous = isAnonymous;
    return this;
  }

 /**
   * Ürün yorumu nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Ürün yorumu nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }


 /**
   * Yorumu yapan üye.
   * @return member
  **/
  @JsonProperty("member")
  public Member getMember() {
    return member;
  }

  public void setMember(Member member) {
    this.member = member;
  }

  public ProductComment member(Member member) {
    this.member = member;
    return this;
  }

 /**
   * Yorum yapılan ürün.
   * @return product
  **/
  @JsonProperty("product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public ProductComment product(Product product) {
    this.product = product;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductComment {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    rank: ").append(toIndentedString(rank)).append("\n");
    sb.append("    isAnonymous: ").append(toIndentedString(isAnonymous)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    member: ").append(toIndentedString(member)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

