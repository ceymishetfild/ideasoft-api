package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class OptionGroup  {
  
  @ApiModelProperty(example = "123", value = "Varyant grubu nesnesi kimlik değeri.")
 /**
   * Varyant grubu nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "Renk", required = true, value = "Varyant grubunun başlığı. Varyant değeri kırmızı ise bu değer renk olabilir.")
 /**
   * Varyant grubunun başlığı. Varyant değeri kırmızı ise bu değer renk olabilir.  
  **/
  private String title = null;

  @ApiModelProperty(example = "9999", value = "Varyant grubunun sıralama değeri.")
 /**
   * Varyant grubunun sıralama değeri.  
  **/
  private Integer sortOrder = null;


@XmlType(name="FilterStatusEnum")
@XmlEnum(String.class)
public enum FilterStatusEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    FilterStatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static FilterStatusEnum fromValue(String v) {
        for (FilterStatusEnum b : FilterStatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", value = "Varyant grubunun filtre menüsündeki gösterim durumu.<div class='idea_choice_list'><code>1</code> : Gösterilsin.<br><code>0</code> : Gösterilmesin.<br></div>")
 /**
   * Varyant grubunun filtre menüsündeki gösterim durumu.<div class='idea_choice_list'><code>1</code> : Gösterilsin.<br><code>0</code> : Gösterilmesin.<br></div>  
  **/
  private FilterStatusEnum filterStatus = null;
 /**
   * Varyant grubu nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OptionGroup id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Varyant grubunun başlığı. Varyant değeri kırmızı ise bu değer renk olabilir.
   * @return title
  **/
  @JsonProperty("title")
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public OptionGroup title(String title) {
    this.title = title;
    return this;
  }

 /**
   * Varyant grubunun sıralama değeri.
   * minimum: 0
   * maximum: 9999
   * @return sortOrder
  **/
  @JsonProperty("sortOrder")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public OptionGroup sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

 /**
   * Varyant grubunun filtre menüsündeki gösterim durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Gösterilsin.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Gösterilmesin.&lt;br&gt;&lt;/div&gt;
   * @return filterStatus
  **/
  @JsonProperty("filterStatus")
  public String getFilterStatus() {
    if (filterStatus == null) {
      return null;
    }
    return filterStatus.value();
  }

  public void setFilterStatus(FilterStatusEnum filterStatus) {
    this.filterStatus = filterStatus;
  }

  public OptionGroup filterStatus(FilterStatusEnum filterStatus) {
    this.filterStatus = filterStatus;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OptionGroup {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    filterStatus: ").append(toIndentedString(filterStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

