package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SelectionGroup  {
  
  @ApiModelProperty(example = "123", value = "Ek özellik grubu nesnesi kimlik değeri.")
 /**
   * Ek özellik grubu nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "SelectionGroup", required = true, value = "Ek özellik grubu nesnesinin başlığı.")
 /**
   * Ek özellik grubu nesnesinin başlığı.  
  **/
  private String title = null;
  @ApiModelProperty(example = "999", required = true, value = "Ek özellik grubu nesnesi için sıralama değeri.")
 /**
   * Ek özellik grubu nesnesi için sıralama değeri.  
  **/
  private Integer sortOrder = null;

 /**
   * Ek özellik grubu nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public SelectionGroup id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ek özellik grubu nesnesinin başlığı.
   * @return title
  **/
  @JsonProperty("title")
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public SelectionGroup title(String title) {
    this.title = title;
    return this;
  }

 /**
   * Ek özellik grubu nesnesi için sıralama değeri.
   * @return sortOrder
  **/
  @JsonProperty("sortOrder")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public SelectionGroup sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SelectionGroup {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

