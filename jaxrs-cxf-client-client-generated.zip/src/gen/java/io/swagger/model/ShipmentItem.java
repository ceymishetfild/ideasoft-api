package io.swagger.model;

import io.swagger.model.OrderItem;
import io.swagger.model.Product;
import io.swagger.model.Shipment;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ShipmentItem  {
  
  @ApiModelProperty(example = "123", value = "Teslimat Kalemi nesnesi kimlik değeri.")
 /**
   * Teslimat Kalemi nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "123", value = "Ana ürünün id değeri.")
 /**
   * Ana ürünün id değeri.  
  **/
  private Integer rootProductId = null;
  @ApiModelProperty(example = "2", required = true, value = "Ürünün stok tipi cinsinden miktarı.")
 /**
   * Ürünün stok tipi cinsinden miktarı.  
  **/
  private Integer amount = null;
  @ApiModelProperty(example = "20.0", required = true, value = "Ürünün fiyatı.")
 /**
   * Ürünün fiyatı.  
  **/
  private Float price = null;
  @ApiModelProperty(example = "Kırmızı Kalem", value = "Ürün başlığı.")
 /**
   * Ürün başlığı.  
  **/
  private String productLabel = null;

@XmlType(name="CurrencyEnum")
@XmlEnum(String.class)
public enum CurrencyEnum {

@XmlEnumValue("USD") USD(String.valueOf("USD")), @XmlEnumValue("EUR") EUR(String.valueOf("EUR")), @XmlEnumValue("TL") TL(String.valueOf("TL")), @XmlEnumValue("GBP") GBP(String.valueOf("GBP")), @XmlEnumValue("JPY") JPY(String.valueOf("JPY")), @XmlEnumValue("CNY") CNY(String.valueOf("CNY")), @XmlEnumValue("GR") GR(String.valueOf("GR")), @XmlEnumValue("CHF") CHF(String.valueOf("CHF"));


    private String value;

    CurrencyEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static CurrencyEnum fromValue(String v) {
        for (CurrencyEnum b : CurrencyEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "TL", required = true, value = "Ürünün kur bilgisi.<div class='idea_choice_list'><code>USD</code> : Amerikan Doları<br><code>EUR</code> : Euro<br><code>TL</code> : Türk Lirası<br><code>GBP</code> : İngiliz Sterlini<br><code>JPY</code> : Japon Yeni<br><code>CNY</code> : Çin Yuanı<br><code>GR</code> : Gram Altın<br><code>CHF</code> : İsviçre Frangı<br></div>")
 /**
   * Ürünün kur bilgisi.<div class='idea_choice_list'><code>USD</code> : Amerikan Doları<br><code>EUR</code> : Euro<br><code>TL</code> : Türk Lirası<br><code>GBP</code> : İngiliz Sterlini<br><code>JPY</code> : Japon Yeni<br><code>CNY</code> : Çin Yuanı<br><code>GR</code> : Gram Altın<br><code>CHF</code> : İsviçre Frangı<br></div>  
  **/
  private CurrencyEnum currency = null;
  @ApiModelProperty(example = "18", value = "Ürünün vergi değeri.")
 /**
   * Ürünün vergi değeri.  
  **/
  private Integer tax = null;
  @ApiModelProperty(example = "1.0", required = true, value = "Ürünün desi bilgisi.")
 /**
   * Ürünün desi bilgisi.  
  **/
  private Float dm3 = null;
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Teslimat Kalemi nesnesinin oluşturulma zamanı.")
 /**
   * Teslimat Kalemi nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;

@XmlType(name="StatusEnum")
@XmlEnum(Integer.class)
public enum StatusEnum {

@XmlEnumValue("0") NUMBER_0(Integer.valueOf(0)), @XmlEnumValue("1") NUMBER_1(Integer.valueOf(1));


    private Integer value;

    StatusEnum (Integer v) {
        value = v;
    }

    public Integer value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", required = true, value = "Teslimat Kalemi nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
 /**
   * Teslimat Kalemi nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>  
  **/
  private StatusEnum status = null;
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Teslimat Kalemi nesnesinin güncellenme zamanı.")
 /**
   * Teslimat Kalemi nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;
  @ApiModelProperty(value = "")
  private OrderItem orderItem = null;
  @ApiModelProperty(value = "")
  private Product product = null;
  @ApiModelProperty(value = "")
  private Shipment shipment = null;

 /**
   * Teslimat Kalemi nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ShipmentItem id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ana ürünün id değeri.
   * minimum: 0
   * @return rootProductId
  **/
  @JsonProperty("rootProductId")
  public Integer getRootProductId() {
    return rootProductId;
  }

  public void setRootProductId(Integer rootProductId) {
    this.rootProductId = rootProductId;
  }

  public ShipmentItem rootProductId(Integer rootProductId) {
    this.rootProductId = rootProductId;
    return this;
  }

 /**
   * Ürünün stok tipi cinsinden miktarı.
   * minimum: 0
   * @return amount
  **/
  @JsonProperty("amount")
  public Integer getAmount() {
    return amount;
  }

  public void setAmount(Integer amount) {
    this.amount = amount;
  }

  public ShipmentItem amount(Integer amount) {
    this.amount = amount;
    return this;
  }

 /**
   * Ürünün fiyatı.
   * minimum: 0
   * @return price
  **/
  @JsonProperty("price")
  public Float getPrice() {
    return price;
  }

  public void setPrice(Float price) {
    this.price = price;
  }

  public ShipmentItem price(Float price) {
    this.price = price;
    return this;
  }

 /**
   * Ürün başlığı.
   * @return productLabel
  **/
  @JsonProperty("productLabel")
  public String getProductLabel() {
    return productLabel;
  }

  public void setProductLabel(String productLabel) {
    this.productLabel = productLabel;
  }

  public ShipmentItem productLabel(String productLabel) {
    this.productLabel = productLabel;
    return this;
  }

 /**
   * Ürünün kur bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;USD&lt;/code&gt; : Amerikan Doları&lt;br&gt;&lt;code&gt;EUR&lt;/code&gt; : Euro&lt;br&gt;&lt;code&gt;TL&lt;/code&gt; : Türk Lirası&lt;br&gt;&lt;code&gt;GBP&lt;/code&gt; : İngiliz Sterlini&lt;br&gt;&lt;code&gt;JPY&lt;/code&gt; : Japon Yeni&lt;br&gt;&lt;code&gt;CNY&lt;/code&gt; : Çin Yuanı&lt;br&gt;&lt;code&gt;GR&lt;/code&gt; : Gram Altın&lt;br&gt;&lt;code&gt;CHF&lt;/code&gt; : İsviçre Frangı&lt;br&gt;&lt;/div&gt;
   * @return currency
  **/
  @JsonProperty("currency")
  public String getCurrency() {
    if (currency == null) {
      return null;
    }
    return currency.value();
  }

  public void setCurrency(CurrencyEnum currency) {
    this.currency = currency;
  }

  public ShipmentItem currency(CurrencyEnum currency) {
    this.currency = currency;
    return this;
  }

 /**
   * Ürünün vergi değeri.
   * minimum: 0
   * @return tax
  **/
  @JsonProperty("tax")
  public Integer getTax() {
    return tax;
  }

  public void setTax(Integer tax) {
    this.tax = tax;
  }

  public ShipmentItem tax(Integer tax) {
    this.tax = tax;
    return this;
  }

 /**
   * Ürünün desi bilgisi.
   * minimum: 0
   * @return dm3
  **/
  @JsonProperty("dm3")
  public Float getDm3() {
    return dm3;
  }

  public void setDm3(Float dm3) {
    this.dm3 = dm3;
  }

  public ShipmentItem dm3(Float dm3) {
    this.dm3 = dm3;
    return this;
  }

 /**
   * Teslimat Kalemi nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Teslimat Kalemi nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public Integer getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public ShipmentItem status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Teslimat Kalemi nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(Date updatedAt) {
    this.updatedAt = updatedAt;
  }

  public ShipmentItem updatedAt(Date updatedAt) {
    this.updatedAt = updatedAt;
    return this;
  }

 /**
   * Get orderItem
   * @return orderItem
  **/
  @JsonProperty("orderItem")
  public OrderItem getOrderItem() {
    return orderItem;
  }

  public void setOrderItem(OrderItem orderItem) {
    this.orderItem = orderItem;
  }

  public ShipmentItem orderItem(OrderItem orderItem) {
    this.orderItem = orderItem;
    return this;
  }

 /**
   * Get product
   * @return product
  **/
  @JsonProperty("product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public ShipmentItem product(Product product) {
    this.product = product;
    return this;
  }

 /**
   * Get shipment
   * @return shipment
  **/
  @JsonProperty("shipment")
  public Shipment getShipment() {
    return shipment;
  }

  public void setShipment(Shipment shipment) {
    this.shipment = shipment;
  }

  public ShipmentItem shipment(Shipment shipment) {
    this.shipment = shipment;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShipmentItem {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    rootProductId: ").append(toIndentedString(rootProductId)).append("\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    price: ").append(toIndentedString(price)).append("\n");
    sb.append("    productLabel: ").append(toIndentedString(productLabel)).append("\n");
    sb.append("    currency: ").append(toIndentedString(currency)).append("\n");
    sb.append("    tax: ").append(toIndentedString(tax)).append("\n");
    sb.append("    dm3: ").append(toIndentedString(dm3)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    orderItem: ").append(toIndentedString(orderItem)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("    shipment: ").append(toIndentedString(shipment)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

