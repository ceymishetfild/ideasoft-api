package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class QuickCart  {
  
  @ApiModelProperty(example = "123", value = "Hızlı satın al bağlantısı nesnesi kimlik değeri.")
 /**
   * Hızlı satın al bağlantısı nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "Hızlı Kalem Al", required = true, value = "Hızlı satın al bağlantısı nesnesi için isim değeri.")
 /**
   * Hızlı satın al bağlantısı nesnesi için isim değeri.  
  **/
  private String name = null;

  @ApiModelProperty(example = "products%5B0%5D%5Bid%5D=31&products%5B0%5D%5Bamount%5D=1", required = true, value = "Hızlı satın al bağlantısı url'si.")
 /**
   * Hızlı satın al bağlantısı url'si.  
  **/
  private String url = null;

  @ApiModelProperty(example = "https://goo.gl/VJ2FSF", value = "Hızlı satın al bağlantısı için kısaltılmış url.")
 /**
   * Hızlı satın al bağlantısı için kısaltılmış url.  
  **/
  private String shortUrl = null;
 /**
   * Hızlı satın al bağlantısı nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public QuickCart id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Hızlı satın al bağlantısı nesnesi için isim değeri.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public QuickCart name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Hızlı satın al bağlantısı url&#39;si.
   * @return url
  **/
  @JsonProperty("url")
  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public QuickCart url(String url) {
    this.url = url;
    return this;
  }

 /**
   * Hızlı satın al bağlantısı için kısaltılmış url.
   * @return shortUrl
  **/
  @JsonProperty("shortUrl")
  public String getShortUrl() {
    return shortUrl;
  }

  public void setShortUrl(String shortUrl) {
    this.shortUrl = shortUrl;
  }

  public QuickCart shortUrl(String shortUrl) {
    this.shortUrl = shortUrl;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class QuickCart {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    url: ").append(toIndentedString(url)).append("\n");
    sb.append("    shortUrl: ").append(toIndentedString(shortUrl)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

