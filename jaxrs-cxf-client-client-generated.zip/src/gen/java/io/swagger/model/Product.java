package io.swagger.model;

import io.swagger.model.Brand;
import io.swagger.model.Currency;
import io.swagger.model.Product;
import io.swagger.model.ProductImage;
import io.swagger.model.ProductPrice;
import io.swagger.model.ProductToCategory;
import io.swagger.model.ProductToCountDown;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Product  {
  
  @ApiModelProperty(example = "123", value = "Ürün nesnesi kimlik değeri.")
 /**
   * Ürün nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "Kalem", required = true, value = "Ürünün adı")
 /**
   * Ürünün adı  
  **/
  private String name = null;
  @ApiModelProperty(example = "kalem", value = "Slug değeri ilgili nesnenin Url değeridir.")
 /**
   * Slug değeri ilgili nesnenin Url değeridir.  
  **/
  private String slug = null;
  @ApiModelProperty(example = "kalem", required = true, value = "Ürünün tam adı. Bu değer bir varyant için ana ürünün adı ve varyant adının birleşiminden oluşur. Örneğin Kırmızı varyantı için Kalem Kırmızı olur.")
 /**
   * Ürünün tam adı. Bu değer bir varyant için ana ürünün adı ve varyant adının birleşiminden oluşur. Örneğin Kırmızı varyantı için Kalem Kırmızı olur.  
  **/
  private String fullName = null;
  @ApiModelProperty(example = "KAL-1234", required = true, value = "Ürünün stok kodu. ID değeri gibi eşsiz bir kimlik değeridir.")
 /**
   * Ürünün stok kodu. ID değeri gibi eşsiz bir kimlik değeridir.  
  **/
  private String sku = null;
  @ApiModelProperty(example = "869456789874", value = "Ürünün barkodu.")
 /**
   * Ürünün barkodu.  
  **/
  private String barcode = null;
  @ApiModelProperty(example = "10.0", required = true, value = "Ürünün Fiyat 1 bilgisi.")
 /**
   * Ürünün Fiyat 1 bilgisi.  
  **/
  private Float price1 = null;
  @ApiModelProperty(example = "24", value = "Ürünün garanti süresi.")
 /**
   * Ürünün garanti süresi.  
  **/
  private Integer warranty = null;
  @ApiModelProperty(example = "18", value = "Ürünün KDV oranı.")
 /**
   * Ürünün KDV oranı.  
  **/
  private Integer tax = null;
  @ApiModelProperty(example = "10.0", value = "Ürünün stok tipi cinsinden miktarı.")
 /**
   * Ürünün stok tipi cinsinden miktarı.  
  **/
  private Float stockAmount = null;
  @ApiModelProperty(example = "1.0", value = "Ürünün desisi.")
 /**
   * Ürünün desisi.  
  **/
  private Float volumetricWeight = null;
  @ApiModelProperty(example = "5.0", value = "Ürünün alış fiyatı.")
 /**
   * Ürünün alış fiyatı.  
  **/
  private Float buyingPrice = null;

@XmlType(name="StockTypeLabelEnum")
@XmlEnum(String.class)
public enum StockTypeLabelEnum {

@XmlEnumValue("Piece") PIECE(String.valueOf("Piece")), @XmlEnumValue("cm") CM(String.valueOf("cm")), @XmlEnumValue("Dozen") DOZEN(String.valueOf("Dozen")), @XmlEnumValue("gram") GRAM(String.valueOf("gram")), @XmlEnumValue("kg") KG(String.valueOf("kg")), @XmlEnumValue("Person") PERSON(String.valueOf("Person")), @XmlEnumValue("Package") PACKAGE(String.valueOf("Package")), @XmlEnumValue("metre") METRE(String.valueOf("metre")), @XmlEnumValue("m2") M2(String.valueOf("m2")), @XmlEnumValue("pair") PAIR(String.valueOf("pair"));


    private String value;

    StockTypeLabelEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StockTypeLabelEnum fromValue(String v) {
        for (StockTypeLabelEnum b : StockTypeLabelEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "Piece", value = "Ürünün stok tipi.<div class='idea_choice_list'><code>Piece</code> : Stok tipi birimi Adet<br><code>cm</code> : Stok tipi birimi Santimetre<br><code>Dozen</code> : Stok tipi birimi Düzine<br><code>gram</code> : Stok tipi birimi Gram<br><code>kg</code> : Stok tipi birimi Kilogram<br><code>Person</code> : Stok tipi birimi Kişi<br><code>Package</code> : Stok tipi birimi Paket<br><code>metre</code> : Stok tipi birimi Metre<br><code>m2</code> : Stok tipi birimi Metrekare<br><code>pair</code> : Stok tipi birimi Çift<br></div>")
 /**
   * Ürünün stok tipi.<div class='idea_choice_list'><code>Piece</code> : Stok tipi birimi Adet<br><code>cm</code> : Stok tipi birimi Santimetre<br><code>Dozen</code> : Stok tipi birimi Düzine<br><code>gram</code> : Stok tipi birimi Gram<br><code>kg</code> : Stok tipi birimi Kilogram<br><code>Person</code> : Stok tipi birimi Kişi<br><code>Package</code> : Stok tipi birimi Paket<br><code>metre</code> : Stok tipi birimi Metre<br><code>m2</code> : Stok tipi birimi Metrekare<br><code>pair</code> : Stok tipi birimi Çift<br></div>  
  **/
  private StockTypeLabelEnum stockTypeLabel = null;
  @ApiModelProperty(example = "5.0", value = "Ürünün indirim değeri. Örneğin; discountType 1 olursa %5, 0 olursa 5 tl anlamına gelir.")
 /**
   * Ürünün indirim değeri. Örneğin; discountType 1 olursa %5, 0 olursa 5 tl anlamına gelir.  
  **/
  private Float discount = null;

@XmlType(name="DiscountTypeEnum")
@XmlEnum(Integer.class)
public enum DiscountTypeEnum {

@XmlEnumValue("0") NUMBER_0(Integer.valueOf(0)), @XmlEnumValue("1") NUMBER_1(Integer.valueOf(1));


    private Integer value;

    DiscountTypeEnum (Integer v) {
        value = v;
    }

    public Integer value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static DiscountTypeEnum fromValue(String v) {
        for (DiscountTypeEnum b : DiscountTypeEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", value = "Ürünün indirim tipini belirtir.<div class='idea_choice_list'><code>1</code> : İndirim yüzdesi<br><code>0</code> : İndirimli fiyat<br></div>")
 /**
   * Ürünün indirim tipini belirtir.<div class='idea_choice_list'><code>1</code> : İndirim yüzdesi<br><code>0</code> : İndirimli fiyat<br></div>  
  **/
  private DiscountTypeEnum discountType = null;
  @ApiModelProperty(example = "10.0", value = "Havale indirimi yüzdesi.")
 /**
   * Havale indirimi yüzdesi.  
  **/
  private Float moneyOrderDiscount = null;

@XmlType(name="StatusEnum")
@XmlEnum(Integer.class)
public enum StatusEnum {

@XmlEnumValue("0") NUMBER_0(Integer.valueOf(0)), @XmlEnumValue("1") NUMBER_1(Integer.valueOf(1));


    private Integer value;

    StatusEnum (Integer v) {
        value = v;
    }

    public Integer value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", required = true, value = "Ürün nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif<br><code>0</code> : Pasif<br></div>")
 /**
   * Ürün nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif<br><code>0</code> : Pasif<br></div>  
  **/
  private StatusEnum status = null;

@XmlType(name="TaxIncludedEnum")
@XmlEnum(String.class)
public enum TaxIncludedEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    TaxIncludedEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static TaxIncludedEnum fromValue(String v) {
        for (TaxIncludedEnum b : TaxIncludedEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", value = "Ürün fiyatlarına KDV dahil olup olmadığın belirten değer.<div class='idea_choice_list'><code>1</code> : KDV Dahil<br><code>0</code> : KDV Hariç<br></div>")
 /**
   * Ürün fiyatlarına KDV dahil olup olmadığın belirten değer.<div class='idea_choice_list'><code>1</code> : KDV Dahil<br><code>0</code> : KDV Hariç<br></div>  
  **/
  private TaxIncludedEnum taxIncluded = null;
  @ApiModelProperty(example = "superTedarik", value = "Ürünün distribütör bilgisi")
 /**
   * Ürünün distribütör bilgisi  
  **/
  private String distributor = null;

@XmlType(name="IsGiftedEnum")
@XmlEnum(String.class)
public enum IsGiftedEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    IsGiftedEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static IsGiftedEnum fromValue(String v) {
        for (IsGiftedEnum b : IsGiftedEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Ürünün hediyeli olup olmadığını belirtir.<div class='idea_choice_list'><code>1</code> : Hediyeli<br><code>0</code> : Hediyeli Değil<br></div>")
 /**
   * Ürünün hediyeli olup olmadığını belirtir.<div class='idea_choice_list'><code>1</code> : Hediyeli<br><code>0</code> : Hediyeli Değil<br></div>  
  **/
  private IsGiftedEnum isGifted = null;
  @ApiModelProperty(example = "Silgi hediyeli.", value = "Ürünün yanında hediye olarak vermek istediğiniz hediyeyi bu alanda metin ya da rakamla belirtebilirsiniz.")
 /**
   * Ürünün yanında hediye olarak vermek istediğiniz hediyeyi bu alanda metin ya da rakamla belirtebilirsiniz.  
  **/
  private String gift = null;

@XmlType(name="CustomShippingDisabledEnum")
@XmlEnum(String.class)
public enum CustomShippingDisabledEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    CustomShippingDisabledEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static CustomShippingDisabledEnum fromValue(String v) {
        for (CustomShippingDisabledEnum b : CustomShippingDisabledEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", value = "Kargo ücreti için sistemin kullanılıp kullanılmama değerini belirtir.<div class='idea_choice_list'><code>1</code> : Sistem seçeneği seçili<br><code>0</code> : Sistem seçeneği seçili değil<br></div>")
 /**
   * Kargo ücreti için sistemin kullanılıp kullanılmama değerini belirtir.<div class='idea_choice_list'><code>1</code> : Sistem seçeneği seçili<br><code>0</code> : Sistem seçeneği seçili değil<br></div>  
  **/
  private CustomShippingDisabledEnum customShippingDisabled = null;
  @ApiModelProperty(example = "5.0", value = "Sistem seçeneği seçilmemişse ürün için girilmesi gereken kargo ücreti.")
 /**
   * Sistem seçeneği seçilmemişse ürün için girilmesi gereken kargo ücreti.  
  **/
  private Float customShippingCost = null;
  @ApiModelProperty(example = "8", value = "Ürünün piyasa fiyatı")
 /**
   * Ürünün piyasa fiyatı  
  **/
  private String marketPriceDetail = null;
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Ürün nesnesinin oluşturulma zamanı.")
 /**
   * Ürün nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Ürün nesnesinin güncellenme zamanı.")
 /**
   * Ürün nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;
  @ApiModelProperty(example = "kırmızı, kalem, kırtasiye", value = "Arama motorları tarafından tespit edilebilecek anahtar kelimeler.")
 /**
   * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.  
  **/
  private String metaKeywords = null;
  @ApiModelProperty(example = "Kaliteli kırtasiye ürünleri.", value = "Arama motorları tarafından tespit edilebilecek açıklama yazısı.")
 /**
   * Arama motorları tarafından tespit edilebilecek açıklama yazısı.  
  **/
  private String metaDescription = null;
  @ApiModelProperty(example = "Kırmızı Kalem", value = "Ürün nesnesinin etiket başlığı.")
 /**
   * Ürün nesnesinin etiket başlığı.  
  **/
  private String pageTitle = null;

@XmlType(name="HasOptionEnum")
@XmlEnum(String.class)
public enum HasOptionEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    HasOptionEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static HasOptionEnum fromValue(String v) {
        for (HasOptionEnum b : HasOptionEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", value = "Ürünün varyantının olup olmadığı değerini belirtir. (API otomatik olarak bu değeri atar.)<div class='idea_choice_list'><code>1</code> : Varyantı var<br><code>0</code> : Varyantı yok<br></div>")
 /**
   * Ürünün varyantının olup olmadığı değerini belirtir. (API otomatik olarak bu değeri atar.)<div class='idea_choice_list'><code>1</code> : Varyantı var<br><code>0</code> : Varyantı yok<br></div>  
  **/
  private HasOptionEnum hasOption = null;
  @ApiModelProperty(example = "Yumuşak uçlu, kırmızı renkli kalem.", value = "Ürünün kısa açıklaması.")
 /**
   * Ürünün kısa açıklaması.  
  **/
  private String shortDetails = null;
  @ApiModelProperty(example = "kırmızı, kalem, kırtasiye", value = "Ziyaretçilerinizin site içindeki ürünlerinizin hangi anahtar kelimelerine göre bulacağını belirler.Kelimeler arasında virgül bırakılarak girilmelidir.(etiket1,etiket2)")
 /**
   * Ziyaretçilerinizin site içindeki ürünlerinizin hangi anahtar kelimelerine göre bulacağını belirler.Kelimeler arasında virgül bırakılarak girilmelidir.(etiket1,etiket2)  
  **/
  private String searchKeywords = null;
  @ApiModelProperty(example = "-", value = "Ürüne özel yasal veya isteğe bağlı belirleyebiliceğiniz taksit adedini belirtir. Ürüne özel bir belirleme yapmak istemiyorsanız '-' işareti kullanabilirsiniz.")
 /**
   * Ürüne özel yasal veya isteğe bağlı belirleyebiliceğiniz taksit adedini belirtir. Ürüne özel bir belirleme yapmak istemiyorsanız '-' işareti kullanabilirsiniz.  
  **/
  private String installmentThreshold = null;
  @ApiModelProperty(example = "99", value = "Anasayfa vitrini sırası.")
 /**
   * Anasayfa vitrini sırası.  
  **/
  private Integer homeSortOrder = null;
  @ApiModelProperty(example = "99", value = "Popüler ürünler vitrini sırası.")
 /**
   * Popüler ürünler vitrini sırası.  
  **/
  private Integer popularSortOrder = null;
  @ApiModelProperty(example = "9999", value = "Marka vitrini sırası.")
 /**
   * Marka vitrini sırası.  
  **/
  private Integer brandSortOrder = null;
  @ApiModelProperty(example = "9999", value = "Sponsor ürünler vitrini sırası")
 /**
   * Sponsor ürünler vitrini sırası  
  **/
  private Integer featuredSortOrder = null;
  @ApiModelProperty(example = "9999", value = "Kampanyalı ürünler vitrini sırası.")
 /**
   * Kampanyalı ürünler vitrini sırası.  
  **/
  private Integer campaignedSortOrder = null;
  @ApiModelProperty(example = "9999", value = "Yeni ürünler vitrini sırası.")
 /**
   * Yeni ürünler vitrini sırası.  
  **/
  private Integer newSortOrder = null;
  @ApiModelProperty(example = "9999", value = "İndirimli ürünler vitrini sırası")
 /**
   * İndirimli ürünler vitrini sırası  
  **/
  private Integer discountedSortOrder = null;
  @ApiModelProperty(value = "")
  private Brand brand = null;
  @ApiModelProperty(value = "")
  private Currency currency = null;
  @ApiModelProperty(value = "")
  private Product parent = null;
  @ApiModelProperty(value = "")
  private ProductToCountDown countdown = null;
  @ApiModelProperty(value = "Ürünün fiyatları.")
 /**
   * Ürünün fiyatları.  
  **/
  private List<ProductPrice> prices = new ArrayList<ProductPrice>();
  @ApiModelProperty(value = "Ürünün resimleri.")
 /**
   * Ürünün resimleri.  
  **/
  private List<ProductImage> images = new ArrayList<ProductImage>();
  @ApiModelProperty(value = "Ürünün kategorileri.")
 /**
   * Ürünün kategorileri.  
  **/
  private List<ProductToCategory> productToCategories = new ArrayList<ProductToCategory>();

 /**
   * Ürün nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Product id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ürünün adı
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Product name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Slug değeri ilgili nesnenin Url değeridir.
   * @return slug
  **/
  @JsonProperty("slug")
  public String getSlug() {
    return slug;
  }

  public void setSlug(String slug) {
    this.slug = slug;
  }

  public Product slug(String slug) {
    this.slug = slug;
    return this;
  }

 /**
   * Ürünün tam adı. Bu değer bir varyant için ana ürünün adı ve varyant adının birleşiminden oluşur. Örneğin Kırmızı varyantı için Kalem Kırmızı olur.
   * @return fullName
  **/
  @JsonProperty("fullName")
  public String getFullName() {
    return fullName;
  }

  public void setFullName(String fullName) {
    this.fullName = fullName;
  }

  public Product fullName(String fullName) {
    this.fullName = fullName;
    return this;
  }

 /**
   * Ürünün stok kodu. ID değeri gibi eşsiz bir kimlik değeridir.
   * @return sku
  **/
  @JsonProperty("sku")
  public String getSku() {
    return sku;
  }

  public void setSku(String sku) {
    this.sku = sku;
  }

  public Product sku(String sku) {
    this.sku = sku;
    return this;
  }

 /**
   * Ürünün barkodu.
   * @return barcode
  **/
  @JsonProperty("barcode")
  public String getBarcode() {
    return barcode;
  }

  public void setBarcode(String barcode) {
    this.barcode = barcode;
  }

  public Product barcode(String barcode) {
    this.barcode = barcode;
    return this;
  }

 /**
   * Ürünün Fiyat 1 bilgisi.
   * minimum: 0
   * @return price1
  **/
  @JsonProperty("price1")
  public Float getPrice1() {
    return price1;
  }

  public void setPrice1(Float price1) {
    this.price1 = price1;
  }

  public Product price1(Float price1) {
    this.price1 = price1;
    return this;
  }

 /**
   * Ürünün garanti süresi.
   * minimum: 0
   * @return warranty
  **/
  @JsonProperty("warranty")
  public Integer getWarranty() {
    return warranty;
  }

  public void setWarranty(Integer warranty) {
    this.warranty = warranty;
  }

  public Product warranty(Integer warranty) {
    this.warranty = warranty;
    return this;
  }

 /**
   * Ürünün KDV oranı.
   * minimum: 0
   * @return tax
  **/
  @JsonProperty("tax")
  public Integer getTax() {
    return tax;
  }

  public void setTax(Integer tax) {
    this.tax = tax;
  }

  public Product tax(Integer tax) {
    this.tax = tax;
    return this;
  }

 /**
   * Ürünün stok tipi cinsinden miktarı.
   * minimum: 0
   * @return stockAmount
  **/
  @JsonProperty("stockAmount")
  public Float getStockAmount() {
    return stockAmount;
  }

  public void setStockAmount(Float stockAmount) {
    this.stockAmount = stockAmount;
  }

  public Product stockAmount(Float stockAmount) {
    this.stockAmount = stockAmount;
    return this;
  }

 /**
   * Ürünün desisi.
   * minimum: 0
   * @return volumetricWeight
  **/
  @JsonProperty("volumetricWeight")
  public Float getVolumetricWeight() {
    return volumetricWeight;
  }

  public void setVolumetricWeight(Float volumetricWeight) {
    this.volumetricWeight = volumetricWeight;
  }

  public Product volumetricWeight(Float volumetricWeight) {
    this.volumetricWeight = volumetricWeight;
    return this;
  }

 /**
   * Ürünün alış fiyatı.
   * minimum: 0
   * @return buyingPrice
  **/
  @JsonProperty("buyingPrice")
  public Float getBuyingPrice() {
    return buyingPrice;
  }

  public void setBuyingPrice(Float buyingPrice) {
    this.buyingPrice = buyingPrice;
  }

  public Product buyingPrice(Float buyingPrice) {
    this.buyingPrice = buyingPrice;
    return this;
  }

 /**
   * Ürünün stok tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Piece&lt;/code&gt; : Stok tipi birimi Adet&lt;br&gt;&lt;code&gt;cm&lt;/code&gt; : Stok tipi birimi Santimetre&lt;br&gt;&lt;code&gt;Dozen&lt;/code&gt; : Stok tipi birimi Düzine&lt;br&gt;&lt;code&gt;gram&lt;/code&gt; : Stok tipi birimi Gram&lt;br&gt;&lt;code&gt;kg&lt;/code&gt; : Stok tipi birimi Kilogram&lt;br&gt;&lt;code&gt;Person&lt;/code&gt; : Stok tipi birimi Kişi&lt;br&gt;&lt;code&gt;Package&lt;/code&gt; : Stok tipi birimi Paket&lt;br&gt;&lt;code&gt;metre&lt;/code&gt; : Stok tipi birimi Metre&lt;br&gt;&lt;code&gt;m2&lt;/code&gt; : Stok tipi birimi Metrekare&lt;br&gt;&lt;code&gt;pair&lt;/code&gt; : Stok tipi birimi Çift&lt;br&gt;&lt;/div&gt;
   * @return stockTypeLabel
  **/
  @JsonProperty("stockTypeLabel")
  public String getStockTypeLabel() {
    if (stockTypeLabel == null) {
      return null;
    }
    return stockTypeLabel.value();
  }

  public void setStockTypeLabel(StockTypeLabelEnum stockTypeLabel) {
    this.stockTypeLabel = stockTypeLabel;
  }

  public Product stockTypeLabel(StockTypeLabelEnum stockTypeLabel) {
    this.stockTypeLabel = stockTypeLabel;
    return this;
  }

 /**
   * Ürünün indirim değeri. Örneğin; discountType 1 olursa %5, 0 olursa 5 tl anlamına gelir.
   * minimum: 0
   * @return discount
  **/
  @JsonProperty("discount")
  public Float getDiscount() {
    return discount;
  }

  public void setDiscount(Float discount) {
    this.discount = discount;
  }

  public Product discount(Float discount) {
    this.discount = discount;
    return this;
  }

 /**
   * Ürünün indirim tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : İndirim yüzdesi&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : İndirimli fiyat&lt;br&gt;&lt;/div&gt;
   * @return discountType
  **/
  @JsonProperty("discountType")
  public Integer getDiscountType() {
    if (discountType == null) {
      return null;
    }
    return discountType.value();
  }

  public void setDiscountType(DiscountTypeEnum discountType) {
    this.discountType = discountType;
  }

  public Product discountType(DiscountTypeEnum discountType) {
    this.discountType = discountType;
    return this;
  }

 /**
   * Havale indirimi yüzdesi.
   * minimum: 0
   * maximum: 99.99
   * @return moneyOrderDiscount
  **/
  @JsonProperty("moneyOrderDiscount")
  public Float getMoneyOrderDiscount() {
    return moneyOrderDiscount;
  }

  public void setMoneyOrderDiscount(Float moneyOrderDiscount) {
    this.moneyOrderDiscount = moneyOrderDiscount;
  }

  public Product moneyOrderDiscount(Float moneyOrderDiscount) {
    this.moneyOrderDiscount = moneyOrderDiscount;
    return this;
  }

 /**
   * Ürün nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public Integer getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Product status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Ürün fiyatlarına KDV dahil olup olmadığın belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : KDV Dahil&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : KDV Hariç&lt;br&gt;&lt;/div&gt;
   * @return taxIncluded
  **/
  @JsonProperty("taxIncluded")
  public String getTaxIncluded() {
    if (taxIncluded == null) {
      return null;
    }
    return taxIncluded.value();
  }

  public void setTaxIncluded(TaxIncludedEnum taxIncluded) {
    this.taxIncluded = taxIncluded;
  }

  public Product taxIncluded(TaxIncludedEnum taxIncluded) {
    this.taxIncluded = taxIncluded;
    return this;
  }

 /**
   * Ürünün distribütör bilgisi
   * @return distributor
  **/
  @JsonProperty("distributor")
  public String getDistributor() {
    return distributor;
  }

  public void setDistributor(String distributor) {
    this.distributor = distributor;
  }

  public Product distributor(String distributor) {
    this.distributor = distributor;
    return this;
  }

 /**
   * Ürünün hediyeli olup olmadığını belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hediyeli&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hediyeli Değil&lt;br&gt;&lt;/div&gt;
   * @return isGifted
  **/
  @JsonProperty("isGifted")
  public String getIsGifted() {
    if (isGifted == null) {
      return null;
    }
    return isGifted.value();
  }

  public void setIsGifted(IsGiftedEnum isGifted) {
    this.isGifted = isGifted;
  }

  public Product isGifted(IsGiftedEnum isGifted) {
    this.isGifted = isGifted;
    return this;
  }

 /**
   * Ürünün yanında hediye olarak vermek istediğiniz hediyeyi bu alanda metin ya da rakamla belirtebilirsiniz.
   * @return gift
  **/
  @JsonProperty("gift")
  public String getGift() {
    return gift;
  }

  public void setGift(String gift) {
    this.gift = gift;
  }

  public Product gift(String gift) {
    this.gift = gift;
    return this;
  }

 /**
   * Kargo ücreti için sistemin kullanılıp kullanılmama değerini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sistem seçeneği seçili&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sistem seçeneği seçili değil&lt;br&gt;&lt;/div&gt;
   * @return customShippingDisabled
  **/
  @JsonProperty("customShippingDisabled")
  public String getCustomShippingDisabled() {
    if (customShippingDisabled == null) {
      return null;
    }
    return customShippingDisabled.value();
  }

  public void setCustomShippingDisabled(CustomShippingDisabledEnum customShippingDisabled) {
    this.customShippingDisabled = customShippingDisabled;
  }

  public Product customShippingDisabled(CustomShippingDisabledEnum customShippingDisabled) {
    this.customShippingDisabled = customShippingDisabled;
    return this;
  }

 /**
   * Sistem seçeneği seçilmemişse ürün için girilmesi gereken kargo ücreti.
   * minimum: 0
   * @return customShippingCost
  **/
  @JsonProperty("customShippingCost")
  public Float getCustomShippingCost() {
    return customShippingCost;
  }

  public void setCustomShippingCost(Float customShippingCost) {
    this.customShippingCost = customShippingCost;
  }

  public Product customShippingCost(Float customShippingCost) {
    this.customShippingCost = customShippingCost;
    return this;
  }

 /**
   * Ürünün piyasa fiyatı
   * @return marketPriceDetail
  **/
  @JsonProperty("marketPriceDetail")
  public String getMarketPriceDetail() {
    return marketPriceDetail;
  }

  public void setMarketPriceDetail(String marketPriceDetail) {
    this.marketPriceDetail = marketPriceDetail;
  }

  public Product marketPriceDetail(String marketPriceDetail) {
    this.marketPriceDetail = marketPriceDetail;
    return this;
  }

 /**
   * Ürün nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Ürün nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }


 /**
   * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.
   * @return metaKeywords
  **/
  @JsonProperty("metaKeywords")
  public String getMetaKeywords() {
    return metaKeywords;
  }

  public void setMetaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
  }

  public Product metaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
    return this;
  }

 /**
   * Arama motorları tarafından tespit edilebilecek açıklama yazısı.
   * @return metaDescription
  **/
  @JsonProperty("metaDescription")
  public String getMetaDescription() {
    return metaDescription;
  }

  public void setMetaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
  }

  public Product metaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
    return this;
  }

 /**
   * Ürün nesnesinin etiket başlığı.
   * @return pageTitle
  **/
  @JsonProperty("pageTitle")
  public String getPageTitle() {
    return pageTitle;
  }

  public void setPageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
  }

  public Product pageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
    return this;
  }

 /**
   * Ürünün varyantının olup olmadığı değerini belirtir. (API otomatik olarak bu değeri atar.)&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Varyantı var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Varyantı yok&lt;br&gt;&lt;/div&gt;
   * @return hasOption
  **/
  @JsonProperty("hasOption")
  public String getHasOption() {
    if (hasOption == null) {
      return null;
    }
    return hasOption.value();
  }

  public void setHasOption(HasOptionEnum hasOption) {
    this.hasOption = hasOption;
  }

  public Product hasOption(HasOptionEnum hasOption) {
    this.hasOption = hasOption;
    return this;
  }

 /**
   * Ürünün kısa açıklaması.
   * @return shortDetails
  **/
  @JsonProperty("shortDetails")
  public String getShortDetails() {
    return shortDetails;
  }

  public void setShortDetails(String shortDetails) {
    this.shortDetails = shortDetails;
  }

  public Product shortDetails(String shortDetails) {
    this.shortDetails = shortDetails;
    return this;
  }

 /**
   * Ziyaretçilerinizin site içindeki ürünlerinizin hangi anahtar kelimelerine göre bulacağını belirler.Kelimeler arasında virgül bırakılarak girilmelidir.(etiket1,etiket2)
   * @return searchKeywords
  **/
  @JsonProperty("searchKeywords")
  public String getSearchKeywords() {
    return searchKeywords;
  }

  public void setSearchKeywords(String searchKeywords) {
    this.searchKeywords = searchKeywords;
  }

  public Product searchKeywords(String searchKeywords) {
    this.searchKeywords = searchKeywords;
    return this;
  }

 /**
   * Ürüne özel yasal veya isteğe bağlı belirleyebiliceğiniz taksit adedini belirtir. Ürüne özel bir belirleme yapmak istemiyorsanız &#39;-&#39; işareti kullanabilirsiniz.
   * @return installmentThreshold
  **/
  @JsonProperty("installmentThreshold")
  public String getInstallmentThreshold() {
    return installmentThreshold;
  }

  public void setInstallmentThreshold(String installmentThreshold) {
    this.installmentThreshold = installmentThreshold;
  }

  public Product installmentThreshold(String installmentThreshold) {
    this.installmentThreshold = installmentThreshold;
    return this;
  }

 /**
   * Anasayfa vitrini sırası.
   * maximum: 99
   * @return homeSortOrder
  **/
  @JsonProperty("homeSortOrder")
  public Integer getHomeSortOrder() {
    return homeSortOrder;
  }

  public void setHomeSortOrder(Integer homeSortOrder) {
    this.homeSortOrder = homeSortOrder;
  }

  public Product homeSortOrder(Integer homeSortOrder) {
    this.homeSortOrder = homeSortOrder;
    return this;
  }

 /**
   * Popüler ürünler vitrini sırası.
   * maximum: 99
   * @return popularSortOrder
  **/
  @JsonProperty("popularSortOrder")
  public Integer getPopularSortOrder() {
    return popularSortOrder;
  }

  public void setPopularSortOrder(Integer popularSortOrder) {
    this.popularSortOrder = popularSortOrder;
  }

  public Product popularSortOrder(Integer popularSortOrder) {
    this.popularSortOrder = popularSortOrder;
    return this;
  }

 /**
   * Marka vitrini sırası.
   * maximum: 9999
   * @return brandSortOrder
  **/
  @JsonProperty("brandSortOrder")
  public Integer getBrandSortOrder() {
    return brandSortOrder;
  }

  public void setBrandSortOrder(Integer brandSortOrder) {
    this.brandSortOrder = brandSortOrder;
  }

  public Product brandSortOrder(Integer brandSortOrder) {
    this.brandSortOrder = brandSortOrder;
    return this;
  }

 /**
   * Sponsor ürünler vitrini sırası
   * maximum: 9999
   * @return featuredSortOrder
  **/
  @JsonProperty("featuredSortOrder")
  public Integer getFeaturedSortOrder() {
    return featuredSortOrder;
  }

  public void setFeaturedSortOrder(Integer featuredSortOrder) {
    this.featuredSortOrder = featuredSortOrder;
  }

  public Product featuredSortOrder(Integer featuredSortOrder) {
    this.featuredSortOrder = featuredSortOrder;
    return this;
  }

 /**
   * Kampanyalı ürünler vitrini sırası.
   * maximum: 9999
   * @return campaignedSortOrder
  **/
  @JsonProperty("campaignedSortOrder")
  public Integer getCampaignedSortOrder() {
    return campaignedSortOrder;
  }

  public void setCampaignedSortOrder(Integer campaignedSortOrder) {
    this.campaignedSortOrder = campaignedSortOrder;
  }

  public Product campaignedSortOrder(Integer campaignedSortOrder) {
    this.campaignedSortOrder = campaignedSortOrder;
    return this;
  }

 /**
   * Yeni ürünler vitrini sırası.
   * maximum: 9999
   * @return newSortOrder
  **/
  @JsonProperty("newSortOrder")
  public Integer getNewSortOrder() {
    return newSortOrder;
  }

  public void setNewSortOrder(Integer newSortOrder) {
    this.newSortOrder = newSortOrder;
  }

  public Product newSortOrder(Integer newSortOrder) {
    this.newSortOrder = newSortOrder;
    return this;
  }

 /**
   * İndirimli ürünler vitrini sırası
   * maximum: 9999
   * @return discountedSortOrder
  **/
  @JsonProperty("discountedSortOrder")
  public Integer getDiscountedSortOrder() {
    return discountedSortOrder;
  }

  public void setDiscountedSortOrder(Integer discountedSortOrder) {
    this.discountedSortOrder = discountedSortOrder;
  }

  public Product discountedSortOrder(Integer discountedSortOrder) {
    this.discountedSortOrder = discountedSortOrder;
    return this;
  }

 /**
   * Get brand
   * @return brand
  **/
  @JsonProperty("brand")
  public Brand getBrand() {
    return brand;
  }

  public void setBrand(Brand brand) {
    this.brand = brand;
  }

  public Product brand(Brand brand) {
    this.brand = brand;
    return this;
  }

 /**
   * Get currency
   * @return currency
  **/
  @JsonProperty("currency")
  public Currency getCurrency() {
    return currency;
  }

  public void setCurrency(Currency currency) {
    this.currency = currency;
  }

  public Product currency(Currency currency) {
    this.currency = currency;
    return this;
  }

 /**
   * Get parent
   * @return parent
  **/
  @JsonProperty("parent")
  public Product getParent() {
    return parent;
  }

  public void setParent(Product parent) {
    this.parent = parent;
  }

  public Product parent(Product parent) {
    this.parent = parent;
    return this;
  }

 /**
   * Get countdown
   * @return countdown
  **/
  @JsonProperty("countdown")
  public ProductToCountDown getCountdown() {
    return countdown;
  }

  public void setCountdown(ProductToCountDown countdown) {
    this.countdown = countdown;
  }

  public Product countdown(ProductToCountDown countdown) {
    this.countdown = countdown;
    return this;
  }

 /**
   * Ürünün fiyatları.
   * @return prices
  **/
  @JsonProperty("prices")
  public List<ProductPrice> getPrices() {
    return prices;
  }

  public void setPrices(List<ProductPrice> prices) {
    this.prices = prices;
  }

  public Product prices(List<ProductPrice> prices) {
    this.prices = prices;
    return this;
  }

  public Product addPricesItem(ProductPrice pricesItem) {
    this.prices.add(pricesItem);
    return this;
  }

 /**
   * Ürünün resimleri.
   * @return images
  **/
  @JsonProperty("images")
  public List<ProductImage> getImages() {
    return images;
  }

  public void setImages(List<ProductImage> images) {
    this.images = images;
  }

  public Product images(List<ProductImage> images) {
    this.images = images;
    return this;
  }

  public Product addImagesItem(ProductImage imagesItem) {
    this.images.add(imagesItem);
    return this;
  }

 /**
   * Ürünün kategorileri.
   * @return productToCategories
  **/
  @JsonProperty("productToCategories")
  public List<ProductToCategory> getProductToCategories() {
    return productToCategories;
  }

  public void setProductToCategories(List<ProductToCategory> productToCategories) {
    this.productToCategories = productToCategories;
  }

  public Product productToCategories(List<ProductToCategory> productToCategories) {
    this.productToCategories = productToCategories;
    return this;
  }

  public Product addProductToCategoriesItem(ProductToCategory productToCategoriesItem) {
    this.productToCategories.add(productToCategoriesItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Product {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    slug: ").append(toIndentedString(slug)).append("\n");
    sb.append("    fullName: ").append(toIndentedString(fullName)).append("\n");
    sb.append("    sku: ").append(toIndentedString(sku)).append("\n");
    sb.append("    barcode: ").append(toIndentedString(barcode)).append("\n");
    sb.append("    price1: ").append(toIndentedString(price1)).append("\n");
    sb.append("    warranty: ").append(toIndentedString(warranty)).append("\n");
    sb.append("    tax: ").append(toIndentedString(tax)).append("\n");
    sb.append("    stockAmount: ").append(toIndentedString(stockAmount)).append("\n");
    sb.append("    volumetricWeight: ").append(toIndentedString(volumetricWeight)).append("\n");
    sb.append("    buyingPrice: ").append(toIndentedString(buyingPrice)).append("\n");
    sb.append("    stockTypeLabel: ").append(toIndentedString(stockTypeLabel)).append("\n");
    sb.append("    discount: ").append(toIndentedString(discount)).append("\n");
    sb.append("    discountType: ").append(toIndentedString(discountType)).append("\n");
    sb.append("    moneyOrderDiscount: ").append(toIndentedString(moneyOrderDiscount)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    taxIncluded: ").append(toIndentedString(taxIncluded)).append("\n");
    sb.append("    distributor: ").append(toIndentedString(distributor)).append("\n");
    sb.append("    isGifted: ").append(toIndentedString(isGifted)).append("\n");
    sb.append("    gift: ").append(toIndentedString(gift)).append("\n");
    sb.append("    customShippingDisabled: ").append(toIndentedString(customShippingDisabled)).append("\n");
    sb.append("    customShippingCost: ").append(toIndentedString(customShippingCost)).append("\n");
    sb.append("    marketPriceDetail: ").append(toIndentedString(marketPriceDetail)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    metaKeywords: ").append(toIndentedString(metaKeywords)).append("\n");
    sb.append("    metaDescription: ").append(toIndentedString(metaDescription)).append("\n");
    sb.append("    pageTitle: ").append(toIndentedString(pageTitle)).append("\n");
    sb.append("    hasOption: ").append(toIndentedString(hasOption)).append("\n");
    sb.append("    shortDetails: ").append(toIndentedString(shortDetails)).append("\n");
    sb.append("    searchKeywords: ").append(toIndentedString(searchKeywords)).append("\n");
    sb.append("    installmentThreshold: ").append(toIndentedString(installmentThreshold)).append("\n");
    sb.append("    homeSortOrder: ").append(toIndentedString(homeSortOrder)).append("\n");
    sb.append("    popularSortOrder: ").append(toIndentedString(popularSortOrder)).append("\n");
    sb.append("    brandSortOrder: ").append(toIndentedString(brandSortOrder)).append("\n");
    sb.append("    featuredSortOrder: ").append(toIndentedString(featuredSortOrder)).append("\n");
    sb.append("    campaignedSortOrder: ").append(toIndentedString(campaignedSortOrder)).append("\n");
    sb.append("    newSortOrder: ").append(toIndentedString(newSortOrder)).append("\n");
    sb.append("    discountedSortOrder: ").append(toIndentedString(discountedSortOrder)).append("\n");
    sb.append("    brand: ").append(toIndentedString(brand)).append("\n");
    sb.append("    currency: ").append(toIndentedString(currency)).append("\n");
    sb.append("    parent: ").append(toIndentedString(parent)).append("\n");
    sb.append("    countdown: ").append(toIndentedString(countdown)).append("\n");
    sb.append("    prices: ").append(toIndentedString(prices)).append("\n");
    sb.append("    images: ").append(toIndentedString(images)).append("\n");
    sb.append("    productToCategories: ").append(toIndentedString(productToCategories)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

