package io.swagger.model;

import io.swagger.model.OptionGroup;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Options  {
  
  @ApiModelProperty(example = "123", value = "Varyant nesnesi kimlik değeri.")
 /**
   * Varyant nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "Kırmızı", required = true, value = "Varyant başlığı. Varyant Grubu renk is bu değer kırmızı olabilir.")
 /**
   * Varyant başlığı. Varyant Grubu renk is bu değer kırmızı olabilir.  
  **/
  private String title = null;

  @ApiModelProperty(example = "999", value = "Varyant nesnesi için sıralama değeri.")
 /**
   * Varyant nesnesi için sıralama değeri.  
  **/
  private Integer sortOrder = null;


@XmlType(name="LogoEnum")
@XmlEnum(String.class)
public enum LogoEnum {

@XmlEnumValue("jpg") JPG(String.valueOf("jpg")), @XmlEnumValue("png") PNG(String.valueOf("png")), @XmlEnumValue("gif") GIF(String.valueOf("gif")), @XmlEnumValue("jpeg") JPEG(String.valueOf("jpeg"));


    private String value;

    LogoEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static LogoEnum fromValue(String v) {
        for (LogoEnum b : LogoEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "logo.jpg", value = "Logo görselinin adı.<div class='idea_choice_list'><code>jpg</code> : jpg dosyası için geçerli uzantı.<br><code>png</code> : png dosyası için geçerli uzantı.<br><code>gif</code> : gif dosyası için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyası için geçerli uzantı.<br></div>")
 /**
   * Logo görselinin adı.<div class='idea_choice_list'><code>jpg</code> : jpg dosyası için geçerli uzantı.<br><code>png</code> : png dosyası için geçerli uzantı.<br><code>gif</code> : gif dosyası için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyası için geçerli uzantı.<br></div>  
  **/
  private LogoEnum logo = null;

  @ApiModelProperty(required = true, value = "Varyant grubu nesnesi.")
 /**
   * Varyant grubu nesnesi.  
  **/
  private OptionGroup optionGroup = null;

  @ApiModelProperty(example = "Buraya example gelecek.", value = "Varyant nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.")
 /**
   * Varyant nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.  
  **/
  private String attachment = null;
 /**
   * Varyant nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Options id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Varyant başlığı. Varyant Grubu renk is bu değer kırmızı olabilir.
   * @return title
  **/
  @JsonProperty("title")
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public Options title(String title) {
    this.title = title;
    return this;
  }

 /**
   * Varyant nesnesi için sıralama değeri.
   * minimum: 0
   * maximum: 9999
   * @return sortOrder
  **/
  @JsonProperty("sortOrder")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public Options sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

 /**
   * Logo görselinin adı.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;jpg&lt;/code&gt; : jpg dosyası için geçerli uzantı.&lt;br&gt;&lt;code&gt;png&lt;/code&gt; : png dosyası için geçerli uzantı.&lt;br&gt;&lt;code&gt;gif&lt;/code&gt; : gif dosyası için geçerli uzantı.&lt;br&gt;&lt;code&gt;jpeg&lt;/code&gt; : jpeg dosyası için geçerli uzantı.&lt;br&gt;&lt;/div&gt;
   * @return logo
  **/
  @JsonProperty("logo")
  public String getLogo() {
    if (logo == null) {
      return null;
    }
    return logo.value();
  }

  public void setLogo(LogoEnum logo) {
    this.logo = logo;
  }

  public Options logo(LogoEnum logo) {
    this.logo = logo;
    return this;
  }

 /**
   * Varyant grubu nesnesi.
   * @return optionGroup
  **/
  @JsonProperty("optionGroup")
  public OptionGroup getOptionGroup() {
    return optionGroup;
  }

  public void setOptionGroup(OptionGroup optionGroup) {
    this.optionGroup = optionGroup;
  }

  public Options optionGroup(OptionGroup optionGroup) {
    this.optionGroup = optionGroup;
    return this;
  }

 /**
   * Varyant nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
   * @return attachment
  **/
  @JsonProperty("attachment")
  public String getAttachment() {
    return attachment;
  }

  public void setAttachment(String attachment) {
    this.attachment = attachment;
  }

  public Options attachment(String attachment) {
    this.attachment = attachment;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Options {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    logo: ").append(toIndentedString(logo)).append("\n");
    sb.append("    optionGroup: ").append(toIndentedString(optionGroup)).append("\n");
    sb.append("    attachment: ").append(toIndentedString(attachment)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

