package io.swagger.model;

import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Currency  {
  
  @ApiModelProperty(example = "123", value = "Kur nesnesi kimlik değeri.")
 /**
   * Kur nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "TL", value = "Kur etiketi.")
 /**
   * Kur etiketi.  
  **/
  private String label = null;
  @ApiModelProperty(example = "1.0", value = "Kurun alış fiyatı.")
 /**
   * Kurun alış fiyatı.  
  **/
  private Float buyingPrice = null;
  @ApiModelProperty(example = "1.0", value = "Kurun satış fiyatı.")
 /**
   * Kurun satış fiyatı.  
  **/
  private Float sellingPrice = null;
  @ApiModelProperty(example = "TL", value = "Kurun kısaltması.")
 /**
   * Kurun kısaltması.  
  **/
  private String abbr = null;
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Kur nesnesinin güncellenme zamanı.")
 /**
   * Kur nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;

@XmlType(name="StatusEnum")
@XmlEnum(String.class)
public enum StatusEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    StatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", value = "Kur nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
 /**
   * Kur nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>  
  **/
  private StatusEnum status = null;

@XmlType(name="IsPrimaryEnum")
@XmlEnum(String.class)
public enum IsPrimaryEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    IsPrimaryEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static IsPrimaryEnum fromValue(String v) {
        for (IsPrimaryEnum b : IsPrimaryEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", value = "Kurun birincil kur olup olmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Birincil kur.<br><code>0</code> : Birincil kur değil.<br></div>")
 /**
   * Kurun birincil kur olup olmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Birincil kur.<br><code>0</code> : Birincil kur değil.<br></div>  
  **/
  private IsPrimaryEnum isPrimary = null;

 /**
   * Kur nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Currency id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Kur etiketi.
   * @return label
  **/
  @JsonProperty("label")
  public String getLabel() {
    return label;
  }


 /**
   * Kurun alış fiyatı.
   * minimum: 0
   * @return buyingPrice
  **/
  @JsonProperty("buyingPrice")
  public Float getBuyingPrice() {
    return buyingPrice;
  }

  public void setBuyingPrice(Float buyingPrice) {
    this.buyingPrice = buyingPrice;
  }

  public Currency buyingPrice(Float buyingPrice) {
    this.buyingPrice = buyingPrice;
    return this;
  }

 /**
   * Kurun satış fiyatı.
   * minimum: 0
   * @return sellingPrice
  **/
  @JsonProperty("sellingPrice")
  public Float getSellingPrice() {
    return sellingPrice;
  }

  public void setSellingPrice(Float sellingPrice) {
    this.sellingPrice = sellingPrice;
  }

  public Currency sellingPrice(Float sellingPrice) {
    this.sellingPrice = sellingPrice;
    return this;
  }

 /**
   * Kurun kısaltması.
   * @return abbr
  **/
  @JsonProperty("abbr")
  public String getAbbr() {
    return abbr;
  }


 /**
   * Kur nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(Date updatedAt) {
    this.updatedAt = updatedAt;
  }

  public Currency updatedAt(Date updatedAt) {
    this.updatedAt = updatedAt;
    return this;
  }

 /**
   * Kur nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Currency status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Kurun birincil kur olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Birincil kur.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Birincil kur değil.&lt;br&gt;&lt;/div&gt;
   * @return isPrimary
  **/
  @JsonProperty("isPrimary")
  public String getIsPrimary() {
    if (isPrimary == null) {
      return null;
    }
    return isPrimary.value();
  }

  public void setIsPrimary(IsPrimaryEnum isPrimary) {
    this.isPrimary = isPrimary;
  }

  public Currency isPrimary(IsPrimaryEnum isPrimary) {
    this.isPrimary = isPrimary;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Currency {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    label: ").append(toIndentedString(label)).append("\n");
    sb.append("    buyingPrice: ").append(toIndentedString(buyingPrice)).append("\n");
    sb.append("    sellingPrice: ").append(toIndentedString(sellingPrice)).append("\n");
    sb.append("    abbr: ").append(toIndentedString(abbr)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    isPrimary: ").append(toIndentedString(isPrimary)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

