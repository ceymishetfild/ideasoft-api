package io.swagger.model;

import io.swagger.model.ShippingProvider;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ShippingCompany  {
  
  @ApiModelProperty(example = "123", value = "Kargo firması nesnesi kimlik değeri.")
 /**
   * Kargo firması nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "Idea Cargo", required = true, value = "Kargo firması nesnesi için isim değeri.")
 /**
   * Kargo firması nesnesi için isim değeri.  
  **/
  private String name = null;


@XmlType(name="StatusEnum")
@XmlEnum(String.class)
public enum StatusEnum {

@XmlEnumValue("active") ACTIVE(String.valueOf("active")), @XmlEnumValue("passive") PASSIVE(String.valueOf("passive"));


    private String value;

    StatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "active", required = true, value = "Kargo firması nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>active</code> : Aktif.<br><code>passive</code> : Pasif.<br></div>")
 /**
   * Kargo firması nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>active</code> : Aktif.<br><code>passive</code> : Pasif.<br></div>  
  **/
  private StatusEnum status = null;

  @ApiModelProperty(example = "5.0", value = "Kargo firması için sabit ücret. Sabit bir kargo ücreti uygulayacaksanız her sipariş için sabit kargo ücreti girebilirsiniz. Desi bilgilerini kaydetmeniz durumunda desi toplamlarının üzerine sabit ücret eklenecektir.")
 /**
   * Kargo firması için sabit ücret. Sabit bir kargo ücreti uygulayacaksanız her sipariş için sabit kargo ücreti girebilirsiniz. Desi bilgilerini kaydetmeniz durumunda desi toplamlarının üzerine sabit ücret eklenecektir.  
  **/
  private Float extraPrice = null;

  @ApiModelProperty(example = "10.0", value = "Kargo firması için girmiş olduğunuz desi bilgileri 50 Desiye kadar girilebilmektedir. 50'nin üzeri veya girmiş olduğunuz desi miktarının üzerine her +1 desi için eklenecek olan kargo ücreti.")
 /**
   * Kargo firması için girmiş olduğunuz desi bilgileri 50 Desiye kadar girilebilmektedir. 50'nin üzeri veya girmiş olduğunuz desi miktarının üzerine her +1 desi için eklenecek olan kargo ücreti.  
  **/
  private Float extraVolumetricWeightPrice = null;

  @ApiModelProperty(example = "100.0", value = "Alışveriş sepeti toplamı belirlediğiniz Ücretsiz kargo limitini geçtiğinde müşterileriniz ücretsiz kargo hizmetinden faydalanabilirler.(Örn: X Lira üzeri ücretsiz Kargo!)")
 /**
   * Alışveriş sepeti toplamı belirlediğiniz Ücretsiz kargo limitini geçtiğinde müşterileriniz ücretsiz kargo hizmetinden faydalanabilirler.(Örn: X Lira üzeri ücretsiz Kargo!)  
  **/
  private Float freeShipmentOrderPrice = null;

  @ApiModelProperty(example = "1.0", value = "Ücretsiz kargo miktarı için maksimum ücretsiz desi miktarıdır. Alışveriş sırasındaki desi miktarı ücretsiz desi miktarından fazlaysa, + Desi miktarını sipariş sırasında sistem müşteriden tahsil eder.(Örn: X TL üzeri ücretsiz kargo! Fakat X desiye kadar)Üzeri müşteriden tahsil edilir.")
 /**
   * Ücretsiz kargo miktarı için maksimum ücretsiz desi miktarıdır. Alışveriş sırasındaki desi miktarı ücretsiz desi miktarından fazlaysa, + Desi miktarını sipariş sırasında sistem müşteriden tahsil eder.(Örn: X TL üzeri ücretsiz kargo! Fakat X desiye kadar)Üzeri müşteriden tahsil edilir.  
  **/
  private Float freeShipmentVolumetricWeightLimit = null;

  @ApiModelProperty(example = "999", value = "Kargo firması nesnesi için sıralama değeri.")
 /**
   * Kargo firması nesnesi için sıralama değeri.  
  **/
  private Integer sortOrder = null;

  @ApiModelProperty(example = "CMP12KD", value = "API tarafından otomatik oluşturulan kargo firması kodu.")
 /**
   * API tarafından otomatik oluşturulan kargo firması kodu.  
  **/
  private String companyCode = null;


@XmlType(name="PaymentTypeEnum")
@XmlEnum(String.class)
public enum PaymentTypeEnum {

@XmlEnumValue("cash_on_delivery") CASH_ON_DELIVERY(String.valueOf("cash_on_delivery")), @XmlEnumValue("standart_delivery") STANDART_DELIVERY(String.valueOf("standart_delivery")), @XmlEnumValue("not_applicable") NOT_APPLICABLE(String.valueOf("not_applicable"));


    private String value;

    PaymentTypeEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static PaymentTypeEnum fromValue(String v) {
        for (PaymentTypeEnum b : PaymentTypeEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "standart_delivery", value = "Kargo firması için ödeme tipi.<div class='idea_choice_list'><code>cash_on_delivery</code> : Alıcı ödemeli.<br><code>standart_delivery</code> : Gönderici ödemeli.<br><code>not_applicable</code> : Bu alan için uygulanabilir değil.<br></div>")
 /**
   * Kargo firması için ödeme tipi.<div class='idea_choice_list'><code>cash_on_delivery</code> : Alıcı ödemeli.<br><code>standart_delivery</code> : Gönderici ödemeli.<br><code>not_applicable</code> : Bu alan için uygulanabilir değil.<br></div>  
  **/
  private PaymentTypeEnum paymentType = null;

  @ApiModelProperty(required = true, value = "Teslimat hizmeti sağlayıcısı nesnesi.")
 /**
   * Teslimat hizmeti sağlayıcısı nesnesi.  
  **/
  private ShippingProvider shippingProvider = null;
 /**
   * Kargo firması nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ShippingCompany id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Kargo firması nesnesi için isim değeri.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public ShippingCompany name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Kargo firması nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;active&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public ShippingCompany status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Kargo firması için sabit ücret. Sabit bir kargo ücreti uygulayacaksanız her sipariş için sabit kargo ücreti girebilirsiniz. Desi bilgilerini kaydetmeniz durumunda desi toplamlarının üzerine sabit ücret eklenecektir.
   * minimum: 0
   * @return extraPrice
  **/
  @JsonProperty("extraPrice")
  public Float getExtraPrice() {
    return extraPrice;
  }

  public void setExtraPrice(Float extraPrice) {
    this.extraPrice = extraPrice;
  }

  public ShippingCompany extraPrice(Float extraPrice) {
    this.extraPrice = extraPrice;
    return this;
  }

 /**
   * Kargo firması için girmiş olduğunuz desi bilgileri 50 Desiye kadar girilebilmektedir. 50&#39;nin üzeri veya girmiş olduğunuz desi miktarının üzerine her +1 desi için eklenecek olan kargo ücreti.
   * minimum: 0
   * @return extraVolumetricWeightPrice
  **/
  @JsonProperty("extraVolumetricWeightPrice")
  public Float getExtraVolumetricWeightPrice() {
    return extraVolumetricWeightPrice;
  }

  public void setExtraVolumetricWeightPrice(Float extraVolumetricWeightPrice) {
    this.extraVolumetricWeightPrice = extraVolumetricWeightPrice;
  }

  public ShippingCompany extraVolumetricWeightPrice(Float extraVolumetricWeightPrice) {
    this.extraVolumetricWeightPrice = extraVolumetricWeightPrice;
    return this;
  }

 /**
   * Alışveriş sepeti toplamı belirlediğiniz Ücretsiz kargo limitini geçtiğinde müşterileriniz ücretsiz kargo hizmetinden faydalanabilirler.(Örn: X Lira üzeri ücretsiz Kargo!)
   * minimum: 0
   * @return freeShipmentOrderPrice
  **/
  @JsonProperty("freeShipmentOrderPrice")
  public Float getFreeShipmentOrderPrice() {
    return freeShipmentOrderPrice;
  }

  public void setFreeShipmentOrderPrice(Float freeShipmentOrderPrice) {
    this.freeShipmentOrderPrice = freeShipmentOrderPrice;
  }

  public ShippingCompany freeShipmentOrderPrice(Float freeShipmentOrderPrice) {
    this.freeShipmentOrderPrice = freeShipmentOrderPrice;
    return this;
  }

 /**
   * Ücretsiz kargo miktarı için maksimum ücretsiz desi miktarıdır. Alışveriş sırasındaki desi miktarı ücretsiz desi miktarından fazlaysa, + Desi miktarını sipariş sırasında sistem müşteriden tahsil eder.(Örn: X TL üzeri ücretsiz kargo! Fakat X desiye kadar)Üzeri müşteriden tahsil edilir.
   * minimum: 0
   * @return freeShipmentVolumetricWeightLimit
  **/
  @JsonProperty("freeShipmentVolumetricWeightLimit")
  public Float getFreeShipmentVolumetricWeightLimit() {
    return freeShipmentVolumetricWeightLimit;
  }

  public void setFreeShipmentVolumetricWeightLimit(Float freeShipmentVolumetricWeightLimit) {
    this.freeShipmentVolumetricWeightLimit = freeShipmentVolumetricWeightLimit;
  }

  public ShippingCompany freeShipmentVolumetricWeightLimit(Float freeShipmentVolumetricWeightLimit) {
    this.freeShipmentVolumetricWeightLimit = freeShipmentVolumetricWeightLimit;
    return this;
  }

 /**
   * Kargo firması nesnesi için sıralama değeri.
   * minimum: 0
   * @return sortOrder
  **/
  @JsonProperty("sortOrder")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public ShippingCompany sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

 /**
   * API tarafından otomatik oluşturulan kargo firması kodu.
   * @return companyCode
  **/
  @JsonProperty("companyCode")
  public String getCompanyCode() {
    return companyCode;
  }

  public void setCompanyCode(String companyCode) {
    this.companyCode = companyCode;
  }

  public ShippingCompany companyCode(String companyCode) {
    this.companyCode = companyCode;
    return this;
  }

 /**
   * Kargo firması için ödeme tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli.&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli.&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil.&lt;br&gt;&lt;/div&gt;
   * @return paymentType
  **/
  @JsonProperty("paymentType")
  public String getPaymentType() {
    if (paymentType == null) {
      return null;
    }
    return paymentType.value();
  }

  public void setPaymentType(PaymentTypeEnum paymentType) {
    this.paymentType = paymentType;
  }

  public ShippingCompany paymentType(PaymentTypeEnum paymentType) {
    this.paymentType = paymentType;
    return this;
  }

 /**
   * Teslimat hizmeti sağlayıcısı nesnesi.
   * @return shippingProvider
  **/
  @JsonProperty("shippingProvider")
  public ShippingProvider getShippingProvider() {
    return shippingProvider;
  }

  public void setShippingProvider(ShippingProvider shippingProvider) {
    this.shippingProvider = shippingProvider;
  }

  public ShippingCompany shippingProvider(ShippingProvider shippingProvider) {
    this.shippingProvider = shippingProvider;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShippingCompany {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    extraPrice: ").append(toIndentedString(extraPrice)).append("\n");
    sb.append("    extraVolumetricWeightPrice: ").append(toIndentedString(extraVolumetricWeightPrice)).append("\n");
    sb.append("    freeShipmentOrderPrice: ").append(toIndentedString(freeShipmentOrderPrice)).append("\n");
    sb.append("    freeShipmentVolumetricWeightLimit: ").append(toIndentedString(freeShipmentVolumetricWeightLimit)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    companyCode: ").append(toIndentedString(companyCode)).append("\n");
    sb.append("    paymentType: ").append(toIndentedString(paymentType)).append("\n");
    sb.append("    shippingProvider: ").append(toIndentedString(shippingProvider)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

