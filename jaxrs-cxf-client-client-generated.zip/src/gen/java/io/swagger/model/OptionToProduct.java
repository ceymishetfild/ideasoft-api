package io.swagger.model;

import io.swagger.model.OptionGroup;
import io.swagger.model.Options;
import io.swagger.model.Product;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class OptionToProduct  {
  
  @ApiModelProperty(example = "123", value = "Varyant ürün bağı nesnesi kimlik değeri.")
 /**
   * Varyant ürün bağı nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "123", required = true, value = "Ana ürünün benzersiz kimlik değeri.")
 /**
   * Ana ürünün benzersiz kimlik değeri.  
  **/
  private Integer parentProductId = null;
  @ApiModelProperty(value = "")
  private OptionGroup optionGroup = null;
  @ApiModelProperty(value = "")
  private Options option = null;
  @ApiModelProperty(value = "")
  private Product product = null;

 /**
   * Varyant ürün bağı nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OptionToProduct id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ana ürünün benzersiz kimlik değeri.
   * @return parentProductId
  **/
  @JsonProperty("parentProductId")
  public Integer getParentProductId() {
    return parentProductId;
  }

  public void setParentProductId(Integer parentProductId) {
    this.parentProductId = parentProductId;
  }

  public OptionToProduct parentProductId(Integer parentProductId) {
    this.parentProductId = parentProductId;
    return this;
  }

 /**
   * Get optionGroup
   * @return optionGroup
  **/
  @JsonProperty("optionGroup")
  public OptionGroup getOptionGroup() {
    return optionGroup;
  }

  public void setOptionGroup(OptionGroup optionGroup) {
    this.optionGroup = optionGroup;
  }

  public OptionToProduct optionGroup(OptionGroup optionGroup) {
    this.optionGroup = optionGroup;
    return this;
  }

 /**
   * Get option
   * @return option
  **/
  @JsonProperty("option")
  public Options getOption() {
    return option;
  }

  public void setOption(Options option) {
    this.option = option;
  }

  public OptionToProduct option(Options option) {
    this.option = option;
    return this;
  }

 /**
   * Get product
   * @return product
  **/
  @JsonProperty("product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public OptionToProduct product(Product product) {
    this.product = product;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OptionToProduct {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    parentProductId: ").append(toIndentedString(parentProductId)).append("\n");
    sb.append("    optionGroup: ").append(toIndentedString(optionGroup)).append("\n");
    sb.append("    option: ").append(toIndentedString(option)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

