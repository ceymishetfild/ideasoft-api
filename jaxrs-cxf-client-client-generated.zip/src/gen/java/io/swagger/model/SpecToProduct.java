package io.swagger.model;

import io.swagger.model.Product;
import io.swagger.model.SpecGroup;
import io.swagger.model.SpecName;
import io.swagger.model.SpecValue;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SpecToProduct  {
  
  @ApiModelProperty(example = "123", value = "Ürün özellik ürün bağı nesnesi kimlik değeri.")
 /**
   * Ürün özellik ürün bağı nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(value = "")
  private Product product = null;
  @ApiModelProperty(value = "")
  private SpecGroup specGroup = null;
  @ApiModelProperty(value = "")
  private SpecName specName = null;
  @ApiModelProperty(value = "")
  private SpecValue specValue = null;

 /**
   * Ürün özellik ürün bağı nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public SpecToProduct id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Get product
   * @return product
  **/
  @JsonProperty("product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public SpecToProduct product(Product product) {
    this.product = product;
    return this;
  }

 /**
   * Get specGroup
   * @return specGroup
  **/
  @JsonProperty("specGroup")
  public SpecGroup getSpecGroup() {
    return specGroup;
  }

  public void setSpecGroup(SpecGroup specGroup) {
    this.specGroup = specGroup;
  }

  public SpecToProduct specGroup(SpecGroup specGroup) {
    this.specGroup = specGroup;
    return this;
  }

 /**
   * Get specName
   * @return specName
  **/
  @JsonProperty("specName")
  public SpecName getSpecName() {
    return specName;
  }

  public void setSpecName(SpecName specName) {
    this.specName = specName;
  }

  public SpecToProduct specName(SpecName specName) {
    this.specName = specName;
    return this;
  }

 /**
   * Get specValue
   * @return specValue
  **/
  @JsonProperty("specValue")
  public SpecValue getSpecValue() {
    return specValue;
  }

  public void setSpecValue(SpecValue specValue) {
    this.specValue = specValue;
  }

  public SpecToProduct specValue(SpecValue specValue) {
    this.specValue = specValue;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SpecToProduct {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("    specGroup: ").append(toIndentedString(specGroup)).append("\n");
    sb.append("    specName: ").append(toIndentedString(specName)).append("\n");
    sb.append("    specValue: ").append(toIndentedString(specValue)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

