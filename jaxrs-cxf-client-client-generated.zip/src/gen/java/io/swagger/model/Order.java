package io.swagger.model;

import io.swagger.model.BillingAddress;
import io.swagger.model.Maillist;
import io.swagger.model.Member;
import io.swagger.model.OrderDetail;
import io.swagger.model.OrderItem;
import io.swagger.model.ShippingAddress;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Order  {
  
  @ApiModelProperty(example = "123", value = "Sipariş nesnesi kimlik değeri.")
 /**
   * Sipariş nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "John", required = true, value = "Müşterinin ismi.")
 /**
   * Müşterinin ismi.  
  **/
  private String customerFirstname = null;
  @ApiModelProperty(example = "Doe", required = true, value = "Müşterinin soy ismi.")
 /**
   * Müşterinin soy ismi.  
  **/
  private String customerSurname = null;
  @ApiModelProperty(example = "johndoe@ideasoft.com.tr", required = true, value = "Müşterinin e-mail adresi.")
 /**
   * Müşterinin e-mail adresi.  
  **/
  private String customerEmail = null;
  @ApiModelProperty(example = "+90 (216) 326 04 77", required = true, value = "Müşterinin telefon numarası.")
 /**
   * Müşterinin telefon numarası.  
  **/
  private String customerPhone = null;
  @ApiModelProperty(example = "Havale", required = true, value = "Siparişin ödeme tipi.")
 /**
   * Siparişin ödeme tipi.  
  **/
  private String paymentTypeName = null;
  @ApiModelProperty(example = "MoneyOrder", required = true, value = "Siparişin ödeme altyapısı sağlayıcısının kodu. Ön tanımlıdır. API otomatik oluşturur.")
 /**
   * Siparişin ödeme altyapısı sağlayıcısının kodu. Ön tanımlıdır. API otomatik oluşturur.  
  **/
  private String paymentProviderCode = null;
  @ApiModelProperty(example = "Havale", required = true, value = "Siparişin ödeme altyapısı sağlayıcısının adı. Ön tanımlıdır. API otomatik oluşturur.")
 /**
   * Siparişin ödeme altyapısı sağlayıcısının adı. Ön tanımlıdır. API otomatik oluşturur.  
  **/
  private String paymentProviderName = null;
  @ApiModelProperty(example = "ideabank_1", required = true, value = "Siparişin ödeme kanalının kodu. Ön tanımlıdır. API otomatik oluşturur.")
 /**
   * Siparişin ödeme kanalının kodu. Ön tanımlıdır. API otomatik oluşturur.  
  **/
  private String paymentGatewayCode = null;
  @ApiModelProperty(example = "IdeaBank", required = true, value = "Siparişin ödeme kanalının adı. Ön tanımlıdır. API otomatik oluşturur.")
 /**
   * Siparişin ödeme kanalının adı. Ön tanımlıdır. API otomatik oluşturur.  
  **/
  private String paymentGatewayName = null;
  @ApiModelProperty(example = "IdeaBank", value = "Siparişin banka adı. Ön tanımlıdır. API otomatik oluşturur.")
 /**
   * Siparişin banka adı. Ön tanımlıdır. API otomatik oluşturur.  
  **/
  private String bankName = null;
  @ApiModelProperty(example = "192.168.1.1", required = true, value = "Müşterinin IP adresi.")
 /**
   * Müşterinin IP adresi.  
  **/
  private String clientIp = null;
  @ApiModelProperty(example = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36", value = "Siparişin gerçekleştiği tarayıcı bilgisi.")
 /**
   * Siparişin gerçekleştiği tarayıcı bilgisi.  
  **/
  private String userAgent = null;
  @ApiModelProperty(example = "TL", required = true, value = "Kur bilgisi.")
 /**
   * Kur bilgisi.  
  **/
  private String currency = null;
  @ApiModelProperty(example = "{\"TL\":[1,1],\"USD\":[3.7698,3.7766],\"EUR\":[4.6575,4.6659],\"GBP\":[5.2597,5.2872]}", required = true, value = "Kur oranları.")
 /**
   * Kur oranları.  
  **/
  private String currencyRates = null;
  @ApiModelProperty(example = "1.69492", required = true, value = "Siparişin vergi hariç fiyatı.")
 /**
   * Siparişin vergi hariç fiyatı.  
  **/
  private Float amount = null;
  @ApiModelProperty(example = "0.0", required = true, value = "Siparişte kullanılan hediye çeki indirimi tutarı.")
 /**
   * Siparişte kullanılan hediye çeki indirimi tutarı.  
  **/
  private Float couponDiscount = null;
  @ApiModelProperty(example = "0.30508", required = true, value = "Siparişin vergi tutarı.")
 /**
   * Siparişin vergi tutarı.  
  **/
  private Float taxAmount = null;
  @ApiModelProperty(example = "0.0", required = true, value = "Siparişte kullanılan promosyon indirimi tutarı.")
 /**
   * Siparişte kullanılan promosyon indirimi tutarı.  
  **/
  private Float promotionDiscount = null;
  @ApiModelProperty(example = "2.0", required = true, value = "Siparişin genel fiyat tutarı. orderAmount, couponDiscount, taxAmount, promotionDiscount, shippingAmount, additionalServiceAmount tutarlarının toplamı.")
 /**
   * Siparişin genel fiyat tutarı. orderAmount, couponDiscount, taxAmount, promotionDiscount, shippingAmount, additionalServiceAmount tutarlarının toplamı.  
  **/
  private Float generalAmount = null;
  @ApiModelProperty(example = "5.0", required = true, value = "Siparişin teslimat ücreti.")
 /**
   * Siparişin teslimat ücreti.  
  **/
  private Float shippingAmount = null;
  @ApiModelProperty(example = "0.0", required = true, value = "Siparişin ek hizmet bedeli ücreti.")
 /**
   * Siparişin ek hizmet bedeli ücreti.  
  **/
  private Float additionalServiceAmount = null;
  @ApiModelProperty(example = "2.0", required = true, value = "Siparişin son ödeme tutarı. generalAmount değerinin üzerine taksitten kaynaklı vade farkı bedeli eklenmiş hali.")
 /**
   * Siparişin son ödeme tutarı. generalAmount değerinin üzerine taksitten kaynaklı vade farkı bedeli eklenmiş hali.  
  **/
  private Float finalAmount = null;
  @ApiModelProperty(example = "200.0", value = "Siparişten kazanılan puan tutarı.")
 /**
   * Siparişten kazanılan puan tutarı.  
  **/
  private Float sumOfGainedPoints = null;
  @ApiModelProperty(example = "0", value = "Siparişin taksit adeti.")
 /**
   * Siparişin taksit adeti.  
  **/
  private Integer installment = null;
  @ApiModelProperty(example = "1.0", value = "Siparişin taksit oranı.")
 /**
   * Siparişin taksit oranı.  
  **/
  private Float installmentRate = null;
  @ApiModelProperty(example = "0", value = "Siparişin ek taksit adeti.")
 /**
   * Siparişin ek taksit adeti.  
  **/
  private Integer extraInstallment = null;
  @ApiModelProperty(example = "c88728ce28151", value = "Siparişin numarası.")
 /**
   * Siparişin numarası.  
  **/
  private String transactionId = null;

@XmlType(name="HasUserNoteEnum")
@XmlEnum(String.class)
public enum HasUserNoteEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    HasUserNoteEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static HasUserNoteEnum fromValue(String v) {
        for (HasUserNoteEnum b : HasUserNoteEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Siparişin müşteri notuna sahiplik durumu.<div class='idea_choice_list'><code>1</code> : Sipariş müşteri notuna sahip.<br><code>0</code> : Sipariş müşteri notuna sahip değil.<br></div>")
 /**
   * Siparişin müşteri notuna sahiplik durumu.<div class='idea_choice_list'><code>1</code> : Sipariş müşteri notuna sahip.<br><code>0</code> : Sipariş müşteri notuna sahip değil.<br></div>  
  **/
  private HasUserNoteEnum hasUserNote = null;

@XmlType(name="StatusEnum")
@XmlEnum(String.class)
public enum StatusEnum {

@XmlEnumValue("deleted") DELETED(String.valueOf("deleted")), @XmlEnumValue("waiting_for_approval") WAITING_FOR_APPROVAL(String.valueOf("waiting_for_approval")), @XmlEnumValue("approved") APPROVED(String.valueOf("approved")), @XmlEnumValue("fulfilled") FULFILLED(String.valueOf("fulfilled")), @XmlEnumValue("cancelled") CANCELLED(String.valueOf("cancelled")), @XmlEnumValue("delivered") DELIVERED(String.valueOf("delivered")), @XmlEnumValue("on_accumulation") ON_ACCUMULATION(String.valueOf("on_accumulation")), @XmlEnumValue("waiting_for_payment") WAITING_FOR_PAYMENT(String.valueOf("waiting_for_payment")), @XmlEnumValue("being_prepared") BEING_PREPARED(String.valueOf("being_prepared")), @XmlEnumValue("refunded") REFUNDED(String.valueOf("refunded")), @XmlEnumValue("personal_status_1") PERSONAL_STATUS_1(String.valueOf("personal_status_1")), @XmlEnumValue("personal_status_2") PERSONAL_STATUS_2(String.valueOf("personal_status_2")), @XmlEnumValue("personal_status_3") PERSONAL_STATUS_3(String.valueOf("personal_status_3"));


    private String value;

    StatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "waiting_for_approval", required = true, value = "Sipariş durumu.<div class='idea_choice_list'><code>deleted</code> : Silindi<br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br></div>")
 /**
   * Sipariş durumu.<div class='idea_choice_list'><code>deleted</code> : Silindi<br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br></div>  
  **/
  private StatusEnum status = null;

@XmlType(name="PaymentStatusEnum")
@XmlEnum(String.class)
public enum PaymentStatusEnum {

@XmlEnumValue("in_transaction") IN_TRANSACTION(String.valueOf("in_transaction")), @XmlEnumValue("failed") FAILED(String.valueOf("failed")), @XmlEnumValue("success") SUCCESS(String.valueOf("success"));


    private String value;

    PaymentStatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static PaymentStatusEnum fromValue(String v) {
        for (PaymentStatusEnum b : PaymentStatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "success", required = true, value = "Ödeme durumu bilgisi.<div class='idea_choice_list'><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br><code>failed</code> : Hatalı Ödemeler<br><code>success</code> : Başarılı<br></div>")
 /**
   * Ödeme durumu bilgisi.<div class='idea_choice_list'><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br><code>failed</code> : Hatalı Ödemeler<br><code>success</code> : Başarılı<br></div>  
  **/
  private PaymentStatusEnum paymentStatus = null;
  @ApiModelProperty(example = "Limit yetersiz.", value = "Siparişin hata mesajı.")
 /**
   * Siparişin hata mesajı.  
  **/
  private String errorMessage = null;

@XmlType(name="DeviceTypeEnum")
@XmlEnum(String.class)
public enum DeviceTypeEnum {

@XmlEnumValue("desktop") DESKTOP(String.valueOf("desktop")), @XmlEnumValue("mobile") MOBILE(String.valueOf("mobile")), @XmlEnumValue("tablet") TABLET(String.valueOf("tablet"));


    private String value;

    DeviceTypeEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static DeviceTypeEnum fromValue(String v) {
        for (DeviceTypeEnum b : DeviceTypeEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "desktop", required = true, value = "Siparişin gerçekleştiği cihaz bilgisi.<div class='idea_choice_list'><code>desktop</code> : Masaüstü<br><code>mobile</code> : Mobil<br><code>tablet</code> : Tablet<br></div>")
 /**
   * Siparişin gerçekleştiği cihaz bilgisi.<div class='idea_choice_list'><code>desktop</code> : Masaüstü<br><code>mobile</code> : Mobil<br><code>tablet</code> : Tablet<br></div>  
  **/
  private DeviceTypeEnum deviceType = null;
  @ApiModelProperty(example = "www.referrer.com", value = "Siparişe yönlendiren web-sitesi adresi. Yönlendirmeyi yapan web-sitesinin tam URL bilgisini de içerir. API otomatik oluşturur.")
 /**
   * Siparişe yönlendiren web-sitesi adresi. Yönlendirmeyi yapan web-sitesinin tam URL bilgisini de içerir. API otomatik oluşturur.  
  **/
  private String referrer = null;
  @ApiModelProperty(example = "1", value = "Sipariş için alınan fatura çıktısı adedi.")
 /**
   * Sipariş için alınan fatura çıktısı adedi.  
  **/
  private Integer invoicePrintCount = null;

@XmlType(name="UseGiftPackageEnum")
@XmlEnum(String.class)
public enum UseGiftPackageEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    UseGiftPackageEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static UseGiftPackageEnum fromValue(String v) {
        for (UseGiftPackageEnum b : UseGiftPackageEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Hediye paketi istenilmesi durumu.<div class='idea_choice_list'><code>1</code> : Hediye paketi istiyorum<br><code>0</code> : Hediye paketi istemiyorum<br></div>")
 /**
   * Hediye paketi istenilmesi durumu.<div class='idea_choice_list'><code>1</code> : Hediye paketi istiyorum<br><code>0</code> : Hediye paketi istemiyorum<br></div>  
  **/
  private UseGiftPackageEnum useGiftPackage = null;
  @ApiModelProperty(example = "Doğum günün kutlu olsun.", value = "Hediye notu.")
 /**
   * Hediye notu.  
  **/
  private String giftNote = null;
  @ApiModelProperty(example = "Üyeliksiz alışveriş", value = "Üye grubu adı.")
 /**
   * Üye grubu adı.  
  **/
  private String memberGroupName = null;

@XmlType(name="UsePromotionEnum")
@XmlEnum(String.class)
public enum UsePromotionEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    UsePromotionEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static UsePromotionEnum fromValue(String v) {
        for (UsePromotionEnum b : UsePromotionEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Promosyon kullanılma durumu.<div class='idea_choice_list'><code>1</code> : Promosyon kullan<br><code>0</code> : Promosyon kullanma<br></div>")
 /**
   * Promosyon kullanılma durumu.<div class='idea_choice_list'><code>1</code> : Promosyon kullan<br><code>0</code> : Promosyon kullanma<br></div>  
  **/
  private UsePromotionEnum usePromotion = null;
  @ApiModelProperty(example = "idea", value = "Siparişin teslimat hizmeti sağlayıcısı kodu. Ön tanımlıdır. API otomatik oluşturur.")
 /**
   * Siparişin teslimat hizmeti sağlayıcısı kodu. Ön tanımlıdır. API otomatik oluşturur.  
  **/
  private String shippingProviderCode = null;
  @ApiModelProperty(example = "Idea Cargo", value = "Siparişin teslimat hizmeti sağlayıcısı adı. Ön tanımlıdır.")
 /**
   * Siparişin teslimat hizmeti sağlayıcısı adı. Ön tanımlıdır.  
  **/
  private String shippingProviderName = null;
  @ApiModelProperty(example = "Idea Cargo", value = "Siparişin kargo firması adı. Ön tanımlıdır.")
 /**
   * Siparişin kargo firması adı. Ön tanımlıdır.  
  **/
  private String shippingCompanyName = null;

@XmlType(name="ShippingPaymentTypeEnum")
@XmlEnum(String.class)
public enum ShippingPaymentTypeEnum {

@XmlEnumValue("cash_on_delivery") CASH_ON_DELIVERY(String.valueOf("cash_on_delivery")), @XmlEnumValue("standart_delivery") STANDART_DELIVERY(String.valueOf("standart_delivery")), @XmlEnumValue("not_applicable") NOT_APPLICABLE(String.valueOf("not_applicable"));


    private String value;

    ShippingPaymentTypeEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static ShippingPaymentTypeEnum fromValue(String v) {
        for (ShippingPaymentTypeEnum b : ShippingPaymentTypeEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "standart_delivery", value = "Siparişin kargo ödeme tipi.<div class='idea_choice_list'><code>cash_on_delivery</code> : Alıcı Ödemeli<br><code>standart_delivery</code> : Gönderici Ödemeli<br><code>not_applicable</code> : Bu alan için geçerli değil.<br></div>")
 /**
   * Siparişin kargo ödeme tipi.<div class='idea_choice_list'><code>cash_on_delivery</code> : Alıcı Ödemeli<br><code>standart_delivery</code> : Gönderici Ödemeli<br><code>not_applicable</code> : Bu alan için geçerli değil.<br></div>  
  **/
  private ShippingPaymentTypeEnum shippingPaymentType = null;
  @ApiModelProperty(example = "123123IDEA", value = "Siparişin kargo takip kodu.")
 /**
   * Siparişin kargo takip kodu.  
  **/
  private String shippingTrackingCode = null;
  @ApiModelProperty(example = "IdeaShop Payment", required = true, value = "Siparişin kaynak bilgisi. Siparişin kaynak yazılımını belirtir.")
 /**
   * Siparişin kaynak bilgisi. Siparişin kaynak yazılımını belirtir.  
  **/
  private String source = null;
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Sipariş nesnesinin oluşturulma zamanı.")
 /**
   * Sipariş nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Sipariş nesnesinin güncellenme zamanı.")
 /**
   * Sipariş nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;
  @ApiModelProperty(value = "")
  private Maillist maillist = null;
  @ApiModelProperty(value = "")
  private Member member = null;
  @ApiModelProperty(value = "Sipariş detayları.")
 /**
   * Sipariş detayları.  
  **/
  private List<OrderDetail> orderDetails = new ArrayList<OrderDetail>();
  @ApiModelProperty(value = "Sipariş kalemleri.")
 /**
   * Sipariş kalemleri.  
  **/
  private List<OrderItem> orderItems = new ArrayList<OrderItem>();
  @ApiModelProperty(value = "")
  private ShippingAddress shippingAddress = null;
  @ApiModelProperty(value = "")
  private BillingAddress billingAddress = null;

 /**
   * Sipariş nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Order id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Müşterinin ismi.
   * @return customerFirstname
  **/
  @JsonProperty("customerFirstname")
  public String getCustomerFirstname() {
    return customerFirstname;
  }

  public void setCustomerFirstname(String customerFirstname) {
    this.customerFirstname = customerFirstname;
  }

  public Order customerFirstname(String customerFirstname) {
    this.customerFirstname = customerFirstname;
    return this;
  }

 /**
   * Müşterinin soy ismi.
   * @return customerSurname
  **/
  @JsonProperty("customerSurname")
  public String getCustomerSurname() {
    return customerSurname;
  }

  public void setCustomerSurname(String customerSurname) {
    this.customerSurname = customerSurname;
  }

  public Order customerSurname(String customerSurname) {
    this.customerSurname = customerSurname;
    return this;
  }

 /**
   * Müşterinin e-mail adresi.
   * @return customerEmail
  **/
  @JsonProperty("customerEmail")
  public String getCustomerEmail() {
    return customerEmail;
  }

  public void setCustomerEmail(String customerEmail) {
    this.customerEmail = customerEmail;
  }

  public Order customerEmail(String customerEmail) {
    this.customerEmail = customerEmail;
    return this;
  }

 /**
   * Müşterinin telefon numarası.
   * @return customerPhone
  **/
  @JsonProperty("customerPhone")
  public String getCustomerPhone() {
    return customerPhone;
  }

  public void setCustomerPhone(String customerPhone) {
    this.customerPhone = customerPhone;
  }

  public Order customerPhone(String customerPhone) {
    this.customerPhone = customerPhone;
    return this;
  }

 /**
   * Siparişin ödeme tipi.
   * @return paymentTypeName
  **/
  @JsonProperty("paymentTypeName")
  public String getPaymentTypeName() {
    return paymentTypeName;
  }

  public void setPaymentTypeName(String paymentTypeName) {
    this.paymentTypeName = paymentTypeName;
  }

  public Order paymentTypeName(String paymentTypeName) {
    this.paymentTypeName = paymentTypeName;
    return this;
  }

 /**
   * Siparişin ödeme altyapısı sağlayıcısının kodu. Ön tanımlıdır. API otomatik oluşturur.
   * @return paymentProviderCode
  **/
  @JsonProperty("paymentProviderCode")
  public String getPaymentProviderCode() {
    return paymentProviderCode;
  }

  public void setPaymentProviderCode(String paymentProviderCode) {
    this.paymentProviderCode = paymentProviderCode;
  }

  public Order paymentProviderCode(String paymentProviderCode) {
    this.paymentProviderCode = paymentProviderCode;
    return this;
  }

 /**
   * Siparişin ödeme altyapısı sağlayıcısının adı. Ön tanımlıdır. API otomatik oluşturur.
   * @return paymentProviderName
  **/
  @JsonProperty("paymentProviderName")
  public String getPaymentProviderName() {
    return paymentProviderName;
  }

  public void setPaymentProviderName(String paymentProviderName) {
    this.paymentProviderName = paymentProviderName;
  }

  public Order paymentProviderName(String paymentProviderName) {
    this.paymentProviderName = paymentProviderName;
    return this;
  }

 /**
   * Siparişin ödeme kanalının kodu. Ön tanımlıdır. API otomatik oluşturur.
   * @return paymentGatewayCode
  **/
  @JsonProperty("paymentGatewayCode")
  public String getPaymentGatewayCode() {
    return paymentGatewayCode;
  }

  public void setPaymentGatewayCode(String paymentGatewayCode) {
    this.paymentGatewayCode = paymentGatewayCode;
  }

  public Order paymentGatewayCode(String paymentGatewayCode) {
    this.paymentGatewayCode = paymentGatewayCode;
    return this;
  }

 /**
   * Siparişin ödeme kanalının adı. Ön tanımlıdır. API otomatik oluşturur.
   * @return paymentGatewayName
  **/
  @JsonProperty("paymentGatewayName")
  public String getPaymentGatewayName() {
    return paymentGatewayName;
  }

  public void setPaymentGatewayName(String paymentGatewayName) {
    this.paymentGatewayName = paymentGatewayName;
  }

  public Order paymentGatewayName(String paymentGatewayName) {
    this.paymentGatewayName = paymentGatewayName;
    return this;
  }

 /**
   * Siparişin banka adı. Ön tanımlıdır. API otomatik oluşturur.
   * @return bankName
  **/
  @JsonProperty("bankName")
  public String getBankName() {
    return bankName;
  }

  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  public Order bankName(String bankName) {
    this.bankName = bankName;
    return this;
  }

 /**
   * Müşterinin IP adresi.
   * @return clientIp
  **/
  @JsonProperty("clientIp")
  public String getClientIp() {
    return clientIp;
  }

  public void setClientIp(String clientIp) {
    this.clientIp = clientIp;
  }

  public Order clientIp(String clientIp) {
    this.clientIp = clientIp;
    return this;
  }

 /**
   * Siparişin gerçekleştiği tarayıcı bilgisi.
   * @return userAgent
  **/
  @JsonProperty("userAgent")
  public String getUserAgent() {
    return userAgent;
  }

  public void setUserAgent(String userAgent) {
    this.userAgent = userAgent;
  }

  public Order userAgent(String userAgent) {
    this.userAgent = userAgent;
    return this;
  }

 /**
   * Kur bilgisi.
   * @return currency
  **/
  @JsonProperty("currency")
  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public Order currency(String currency) {
    this.currency = currency;
    return this;
  }

 /**
   * Kur oranları.
   * @return currencyRates
  **/
  @JsonProperty("currencyRates")
  public String getCurrencyRates() {
    return currencyRates;
  }

  public void setCurrencyRates(String currencyRates) {
    this.currencyRates = currencyRates;
  }

  public Order currencyRates(String currencyRates) {
    this.currencyRates = currencyRates;
    return this;
  }

 /**
   * Siparişin vergi hariç fiyatı.
   * minimum: 0
   * @return amount
  **/
  @JsonProperty("amount")
  public Float getAmount() {
    return amount;
  }

  public void setAmount(Float amount) {
    this.amount = amount;
  }

  public Order amount(Float amount) {
    this.amount = amount;
    return this;
  }

 /**
   * Siparişte kullanılan hediye çeki indirimi tutarı.
   * minimum: 0
   * @return couponDiscount
  **/
  @JsonProperty("couponDiscount")
  public Float getCouponDiscount() {
    return couponDiscount;
  }

  public void setCouponDiscount(Float couponDiscount) {
    this.couponDiscount = couponDiscount;
  }

  public Order couponDiscount(Float couponDiscount) {
    this.couponDiscount = couponDiscount;
    return this;
  }

 /**
   * Siparişin vergi tutarı.
   * minimum: 0
   * @return taxAmount
  **/
  @JsonProperty("taxAmount")
  public Float getTaxAmount() {
    return taxAmount;
  }

  public void setTaxAmount(Float taxAmount) {
    this.taxAmount = taxAmount;
  }

  public Order taxAmount(Float taxAmount) {
    this.taxAmount = taxAmount;
    return this;
  }

 /**
   * Siparişte kullanılan promosyon indirimi tutarı.
   * minimum: 0
   * @return promotionDiscount
  **/
  @JsonProperty("promotionDiscount")
  public Float getPromotionDiscount() {
    return promotionDiscount;
  }

  public void setPromotionDiscount(Float promotionDiscount) {
    this.promotionDiscount = promotionDiscount;
  }

  public Order promotionDiscount(Float promotionDiscount) {
    this.promotionDiscount = promotionDiscount;
    return this;
  }

 /**
   * Siparişin genel fiyat tutarı. orderAmount, couponDiscount, taxAmount, promotionDiscount, shippingAmount, additionalServiceAmount tutarlarının toplamı.
   * minimum: 0
   * @return generalAmount
  **/
  @JsonProperty("generalAmount")
  public Float getGeneralAmount() {
    return generalAmount;
  }

  public void setGeneralAmount(Float generalAmount) {
    this.generalAmount = generalAmount;
  }

  public Order generalAmount(Float generalAmount) {
    this.generalAmount = generalAmount;
    return this;
  }

 /**
   * Siparişin teslimat ücreti.
   * minimum: 0
   * @return shippingAmount
  **/
  @JsonProperty("shippingAmount")
  public Float getShippingAmount() {
    return shippingAmount;
  }

  public void setShippingAmount(Float shippingAmount) {
    this.shippingAmount = shippingAmount;
  }

  public Order shippingAmount(Float shippingAmount) {
    this.shippingAmount = shippingAmount;
    return this;
  }

 /**
   * Siparişin ek hizmet bedeli ücreti.
   * @return additionalServiceAmount
  **/
  @JsonProperty("additionalServiceAmount")
  public Float getAdditionalServiceAmount() {
    return additionalServiceAmount;
  }

  public void setAdditionalServiceAmount(Float additionalServiceAmount) {
    this.additionalServiceAmount = additionalServiceAmount;
  }

  public Order additionalServiceAmount(Float additionalServiceAmount) {
    this.additionalServiceAmount = additionalServiceAmount;
    return this;
  }

 /**
   * Siparişin son ödeme tutarı. generalAmount değerinin üzerine taksitten kaynaklı vade farkı bedeli eklenmiş hali.
   * minimum: 0
   * @return finalAmount
  **/
  @JsonProperty("finalAmount")
  public Float getFinalAmount() {
    return finalAmount;
  }

  public void setFinalAmount(Float finalAmount) {
    this.finalAmount = finalAmount;
  }

  public Order finalAmount(Float finalAmount) {
    this.finalAmount = finalAmount;
    return this;
  }

 /**
   * Siparişten kazanılan puan tutarı.
   * minimum: 0
   * @return sumOfGainedPoints
  **/
  @JsonProperty("sumOfGainedPoints")
  public Float getSumOfGainedPoints() {
    return sumOfGainedPoints;
  }

  public void setSumOfGainedPoints(Float sumOfGainedPoints) {
    this.sumOfGainedPoints = sumOfGainedPoints;
  }

  public Order sumOfGainedPoints(Float sumOfGainedPoints) {
    this.sumOfGainedPoints = sumOfGainedPoints;
    return this;
  }

 /**
   * Siparişin taksit adeti.
   * minimum: 0
   * maximum: 12
   * @return installment
  **/
  @JsonProperty("installment")
  public Integer getInstallment() {
    return installment;
  }

  public void setInstallment(Integer installment) {
    this.installment = installment;
  }

  public Order installment(Integer installment) {
    this.installment = installment;
    return this;
  }

 /**
   * Siparişin taksit oranı.
   * @return installmentRate
  **/
  @JsonProperty("installmentRate")
  public Float getInstallmentRate() {
    return installmentRate;
  }

  public void setInstallmentRate(Float installmentRate) {
    this.installmentRate = installmentRate;
  }

  public Order installmentRate(Float installmentRate) {
    this.installmentRate = installmentRate;
    return this;
  }

 /**
   * Siparişin ek taksit adeti.
   * minimum: 0
   * maximum: 12
   * @return extraInstallment
  **/
  @JsonProperty("extraInstallment")
  public Integer getExtraInstallment() {
    return extraInstallment;
  }

  public void setExtraInstallment(Integer extraInstallment) {
    this.extraInstallment = extraInstallment;
  }

  public Order extraInstallment(Integer extraInstallment) {
    this.extraInstallment = extraInstallment;
    return this;
  }

 /**
   * Siparişin numarası.
   * @return transactionId
  **/
  @JsonProperty("transactionId")
  public String getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(String transactionId) {
    this.transactionId = transactionId;
  }

  public Order transactionId(String transactionId) {
    this.transactionId = transactionId;
    return this;
  }

 /**
   * Siparişin müşteri notuna sahiplik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sipariş müşteri notuna sahip.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sipariş müşteri notuna sahip değil.&lt;br&gt;&lt;/div&gt;
   * @return hasUserNote
  **/
  @JsonProperty("hasUserNote")
  public String getHasUserNote() {
    if (hasUserNote == null) {
      return null;
    }
    return hasUserNote.value();
  }

  public void setHasUserNote(HasUserNoteEnum hasUserNote) {
    this.hasUserNote = hasUserNote;
  }

  public Order hasUserNote(HasUserNoteEnum hasUserNote) {
    this.hasUserNote = hasUserNote;
    return this;
  }

 /**
   * Sipariş durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Order status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Ödeme durumu bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;success&lt;/code&gt; : Başarılı&lt;br&gt;&lt;/div&gt;
   * @return paymentStatus
  **/
  @JsonProperty("paymentStatus")
  public String getPaymentStatus() {
    if (paymentStatus == null) {
      return null;
    }
    return paymentStatus.value();
  }

  public void setPaymentStatus(PaymentStatusEnum paymentStatus) {
    this.paymentStatus = paymentStatus;
  }

  public Order paymentStatus(PaymentStatusEnum paymentStatus) {
    this.paymentStatus = paymentStatus;
    return this;
  }

 /**
   * Siparişin hata mesajı.
   * @return errorMessage
  **/
  @JsonProperty("errorMessage")
  public String getErrorMessage() {
    return errorMessage;
  }

  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  public Order errorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
    return this;
  }

 /**
   * Siparişin gerçekleştiği cihaz bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil&lt;br&gt;&lt;code&gt;tablet&lt;/code&gt; : Tablet&lt;br&gt;&lt;/div&gt;
   * @return deviceType
  **/
  @JsonProperty("deviceType")
  public String getDeviceType() {
    if (deviceType == null) {
      return null;
    }
    return deviceType.value();
  }

  public void setDeviceType(DeviceTypeEnum deviceType) {
    this.deviceType = deviceType;
  }

  public Order deviceType(DeviceTypeEnum deviceType) {
    this.deviceType = deviceType;
    return this;
  }

 /**
   * Siparişe yönlendiren web-sitesi adresi. Yönlendirmeyi yapan web-sitesinin tam URL bilgisini de içerir. API otomatik oluşturur.
   * @return referrer
  **/
  @JsonProperty("referrer")
  public String getReferrer() {
    return referrer;
  }

  public void setReferrer(String referrer) {
    this.referrer = referrer;
  }

  public Order referrer(String referrer) {
    this.referrer = referrer;
    return this;
  }

 /**
   * Sipariş için alınan fatura çıktısı adedi.
   * minimum: 0
   * @return invoicePrintCount
  **/
  @JsonProperty("invoicePrintCount")
  public Integer getInvoicePrintCount() {
    return invoicePrintCount;
  }

  public void setInvoicePrintCount(Integer invoicePrintCount) {
    this.invoicePrintCount = invoicePrintCount;
  }

  public Order invoicePrintCount(Integer invoicePrintCount) {
    this.invoicePrintCount = invoicePrintCount;
    return this;
  }

 /**
   * Hediye paketi istenilmesi durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hediye paketi istiyorum&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hediye paketi istemiyorum&lt;br&gt;&lt;/div&gt;
   * @return useGiftPackage
  **/
  @JsonProperty("useGiftPackage")
  public String getUseGiftPackage() {
    if (useGiftPackage == null) {
      return null;
    }
    return useGiftPackage.value();
  }

  public void setUseGiftPackage(UseGiftPackageEnum useGiftPackage) {
    this.useGiftPackage = useGiftPackage;
  }

  public Order useGiftPackage(UseGiftPackageEnum useGiftPackage) {
    this.useGiftPackage = useGiftPackage;
    return this;
  }

 /**
   * Hediye notu.
   * @return giftNote
  **/
  @JsonProperty("giftNote")
  public String getGiftNote() {
    return giftNote;
  }

  public void setGiftNote(String giftNote) {
    this.giftNote = giftNote;
  }

  public Order giftNote(String giftNote) {
    this.giftNote = giftNote;
    return this;
  }

 /**
   * Üye grubu adı.
   * @return memberGroupName
  **/
  @JsonProperty("memberGroupName")
  public String getMemberGroupName() {
    return memberGroupName;
  }

  public void setMemberGroupName(String memberGroupName) {
    this.memberGroupName = memberGroupName;
  }

  public Order memberGroupName(String memberGroupName) {
    this.memberGroupName = memberGroupName;
    return this;
  }

 /**
   * Promosyon kullanılma durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Promosyon kullan&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Promosyon kullanma&lt;br&gt;&lt;/div&gt;
   * @return usePromotion
  **/
  @JsonProperty("usePromotion")
  public String getUsePromotion() {
    if (usePromotion == null) {
      return null;
    }
    return usePromotion.value();
  }

  public void setUsePromotion(UsePromotionEnum usePromotion) {
    this.usePromotion = usePromotion;
  }

  public Order usePromotion(UsePromotionEnum usePromotion) {
    this.usePromotion = usePromotion;
    return this;
  }

 /**
   * Siparişin teslimat hizmeti sağlayıcısı kodu. Ön tanımlıdır. API otomatik oluşturur.
   * @return shippingProviderCode
  **/
  @JsonProperty("shippingProviderCode")
  public String getShippingProviderCode() {
    return shippingProviderCode;
  }

  public void setShippingProviderCode(String shippingProviderCode) {
    this.shippingProviderCode = shippingProviderCode;
  }

  public Order shippingProviderCode(String shippingProviderCode) {
    this.shippingProviderCode = shippingProviderCode;
    return this;
  }

 /**
   * Siparişin teslimat hizmeti sağlayıcısı adı. Ön tanımlıdır.
   * @return shippingProviderName
  **/
  @JsonProperty("shippingProviderName")
  public String getShippingProviderName() {
    return shippingProviderName;
  }

  public void setShippingProviderName(String shippingProviderName) {
    this.shippingProviderName = shippingProviderName;
  }

  public Order shippingProviderName(String shippingProviderName) {
    this.shippingProviderName = shippingProviderName;
    return this;
  }

 /**
   * Siparişin kargo firması adı. Ön tanımlıdır.
   * @return shippingCompanyName
  **/
  @JsonProperty("shippingCompanyName")
  public String getShippingCompanyName() {
    return shippingCompanyName;
  }

  public void setShippingCompanyName(String shippingCompanyName) {
    this.shippingCompanyName = shippingCompanyName;
  }

  public Order shippingCompanyName(String shippingCompanyName) {
    this.shippingCompanyName = shippingCompanyName;
    return this;
  }

 /**
   * Siparişin kargo ödeme tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı Ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici Ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için geçerli değil.&lt;br&gt;&lt;/div&gt;
   * @return shippingPaymentType
  **/
  @JsonProperty("shippingPaymentType")
  public String getShippingPaymentType() {
    if (shippingPaymentType == null) {
      return null;
    }
    return shippingPaymentType.value();
  }

  public void setShippingPaymentType(ShippingPaymentTypeEnum shippingPaymentType) {
    this.shippingPaymentType = shippingPaymentType;
  }

  public Order shippingPaymentType(ShippingPaymentTypeEnum shippingPaymentType) {
    this.shippingPaymentType = shippingPaymentType;
    return this;
  }

 /**
   * Siparişin kargo takip kodu.
   * @return shippingTrackingCode
  **/
  @JsonProperty("shippingTrackingCode")
  public String getShippingTrackingCode() {
    return shippingTrackingCode;
  }

  public void setShippingTrackingCode(String shippingTrackingCode) {
    this.shippingTrackingCode = shippingTrackingCode;
  }

  public Order shippingTrackingCode(String shippingTrackingCode) {
    this.shippingTrackingCode = shippingTrackingCode;
    return this;
  }

 /**
   * Siparişin kaynak bilgisi. Siparişin kaynak yazılımını belirtir.
   * @return source
  **/
  @JsonProperty("source")
  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public Order source(String source) {
    this.source = source;
    return this;
  }

 /**
   * Sipariş nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Sipariş nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }


 /**
   * Get maillist
   * @return maillist
  **/
  @JsonProperty("maillist")
  public Maillist getMaillist() {
    return maillist;
  }

  public void setMaillist(Maillist maillist) {
    this.maillist = maillist;
  }

  public Order maillist(Maillist maillist) {
    this.maillist = maillist;
    return this;
  }

 /**
   * Get member
   * @return member
  **/
  @JsonProperty("member")
  public Member getMember() {
    return member;
  }

  public void setMember(Member member) {
    this.member = member;
  }

  public Order member(Member member) {
    this.member = member;
    return this;
  }

 /**
   * Sipariş detayları.
   * @return orderDetails
  **/
  @JsonProperty("orderDetails")
  public List<OrderDetail> getOrderDetails() {
    return orderDetails;
  }

  public void setOrderDetails(List<OrderDetail> orderDetails) {
    this.orderDetails = orderDetails;
  }

  public Order orderDetails(List<OrderDetail> orderDetails) {
    this.orderDetails = orderDetails;
    return this;
  }

  public Order addOrderDetailsItem(OrderDetail orderDetailsItem) {
    this.orderDetails.add(orderDetailsItem);
    return this;
  }

 /**
   * Sipariş kalemleri.
   * @return orderItems
  **/
  @JsonProperty("orderItems")
  public List<OrderItem> getOrderItems() {
    return orderItems;
  }

  public void setOrderItems(List<OrderItem> orderItems) {
    this.orderItems = orderItems;
  }

  public Order orderItems(List<OrderItem> orderItems) {
    this.orderItems = orderItems;
    return this;
  }

  public Order addOrderItemsItem(OrderItem orderItemsItem) {
    this.orderItems.add(orderItemsItem);
    return this;
  }

 /**
   * Get shippingAddress
   * @return shippingAddress
  **/
  @JsonProperty("shippingAddress")
  public ShippingAddress getShippingAddress() {
    return shippingAddress;
  }

  public void setShippingAddress(ShippingAddress shippingAddress) {
    this.shippingAddress = shippingAddress;
  }

  public Order shippingAddress(ShippingAddress shippingAddress) {
    this.shippingAddress = shippingAddress;
    return this;
  }

 /**
   * Get billingAddress
   * @return billingAddress
  **/
  @JsonProperty("billingAddress")
  public BillingAddress getBillingAddress() {
    return billingAddress;
  }

  public void setBillingAddress(BillingAddress billingAddress) {
    this.billingAddress = billingAddress;
  }

  public Order billingAddress(BillingAddress billingAddress) {
    this.billingAddress = billingAddress;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Order {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    customerFirstname: ").append(toIndentedString(customerFirstname)).append("\n");
    sb.append("    customerSurname: ").append(toIndentedString(customerSurname)).append("\n");
    sb.append("    customerEmail: ").append(toIndentedString(customerEmail)).append("\n");
    sb.append("    customerPhone: ").append(toIndentedString(customerPhone)).append("\n");
    sb.append("    paymentTypeName: ").append(toIndentedString(paymentTypeName)).append("\n");
    sb.append("    paymentProviderCode: ").append(toIndentedString(paymentProviderCode)).append("\n");
    sb.append("    paymentProviderName: ").append(toIndentedString(paymentProviderName)).append("\n");
    sb.append("    paymentGatewayCode: ").append(toIndentedString(paymentGatewayCode)).append("\n");
    sb.append("    paymentGatewayName: ").append(toIndentedString(paymentGatewayName)).append("\n");
    sb.append("    bankName: ").append(toIndentedString(bankName)).append("\n");
    sb.append("    clientIp: ").append(toIndentedString(clientIp)).append("\n");
    sb.append("    userAgent: ").append(toIndentedString(userAgent)).append("\n");
    sb.append("    currency: ").append(toIndentedString(currency)).append("\n");
    sb.append("    currencyRates: ").append(toIndentedString(currencyRates)).append("\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    couponDiscount: ").append(toIndentedString(couponDiscount)).append("\n");
    sb.append("    taxAmount: ").append(toIndentedString(taxAmount)).append("\n");
    sb.append("    promotionDiscount: ").append(toIndentedString(promotionDiscount)).append("\n");
    sb.append("    generalAmount: ").append(toIndentedString(generalAmount)).append("\n");
    sb.append("    shippingAmount: ").append(toIndentedString(shippingAmount)).append("\n");
    sb.append("    additionalServiceAmount: ").append(toIndentedString(additionalServiceAmount)).append("\n");
    sb.append("    finalAmount: ").append(toIndentedString(finalAmount)).append("\n");
    sb.append("    sumOfGainedPoints: ").append(toIndentedString(sumOfGainedPoints)).append("\n");
    sb.append("    installment: ").append(toIndentedString(installment)).append("\n");
    sb.append("    installmentRate: ").append(toIndentedString(installmentRate)).append("\n");
    sb.append("    extraInstallment: ").append(toIndentedString(extraInstallment)).append("\n");
    sb.append("    transactionId: ").append(toIndentedString(transactionId)).append("\n");
    sb.append("    hasUserNote: ").append(toIndentedString(hasUserNote)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    paymentStatus: ").append(toIndentedString(paymentStatus)).append("\n");
    sb.append("    errorMessage: ").append(toIndentedString(errorMessage)).append("\n");
    sb.append("    deviceType: ").append(toIndentedString(deviceType)).append("\n");
    sb.append("    referrer: ").append(toIndentedString(referrer)).append("\n");
    sb.append("    invoicePrintCount: ").append(toIndentedString(invoicePrintCount)).append("\n");
    sb.append("    useGiftPackage: ").append(toIndentedString(useGiftPackage)).append("\n");
    sb.append("    giftNote: ").append(toIndentedString(giftNote)).append("\n");
    sb.append("    memberGroupName: ").append(toIndentedString(memberGroupName)).append("\n");
    sb.append("    usePromotion: ").append(toIndentedString(usePromotion)).append("\n");
    sb.append("    shippingProviderCode: ").append(toIndentedString(shippingProviderCode)).append("\n");
    sb.append("    shippingProviderName: ").append(toIndentedString(shippingProviderName)).append("\n");
    sb.append("    shippingCompanyName: ").append(toIndentedString(shippingCompanyName)).append("\n");
    sb.append("    shippingPaymentType: ").append(toIndentedString(shippingPaymentType)).append("\n");
    sb.append("    shippingTrackingCode: ").append(toIndentedString(shippingTrackingCode)).append("\n");
    sb.append("    source: ").append(toIndentedString(source)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    maillist: ").append(toIndentedString(maillist)).append("\n");
    sb.append("    member: ").append(toIndentedString(member)).append("\n");
    sb.append("    orderDetails: ").append(toIndentedString(orderDetails)).append("\n");
    sb.append("    orderItems: ").append(toIndentedString(orderItems)).append("\n");
    sb.append("    shippingAddress: ").append(toIndentedString(shippingAddress)).append("\n");
    sb.append("    billingAddress: ").append(toIndentedString(billingAddress)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

