package io.swagger.model;

import io.swagger.model.Region;
import io.swagger.model.ShippingCompany;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ShippingRate  {
  
  @ApiModelProperty(example = "123", value = "Kargo oranı nesnesi kimlik değeri.")
 /**
   * Kargo oranı nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "0", required = true, value = "İlgili kargo firması, ilgili bölge ve ilgili orana ait minimum desi değeri.")
 /**
   * İlgili kargo firması, ilgili bölge ve ilgili orana ait minimum desi değeri.  
  **/
  private Integer volumetricWeightStart = null;

  @ApiModelProperty(example = "1", required = true, value = "İlgili kargo firması, ilgili bölge ve ilgili orana ait maximum desi değeri.")
 /**
   * İlgili kargo firması, ilgili bölge ve ilgili orana ait maximum desi değeri.  
  **/
  private Integer volumetricWeightEnd = null;

  @ApiModelProperty(example = "1.0", required = true, value = "Seçili bölge ve kargo firması için kargo oranı.")
 /**
   * Seçili bölge ve kargo firması için kargo oranı.  
  **/
  private Float rate = null;

  @ApiModelProperty(value = "Bölge nesnesi.")
 /**
   * Bölge nesnesi.  
  **/
  private Region region = null;

  @ApiModelProperty(value = "Kargo firması nesnesi.")
 /**
   * Kargo firması nesnesi.  
  **/
  private ShippingCompany shippingCompany = null;
 /**
   * Kargo oranı nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ShippingRate id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * İlgili kargo firması, ilgili bölge ve ilgili orana ait minimum desi değeri.
   * @return volumetricWeightStart
  **/
  @JsonProperty("volumetricWeightStart")
  public Integer getVolumetricWeightStart() {
    return volumetricWeightStart;
  }

  public void setVolumetricWeightStart(Integer volumetricWeightStart) {
    this.volumetricWeightStart = volumetricWeightStart;
  }

  public ShippingRate volumetricWeightStart(Integer volumetricWeightStart) {
    this.volumetricWeightStart = volumetricWeightStart;
    return this;
  }

 /**
   * İlgili kargo firması, ilgili bölge ve ilgili orana ait maximum desi değeri.
   * @return volumetricWeightEnd
  **/
  @JsonProperty("volumetricWeightEnd")
  public Integer getVolumetricWeightEnd() {
    return volumetricWeightEnd;
  }

  public void setVolumetricWeightEnd(Integer volumetricWeightEnd) {
    this.volumetricWeightEnd = volumetricWeightEnd;
  }

  public ShippingRate volumetricWeightEnd(Integer volumetricWeightEnd) {
    this.volumetricWeightEnd = volumetricWeightEnd;
    return this;
  }

 /**
   * Seçili bölge ve kargo firması için kargo oranı.
   * minimum: 0
   * @return rate
  **/
  @JsonProperty("rate")
  public Float getRate() {
    return rate;
  }

  public void setRate(Float rate) {
    this.rate = rate;
  }

  public ShippingRate rate(Float rate) {
    this.rate = rate;
    return this;
  }

 /**
   * Bölge nesnesi.
   * @return region
  **/
  @JsonProperty("region")
  public Region getRegion() {
    return region;
  }

  public void setRegion(Region region) {
    this.region = region;
  }

  public ShippingRate region(Region region) {
    this.region = region;
    return this;
  }

 /**
   * Kargo firması nesnesi.
   * @return shippingCompany
  **/
  @JsonProperty("shippingCompany")
  public ShippingCompany getShippingCompany() {
    return shippingCompany;
  }

  public void setShippingCompany(ShippingCompany shippingCompany) {
    this.shippingCompany = shippingCompany;
  }

  public ShippingRate shippingCompany(ShippingCompany shippingCompany) {
    this.shippingCompany = shippingCompany;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShippingRate {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    volumetricWeightStart: ").append(toIndentedString(volumetricWeightStart)).append("\n");
    sb.append("    volumetricWeightEnd: ").append(toIndentedString(volumetricWeightEnd)).append("\n");
    sb.append("    rate: ").append(toIndentedString(rate)).append("\n");
    sb.append("    region: ").append(toIndentedString(region)).append("\n");
    sb.append("    shippingCompany: ").append(toIndentedString(shippingCompany)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

