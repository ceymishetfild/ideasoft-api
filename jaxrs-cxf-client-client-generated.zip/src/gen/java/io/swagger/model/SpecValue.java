package io.swagger.model;

import io.swagger.model.SpecGroup;
import io.swagger.model.SpecName;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SpecValue  {
  
  @ApiModelProperty(example = "123", value = "Ürün özellik değeri nesnesi kimlik değeri.")
 /**
   * Ürün özellik değeri nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "8 GB", required = true, value = "Ürün özellik değeri nesnesi için isim değeri.")
 /**
   * Ürün özellik değeri nesnesi için isim değeri.  
  **/
  private String name = null;

  @ApiModelProperty(example = "999", value = "Ürün özellik değeri nesnesi için sıralama değeri.")
 /**
   * Ürün özellik değeri nesnesi için sıralama değeri.  
  **/
  private Integer sortOrder = null;


@XmlType(name="LogoEnum")
@XmlEnum(String.class)
public enum LogoEnum {

@XmlEnumValue("jpg") JPG(String.valueOf("jpg")), @XmlEnumValue("png") PNG(String.valueOf("png")), @XmlEnumValue("gif") GIF(String.valueOf("gif")), @XmlEnumValue("jpeg") JPEG(String.valueOf("jpeg"));


    private String value;

    LogoEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static LogoEnum fromValue(String v) {
        for (LogoEnum b : LogoEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "jpg", value = "Ürün özellik değeri logo görseli için geçerli dosya uzantıları.<div class='idea_choice_list'><code>jpg</code> : jpg dosyaları için geçerli uzantı.<br><code>png</code> : png dosyaları için geçerli uzantı.<br><code>gif</code> : gif dosyaları için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyaları için geçerli uzantı.<br></div>")
 /**
   * Ürün özellik değeri logo görseli için geçerli dosya uzantıları.<div class='idea_choice_list'><code>jpg</code> : jpg dosyaları için geçerli uzantı.<br><code>png</code> : png dosyaları için geçerli uzantı.<br><code>gif</code> : gif dosyaları için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyaları için geçerli uzantı.<br></div>  
  **/
  private LogoEnum logo = null;


@XmlType(name="StatusEnum")
@XmlEnum(String.class)
public enum StatusEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    StatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", required = true, value = "Ürün özellik değerinin aktiflik bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
 /**
   * Ürün özellik değerinin aktiflik bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>  
  **/
  private StatusEnum status = null;

  @ApiModelProperty(example = "Buraya örnek gelecek.", value = "Ürün görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.")
 /**
   * Ürün görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.  
  **/
  private String attachment = null;

  @ApiModelProperty(required = true, value = "Ürün özelliği grubu nesnesi.")
 /**
   * Ürün özelliği grubu nesnesi.  
  **/
  private SpecGroup specGroup = null;

  @ApiModelProperty(required = true, value = "Ürün özelliği nesnesi.")
 /**
   * Ürün özelliği nesnesi.  
  **/
  private SpecName specName = null;
 /**
   * Ürün özellik değeri nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public SpecValue id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ürün özellik değeri nesnesi için isim değeri.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public SpecValue name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Ürün özellik değeri nesnesi için sıralama değeri.
   * minimum: 0
   * maximum: 999
   * @return sortOrder
  **/
  @JsonProperty("sortOrder")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public SpecValue sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

 /**
   * Ürün özellik değeri logo görseli için geçerli dosya uzantıları.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;jpg&lt;/code&gt; : jpg dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;png&lt;/code&gt; : png dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;gif&lt;/code&gt; : gif dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;jpeg&lt;/code&gt; : jpeg dosyaları için geçerli uzantı.&lt;br&gt;&lt;/div&gt;
   * @return logo
  **/
  @JsonProperty("logo")
  public String getLogo() {
    if (logo == null) {
      return null;
    }
    return logo.value();
  }

  public void setLogo(LogoEnum logo) {
    this.logo = logo;
  }

  public SpecValue logo(LogoEnum logo) {
    this.logo = logo;
    return this;
  }

 /**
   * Ürün özellik değerinin aktiflik bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public SpecValue status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Ürün görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
   * @return attachment
  **/
  @JsonProperty("attachment")
  public String getAttachment() {
    return attachment;
  }

  public void setAttachment(String attachment) {
    this.attachment = attachment;
  }

  public SpecValue attachment(String attachment) {
    this.attachment = attachment;
    return this;
  }

 /**
   * Ürün özelliği grubu nesnesi.
   * @return specGroup
  **/
  @JsonProperty("specGroup")
  public SpecGroup getSpecGroup() {
    return specGroup;
  }

  public void setSpecGroup(SpecGroup specGroup) {
    this.specGroup = specGroup;
  }

  public SpecValue specGroup(SpecGroup specGroup) {
    this.specGroup = specGroup;
    return this;
  }

 /**
   * Ürün özelliği nesnesi.
   * @return specName
  **/
  @JsonProperty("specName")
  public SpecName getSpecName() {
    return specName;
  }

  public void setSpecName(SpecName specName) {
    this.specName = specName;
  }

  public SpecValue specName(SpecName specName) {
    this.specName = specName;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SpecValue {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    logo: ").append(toIndentedString(logo)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    attachment: ").append(toIndentedString(attachment)).append("\n");
    sb.append("    specGroup: ").append(toIndentedString(specGroup)).append("\n");
    sb.append("    specName: ").append(toIndentedString(specName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

