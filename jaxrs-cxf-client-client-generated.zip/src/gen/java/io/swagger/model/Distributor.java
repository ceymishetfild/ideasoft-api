package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Distributor  {
  
  @ApiModelProperty(example = "123", value = "Distributor nesnesi kimlik değeri.")
 /**
   * Distributor nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "Kırtasiye Tedarik", required = true, value = "Distributor nesnesi için isim değeri.")
 /**
   * Distributor nesnesi için isim değeri.  
  **/
  private String name = null;

  @ApiModelProperty(example = "info@kirtasiyetedarik.com", value = "E-mail adresi.")
 /**
   * E-mail adresi.  
  **/
  private String email = null;

  @ApiModelProperty(example = "+90 (544) 444 44 44", value = "Telefon numarası.")
 /**
   * Telefon numarası.  
  **/
  private String phone = null;

  @ApiModelProperty(example = "Richard Roe", value = "İletişim kişisi.")
 /**
   * İletişim kişisi.  
  **/
  private String contactPerson = null;
 /**
   * Distributor nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Distributor id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Distributor nesnesi için isim değeri.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Distributor name(String name) {
    this.name = name;
    return this;
  }

 /**
   * E-mail adresi.
   * @return email
  **/
  @JsonProperty("email")
  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public Distributor email(String email) {
    this.email = email;
    return this;
  }

 /**
   * Telefon numarası.
   * @return phone
  **/
  @JsonProperty("phone")
  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public Distributor phone(String phone) {
    this.phone = phone;
    return this;
  }

 /**
   * İletişim kişisi.
   * @return contactPerson
  **/
  @JsonProperty("contactPerson")
  public String getContactPerson() {
    return contactPerson;
  }

  public void setContactPerson(String contactPerson) {
    this.contactPerson = contactPerson;
  }

  public Distributor contactPerson(String contactPerson) {
    this.contactPerson = contactPerson;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Distributor {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    phone: ").append(toIndentedString(phone)).append("\n");
    sb.append("    contactPerson: ").append(toIndentedString(contactPerson)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

