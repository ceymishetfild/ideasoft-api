package io.swagger.model;

import io.swagger.model.Order;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderUserNote  {
  
  @ApiModelProperty(example = "123", value = "Sipariş yönetici notu nesnesi kimlik değeri.")
 /**
   * Sipariş yönetici notu nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "johndoe@ideasoft.com.tr", required = true, value = "Yöneticinin(admin) e-mail adresi.")
 /**
   * Yöneticinin(admin) e-mail adresi.  
  **/
  private String userEmail = null;

  @ApiModelProperty(example = "John", value = "Yöneticinin(admin) ismi.")
 /**
   * Yöneticinin(admin) ismi.  
  **/
  private String userFirstname = null;

  @ApiModelProperty(example = "Doe", value = "Yöneticinin(admin) soy ismi.")
 /**
   * Yöneticinin(admin) soy ismi.  
  **/
  private String userSurname = null;

  @ApiModelProperty(example = "Kutulanırken dikkat edilecek.", required = true, value = "Yöneticinin(admin) sipariş için girdiği not.")
 /**
   * Yöneticinin(admin) sipariş için girdiği not.  
  **/
  private String note = null;

  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", required = true, value = "Sipariş yönetici notu nesnesinin oluşturulma zamanı.")
 /**
   * Sipariş yönetici notu nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;

  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", required = true, value = "Sipariş yönetici notu nesnesinin güncellenme zamanı.")
 /**
   * Sipariş yönetici notu nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;

  @ApiModelProperty(required = true, value = "Sipariş nesnesi.")
 /**
   * Sipariş nesnesi.  
  **/
  private Order order = null;
 /**
   * Sipariş yönetici notu nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OrderUserNote id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Yöneticinin(admin) e-mail adresi.
   * @return userEmail
  **/
  @JsonProperty("userEmail")
  public String getUserEmail() {
    return userEmail;
  }

  public void setUserEmail(String userEmail) {
    this.userEmail = userEmail;
  }

  public OrderUserNote userEmail(String userEmail) {
    this.userEmail = userEmail;
    return this;
  }

 /**
   * Yöneticinin(admin) ismi.
   * @return userFirstname
  **/
  @JsonProperty("userFirstname")
  public String getUserFirstname() {
    return userFirstname;
  }

  public void setUserFirstname(String userFirstname) {
    this.userFirstname = userFirstname;
  }

  public OrderUserNote userFirstname(String userFirstname) {
    this.userFirstname = userFirstname;
    return this;
  }

 /**
   * Yöneticinin(admin) soy ismi.
   * @return userSurname
  **/
  @JsonProperty("userSurname")
  public String getUserSurname() {
    return userSurname;
  }

  public void setUserSurname(String userSurname) {
    this.userSurname = userSurname;
  }

  public OrderUserNote userSurname(String userSurname) {
    this.userSurname = userSurname;
    return this;
  }

 /**
   * Yöneticinin(admin) sipariş için girdiği not.
   * @return note
  **/
  @JsonProperty("note")
  public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }

  public OrderUserNote note(String note) {
    this.note = note;
    return this;
  }

 /**
   * Sipariş yönetici notu nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Sipariş yönetici notu nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }


 /**
   * Sipariş nesnesi.
   * @return order
  **/
  @JsonProperty("order")
  public Order getOrder() {
    return order;
  }

  public void setOrder(Order order) {
    this.order = order;
  }

  public OrderUserNote order(Order order) {
    this.order = order;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderUserNote {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    userEmail: ").append(toIndentedString(userEmail)).append("\n");
    sb.append("    userFirstname: ").append(toIndentedString(userFirstname)).append("\n");
    sb.append("    userSurname: ").append(toIndentedString(userSurname)).append("\n");
    sb.append("    note: ").append(toIndentedString(note)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    order: ").append(toIndentedString(order)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

