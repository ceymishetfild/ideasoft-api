package io.swagger.model;

import io.swagger.model.Country;
import io.swagger.model.Region;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Location  {
  
  @ApiModelProperty(example = "123", value = "Şehir nesnesi kimlik değeri.")
 /**
   * Şehir nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "İstanbul", required = true, value = "Şehir nesnesi için isim değeri.")
 /**
   * Şehir nesnesi için isim değeri.  
  **/
  private String name = null;

@XmlType(name="StatusEnum")
@XmlEnum(String.class)
public enum StatusEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    StatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", required = true, value = "Şehir nesnesinin aktiflik durumunu belirten değer.")
 /**
   * Şehir nesnesinin aktiflik durumunu belirten değer.  
  **/
  private StatusEnum status = null;

@XmlType(name="PredefinedEnum")
@XmlEnum(String.class)
public enum PredefinedEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    PredefinedEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static PredefinedEnum fromValue(String v) {
        for (PredefinedEnum b : PredefinedEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "0", value = "Şehir nesnesinin öntanımlı olup olmadığını belirtir.<div class='idea_choice_list'><code>1</code> : Öntanımlı şehir.<br><code>0</code> : Yeni eklenmiş şehir.<br></div>")
 /**
   * Şehir nesnesinin öntanımlı olup olmadığını belirtir.<div class='idea_choice_list'><code>1</code> : Öntanımlı şehir.<br><code>0</code> : Yeni eklenmiş şehir.<br></div>  
  **/
  private PredefinedEnum predefined = null;
  @ApiModelProperty(value = "")
  private Country country = null;
  @ApiModelProperty(value = "")
  private Region region = null;

 /**
   * Şehir nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Location id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Şehir nesnesi için isim değeri.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Location name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Şehir nesnesinin aktiflik durumunu belirten değer.
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Location status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Şehir nesnesinin öntanımlı olup olmadığını belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Öntanımlı şehir.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yeni eklenmiş şehir.&lt;br&gt;&lt;/div&gt;
   * @return predefined
  **/
  @JsonProperty("predefined")
  public String getPredefined() {
    if (predefined == null) {
      return null;
    }
    return predefined.value();
  }


 /**
   * Get country
   * @return country
  **/
  @JsonProperty("country")
  public Country getCountry() {
    return country;
  }

  public void setCountry(Country country) {
    this.country = country;
  }

  public Location country(Country country) {
    this.country = country;
    return this;
  }

 /**
   * Get region
   * @return region
  **/
  @JsonProperty("region")
  public Region getRegion() {
    return region;
  }

  public void setRegion(Region region) {
    this.region = region;
  }

  public Location region(Region region) {
    this.region = region;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Location {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    predefined: ").append(toIndentedString(predefined)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("    region: ").append(toIndentedString(region)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

