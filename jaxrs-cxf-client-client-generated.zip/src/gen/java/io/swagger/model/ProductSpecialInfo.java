package io.swagger.model;

import io.swagger.model.Product;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductSpecialInfo  {
  
  @ApiModelProperty(example = "123", value = "Özel bilgi alanı nesnesi kimlik değeri.")
 /**
   * Özel bilgi alanı nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "ProductSpecialInfo", required = true, value = "Özel bilgi alanı başlığı.")
 /**
   * Özel bilgi alanı başlığı.  
  **/
  private String title = null;

  @ApiModelProperty(example = "Özel bilgi alanı içeriği.", required = true, value = "Özel bilgi alanı içeriği.")
 /**
   * Özel bilgi alanı içeriği.  
  **/
  private String content = null;

  @ApiModelProperty(example = "0", required = true, value = "Özel bilgi alanı aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
 /**
   * Özel bilgi alanı aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>  
  **/
  private Integer status = null;

  @ApiModelProperty(required = true, value = "Ürün nesnesi.")
 /**
   * Ürün nesnesi.  
  **/
  private Product product = null;
 /**
   * Özel bilgi alanı nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductSpecialInfo id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Özel bilgi alanı başlığı.
   * @return title
  **/
  @JsonProperty("title")
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public ProductSpecialInfo title(String title) {
    this.title = title;
    return this;
  }

 /**
   * Özel bilgi alanı içeriği.
   * @return content
  **/
  @JsonProperty("content")
  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public ProductSpecialInfo content(String content) {
    this.content = content;
    return this;
  }

 /**
   * Özel bilgi alanı aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public Integer getStatus() {
    return status;
  }

  public void setStatus(Integer status) {
    this.status = status;
  }

  public ProductSpecialInfo status(Integer status) {
    this.status = status;
    return this;
  }

 /**
   * Ürün nesnesi.
   * @return product
  **/
  @JsonProperty("product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public ProductSpecialInfo product(Product product) {
    this.product = product;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductSpecialInfo {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

