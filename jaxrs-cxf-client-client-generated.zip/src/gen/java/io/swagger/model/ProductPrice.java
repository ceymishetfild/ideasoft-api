package io.swagger.model;

import io.swagger.model.Product;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductPrice  {
  
  @ApiModelProperty(example = "123", value = "Ürün fiyatı nesnesi kimlik değeri.")
 /**
   * Ürün fiyatı nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "10.0", required = true, value = "Ürün fiyatı değeri.")
 /**
   * Ürün fiyatı değeri.  
  **/
  private Float value = null;
  @ApiModelProperty(example = "2", required = true, value = "Ürün fiyatı indexi. Fiyat 2, Fiyat 3 gibi.")
 /**
   * Ürün fiyatı indexi. Fiyat 2, Fiyat 3 gibi.  
  **/
  private Integer type = null;
  @ApiModelProperty(value = "")
  private Product product = null;

 /**
   * Ürün fiyatı nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductPrice id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ürün fiyatı değeri.
   * minimum: 0
   * @return value
  **/
  @JsonProperty("value")
  public Float getValue() {
    return value;
  }

  public void setValue(Float value) {
    this.value = value;
  }

  public ProductPrice value(Float value) {
    this.value = value;
    return this;
  }

 /**
   * Ürün fiyatı indexi. Fiyat 2, Fiyat 3 gibi.
   * minimum: 2
   * maximum: 5
   * @return type
  **/
  @JsonProperty("type")
  public Integer getType() {
    return type;
  }

  public void setType(Integer type) {
    this.type = type;
  }

  public ProductPrice type(Integer type) {
    this.type = type;
    return this;
  }

 /**
   * Get product
   * @return product
  **/
  @JsonProperty("product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public ProductPrice product(Product product) {
    this.product = product;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductPrice {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    value: ").append(toIndentedString(value)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

