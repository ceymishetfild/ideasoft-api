package io.swagger.model;

import io.swagger.model.Member;
import io.swagger.model.Order;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderRefundRequest  {
  
  @ApiModelProperty(example = "123", value = "Sipariş iptal talebi nesnesi kimlik değeri.")
 /**
   * Sipariş iptal talebi nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "KOD-1234", required = true, value = "Sipariş iptal talebi için oluşturulan benzersiz kod değeri.")
 /**
   * Sipariş iptal talebi için oluşturulan benzersiz kod değeri.  
  **/
  private String code = null;

@XmlType(name="StatusEnum")
@XmlEnum(String.class)
public enum StatusEnum {

@XmlEnumValue("approved") APPROVED(String.valueOf("approved")), @XmlEnumValue("waiting_for_approval") WAITING_FOR_APPROVAL(String.valueOf("waiting_for_approval")), @XmlEnumValue("cancelled") CANCELLED(String.valueOf("cancelled"));


    private String value;

    StatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "approved", required = true, value = "Sipariş iptal talebi için durum bilgisi.<div class='idea_choice_list'><code>approved</code> : Onaylandı.<br><code>waiting_for_approval</code> : Onay bekliyor.<br><code>cancelled</code> : İptal edildi.<br></div>")
 /**
   * Sipariş iptal talebi için durum bilgisi.<div class='idea_choice_list'><code>approved</code> : Onaylandı.<br><code>waiting_for_approval</code> : Onay bekliyor.<br><code>cancelled</code> : İptal edildi.<br></div>  
  **/
  private StatusEnum status = null;
  @ApiModelProperty(example = "15.0", required = true, value = "Müşteriye ödenecek miktar bilgisi.")
 /**
   * Müşteriye ödenecek miktar bilgisi.  
  **/
  private Float fee = null;
  @ApiModelProperty(example = "Ürün kusurlu.", value = "Sipariş iptal talebinin oluşturulması sebebinin detaylı açıklaması.")
 /**
   * Sipariş iptal talebinin oluşturulması sebebinin detaylı açıklaması.  
  **/
  private String cancellationReason = null;
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", required = true, value = "Sipariş iptal talebi nesnesinin oluşturulma zamanı.")
 /**
   * Sipariş iptal talebi nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", required = true, value = "Sipariş iptal talebi nesnesinin güncellenme zamanı.")
 /**
   * Sipariş iptal talebi nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;
  @ApiModelProperty(value = "")
  private Member member = null;
  @ApiModelProperty(value = "")
  private Order order = null;

 /**
   * Sipariş iptal talebi nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OrderRefundRequest id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Sipariş iptal talebi için oluşturulan benzersiz kod değeri.
   * @return code
  **/
  @JsonProperty("code")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public OrderRefundRequest code(String code) {
    this.code = code;
    return this;
  }

 /**
   * Sipariş iptal talebi için durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı.&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor.&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public OrderRefundRequest status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Müşteriye ödenecek miktar bilgisi.
   * minimum: 0
   * @return fee
  **/
  @JsonProperty("fee")
  public Float getFee() {
    return fee;
  }

  public void setFee(Float fee) {
    this.fee = fee;
  }

  public OrderRefundRequest fee(Float fee) {
    this.fee = fee;
    return this;
  }

 /**
   * Sipariş iptal talebinin oluşturulması sebebinin detaylı açıklaması.
   * @return cancellationReason
  **/
  @JsonProperty("cancellationReason")
  public String getCancellationReason() {
    return cancellationReason;
  }

  public void setCancellationReason(String cancellationReason) {
    this.cancellationReason = cancellationReason;
  }

  public OrderRefundRequest cancellationReason(String cancellationReason) {
    this.cancellationReason = cancellationReason;
    return this;
  }

 /**
   * Sipariş iptal talebi nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Sipariş iptal talebi nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }


 /**
   * Get member
   * @return member
  **/
  @JsonProperty("member")
  public Member getMember() {
    return member;
  }

  public void setMember(Member member) {
    this.member = member;
  }

  public OrderRefundRequest member(Member member) {
    this.member = member;
    return this;
  }

 /**
   * Get order
   * @return order
  **/
  @JsonProperty("order")
  public Order getOrder() {
    return order;
  }

  public void setOrder(Order order) {
    this.order = order;
  }

  public OrderRefundRequest order(Order order) {
    this.order = order;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderRefundRequest {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    fee: ").append(toIndentedString(fee)).append("\n");
    sb.append("    cancellationReason: ").append(toIndentedString(cancellationReason)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    member: ").append(toIndentedString(member)).append("\n");
    sb.append("    order: ").append(toIndentedString(order)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

