package io.swagger.model;

import io.swagger.model.PaymentGatewaySetting;
import io.swagger.model.PaymentProvider;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PaymentGateway  {
  
  @ApiModelProperty(example = "123", value = "Ödeme kanalı nesnesi kimlik değeri.")
 /**
   * Ödeme kanalı nesnesi kimlik değeri.  
  **/
  private Integer id = null;

  @ApiModelProperty(example = "ideabank", required = true, value = "Ödeme kanalı için ön tanımlanmış kod değeri.")
 /**
   * Ödeme kanalı için ön tanımlanmış kod değeri.  
  **/
  private String code = null;

  @ApiModelProperty(example = "Idea Bank", required = true, value = "Ödeme kanalı nesnesi için isim değeri.")
 /**
   * Ödeme kanalı nesnesi için isim değeri.  
  **/
  private String name = null;


@XmlType(name="StatusEnum")
@XmlEnum(String.class)
public enum StatusEnum {

@XmlEnumValue("active") ACTIVE(String.valueOf("active")), @XmlEnumValue("passive") PASSIVE(String.valueOf("passive"));


    private String value;

    StatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "active", required = true, value = "Ödeme kanalının aktiflik durumu.<div class='idea_choice_list'><code>active</code> : Aktif<br><code>passive</code> : Pasif<br></div>")
 /**
   * Ödeme kanalının aktiflik durumu.<div class='idea_choice_list'><code>active</code> : Aktif<br><code>passive</code> : Pasif<br></div>  
  **/
  private StatusEnum status = null;

  @ApiModelProperty(example = "999", value = "Ödeme kanalı nesnesi için sıralama değeri.")
 /**
   * Ödeme kanalı nesnesi için sıralama değeri.  
  **/
  private Integer sortOrder = null;

  @ApiModelProperty(required = true, value = "Ödeme altyapısı sağlayıcısı nesnesi.")
 /**
   * Ödeme altyapısı sağlayıcısı nesnesi.  
  **/
  private PaymentProvider paymentProvider = null;

  @ApiModelProperty(value = "Ödeme kanalı ayarları.")
 /**
   * Ödeme kanalı ayarları.  
  **/
  private List<PaymentGatewaySetting> settings = null;
 /**
   * Ödeme kanalı nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public PaymentGateway id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ödeme kanalı için ön tanımlanmış kod değeri.
   * @return code
  **/
  @JsonProperty("code")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public PaymentGateway code(String code) {
    this.code = code;
    return this;
  }

 /**
   * Ödeme kanalı nesnesi için isim değeri.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public PaymentGateway name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Ödeme kanalının aktiflik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public PaymentGateway status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Ödeme kanalı nesnesi için sıralama değeri.
   * minimum: 0
   * @return sortOrder
  **/
  @JsonProperty("sortOrder")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public PaymentGateway sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

 /**
   * Ödeme altyapısı sağlayıcısı nesnesi.
   * @return paymentProvider
  **/
  @JsonProperty("paymentProvider")
  public PaymentProvider getPaymentProvider() {
    return paymentProvider;
  }

  public void setPaymentProvider(PaymentProvider paymentProvider) {
    this.paymentProvider = paymentProvider;
  }

  public PaymentGateway paymentProvider(PaymentProvider paymentProvider) {
    this.paymentProvider = paymentProvider;
    return this;
  }

 /**
   * Ödeme kanalı ayarları.
   * @return settings
  **/
  @JsonProperty("settings")
  public List<PaymentGatewaySetting> getSettings() {
    return settings;
  }

  public void setSettings(List<PaymentGatewaySetting> settings) {
    this.settings = settings;
  }

  public PaymentGateway settings(List<PaymentGatewaySetting> settings) {
    this.settings = settings;
    return this;
  }

  public PaymentGateway addSettingsItem(PaymentGatewaySetting settingsItem) {
    this.settings.add(settingsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PaymentGateway {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    paymentProvider: ").append(toIndentedString(paymentProvider)).append("\n");
    sb.append("    settings: ").append(toIndentedString(settings)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

