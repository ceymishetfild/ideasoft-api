package io.swagger.model;

import io.swagger.model.SpecGroup;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SpecName  {
  
  @ApiModelProperty(example = "123", value = "Ürün özelliği nesnesi kimlik değeri.")
 /**
   * Ürün özelliği nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "Kapasite", required = true, value = "Ürün özelliği nesnesi için isim değeri.")
 /**
   * Ürün özelliği nesnesi için isim değeri.  
  **/
  private String name = null;

@XmlType(name="ChoiceTypeEnum")
@XmlEnum(String.class)
public enum ChoiceTypeEnum {

@XmlEnumValue("singular") SINGULAR(String.valueOf("singular")), @XmlEnumValue("plural") PLURAL(String.valueOf("plural"));


    private String value;

    ChoiceTypeEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static ChoiceTypeEnum fromValue(String v) {
        for (ChoiceTypeEnum b : ChoiceTypeEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "singular", required = true, value = "Özellik tipini belirtir.<div class='idea_choice_list'><code>singular</code> : Tekil<br><code>plural</code> : Çoğul<br></div>")
 /**
   * Özellik tipini belirtir.<div class='idea_choice_list'><code>singular</code> : Tekil<br><code>plural</code> : Çoğul<br></div>  
  **/
  private ChoiceTypeEnum choiceType = null;
  @ApiModelProperty(example = "999", value = "Ürün özelliği sıralama değeri.")
 /**
   * Ürün özelliği sıralama değeri.  
  **/
  private Integer sortOrder = null;

@XmlType(name="StatusEnum")
@XmlEnum(String.class)
public enum StatusEnum {

@XmlEnumValue("0") _0(String.valueOf("0")), @XmlEnumValue("1") _1(String.valueOf("1"));


    private String value;

    StatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "1", required = true, value = "Ürün özelliği aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
 /**
   * Ürün özelliği aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>  
  **/
  private StatusEnum status = null;
  @ApiModelProperty(value = "")
  private SpecGroup specGroup = null;

 /**
   * Ürün özelliği nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public SpecName id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Ürün özelliği nesnesi için isim değeri.
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public SpecName name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Özellik tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul&lt;br&gt;&lt;/div&gt;
   * @return choiceType
  **/
  @JsonProperty("choiceType")
  public String getChoiceType() {
    if (choiceType == null) {
      return null;
    }
    return choiceType.value();
  }

  public void setChoiceType(ChoiceTypeEnum choiceType) {
    this.choiceType = choiceType;
  }

  public SpecName choiceType(ChoiceTypeEnum choiceType) {
    this.choiceType = choiceType;
    return this;
  }

 /**
   * Ürün özelliği sıralama değeri.
   * minimum: 0
   * maximum: 999
   * @return sortOrder
  **/
  @JsonProperty("sortOrder")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public SpecName sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

 /**
   * Ürün özelliği aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public SpecName status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Get specGroup
   * @return specGroup
  **/
  @JsonProperty("specGroup")
  public SpecGroup getSpecGroup() {
    return specGroup;
  }

  public void setSpecGroup(SpecGroup specGroup) {
    this.specGroup = specGroup;
  }

  public SpecName specGroup(SpecGroup specGroup) {
    this.specGroup = specGroup;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SpecName {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    choiceType: ").append(toIndentedString(choiceType)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    specGroup: ").append(toIndentedString(specGroup)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

