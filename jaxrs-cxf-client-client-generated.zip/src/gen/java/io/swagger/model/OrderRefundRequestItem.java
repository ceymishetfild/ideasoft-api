package io.swagger.model;

import io.swagger.model.OrderItem;
import io.swagger.model.OrderRefundRequest;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderRefundRequestItem  {
  
  @ApiModelProperty(example = "123", value = "Sipariş iptal talebi kalemi nesnesi kimlik değeri.")
 /**
   * Sipariş iptal talebi kalemi nesnesi kimlik değeri.  
  **/
  private Integer id = null;
  @ApiModelProperty(example = "1.0", required = true, value = "Sipariş iptal talebi istenen ürün miktarı.")
 /**
   * Sipariş iptal talebi istenen ürün miktarı.  
  **/
  private Float amount = null;
  @ApiModelProperty(example = "Ürünü iade etmek istiyorum.", required = true, value = "Sipariş iptal talebi sebebi. Tanımlı dört seçenekten biri seçilmelidir.<div class='idea_choice_list'><code>Ürünü iade etmek istiyorum.</code> : <br><code>Ürünü değiştirmek istiyorum.</code> : <br><code>Faturadaki ürünler ile bana gelen ürünler farklı.</code> : <br><code>Diğer</code> : <br></div>")
 /**
   * Sipariş iptal talebi sebebi. Tanımlı dört seçenekten biri seçilmelidir.<div class='idea_choice_list'><code>Ürünü iade etmek istiyorum.</code> : <br><code>Ürünü değiştirmek istiyorum.</code> : <br><code>Faturadaki ürünler ile bana gelen ürünler farklı.</code> : <br><code>Diğer</code> : <br></div>  
  **/
  private String reason = null;
  @ApiModelProperty(example = "Ürünü iade etmek istiyorum. Çünkü ürünü beğenmedim.", required = true, value = "Sipariş iptal talebinin detaylı açıklaması.")
 /**
   * Sipariş iptal talebinin detaylı açıklaması.  
  **/
  private String details = null;
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Sipariş iptal talebi kalemi nesnesinin oluşturulma zamanı.")
 /**
   * Sipariş iptal talebi kalemi nesnesinin oluşturulma zamanı.  
  **/
  private Date createdAt = null;
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Sipariş iptal talebi kalemi nesnesinin güncellenme zamanı.")
 /**
   * Sipariş iptal talebi kalemi nesnesinin güncellenme zamanı.  
  **/
  private Date updatedAt = null;
  @ApiModelProperty(value = "")
  private OrderItem orderItem = null;
  @ApiModelProperty(value = "")
  private OrderRefundRequest orderRefundRequest = null;

 /**
   * Sipariş iptal talebi kalemi nesnesi kimlik değeri.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OrderRefundRequestItem id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Sipariş iptal talebi istenen ürün miktarı.
   * minimum: 0
   * @return amount
  **/
  @JsonProperty("amount")
  public Float getAmount() {
    return amount;
  }

  public void setAmount(Float amount) {
    this.amount = amount;
  }

  public OrderRefundRequestItem amount(Float amount) {
    this.amount = amount;
    return this;
  }

 /**
   * Sipariş iptal talebi sebebi. Tanımlı dört seçenekten biri seçilmelidir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Ürünü iade etmek istiyorum.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Ürünü değiştirmek istiyorum.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Faturadaki ürünler ile bana gelen ürünler farklı.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Diğer&lt;/code&gt; : &lt;br&gt;&lt;/div&gt;
   * @return reason
  **/
  @JsonProperty("reason")
  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }

  public OrderRefundRequestItem reason(String reason) {
    this.reason = reason;
    return this;
  }

 /**
   * Sipariş iptal talebinin detaylı açıklaması.
   * @return details
  **/
  @JsonProperty("details")
  public String getDetails() {
    return details;
  }

  public void setDetails(String details) {
    this.details = details;
  }

  public OrderRefundRequestItem details(String details) {
    this.details = details;
    return this;
  }

 /**
   * Sipariş iptal talebi kalemi nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @JsonProperty("createdAt")
  public Date getCreatedAt() {
    return createdAt;
  }


 /**
   * Sipariş iptal talebi kalemi nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @JsonProperty("updatedAt")
  public Date getUpdatedAt() {
    return updatedAt;
  }


 /**
   * Get orderItem
   * @return orderItem
  **/
  @JsonProperty("orderItem")
  public OrderItem getOrderItem() {
    return orderItem;
  }

  public void setOrderItem(OrderItem orderItem) {
    this.orderItem = orderItem;
  }

  public OrderRefundRequestItem orderItem(OrderItem orderItem) {
    this.orderItem = orderItem;
    return this;
  }

 /**
   * Get orderRefundRequest
   * @return orderRefundRequest
  **/
  @JsonProperty("orderRefundRequest")
  public OrderRefundRequest getOrderRefundRequest() {
    return orderRefundRequest;
  }

  public void setOrderRefundRequest(OrderRefundRequest orderRefundRequest) {
    this.orderRefundRequest = orderRefundRequest;
  }

  public OrderRefundRequestItem orderRefundRequest(OrderRefundRequest orderRefundRequest) {
    this.orderRefundRequest = orderRefundRequest;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderRefundRequestItem {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    reason: ").append(toIndentedString(reason)).append("\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    orderItem: ").append(toIndentedString(orderItem)).append("\n");
    sb.append("    orderRefundRequest: ").append(toIndentedString(orderRefundRequest)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

