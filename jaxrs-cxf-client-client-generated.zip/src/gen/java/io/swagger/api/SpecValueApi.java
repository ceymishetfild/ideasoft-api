package io.swagger.api;

import io.swagger.model.Error;
import io.swagger.model.SpecValue;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;
import io.swagger.jaxrs.PATCH;

/**
 * IdeaSoft API
 *
 * <p><div class=\"apidoc-icons\"><div class=\"apidoc-icons-item\"><a href=\"javascript:void(0)\" class=\"faq-button\" title=\"Sıkça Sorulan Sorular\"><div class=\"apidoc-icons-img\"><img src=\"/images/help-icon-4.png\" alt=\"Sıkça Sorulan Sorular\"></div><h4>Sıkça Sorulan Sorular</h4></a><p>Sizlerden sıkça gelen sorulan soruları buradan görüntüleyerek, sorularınıza daha hızlı cevap bulabilirsiniz.</p></div><div class=\"apidoc-icons-item\"><a href=\"mailto:techsupport@ideasoft.com.tr\" title=\"Destek Sistemi\"><div class=\"apidoc-icons-img\"><img src=\"/images/help-icon-5.png\" alt=\"Destek Sistemi\"></div><h4>Destek Sistemi</h4></a><p>API ile ilgili tüm sorularınız için bizimle <a href=\"mailto:techsupport@ideasoft.com.tr\">techsupport@ideasoft.com.tr</a> adresimiz üzerinden iletişime geçebilirsiniz. Sizlere yardımcı olmaktan mutluluk duyarız.</p></div></div><p>IdeaSoft API kullanmak için ihtiyaç duyacağınız bilgileri bu dökümanda sizler için topladık. Navigasyon bölmesinden bilgi almak istediğiniz servislere gidebilir örnek istekleri, cevapları ve istek parametrelerini detaylıca görebilirsiniz. Servisin size dönmüş olduğu cevaptaki ilgili nesneyi cevaplar kısmında nesnenin ismine tıklayarak detaylı bir şekilde inceleyebilir her bir özelliğiyle ilgili detaylı açıklamalar bulabilirsiniz.</p>
 *
 */
@Path("/")
@Api(value = "/", description = "")
public interface SpecValueApi  {

    /**
     * Ürün Özellik Değeri Listesi Alma
     *
     * Ürün Özellik Değeri listesini verir.
     *
     */
    @GET
    @Path("/spec_values")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Ürün Özellik Değeri Listesi Alma", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = " listesi alma işlemi (GET) başarı ile sonuçlandı.", response = SpecValue.class),
        @ApiResponse(code = 400, message = "İstek gövdesinin (genellikle json objesi) yapısı bozuk.", response = Error.class),
        @ApiResponse(code = 401, message = "Yetki hatası. Authorization istek başlığı hatalı veya bulunamadı.", response = Error.class),
        @ApiResponse(code = 403, message = "İstemcinin bu operasyona özel gerekli yetkileri yok.", response = Error.class),
        @ApiResponse(code = 404, message = "Talep edilen nesne sunucuda bulunamadı.", response = Error.class),
        @ApiResponse(code = 405, message = "Bu operasyon tipine (GET, POST, PUT veya DELETE) izin verilmiyor.", response = Error.class),
        @ApiResponse(code = 422, message = "Gönderilen nesnede (genellikle validasyonla ilgili) sorun var.", response = Error.class),
        @ApiResponse(code = 429, message = "Belli bir süre içerisinde çok fazla istek yapıldı.", response = Error.class),
        @ApiResponse(code = 500, message = "Sunucuda bir hata oluştu ve istek karşılanamadı.", response = Error.class),
        @ApiResponse(code = 503, message = "Sunucu şu anda hizmet vermiyor (kapalı veya erişilemiyor).", response = Error.class) })
    public SpecValue specValuesGet(@QueryParam("sort")String sort, @QueryParam("limit")@DefaultValue("20") Integer limit, @QueryParam("page")@DefaultValue("1") Integer page, @QueryParam("sinceId")Integer sinceId, @QueryParam("ids")String ids, @QueryParam("name")String name, @QueryParam("specName")Integer specName, @QueryParam("specValue")Integer specValue);

    /**
     * Ürün Özellik Değeri Silme
     *
     * Kalıcı olarak ilgili Ürün Özellik Değerini siler.
     *
     */
    @DELETE
    @Path("/spec_values/{id}")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Ürün Özellik Değeri Silme", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 204, message = "Silme isteği başarı ile sonuçlandı. (cevapta içerik bulunmaz.)", response = .class),
        @ApiResponse(code = 400, message = "İstek gövdesinin (genellikle json objesi) yapısı bozuk.", response = Error.class),
        @ApiResponse(code = 401, message = "Yetki hatası. Authorization istek başlığı hatalı veya bulunamadı.", response = Error.class),
        @ApiResponse(code = 403, message = "İstemcinin bu operasyona özel gerekli yetkileri yok.", response = Error.class),
        @ApiResponse(code = 404, message = "Talep edilen nesne sunucuda bulunamadı.", response = Error.class),
        @ApiResponse(code = 405, message = "Bu operasyon tipine (GET, POST, PUT veya DELETE) izin verilmiyor.", response = Error.class),
        @ApiResponse(code = 422, message = "Gönderilen nesnede (genellikle validasyonla ilgili) sorun var.", response = Error.class),
        @ApiResponse(code = 429, message = "Belli bir süre içerisinde çok fazla istek yapıldı.", response = Error.class),
        @ApiResponse(code = 500, message = "Sunucuda bir hata oluştu ve istek karşılanamadı.", response = Error.class),
        @ApiResponse(code = 503, message = "Sunucu şu anda hizmet vermiyor (kapalı veya erişilemiyor).", response = Error.class) })
    public void specValuesIdDelete(@PathParam("id") Integer id);

    /**
     * Ürün Özellik Değeri Alma
     *
     * İlgili Ürün Özellik Değerini getirir.
     *
     */
    @GET
    @Path("/spec_values/{id}")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Ürün Özellik Değeri Alma", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = " alma işlemi (GET) başarı ile sonuçlandı.", response = SpecValue.class),
        @ApiResponse(code = 400, message = "İstek gövdesinin (genellikle json objesi) yapısı bozuk.", response = Error.class),
        @ApiResponse(code = 401, message = "Yetki hatası. Authorization istek başlığı hatalı veya bulunamadı.", response = Error.class),
        @ApiResponse(code = 403, message = "İstemcinin bu operasyona özel gerekli yetkileri yok.", response = Error.class),
        @ApiResponse(code = 404, message = "Talep edilen nesne sunucuda bulunamadı.", response = Error.class),
        @ApiResponse(code = 405, message = "Bu operasyon tipine (GET, POST, PUT veya DELETE) izin verilmiyor.", response = Error.class),
        @ApiResponse(code = 422, message = "Gönderilen nesnede (genellikle validasyonla ilgili) sorun var.", response = Error.class),
        @ApiResponse(code = 429, message = "Belli bir süre içerisinde çok fazla istek yapıldı.", response = Error.class),
        @ApiResponse(code = 500, message = "Sunucuda bir hata oluştu ve istek karşılanamadı.", response = Error.class),
        @ApiResponse(code = 503, message = "Sunucu şu anda hizmet vermiyor (kapalı veya erişilemiyor).", response = Error.class) })
    public SpecValue specValuesIdGet(@PathParam("id") Integer id);

    /**
     * Ürün Özellik Değeri Güncelleme
     *
     * İlgili Ürün Özellik Değerini günceller.
     *
     */
    @PUT
    @Path("/spec_values/{id}")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Ürün Özellik Değeri Güncelleme", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = " güncelleme işlemi (PUT) başarı ile sonuçlandı.", response = SpecValue.class),
        @ApiResponse(code = 400, message = "İstek gövdesinin (genellikle json objesi) yapısı bozuk.", response = Error.class),
        @ApiResponse(code = 401, message = "Yetki hatası. Authorization istek başlığı hatalı veya bulunamadı.", response = Error.class),
        @ApiResponse(code = 403, message = "İstemcinin bu operasyona özel gerekli yetkileri yok.", response = Error.class),
        @ApiResponse(code = 404, message = "Talep edilen nesne sunucuda bulunamadı.", response = Error.class),
        @ApiResponse(code = 405, message = "Bu operasyon tipine (GET, POST, PUT veya DELETE) izin verilmiyor.", response = Error.class),
        @ApiResponse(code = 422, message = "Gönderilen nesnede (genellikle validasyonla ilgili) sorun var.", response = Error.class),
        @ApiResponse(code = 429, message = "Belli bir süre içerisinde çok fazla istek yapıldı.", response = Error.class),
        @ApiResponse(code = 500, message = "Sunucuda bir hata oluştu ve istek karşılanamadı.", response = Error.class),
        @ApiResponse(code = 503, message = "Sunucu şu anda hizmet vermiyor (kapalı veya erişilemiyor).", response = Error.class) })
    public SpecValue specValuesIdPut(@PathParam("id") Integer id, SpecValue specValue);

    /**
     * Ürün Özellik Değeri Oluşturma
     *
     * Yeni bir Ürün Özellik Değeri oluşturur.
     *
     */
    @POST
    @Path("/spec_values")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Ürün Özellik Değeri Oluşturma", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 201, message = " oluşturma işlemi (POST) başarı ile sonuçlandı.", response = SpecValue.class),
        @ApiResponse(code = 400, message = "İstek gövdesinin (genellikle json objesi) yapısı bozuk.", response = Error.class),
        @ApiResponse(code = 401, message = "Yetki hatası. Authorization istek başlığı hatalı veya bulunamadı.", response = Error.class),
        @ApiResponse(code = 403, message = "İstemcinin bu operasyona özel gerekli yetkileri yok.", response = Error.class),
        @ApiResponse(code = 404, message = "Talep edilen nesne sunucuda bulunamadı.", response = Error.class),
        @ApiResponse(code = 405, message = "Bu operasyon tipine (GET, POST, PUT veya DELETE) izin verilmiyor.", response = Error.class),
        @ApiResponse(code = 422, message = "Gönderilen nesnede (genellikle validasyonla ilgili) sorun var.", response = Error.class),
        @ApiResponse(code = 429, message = "Belli bir süre içerisinde çok fazla istek yapıldı.", response = Error.class),
        @ApiResponse(code = 500, message = "Sunucuda bir hata oluştu ve istek karşılanamadı.", response = Error.class),
        @ApiResponse(code = 503, message = "Sunucu şu anda hizmet vermiyor (kapalı veya erişilemiyor).", response = Error.class) })
    public SpecValue specValuesPost(SpecValue specValue);
}

