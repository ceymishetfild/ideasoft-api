package io.swagger.api;

import io.swagger.model.Error;
import org.joda.time.LocalDate;
import io.swagger.model.Payment;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;
import io.swagger.jaxrs.PATCH;

/**
 * IdeaSoft API
 *
 * <p><div class=\"apidoc-icons\"><div class=\"apidoc-icons-item\"><a href=\"javascript:void(0)\" class=\"faq-button\" title=\"Sıkça Sorulan Sorular\"><div class=\"apidoc-icons-img\"><img src=\"/images/help-icon-4.png\" alt=\"Sıkça Sorulan Sorular\"></div><h4>Sıkça Sorulan Sorular</h4></a><p>Sizlerden sıkça gelen sorulan soruları buradan görüntüleyerek, sorularınıza daha hızlı cevap bulabilirsiniz.</p></div><div class=\"apidoc-icons-item\"><a href=\"mailto:techsupport@ideasoft.com.tr\" title=\"Destek Sistemi\"><div class=\"apidoc-icons-img\"><img src=\"/images/help-icon-5.png\" alt=\"Destek Sistemi\"></div><h4>Destek Sistemi</h4></a><p>API ile ilgili tüm sorularınız için bizimle <a href=\"mailto:techsupport@ideasoft.com.tr\">techsupport@ideasoft.com.tr</a> adresimiz üzerinden iletişime geçebilirsiniz. Sizlere yardımcı olmaktan mutluluk duyarız.</p></div></div><p>IdeaSoft API kullanmak için ihtiyaç duyacağınız bilgileri bu dökümanda sizler için topladık. Navigasyon bölmesinden bilgi almak istediğiniz servislere gidebilir örnek istekleri, cevapları ve istek parametrelerini detaylıca görebilirsiniz. Servisin size dönmüş olduğu cevaptaki ilgili nesneyi cevaplar kısmında nesnenin ismine tıklayarak detaylı bir şekilde inceleyebilir her bir özelliğiyle ilgili detaylı açıklamalar bulabilirsiniz.</p>
 *
 */
@Path("/")
@Api(value = "/", description = "")
public interface PaymentApi  {

    /**
     * Ödeme Listesi Alma
     *
     * Ödeme listesini verir.
     *
     */
    @GET
    @Path("/payments")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Ödeme Listesi Alma", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Payment listesi alma işlemi (GET) başarı ile sonuçlandı.", response = Payment.class),
        @ApiResponse(code = 400, message = "İstek gövdesinin (genellikle json objesi) yapısı bozuk.", response = Error.class),
        @ApiResponse(code = 401, message = "Yetki hatası. Authorization istek başlığı hatalı veya bulunamadı.", response = Error.class),
        @ApiResponse(code = 403, message = "İstemcinin bu operasyona özel gerekli yetkileri yok.", response = Error.class),
        @ApiResponse(code = 404, message = "Talep edilen nesne sunucuda bulunamadı.", response = Error.class),
        @ApiResponse(code = 405, message = "Bu operasyon tipine (GET, POST, PUT veya DELETE) izin verilmiyor.", response = Error.class),
        @ApiResponse(code = 422, message = "Gönderilen nesnede (genellikle validasyonla ilgili) sorun var.", response = Error.class),
        @ApiResponse(code = 429, message = "Belli bir süre içerisinde çok fazla istek yapıldı.", response = Error.class),
        @ApiResponse(code = 500, message = "Sunucuda bir hata oluştu ve istek karşılanamadı.", response = Error.class),
        @ApiResponse(code = 503, message = "Sunucu şu anda hizmet vermiyor (kapalı veya erişilemiyor).", response = Error.class) })
    public Payment paymentsGet(@QueryParam("sort")String sort, @QueryParam("limit")@DefaultValue("20") Integer limit, @QueryParam("page")@DefaultValue("1") Integer page, @QueryParam("sinceId")Integer sinceId, @QueryParam("transactionId")String transactionId, @QueryParam("memberEmail")String memberEmail, @QueryParam("member")Integer member, @QueryParam("status")String status, @QueryParam("paymentTypeName")String paymentTypeName, @QueryParam("startDate")LocalDate startDate, @QueryParam("endDate")String endDate);

    /**
     * Ödeme Silme
     *
     * Kalıcı olarak ilgili Ödemeyi siler.
     *
     */
    @DELETE
    @Path("/payments/{id}")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Ödeme Silme", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 204, message = "Payment silme isteği başarı ile sonuçlandı. (cevapta içerik bulunmaz.)", response = .class),
        @ApiResponse(code = 400, message = "İstek gövdesinin (genellikle json objesi) yapısı bozuk.", response = Error.class),
        @ApiResponse(code = 401, message = "Yetki hatası. Authorization istek başlığı hatalı veya bulunamadı.", response = Error.class),
        @ApiResponse(code = 403, message = "İstemcinin bu operasyona özel gerekli yetkileri yok.", response = Error.class),
        @ApiResponse(code = 404, message = "Talep edilen nesne sunucuda bulunamadı.", response = Error.class),
        @ApiResponse(code = 405, message = "Bu operasyon tipine (GET, POST, PUT veya DELETE) izin verilmiyor.", response = Error.class),
        @ApiResponse(code = 422, message = "Gönderilen nesnede (genellikle validasyonla ilgili) sorun var.", response = Error.class),
        @ApiResponse(code = 429, message = "Belli bir süre içerisinde çok fazla istek yapıldı.", response = Error.class),
        @ApiResponse(code = 500, message = "Sunucuda bir hata oluştu ve istek karşılanamadı.", response = Error.class),
        @ApiResponse(code = 503, message = "Sunucu şu anda hizmet vermiyor (kapalı veya erişilemiyor).", response = Error.class) })
    public void paymentsIdDelete(@PathParam("id") Integer id);

    /**
     * Ödeme Alma
     *
     * İlgili Ödemeyi getirir.
     *
     */
    @GET
    @Path("/payments/{id}")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Ödeme Alma", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Payment alma işlemi (GET) başarı ile sonuçlandı.", response = Payment.class),
        @ApiResponse(code = 400, message = "İstek gövdesinin (genellikle json objesi) yapısı bozuk.", response = Error.class),
        @ApiResponse(code = 401, message = "Yetki hatası. Authorization istek başlığı hatalı veya bulunamadı.", response = Error.class),
        @ApiResponse(code = 403, message = "İstemcinin bu operasyona özel gerekli yetkileri yok.", response = Error.class),
        @ApiResponse(code = 404, message = "Talep edilen nesne sunucuda bulunamadı.", response = Error.class),
        @ApiResponse(code = 405, message = "Bu operasyon tipine (GET, POST, PUT veya DELETE) izin verilmiyor.", response = Error.class),
        @ApiResponse(code = 422, message = "Gönderilen nesnede (genellikle validasyonla ilgili) sorun var.", response = Error.class),
        @ApiResponse(code = 429, message = "Belli bir süre içerisinde çok fazla istek yapıldı.", response = Error.class),
        @ApiResponse(code = 500, message = "Sunucuda bir hata oluştu ve istek karşılanamadı.", response = Error.class),
        @ApiResponse(code = 503, message = "Sunucu şu anda hizmet vermiyor (kapalı veya erişilemiyor).", response = Error.class) })
    public Payment paymentsIdGet(@PathParam("id") Integer id);

    /**
     * Ödeme Güncelleme
     *
     * İlgili Ödemeyi günceller.
     *
     */
    @PUT
    @Path("/payments/{id}")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Ödeme Güncelleme", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Payment güncelleme işlemi (PUT) başarı ile sonuçlandı.", response = Payment.class),
        @ApiResponse(code = 400, message = "İstek gövdesinin (genellikle json objesi) yapısı bozuk.", response = Error.class),
        @ApiResponse(code = 401, message = "Yetki hatası. Authorization istek başlığı hatalı veya bulunamadı.", response = Error.class),
        @ApiResponse(code = 403, message = "İstemcinin bu operasyona özel gerekli yetkileri yok.", response = Error.class),
        @ApiResponse(code = 404, message = "Talep edilen nesne sunucuda bulunamadı.", response = Error.class),
        @ApiResponse(code = 405, message = "Bu operasyon tipine (GET, POST, PUT veya DELETE) izin verilmiyor.", response = Error.class),
        @ApiResponse(code = 422, message = "Gönderilen nesnede (genellikle validasyonla ilgili) sorun var.", response = Error.class),
        @ApiResponse(code = 429, message = "Belli bir süre içerisinde çok fazla istek yapıldı.", response = Error.class),
        @ApiResponse(code = 500, message = "Sunucuda bir hata oluştu ve istek karşılanamadı.", response = Error.class),
        @ApiResponse(code = 503, message = "Sunucu şu anda hizmet vermiyor (kapalı veya erişilemiyor).", response = Error.class) })
    public Payment paymentsIdPut(@PathParam("id") Integer id, Payment payment);

    /**
     * Ödeme Oluşturma
     *
     * Yeni bir Ödeme oluşturur.
     *
     */
    @POST
    @Path("/payments")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Ödeme Oluşturma", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 201, message = "Payment oluşturma işlemi (POST) başarı ile sonuçlandı.", response = Payment.class),
        @ApiResponse(code = 400, message = "İstek gövdesinin (genellikle json objesi) yapısı bozuk.", response = Error.class),
        @ApiResponse(code = 401, message = "Yetki hatası. Authorization istek başlığı hatalı veya bulunamadı.", response = Error.class),
        @ApiResponse(code = 403, message = "İstemcinin bu operasyona özel gerekli yetkileri yok.", response = Error.class),
        @ApiResponse(code = 404, message = "Talep edilen nesne sunucuda bulunamadı.", response = Error.class),
        @ApiResponse(code = 405, message = "Bu operasyon tipine (GET, POST, PUT veya DELETE) izin verilmiyor.", response = Error.class),
        @ApiResponse(code = 422, message = "Gönderilen nesnede (genellikle validasyonla ilgili) sorun var.", response = Error.class),
        @ApiResponse(code = 429, message = "Belli bir süre içerisinde çok fazla istek yapıldı.", response = Error.class),
        @ApiResponse(code = 500, message = "Sunucuda bir hata oluştu ve istek karşılanamadı.", response = Error.class),
        @ApiResponse(code = 503, message = "Sunucu şu anda hizmet vermiyor (kapalı veya erişilemiyor).", response = Error.class) })
    public Payment paymentsPost(Payment payment);
}

