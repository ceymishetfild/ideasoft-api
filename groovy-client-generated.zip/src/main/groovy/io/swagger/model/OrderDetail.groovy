package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Order;
@Canonical
class OrderDetail {

  /* Sipariş detayı nesnesi kimlik değeri. */
  Integer id = null

  /* Sipariş detayı nesnesi için değişken anahtarı. */
  String varKey = null

  /* Sipariş detayı nesnesi için değişken değeri. */
  String varValue = null

  /* Sipariş nesnesi. */
  Order order = null
  

}

