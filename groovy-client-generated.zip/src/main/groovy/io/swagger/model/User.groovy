package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ArrayList;
import io.swagger.model.MemberGroup;
import io.swagger.model.ShopUserlevels;
import java.util.List;
@Canonical
class User {

  /* Yönetici nesnesi kimlik değeri. */
  Integer id = null

  /* Yöneticinin ismi. */
  String firstname = null

  /* Yöneticinin soy ismi. */
  String surname = null

  /* Yöneticinin e-mail adresi. */
  String email = null

  /* Yöneticinin kullanıcı adı. */
  String username = null

  /* Yöneticinin telefon numarası. */
  String phoneNumber = null

  /* Yöneticinin aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br><code>2</code> : Askıya alınmış.<br></div> */
  Integer status = null

  /* Yöneticinin site sahibi olma durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Site sahibi.<br><code>0</code> : Site sahibi değil.<br></div> */
  String isOwner = null

  /* İlgili üye grubu. */
  List<MemberGroup> membergroups = new ArrayList<MemberGroup>()

  /* Yöneticinin SMS verifikasyonu yapılma bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : SMS verifikasyon yapılmış.<br><code>0</code> : SMS verifikasyon yapılmamış.<br></div> */
  String smsApproved = null

    ShopUserlevels userlevel = null
  

}

