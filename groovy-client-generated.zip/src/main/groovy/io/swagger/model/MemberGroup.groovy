package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class MemberGroup {

  /* Üye Grubu nesnesi kimlik değeri. */
  Integer id = null

  /* Üye Grubu nesnesi için isim değeri. */
  String name = null

  /* Üye Grubunun fiyat indisi. Örnek Fiyat 2. */
  Integer priceIndex = null

  /* Üye Grubunun izin verilmiş ödeme kanalları. */
  String allowedPaymentGateways = null
  

}

