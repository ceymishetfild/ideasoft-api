package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.SelectionGroup;
@Canonical
class Selection {

  /* Ek özellik nesnesi kimlik değeri. */
  Integer id = null

  /* Ek özellik nesnesinin başlığı. */
  String title = null

  /* Ek özellik nesnesi için sıralama değeri. */
  Integer sortOrder = null

  /* Ek özellik grubu nesnesi. */
  SelectionGroup selectionGroup = null
  

}

