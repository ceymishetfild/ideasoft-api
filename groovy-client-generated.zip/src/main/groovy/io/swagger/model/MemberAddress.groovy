package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Country;
import io.swagger.model.Date;
import io.swagger.model.Location;
import io.swagger.model.Member;
import io.swagger.model.Town;
@Canonical
class MemberAddress {

  /* Üye adresi nesnesinin benzersiz rakamsal kimlik değeri. */
  Integer id = null

  /* Üye Adresi adı. */
  String name = null

  /* Üye Adresi tipi.<div class='idea_choice_list'><code>shipping</code> : Teslimat adresi.<br><code>billing</code> : Fatura adresi.<br></div> */
  String type = null

  /* Üyenin ismi. */
  String firstname = null

  /* Üyenin soy ismi. */
  String surname = null

  /* Üyenin adres bilgileri. */
  String address = null

  /* İlçe adı. */
  String subLocationName = null

  /* Üyenin telefon numarası. */
  String phoneNumber = null

  /* Üyenin mobil telefon numarası. */
  String mobilePhoneNumber = null

  /* Üyenin TC kimlik numarası. */
  String tcId = null

  /* Üyenin vergi numarası. */
  String taxNumber = null

  /* Üyenin vergi dairesi. */
  String taxOffice = null

  /* Fatura tipini belirtir.<div class='idea_choice_list'><code>individual</code> : Bireysel<br><code>corporate</code> : Kurumsal<br></div> */
  String invoiceType = null

  /* Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div> */
  Boolean isEinvoiceUser = null

  /* Tema nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Tema nesnesinin güncellenme zamanı. */
  Date updatedAt = null

    Member member = null

    Country country = null

    Location location = null

    Town subLocation = null
  

}

