package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Date;
import io.swagger.model.Member;
import io.swagger.model.Product;
@Canonical
class ProductComment {

  /* Ürün yorumu nesnesi kimlik değeri. */
  Integer id = null

  /* Ürün yorumu başlığı. */
  String title = null

  /* Ürün yorumu içeriği. */
  String content = null

  /* Ürün yorumu durumu.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div> */
  Boolean status = null

  /* Ürün yorumunda ürüne verilen puan.<div class='idea_choice_list'><code>1</code> : 1 puan.<br><code>2</code> : 2 puan.<br><code>3</code> : 3 puan.<br><code>4</code> : 4 puan.<br><code>5</code> : 5 puan.<br></div> */
  Integer rank = null

  /* Ürün yorumu yapan kişinin anonim olup olmadığı bilgisi.<div class='idea_choice_list'><code>1</code> : Anonim.<br><code>0</code> : Anonim değil.<br></div> */
  Boolean isAnonymous = null

  /* Ürün yorumu nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Ürün yorumu nesnesinin güncellenme zamanı. */
  Date updatedAt = null

  /* Yorumu yapan üye. */
  Member member = null

  /* Yorum yapılan ürün. */
  Product product = null
  

}

