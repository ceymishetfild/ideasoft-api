package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class OrderItemCustomization {

  /* Sipariş kalemi özelleştirme kimlik değeri. */
  Integer id = null

  /* Ürün özelleştirme grubu nesnesi kimlik değeri. */
  Integer productCustomizationGroupId = null

  /* Ürün özelleştirme grubu nesnesinin grup adı. */
  String productCustomizationGroupName = null

  /* Ürün özelleştirme grubu nesnesinin sıralaması. */
  Integer productCustomizationGroupSortOrder = null

  /* Ürün özelleştirme nesnesi kimlik değeri.. */
  Integer productCustomizationFieldId = null

  /* Ürün özelleştirme nesnesinin alan tipi. */
  String productCustomizationFieldType = null

  /* Ürün özelleştirme nesnesinin alan adı. */
  String productCustomizationFieldName = null

  /* Ürün özelleştirme nesnesinin değeri. */
  String productCustomizationFieldValue = null

  /* Sepet kalemi özelliği nesnesi kimlik değeri. */
  Integer cartItemAttributeId = null
  

}

