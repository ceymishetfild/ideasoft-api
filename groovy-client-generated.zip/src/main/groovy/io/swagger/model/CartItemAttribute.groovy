package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.CartItem;
import io.swagger.model.Date;
@Canonical
class CartItemAttribute {

  /* Sepet kalemi özelliği nesnesi kimlik değeri. */
  Integer id = null

  /* Sepet kalemi özelliği nesnesinin isim değeri. Örneğin, sepet kalemi kalem ise bu değer renk olabilir. */
  String name = null

  /* Sepet kalemi özelliği nesnesinin değeri. Örneğin, sepet kalemi kalem, isim değeri renk ise bu değer kırmızı olabilir. */
  String value = null

  /* Sepet kalemi özelliği nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Sepet kalemi nesnesi. */
  CartItem cartItem = null
  

}

