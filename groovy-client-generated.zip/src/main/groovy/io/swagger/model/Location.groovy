package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Country;
import io.swagger.model.Region;
@Canonical
class Location {

  /* Şehir nesnesi kimlik değeri. */
  Integer id = null

  /* Şehir nesnesi için isim değeri. */
  String name = null

  /* Şehir nesnesinin aktiflik durumunu belirten değer. */
  String status = null

  /* Şehir nesnesinin öntanımlı olup olmadığını belirtir.<div class='idea_choice_list'><code>1</code> : Öntanımlı şehir.<br><code>0</code> : Yeni eklenmiş şehir.<br></div> */
  String predefined = null

    Country country = null

    Region region = null
  

}

