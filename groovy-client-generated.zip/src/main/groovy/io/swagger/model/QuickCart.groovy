package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class QuickCart {

  /* Hızlı satın al bağlantısı nesnesi kimlik değeri. */
  Integer id = null

  /* Hızlı satın al bağlantısı nesnesi için isim değeri. */
  String name = null

  /* Hızlı satın al bağlantısı url'si. */
  String url = null

  /* Hızlı satın al bağlantısı için kısaltılmış url. */
  String shortUrl = null
  

}

