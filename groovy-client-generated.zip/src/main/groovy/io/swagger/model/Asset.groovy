package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Date;
@Canonical
class Asset {

  /* Tema Dosyası nesnesi anahtar değeri. */
  String key = null

  /* Tema Dosyası içerik tipi. Geçerli bir MIME Content-Type verilmelidir. */
  String contentType = null

  /* Tema Dosyası içeriği. */
  String attachment = null

  /* Tema Dosyası nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Tema Dosyası nesnesinin güncellenme zamanı. */
  Date updatedAt = null
  

}

