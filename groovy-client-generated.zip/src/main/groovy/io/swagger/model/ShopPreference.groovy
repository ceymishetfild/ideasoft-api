package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class ShopPreference {

  /* Tanımlama nesnesi kimlik değeri. */
  Integer id = null

  /* Tanımlama nesnesi için değişken anahtarı. */
  String varKey = null

  /* Tanımlama nesnesi için değişken değeri. */
  String varValue = null
  

}

