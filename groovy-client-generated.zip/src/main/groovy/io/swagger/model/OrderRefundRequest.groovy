package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Date;
import io.swagger.model.Member;
import io.swagger.model.Order;
@Canonical
class OrderRefundRequest {

  /* Sipariş iptal talebi nesnesi kimlik değeri. */
  Integer id = null

  /* Sipariş iptal talebi için oluşturulan benzersiz kod değeri. */
  String code = null

  /* Sipariş iptal talebi için durum bilgisi.<div class='idea_choice_list'><code>approved</code> : Onaylandı.<br><code>waiting_for_approval</code> : Onay bekliyor.<br><code>cancelled</code> : İptal edildi.<br></div> */
  String status = null

  /* Müşteriye ödenecek miktar bilgisi. */
  Float fee = null

  /* Sipariş iptal talebinin oluşturulması sebebinin detaylı açıklaması. */
  String cancellationReason = null

  /* Sipariş iptal talebi nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Sipariş iptal talebi nesnesinin güncellenme zamanı. */
  Date updatedAt = null

    Member member = null

    Order order = null
  

}

