package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ArrayList;
import io.swagger.model.PaymentGatewaySetting;
import io.swagger.model.PaymentProvider;
import java.util.List;
@Canonical
class PaymentGateway {

  /* Ödeme kanalı nesnesi kimlik değeri. */
  Integer id = null

  /* Ödeme kanalı için ön tanımlanmış kod değeri. */
  String code = null

  /* Ödeme kanalı nesnesi için isim değeri. */
  String name = null

  /* Ödeme kanalının aktiflik durumu.<div class='idea_choice_list'><code>active</code> : Aktif<br><code>passive</code> : Pasif<br></div> */
  String status = null

  /* Ödeme kanalı nesnesi için sıralama değeri. */
  Integer sortOrder = null

    PaymentProvider paymentProvider = null

  /* Ödeme kanalı ayarları. */
  List<PaymentGatewaySetting> settings = new ArrayList<PaymentGatewaySetting>()
  

}

