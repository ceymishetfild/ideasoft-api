package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Date;
import io.swagger.model.Order;
@Canonical
class OrderUserNote {

  /* Sipariş yönetici notu nesnesi kimlik değeri. */
  Integer id = null

  /* Yöneticinin(admin) e-mail adresi. */
  String userEmail = null

  /* Yöneticinin(admin) ismi. */
  String userFirstname = null

  /* Yöneticinin(admin) soy ismi. */
  String userSurname = null

  /* Yöneticinin(admin) sipariş için girdiği not. */
  String note = null

  /* Sipariş yönetici notu nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Sipariş yönetici notu nesnesinin güncellenme zamanı. */
  Date updatedAt = null

  /* Sipariş nesnesi. */
  Order order = null
  

}

