package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.OptionGroup;
@Canonical
class Options {

  /* Varyant nesnesi kimlik değeri. */
  Integer id = null

  /* Varyant başlığı. Varyant Grubu renk is bu değer kırmızı olabilir. */
  String title = null

  /* Varyant nesnesi için sıralama değeri. */
  Integer sortOrder = null

  /* Logo görselinin adı.<div class='idea_choice_list'><code>jpg</code> : jpg dosyası için geçerli uzantı.<br><code>png</code> : png dosyası için geçerli uzantı.<br><code>gif</code> : gif dosyası için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyası için geçerli uzantı.<br></div> */
  String logo = null

  /* Varyant grubu nesnesi. */
  OptionGroup optionGroup = null

  /* Varyant nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. */
  String attachment = null
  

}

