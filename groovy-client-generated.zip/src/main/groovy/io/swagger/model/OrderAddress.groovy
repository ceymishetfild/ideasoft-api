package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Order;
@Canonical
class OrderAddress {

  /* Sipariş adresi nesnesi kimlik değeri. */
  Integer id = null

  /* Müşterinin ismi. */
  String firstname = null

  /* Müşterinin soy ismi. */
  String surname = null

  /* Müşterinin ülke bilgisi. */
  String country = null

  /* Müşterinin şehir bilgisi. */
  String location = null

  /* Müşterinin ilçe bilgisi. */
  String subLocation = null

  /* Müşterinin adres bilgisi. */
  String address = null

  /* Müşterinin telefon numarası. */
  String phoneNumber = null

  /* Müşterinin mobil telefon numarası. */
  String mobilePhoneNumber = null

  /* Sipariş nesnesi. */
  Order order = null
  

}

