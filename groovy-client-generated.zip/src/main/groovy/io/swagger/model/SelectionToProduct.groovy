package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Product;
import io.swagger.model.Selection;
@Canonical
class SelectionToProduct {

  /* Ek özellik ürün bağı nesnesi kimlik değeri. */
  Integer id = null

    Selection selection = null

    Product product = null
  

}

