package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Country;
import io.swagger.model.Date;
import io.swagger.model.Location;
import io.swagger.model.Member;
import io.swagger.model.MemberGroup;
@Canonical
class Member {

  /* Üye nesnesi kimlik değeri. */
  Integer id = null

  /* Üyenin ismi. */
  String firstname = null

  /* Üyenin soy ismi. */
  String surname = null

  /* Üyenin e-mail adresi. */
  String email = null

  /* Üyenin cinsiyet bilgisi.<div class='idea_choice_list'><code>male</code> : Erkek<br><code>female</code> : Kadın<br></div> */
  String gender = null

  /* Üyenin doğum tarihi. */
  Date birthDate = null

  /* Üyenin telefon numarası. */
  String phoneNumber = null

  /* Üyenin mobil telefon numarası. */
  String mobilePhoneNumber = null

  /* Üyenin diğer şehir bilgileri. */
  String otherLocation = null

  /* Üyenin adres bilgileri. */
  String address = null

  /* Üyenin vergi numarası. */
  String taxNumber = null

  /* Üyenin TC kimlik numarası. */
  String tcId = null

  /* Üyenin durum bilgisi.<div class='idea_choice_list'><code>queue</code> : Sırada<br><code>active</code> : Aktif<br><code>passive</code> : Pasif<br><code>suspended</code> : Askıda<br></div> */
  String status = null

  /* Üyenin son giriş yaptığı tarih. */
  Date lastLoginDate = null

  /* Üye nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Üye nesnesinin güncellenme zamanı. */
  Date updatedAt = null

  /* Üyenin posta kodu. */
  String zipCode = null

  /* Üyenin kurumsal adı. */
  String commercialName = null

  /* Üyenin vergi dairesi. */
  String taxOffice = null

  /* Üyeye gönderilen son e-mail tarihi. */
  Date lastMailSentDate = null

  /* Üyenin en son giriş yaptığı IP adresi. */
  String lastIp = null

  /* Üyenin kazandığı puan tutarı. */
  Float gainedPointAmount = null

  /* Üyenin harcadığı puan tutarı. */
  Float spentPointAmount = null

  /* Üyenin kampanyalara katılım için izin durumu.<div class='idea_choice_list'><code>1</code> : Kampanyalar için izinli.<br><code>0</code> : Kampanyalar için izinsiz.<br></div> */
  String allowedToCampaigns = null

  /* Üyenin tavsiye ettiği kişilerden dolayı kazandığı puan. */
  Float referredMemberGainedPointAmount = null

  /* Üyenin ilçesi. */
  String district = null

  /* Üyenin kullandığı cihaz tipi. */
  String deviceType = null

  /* Üyenin kullandığı cihaz bilgisi. */
  String deviceInfo = null

    Country country = null

    Location location = null

    MemberGroup memberGroup = null

    Member referredMember = null
  

}

