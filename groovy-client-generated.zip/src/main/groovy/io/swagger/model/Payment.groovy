package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Date;
import io.swagger.model.Member;
@Canonical
class Payment {

  /* Ödeme nesnesi kimlik değeri. */
  Integer id = null

  /* Üyenin ismi. */
  String memberFirstname = null

  /* Üyenin soy ismi. */
  String memberSurname = null

  /* Üyenin e-mail adresi. */
  String memberEmail = null

  /* Üyenin telefon numarası. */
  String memberPhone = null

  /* Ödeme tipi */
  String paymentTypeName = null

  /* Ödeme hizmeti sağlayıcısı kodu. Bu değer ön tanımlıdır. */
  String paymentProviderCode = null

  /* Ödeme hizmeti sağlayıcısı adı. Bu değer ön tanımlıdır. */
  String paymentProviderName = null

  /* Ödeme kanalı adı. Bu değer ön tanımlıdır. */
  String paymentGatewayName = null

  /* Ödeme kanalı kodu. Bu değer ön tanımlıdır. */
  String paymentGatewayCode = null

  /* Ödeme yapılan banka. Bu değer ön tanımlıdır. */
  String bankName = null

  /* Ödemenin gerçekleştiği cihaz bilgisi.<div class='idea_choice_list'><code>desktop</code> : Masaüstü<br><code>mobile</code> : Mobil<br><code>tablet</code> : Tablet<br></div> */
  String deviceType = null

  /* Müşterinin IP adresi. */
  String clientIp = null

  /* Kur oranları. */
  String currencyRates = null

  /* Ödemenin saf fiyatı. */
  Float amount = null

  /* Ödemenin son fiyatı. */
  Float finalAmount = null

  /* Ödemeden kazanılan toplam puan. */
  Float sumOfGainedPoints = null

  /* Ödemenin standart taksit sayısı. */
  Integer installment = null

  /* Ödemenin taksit oranı. */
  Float installmentRate = null

  /* Ödemenin ekstra taksit sayısı. */
  Integer extraInstallment = null

  /* Kur bilgisi. */
  String currency = null

  /* Siparişin numarası. */
  String transactionId = null

  /* Müşterinin ödeme notu. */
  String memberNote = null

  /* Yönetici(admin) ödeme notu. */
  String userNote = null

  /* Ödeme durumu.<div class='idea_choice_list'><code>deleted</code> : Silindi<br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br><code>failed</code> : Hatalı Ödemeler<br><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br></div> */
  String status = null

  /* Ödemenin hata mesajı. */
  String errorMessage = null

  /* Kart saklama sistemi. */
  String cardSavingSystem = null

  /* Ödeme nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Üye nesnesi. */
  Member member = null
  

}

