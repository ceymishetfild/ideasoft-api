package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ExtraInfo;
import io.swagger.model.Product;
@Canonical
class ExtraInfoToProduct {

  /* Ek bilgi ürün bağı nesnesi kimlik değeri. */
  Integer id = null

  /* Ek bilgi ürün bağı değeridir. Ek bilgi renk ise bu değer kırmızı olabilir. */
  String value = null

    ExtraInfo extraInfo = null

    Product product = null
  

}

