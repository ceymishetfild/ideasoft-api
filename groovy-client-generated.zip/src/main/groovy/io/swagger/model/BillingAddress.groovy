package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.model.Order;
import io.swagger.model.OrderAddress;
@Canonical
class BillingAddress {
  

}

