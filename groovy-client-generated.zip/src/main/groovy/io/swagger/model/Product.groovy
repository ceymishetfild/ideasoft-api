package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ArrayList;
import io.swagger.model.Brand;
import io.swagger.model.Currency;
import io.swagger.model.Date;
import io.swagger.model.Product;
import io.swagger.model.ProductImage;
import io.swagger.model.ProductPrice;
import io.swagger.model.ProductToCategory;
import io.swagger.model.ProductToCountDown;
import java.util.List;
@Canonical
class Product {

  /* Ürün nesnesi kimlik değeri. */
  Integer id = null

  /* Ürünün adı */
  String name = null

  /* Slug değeri ilgili nesnenin Url değeridir. */
  String slug = null

  /* Ürünün tam adı. Bu değer bir varyant için ana ürünün adı ve varyant adının birleşiminden oluşur. Örneğin Kırmızı varyantı için Kalem Kırmızı olur. */
  String fullName = null

  /* Ürünün stok kodu. ID değeri gibi eşsiz bir kimlik değeridir. */
  String sku = null

  /* Ürünün barkodu. */
  String barcode = null

  /* Ürünün Fiyat 1 bilgisi. */
  Float price1 = null

  /* Ürünün garanti süresi. */
  Integer warranty = null

  /* Ürünün KDV oranı. */
  Integer tax = null

  /* Ürünün stok tipi cinsinden miktarı. */
  Float stockAmount = null

  /* Ürünün desisi. */
  Float volumetricWeight = null

  /* Ürünün alış fiyatı. */
  Float buyingPrice = null

  /* Ürünün stok tipi.<div class='idea_choice_list'><code>Piece</code> : Stok tipi birimi Adet<br><code>cm</code> : Stok tipi birimi Santimetre<br><code>Dozen</code> : Stok tipi birimi Düzine<br><code>gram</code> : Stok tipi birimi Gram<br><code>kg</code> : Stok tipi birimi Kilogram<br><code>Person</code> : Stok tipi birimi Kişi<br><code>Package</code> : Stok tipi birimi Paket<br><code>metre</code> : Stok tipi birimi Metre<br><code>m2</code> : Stok tipi birimi Metrekare<br><code>pair</code> : Stok tipi birimi Çift<br></div> */
  String stockTypeLabel = null

  /* Ürünün indirim değeri. Örneğin; discountType 1 olursa %5, 0 olursa 5 tl anlamına gelir. */
  Float discount = null

  /* Ürünün indirim tipini belirtir.<div class='idea_choice_list'><code>1</code> : İndirim yüzdesi<br><code>0</code> : İndirimli fiyat<br></div> */
  Integer discountType = null

  /* Havale indirimi yüzdesi. */
  Float moneyOrderDiscount = null

  /* Ürün nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif<br><code>0</code> : Pasif<br></div> */
  Integer status = null

  /* Ürün fiyatlarına KDV dahil olup olmadığın belirten değer.<div class='idea_choice_list'><code>1</code> : KDV Dahil<br><code>0</code> : KDV Hariç<br></div> */
  String taxIncluded = null

  /* Ürünün distribütör bilgisi */
  String distributor = null

  /* Ürünün hediyeli olup olmadığını belirtir.<div class='idea_choice_list'><code>1</code> : Hediyeli<br><code>0</code> : Hediyeli Değil<br></div> */
  String isGifted = null

  /* Ürünün yanında hediye olarak vermek istediğiniz hediyeyi bu alanda metin ya da rakamla belirtebilirsiniz. */
  String gift = null

  /* Kargo ücreti için sistemin kullanılıp kullanılmama değerini belirtir.<div class='idea_choice_list'><code>1</code> : Sistem seçeneği seçili<br><code>0</code> : Sistem seçeneği seçili değil<br></div> */
  String customShippingDisabled = null

  /* Sistem seçeneği seçilmemişse ürün için girilmesi gereken kargo ücreti. */
  Float customShippingCost = null

  /* Ürünün piyasa fiyatı */
  String marketPriceDetail = null

  /* Ürün nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Ürün nesnesinin güncellenme zamanı. */
  Date updatedAt = null

  /* Arama motorları tarafından tespit edilebilecek anahtar kelimeler. */
  String metaKeywords = null

  /* Arama motorları tarafından tespit edilebilecek açıklama yazısı. */
  String metaDescription = null

  /* Ürün nesnesinin etiket başlığı. */
  String pageTitle = null

  /* Ürünün varyantının olup olmadığı değerini belirtir. (API otomatik olarak bu değeri atar.)<div class='idea_choice_list'><code>1</code> : Varyantı var<br><code>0</code> : Varyantı yok<br></div> */
  String hasOption = null

  /* Ürünün kısa açıklaması. */
  String shortDetails = null

  /* Ziyaretçilerinizin site içindeki ürünlerinizin hangi anahtar kelimelerine göre bulacağını belirler.Kelimeler arasında virgül bırakılarak girilmelidir.(etiket1,etiket2) */
  String searchKeywords = null

  /* Ürüne özel yasal veya isteğe bağlı belirleyebiliceğiniz taksit adedini belirtir. Ürüne özel bir belirleme yapmak istemiyorsanız '-' işareti kullanabilirsiniz. */
  String installmentThreshold = null

  /* Anasayfa vitrini sırası. */
  Integer homeSortOrder = null

  /* Popüler ürünler vitrini sırası. */
  Integer popularSortOrder = null

  /* Marka vitrini sırası. */
  Integer brandSortOrder = null

  /* Sponsor ürünler vitrini sırası */
  Integer featuredSortOrder = null

  /* Kampanyalı ürünler vitrini sırası. */
  Integer campaignedSortOrder = null

  /* Yeni ürünler vitrini sırası. */
  Integer newSortOrder = null

  /* İndirimli ürünler vitrini sırası */
  Integer discountedSortOrder = null

    Brand brand = null

    Currency currency = null

    Product parent = null

    ProductToCountDown countdown = null

  /* Ürünün fiyatları. */
  List<ProductPrice> prices = new ArrayList<ProductPrice>()

  /* Ürünün resimleri. */
  List<ProductImage> images = new ArrayList<ProductImage>()

  /* Ürünün kategorileri. */
  List<ProductToCategory> productToCategories = new ArrayList<ProductToCategory>()
  

}

