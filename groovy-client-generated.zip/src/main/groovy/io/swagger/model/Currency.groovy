package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Date;
@Canonical
class Currency {

  /* Kur nesnesi kimlik değeri. */
  Integer id = null

  /* Kur etiketi. */
  String label = null

  /* Kurun alış fiyatı. */
  Float buyingPrice = null

  /* Kurun satış fiyatı. */
  Float sellingPrice = null

  /* Kurun kısaltması. */
  String abbr = null

  /* Kur nesnesinin güncellenme zamanı. */
  Date updatedAt = null

  /* Kur nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div> */
  String status = null

  /* Kurun birincil kur olup olmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Birincil kur.<br><code>0</code> : Birincil kur değil.<br></div> */
  String isPrimary = null
  

}

