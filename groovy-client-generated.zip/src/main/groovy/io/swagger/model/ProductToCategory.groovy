package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Category;
import io.swagger.model.Product;
@Canonical
class ProductToCategory {

  /* Ürün kategori bağı nesnesi kimlik değeri. */
  Integer id = null

  /* Ürün kategori bağının sıralama değeri. Özel sıra belirtmek istemiyorsanız 9999 olarak iletebilirsiniz. */
  Integer sortOrder = null

  /* Ürün nesnesi. */
  Product product = null

  /* Kategori nesnesi. */
  Category category = null
  

}

