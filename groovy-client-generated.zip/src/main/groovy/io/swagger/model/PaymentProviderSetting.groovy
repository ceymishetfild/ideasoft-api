package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class PaymentProviderSetting {

  /* Ödeme altyapısı sağlayıcısı ayarı nesnesi kimlik değeri. */
  Integer id = null

  /* Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken anahtarı. */
  String varKey = null

  /* Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken değeri. */
  String varValue = null
  

}

