package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.PaymentGateway;
@Canonical
class PaymentGatewaySetting {

  /* Ödeme kanalı ayarı nesnesi kimlik değeri. */
  Integer id = null

  /* Ödeme kanalı ayarı nesnesi için değişken anahtarı. */
  String varKey = null

  /* Ödeme kanalı ayarı nesnesi için değişken değeri. */
  String varValue = null

    PaymentGateway paymentGateway = null
  

}

