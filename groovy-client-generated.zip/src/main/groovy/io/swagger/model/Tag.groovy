package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class Tag {

  /* SEO+ etiketi nesnesi kimlik değeri. */
  Integer id = null

  /* SEO+ etiketi nesnesi için isim değeri. */
  String name = null

  /* SEO+ etiketinin kaç kez kullanıldığı bilgisi. */
  Integer count = null

  /* SEO+ etiketi nesnesinin etiket başlığı. */
  String pageTitle = null

  /* Arama motorları tarafından tespit edilebilecek açıklama yazısı. */
  String metaDescription = null

  /* Arama motorları tarafından tespit edilebilecek anahtar kelimeler. */
  String metaKeywords = null
  

}

