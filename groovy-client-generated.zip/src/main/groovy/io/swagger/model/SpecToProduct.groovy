package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Product;
import io.swagger.model.SpecGroup;
import io.swagger.model.SpecName;
import io.swagger.model.SpecValue;
@Canonical
class SpecToProduct {

  /* Ürün özellik ürün bağı nesnesi kimlik değeri. */
  Integer id = null

    Product product = null

    SpecGroup specGroup = null

    SpecName specName = null

    SpecValue specValue = null
  

}

