package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class Error {

  /* HTTP Hata kodu. */
  Integer code = null

  /* Hata mesajı. Hata mesajları İngilizce dilindedir. */
  String errorMessage = null

  /* Hata kodu. Eğer ek bir hata kodu varsa bu alanda belirtilir. */
  Integer errorCode = null
  

}

