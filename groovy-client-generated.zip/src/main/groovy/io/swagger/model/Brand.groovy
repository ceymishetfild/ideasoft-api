package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Date;
@Canonical
class Brand {

  /* Marka nesnesi kimlik değeri. */
  Integer id = null

  /* Marka nesnesi için isim değeri. */
  String name = null

  /* Slug değeri ilgili nesnenin Url değeridir. */
  String slug = null

  /* Marka nesnesi için sıralama değeri. */
  Integer sortOrder = null

  /* Marka nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div> */
  String status = null

  /* Markanın tedarikçisi. */
  String distributor = null

  /* Marka nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF */
  String imageFile = null

  /* Marka nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir. */
  String showcaseContent = null

  /* Marka nesnesi üst içerik metninin gösterim durumu. */
  String displayShowcaseContent = null

  /* Arama motorları tarafından tespit edilebilecek anahtar kelimeler. */
  String metaKeywords = null

  /* Arama motorları tarafından tespit edilebilecek açıklama yazısı. */
  String metaDescription = null

  /* Marka nesnesinin etiket başlığı. */
  String pageTitle = null

  /* Marka nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. */
  String attachment = null

  /* Marka nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Marka nesnesinin güncellenme zamanı. */
  Date updatedAt = null
  

}

