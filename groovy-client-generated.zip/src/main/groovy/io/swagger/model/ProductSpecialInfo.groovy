package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Product;
@Canonical
class ProductSpecialInfo {

  /* Özel bilgi alanı nesnesi kimlik değeri. */
  Integer id = null

  /* Özel bilgi alanı başlığı. */
  String title = null

  /* Özel bilgi alanı içeriği. */
  String content = null

  /* Özel bilgi alanı aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div> */
  Integer status = null

    Product product = null
  

}

