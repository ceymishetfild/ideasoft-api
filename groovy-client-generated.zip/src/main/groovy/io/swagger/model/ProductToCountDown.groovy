package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Date;
import io.swagger.model.Product;
@Canonical
class ProductToCountDown {

  /* Ürün geri sayım bağı nesnesi kimlik değeri. */
  Integer id = null

  /* Geri sayımın başlangıç tarihi. */
  Date startDate = null

  /* Geri sayımın bitiş tarihi. */
  Date endDate = null

  /* Geri sayımın ürün için geçersiz olma tarihi. */
  Date expireDate = null

  /* Geri sayımın aktiflik durumu bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div> */
  String useCountDown = null

  /* Ürün nesnesi. */
  Product product = null
  

}

