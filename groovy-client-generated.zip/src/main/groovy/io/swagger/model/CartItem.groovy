package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ArrayList;
import io.swagger.model.Cart;
import io.swagger.model.CartItemAttribute;
import io.swagger.model.Date;
import io.swagger.model.Product;
import java.util.List;
@Canonical
class CartItem {

  /* Sepet kalemi nesnesi kimlik değeri. */
  Integer id = null

  /* Ana ürünün benzersiz rakamsal kimlik değeri. */
  Integer parentProductId = null

  /* Sepetteki kalem adedi. */
  Float quantity = null

  /* Sepetteki kaleme ait kategorinin benzersiz kimlik değeri. */
  Integer categoryId = null

  /* Sepet kalemi nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Sepet kalemi nesnesinin güncellenme zamanı. */
  Date updatedAt = null

  /* Sepet nesnesi. */
  Cart cart = null

  /* Ürün nesnesi. */
  Product product = null

  /* Sepet kalemi özelliği barındıran liste. */
  List<CartItemAttribute> attributes = new ArrayList<CartItemAttribute>()
  

}

