package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.PaymentGateway;
@Canonical
class InstallmentRate {

  /* Taksit oranı nesnesi kimlik değeri. */
  Integer id = null

  /* Taksit adeti. */
  Integer installment = null

  /* Taksit adeti için oran bilgisi. */
  Float rate = null

    PaymentGateway paymentGateway = null
  

}

