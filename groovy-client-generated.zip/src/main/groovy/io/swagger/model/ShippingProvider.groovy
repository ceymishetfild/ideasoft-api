package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ArrayList;
import io.swagger.model.ShippingProviderSetting;
import java.util.List;
@Canonical
class ShippingProvider {

  /* Teslimat hizmeti sağlayıcısı nesnesi kimlik değeri. */
  Integer id = null

  /* Teslimat hizmeti sağlayıcısı kodu. Benzersiz olmalıdır. */
  String code = null

  /* Teslimat hizmeti sağlayıcısı nesnesi için isim değeri. */
  String name = null

  /* Kargo takip url. */
  String trackingUrl = null

  /* Kargo takip formu almak için kullanılacak method.<div class='idea_choice_list'><code>get</code> : GET methodu.<br><code>post</code> : POST methodu.<br></div> */
  String trackingFormMethod = null

  /* İlgili kargo takip formu almak için kullanılacak yük. */
  String payload = null

  /* Teslimat hizmeti sağlayıcısı için ayarlar. */
  List<ShippingProviderSetting> settings = new ArrayList<ShippingProviderSetting>()
  

}

