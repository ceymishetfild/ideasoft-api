package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Distributor;
import io.swagger.model.Product;
@Canonical
class DistributorToProduct {

  /* Distribütor ürün bağı nesnesi kimlik değeri. */
  Integer id = null

  /* The description of the Distributor. */
  Distributor distributor = null

  /* The description of the Product. */
  Product product = null
  

}

