package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ArrayList;
import io.swagger.model.PaymentProviderSetting;
import io.swagger.model.PaymentType;
import java.util.List;
@Canonical
class PaymentProvider {

  /* Ödeme altyapısı sağlayıcısı nesnesi kimlik değeri. */
  Integer id = null

  /* Ödeme altyapısı sağlayıcısı için ön tanımlanmış kod değeri. */
  String code = null

  /* Ödeme altyapısı sağlayıcısı için isim değeri. */
  String name = null

  /* Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer. */
  String status = null

    PaymentType paymentType = null

  /* Ödeme altyapısı sağlayıcısı ayarları */
  List<PaymentProviderSetting> settings = new ArrayList<PaymentProviderSetting>()
  

}

