package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Country;
import io.swagger.model.Date;
import io.swagger.model.Location;
import io.swagger.model.MemberAddress;
import io.swagger.model.ShippingCompany;
@Canonical
class PreOrderInfo {

  /* Sipariş öncesi bilgisi nesnesi kimlik değeri. */
  Integer id = null

  /* Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri. */
  String sessionId = null

  /* Müşterinin ismi. */
  String customerFirstname = null

  /* Müşterinin soy ismi. */
  String customerSurname = null

  /* Müşterinin e-mail adresi. */
  String customerEmail = null

  /* Teslimat yapılacak kişinin ismi. */
  String shippingFirstname = null

  /* Teslimat yapılacak kişinin soy ismi. */
  String shippingSurname = null

  /* Teslimat adresi bilgileri. */
  String shippingAddress = null

  /* Teslimat yapılacak kişinin telefon numarası. */
  String shippingPhoneNumber = null

  /* Teslimat yapılacak kişinin mobil telefon numarası. */
  String shippingMobilePhoneNumber = null

  /* Teslimat şehri. */
  String shippingLocationName = null

  /* Teslimat ilçesi. */
  String shippingTown = null

  /* Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.<div class='idea_choice_list'><code>1</code> : Var<br><code>0</code> : Yok<br></div> */
  String differentBillingAddress = null

  /* Fatura kesilen kişinin ismi. */
  String billingFirstname = null

  /* Fatura kesilen kişinin soy ismi. */
  String billingSurname = null

  /* Fatura adresi bilgileri. */
  String billingAddress = null

  /* Fatura kesilen kişinin telefon numarası. */
  String billingPhoneNumber = null

  /* Fatura kesilen kişinin mobil telefon numarası. */
  String billingMobilePhoneNumber = null

  /* Fatura adresi şehri */
  String billingLocationName = null

  /* Fatura adresi ilçesi. */
  String billingTown = null

  /* Fatura tipini belirtir.<div class='idea_choice_list'><code>individual</code> : Bireysel<br><code>corporate</code> : Kurumsal<br></div> */
  String billingInvoiceType = null

  /* Fatura kesilen kişinin TC kimlik numarası. */
  String billingIdentityRegistrationNumber = null

  /* Fatura kesilen kişi/kurumun vergi dairesi. */
  String billingTaxOffice = null

  /* Fatura kesilen kişi/kurum vergi numarası. */
  String billingTaxNo = null

  /* Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div> */
  String isEinvoiceUser = null

  /* Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div> */
  String useGiftPackage = null

  /* Hediye notu bilgisi. */
  String giftNote = null

  /* Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif */
  String imageFile = null

  /* Müşterinin teslimatın gerçekleşmisini istediği tarih. */
  Date deliveryDate = null

  /* API bu değeri otomatik oluşturur. */
  String deliveryTime = null

  /* Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Sipariş öncesi bilgisi nesnesinin güncellenme zamanı. */
  Date updatedAt = null

    Country billingCountry = null

    Location billingLocation = null

    ShippingCompany shippingCompany = null

    Country shippingCountry = null

    Location shippingLocation = null

    MemberAddress memberShippingAddress = null

    MemberAddress memberBillingAddress = null
  

}

