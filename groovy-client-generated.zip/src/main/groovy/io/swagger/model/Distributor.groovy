package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class Distributor {

  /* Distributor nesnesi kimlik değeri. */
  Integer id = null

  /* Distributor nesnesi için isim değeri. */
  String name = null

  /* E-mail adresi. */
  String email = null

  /* Telefon numarası. */
  String phone = null

  /* İletişim kişisi. */
  String contactPerson = null
  

}

