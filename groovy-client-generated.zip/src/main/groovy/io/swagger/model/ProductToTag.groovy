package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Product;
import io.swagger.model.Tag;
@Canonical
class ProductToTag {

  /* Ürün SEO+ etiketi bağı nesnesi kimlik değeri. */
  Integer id = null

    Product product = null

    Tag tag = null
  

}

