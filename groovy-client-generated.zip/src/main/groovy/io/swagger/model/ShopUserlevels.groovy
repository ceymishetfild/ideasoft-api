package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class ShopUserlevels {

  /* Yönetici grubu nesnesinin benzersiz rakamsal kimlik değeri. */
  Integer id = null

  /* Yönetici grubu ismi. */
  String label = null

  /* Yönetici grubunun sahip olduğu roller. */
  String roles = null
  

}

