package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Date;
import io.swagger.model.OrderItem;
import io.swagger.model.OrderRefundRequest;
@Canonical
class OrderRefundRequestItem {

  /* Sipariş iptal talebi kalemi nesnesi kimlik değeri. */
  Integer id = null

  /* Sipariş iptal talebi istenen ürün miktarı. */
  Float amount = null

  /* Sipariş iptal talebi sebebi. Tanımlı dört seçenekten biri seçilmelidir.<div class='idea_choice_list'><code>Ürünü iade etmek istiyorum.</code> : <br><code>Ürünü değiştirmek istiyorum.</code> : <br><code>Faturadaki ürünler ile bana gelen ürünler farklı.</code> : <br><code>Diğer</code> : <br></div> */
  String reason = null

  /* Sipariş iptal talebinin detaylı açıklaması. */
  String details = null

  /* Sipariş iptal talebi kalemi nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Sipariş iptal talebi kalemi nesnesinin güncellenme zamanı. */
  Date updatedAt = null

  /* Sipariş kalemi nesnesi. */
  OrderItem orderItem = null

  /* Sipariş iptal talebi nesnesi. */
  OrderRefundRequest orderRefundRequest = null
  

}

