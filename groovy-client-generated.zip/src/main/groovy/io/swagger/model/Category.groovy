package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Category;
import io.swagger.model.Date;
@Canonical
class Category {

  /* Kategori nesnesi kimlik değeri. */
  Integer id = null

  /* Kategori nesnesi için isim değeri. */
  String name = null

  /* Slug değeri ilgili nesnenin Url değeridir. */
  String slug = null

  /* Kategori nesnesi için sıralama değeri. */
  Integer sortOrder = null

  /* Kategori nesnesinin aktiflik durumunu belirten değer. */
  String status = null

  /* Kategori nesnesinin fiyat katsayısı. */
  Float percent = null

  /* Kategori nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF */
  String imageFile = null

  /* Her zaman null değer alır. Pratikte kullanımı yoktur. */
  String distributor = null

  /* Kategori nesnesinin üst içerik metninin gösterim durumu. */
  Integer displayShowcaseContent = null

  /* Kategori nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir. */
  String showcaseContent = null

  /* Kategori nesnesinin üst içerik metninin gösterim tipi.<div class='idea_choice_list'><code>1</code> : Kategori içeriği.<br><code>2</code> : Kategori ve üst kategori içeriği.<br><code>3</code> : Kategori ve tüm üst kategoriler.<br></div> */
  Integer showcaseContentDisplayType = null

  /* Kategori nesnesinin alt kategori barındırma durumu. Bu değer otomatik oluşturulur. */
  String hasChildren = null

  /* Arama motorları tarafından tespit edilebilecek anahtar kelimeler. */
  String metaKeywords = null

  /* Arama motorları tarafından tespit edilebilecek açıklama yazısı. */
  String metaDescription = null

  /* Kategori nesnesinin etiket başlığı. */
  String pageTitle = null

  /* Üst kategori olan kategori nesnesi. */
  Category parent = null

  /* Kategori nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. */
  String attachment = null

  /* Kategori nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Kategori nesnesinin güncellenme zamanı. */
  Date updatedAt = null
  

}

