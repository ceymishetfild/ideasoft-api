package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Product;
@Canonical
class ProductImage {

  /* Ürün resmi nesnesi kimlik değeri. */
  Integer id = null

  /* Ürün resminin dosya adı. Uzantı olmadan yazılmalıdır. */
  String filename = null

  /* Resim için geçerli dosya uzantıları.<div class='idea_choice_list'><code>jpg</code> : jpg dosyaları için geçerli uzantı.<br><code>png</code> : png dosyaları için geçerli uzantı.<br><code>gif</code> : gif dosyaları için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyaları için geçerli uzantı.<br></div> */
  String extension = null

  /* Dosya konumu adı. API otomatik oluşturur. */
  String directoryName = null

  /* Revision değeri aynı isimle eklediğiniz resimlerin ön bellekten yüklenmesini engellemek için gerekli bir değerdir. Aynı isimle tekrardan resim yüklenirken bir önceki resimden farklı bir değer almalıdır. */
  String revision = null

  /* Resmin sıralama değeri. Ürün içerisindeki 8 fotoğraf içinden hangisi olacağını belirler. */
  Integer sortOrder = null

  /* Ürün nesnesi. */
  Product product = null

  /* Ürün resminin base64 formatına çevrilmiş resim kodu. Oluşturma(POST) isteği esnasında başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. */
  String attachment = null
  

}

