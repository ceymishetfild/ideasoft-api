package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Member;
import io.swagger.model.Product;
@Canonical
class FavouritedProduct {

  /* Favori ürün nesnesi kimlik değeri. */
  Integer id = null

  /* Üye nesnesi. */
  Member member = null

  /* Ürün nesnesi. */
  Product product = null
  

}

