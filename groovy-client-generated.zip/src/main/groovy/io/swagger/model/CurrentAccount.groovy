package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Date;
import io.swagger.model.Member;
@Canonical
class CurrentAccount {

  /* Cari hesap nesnesi kimlik değeri. */
  Integer id = null

  /* Cari hesap için düzenlenebilir bir kod değeri. */
  String code = null

  /* Cari hesap nesnesinin başlığı. */
  String title = null

  /* Cari hesabın bakiyesi. */
  Float balance = null

  /* Cari hesap için belirlenmiş risk limiti. */
  Float riskLimit = null

  /* Cari hesap nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Cari hesap nesnesinin güncellenme zamanı. */
  Date updatedAt = null

  /* Üye nesnesi. */
  Member member = null
  

}

