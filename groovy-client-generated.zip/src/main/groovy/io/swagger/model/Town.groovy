package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Location;
import io.swagger.model.TownGroup;
@Canonical
class Town {

  /* İlçe nesnesi kimlik değeri. */
  Integer id = null

  /* İlçe nesnesi için isim değeri. */
  String name = null

  /* İlçenin aktiflik bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div> */
  String status = null

  /* Şehir nesnesi. */
  Location location = null

  /* İlçe grubu nesnesi. */
  TownGroup townGroup = null
  

}

