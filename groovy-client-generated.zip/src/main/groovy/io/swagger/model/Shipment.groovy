package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Date;
import io.swagger.model.Order;
@Canonical
class Shipment {

  /* Teslimat nesnesi kimlik değeri. */
  Integer id = null

  /* Teslimat barkodu. */
  String barcode = null

  /* Teslimat fatura numarası. */
  String waybillNo = null

  /* Teslimat irsaliye makbuzu numarası. */
  String invoiceKey = null

  /* Teslimatın kargo şubesi */
  String cargoOffice = null

  /* Teslimat kodu. Kargo takip kodu. */
  String code = null

  /* Teslimat tipi */
  String deliveryType = null

  /* Faturanın pakete dahillik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Dahil.<br><code>0</code> : Dahil değil.<br></div> */
  String invoiceIncluded = null

  /* Kapıda ödeme hizmeti bedeli. */
  Float payAtDoorAmount = null

  /* Teslimat nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Teslimat nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div> */
  Integer status = null

    Order order = null
  

}

