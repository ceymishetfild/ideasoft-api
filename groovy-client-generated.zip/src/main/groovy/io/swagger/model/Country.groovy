package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class Country {

  /* Ülke nesnesi kimlik değeri. */
  Integer id = null

  /* Ülke nesnesi için isim değeri. */
  String name = null

  /* Ülkenin aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div> */
  String status = null
  

}

