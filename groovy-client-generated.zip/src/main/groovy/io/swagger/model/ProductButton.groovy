package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Product;
@Canonical
class ProductButton {

  /* Ürün ve stok butonu nesnesi kimlik değeri. */
  Integer id = null

  /* Hızlı gönderi butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Hızlı kargo butonu aktif.<br><code>0</code> : Hızlı kargo butonu pasif.<br></div> */
  String fastShipping = null

  /* Aynı gün kargo butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aynı gün kargo butonu aktif.<br><code>0</code> : Aynı gün kargo butonu pasif.<br></div> */
  String sameDayShipping = null

  /* 3 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 3 günde teslimat butonu aktif.<br><code>0</code> : 3 günde teslimat butonu pasif.<br></div> */
  String threeDaysDelivery = null

  /* 5 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 5 günde teslimat butonu aktif.<br><code>0</code> : 5 günde teslimat butonu pasif.<br></div> */
  String fiveDaysDelivery = null

  /* 7 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 7 günde teslimat butonu aktif.<br><code>0</code> : 7 günde teslimat butonu pasif.<br></div> */
  String sevenDaysDelivery = null

  /* Kargo bedava butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Kargo bedava butonu aktif.<br><code>0</code> : Kargo bedava butonu pasif.<br></div> */
  String freeShipping = null

  /* Stoktan teslim butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Stoktan teslim butonu aktif.<br><code>0</code> : Stoktan teslim butonu pasif.<br></div> */
  String deliveryFromStock = null

  /* Ön siparişli stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Ön siparişli ürün butonu aktif.<br><code>0</code> : Ön siparişli ürün butonu pasif.<br></div> */
  String preOrderedProduct = null

  /* Sınırlı stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Sınırlı stok butonu aktif.<br><code>0</code> : Sınırlı stok butonu pasif.<br></div> */
  String limitedStock = null

  /* Stok sorunuz butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Stok sorunuz butonu aktif.<br><code>0</code> : Stok sorunuz butonu pasif.<br></div> */
  String askStock = null

  /* Kampanyalı stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Kampanyalı ürün butonu aktif.<br><code>0</code> : Kampanyalı ürün butonu pasif.<br></div> */
  String campaignedProduct = null

  /* Ürün nesnesi. */
  Product product = null
  

}

