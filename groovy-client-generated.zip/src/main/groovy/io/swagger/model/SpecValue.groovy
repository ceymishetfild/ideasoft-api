package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.SpecGroup;
import io.swagger.model.SpecName;
@Canonical
class SpecValue {

  /* Ürün özellik değeri nesnesi kimlik değeri. */
  Integer id = null

  /* Ürün özellik değeri nesnesi için isim değeri. */
  String name = null

  /* Ürün özellik değeri nesnesi için sıralama değeri. */
  Integer sortOrder = null

  /* Ürün özellik değeri logo görseli için geçerli dosya uzantıları.<div class='idea_choice_list'><code>jpg</code> : jpg dosyaları için geçerli uzantı.<br><code>png</code> : png dosyaları için geçerli uzantı.<br><code>gif</code> : gif dosyaları için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyaları için geçerli uzantı.<br></div> */
  String logo = null

  /* Ürün özellik değerinin aktiflik bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div> */
  String status = null

  /* Ürün görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. */
  String attachment = null

  /* Ürün özelliği grubu nesnesi. */
  SpecGroup specGroup = null

  /* Ürün özelliği nesnesi. */
  SpecName specName = null
  

}

