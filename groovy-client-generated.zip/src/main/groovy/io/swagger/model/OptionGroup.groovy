package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class OptionGroup {

  /* Varyant grubu nesnesi kimlik değeri. */
  Integer id = null

  /* Varyant grubunun başlığı. Varyant değeri kırmızı ise bu değer renk olabilir. */
  String title = null

  /* Varyant grubunun sıralama değeri. */
  Integer sortOrder = null

  /* Varyant grubunun filtre menüsündeki gösterim durumu.<div class='idea_choice_list'><code>1</code> : Gösterilsin.<br><code>0</code> : Gösterilmesin.<br></div> */
  String filterStatus = null
  

}

