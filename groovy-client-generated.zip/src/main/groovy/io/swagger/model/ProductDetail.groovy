package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Product;
@Canonical
class ProductDetail {

  /* Ürün detayı nesnesi kimlik değeri. */
  Integer id = null

  /* Ürünün stok kodu. */
  String sku = null

  /* Detay bilgisi. */
  String details = null

  /* Ürün ekstra detaylı bilgi. */
  String extraDetails = null

  /* Ürün nesnesi. */
  Product product = null
  

}

