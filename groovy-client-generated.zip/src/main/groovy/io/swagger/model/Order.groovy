package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ArrayList;
import io.swagger.model.BillingAddress;
import io.swagger.model.Date;
import io.swagger.model.Maillist;
import io.swagger.model.Member;
import io.swagger.model.OrderDetail;
import io.swagger.model.OrderItem;
import io.swagger.model.ShippingAddress;
import java.util.List;
@Canonical
class Order {

  /* Sipariş nesnesi kimlik değeri. */
  Integer id = null

  /* Müşterinin ismi. */
  String customerFirstname = null

  /* Müşterinin soy ismi. */
  String customerSurname = null

  /* Müşterinin e-mail adresi. */
  String customerEmail = null

  /* Müşterinin telefon numarası. */
  String customerPhone = null

  /* Siparişin ödeme tipi. */
  String paymentTypeName = null

  /* Siparişin ödeme altyapısı sağlayıcısının kodu. Ön tanımlıdır. API otomatik oluşturur. */
  String paymentProviderCode = null

  /* Siparişin ödeme altyapısı sağlayıcısının adı. Ön tanımlıdır. API otomatik oluşturur. */
  String paymentProviderName = null

  /* Siparişin ödeme kanalının kodu. Ön tanımlıdır. API otomatik oluşturur. */
  String paymentGatewayCode = null

  /* Siparişin ödeme kanalının adı. Ön tanımlıdır. API otomatik oluşturur. */
  String paymentGatewayName = null

  /* Siparişin banka adı. Ön tanımlıdır. API otomatik oluşturur. */
  String bankName = null

  /* Müşterinin IP adresi. */
  String clientIp = null

  /* Siparişin gerçekleştiği tarayıcı bilgisi. */
  String userAgent = null

  /* Kur bilgisi. */
  String currency = null

  /* Kur oranları. */
  String currencyRates = null

  /* Siparişin vergi hariç fiyatı. */
  Float amount = null

  /* Siparişte kullanılan hediye çeki indirimi tutarı. */
  Float couponDiscount = null

  /* Siparişin vergi tutarı. */
  Float taxAmount = null

  /* Siparişte kullanılan promosyon indirimi tutarı. */
  Float promotionDiscount = null

  /* Siparişin genel fiyat tutarı. orderAmount, couponDiscount, taxAmount, promotionDiscount, shippingAmount, additionalServiceAmount tutarlarının toplamı. */
  Float generalAmount = null

  /* Siparişin teslimat ücreti. */
  Float shippingAmount = null

  /* Siparişin ek hizmet bedeli ücreti. */
  Float additionalServiceAmount = null

  /* Siparişin son ödeme tutarı. generalAmount değerinin üzerine taksitten kaynaklı vade farkı bedeli eklenmiş hali. */
  Float finalAmount = null

  /* Siparişten kazanılan puan tutarı. */
  Float sumOfGainedPoints = null

  /* Siparişin taksit adeti. */
  Integer installment = null

  /* Siparişin taksit oranı. */
  Float installmentRate = null

  /* Siparişin ek taksit adeti. */
  Integer extraInstallment = null

  /* Siparişin numarası. */
  String transactionId = null

  /* Siparişin müşteri notuna sahiplik durumu.<div class='idea_choice_list'><code>1</code> : Sipariş müşteri notuna sahip.<br><code>0</code> : Sipariş müşteri notuna sahip değil.<br></div> */
  String hasUserNote = null

  /* Sipariş durumu.<div class='idea_choice_list'><code>deleted</code> : Silindi<br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br></div> */
  String status = null

  /* Ödeme durumu bilgisi.<div class='idea_choice_list'><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br><code>failed</code> : Hatalı Ödemeler<br><code>success</code> : Başarılı<br></div> */
  String paymentStatus = null

  /* Siparişin hata mesajı. */
  String errorMessage = null

  /* Siparişin gerçekleştiği cihaz bilgisi.<div class='idea_choice_list'><code>desktop</code> : Masaüstü<br><code>mobile</code> : Mobil<br><code>tablet</code> : Tablet<br></div> */
  String deviceType = null

  /* Siparişe yönlendiren web-sitesi adresi. Yönlendirmeyi yapan web-sitesinin tam URL bilgisini de içerir. API otomatik oluşturur. */
  String referrer = null

  /* Sipariş için alınan fatura çıktısı adedi. */
  Integer invoicePrintCount = null

  /* Hediye paketi istenilmesi durumu.<div class='idea_choice_list'><code>1</code> : Hediye paketi istiyorum<br><code>0</code> : Hediye paketi istemiyorum<br></div> */
  String useGiftPackage = null

  /* Hediye notu. */
  String giftNote = null

  /* Üye grubu adı. */
  String memberGroupName = null

  /* Promosyon kullanılma durumu.<div class='idea_choice_list'><code>1</code> : Promosyon kullan<br><code>0</code> : Promosyon kullanma<br></div> */
  String usePromotion = null

  /* Siparişin teslimat hizmeti sağlayıcısı kodu. Ön tanımlıdır. API otomatik oluşturur. */
  String shippingProviderCode = null

  /* Siparişin teslimat hizmeti sağlayıcısı adı. Ön tanımlıdır. */
  String shippingProviderName = null

  /* Siparişin kargo firması adı. Ön tanımlıdır. */
  String shippingCompanyName = null

  /* Siparişin kargo ödeme tipi.<div class='idea_choice_list'><code>cash_on_delivery</code> : Alıcı Ödemeli<br><code>standart_delivery</code> : Gönderici Ödemeli<br><code>not_applicable</code> : Bu alan için geçerli değil.<br></div> */
  String shippingPaymentType = null

  /* Siparişin kargo takip kodu. */
  String shippingTrackingCode = null

  /* Siparişin kaynak bilgisi. Siparişin kaynak yazılımını belirtir. */
  String source = null

  /* Sipariş nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Sipariş nesnesinin güncellenme zamanı. */
  Date updatedAt = null

    Maillist maillist = null

    Member member = null

  /* Sipariş detayları. */
  List<OrderDetail> orderDetails = new ArrayList<OrderDetail>()

  /* Sipariş kalemleri. */
  List<OrderItem> orderItems = new ArrayList<OrderItem>()

    ShippingAddress shippingAddress = null

    BillingAddress billingAddress = null
  

}

