package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ShippingProvider;
@Canonical
class ShippingProviderSetting {

  /* Teslimat hizmeti sağlayıcısı ayarı nesnesi kimlik değeri. */
  Integer id = null

  /* Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken anahtarı. */
  String varKey = null

  /* Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken değeri. */
  String varValue = null

  /* Teslimat hizmeti sağlayıcısı nesnesi. */
  ShippingProvider shippingProvider = null
  

}

