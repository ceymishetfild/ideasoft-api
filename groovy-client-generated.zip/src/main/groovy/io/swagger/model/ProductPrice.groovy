package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Product;
@Canonical
class ProductPrice {

  /* Ürün fiyatı nesnesi kimlik değeri. */
  Integer id = null

  /* Ürün fiyatı değeri. */
  Float value = null

  /* Ürün fiyatı indexi. Fiyat 2, Fiyat 3 gibi. */
  Integer type = null

    Product product = null
  

}

