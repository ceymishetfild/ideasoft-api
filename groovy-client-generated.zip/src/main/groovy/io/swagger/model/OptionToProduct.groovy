package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.OptionGroup;
import io.swagger.model.Options;
import io.swagger.model.Product;
@Canonical
class OptionToProduct {

  /* Varyant ürün bağı nesnesi kimlik değeri. */
  Integer id = null

  /* Ana ürünün benzersiz kimlik değeri. */
  Integer parentProductId = null

  /* Varyant grubu nesnesi. */
  OptionGroup optionGroup = null

  /* Varyant nesnesi. */
  Options option = null

  /* Ürün nesnesi. */
  Product product = null
  

}

