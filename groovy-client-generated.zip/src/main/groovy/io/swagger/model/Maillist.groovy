package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Date;
import io.swagger.model.MaillistGroup;
@Canonical
class Maillist {

  /* Mail listesi nesnesi kimlik değeri. */
  Integer id = null

  /* Mail listesi nesnesi için isim değeri. */
  String name = null

  /* Ziyaretçi veya üyenin mail adresi. */
  String email = null

  /* En son e-mail gönderilen zaman. */
  Date lastMailSentDate = null

  /* Mail listesi nesnesini oluşturan kişinin IP adresi. */
  String creatorIpAddress = null

  /* Mail listesi nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Mail listesi nesnesinin güncellenme zamanı. */
  Date updatedAt = null

  /* Mail listesi grubu nesnesi. */
  MaillistGroup maillistGroup = null
  

}

