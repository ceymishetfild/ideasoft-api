package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Order;
import io.swagger.model.OrderItemSubscription;
import io.swagger.model.Product;
@Canonical
class OrderItem {

  /* Sipariş kalemi nesnesi kimlik değeri. */
  Integer id = null

  /* Ürünün adı. */
  String productName = null

  /* Ürünün stok kodu. */
  String productSku = null

  /* Ürünün barkodu. */
  String productBarcode = null

  /* Ürünün fiyatı. */
  Float productPrice = null

  /* Ürünün kuru. */
  String productCurrency = null

  /* Ürünün stok tipi cinsinden miktarı. */
  Float productQuantity = null

  /* Ürünün vergisi */
  Integer productTax = null

  /* Ürünün standart indirim değeri. */
  Float productDiscount = null

  /* Ürünün havale indirim değeri. */
  Float productMoneyOrderDiscount = null

  /* Ürünün ağırlığı. */
  Float productWeight = null

  /* Ürünün stok tipi.<div class='idea_choice_list'><code>Adet</code> : Stok tipi birimi Adet<br><code>cm</code> : Stok tipi birimi Santimetre<br><code>Düzine</code> : Stok tipi birimi Düzine<br><code>gram</code> : Stok tipi birimi Gram<br><code>kg</code> : Stok tipi birimi Kilogram<br><code>Kişi</code> : Stok tipi birimi Kişi<br><code>Paket</code> : Stok tipi birimi Paket<br><code>metre</code> : Stok tipi birimi Metre<br><code>m2</code> : Stok tipi birimi Metre kare<br><code>Çift</code> : Stok tipi birimi Çift<br></div> */
  String productStockTypeLabel = null

  /* Ürünün promosyon olup olmadığını belirten değer.<div class='idea_choice_list'><code>0</code> : Ürün promosyon değil.<br><code>1</code> : Ürün promosyon.<br></div> */
  String isProductPromotioned = null

  /* Ürünün hediye çeki indirim değeri. */
  Float discount = null

    Order order = null

    Product product = null

    OrderItemSubscription orderItemSubscription = null
  

}

