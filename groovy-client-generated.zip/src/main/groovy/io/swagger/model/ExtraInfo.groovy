package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class ExtraInfo {

  /* Ek bilgi nesnesi kimlik değeri. */
  Integer id = null

  /* Ek bilgi nesnesi için isim değeri. */
  String name = null

  /* Ek bilgi nesnesi için sıralama değeri. */
  Integer sortOrder = null
  

}

