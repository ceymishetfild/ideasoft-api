package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Date;
import io.swagger.model.OrderItem;
import io.swagger.model.Product;
import io.swagger.model.Shipment;
@Canonical
class ShipmentItem {

  /* Teslimat Kalemi nesnesi kimlik değeri. */
  Integer id = null

  /* Ana ürünün id değeri. */
  Integer rootProductId = null

  /* Ürünün stok tipi cinsinden miktarı. */
  Integer amount = null

  /* Ürünün fiyatı. */
  Float price = null

  /* Ürün başlığı. */
  String productLabel = null

  /* Ürünün kur bilgisi.<div class='idea_choice_list'><code>USD</code> : Amerikan Doları<br><code>EUR</code> : Euro<br><code>TL</code> : Türk Lirası<br><code>GBP</code> : İngiliz Sterlini<br><code>JPY</code> : Japon Yeni<br><code>CNY</code> : Çin Yuanı<br><code>GR</code> : Gram Altın<br><code>CHF</code> : İsviçre Frangı<br></div> */
  String currency = null

  /* Ürünün vergi değeri. */
  Integer tax = null

  /* Ürünün desi bilgisi. */
  Float dm3 = null

  /* Teslimat Kalemi nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Teslimat Kalemi nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div> */
  Integer status = null

  /* Teslimat Kalemi nesnesinin güncellenme zamanı. */
  Date updatedAt = null

  /* Sipariş kalemi nesnesi. */
  OrderItem orderItem = null

  /* Ürün nesnesi. */
  Product product = null

  /* Teslimat nesnesi. */
  Shipment shipment = null
  

}

