package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class SelectionGroup {

  /* Ek özellik grubu nesnesi kimlik değeri. */
  Integer id = null

  /* Ek özellik grubu nesnesinin başlığı. */
  String title = null

  /* Ek özellik grubu nesnesi için sıralama değeri. */
  Integer sortOrder = null
  

}

