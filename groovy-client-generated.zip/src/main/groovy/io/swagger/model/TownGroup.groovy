package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class TownGroup {

  /* İlçe grubu nesnesi kimlik değeri. */
  Integer id = null

  /* İlçe grubu nesnesi için isim değeri. */
  String name = null

  /* İlçe grubunun aktiflik bilgisini içerir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div> */
  Boolean status = null
  

}

