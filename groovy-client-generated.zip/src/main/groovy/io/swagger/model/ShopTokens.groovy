package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class ShopTokens {

  /* Hediye çeki nesnesi kimlik değeri. */
  Integer id = null

  /* Hediye çekinin benzersiz kodu. Admin panelinden düzenlenebilir. */
  String code = null
  

}

