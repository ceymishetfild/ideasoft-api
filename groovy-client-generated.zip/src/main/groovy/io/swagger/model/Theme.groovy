package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Date;
@Canonical
class Theme {

  /* Tema nesnesi kimlik değeri. */
  Integer id = null

  /* Temanın kullanılacağı platform.<div class='idea_choice_list'><code>desktop</code> : Masaüstü.<br><code>mobile</code> : Mobil.<br></div> */
  String platform = null

  /* Tema tipi.<div class='idea_choice_list'><code>self</code> : Kişisel Tema.<br><code>standard</code> : Standart Tema.<br></div> */
  String type = null

  /* Tema adı. */
  String name = null

  /* Temanın rengi. */
  String preset = null

  /* Temanın dizini. */
  String directoryName = null

  /* Temanın durumu. */
  String status = null

  /* Temanın revisionı. */
  Integer revision = null

  /* Tema nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Tema nesnesinin güncellenme zamanı. */
  Date updatedAt = null

    String attachment = null
  

}

