package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class MaillistGroup {

  /* Mail listesi grubu nesnesi kimlik değeri. */
  Integer id = null

  /* Mail listesi grubu nesnesi için isim değeri. */
  String name = null
  

}

