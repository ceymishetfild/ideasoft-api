package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Region;
import io.swagger.model.ShippingCompany;
@Canonical
class ShippingRate {

  /* Kargo oranı nesnesi kimlik değeri. */
  Integer id = null

  /* İlgili kargo firması, ilgili bölge ve ilgili orana ait minimum desi değeri. */
  Integer volumetricWeightStart = null

  /* İlgili kargo firması, ilgili bölge ve ilgili orana ait maximum desi değeri. */
  Integer volumetricWeightEnd = null

  /* Seçili bölge ve kargo firması için kargo oranı. */
  Float rate = null

    Region region = null

    ShippingCompany shippingCompany = null
  

}

