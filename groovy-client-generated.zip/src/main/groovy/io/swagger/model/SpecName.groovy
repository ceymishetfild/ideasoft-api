package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.SpecGroup;
@Canonical
class SpecName {

  /* Ürün özelliği nesnesi kimlik değeri. */
  Integer id = null

  /* Ürün özelliği nesnesi için isim değeri. */
  String name = null

  /* Özellik tipini belirtir.<div class='idea_choice_list'><code>singular</code> : Tekil<br><code>plural</code> : Çoğul<br></div> */
  String choiceType = null

  /* Ürün özelliği sıralama değeri. */
  Integer sortOrder = null

  /* Ürün özelliği aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div> */
  String status = null

  /* specGroup */
  SpecGroup specGroup = null
  

}

