package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ArrayList;
import io.swagger.model.CartItem;
import io.swagger.model.Date;
import io.swagger.model.Member;
import io.swagger.model.ShopCampaigns;
import io.swagger.model.ShopTokens;
import java.util.List;
@Canonical
class Cart {

  /* Sepet nesnesi kimlik değeri. */
  Integer id = null

  /* Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri. */
  String sessionId = null

  /* Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz. */
  String locked = null

  /* Sepet nesnesinin oluşturulma zamanı. */
  Date createdAt = null

  /* Sepet nesnesinin güncellenme zamanı. */
  Date updatedAt = null

  /* Promosyon nesnesi. */
  ShopCampaigns chosenPromotion = null

  /* Üye nesnesi. */
  Member member = null

  /* Hediye çeki nesnesi. */
  ShopTokens chosenToken = null

  /* Sepet kalemi nesnelerini barındıran liste. */
  List<CartItem> items = new ArrayList<CartItem>()
  

}

