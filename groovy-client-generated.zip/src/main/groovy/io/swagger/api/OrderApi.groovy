package io.swagger.api;

import groovyx.net.http.*
import static groovyx.net.http.ContentType.*
import static groovyx.net.http.Method.*
import io.swagger.api.ApiUtils

import io.swagger.model.Date
import io.swagger.model.Error
import io.swagger.model.Order

import java.util.*;

@Mixin(ApiUtils)
class OrderApi {
    String basePath = "https://magaza-adiniz.myideasoft.com/api"
    String versionPath = "/api/v1"

    def ordersGet ( String sort, Integer limit, Integer page, Integer sinceId, String ids, String transactionId, String customerEmail, Integer member, String status, String paymentStatus, String paymentTypeName, String shippingProviderCode, List<String> q, Date startDate, String endDate, Date startUpdatedAt, String endUpdatedAt, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/orders"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    

        if (!"null".equals(String.valueOf(sort)))
            queryParams.put("sort", String.valueOf(sort))
if (!"null".equals(String.valueOf(limit)))
            queryParams.put("limit", String.valueOf(limit))
if (!"null".equals(String.valueOf(page)))
            queryParams.put("page", String.valueOf(page))
if (!"null".equals(String.valueOf(sinceId)))
            queryParams.put("sinceId", String.valueOf(sinceId))
if (!"null".equals(String.valueOf(ids)))
            queryParams.put("ids", String.valueOf(ids))
if (!"null".equals(String.valueOf(transactionId)))
            queryParams.put("transactionId", String.valueOf(transactionId))
if (!"null".equals(String.valueOf(customerEmail)))
            queryParams.put("customerEmail", String.valueOf(customerEmail))
if (!"null".equals(String.valueOf(member)))
            queryParams.put("member", String.valueOf(member))
if (!"null".equals(String.valueOf(status)))
            queryParams.put("status", String.valueOf(status))
if (!"null".equals(String.valueOf(paymentStatus)))
            queryParams.put("paymentStatus", String.valueOf(paymentStatus))
if (!"null".equals(String.valueOf(paymentTypeName)))
            queryParams.put("paymentTypeName", String.valueOf(paymentTypeName))
if (!"null".equals(String.valueOf(shippingProviderCode)))
            queryParams.put("shippingProviderCode", String.valueOf(shippingProviderCode))
if (!"null".equals(String.valueOf(q)))
            queryParams.put("q", String.valueOf(q))
if (!"null".equals(String.valueOf(startDate)))
            queryParams.put("startDate", String.valueOf(startDate))
if (!"null".equals(String.valueOf(endDate)))
            queryParams.put("endDate", String.valueOf(endDate))
if (!"null".equals(String.valueOf(startUpdatedAt)))
            queryParams.put("startUpdatedAt", String.valueOf(startUpdatedAt))
if (!"null".equals(String.valueOf(endUpdatedAt)))
            queryParams.put("endUpdatedAt", String.valueOf(endUpdatedAt))


        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    Order.class )
                    
    }
    def ordersIdDelete ( Integer id, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/orders/{id}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (id == null) {
            throw new RuntimeException("missing required params id")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "DELETE", "",
                    null )
                    
    }
    def ordersIdGet ( Integer id, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/orders/{id}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (id == null) {
            throw new RuntimeException("missing required params id")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    Order.class )
                    
    }
    def ordersIdPut ( Integer id, Order order, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/orders/{id}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (id == null) {
            throw new RuntimeException("missing required params id")
        }
        // verify required params are set
        if (order == null) {
            throw new RuntimeException("missing required params order")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "PUT", "",
                    Order.class )
                    
    }
    def ordersPost ( Order order, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/orders"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (order == null) {
            throw new RuntimeException("missing required params order")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "POST", "",
                    Order.class )
                    
    }
}
