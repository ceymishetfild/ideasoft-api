package io.swagger.api;

import groovyx.net.http.*
import static groovyx.net.http.ContentType.*
import static groovyx.net.http.Method.*
import io.swagger.api.ApiUtils

import io.swagger.model.Date
import io.swagger.model.Error
import io.swagger.model.OrderItem

import java.util.*;

@Mixin(ApiUtils)
class OrderItemApi {
    String basePath = "https://magaza-adiniz.myideasoft.com/api"
    String versionPath = "/api/v1"

    def orderItemsGet ( String sort, Integer limit, Integer page, Integer sinceId, String ids, Integer order, String productName, String productSku, String productBarcode, Date startDate, String endDate, Date startUpdatedAt, String endUpdatedAt, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/order_items"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    

        if (!"null".equals(String.valueOf(sort)))
            queryParams.put("sort", String.valueOf(sort))
if (!"null".equals(String.valueOf(limit)))
            queryParams.put("limit", String.valueOf(limit))
if (!"null".equals(String.valueOf(page)))
            queryParams.put("page", String.valueOf(page))
if (!"null".equals(String.valueOf(sinceId)))
            queryParams.put("sinceId", String.valueOf(sinceId))
if (!"null".equals(String.valueOf(ids)))
            queryParams.put("ids", String.valueOf(ids))
if (!"null".equals(String.valueOf(order)))
            queryParams.put("order", String.valueOf(order))
if (!"null".equals(String.valueOf(productName)))
            queryParams.put("productName", String.valueOf(productName))
if (!"null".equals(String.valueOf(productSku)))
            queryParams.put("productSku", String.valueOf(productSku))
if (!"null".equals(String.valueOf(productBarcode)))
            queryParams.put("productBarcode", String.valueOf(productBarcode))
if (!"null".equals(String.valueOf(startDate)))
            queryParams.put("startDate", String.valueOf(startDate))
if (!"null".equals(String.valueOf(endDate)))
            queryParams.put("endDate", String.valueOf(endDate))
if (!"null".equals(String.valueOf(startUpdatedAt)))
            queryParams.put("startUpdatedAt", String.valueOf(startUpdatedAt))
if (!"null".equals(String.valueOf(endUpdatedAt)))
            queryParams.put("endUpdatedAt", String.valueOf(endUpdatedAt))


        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    OrderItem.class )
                    
    }
    def orderItemsIdGet ( Integer id, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/order_items/{id}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (id == null) {
            throw new RuntimeException("missing required params id")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    OrderItem.class )
                    
    }
}
