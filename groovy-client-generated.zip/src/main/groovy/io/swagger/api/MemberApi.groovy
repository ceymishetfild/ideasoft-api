package io.swagger.api;

import groovyx.net.http.*
import static groovyx.net.http.ContentType.*
import static groovyx.net.http.Method.*
import io.swagger.api.ApiUtils

import io.swagger.model.Date
import io.swagger.model.Error
import io.swagger.model.Member

import java.util.*;

@Mixin(ApiUtils)
class MemberApi {
    String basePath = "https://magaza-adiniz.myideasoft.com/api"
    String versionPath = "/api/v1"

    def membersChartsGet ( String timeFrame, String startDate, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/members/charts"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (timeFrame == null) {
            throw new RuntimeException("missing required params timeFrame")
        }
        // verify required params are set
        if (startDate == null) {
            throw new RuntimeException("missing required params startDate")
        }

        if (!"null".equals(String.valueOf(timeFrame)))
            queryParams.put("timeFrame", String.valueOf(timeFrame))
if (!"null".equals(String.valueOf(startDate)))
            queryParams.put("startDate", String.valueOf(startDate))


        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    Member.class )
                    
    }
    def membersCombinedGet ( Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/members/combined"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    Member.class )
                    
    }
    def membersGet ( String sort, Integer limit, Integer page, Integer sinceId, String ids, String firstname, String surname, String email, String password, String gender, String mobilePhoneNumber, String phoneNumber, Integer memberGroup, Integer location, Integer country, Integer referredMember, List<String> q, Date startDate, String endDate, Date startUpdatedAt, String endUpdatedAt, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/members"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    

        if (!"null".equals(String.valueOf(sort)))
            queryParams.put("sort", String.valueOf(sort))
if (!"null".equals(String.valueOf(limit)))
            queryParams.put("limit", String.valueOf(limit))
if (!"null".equals(String.valueOf(page)))
            queryParams.put("page", String.valueOf(page))
if (!"null".equals(String.valueOf(sinceId)))
            queryParams.put("sinceId", String.valueOf(sinceId))
if (!"null".equals(String.valueOf(ids)))
            queryParams.put("ids", String.valueOf(ids))
if (!"null".equals(String.valueOf(firstname)))
            queryParams.put("firstname", String.valueOf(firstname))
if (!"null".equals(String.valueOf(surname)))
            queryParams.put("surname", String.valueOf(surname))
if (!"null".equals(String.valueOf(email)))
            queryParams.put("email", String.valueOf(email))
if (!"null".equals(String.valueOf(password)))
            queryParams.put("password", String.valueOf(password))
if (!"null".equals(String.valueOf(gender)))
            queryParams.put("gender", String.valueOf(gender))
if (!"null".equals(String.valueOf(mobilePhoneNumber)))
            queryParams.put("mobilePhoneNumber", String.valueOf(mobilePhoneNumber))
if (!"null".equals(String.valueOf(phoneNumber)))
            queryParams.put("phoneNumber", String.valueOf(phoneNumber))
if (!"null".equals(String.valueOf(memberGroup)))
            queryParams.put("memberGroup", String.valueOf(memberGroup))
if (!"null".equals(String.valueOf(location)))
            queryParams.put("location", String.valueOf(location))
if (!"null".equals(String.valueOf(country)))
            queryParams.put("country", String.valueOf(country))
if (!"null".equals(String.valueOf(referredMember)))
            queryParams.put("referredMember", String.valueOf(referredMember))
if (!"null".equals(String.valueOf(q)))
            queryParams.put("q", String.valueOf(q))
if (!"null".equals(String.valueOf(startDate)))
            queryParams.put("startDate", String.valueOf(startDate))
if (!"null".equals(String.valueOf(endDate)))
            queryParams.put("endDate", String.valueOf(endDate))
if (!"null".equals(String.valueOf(startUpdatedAt)))
            queryParams.put("startUpdatedAt", String.valueOf(startUpdatedAt))
if (!"null".equals(String.valueOf(endUpdatedAt)))
            queryParams.put("endUpdatedAt", String.valueOf(endUpdatedAt))


        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    Member.class )
                    
    }
    def membersIdDelete ( Integer id, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/members/{id}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (id == null) {
            throw new RuntimeException("missing required params id")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "DELETE", "",
                    null )
                    
    }
    def membersIdGet ( Integer id, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/members/{id}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (id == null) {
            throw new RuntimeException("missing required params id")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    Member.class )
                    
    }
    def membersIdPut ( Integer id, Member member, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/members/{id}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (id == null) {
            throw new RuntimeException("missing required params id")
        }
        // verify required params are set
        if (member == null) {
            throw new RuntimeException("missing required params member")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "PUT", "",
                    Member.class )
                    
    }
    def membersPost ( Member member, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/members"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (member == null) {
            throw new RuntimeException("missing required params member")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "POST", "",
                    Member.class )
                    
    }
}
