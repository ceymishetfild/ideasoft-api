package io.swagger.api;

import groovyx.net.http.*
import static groovyx.net.http.ContentType.*
import static groovyx.net.http.Method.*
import io.swagger.api.ApiUtils

import io.swagger.model.Date
import io.swagger.model.Error
import io.swagger.model.OrderRefundRequest

import java.util.*;

@Mixin(ApiUtils)
class OrderRefundRequestApi {
    String basePath = "https://magaza-adiniz.myideasoft.com/api"
    String versionPath = "/api/v1"

    def orderRefundRequestsGet ( String sort, Integer limit, Integer page, Integer sinceId, Integer order, Integer member, String code, String status, Date startDate, String endDate, Date startUpdatedAt, String endUpdatedAt, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/order_refund_requests"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    

        if (!"null".equals(String.valueOf(sort)))
            queryParams.put("sort", String.valueOf(sort))
if (!"null".equals(String.valueOf(limit)))
            queryParams.put("limit", String.valueOf(limit))
if (!"null".equals(String.valueOf(page)))
            queryParams.put("page", String.valueOf(page))
if (!"null".equals(String.valueOf(sinceId)))
            queryParams.put("sinceId", String.valueOf(sinceId))
if (!"null".equals(String.valueOf(order)))
            queryParams.put("order", String.valueOf(order))
if (!"null".equals(String.valueOf(member)))
            queryParams.put("member", String.valueOf(member))
if (!"null".equals(String.valueOf(code)))
            queryParams.put("code", String.valueOf(code))
if (!"null".equals(String.valueOf(status)))
            queryParams.put("status", String.valueOf(status))
if (!"null".equals(String.valueOf(startDate)))
            queryParams.put("startDate", String.valueOf(startDate))
if (!"null".equals(String.valueOf(endDate)))
            queryParams.put("endDate", String.valueOf(endDate))
if (!"null".equals(String.valueOf(startUpdatedAt)))
            queryParams.put("startUpdatedAt", String.valueOf(startUpdatedAt))
if (!"null".equals(String.valueOf(endUpdatedAt)))
            queryParams.put("endUpdatedAt", String.valueOf(endUpdatedAt))


        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    OrderRefundRequest.class )
                    
    }
    def orderRefundRequestsIdDelete ( Integer id, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/order_refund_requests/{id}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (id == null) {
            throw new RuntimeException("missing required params id")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "DELETE", "",
                    null )
                    
    }
    def orderRefundRequestsIdGet ( Integer id, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/order_refund_requests/{id}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (id == null) {
            throw new RuntimeException("missing required params id")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    OrderRefundRequest.class )
                    
    }
    def orderRefundRequestsIdPut ( Integer id, OrderRefundRequest orderRefundRequest, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/order_refund_requests/{id}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (id == null) {
            throw new RuntimeException("missing required params id")
        }
        // verify required params are set
        if (orderRefundRequest == null) {
            throw new RuntimeException("missing required params orderRefundRequest")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "PUT", "",
                    OrderRefundRequest.class )
                    
    }
    def orderRefundRequestsPost ( OrderRefundRequest orderRefundRequest, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/order_refund_requests"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (orderRefundRequest == null) {
            throw new RuntimeException("missing required params orderRefundRequest")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "POST", "",
                    OrderRefundRequest.class )
                    
    }
}
