package io.swagger.api;

import groovyx.net.http.*
import static groovyx.net.http.ContentType.*
import static groovyx.net.http.Method.*
import io.swagger.api.ApiUtils

import io.swagger.model.Error
import io.swagger.model.ProductPrice

import java.util.*;

@Mixin(ApiUtils)
class ProductPriceApi {
    String basePath = "https://magaza-adiniz.myideasoft.com/api"
    String versionPath = "/api/v1"

    def productPricesGet ( String sort, Integer limit, Integer page, Integer sinceId, Integer type, Integer product, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/product_prices"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    

        if (!"null".equals(String.valueOf(sort)))
            queryParams.put("sort", String.valueOf(sort))
if (!"null".equals(String.valueOf(limit)))
            queryParams.put("limit", String.valueOf(limit))
if (!"null".equals(String.valueOf(page)))
            queryParams.put("page", String.valueOf(page))
if (!"null".equals(String.valueOf(sinceId)))
            queryParams.put("sinceId", String.valueOf(sinceId))
if (!"null".equals(String.valueOf(type)))
            queryParams.put("type", String.valueOf(type))
if (!"null".equals(String.valueOf(product)))
            queryParams.put("product", String.valueOf(product))


        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    ProductPrice.class )
                    
    }
    def productPricesIdDelete ( Integer id, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/product_prices/{id}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (id == null) {
            throw new RuntimeException("missing required params id")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "DELETE", "",
                    null )
                    
    }
    def productPricesIdGet ( Integer id, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/product_prices/{id}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (id == null) {
            throw new RuntimeException("missing required params id")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    ProductPrice.class )
                    
    }
    def productPricesIdPut ( Integer id, ProductPrice productPrice, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/product_prices/{id}"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (id == null) {
            throw new RuntimeException("missing required params id")
        }
        // verify required params are set
        if (productPrice == null) {
            throw new RuntimeException("missing required params productPrice")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "PUT", "",
                    ProductPrice.class )
                    
    }
    def productPricesPost ( ProductPrice productPrice, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/product_prices"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (productPrice == null) {
            throw new RuntimeException("missing required params productPrice")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "POST", "",
                    ProductPrice.class )
                    
    }
}
