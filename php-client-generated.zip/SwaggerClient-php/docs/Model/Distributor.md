# Distributor

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Distributor nesnesi kimlik değeri. | [optional] 
**name** | **string** | Distributor nesnesi için isim değeri. | 
**email** | **string** | E-mail adresi. | [optional] 
**phone** | **string** | Telefon numarası. | [optional] 
**contact_person** | **string** | İletişim kişisi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


