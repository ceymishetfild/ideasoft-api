# ExtraInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ek bilgi nesnesi kimlik değeri. | [optional] 
**name** | **string** | Ek bilgi nesnesi için isim değeri. | 
**sort_order** | **int** | Ek bilgi nesnesi için sıralama değeri. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


