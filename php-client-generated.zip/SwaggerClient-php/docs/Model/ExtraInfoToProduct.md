# ExtraInfoToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ek bilgi ürün bağı nesnesi kimlik değeri. | [optional] 
**value** | **string** | Ek bilgi ürün bağı değeridir. Ek bilgi renk ise bu değer kırmızı olabilir. | 
**extra_info** | [**\Swagger\Client\Model\ExtraInfo**](ExtraInfo.md) |  | [optional] 
**product** | [**\Swagger\Client\Model\Product**](Product.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


