# ProductToTag

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ürün SEO+ etiketi bağı nesnesi kimlik değeri. | [optional] 
**product** | [**\Swagger\Client\Model\Product**](Product.md) |  | [optional] 
**tag** | [**\Swagger\Client\Model\Tag**](Tag.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


