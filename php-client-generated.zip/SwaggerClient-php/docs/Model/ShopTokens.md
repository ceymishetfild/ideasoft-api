# ShopTokens

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Hediye çeki nesnesi kimlik değeri. | [optional] 
**code** | **string** | Hediye çekinin benzersiz kodu. Admin panelinden düzenlenebilir. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


