# Cart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sepet nesnesi kimlik değeri. | [optional] 
**session_id** | **string** | Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri. | 
**locked** | **string** | Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz. | [optional] 
**created_at** | [**\DateTime**](\DateTime.md) | Sepet nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | [**\DateTime**](\DateTime.md) | Sepet nesnesinin güncellenme zamanı. | [optional] 
**chosen_promotion** | [**\Swagger\Client\Model\ShopCampaigns**](ShopCampaigns.md) |  | [optional] 
**member** | [**\Swagger\Client\Model\Member**](Member.md) |  | [optional] 
**chosen_token** | [**\Swagger\Client\Model\ShopTokens**](ShopTokens.md) |  | [optional] 
**items** | [**\Swagger\Client\Model\CartItem[]**](CartItem.md) | Sepet kalemi nesnelerini barındıran liste. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


