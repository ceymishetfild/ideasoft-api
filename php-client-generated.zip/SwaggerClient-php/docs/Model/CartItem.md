# CartItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sepet kalemi nesnesi kimlik değeri. | [optional] 
**parent_product_id** | **int** | Ana ürünün benzersiz rakamsal kimlik değeri. | [optional] 
**quantity** | **float** | Sepetteki kalem adedi. | 
**category_id** | **int** | Sepetteki kaleme ait kategorinin benzersiz kimlik değeri. | [optional] 
**created_at** | [**\DateTime**](\DateTime.md) | Sepet kalemi nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | [**\DateTime**](\DateTime.md) | Sepet kalemi nesnesinin güncellenme zamanı. | [optional] 
**cart** | [**\Swagger\Client\Model\Cart**](Cart.md) |  | [optional] 
**product** | [**\Swagger\Client\Model\Product**](Product.md) |  | [optional] 
**attributes** | [**\Swagger\Client\Model\CartItemAttribute[]**](CartItemAttribute.md) | Sepet kalemi özelliği barındıran liste. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


