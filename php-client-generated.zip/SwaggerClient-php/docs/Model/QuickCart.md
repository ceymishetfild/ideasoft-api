# QuickCart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Hızlı satın al bağlantısı nesnesi kimlik değeri. | [optional] 
**name** | **string** | Hızlı satın al bağlantısı nesnesi için isim değeri. | 
**url** | **string** | Hızlı satın al bağlantısı url&#39;si. | 
**short_url** | **string** | Hızlı satın al bağlantısı için kısaltılmış url. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


