# PreOrderInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sipariş öncesi bilgisi nesnesi kimlik değeri. | [optional] 
**session_id** | **string** | Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri. | 
**customer_firstname** | **string** | Müşterinin ismi. | [optional] 
**customer_surname** | **string** | Müşterinin soy ismi. | [optional] 
**customer_email** | **string** | Müşterinin e-mail adresi. | [optional] 
**shipping_firstname** | **string** | Teslimat yapılacak kişinin ismi. | 
**shipping_surname** | **string** | Teslimat yapılacak kişinin soy ismi. | 
**shipping_address** | **string** | Teslimat adresi bilgileri. | 
**shipping_phone_number** | **string** | Teslimat yapılacak kişinin telefon numarası. | 
**shipping_mobile_phone_number** | **string** | Teslimat yapılacak kişinin mobil telefon numarası. | 
**shipping_location_name** | **string** | Teslimat şehri. | 
**shipping_town** | **string** | Teslimat ilçesi. | 
**different_billing_address** | **string** | Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yok&lt;br&gt;&lt;/div&gt; | [optional] 
**billing_firstname** | **string** | Fatura kesilen kişinin ismi. | 
**billing_surname** | **string** | Fatura kesilen kişinin soy ismi. | 
**billing_address** | **string** | Fatura adresi bilgileri. | 
**billing_phone_number** | **string** | Fatura kesilen kişinin telefon numarası. | 
**billing_mobile_phone_number** | **string** | Fatura kesilen kişinin mobil telefon numarası. | 
**billing_location_name** | **string** | Fatura adresi şehri | 
**billing_town** | **string** | Fatura adresi ilçesi. | 
**billing_invoice_type** | **string** | Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt; | 
**billing_identity_registration_number** | **string** | Fatura kesilen kişinin TC kimlik numarası. | [optional] 
**billing_tax_office** | **string** | Fatura kesilen kişi/kurumun vergi dairesi. | [optional] 
**billing_tax_no** | **string** | Fatura kesilen kişi/kurum vergi numarası. | [optional] 
**is_einvoice_user** | **string** | Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] 
**use_gift_package** | **string** | Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] 
**gift_note** | **string** | Hediye notu bilgisi. | [optional] 
**image_file** | **string** | Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif | [optional] 
**delivery_date** | [**\DateTime**](\DateTime.md) | Müşterinin teslimatın gerçekleşmisini istediği tarih. | [optional] 
**delivery_time** | **string** | API bu değeri otomatik oluşturur. | [optional] 
**created_at** | [**\DateTime**](\DateTime.md) | Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | [**\DateTime**](\DateTime.md) | Sipariş öncesi bilgisi nesnesinin güncellenme zamanı. | [optional] 
**billing_country** | [**\Swagger\Client\Model\Country**](Country.md) |  | [optional] 
**billing_location** | [**\Swagger\Client\Model\Location**](Location.md) |  | [optional] 
**shipping_company** | [**\Swagger\Client\Model\ShippingCompany**](ShippingCompany.md) |  | [optional] 
**shipping_country** | [**\Swagger\Client\Model\Country**](Country.md) |  | [optional] 
**shipping_location** | [**\Swagger\Client\Model\Location**](Location.md) |  | [optional] 
**member_shipping_address** | [**\Swagger\Client\Model\MemberAddress**](MemberAddress.md) |  | [optional] 
**member_billing_address** | [**\Swagger\Client\Model\MemberAddress**](MemberAddress.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


