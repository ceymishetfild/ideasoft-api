# Asset

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **string** | Tema Dosyası nesnesi anahtar değeri. | [optional] 
**content_type** | **string** | Tema Dosyası içerik tipi. Geçerli bir MIME Content-Type verilmelidir. | [optional] 
**attachment** | **string** | Tema Dosyası içeriği. | [optional] 
**created_at** | [**\DateTime**](\DateTime.md) | Tema Dosyası nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | [**\DateTime**](\DateTime.md) | Tema Dosyası nesnesinin güncellenme zamanı. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


