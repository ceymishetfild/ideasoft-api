# CurrentAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Cari hesap nesnesi kimlik değeri. | [optional] 
**code** | **string** | Cari hesap için düzenlenebilir bir kod değeri. | [optional] 
**title** | **string** | Cari hesap nesnesinin başlığı. | 
**balance** | **float** | Cari hesabın bakiyesi. | [optional] 
**risk_limit** | **float** | Cari hesap için belirlenmiş risk limiti. | [optional] 
**created_at** | [**\DateTime**](\DateTime.md) | Cari hesap nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | [**\DateTime**](\DateTime.md) | Cari hesap nesnesinin güncellenme zamanı. | [optional] 
**member** | [**\Swagger\Client\Model\Member**](Member.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


