# OptionToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Varyant ürün bağı nesnesi kimlik değeri. | [optional] 
**parent_product_id** | **int** | Ana ürünün benzersiz kimlik değeri. | 
**option_group** | [**\Swagger\Client\Model\OptionGroup**](OptionGroup.md) |  | [optional] 
**option** | [**\Swagger\Client\Model\Options**](Options.md) |  | [optional] 
**product** | [**\Swagger\Client\Model\Product**](Product.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


