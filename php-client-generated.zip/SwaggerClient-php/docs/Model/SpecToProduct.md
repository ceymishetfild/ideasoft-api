# SpecToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ürün özellik ürün bağı nesnesi kimlik değeri. | [optional] 
**product** | [**\Swagger\Client\Model\Product**](Product.md) |  | [optional] 
**spec_group** | [**\Swagger\Client\Model\SpecGroup**](SpecGroup.md) |  | [optional] 
**spec_name** | [**\Swagger\Client\Model\SpecName**](SpecName.md) |  | [optional] 
**spec_value** | [**\Swagger\Client\Model\SpecValue**](SpecValue.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


