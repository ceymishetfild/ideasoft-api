# InstallmentRate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Taksit oranı nesnesi kimlik değeri. | [optional] 
**installment** | **int** | Taksit adeti. | 
**rate** | **float** | Taksit adeti için oran bilgisi. | 
**payment_gateway** | [**\Swagger\Client\Model\PaymentGateway**](PaymentGateway.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


