# Selection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ek özellik nesnesi kimlik değeri. | [optional] 
**title** | **string** | Ek özellik nesnesinin başlığı. | [optional] 
**sort_order** | **int** | Ek özellik nesnesi için sıralama değeri. | 
**selection_group** | [**\Swagger\Client\Model\SelectionGroup**](SelectionGroup.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


