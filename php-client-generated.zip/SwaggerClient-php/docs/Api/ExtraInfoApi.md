# Swagger\Client\ExtraInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extraInfosGet**](ExtraInfoApi.md#extraInfosGet) | **GET** /extra_infos | Ek Bilgi Listesi Alma
[**extraInfosIdDelete**](ExtraInfoApi.md#extraInfosIdDelete) | **DELETE** /extra_infos/{id} | Ek Bilgi Silme
[**extraInfosIdGet**](ExtraInfoApi.md#extraInfosIdGet) | **GET** /extra_infos/{id} | Ek Bilgi Alma
[**extraInfosIdPut**](ExtraInfoApi.md#extraInfosIdPut) | **PUT** /extra_infos/{id} | Ek Bilgi Güncelleme
[**extraInfosPost**](ExtraInfoApi.md#extraInfosPost) | **POST** /extra_infos | Ek Bilgi Oluşturma


# **extraInfosGet**
> \Swagger\Client\Model\ExtraInfo extraInfosGet($sort, $limit, $page, $since_id, $name)

Ek Bilgi Listesi Alma

Ek Bilgi listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ExtraInfoApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$name = "name_example"; // string | Ek Bilgi adı

try {
    $result = $apiInstance->extraInfosGet($sort, $limit, $page, $since_id, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ExtraInfoApi->extraInfosGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **name** | **string**| Ek Bilgi adı | [optional]

### Return type

[**\Swagger\Client\Model\ExtraInfo**](../Model/ExtraInfo.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **extraInfosIdDelete**
> extraInfosIdDelete($id)

Ek Bilgi Silme

Kalıcı olarak ilgili Ek Bilgiyi siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ExtraInfoApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ek Bilgi nesnesinin id değeri

try {
    $apiInstance->extraInfosIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling ExtraInfoApi->extraInfosIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **extraInfosIdGet**
> \Swagger\Client\Model\ExtraInfo extraInfosIdGet($id)

Ek Bilgi Alma

İlgili Ek Bilgiyi getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ExtraInfoApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ek Bilgi nesnesinin id değeri

try {
    $result = $apiInstance->extraInfosIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ExtraInfoApi->extraInfosIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\ExtraInfo**](../Model/ExtraInfo.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **extraInfosIdPut**
> \Swagger\Client\Model\ExtraInfo extraInfosIdPut($id, $extra_info)

Ek Bilgi Güncelleme

İlgili Ek Bilgiyi günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ExtraInfoApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ek Bilgi nesnesinin id değeri
$extra_info = new \Swagger\Client\Model\ExtraInfo(); // \Swagger\Client\Model\ExtraInfo | ExtraInfo nesnesi

try {
    $result = $apiInstance->extraInfosIdPut($id, $extra_info);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ExtraInfoApi->extraInfosIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi nesnesinin id değeri |
 **extra_info** | [**\Swagger\Client\Model\ExtraInfo**](../Model/ExtraInfo.md)| ExtraInfo nesnesi |

### Return type

[**\Swagger\Client\Model\ExtraInfo**](../Model/ExtraInfo.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **extraInfosPost**
> \Swagger\Client\Model\ExtraInfo extraInfosPost($extra_info)

Ek Bilgi Oluşturma

Yeni bir Ek Bilgi oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ExtraInfoApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$extra_info = new \Swagger\Client\Model\ExtraInfo(); // \Swagger\Client\Model\ExtraInfo | ExtraInfo nesnesi

try {
    $result = $apiInstance->extraInfosPost($extra_info);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ExtraInfoApi->extraInfosPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extra_info** | [**\Swagger\Client\Model\ExtraInfo**](../Model/ExtraInfo.md)| ExtraInfo nesnesi |

### Return type

[**\Swagger\Client\Model\ExtraInfo**](../Model/ExtraInfo.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

