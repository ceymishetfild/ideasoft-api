# Swagger\Client\MemberAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**memberAddressesGet**](MemberAddressApi.md#memberAddressesGet) | **GET** /member_addresses | Üye Adresi Listeleme
[**memberAddressesIdDelete**](MemberAddressApi.md#memberAddressesIdDelete) | **DELETE** /member_addresses/{id} | Üye Adresi Silme
[**memberAddressesIdGet**](MemberAddressApi.md#memberAddressesIdGet) | **GET** /member_addresses/{id} | Üye Adresi Alma
[**memberAddressesIdPut**](MemberAddressApi.md#memberAddressesIdPut) | **PUT** /member_addresses/{id} | Üye Adresi Güncelleme
[**memberAddressesPost**](MemberAddressApi.md#memberAddressesPost) | **POST** /member_addresses | Üye Adresi Oluşturma


# **memberAddressesGet**
> \Swagger\Client\Model\MemberAddress memberAddressesGet($sort, $limit, $page, $since_id, $member, $start_date, $end_date)

Üye Adresi Listeleme

Üye Adresi listesi verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberAddressApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$member = 56; // int | Üye id
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi

try {
    $result = $apiInstance->memberAddressesGet($sort, $limit, $page, $since_id, $member, $start_date, $end_date);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MemberAddressApi->memberAddressesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **member** | **int**| Üye id | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]

### Return type

[**\Swagger\Client\Model\MemberAddress**](../Model/MemberAddress.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **memberAddressesIdDelete**
> memberAddressesIdDelete($id)

Üye Adresi Silme

Kalıcı olarak ilgili Üye Adresini siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberAddressApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Üye Adresi nesnesinin id değeri

try {
    $apiInstance->memberAddressesIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling MemberAddressApi->memberAddressesIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Adresi nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **memberAddressesIdGet**
> \Swagger\Client\Model\MemberAddress memberAddressesIdGet($id)

Üye Adresi Alma

İlgili Üye Adresini getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberAddressApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Üye Adresi nesnesinin id değeri

try {
    $result = $apiInstance->memberAddressesIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MemberAddressApi->memberAddressesIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Adresi nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\MemberAddress**](../Model/MemberAddress.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **memberAddressesIdPut**
> \Swagger\Client\Model\MemberAddress memberAddressesIdPut($id, $member_address)

Üye Adresi Güncelleme

İlgili Üye Adresini günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberAddressApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Üye Adresi nesnesinin id değeri
$member_address = new \Swagger\Client\Model\MemberAddress(); // \Swagger\Client\Model\MemberAddress | MemberAddress nesnesi

try {
    $result = $apiInstance->memberAddressesIdPut($id, $member_address);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MemberAddressApi->memberAddressesIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Adresi nesnesinin id değeri |
 **member_address** | [**\Swagger\Client\Model\MemberAddress**](../Model/MemberAddress.md)| MemberAddress nesnesi |

### Return type

[**\Swagger\Client\Model\MemberAddress**](../Model/MemberAddress.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **memberAddressesPost**
> \Swagger\Client\Model\MemberAddress memberAddressesPost($member_address)

Üye Adresi Oluşturma

Yeni bir Üye Adresi oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberAddressApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$member_address = new \Swagger\Client\Model\MemberAddress(); // \Swagger\Client\Model\MemberAddress | MemberAddress nesnesi

try {
    $result = $apiInstance->memberAddressesPost($member_address);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MemberAddressApi->memberAddressesPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member_address** | [**\Swagger\Client\Model\MemberAddress**](../Model/MemberAddress.md)| MemberAddress nesnesi |

### Return type

[**\Swagger\Client\Model\MemberAddress**](../Model/MemberAddress.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

