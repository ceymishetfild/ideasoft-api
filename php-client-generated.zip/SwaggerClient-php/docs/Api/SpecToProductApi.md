# Swagger\Client\SpecToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specToProductsGet**](SpecToProductApi.md#specToProductsGet) | **GET** /spec_to_products | Ürün Özellik Ürün Bağı Listesi Alma
[**specToProductsIdDelete**](SpecToProductApi.md#specToProductsIdDelete) | **DELETE** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Silme
[**specToProductsIdGet**](SpecToProductApi.md#specToProductsIdGet) | **GET** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Alma
[**specToProductsIdPut**](SpecToProductApi.md#specToProductsIdPut) | **PUT** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Güncelleme
[**specToProductsPost**](SpecToProductApi.md#specToProductsPost) | **POST** /spec_to_products | Ürün Özellik Ürün Bağı Oluşturma


# **specToProductsGet**
> \Swagger\Client\Model\SpecToProduct specToProductsGet($sort, $limit, $page, $since_id, $product, $spec_group, $spec_name, $spec_value)

Ürün Özellik Ürün Bağı Listesi Alma

Ürün Özellik Ürün Bağı listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SpecToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$product = 56; // int | Ürün id
$spec_group = 56; // int | Ürün özellik grubu id
$spec_name = 56; // int | Ürün özellik id
$spec_value = 56; // int | Ürün özellik değeri id

try {
    $result = $apiInstance->specToProductsGet($sort, $limit, $page, $since_id, $product, $spec_group, $spec_name, $spec_value);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SpecToProductApi->specToProductsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **product** | **int**| Ürün id | [optional]
 **spec_group** | **int**| Ürün özellik grubu id | [optional]
 **spec_name** | **int**| Ürün özellik id | [optional]
 **spec_value** | **int**| Ürün özellik değeri id | [optional]

### Return type

[**\Swagger\Client\Model\SpecToProduct**](../Model/SpecToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **specToProductsIdDelete**
> specToProductsIdDelete($id)

Ürün Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SpecToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Özellik Ürün Bağı nesnesinin id değeri

try {
    $apiInstance->specToProductsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling SpecToProductApi->specToProductsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Ürün Bağı nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **specToProductsIdGet**
> \Swagger\Client\Model\SpecToProduct specToProductsIdGet($id)

Ürün Özellik Ürün Bağı Alma

İlgili Ürün Özellik Ürün Bağını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SpecToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Özellik Ürün Bağı nesnesinin id değeri

try {
    $result = $apiInstance->specToProductsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SpecToProductApi->specToProductsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Ürün Bağı nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\SpecToProduct**](../Model/SpecToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **specToProductsIdPut**
> \Swagger\Client\Model\SpecToProduct specToProductsIdPut($id, $spec_to_product)

Ürün Özellik Ürün Bağı Güncelleme

İlgili Ürün Özellik Ürün Bağını günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SpecToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Özellik Ürün Bağı nesnesinin id değeri
$spec_to_product = new \Swagger\Client\Model\SpecToProduct(); // \Swagger\Client\Model\SpecToProduct | SpecToProduct nesnesi

try {
    $result = $apiInstance->specToProductsIdPut($id, $spec_to_product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SpecToProductApi->specToProductsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Ürün Bağı nesnesinin id değeri |
 **spec_to_product** | [**\Swagger\Client\Model\SpecToProduct**](../Model/SpecToProduct.md)| SpecToProduct nesnesi |

### Return type

[**\Swagger\Client\Model\SpecToProduct**](../Model/SpecToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **specToProductsPost**
> \Swagger\Client\Model\SpecToProduct specToProductsPost($spec_to_product)

Ürün Özellik Ürün Bağı Oluşturma

Yeni bir Ürün Özellik Ürün Bağı oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SpecToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$spec_to_product = new \Swagger\Client\Model\SpecToProduct(); // \Swagger\Client\Model\SpecToProduct | SpecToProduct nesnesi

try {
    $result = $apiInstance->specToProductsPost($spec_to_product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SpecToProductApi->specToProductsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **spec_to_product** | [**\Swagger\Client\Model\SpecToProduct**](../Model/SpecToProduct.md)| SpecToProduct nesnesi |

### Return type

[**\Swagger\Client\Model\SpecToProduct**](../Model/SpecToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

