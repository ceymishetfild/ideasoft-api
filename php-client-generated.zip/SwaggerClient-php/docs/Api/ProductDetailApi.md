# Swagger\Client\ProductDetailApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productDetailsGet**](ProductDetailApi.md#productDetailsGet) | **GET** /product_details | Ürün Detay Listesi Alma
[**productDetailsIdDelete**](ProductDetailApi.md#productDetailsIdDelete) | **DELETE** /product_details/{id} | Ürün Detay Silme
[**productDetailsIdGet**](ProductDetailApi.md#productDetailsIdGet) | **GET** /product_details/{id} | Ürün Detay Alma
[**productDetailsIdPut**](ProductDetailApi.md#productDetailsIdPut) | **PUT** /product_details/{id} | Ürün Detay Güncelleme
[**productDetailsPost**](ProductDetailApi.md#productDetailsPost) | **POST** /product_details | Ürün Detay Oluşturma


# **productDetailsGet**
> \Swagger\Client\Model\ProductDetail productDetailsGet($sort, $limit, $page, $since_id, $sku)

Ürün Detay Listesi Alma

Ürün Detay listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductDetailApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$sku = "sku_example"; // string | Ürün stok kodu

try {
    $result = $apiInstance->productDetailsGet($sort, $limit, $page, $since_id, $sku);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductDetailApi->productDetailsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **sku** | **string**| Ürün stok kodu | [optional]

### Return type

[**\Swagger\Client\Model\ProductDetail**](../Model/ProductDetail.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productDetailsIdDelete**
> productDetailsIdDelete($id)

Ürün Detay Silme

Kalıcı olarak ilgili Ürün Detayını siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductDetailApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Detay nesnesinin id değeri

try {
    $apiInstance->productDetailsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling ProductDetailApi->productDetailsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Detay nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productDetailsIdGet**
> \Swagger\Client\Model\ProductDetail productDetailsIdGet($id)

Ürün Detay Alma

İlgili Ürün Detayını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductDetailApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Detay nesnesinin id değeri

try {
    $result = $apiInstance->productDetailsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductDetailApi->productDetailsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Detay nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\ProductDetail**](../Model/ProductDetail.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productDetailsIdPut**
> \Swagger\Client\Model\ProductDetail productDetailsIdPut($id, $product_detail)

Ürün Detay Güncelleme

İlgili Ürün Detayını günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductDetailApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Detay nesnesinin id değeri
$product_detail = new \Swagger\Client\Model\ProductDetail(); // \Swagger\Client\Model\ProductDetail | ProductDetail nesnesi

try {
    $result = $apiInstance->productDetailsIdPut($id, $product_detail);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductDetailApi->productDetailsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Detay nesnesinin id değeri |
 **product_detail** | [**\Swagger\Client\Model\ProductDetail**](../Model/ProductDetail.md)| ProductDetail nesnesi |

### Return type

[**\Swagger\Client\Model\ProductDetail**](../Model/ProductDetail.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productDetailsPost**
> \Swagger\Client\Model\ProductDetail productDetailsPost($product_detail)

Ürün Detay Oluşturma

Yeni bir Ürün Detay oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductDetailApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$product_detail = new \Swagger\Client\Model\ProductDetail(); // \Swagger\Client\Model\ProductDetail | ProductDetail nesnesi

try {
    $result = $apiInstance->productDetailsPost($product_detail);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductDetailApi->productDetailsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_detail** | [**\Swagger\Client\Model\ProductDetail**](../Model/ProductDetail.md)| ProductDetail nesnesi |

### Return type

[**\Swagger\Client\Model\ProductDetail**](../Model/ProductDetail.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

