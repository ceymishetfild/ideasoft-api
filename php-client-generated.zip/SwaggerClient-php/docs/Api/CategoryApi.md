# Swagger\Client\CategoryApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**categoriesGet**](CategoryApi.md#categoriesGet) | **GET** /categories | Kategori Listesi Alma
[**categoriesIdDelete**](CategoryApi.md#categoriesIdDelete) | **DELETE** /categories/{id} | Kategori Silme
[**categoriesIdGet**](CategoryApi.md#categoriesIdGet) | **GET** /categories/{id} | Kategori Alma
[**categoriesIdPut**](CategoryApi.md#categoriesIdPut) | **PUT** /categories/{id} | Kategori Güncelleme
[**categoriesPost**](CategoryApi.md#categoriesPost) | **POST** /categories | Kategori Oluşturma


# **categoriesGet**
> \Swagger\Client\Model\Category categoriesGet($sort, $limit, $page, $since_id, $name, $status, $distributor, $parent, $start_date, $end_date, $start_updated_at, $end_updated_at)

Kategori Listesi Alma

Kategori listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CategoryApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$name = "name_example"; // string | Kategori adı
$status = 56; // int | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
$distributor = "distributor_example"; // string | Kategori Distribütör
$parent = 56; // int | Üst kategori id
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi
$start_updated_at = new \DateTime("2013-10-20"); // \DateTime | updatedAt değeri için başlangıç tarihi
$end_updated_at = "end_updated_at_example"; // string | updatedAt değeri için bitiş tarihi

try {
    $result = $apiInstance->categoriesGet($sort, $limit, $page, $since_id, $name, $status, $distributor, $parent, $start_date, $end_date, $start_updated_at, $end_updated_at);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CategoryApi->categoriesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **name** | **string**| Kategori adı | [optional]
 **status** | **int**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional]
 **distributor** | **string**| Kategori Distribütör | [optional]
 **parent** | **int**| Üst kategori id | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]
 **start_updated_at** | **\DateTime**| updatedAt değeri için başlangıç tarihi | [optional]
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**\Swagger\Client\Model\Category**](../Model/Category.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **categoriesIdDelete**
> categoriesIdDelete($id)

Kategori Silme

Kalıcı olarak ilgili Kategoriyi siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CategoryApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Kategori nesnesinin id değeri

try {
    $apiInstance->categoriesIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling CategoryApi->categoriesIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kategori nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **categoriesIdGet**
> \Swagger\Client\Model\Category categoriesIdGet($id)

Kategori Alma

İlgili Kategoriyi getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CategoryApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Kategori nesnesinin id değeri

try {
    $result = $apiInstance->categoriesIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CategoryApi->categoriesIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kategori nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\Category**](../Model/Category.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **categoriesIdPut**
> \Swagger\Client\Model\Category categoriesIdPut($id, $category)

Kategori Güncelleme

İlgili Kategoriyi günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CategoryApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Kategori nesnesinin id değeri
$category = new \Swagger\Client\Model\Category(); // \Swagger\Client\Model\Category | Category nesnesi

try {
    $result = $apiInstance->categoriesIdPut($id, $category);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CategoryApi->categoriesIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kategori nesnesinin id değeri |
 **category** | [**\Swagger\Client\Model\Category**](../Model/Category.md)| Category nesnesi |

### Return type

[**\Swagger\Client\Model\Category**](../Model/Category.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **categoriesPost**
> \Swagger\Client\Model\Category categoriesPost($category)

Kategori Oluşturma

Yeni bir Kategori oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CategoryApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$category = new \Swagger\Client\Model\Category(); // \Swagger\Client\Model\Category | Category nesnesi

try {
    $result = $apiInstance->categoriesPost($category);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CategoryApi->categoriesPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **category** | [**\Swagger\Client\Model\Category**](../Model/Category.md)| Category nesnesi |

### Return type

[**\Swagger\Client\Model\Category**](../Model/Category.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

