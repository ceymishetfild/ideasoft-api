# Swagger\Client\OrderUserNoteApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**orderUserNotesGet**](OrderUserNoteApi.md#orderUserNotesGet) | **GET** /order_user_notes | Sipariş Yönetici Notu Listesi Alma
[**orderUserNotesIdDelete**](OrderUserNoteApi.md#orderUserNotesIdDelete) | **DELETE** /order_user_notes/{id} | Sipariş Yönetici Notu Silme
[**orderUserNotesIdGet**](OrderUserNoteApi.md#orderUserNotesIdGet) | **GET** /order_user_notes/{id} | Sipariş Yönetici Notu Alma
[**orderUserNotesIdPut**](OrderUserNoteApi.md#orderUserNotesIdPut) | **PUT** /order_user_notes/{id} | Sipariş Yönetici Notu Güncelleme
[**orderUserNotesPost**](OrderUserNoteApi.md#orderUserNotesPost) | **POST** /order_user_notes | Sipariş Yönetici Notu Oluşturma


# **orderUserNotesGet**
> \Swagger\Client\Model\OrderUserNote orderUserNotesGet($sort, $limit, $page, $since_id, $order, $user_email, $start_date, $end_date, $start_updated_at, $end_updated_at)

Sipariş Yönetici Notu Listesi Alma

Sipariş Yönetici Notu listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OrderUserNoteApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$order = 56; // int | Sipariş id
$user_email = "user_email_example"; // string | Yönetici e-mail
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi
$start_updated_at = new \DateTime("2013-10-20"); // \DateTime | updatedAt değeri için başlangıç tarihi
$end_updated_at = "end_updated_at_example"; // string | updatedAt değeri için bitiş tarihi

try {
    $result = $apiInstance->orderUserNotesGet($sort, $limit, $page, $since_id, $order, $user_email, $start_date, $end_date, $start_updated_at, $end_updated_at);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrderUserNoteApi->orderUserNotesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **order** | **int**| Sipariş id | [optional]
 **user_email** | **string**| Yönetici e-mail | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]
 **start_updated_at** | **\DateTime**| updatedAt değeri için başlangıç tarihi | [optional]
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**\Swagger\Client\Model\OrderUserNote**](../Model/OrderUserNote.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **orderUserNotesIdDelete**
> orderUserNotesIdDelete($id)

Sipariş Yönetici Notu Silme

Kalıcı olarak ilgili Sipariş Yönetici Notunu siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OrderUserNoteApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sipariş Yönetici Notu nesnesinin id değeri

try {
    $apiInstance->orderUserNotesIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling OrderUserNoteApi->orderUserNotesIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Yönetici Notu nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **orderUserNotesIdGet**
> \Swagger\Client\Model\OrderUserNote orderUserNotesIdGet($id)

Sipariş Yönetici Notu Alma

İlgili Sipariş Yönetici Notunu getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OrderUserNoteApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sipariş Yönetici Notu nesnesinin id değeri

try {
    $result = $apiInstance->orderUserNotesIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrderUserNoteApi->orderUserNotesIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Yönetici Notu nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\OrderUserNote**](../Model/OrderUserNote.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **orderUserNotesIdPut**
> \Swagger\Client\Model\OrderUserNote orderUserNotesIdPut($id, $order_user_note)

Sipariş Yönetici Notu Güncelleme

İlgili Sipariş Yönetici Notunu günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OrderUserNoteApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sipariş Yönetici Notu nesnesinin id değeri
$order_user_note = new \Swagger\Client\Model\OrderUserNote(); // \Swagger\Client\Model\OrderUserNote | OrderUserNote nesnesi

try {
    $result = $apiInstance->orderUserNotesIdPut($id, $order_user_note);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrderUserNoteApi->orderUserNotesIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Yönetici Notu nesnesinin id değeri |
 **order_user_note** | [**\Swagger\Client\Model\OrderUserNote**](../Model/OrderUserNote.md)| OrderUserNote nesnesi |

### Return type

[**\Swagger\Client\Model\OrderUserNote**](../Model/OrderUserNote.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **orderUserNotesPost**
> \Swagger\Client\Model\OrderUserNote orderUserNotesPost($order_user_note)

Sipariş Yönetici Notu Oluşturma

Yeni bir Sipariş Yönetici Notu oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OrderUserNoteApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$order_user_note = new \Swagger\Client\Model\OrderUserNote(); // \Swagger\Client\Model\OrderUserNote | OrderUserNote nesnesi

try {
    $result = $apiInstance->orderUserNotesPost($order_user_note);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrderUserNoteApi->orderUserNotesPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_user_note** | [**\Swagger\Client\Model\OrderUserNote**](../Model/OrderUserNote.md)| OrderUserNote nesnesi |

### Return type

[**\Swagger\Client\Model\OrderUserNote**](../Model/OrderUserNote.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

