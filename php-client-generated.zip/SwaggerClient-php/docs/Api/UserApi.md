# Swagger\Client\UserApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**usersGet**](UserApi.md#usersGet) | **GET** /users | Yönetici Listesi Alma
[**usersIdGet**](UserApi.md#usersIdGet) | **GET** /users/{id} | Yönetici Alma


# **usersGet**
> \Swagger\Client\Model\User usersGet($sort, $limit, $page, $since_id, $firstname, $surname, $email, $username, $phone_number, $is_owner, $status, $start_date, $end_date, $start_updated_at, $end_updated_at)

Yönetici Listesi Alma

Yönetici listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\UserApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$firstname = "firstname_example"; // string | Adı
$surname = "surname_example"; // string | Soyadı
$email = "email_example"; // string | e-mail
$username = "username_example"; // string | Yönetici adı
$phone_number = "phone_number_example"; // string | Telefon numarası
$is_owner = 56; // int | Mağaza sahibi mi?<code>0</code><br><code>1</code>
$status = "status_example"; // string | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif<br><code>2</code> : Askıya alınmış
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi
$start_updated_at = new \DateTime("2013-10-20"); // \DateTime | updatedAt değeri için başlangıç tarihi
$end_updated_at = "end_updated_at_example"; // string | updatedAt değeri için bitiş tarihi

try {
    $result = $apiInstance->usersGet($sort, $limit, $page, $since_id, $firstname, $surname, $email, $username, $phone_number, $is_owner, $status, $start_date, $end_date, $start_updated_at, $end_updated_at);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling UserApi->usersGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **firstname** | **string**| Adı | [optional]
 **surname** | **string**| Soyadı | [optional]
 **email** | **string**| e-mail | [optional]
 **username** | **string**| Yönetici adı | [optional]
 **phone_number** | **string**| Telefon numarası | [optional]
 **is_owner** | **int**| Mağaza sahibi mi?&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional]
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Askıya alınmış | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]
 **start_updated_at** | **\DateTime**| updatedAt değeri için başlangıç tarihi | [optional]
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**\Swagger\Client\Model\User**](../Model/User.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **usersIdGet**
> \Swagger\Client\Model\User usersIdGet($id)

Yönetici Alma

İlgili Yöneticiyi  getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\UserApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Yönetici nesnesinin id değeri

try {
    $result = $apiInstance->usersIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling UserApi->usersIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Yönetici nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\User**](../Model/User.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

