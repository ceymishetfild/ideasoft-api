# Swagger\Client\ProductPriceApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productPricesGet**](ProductPriceApi.md#productPricesGet) | **GET** /product_prices | Ürün Fiyat Listesi Alma
[**productPricesIdDelete**](ProductPriceApi.md#productPricesIdDelete) | **DELETE** /product_prices/{id} | Ürün Fiyat Silme
[**productPricesIdGet**](ProductPriceApi.md#productPricesIdGet) | **GET** /product_prices/{id} | Ürün Fiyat Alma
[**productPricesIdPut**](ProductPriceApi.md#productPricesIdPut) | **PUT** /product_prices/{id} | Ürün Fiyat Güncelleme
[**productPricesPost**](ProductPriceApi.md#productPricesPost) | **POST** /product_prices | Ürün Fiyat Oluşturma


# **productPricesGet**
> \Swagger\Client\Model\ProductPrice productPricesGet($sort, $limit, $page, $since_id, $type, $product)

Ürün Fiyat Listesi Alma

Ürün Fiyat listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductPriceApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$type = 56; // int | Ürün fiyat tipi
$product = 56; // int | Ürün id

try {
    $result = $apiInstance->productPricesGet($sort, $limit, $page, $since_id, $type, $product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductPriceApi->productPricesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **type** | **int**| Ürün fiyat tipi | [optional]
 **product** | **int**| Ürün id | [optional]

### Return type

[**\Swagger\Client\Model\ProductPrice**](../Model/ProductPrice.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productPricesIdDelete**
> productPricesIdDelete($id)

Ürün Fiyat Silme

Kalıcı olarak ilgili Ürün Fiyatını siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductPriceApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Fiyat nesnesinin id değeri

try {
    $apiInstance->productPricesIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling ProductPriceApi->productPricesIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Fiyat nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productPricesIdGet**
> \Swagger\Client\Model\ProductPrice productPricesIdGet($id)

Ürün Fiyat Alma

İlgili Ürün Fiyatını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductPriceApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Fiyat nesnesinin id değeri

try {
    $result = $apiInstance->productPricesIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductPriceApi->productPricesIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Fiyat nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\ProductPrice**](../Model/ProductPrice.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productPricesIdPut**
> \Swagger\Client\Model\ProductPrice productPricesIdPut($id, $product_price)

Ürün Fiyat Güncelleme

İlgili Ürün Fiyatını günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductPriceApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Fiyat nesnesinin id değeri
$product_price = new \Swagger\Client\Model\ProductPrice(); // \Swagger\Client\Model\ProductPrice | ProductPrice nesnesi

try {
    $result = $apiInstance->productPricesIdPut($id, $product_price);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductPriceApi->productPricesIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Fiyat nesnesinin id değeri |
 **product_price** | [**\Swagger\Client\Model\ProductPrice**](../Model/ProductPrice.md)| ProductPrice nesnesi |

### Return type

[**\Swagger\Client\Model\ProductPrice**](../Model/ProductPrice.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productPricesPost**
> \Swagger\Client\Model\ProductPrice productPricesPost($product_price)

Ürün Fiyat Oluşturma

Yeni bir Ürün Fiyat oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductPriceApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$product_price = new \Swagger\Client\Model\ProductPrice(); // \Swagger\Client\Model\ProductPrice | ProductPrice nesnesi

try {
    $result = $apiInstance->productPricesPost($product_price);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductPriceApi->productPricesPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_price** | [**\Swagger\Client\Model\ProductPrice**](../Model/ProductPrice.md)| ProductPrice nesnesi |

### Return type

[**\Swagger\Client\Model\ProductPrice**](../Model/ProductPrice.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

