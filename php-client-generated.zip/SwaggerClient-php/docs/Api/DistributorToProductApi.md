# Swagger\Client\DistributorToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**distributorToProductsGet**](DistributorToProductApi.md#distributorToProductsGet) | **GET** /distributor_to_products | Distribütör Ürün Bağı Listesi Alma
[**distributorToProductsIdDelete**](DistributorToProductApi.md#distributorToProductsIdDelete) | **DELETE** /distributor_to_products/{id} | Distribütör Ürün Bağı Silme
[**distributorToProductsIdGet**](DistributorToProductApi.md#distributorToProductsIdGet) | **GET** /distributor_to_products/{id} | Distribütör Ürün Bağı Alma
[**distributorToProductsIdPut**](DistributorToProductApi.md#distributorToProductsIdPut) | **PUT** /distributor_to_products/{id} | Distribütör Ürün Bağı Güncelleme
[**distributorToProductsPost**](DistributorToProductApi.md#distributorToProductsPost) | **POST** /distributor_to_products | Distribütör Ürün Bağı Oluşturma


# **distributorToProductsGet**
> \Swagger\Client\Model\DistributorToProduct distributorToProductsGet($sort, $limit, $page, $since_id, $distributor, $product)

Distribütör Ürün Bağı Listesi Alma

Distribütör Ürün Bağı listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DistributorToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$distributor = 56; // int | Distribütör id
$product = 56; // int | Ürün id

try {
    $result = $apiInstance->distributorToProductsGet($sort, $limit, $page, $since_id, $distributor, $product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DistributorToProductApi->distributorToProductsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **distributor** | **int**| Distribütör id | [optional]
 **product** | **int**| Ürün id | [optional]

### Return type

[**\Swagger\Client\Model\DistributorToProduct**](../Model/DistributorToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **distributorToProductsIdDelete**
> distributorToProductsIdDelete($id)

Distribütör Ürün Bağı Silme

Kalıcı olarak ilgili Distribütör Ürün Bağını siler

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DistributorToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Distribütör Ürün Bağı nesnesinin id değeri

try {
    $apiInstance->distributorToProductsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling DistributorToProductApi->distributorToProductsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Distribütör Ürün Bağı nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **distributorToProductsIdGet**
> \Swagger\Client\Model\DistributorToProduct distributorToProductsIdGet($id)

Distribütör Ürün Bağı Alma

İlgili Distribütör Ürün Bağını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DistributorToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Distribütör Ürün Bağı nesnesinin id değeri

try {
    $result = $apiInstance->distributorToProductsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DistributorToProductApi->distributorToProductsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Distribütör Ürün Bağı nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\DistributorToProduct**](../Model/DistributorToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **distributorToProductsIdPut**
> \Swagger\Client\Model\DistributorToProduct distributorToProductsIdPut($id, $distributor_to_product)

Distribütör Ürün Bağı Güncelleme

İlgili Distribütör Ürün Bağını günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DistributorToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Distribütör Ürün Bağı nesnesinin id değeri
$distributor_to_product = new \Swagger\Client\Model\DistributorToProduct(); // \Swagger\Client\Model\DistributorToProduct | DistributorToProduct nesnesi

try {
    $result = $apiInstance->distributorToProductsIdPut($id, $distributor_to_product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DistributorToProductApi->distributorToProductsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Distribütör Ürün Bağı nesnesinin id değeri |
 **distributor_to_product** | [**\Swagger\Client\Model\DistributorToProduct**](../Model/DistributorToProduct.md)| DistributorToProduct nesnesi |

### Return type

[**\Swagger\Client\Model\DistributorToProduct**](../Model/DistributorToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **distributorToProductsPost**
> \Swagger\Client\Model\DistributorToProduct distributorToProductsPost($distributor_to_product)

Distribütör Ürün Bağı Oluşturma

Yeni bir Distribütör Ürün Bağı oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DistributorToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$distributor_to_product = new \Swagger\Client\Model\DistributorToProduct(); // \Swagger\Client\Model\DistributorToProduct | DistributorToProduct nesnesi

try {
    $result = $apiInstance->distributorToProductsPost($distributor_to_product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DistributorToProductApi->distributorToProductsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **distributor_to_product** | [**\Swagger\Client\Model\DistributorToProduct**](../Model/DistributorToProduct.md)| DistributorToProduct nesnesi |

### Return type

[**\Swagger\Client\Model\DistributorToProduct**](../Model/DistributorToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

