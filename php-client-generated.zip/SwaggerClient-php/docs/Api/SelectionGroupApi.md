# Swagger\Client\SelectionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selectionGroupsGet**](SelectionGroupApi.md#selectionGroupsGet) | **GET** /selection_groups | Ek Özellik Grubu Listesi Alma
[**selectionGroupsIdDelete**](SelectionGroupApi.md#selectionGroupsIdDelete) | **DELETE** /selection_groups/{id} | Ek Özellik Grubu Silme
[**selectionGroupsIdGet**](SelectionGroupApi.md#selectionGroupsIdGet) | **GET** /selection_groups/{id} | Ek Özellik Grubu Alma
[**selectionGroupsIdPut**](SelectionGroupApi.md#selectionGroupsIdPut) | **PUT** /selection_groups/{id} | Ek Özellik Grubu Güncelleme
[**selectionGroupsPost**](SelectionGroupApi.md#selectionGroupsPost) | **POST** /selection_groups | Ek Özellik Grubu Oluşturma


# **selectionGroupsGet**
> \Swagger\Client\Model\SelectionGroup selectionGroupsGet($sort, $limit, $page, $since_id, $title)

Ek Özellik Grubu Listesi Alma

Ek Özellik Grubu listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SelectionGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$title = "title_example"; // string | Ek Özellik Grubu başlığı

try {
    $result = $apiInstance->selectionGroupsGet($sort, $limit, $page, $since_id, $title);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SelectionGroupApi->selectionGroupsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **title** | **string**| Ek Özellik Grubu başlığı | [optional]

### Return type

[**\Swagger\Client\Model\SelectionGroup**](../Model/SelectionGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **selectionGroupsIdDelete**
> selectionGroupsIdDelete($id)

Ek Özellik Grubu Silme

Kalıcı olarak ilgili Ek Özellik Grubunu siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SelectionGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ek Özellik Grubu nesnesinin id değeri

try {
    $apiInstance->selectionGroupsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling SelectionGroupApi->selectionGroupsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik Grubu nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **selectionGroupsIdGet**
> \Swagger\Client\Model\SelectionGroup selectionGroupsIdGet($id)

Ek Özellik Grubu Alma

İlgili Ek Özellik Grubunu getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SelectionGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ek Özellik Grubu nesnesinin id değeri

try {
    $result = $apiInstance->selectionGroupsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SelectionGroupApi->selectionGroupsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik Grubu nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\SelectionGroup**](../Model/SelectionGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **selectionGroupsIdPut**
> \Swagger\Client\Model\SelectionGroup selectionGroupsIdPut($id, $selection_group)

Ek Özellik Grubu Güncelleme

İlgili Ek Özellik Grubunu günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SelectionGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ek Özellik Grubu nesnesinin id değeri
$selection_group = new \Swagger\Client\Model\SelectionGroup(); // \Swagger\Client\Model\SelectionGroup | SelectionGroup nesnesi

try {
    $result = $apiInstance->selectionGroupsIdPut($id, $selection_group);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SelectionGroupApi->selectionGroupsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik Grubu nesnesinin id değeri |
 **selection_group** | [**\Swagger\Client\Model\SelectionGroup**](../Model/SelectionGroup.md)| SelectionGroup nesnesi |

### Return type

[**\Swagger\Client\Model\SelectionGroup**](../Model/SelectionGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **selectionGroupsPost**
> \Swagger\Client\Model\SelectionGroup selectionGroupsPost($selection_group)

Ek Özellik Grubu Oluşturma

Yeni bir Ek Özellik Grubu oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SelectionGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$selection_group = new \Swagger\Client\Model\SelectionGroup(); // \Swagger\Client\Model\SelectionGroup | SelectionGroup nesnesi

try {
    $result = $apiInstance->selectionGroupsPost($selection_group);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SelectionGroupApi->selectionGroupsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selection_group** | [**\Swagger\Client\Model\SelectionGroup**](../Model/SelectionGroup.md)| SelectionGroup nesnesi |

### Return type

[**\Swagger\Client\Model\SelectionGroup**](../Model/SelectionGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

