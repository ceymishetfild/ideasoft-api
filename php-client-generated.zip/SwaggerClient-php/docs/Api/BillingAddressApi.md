# Swagger\Client\BillingAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**billingAddressesGet**](BillingAddressApi.md#billingAddressesGet) | **GET** /billing_addresses | Fatura Adresi Listesi Alma
[**billingAddressesIdGet**](BillingAddressApi.md#billingAddressesIdGet) | **GET** /billing_addresses/{id} | Fatura Adresi Alma
[**billingAddressesIdPut**](BillingAddressApi.md#billingAddressesIdPut) | **PUT** /billing_addresses/{id} | Fatura Adresi Güncelleme
[**billingAddressesPost**](BillingAddressApi.md#billingAddressesPost) | **POST** /billing_addresses | Fatura Adresi Oluşturma


# **billingAddressesGet**
> \Swagger\Client\Model\BillingAddress billingAddressesGet($sort, $limit, $page, $since_id, $order, $start_date, $end_date, $start_updated_at, $end_updated_at)

Fatura Adresi Listesi Alma

Fatura Adresi listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\BillingAddressApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$order = 56; // int | Sipariş id
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi
$start_updated_at = new \DateTime("2013-10-20"); // \DateTime | updatedAt değeri için başlangıç tarihi
$end_updated_at = "end_updated_at_example"; // string | updatedAt değeri için bitiş tarihi

try {
    $result = $apiInstance->billingAddressesGet($sort, $limit, $page, $since_id, $order, $start_date, $end_date, $start_updated_at, $end_updated_at);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BillingAddressApi->billingAddressesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **order** | **int**| Sipariş id | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]
 **start_updated_at** | **\DateTime**| updatedAt değeri için başlangıç tarihi | [optional]
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**\Swagger\Client\Model\BillingAddress**](../Model/BillingAddress.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **billingAddressesIdGet**
> \Swagger\Client\Model\BillingAddress billingAddressesIdGet($id)

Fatura Adresi Alma

İlgili Fatura Adresini getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\BillingAddressApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Fatura Adresi nesnesinin id değeri

try {
    $result = $apiInstance->billingAddressesIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BillingAddressApi->billingAddressesIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Fatura Adresi nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\BillingAddress**](../Model/BillingAddress.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **billingAddressesIdPut**
> \Swagger\Client\Model\BillingAddress billingAddressesIdPut($id, $billing_address)

Fatura Adresi Güncelleme

İlgili Fatura Adresini günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\BillingAddressApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Fatura Adresi nesnesinin id değeri
$billing_address = new \Swagger\Client\Model\BillingAddress(); // \Swagger\Client\Model\BillingAddress | BillingAddress nesnesi

try {
    $result = $apiInstance->billingAddressesIdPut($id, $billing_address);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BillingAddressApi->billingAddressesIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Fatura Adresi nesnesinin id değeri |
 **billing_address** | [**\Swagger\Client\Model\BillingAddress**](../Model/BillingAddress.md)| BillingAddress nesnesi |

### Return type

[**\Swagger\Client\Model\BillingAddress**](../Model/BillingAddress.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **billingAddressesPost**
> \Swagger\Client\Model\BillingAddress billingAddressesPost($billing_address)

Fatura Adresi Oluşturma

Yeni bir Fatura Adresi oluşturur. Fatura Adresi oluşturabilmek için geçerli bir önceden tanımlanmış Sipariş id değerine ihtiyaç vardır.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\BillingAddressApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$billing_address = new \Swagger\Client\Model\BillingAddress(); // \Swagger\Client\Model\BillingAddress | BillingAddress nesnesi

try {
    $result = $apiInstance->billingAddressesPost($billing_address);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BillingAddressApi->billingAddressesPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **billing_address** | [**\Swagger\Client\Model\BillingAddress**](../Model/BillingAddress.md)| BillingAddress nesnesi |

### Return type

[**\Swagger\Client\Model\BillingAddress**](../Model/BillingAddress.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

