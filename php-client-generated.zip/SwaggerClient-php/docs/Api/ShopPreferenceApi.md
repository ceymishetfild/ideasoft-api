# Swagger\Client\ShopPreferenceApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**preferencesGet**](ShopPreferenceApi.md#preferencesGet) | **GET** /preferences | Tanımlamalar Listesi Alma
[**preferencesIdGet**](ShopPreferenceApi.md#preferencesIdGet) | **GET** /preferences/{id} | Tanımlamalar Alma
[**preferencesIdPut**](ShopPreferenceApi.md#preferencesIdPut) | **PUT** /preferences/{id} | Tanımlamalar Güncelleme


# **preferencesGet**
> \Swagger\Client\Model\ShopPreference preferencesGet($sort, $limit, $page, $since_id, $var_key)

Tanımlamalar Listesi Alma

Tanımlamalar listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShopPreferenceApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 100; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$var_key = "var_key_example"; // string | Tanımlama varKey değeri

try {
    $result = $apiInstance->preferencesGet($sort, $limit, $page, $since_id, $var_key);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShopPreferenceApi->preferencesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 100]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **var_key** | **string**| Tanımlama varKey değeri | [optional]

### Return type

[**\Swagger\Client\Model\ShopPreference**](../Model/ShopPreference.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **preferencesIdGet**
> \Swagger\Client\Model\ShopPreference preferencesIdGet($id)

Tanımlamalar Alma

İlgili Tanımlamayı getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShopPreferenceApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Tanımlama nesnesinin id değeri

try {
    $result = $apiInstance->preferencesIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShopPreferenceApi->preferencesIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tanımlama nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\ShopPreference**](../Model/ShopPreference.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **preferencesIdPut**
> \Swagger\Client\Model\ShopPreference preferencesIdPut($id, $shop_preference)

Tanımlamalar Güncelleme

İlgili Tanımlamayı günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShopPreferenceApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Tanımlama nesnesinin id değeri
$shop_preference = new \Swagger\Client\Model\ShopPreference(); // \Swagger\Client\Model\ShopPreference | ShopPreference nesnesi

try {
    $result = $apiInstance->preferencesIdPut($id, $shop_preference);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShopPreferenceApi->preferencesIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tanımlama nesnesinin id değeri |
 **shop_preference** | [**\Swagger\Client\Model\ShopPreference**](../Model/ShopPreference.md)| ShopPreference nesnesi |

### Return type

[**\Swagger\Client\Model\ShopPreference**](../Model/ShopPreference.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

