# Swagger\Client\SelectionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selectionsGet**](SelectionApi.md#selectionsGet) | **GET** /selections | Ek Özellik Listesi Alma
[**selectionsIdDelete**](SelectionApi.md#selectionsIdDelete) | **DELETE** /selections/{id} | Ek Özellik Silme
[**selectionsIdGet**](SelectionApi.md#selectionsIdGet) | **GET** /selections/{id} | Ek Özellik Alma
[**selectionsIdPut**](SelectionApi.md#selectionsIdPut) | **PUT** /selections/{id} | Ek Özellik Güncelleme
[**selectionsPost**](SelectionApi.md#selectionsPost) | **POST** /selections | Ek Özellik Oluşturma


# **selectionsGet**
> \Swagger\Client\Model\Selection selectionsGet($sort, $limit, $page, $since_id, $title, $selection_group)

Ek Özellik Listesi Alma

Ek Özellik listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SelectionApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$title = "title_example"; // string | Ek Özellik başlığı
$selection_group = 56; // int | Ek Özellik Grubu id

try {
    $result = $apiInstance->selectionsGet($sort, $limit, $page, $since_id, $title, $selection_group);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SelectionApi->selectionsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **title** | **string**| Ek Özellik başlığı | [optional]
 **selection_group** | **int**| Ek Özellik Grubu id | [optional]

### Return type

[**\Swagger\Client\Model\Selection**](../Model/Selection.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **selectionsIdDelete**
> selectionsIdDelete($id)

Ek Özellik Silme

Kalıcı olarak ilgili Ek Özelliği siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SelectionApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ek Özellik nesnesinin id değeri

try {
    $apiInstance->selectionsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling SelectionApi->selectionsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **selectionsIdGet**
> \Swagger\Client\Model\Selection selectionsIdGet($id)

Ek Özellik Alma

İlgili Ek Özelliği getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SelectionApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ek Özellik nesnesinin id değeri

try {
    $result = $apiInstance->selectionsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SelectionApi->selectionsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\Selection**](../Model/Selection.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **selectionsIdPut**
> \Swagger\Client\Model\Selection selectionsIdPut($id, $selection)

Ek Özellik Güncelleme

İlgili Ek Özelliği günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SelectionApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ek Özellik nesnesinin id değeri
$selection = new \Swagger\Client\Model\Selection(); // \Swagger\Client\Model\Selection | Selection nesnesi

try {
    $result = $apiInstance->selectionsIdPut($id, $selection);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SelectionApi->selectionsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik nesnesinin id değeri |
 **selection** | [**\Swagger\Client\Model\Selection**](../Model/Selection.md)| Selection nesnesi |

### Return type

[**\Swagger\Client\Model\Selection**](../Model/Selection.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **selectionsPost**
> \Swagger\Client\Model\Selection selectionsPost($selection)

Ek Özellik Oluşturma

Yeni bir Ek Özellik oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SelectionApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$selection = new \Swagger\Client\Model\Selection(); // \Swagger\Client\Model\Selection | Selection nesnesi

try {
    $result = $apiInstance->selectionsPost($selection);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SelectionApi->selectionsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selection** | [**\Swagger\Client\Model\Selection**](../Model/Selection.md)| Selection nesnesi |

### Return type

[**\Swagger\Client\Model\Selection**](../Model/Selection.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

