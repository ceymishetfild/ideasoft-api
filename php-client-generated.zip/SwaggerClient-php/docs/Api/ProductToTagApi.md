# Swagger\Client\ProductToTagApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productToTagsGet**](ProductToTagApi.md#productToTagsGet) | **GET** /product_to_tags | Ürün SEO+ Bağı Listesi Alma
[**productToTagsIdDelete**](ProductToTagApi.md#productToTagsIdDelete) | **DELETE** /product_to_tags/{id} | Ürün SEO+ Bağı Silme
[**productToTagsIdGet**](ProductToTagApi.md#productToTagsIdGet) | **GET** /product_to_tags/{id} | Ürün SEO+ Bağı Alma
[**productToTagsIdPut**](ProductToTagApi.md#productToTagsIdPut) | **PUT** /product_to_tags/{id} | Ürün SEO+ Bağı Güncelleme
[**productToTagsPost**](ProductToTagApi.md#productToTagsPost) | **POST** /product_to_tags | Ürün SEO+ Bağı Oluşturma


# **productToTagsGet**
> \Swagger\Client\Model\ProductToTag productToTagsGet($sort, $limit, $page, $since_id, $product, $tag)

Ürün SEO+ Bağı Listesi Alma

Ürün SEO+ Bağı listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductToTagApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$product = 56; // int | Ürün id
$tag = 56; // int | Etiket id

try {
    $result = $apiInstance->productToTagsGet($sort, $limit, $page, $since_id, $product, $tag);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductToTagApi->productToTagsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **product** | **int**| Ürün id | [optional]
 **tag** | **int**| Etiket id | [optional]

### Return type

[**\Swagger\Client\Model\ProductToTag**](../Model/ProductToTag.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productToTagsIdDelete**
> productToTagsIdDelete($id)

Ürün SEO+ Bağı Silme

Kalıcı olarak ilgili Ürün SEO+ Bağını siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductToTagApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün SEO+ nesnesinin id değeri

try {
    $apiInstance->productToTagsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling ProductToTagApi->productToTagsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün SEO+ nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productToTagsIdGet**
> \Swagger\Client\Model\ProductToTag productToTagsIdGet($id)

Ürün SEO+ Bağı Alma

İlgili Ürün SEO+ Bağını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductToTagApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün SEO+ nesnesinin id değeri

try {
    $result = $apiInstance->productToTagsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductToTagApi->productToTagsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün SEO+ nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\ProductToTag**](../Model/ProductToTag.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productToTagsIdPut**
> \Swagger\Client\Model\ProductToTag productToTagsIdPut($id, $product_to_tag)

Ürün SEO+ Bağı Güncelleme

İlgili Ürün SEO+ Bağını günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductToTagApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün SEO+ nesnesinin id değeri
$product_to_tag = new \Swagger\Client\Model\ProductToTag(); // \Swagger\Client\Model\ProductToTag | ProductToTag nesnesi

try {
    $result = $apiInstance->productToTagsIdPut($id, $product_to_tag);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductToTagApi->productToTagsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün SEO+ nesnesinin id değeri |
 **product_to_tag** | [**\Swagger\Client\Model\ProductToTag**](../Model/ProductToTag.md)| ProductToTag nesnesi |

### Return type

[**\Swagger\Client\Model\ProductToTag**](../Model/ProductToTag.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productToTagsPost**
> \Swagger\Client\Model\ProductToTag productToTagsPost($product_to_tag)

Ürün SEO+ Bağı Oluşturma

Yeni bir Ürün SEO+ Bağı oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductToTagApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$product_to_tag = new \Swagger\Client\Model\ProductToTag(); // \Swagger\Client\Model\ProductToTag | ProductToTag nesnesi

try {
    $result = $apiInstance->productToTagsPost($product_to_tag);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductToTagApi->productToTagsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_to_tag** | [**\Swagger\Client\Model\ProductToTag**](../Model/ProductToTag.md)| ProductToTag nesnesi |

### Return type

[**\Swagger\Client\Model\ProductToTag**](../Model/ProductToTag.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

