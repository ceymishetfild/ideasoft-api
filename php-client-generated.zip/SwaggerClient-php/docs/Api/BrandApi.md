# Swagger\Client\BrandApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**brandsGet**](BrandApi.md#brandsGet) | **GET** /brands | Marka Listesi Alma
[**brandsIdDelete**](BrandApi.md#brandsIdDelete) | **DELETE** /brands/{id} | Marka Silme
[**brandsIdGet**](BrandApi.md#brandsIdGet) | **GET** /brands/{id} | Marka Alma
[**brandsIdPut**](BrandApi.md#brandsIdPut) | **PUT** /brands/{id} | Marka Güncelleme
[**brandsPost**](BrandApi.md#brandsPost) | **POST** /brands | Marka Oluşturma


# **brandsGet**
> \Swagger\Client\Model\Brand brandsGet($sort, $limit, $page, $since_id, $name, $status, $distributor, $start_date, $end_date, $start_updated_at, $end_updated_at, $q)

Marka Listesi Alma

Marka listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\BrandApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$name = "name_example"; // string | Marka adı.
$status = 56; // int | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
$distributor = "distributor_example"; // string | Marka distribörü
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi
$start_updated_at = new \DateTime("2013-10-20"); // \DateTime | updatedAt değeri için başlangıç tarihi
$end_updated_at = "end_updated_at_example"; // string | updatedAt değeri için bitiş tarihi
$q = array("q_example"); // string[] | Marka arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;]

try {
    $result = $apiInstance->brandsGet($sort, $limit, $page, $since_id, $name, $status, $distributor, $start_date, $end_date, $start_updated_at, $end_updated_at, $q);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BrandApi->brandsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **name** | **string**| Marka adı. | [optional]
 **status** | **int**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional]
 **distributor** | **string**| Marka distribörü | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]
 **start_updated_at** | **\DateTime**| updatedAt değeri için başlangıç tarihi | [optional]
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional]
 **q** | [**string[]**](../Model/string.md)| Marka arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional]

### Return type

[**\Swagger\Client\Model\Brand**](../Model/Brand.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **brandsIdDelete**
> brandsIdDelete($id)

Marka Silme

Kalıcı olarak ilgili Markayı siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\BrandApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Marka nesnesinin id değeri

try {
    $apiInstance->brandsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling BrandApi->brandsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Marka nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **brandsIdGet**
> \Swagger\Client\Model\Brand brandsIdGet($id)

Marka Alma

İlgili Markayı getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\BrandApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Marka nesnesinin id değeri

try {
    $result = $apiInstance->brandsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BrandApi->brandsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Marka nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\Brand**](../Model/Brand.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **brandsIdPut**
> \Swagger\Client\Model\Brand brandsIdPut($id, $brand)

Marka Güncelleme

İlgili Markayı günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\BrandApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Marka nesnesinin id değeri
$brand = new \Swagger\Client\Model\Brand(); // \Swagger\Client\Model\Brand | Brand nesnesi

try {
    $result = $apiInstance->brandsIdPut($id, $brand);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BrandApi->brandsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Marka nesnesinin id değeri |
 **brand** | [**\Swagger\Client\Model\Brand**](../Model/Brand.md)| Brand nesnesi |

### Return type

[**\Swagger\Client\Model\Brand**](../Model/Brand.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **brandsPost**
> \Swagger\Client\Model\Brand brandsPost($brand)

Marka Oluşturma

Yeni bir Marka oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\BrandApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$brand = new \Swagger\Client\Model\Brand(); // \Swagger\Client\Model\Brand | Brand nesnesi

try {
    $result = $apiInstance->brandsPost($brand);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling BrandApi->brandsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **brand** | [**\Swagger\Client\Model\Brand**](../Model/Brand.md)| Brand nesnesi |

### Return type

[**\Swagger\Client\Model\Brand**](../Model/Brand.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

