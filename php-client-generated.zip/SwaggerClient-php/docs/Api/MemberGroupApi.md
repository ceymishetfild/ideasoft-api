# Swagger\Client\MemberGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**memberGroupsGet**](MemberGroupApi.md#memberGroupsGet) | **GET** /member_groups | Üye Grubu Listesi Alma
[**memberGroupsIdDelete**](MemberGroupApi.md#memberGroupsIdDelete) | **DELETE** /member_groups/{id} | Üye Grubu Silme
[**memberGroupsIdGet**](MemberGroupApi.md#memberGroupsIdGet) | **GET** /member_groups/{id} | Üye Grubu Alma
[**memberGroupsIdPut**](MemberGroupApi.md#memberGroupsIdPut) | **PUT** /member_groups/{id} | Üye Grubu Güncelleme
[**memberGroupsPost**](MemberGroupApi.md#memberGroupsPost) | **POST** /member_groups | Üye Grubu Oluşturma


# **memberGroupsGet**
> \Swagger\Client\Model\MemberGroup memberGroupsGet($sort, $limit, $page, $since_id, $name)

Üye Grubu Listesi Alma

Üye Grubu listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$name = "name_example"; // string | Üye Grubu adı

try {
    $result = $apiInstance->memberGroupsGet($sort, $limit, $page, $since_id, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MemberGroupApi->memberGroupsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **name** | **string**| Üye Grubu adı | [optional]

### Return type

[**\Swagger\Client\Model\MemberGroup**](../Model/MemberGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **memberGroupsIdDelete**
> memberGroupsIdDelete($id)

Üye Grubu Silme

Kalıcı olarak ilgili Üye Grubunu siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Üye Grubu nesnesinin id değeri

try {
    $apiInstance->memberGroupsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling MemberGroupApi->memberGroupsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Grubu nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **memberGroupsIdGet**
> \Swagger\Client\Model\MemberGroup memberGroupsIdGet($id)

Üye Grubu Alma

İlgili Üye Grubunu getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Üye Grubu nesnesinin id değeri

try {
    $result = $apiInstance->memberGroupsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MemberGroupApi->memberGroupsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Grubu nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\MemberGroup**](../Model/MemberGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **memberGroupsIdPut**
> \Swagger\Client\Model\MemberGroup memberGroupsIdPut($id, $member_group)

Üye Grubu Güncelleme

İlgili Üye Grubunu günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Üye Grubu nesnesinin id değeri
$member_group = new \Swagger\Client\Model\MemberGroup(); // \Swagger\Client\Model\MemberGroup | MemberGroup nesnesi

try {
    $result = $apiInstance->memberGroupsIdPut($id, $member_group);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MemberGroupApi->memberGroupsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Grubu nesnesinin id değeri |
 **member_group** | [**\Swagger\Client\Model\MemberGroup**](../Model/MemberGroup.md)| MemberGroup nesnesi |

### Return type

[**\Swagger\Client\Model\MemberGroup**](../Model/MemberGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **memberGroupsPost**
> \Swagger\Client\Model\MemberGroup memberGroupsPost($member_group)

Üye Grubu Oluşturma

Yeni bir Üye Grubu oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$member_group = new \Swagger\Client\Model\MemberGroup(); // \Swagger\Client\Model\MemberGroup | MemberGroup nesnesi

try {
    $result = $apiInstance->memberGroupsPost($member_group);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MemberGroupApi->memberGroupsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member_group** | [**\Swagger\Client\Model\MemberGroup**](../Model/MemberGroup.md)| MemberGroup nesnesi |

### Return type

[**\Swagger\Client\Model\MemberGroup**](../Model/MemberGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

