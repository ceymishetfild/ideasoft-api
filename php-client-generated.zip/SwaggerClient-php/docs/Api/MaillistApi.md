# Swagger\Client\MaillistApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**maillistsGet**](MaillistApi.md#maillistsGet) | **GET** /maillists | Mail Listesi Listesi Alma
[**maillistsIdDelete**](MaillistApi.md#maillistsIdDelete) | **DELETE** /maillists/{id} | Mail Listesi Silme
[**maillistsIdGet**](MaillistApi.md#maillistsIdGet) | **GET** /maillists/{id} | Mail Listesi Alma
[**maillistsIdPut**](MaillistApi.md#maillistsIdPut) | **PUT** /maillists/{id} | Mail Listesi Güncelleme
[**maillistsPost**](MaillistApi.md#maillistsPost) | **POST** /maillists | Mail Listesi Oluşturma


# **maillistsGet**
> \Swagger\Client\Model\Maillist maillistsGet($sort, $limit, $page, $since_id, $name, $email, $maillist_group, $start_date, $end_date, $start_updated_at, $end_updated_at)

Mail Listesi Listesi Alma

Mail Listesi listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MaillistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$name = "name_example"; // string | Mail Listesi adı.
$email = "email_example"; // string | Mail Listesi e-mail.
$maillist_group = 56; // int | Mail Listesi Grubu id
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi
$start_updated_at = new \DateTime("2013-10-20"); // \DateTime | updatedAt değeri için başlangıç tarihi
$end_updated_at = "end_updated_at_example"; // string | updatedAt değeri için bitiş tarihi

try {
    $result = $apiInstance->maillistsGet($sort, $limit, $page, $since_id, $name, $email, $maillist_group, $start_date, $end_date, $start_updated_at, $end_updated_at);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MaillistApi->maillistsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **name** | **string**| Mail Listesi adı. | [optional]
 **email** | **string**| Mail Listesi e-mail. | [optional]
 **maillist_group** | **int**| Mail Listesi Grubu id | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]
 **start_updated_at** | **\DateTime**| updatedAt değeri için başlangıç tarihi | [optional]
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**\Swagger\Client\Model\Maillist**](../Model/Maillist.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **maillistsIdDelete**
> maillistsIdDelete($id)

Mail Listesi Silme

Kalıcı olarak ilgili Mail Listesini siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MaillistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Mail Listesi nesnesinin id değeri

try {
    $apiInstance->maillistsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling MaillistApi->maillistsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **maillistsIdGet**
> \Swagger\Client\Model\Maillist maillistsIdGet($id)

Mail Listesi Alma

İlgili Mail Listesini getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MaillistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Mail Listesi nesnesinin id değeri

try {
    $result = $apiInstance->maillistsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MaillistApi->maillistsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\Maillist**](../Model/Maillist.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **maillistsIdPut**
> \Swagger\Client\Model\Maillist maillistsIdPut($id, $maillist)

Mail Listesi Güncelleme

İlgili Mail Listesini günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MaillistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Mail Listesi nesnesinin id değeri
$maillist = new \Swagger\Client\Model\Maillist(); // \Swagger\Client\Model\Maillist | Maillist nesnesi

try {
    $result = $apiInstance->maillistsIdPut($id, $maillist);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MaillistApi->maillistsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi nesnesinin id değeri |
 **maillist** | [**\Swagger\Client\Model\Maillist**](../Model/Maillist.md)| Maillist nesnesi |

### Return type

[**\Swagger\Client\Model\Maillist**](../Model/Maillist.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **maillistsPost**
> \Swagger\Client\Model\Maillist maillistsPost($maillist)

Mail Listesi Oluşturma

Yeni bir Mail Listesini oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MaillistApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$maillist = new \Swagger\Client\Model\Maillist(); // \Swagger\Client\Model\Maillist | Maillist nesnesi

try {
    $result = $apiInstance->maillistsPost($maillist);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MaillistApi->maillistsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **maillist** | [**\Swagger\Client\Model\Maillist**](../Model/Maillist.md)| Maillist nesnesi |

### Return type

[**\Swagger\Client\Model\Maillist**](../Model/Maillist.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

