# Swagger\Client\OrderRefundRequestApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**orderRefundRequestsGet**](OrderRefundRequestApi.md#orderRefundRequestsGet) | **GET** /order_refund_requests | Sipariş İptal Talebi Listesi Alma
[**orderRefundRequestsIdDelete**](OrderRefundRequestApi.md#orderRefundRequestsIdDelete) | **DELETE** /order_refund_requests/{id} | Sipariş İptal Talebi Silme
[**orderRefundRequestsIdGet**](OrderRefundRequestApi.md#orderRefundRequestsIdGet) | **GET** /order_refund_requests/{id} | Sipariş İptal Talebi Alma
[**orderRefundRequestsIdPut**](OrderRefundRequestApi.md#orderRefundRequestsIdPut) | **PUT** /order_refund_requests/{id} | Sipariş İptal Talebi Güncelleme
[**orderRefundRequestsPost**](OrderRefundRequestApi.md#orderRefundRequestsPost) | **POST** /order_refund_requests | Sipariş İptal Talebi Oluşturma


# **orderRefundRequestsGet**
> \Swagger\Client\Model\OrderRefundRequest orderRefundRequestsGet($sort, $limit, $page, $since_id, $order, $member, $code, $status, $start_date, $end_date, $start_updated_at, $end_updated_at)

Sipariş İptal Talebi Listesi Alma

Sipariş İptal Talebi listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OrderRefundRequestApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$order = 56; // int | Sipariş id
$member = 56; // int | Üye id
$code = "code_example"; // string | Sipariş İptal Talebi kodu
$status = "status_example"; // string | Status şu değerleri alabilir: <br><code>waiting_for_approval</code> : Onay bekliyor<br><code>approved</code> : Onaylandı<br><code>cancelled</code> : İptal edildi
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi
$start_updated_at = new \DateTime("2013-10-20"); // \DateTime | updatedAt değeri için başlangıç tarihi
$end_updated_at = "end_updated_at_example"; // string | updatedAt değeri için bitiş tarihi

try {
    $result = $apiInstance->orderRefundRequestsGet($sort, $limit, $page, $since_id, $order, $member, $code, $status, $start_date, $end_date, $start_updated_at, $end_updated_at);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrderRefundRequestApi->orderRefundRequestsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **order** | **int**| Sipariş id | [optional]
 **member** | **int**| Üye id | [optional]
 **code** | **string**| Sipariş İptal Talebi kodu | [optional]
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]
 **start_updated_at** | **\DateTime**| updatedAt değeri için başlangıç tarihi | [optional]
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**\Swagger\Client\Model\OrderRefundRequest**](../Model/OrderRefundRequest.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **orderRefundRequestsIdDelete**
> orderRefundRequestsIdDelete($id)

Sipariş İptal Talebi Silme

Kalıcı olarak ilgili Sipariş İptal Talebini siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OrderRefundRequestApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sipariş İptal Talebi nesnesinin id değeri

try {
    $apiInstance->orderRefundRequestsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling OrderRefundRequestApi->orderRefundRequestsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş İptal Talebi nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **orderRefundRequestsIdGet**
> \Swagger\Client\Model\OrderRefundRequest orderRefundRequestsIdGet($id)

Sipariş İptal Talebi Alma

İlgili Sipariş İptal Talebini getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OrderRefundRequestApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sipariş İptal Talebi nesnesinin id değeri

try {
    $result = $apiInstance->orderRefundRequestsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrderRefundRequestApi->orderRefundRequestsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş İptal Talebi nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\OrderRefundRequest**](../Model/OrderRefundRequest.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **orderRefundRequestsIdPut**
> \Swagger\Client\Model\OrderRefundRequest orderRefundRequestsIdPut($id, $order_refund_request)

Sipariş İptal Talebi Güncelleme

İlgili Sipariş İptal Talebini günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OrderRefundRequestApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sipariş İptal Talebi nesnesinin id değeri
$order_refund_request = new \Swagger\Client\Model\OrderRefundRequest(); // \Swagger\Client\Model\OrderRefundRequest | OrderRefundRequest nesnesi

try {
    $result = $apiInstance->orderRefundRequestsIdPut($id, $order_refund_request);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrderRefundRequestApi->orderRefundRequestsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş İptal Talebi nesnesinin id değeri |
 **order_refund_request** | [**\Swagger\Client\Model\OrderRefundRequest**](../Model/OrderRefundRequest.md)| OrderRefundRequest nesnesi |

### Return type

[**\Swagger\Client\Model\OrderRefundRequest**](../Model/OrderRefundRequest.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **orderRefundRequestsPost**
> \Swagger\Client\Model\OrderRefundRequest orderRefundRequestsPost($order_refund_request)

Sipariş İptal Talebi Oluşturma

Yeni bir Sipariş İptal Talebi oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OrderRefundRequestApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$order_refund_request = new \Swagger\Client\Model\OrderRefundRequest(); // \Swagger\Client\Model\OrderRefundRequest | OrderRefundRequest nesnesi

try {
    $result = $apiInstance->orderRefundRequestsPost($order_refund_request);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrderRefundRequestApi->orderRefundRequestsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_refund_request** | [**\Swagger\Client\Model\OrderRefundRequest**](../Model/OrderRefundRequest.md)| OrderRefundRequest nesnesi |

### Return type

[**\Swagger\Client\Model\OrderRefundRequest**](../Model/OrderRefundRequest.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

