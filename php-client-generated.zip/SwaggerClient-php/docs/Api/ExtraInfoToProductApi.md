# Swagger\Client\ExtraInfoToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extraInfoToProductsGet**](ExtraInfoToProductApi.md#extraInfoToProductsGet) | **GET** /extra_info_to_products | Ek Bilgi Ürün Bağı Listesi Alma
[**extraInfoToProductsIdDelete**](ExtraInfoToProductApi.md#extraInfoToProductsIdDelete) | **DELETE** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Silme
[**extraInfoToProductsIdGet**](ExtraInfoToProductApi.md#extraInfoToProductsIdGet) | **GET** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Alma
[**extraInfoToProductsIdPut**](ExtraInfoToProductApi.md#extraInfoToProductsIdPut) | **PUT** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Güncelleme
[**extraInfoToProductsPost**](ExtraInfoToProductApi.md#extraInfoToProductsPost) | **POST** /extra_info_to_products | Ek Bilgi Ürün Bağı Oluşturma


# **extraInfoToProductsGet**
> \Swagger\Client\Model\ExtraInfoToProduct extraInfoToProductsGet($sort, $limit, $page, $since_id, $extra_info, $product)

Ek Bilgi Ürün Bağı Listesi Alma

Ek Bilgi Ürün Bağı listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ExtraInfoToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$extra_info = 56; // int | Ek bilgi id
$product = 56; // int | Ürün id

try {
    $result = $apiInstance->extraInfoToProductsGet($sort, $limit, $page, $since_id, $extra_info, $product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ExtraInfoToProductApi->extraInfoToProductsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **extra_info** | **int**| Ek bilgi id | [optional]
 **product** | **int**| Ürün id | [optional]

### Return type

[**\Swagger\Client\Model\ExtraInfoToProduct**](../Model/ExtraInfoToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **extraInfoToProductsIdDelete**
> extraInfoToProductsIdDelete($id)

Ek Bilgi Ürün Bağı Silme

Kalıcı olarak ilgili Ek Bilgi Ürün Bağını siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ExtraInfoToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ek Bilgi Ürün Bağı nesnesinin id değeri

try {
    $apiInstance->extraInfoToProductsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling ExtraInfoToProductApi->extraInfoToProductsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi Ürün Bağı nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **extraInfoToProductsIdGet**
> \Swagger\Client\Model\ExtraInfoToProduct extraInfoToProductsIdGet($id)

Ek Bilgi Ürün Bağı Alma

İlgili Ek Bilgi Ürün Bağını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ExtraInfoToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ek Bilgi Ürün Bağı nesnesinin id değeri

try {
    $result = $apiInstance->extraInfoToProductsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ExtraInfoToProductApi->extraInfoToProductsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi Ürün Bağı nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\ExtraInfoToProduct**](../Model/ExtraInfoToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **extraInfoToProductsIdPut**
> \Swagger\Client\Model\ExtraInfoToProduct extraInfoToProductsIdPut($id, $extra_info_to_product)

Ek Bilgi Ürün Bağı Güncelleme

İlgili Ek Bilgi Ürün Bağını günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ExtraInfoToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ek Bilgi Ürün Bağı nesnesinin id değeri
$extra_info_to_product = new \Swagger\Client\Model\ExtraInfoToProduct(); // \Swagger\Client\Model\ExtraInfoToProduct | ExtraInfoToProduct nesnesi

try {
    $result = $apiInstance->extraInfoToProductsIdPut($id, $extra_info_to_product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ExtraInfoToProductApi->extraInfoToProductsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi Ürün Bağı nesnesinin id değeri |
 **extra_info_to_product** | [**\Swagger\Client\Model\ExtraInfoToProduct**](../Model/ExtraInfoToProduct.md)| ExtraInfoToProduct nesnesi |

### Return type

[**\Swagger\Client\Model\ExtraInfoToProduct**](../Model/ExtraInfoToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **extraInfoToProductsPost**
> \Swagger\Client\Model\ExtraInfoToProduct extraInfoToProductsPost($extra_info_to_product)

Ek Bilgi Ürün Bağı Oluşturma

Yeni bir Ek Bilgi Ürün Bağı oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ExtraInfoToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$extra_info_to_product = new \Swagger\Client\Model\ExtraInfoToProduct(); // \Swagger\Client\Model\ExtraInfoToProduct | ExtraInfoToProduct nesnesi

try {
    $result = $apiInstance->extraInfoToProductsPost($extra_info_to_product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ExtraInfoToProductApi->extraInfoToProductsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extra_info_to_product** | [**\Swagger\Client\Model\ExtraInfoToProduct**](../Model/ExtraInfoToProduct.md)| ExtraInfoToProduct nesnesi |

### Return type

[**\Swagger\Client\Model\ExtraInfoToProduct**](../Model/ExtraInfoToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

