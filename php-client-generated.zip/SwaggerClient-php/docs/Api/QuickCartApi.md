# Swagger\Client\QuickCartApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**quickCartsGet**](QuickCartApi.md#quickCartsGet) | **GET** /quick_carts | Hızlı Satın Al Bağlantısı Alma
[**quickCartsIdDelete**](QuickCartApi.md#quickCartsIdDelete) | **DELETE** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Silme
[**quickCartsIdGet**](QuickCartApi.md#quickCartsIdGet) | **GET** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Alma
[**quickCartsIdPut**](QuickCartApi.md#quickCartsIdPut) | **PUT** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Güncelleme
[**quickCartsPost**](QuickCartApi.md#quickCartsPost) | **POST** /quick_carts | Hızlı Satın Al Bağlantısı Oluşturma


# **quickCartsGet**
> \Swagger\Client\Model\QuickCart quickCartsGet($sort, $limit, $page, $since_id, $name)

Hızlı Satın Al Bağlantısı Alma

Hızlı Satın Al Bağlantısı döndürür.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\QuickCartApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$name = "name_example"; // string | Hızlı Satın Al Bağlantısı adı

try {
    $result = $apiInstance->quickCartsGet($sort, $limit, $page, $since_id, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling QuickCartApi->quickCartsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **name** | **string**| Hızlı Satın Al Bağlantısı adı | [optional]

### Return type

[**\Swagger\Client\Model\QuickCart**](../Model/QuickCart.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **quickCartsIdDelete**
> quickCartsIdDelete($id)

Hızlı Satın Al Bağlantısı Silme

Kalıcı olarak ilgili Hızlı Satın Al Bağlantısını siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\QuickCartApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Hızlı Satın Al nesnesinin id değeri

try {
    $apiInstance->quickCartsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling QuickCartApi->quickCartsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Hızlı Satın Al nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **quickCartsIdGet**
> \Swagger\Client\Model\QuickCart quickCartsIdGet($id)

Hızlı Satın Al Bağlantısı Alma

İlgili Hızlı Satın Al Bağlantısını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\QuickCartApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Hızlı Satın Al nesnesinin id değeri

try {
    $result = $apiInstance->quickCartsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling QuickCartApi->quickCartsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Hızlı Satın Al nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\QuickCart**](../Model/QuickCart.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **quickCartsIdPut**
> \Swagger\Client\Model\QuickCart quickCartsIdPut($id, $quick_cart)

Hızlı Satın Al Bağlantısı Güncelleme

İlgili Hızlı Satın Al Bağlantısını günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\QuickCartApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Hızlı Satın Al nesnesinin id değeri
$quick_cart = new \Swagger\Client\Model\QuickCart(); // \Swagger\Client\Model\QuickCart | QuickCart nesnesi

try {
    $result = $apiInstance->quickCartsIdPut($id, $quick_cart);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling QuickCartApi->quickCartsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Hızlı Satın Al nesnesinin id değeri |
 **quick_cart** | [**\Swagger\Client\Model\QuickCart**](../Model/QuickCart.md)| QuickCart nesnesi |

### Return type

[**\Swagger\Client\Model\QuickCart**](../Model/QuickCart.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **quickCartsPost**
> \Swagger\Client\Model\QuickCart quickCartsPost($quick_cart)

Hızlı Satın Al Bağlantısı Oluşturma

Yeni bir Hızlı Satın Al Bağlantısı oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\QuickCartApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$quick_cart = new \Swagger\Client\Model\QuickCart(); // \Swagger\Client\Model\QuickCart | QuickCart nesnesi

try {
    $result = $apiInstance->quickCartsPost($quick_cart);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling QuickCartApi->quickCartsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **quick_cart** | [**\Swagger\Client\Model\QuickCart**](../Model/QuickCart.md)| QuickCart nesnesi |

### Return type

[**\Swagger\Client\Model\QuickCart**](../Model/QuickCart.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

