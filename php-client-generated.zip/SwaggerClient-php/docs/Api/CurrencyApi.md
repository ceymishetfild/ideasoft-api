# Swagger\Client\CurrencyApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**currenciesGet**](CurrencyApi.md#currenciesGet) | **GET** /currencies | Kur Listesi Alma
[**currenciesIdGet**](CurrencyApi.md#currenciesIdGet) | **GET** /currencies/{id} | Kur Alma
[**currenciesIdPut**](CurrencyApi.md#currenciesIdPut) | **PUT** /currencies/{id} | Kur Güncelleme


# **currenciesGet**
> \Swagger\Client\Model\Currency currenciesGet($sort, $limit, $page, $since_id, $label, $abbr, $status)

Kur Listesi Alma

Kur listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CurrencyApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$label = "label_example"; // string | Kur etiketi
$abbr = "abbr_example"; // string | Kur kısaltması
$status = 56; // int | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif

try {
    $result = $apiInstance->currenciesGet($sort, $limit, $page, $since_id, $label, $abbr, $status);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CurrencyApi->currenciesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **label** | **string**| Kur etiketi | [optional]
 **abbr** | **string**| Kur kısaltması | [optional]
 **status** | **int**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional]

### Return type

[**\Swagger\Client\Model\Currency**](../Model/Currency.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **currenciesIdGet**
> \Swagger\Client\Model\Currency currenciesIdGet($id)

Kur Alma

İlgili Kur getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CurrencyApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Kur nesnesinin id değeri

try {
    $result = $apiInstance->currenciesIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CurrencyApi->currenciesIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kur nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\Currency**](../Model/Currency.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **currenciesIdPut**
> \Swagger\Client\Model\Currency currenciesIdPut($id, $currency)

Kur Güncelleme

İlgili Kur günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CurrencyApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Kur nesnesinin id değeri
$currency = new \Swagger\Client\Model\Currency(); // \Swagger\Client\Model\Currency | Currency nesnesi

try {
    $result = $apiInstance->currenciesIdPut($id, $currency);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CurrencyApi->currenciesIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kur nesnesinin id değeri |
 **currency** | [**\Swagger\Client\Model\Currency**](../Model/Currency.md)| Currency nesnesi |

### Return type

[**\Swagger\Client\Model\Currency**](../Model/Currency.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

