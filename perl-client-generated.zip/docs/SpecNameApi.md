# WWW::SwaggerClient::SpecNameApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::SpecNameApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**spec_names_get**](SpecNameApi.md#spec_names_get) | **GET** /spec_names | Ürün Özelliği Listesi Alma
[**spec_names_id_delete**](SpecNameApi.md#spec_names_id_delete) | **DELETE** /spec_names/{id} | Ürün Özelliği Silme
[**spec_names_id_get**](SpecNameApi.md#spec_names_id_get) | **GET** /spec_names/{id} | Ürün Özelliği Alma
[**spec_names_id_put**](SpecNameApi.md#spec_names_id_put) | **PUT** /spec_names/{id} | Ürün Özelliği Güncelleme
[**spec_names_post**](SpecNameApi.md#spec_names_post) | **POST** /spec_names | Ürün Özelliği Oluşturma


# **spec_names_get**
> SpecName spec_names_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name, spec_group => $spec_group, choice_type => $choice_type)

Ürün Özelliği Listesi Alma

Ürün Özelliği listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SpecNameApi;
my $api_instance = WWW::SwaggerClient::SpecNameApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $name = 'name_example'; # string | Ürün Özelliği adı
my $spec_group = 56; # int | Ürün özellik grubu id
my $choice_type = 'choice_type_example'; # string | Status şu değerleri alabilir: <br><code>singular</code> : Tekil<br><code>plural</code> : Çoğul

eval { 
    my $result = $api_instance->spec_names_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name, spec_group => $spec_group, choice_type => $choice_type);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SpecNameApi->spec_names_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **string**| Ürün Özelliği adı | [optional] 
 **spec_group** | **int**| Ürün özellik grubu id | [optional] 
 **choice_type** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul | [optional] 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_names_id_delete**
> spec_names_id_delete(id => $id)

Ürün Özelliği Silme

Kalıcı olarak ilgili Ürün Özelliğini siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SpecNameApi;
my $api_instance = WWW::SwaggerClient::SpecNameApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Özellik nesnesinin id değeri

eval { 
    $api_instance->spec_names_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling SpecNameApi->spec_names_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_names_id_get**
> SpecName spec_names_id_get(id => $id)

Ürün Özelliği Alma

İlgili Ürün Özelliğini getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SpecNameApi;
my $api_instance = WWW::SwaggerClient::SpecNameApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Özellik nesnesinin id değeri

eval { 
    my $result = $api_instance->spec_names_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SpecNameApi->spec_names_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik nesnesinin id değeri | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_names_id_put**
> SpecName spec_names_id_put(id => $id, spec_name => $spec_name)

Ürün Özelliği Güncelleme

İlgili Ürün Özelliğini günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SpecNameApi;
my $api_instance = WWW::SwaggerClient::SpecNameApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Özellik nesnesinin id değeri
my $spec_name = WWW::SwaggerClient::Object::SpecName->new(); # SpecName |  nesnesi

eval { 
    my $result = $api_instance->spec_names_id_put(id => $id, spec_name => $spec_name);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SpecNameApi->spec_names_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik nesnesinin id değeri | 
 **spec_name** | [**SpecName**](SpecName.md)|  nesnesi | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_names_post**
> SpecName spec_names_post(spec_name => $spec_name)

Ürün Özelliği Oluşturma

Yeni bir Ürün Özelliği oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SpecNameApi;
my $api_instance = WWW::SwaggerClient::SpecNameApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $spec_name = WWW::SwaggerClient::Object::SpecName->new(); # SpecName |  nesnesi

eval { 
    my $result = $api_instance->spec_names_post(spec_name => $spec_name);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SpecNameApi->spec_names_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **spec_name** | [**SpecName**](SpecName.md)|  nesnesi | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

