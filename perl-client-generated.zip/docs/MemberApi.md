# WWW::SwaggerClient::MemberApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::MemberApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**members_charts_get**](MemberApi.md#members_charts_get) | **GET** /members/charts | Üye Grafik Aksiyonu
[**members_combined_get**](MemberApi.md#members_combined_get) | **GET** /members/combined | Üye Birleşik Aksiyonu
[**members_get**](MemberApi.md#members_get) | **GET** /members | Üye Listesi Alma
[**members_id_delete**](MemberApi.md#members_id_delete) | **DELETE** /members/{id} | Üye Silme
[**members_id_get**](MemberApi.md#members_id_get) | **GET** /members/{id} | Üye Alma
[**members_id_put**](MemberApi.md#members_id_put) | **PUT** /members/{id} | Üye Güncelleme
[**members_post**](MemberApi.md#members_post) | **POST** /members | Üye Oluşturma


# **members_charts_get**
> Member members_charts_get(time_frame => $time_frame, start_date => $start_date)

Üye Grafik Aksiyonu

Zaman bazında üye genel istatistiklerini getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberApi;
my $api_instance = WWW::SwaggerClient::MemberApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $time_frame = 'time_frame_example'; # string | Şu değerleri olabilir: full, year, month or week
my $start_date = 'start_date_example'; # string | Zaman aralığının başlangıcı

eval { 
    my $result = $api_instance->members_charts_get(time_frame => $time_frame, start_date => $start_date);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MemberApi->members_charts_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **time_frame** | **string**| Şu değerleri olabilir: full, year, month or week | 
 **start_date** | **string**| Zaman aralığının başlangıcı | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **members_combined_get**
> Member members_combined_get()

Üye Birleşik Aksiyonu

Bugün, aylık, yıllık ve toplam üye oturum açma istatistiklerini totalCount cinsinden getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberApi;
my $api_instance = WWW::SwaggerClient::MemberApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);


eval { 
    my $result = $api_instance->members_combined_get();
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MemberApi->members_combined_get: $@\n";
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **members_get**
> Member members_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, firstname => $firstname, surname => $surname, email => $email, password => $password, gender => $gender, mobile_phone_number => $mobile_phone_number, phone_number => $phone_number, member_group => $member_group, location => $location, country => $country, referred_member => $referred_member, q => $q, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at)

Üye Listesi Alma

Üye listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberApi;
my $api_instance = WWW::SwaggerClient::MemberApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $firstname = 'firstname_example'; # string | Adı
my $surname = 'surname_example'; # string | Soyadı
my $email = 'email_example'; # string | e-mail adresi
my $password = 'password_example'; # string | Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri
my $gender = 'gender_example'; # string | Cinsiyet şu değerleri alabilir: <br><code>male</code> : Erkek<br><code>female</code> : Kadın
my $mobile_phone_number = 'mobile_phone_number_example'; # string | Üye mobil telefon numarası
my $phone_number = 'phone_number_example'; # string | Üye telefon numarası
my $member_group = 56; # int | Üye Grubu id
my $location = 56; # int | Şehir id
my $country = 56; # int | Ülke id
my $referred_member = 56; # int | Tavsiye Üye id
my $q = []; # ARRAY[string] | Üye arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;]
my $start_date = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | createdAt değeri için başlangıç tarihi
my $end_date = 'end_date_example'; # string | createdAt değeri için bitiş tarihi
my $start_updated_at = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | updatedAt değeri için başlangıç tarihi
my $end_updated_at = 'end_updated_at_example'; # string | updatedAt değeri için bitiş tarihi

eval { 
    my $result = $api_instance->members_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, firstname => $firstname, surname => $surname, email => $email, password => $password, gender => $gender, mobile_phone_number => $mobile_phone_number, phone_number => $phone_number, member_group => $member_group, location => $location, country => $country, referred_member => $referred_member, q => $q, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MemberApi->members_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **firstname** | **string**| Adı | [optional] 
 **surname** | **string**| Soyadı | [optional] 
 **email** | **string**| e-mail adresi | [optional] 
 **password** | **string**| Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri | [optional] 
 **gender** | **string**| Cinsiyet şu değerleri alabilir: &lt;br&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın | [optional] 
 **mobile_phone_number** | **string**| Üye mobil telefon numarası | [optional] 
 **phone_number** | **string**| Üye telefon numarası | [optional] 
 **member_group** | **int**| Üye Grubu id | [optional] 
 **location** | **int**| Şehir id | [optional] 
 **country** | **int**| Ülke id | [optional] 
 **referred_member** | **int**| Tavsiye Üye id | [optional] 
 **q** | [**ARRAY[string]**](string.md)| Üye arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 
 **start_date** | **DateTime**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **DateTime**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **members_id_delete**
> members_id_delete(id => $id)

Üye Silme

Kalıcı olarak ilgili Üyeyi siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberApi;
my $api_instance = WWW::SwaggerClient::MemberApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Üye nesnesinin id değeri

eval { 
    $api_instance->members_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling MemberApi->members_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **members_id_get**
> Member members_id_get(id => $id)

Üye Alma

İlgili Üyeyi getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberApi;
my $api_instance = WWW::SwaggerClient::MemberApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Üye nesnesinin id değeri

eval { 
    my $result = $api_instance->members_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MemberApi->members_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye nesnesinin id değeri | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **members_id_put**
> Member members_id_put(id => $id, member => $member)

Üye Güncelleme

İlgili Üyeyi günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberApi;
my $api_instance = WWW::SwaggerClient::MemberApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Üye nesnesinin id değeri
my $member = WWW::SwaggerClient::Object::Member->new(); # Member | Member nesnesi

eval { 
    my $result = $api_instance->members_id_put(id => $id, member => $member);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MemberApi->members_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye nesnesinin id değeri | 
 **member** | [**Member**](Member.md)| Member nesnesi | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **members_post**
> Member members_post(member => $member)

Üye Oluşturma

Yeni bir Üye oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberApi;
my $api_instance = WWW::SwaggerClient::MemberApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $member = WWW::SwaggerClient::Object::Member->new(); # Member | Member nesnesi

eval { 
    my $result = $api_instance->members_post(member => $member);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MemberApi->members_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member** | [**Member**](Member.md)| Member nesnesi | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

