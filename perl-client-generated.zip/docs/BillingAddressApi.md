# WWW::SwaggerClient::BillingAddressApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::BillingAddressApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**billing_addresses_get**](BillingAddressApi.md#billing_addresses_get) | **GET** /billing_addresses | Fatura Adresi Listesi Alma
[**billing_addresses_id_get**](BillingAddressApi.md#billing_addresses_id_get) | **GET** /billing_addresses/{id} | Fatura Adresi Alma
[**billing_addresses_id_put**](BillingAddressApi.md#billing_addresses_id_put) | **PUT** /billing_addresses/{id} | Fatura Adresi Güncelleme
[**billing_addresses_post**](BillingAddressApi.md#billing_addresses_post) | **POST** /billing_addresses | Fatura Adresi Oluşturma


# **billing_addresses_get**
> BillingAddress billing_addresses_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, order => $order, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at)

Fatura Adresi Listesi Alma

Fatura Adresi listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::BillingAddressApi;
my $api_instance = WWW::SwaggerClient::BillingAddressApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $order = 56; # int | Sipariş id
my $start_date = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | createdAt değeri için başlangıç tarihi
my $end_date = 'end_date_example'; # string | createdAt değeri için bitiş tarihi
my $start_updated_at = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | updatedAt değeri için başlangıç tarihi
my $end_updated_at = 'end_updated_at_example'; # string | updatedAt değeri için bitiş tarihi

eval { 
    my $result = $api_instance->billing_addresses_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, order => $order, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling BillingAddressApi->billing_addresses_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **int**| Sipariş id | [optional] 
 **start_date** | **DateTime**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **DateTime**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **billing_addresses_id_get**
> BillingAddress billing_addresses_id_get(id => $id)

Fatura Adresi Alma

İlgili Fatura Adresini getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::BillingAddressApi;
my $api_instance = WWW::SwaggerClient::BillingAddressApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Fatura Adresi nesnesinin id değeri

eval { 
    my $result = $api_instance->billing_addresses_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling BillingAddressApi->billing_addresses_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Fatura Adresi nesnesinin id değeri | 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **billing_addresses_id_put**
> BillingAddress billing_addresses_id_put(id => $id, billing_address => $billing_address)

Fatura Adresi Güncelleme

İlgili Fatura Adresini günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::BillingAddressApi;
my $api_instance = WWW::SwaggerClient::BillingAddressApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Fatura Adresi nesnesinin id değeri
my $billing_address = WWW::SwaggerClient::Object::BillingAddress->new(); # BillingAddress | BillingAddress nesnesi

eval { 
    my $result = $api_instance->billing_addresses_id_put(id => $id, billing_address => $billing_address);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling BillingAddressApi->billing_addresses_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Fatura Adresi nesnesinin id değeri | 
 **billing_address** | [**BillingAddress**](BillingAddress.md)| BillingAddress nesnesi | 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **billing_addresses_post**
> BillingAddress billing_addresses_post(billing_address => $billing_address)

Fatura Adresi Oluşturma

Yeni bir Fatura Adresi oluşturur. Fatura Adresi oluşturabilmek için geçerli bir önceden tanımlanmış Sipariş id değerine ihtiyaç vardır.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::BillingAddressApi;
my $api_instance = WWW::SwaggerClient::BillingAddressApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $billing_address = WWW::SwaggerClient::Object::BillingAddress->new(); # BillingAddress | BillingAddress nesnesi

eval { 
    my $result = $api_instance->billing_addresses_post(billing_address => $billing_address);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling BillingAddressApi->billing_addresses_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **billing_address** | [**BillingAddress**](BillingAddress.md)| BillingAddress nesnesi | 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

