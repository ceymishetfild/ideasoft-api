# WWW::SwaggerClient::TownGroupApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::TownGroupApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**town_groups_get**](TownGroupApi.md#town_groups_get) | **GET** /town_groups | İlçe Grubu Listesi Alma
[**town_groups_id_delete**](TownGroupApi.md#town_groups_id_delete) | **DELETE** /town_groups/{id} | İlçe Grubu Silme
[**town_groups_id_get**](TownGroupApi.md#town_groups_id_get) | **GET** /town_groups/{id} | İlçe Grubu Alma
[**town_groups_id_put**](TownGroupApi.md#town_groups_id_put) | **PUT** /town_groups/{id} | İlçe Grubu Güncelleme
[**town_groups_post**](TownGroupApi.md#town_groups_post) | **POST** /town_groups | İlçe Grubu Oluşturma


# **town_groups_get**
> TownGroup town_groups_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name)

İlçe Grubu Listesi Alma

İlçe Grubu listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::TownGroupApi;
my $api_instance = WWW::SwaggerClient::TownGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $name = 'name_example'; # string | İlçe Grubu adı

eval { 
    my $result = $api_instance->town_groups_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling TownGroupApi->town_groups_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **string**| İlçe Grubu adı | [optional] 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **town_groups_id_delete**
> town_groups_id_delete(id => $id)

İlçe Grubu Silme

Kalıcı olarak ilgili İlçe Grubunu siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::TownGroupApi;
my $api_instance = WWW::SwaggerClient::TownGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | İlçe Grubu nesnesinin id değeri

eval { 
    $api_instance->town_groups_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling TownGroupApi->town_groups_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **town_groups_id_get**
> TownGroup town_groups_id_get(id => $id)

İlçe Grubu Alma

İlgili İlçe Grubunu getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::TownGroupApi;
my $api_instance = WWW::SwaggerClient::TownGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | İlçe Grubu nesnesinin id değeri

eval { 
    my $result = $api_instance->town_groups_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling TownGroupApi->town_groups_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe Grubu nesnesinin id değeri | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **town_groups_id_put**
> TownGroup town_groups_id_put(id => $id, town_group => $town_group)

İlçe Grubu Güncelleme

İlgili İlçe Grubunu günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::TownGroupApi;
my $api_instance = WWW::SwaggerClient::TownGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | İlçe Grubu nesnesinin id değeri
my $town_group = WWW::SwaggerClient::Object::TownGroup->new(); # TownGroup |  nesnesi

eval { 
    my $result = $api_instance->town_groups_id_put(id => $id, town_group => $town_group);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling TownGroupApi->town_groups_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe Grubu nesnesinin id değeri | 
 **town_group** | [**TownGroup**](TownGroup.md)|  nesnesi | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **town_groups_post**
> TownGroup town_groups_post(town_group => $town_group)

İlçe Grubu Oluşturma

Yeni bir İlçe Grubu oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::TownGroupApi;
my $api_instance = WWW::SwaggerClient::TownGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $town_group = WWW::SwaggerClient::Object::TownGroup->new(); # TownGroup |  nesnesi

eval { 
    my $result = $api_instance->town_groups_post(town_group => $town_group);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling TownGroupApi->town_groups_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **town_group** | [**TownGroup**](TownGroup.md)|  nesnesi | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

