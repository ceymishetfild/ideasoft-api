# WWW::SwaggerClient::Object::Cart

## Load the model package
```perl
use WWW::SwaggerClient::Object::Cart;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sepet nesnesi kimlik değeri. | [optional] 
**session_id** | **string** | Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri. | 
**locked** | **string** | Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz. | [optional] 
**created_at** | **DateTime** | Sepet nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Sepet nesnesinin güncellenme zamanı. | [optional] 
**chosen_promotion** | [**ShopCampaigns**](ShopCampaigns.md) |  | [optional] 
**member** | [**Member**](Member.md) |  | [optional] 
**chosen_token** | [**ShopTokens**](ShopTokens.md) |  | [optional] 
**items** | [**ARRAY[CartItem]**](CartItem.md) | Sepet kalemi nesnelerini barındıran liste. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


