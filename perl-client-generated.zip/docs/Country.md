# WWW::SwaggerClient::Object::Country

## Load the model package
```perl
use WWW::SwaggerClient::Object::Country;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ülke nesnesi kimlik değeri. | [optional] 
**name** | **string** | Ülke nesnesi için isim değeri. | 
**status** | **string** | Ülkenin aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


