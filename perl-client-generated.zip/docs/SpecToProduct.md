# WWW::SwaggerClient::Object::SpecToProduct

## Load the model package
```perl
use WWW::SwaggerClient::Object::SpecToProduct;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ürün özellik ürün bağı nesnesi kimlik değeri. | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 
**spec_group** | [**SpecGroup**](SpecGroup.md) |  | [optional] 
**spec_name** | [**SpecName**](SpecName.md) |  | [optional] 
**spec_value** | [**SpecValue**](SpecValue.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


