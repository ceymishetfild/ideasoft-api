# WWW::SwaggerClient::Object::SpecToProduct

## Load the model package
```perl
use WWW::SwaggerClient::Object::SpecToProduct;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ürün özellik ürün bağı nesnesi kimlik değeri. | [optional] 
**product** | [**Product**](Product.md) | Ürün nesnesi. | [optional] 
**spec_group** | [**SpecGroup**](SpecGroup.md) | Ürün özelliği grubu nesnesi. | 
**spec_name** | [**SpecName**](SpecName.md) | Ürün özelliği nesnesi. | 
**spec_value** | [**SpecValue**](SpecValue.md) | Ürün özellik grubu nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


