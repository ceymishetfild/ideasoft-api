# WWW::SwaggerClient::LocationApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::LocationApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**locations_get**](LocationApi.md#locations_get) | **GET** /locations | Şehir Listesi Alma
[**locations_id_get**](LocationApi.md#locations_id_get) | **GET** /locations/{id} | Şehir Alma


# **locations_get**
> Location locations_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, name => $name, country => $country, region => $region)

Şehir Listesi Alma

Şehir listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::LocationApi;
my $api_instance = WWW::SwaggerClient::LocationApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $name = 'name_example'; # string | Şehir adı
my $country = 56; # int | Ülke id
my $region = 56; # int | Bölge id

eval { 
    my $result = $api_instance->locations_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, name => $name, country => $country, region => $region);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling LocationApi->locations_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **string**| Şehir adı | [optional] 
 **country** | **int**| Ülke id | [optional] 
 **region** | **int**| Bölge id | [optional] 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **locations_id_get**
> Location locations_id_get(id => $id)

Şehir Alma

İlgili Şehir getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::LocationApi;
my $api_instance = WWW::SwaggerClient::LocationApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Şehir nesnesinin id değeri

eval { 
    my $result = $api_instance->locations_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling LocationApi->locations_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Şehir nesnesinin id değeri | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

