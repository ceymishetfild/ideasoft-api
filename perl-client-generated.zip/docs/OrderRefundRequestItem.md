# WWW::SwaggerClient::Object::OrderRefundRequestItem

## Load the model package
```perl
use WWW::SwaggerClient::Object::OrderRefundRequestItem;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sipariş iptal talebi kalemi nesnesi kimlik değeri. | [optional] 
**amount** | **double** | Sipariş iptal talebi istenen ürün miktarı. | 
**reason** | **string** | Sipariş iptal talebi sebebi. Tanımlı dört seçenekten biri seçilmelidir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Ürünü iade etmek istiyorum.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Ürünü değiştirmek istiyorum.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Faturadaki ürünler ile bana gelen ürünler farklı.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Diğer&lt;/code&gt; : &lt;br&gt;&lt;/div&gt; | 
**details** | **string** | Sipariş iptal talebinin detaylı açıklaması. | 
**created_at** | **DateTime** | Sipariş iptal talebi kalemi nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Sipariş iptal talebi kalemi nesnesinin güncellenme zamanı. | [optional] 
**order_item** | [**OrderItem**](OrderItem.md) | Sipariş kalemi nesnesi. | 
**order_refund_request** | [**OrderRefundRequest**](OrderRefundRequest.md) | Sipariş iptal talebi nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


