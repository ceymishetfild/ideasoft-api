# WWW::SwaggerClient::ThemeApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ThemeApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**themes_get**](ThemeApi.md#themes_get) | **GET** /themes | Tema Listesi Alma
[**themes_id_assets_get**](ThemeApi.md#themes_id_assets_get) | **GET** /themes/{id}/assets | Tema Dosyası Listesi Alma
[**themes_id_assetskeykey_delete**](ThemeApi.md#themes_id_assetskeykey_delete) | **DELETE** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Silme
[**themes_id_assetskeykey_get**](ThemeApi.md#themes_id_assetskeykey_get) | **GET** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Alma
[**themes_id_assetskeykey_put**](ThemeApi.md#themes_id_assetskeykey_put) | **PUT** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Güncelleme
[**themes_id_delete**](ThemeApi.md#themes_id_delete) | **DELETE** /themes/{id} | Tema Silme
[**themes_id_get**](ThemeApi.md#themes_id_get) | **GET** /themes/{id} | Tema Alma
[**themes_id_put**](ThemeApi.md#themes_id_put) | **PUT** /themes/{id} | Tema Güncelleme
[**themes_post**](ThemeApi.md#themes_post) | **POST** /themes | Tema Oluşturma


# **themes_get**
> Theme themes_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, status => $status, platform => $platform, type => $type)

Tema Listesi Alma

Tema listesi verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ThemeApi;
my $api_instance = WWW::SwaggerClient::ThemeApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $status = 56; # int | Tema durumu
my $platform = 'platform_example'; # string | Tema platformu
my $type = 'type_example'; # string | Tema tipi

eval { 
    my $result = $api_instance->themes_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, status => $status, platform => $platform, type => $type);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ThemeApi->themes_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **status** | **int**| Tema durumu | [optional] 
 **platform** | **string**| Tema platformu | [optional] 
 **type** | **string**| Tema tipi | [optional] 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_id_assets_get**
> Asset themes_id_assets_get(id => $id, key => $key)

Tema Dosyası Listesi Alma

Tema Dosyası listesi verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ThemeApi;
my $api_instance = WWW::SwaggerClient::ThemeApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Tema nesnesinin id değeri
my $key = 'key_example'; # string | Tema Dosyası nesnesi anahtar değeri.

eval { 
    my $result = $api_instance->themes_id_assets_get(id => $id, key => $key);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ThemeApi->themes_id_assets_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri | 
 **key** | **string**| Tema Dosyası nesnesi anahtar değeri. | [optional] 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_id_assetskeykey_delete**
> themes_id_assetskeykey_delete(id => $id, key => $key)

Tema Dosyası Silme

Kalıcı olarak ilgili Tema Dosyasını siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ThemeApi;
my $api_instance = WWW::SwaggerClient::ThemeApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Tema nesnesinin id değeri
my $key = 'key_example'; # string | Tema Dosyası nesnesi anahtar değeri.

eval { 
    $api_instance->themes_id_assetskeykey_delete(id => $id, key => $key);
};
if ($@) {
    warn "Exception when calling ThemeApi->themes_id_assetskeykey_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri | 
 **key** | **string**| Tema Dosyası nesnesi anahtar değeri. | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_id_assetskeykey_get**
> Asset themes_id_assetskeykey_get(id => $id, key => $key)

Tema Dosyası Alma

İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ThemeApi;
my $api_instance = WWW::SwaggerClient::ThemeApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Tema nesnesinin id değeri
my $key = 'key_example'; # string | Tema Dosyası nesnesi anahtar değeri.

eval { 
    my $result = $api_instance->themes_id_assetskeykey_get(id => $id, key => $key);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ThemeApi->themes_id_assetskeykey_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri | 
 **key** | **string**| Tema Dosyası nesnesi anahtar değeri. | 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_id_assetskeykey_put**
> Asset themes_id_assetskeykey_put(id => $id, theme => $theme, asset => $asset)

Tema Dosyası Güncelleme

Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ThemeApi;
my $api_instance = WWW::SwaggerClient::ThemeApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Tema nesnesinin id değeri
my $theme = WWW::SwaggerClient::Object::Theme->new(); # Theme |  nesnesi
my $asset = WWW::SwaggerClient::Object::Asset->new(); # Asset |  nesnesi

eval { 
    my $result = $api_instance->themes_id_assetskeykey_put(id => $id, theme => $theme, asset => $asset);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ThemeApi->themes_id_assetskeykey_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri | 
 **theme** | [**Theme**](Theme.md)|  nesnesi | 
 **asset** | [**Asset**](Asset.md)|  nesnesi | 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_id_delete**
> themes_id_delete(id => $id)

Tema Silme

Kalıcı olarak ilgili Temayı siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ThemeApi;
my $api_instance = WWW::SwaggerClient::ThemeApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Tema nesnesinin id değeri

eval { 
    $api_instance->themes_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling ThemeApi->themes_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_id_get**
> Theme themes_id_get(id => $id)

Tema Alma

İlgili Temayı getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ThemeApi;
my $api_instance = WWW::SwaggerClient::ThemeApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Tema nesnesinin id değeri

eval { 
    my $result = $api_instance->themes_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ThemeApi->themes_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_id_put**
> Theme themes_id_put(id => $id, theme => $theme)

Tema Güncelleme

İlgili Temayı günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ThemeApi;
my $api_instance = WWW::SwaggerClient::ThemeApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Tema nesnesinin id değeri
my $theme = WWW::SwaggerClient::Object::Theme->new(); # Theme |  nesnesi

eval { 
    my $result = $api_instance->themes_id_put(id => $id, theme => $theme);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ThemeApi->themes_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri | 
 **theme** | [**Theme**](Theme.md)|  nesnesi | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_post**
> Theme themes_post(theme => $theme)

Tema Oluşturma

Yeni bir tema oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ThemeApi;
my $api_instance = WWW::SwaggerClient::ThemeApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $theme = WWW::SwaggerClient::Object::Theme->new(); # Theme |  nesnesi

eval { 
    my $result = $api_instance->themes_post(theme => $theme);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ThemeApi->themes_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **theme** | [**Theme**](Theme.md)|  nesnesi | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

