# WWW::SwaggerClient::SpecToProductApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::SpecToProductApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**spec_to_products_get**](SpecToProductApi.md#spec_to_products_get) | **GET** /spec_to_products | Ürün Özellik Ürün Bağı Listesi Alma
[**spec_to_products_id_delete**](SpecToProductApi.md#spec_to_products_id_delete) | **DELETE** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Silme
[**spec_to_products_id_get**](SpecToProductApi.md#spec_to_products_id_get) | **GET** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Alma
[**spec_to_products_id_put**](SpecToProductApi.md#spec_to_products_id_put) | **PUT** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Güncelleme
[**spec_to_products_post**](SpecToProductApi.md#spec_to_products_post) | **POST** /spec_to_products | Ürün Özellik Ürün Bağı Oluşturma


# **spec_to_products_get**
> SpecToProduct spec_to_products_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, product => $product, spec_group => $spec_group, spec_name => $spec_name, spec_value => $spec_value)

Ürün Özellik Ürün Bağı Listesi Alma

Ürün Özellik Ürün Bağı listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SpecToProductApi;
my $api_instance = WWW::SwaggerClient::SpecToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $product = 56; # int | Ürün id
my $spec_group = 56; # int | Ürün özellik grubu id
my $spec_name = 56; # int | Ürün özellik id
my $spec_value = 56; # int | Ürün özellik değeri id

eval { 
    my $result = $api_instance->spec_to_products_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, product => $product, spec_group => $spec_group, spec_name => $spec_name, spec_value => $spec_value);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SpecToProductApi->spec_to_products_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **product** | **int**| Ürün id | [optional] 
 **spec_group** | **int**| Ürün özellik grubu id | [optional] 
 **spec_name** | **int**| Ürün özellik id | [optional] 
 **spec_value** | **int**| Ürün özellik değeri id | [optional] 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_to_products_id_delete**
> spec_to_products_id_delete(id => $id)

Ürün Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SpecToProductApi;
my $api_instance = WWW::SwaggerClient::SpecToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Özellik Ürün Bağı nesnesinin id değeri

eval { 
    $api_instance->spec_to_products_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling SpecToProductApi->spec_to_products_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_to_products_id_get**
> SpecToProduct spec_to_products_id_get(id => $id)

Ürün Özellik Ürün Bağı Alma

İlgili Ürün Özellik Ürün Bağını getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SpecToProductApi;
my $api_instance = WWW::SwaggerClient::SpecToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Özellik Ürün Bağı nesnesinin id değeri

eval { 
    my $result = $api_instance->spec_to_products_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SpecToProductApi->spec_to_products_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_to_products_id_put**
> SpecToProduct spec_to_products_id_put(id => $id, spec_to_product => $spec_to_product)

Ürün Özellik Ürün Bağı Güncelleme

İlgili Ürün Özellik Ürün Bağını günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SpecToProductApi;
my $api_instance = WWW::SwaggerClient::SpecToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Özellik Ürün Bağı nesnesinin id değeri
my $spec_to_product = WWW::SwaggerClient::Object::SpecToProduct->new(); # SpecToProduct | SpecToProduct nesnesi

eval { 
    my $result = $api_instance->spec_to_products_id_put(id => $id, spec_to_product => $spec_to_product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SpecToProductApi->spec_to_products_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 
 **spec_to_product** | [**SpecToProduct**](SpecToProduct.md)| SpecToProduct nesnesi | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_to_products_post**
> SpecToProduct spec_to_products_post(spec_to_product => $spec_to_product)

Ürün Özellik Ürün Bağı Oluşturma

Yeni bir Ürün Özellik Ürün Bağı oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SpecToProductApi;
my $api_instance = WWW::SwaggerClient::SpecToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $spec_to_product = WWW::SwaggerClient::Object::SpecToProduct->new(); # SpecToProduct | SpecToProduct nesnesi

eval { 
    my $result = $api_instance->spec_to_products_post(spec_to_product => $spec_to_product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SpecToProductApi->spec_to_products_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **spec_to_product** | [**SpecToProduct**](SpecToProduct.md)| SpecToProduct nesnesi | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

