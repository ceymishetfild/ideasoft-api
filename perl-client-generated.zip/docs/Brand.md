# WWW::SwaggerClient::Object::Brand

## Load the model package
```perl
use WWW::SwaggerClient::Object::Brand;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Marka nesnesi kimlik değeri. | [optional] 
**name** | **string** | Marka nesnesi için isim değeri. | 
**slug** | **string** | Slug değeri ilgili nesnenin Url değeridir. | [optional] 
**sort_order** | **int** | Marka nesnesi için sıralama değeri. | [optional] 
**status** | **string** | Marka nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**distributor** | **string** | Markanın tedarikçisi. | [optional] 
**image_file** | **string** | Marka nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF | [optional] 
**showcase_content** | **string** | Marka nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir. | [optional] 
**display_showcase_content** | **string** | Marka nesnesi üst içerik metninin gösterim durumu. | [optional] 
**meta_keywords** | **string** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] 
**meta_description** | **string** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] 
**page_title** | **string** | Marka nesnesinin etiket başlığı. | [optional] 
**attachment** | **string** | Marka nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. | [optional] 
**created_at** | **DateTime** | Marka nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Marka nesnesinin güncellenme zamanı. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


