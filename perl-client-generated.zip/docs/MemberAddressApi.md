# WWW::SwaggerClient::MemberAddressApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::MemberAddressApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**member_addresses_get**](MemberAddressApi.md#member_addresses_get) | **GET** /member_addresses | Üye Adresi Listeleme
[**member_addresses_id_delete**](MemberAddressApi.md#member_addresses_id_delete) | **DELETE** /member_addresses/{id} | Üye Adresi Silme
[**member_addresses_id_get**](MemberAddressApi.md#member_addresses_id_get) | **GET** /member_addresses/{id} | Üye Adresi Alma
[**member_addresses_id_put**](MemberAddressApi.md#member_addresses_id_put) | **PUT** /member_addresses/{id} | Üye Adresi Güncelleme
[**member_addresses_post**](MemberAddressApi.md#member_addresses_post) | **POST** /member_addresses | Üye Adresi Oluşturma


# **member_addresses_get**
> MemberAddress member_addresses_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, member => $member, start_date => $start_date, end_date => $end_date)

Üye Adresi Listeleme

Üye Adresi listesi verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberAddressApi;
my $api_instance = WWW::SwaggerClient::MemberAddressApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $member = 56; # int | Üye id
my $start_date = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | createdAt değeri için başlangıç tarihi
my $end_date = 'end_date_example'; # string | createdAt değeri için bitiş tarihi

eval { 
    my $result = $api_instance->member_addresses_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, member => $member, start_date => $start_date, end_date => $end_date);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MemberAddressApi->member_addresses_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **member** | **int**| Üye id | [optional] 
 **start_date** | **DateTime**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional] 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_addresses_id_delete**
> member_addresses_id_delete(id => $id)

Üye Adresi Silme

Kalıcı olarak ilgili Üye Adresini siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberAddressApi;
my $api_instance = WWW::SwaggerClient::MemberAddressApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Üye Adresi nesnesinin id değeri

eval { 
    $api_instance->member_addresses_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling MemberAddressApi->member_addresses_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Adresi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_addresses_id_get**
> MemberAddress member_addresses_id_get(id => $id)

Üye Adresi Alma

İlgili Üye Adresini getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberAddressApi;
my $api_instance = WWW::SwaggerClient::MemberAddressApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Üye Adresi nesnesinin id değeri

eval { 
    my $result = $api_instance->member_addresses_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MemberAddressApi->member_addresses_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Adresi nesnesinin id değeri | 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_addresses_id_put**
> MemberAddress member_addresses_id_put(id => $id, member_address => $member_address)

Üye Adresi Güncelleme

İlgili Üye Adresini günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberAddressApi;
my $api_instance = WWW::SwaggerClient::MemberAddressApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Üye Adresi nesnesinin id değeri
my $member_address = WWW::SwaggerClient::Object::MemberAddress->new(); # MemberAddress |  nesnesi

eval { 
    my $result = $api_instance->member_addresses_id_put(id => $id, member_address => $member_address);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MemberAddressApi->member_addresses_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Adresi nesnesinin id değeri | 
 **member_address** | [**MemberAddress**](MemberAddress.md)|  nesnesi | 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_addresses_post**
> MemberAddress member_addresses_post(member_address => $member_address)

Üye Adresi Oluşturma

Yeni bir Üye Adresi oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberAddressApi;
my $api_instance = WWW::SwaggerClient::MemberAddressApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $member_address = WWW::SwaggerClient::Object::MemberAddress->new(); # MemberAddress |  nesnesi

eval { 
    my $result = $api_instance->member_addresses_post(member_address => $member_address);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MemberAddressApi->member_addresses_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member_address** | [**MemberAddress**](MemberAddress.md)|  nesnesi | 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

