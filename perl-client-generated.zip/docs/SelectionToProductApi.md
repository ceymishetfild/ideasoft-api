# WWW::SwaggerClient::SelectionToProductApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::SelectionToProductApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selection_to_products_get**](SelectionToProductApi.md#selection_to_products_get) | **GET** /selection_to_products | Ek Özellik Ürün Bağı Listesi Alma
[**selection_to_products_id_delete**](SelectionToProductApi.md#selection_to_products_id_delete) | **DELETE** /selection_to_products/{id} | Ek Özellik Ürün Bağı Silme
[**selection_to_products_id_get**](SelectionToProductApi.md#selection_to_products_id_get) | **GET** /selection_to_products/{id} | Ek Özellik Ürün Bağı Alma
[**selection_to_products_id_put**](SelectionToProductApi.md#selection_to_products_id_put) | **PUT** /selection_to_products/{id} | Ek Özellik Ürün Bağı Güncelleme
[**selection_to_products_post**](SelectionToProductApi.md#selection_to_products_post) | **POST** /selection_to_products | Ek Özellik Ürün Bağı Oluşturma


# **selection_to_products_get**
> SelectionToProduct selection_to_products_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, selection => $selection, product => $product)

Ek Özellik Ürün Bağı Listesi Alma

Ek Özellik Ürün Bağı listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SelectionToProductApi;
my $api_instance = WWW::SwaggerClient::SelectionToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $selection = 56; # int | Ek Özellik id
my $product = 56; # int | Ürün id

eval { 
    my $result = $api_instance->selection_to_products_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, selection => $selection, product => $product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SelectionToProductApi->selection_to_products_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **selection** | **int**| Ek Özellik id | [optional] 
 **product** | **int**| Ürün id | [optional] 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selection_to_products_id_delete**
> selection_to_products_id_delete(id => $id)

Ek Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ek Özellik Ürün Bağını siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SelectionToProductApi;
my $api_instance = WWW::SwaggerClient::SelectionToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ek Özellik Ürün Bağı nesnesinin id değeri

eval { 
    $api_instance->selection_to_products_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling SelectionToProductApi->selection_to_products_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selection_to_products_id_get**
> SelectionToProduct selection_to_products_id_get(id => $id)

Ek Özellik Ürün Bağı Alma

İlgili Ek Özellik Ürün Bağını getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SelectionToProductApi;
my $api_instance = WWW::SwaggerClient::SelectionToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ek Özellik Ürün Bağı nesnesinin id değeri

eval { 
    my $result = $api_instance->selection_to_products_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SelectionToProductApi->selection_to_products_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selection_to_products_id_put**
> SelectionToProduct selection_to_products_id_put(id => $id, selection_to_product => $selection_to_product)

Ek Özellik Ürün Bağı Güncelleme

İlgili Ek Özellik Ürün Bağını günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SelectionToProductApi;
my $api_instance = WWW::SwaggerClient::SelectionToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ek Özellik Ürün Bağı nesnesinin id değeri
my $selection_to_product = WWW::SwaggerClient::Object::SelectionToProduct->new(); # SelectionToProduct |  nesnesi

eval { 
    my $result = $api_instance->selection_to_products_id_put(id => $id, selection_to_product => $selection_to_product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SelectionToProductApi->selection_to_products_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik Ürün Bağı nesnesinin id değeri | 
 **selection_to_product** | [**SelectionToProduct**](SelectionToProduct.md)|  nesnesi | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selection_to_products_post**
> SelectionToProduct selection_to_products_post(selection_to_product => $selection_to_product)

Ek Özellik Ürün Bağı Oluşturma

Yeni bir Ek Özellik Ürün Bağı oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SelectionToProductApi;
my $api_instance = WWW::SwaggerClient::SelectionToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $selection_to_product = WWW::SwaggerClient::Object::SelectionToProduct->new(); # SelectionToProduct |  nesnesi

eval { 
    my $result = $api_instance->selection_to_products_post(selection_to_product => $selection_to_product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SelectionToProductApi->selection_to_products_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selection_to_product** | [**SelectionToProduct**](SelectionToProduct.md)|  nesnesi | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

