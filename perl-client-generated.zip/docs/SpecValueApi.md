# WWW::SwaggerClient::SpecValueApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::SpecValueApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**spec_values_get**](SpecValueApi.md#spec_values_get) | **GET** /spec_values | Ürün Özellik Değeri Listesi Alma
[**spec_values_id_delete**](SpecValueApi.md#spec_values_id_delete) | **DELETE** /spec_values/{id} | Ürün Özellik Değeri Silme
[**spec_values_id_get**](SpecValueApi.md#spec_values_id_get) | **GET** /spec_values/{id} | Ürün Özellik Değeri Alma
[**spec_values_id_put**](SpecValueApi.md#spec_values_id_put) | **PUT** /spec_values/{id} | Ürün Özellik Değeri Güncelleme
[**spec_values_post**](SpecValueApi.md#spec_values_post) | **POST** /spec_values | Ürün Özellik Değeri Oluşturma


# **spec_values_get**
> SpecValue spec_values_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, name => $name, spec_name => $spec_name, spec_value => $spec_value)

Ürün Özellik Değeri Listesi Alma

Ürün Özellik Değeri listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SpecValueApi;
my $api_instance = WWW::SwaggerClient::SpecValueApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $name = 'name_example'; # string | Ürün özellik adı
my $spec_name = 56; # int | Ürün özellik id
my $spec_value = 56; # int | Ürün özellik değeri id

eval { 
    my $result = $api_instance->spec_values_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, name => $name, spec_name => $spec_name, spec_value => $spec_value);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SpecValueApi->spec_values_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **string**| Ürün özellik adı | [optional] 
 **spec_name** | **int**| Ürün özellik id | [optional] 
 **spec_value** | **int**| Ürün özellik değeri id | [optional] 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_values_id_delete**
> spec_values_id_delete(id => $id)

Ürün Özellik Değeri Silme

Kalıcı olarak ilgili Ürün Özellik Değerini siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SpecValueApi;
my $api_instance = WWW::SwaggerClient::SpecValueApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Özellik Değeri nesnesinin id değeri

eval { 
    $api_instance->spec_values_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling SpecValueApi->spec_values_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Değeri nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_values_id_get**
> SpecValue spec_values_id_get(id => $id)

Ürün Özellik Değeri Alma

İlgili Ürün Özellik Değerini getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SpecValueApi;
my $api_instance = WWW::SwaggerClient::SpecValueApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Özellik Değeri nesnesinin id değeri

eval { 
    my $result = $api_instance->spec_values_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SpecValueApi->spec_values_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Değeri nesnesinin id değeri | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_values_id_put**
> SpecValue spec_values_id_put(id => $id, spec_value => $spec_value)

Ürün Özellik Değeri Güncelleme

İlgili Ürün Özellik Değerini günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SpecValueApi;
my $api_instance = WWW::SwaggerClient::SpecValueApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Özellik Değeri nesnesinin id değeri
my $spec_value = WWW::SwaggerClient::Object::SpecValue->new(); # SpecValue | SpecValue nesnesi

eval { 
    my $result = $api_instance->spec_values_id_put(id => $id, spec_value => $spec_value);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SpecValueApi->spec_values_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Değeri nesnesinin id değeri | 
 **spec_value** | [**SpecValue**](SpecValue.md)| SpecValue nesnesi | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_values_post**
> SpecValue spec_values_post(spec_value => $spec_value)

Ürün Özellik Değeri Oluşturma

Yeni bir Ürün Özellik Değeri oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SpecValueApi;
my $api_instance = WWW::SwaggerClient::SpecValueApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $spec_value = WWW::SwaggerClient::Object::SpecValue->new(); # SpecValue | SpecValue nesnesi

eval { 
    my $result = $api_instance->spec_values_post(spec_value => $spec_value);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SpecValueApi->spec_values_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **spec_value** | [**SpecValue**](SpecValue.md)| SpecValue nesnesi | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

