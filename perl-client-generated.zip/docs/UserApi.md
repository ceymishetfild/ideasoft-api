# WWW::SwaggerClient::UserApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::UserApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**users_get**](UserApi.md#users_get) | **GET** /users | Yönetici Listesi Alma
[**users_id_get**](UserApi.md#users_id_get) | **GET** /users/{id} | Yönetici Alma


# **users_get**
> User users_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, firstname => $firstname, surname => $surname, email => $email, username => $username, phone_number => $phone_number, is_owner => $is_owner, status => $status, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at)

Yönetici Listesi Alma

Yönetici listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::UserApi;
my $api_instance = WWW::SwaggerClient::UserApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $firstname = 'firstname_example'; # string | Adı
my $surname = 'surname_example'; # string | Soyadı
my $email = 'email_example'; # string | e-mail
my $username = 'username_example'; # string | Yönetici adı
my $phone_number = 'phone_number_example'; # string | Telefon numarası
my $is_owner = 'is_owner_example'; # string | Mağaza sahibi mi?<code>0</code><br><code>1</code>
my $status = 'status_example'; # string | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif<br><code>2</code> : Askıya alınmış
my $start_date = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | createdAt değeri için başlangıç tarihi
my $end_date = 'end_date_example'; # string | createdAt değeri için bitiş tarihi
my $start_updated_at = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | updatedAt değeri için başlangıç tarihi
my $end_updated_at = 'end_updated_at_example'; # string | updatedAt değeri için bitiş tarihi

eval { 
    my $result = $api_instance->users_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, firstname => $firstname, surname => $surname, email => $email, username => $username, phone_number => $phone_number, is_owner => $is_owner, status => $status, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling UserApi->users_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **firstname** | **string**| Adı | [optional] 
 **surname** | **string**| Soyadı | [optional] 
 **email** | **string**| e-mail | [optional] 
 **username** | **string**| Yönetici adı | [optional] 
 **phone_number** | **string**| Telefon numarası | [optional] 
 **is_owner** | **string**| Mağaza sahibi mi?&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Askıya alınmış | [optional] 
 **start_date** | **DateTime**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **DateTime**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**User**](User.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **users_id_get**
> User users_id_get(id => $id)

Yönetici Alma

İlgili Yöneticiyi  getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::UserApi;
my $api_instance = WWW::SwaggerClient::UserApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Yönetici nesnesinin id değeri

eval { 
    my $result = $api_instance->users_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling UserApi->users_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Yönetici nesnesinin id değeri | 

### Return type

[**User**](User.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

