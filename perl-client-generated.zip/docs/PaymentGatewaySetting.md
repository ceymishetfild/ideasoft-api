# WWW::SwaggerClient::Object::PaymentGatewaySetting

## Load the model package
```perl
use WWW::SwaggerClient::Object::PaymentGatewaySetting;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ödeme kanalı ayarı nesnesi kimlik değeri. | [optional] 
**var_key** | **string** | Ödeme kanalı ayarı nesnesi için değişken anahtarı. | 
**var_value** | **string** | Ödeme kanalı ayarı nesnesi için değişken değeri. | 
**payment_gateway** | [**PaymentGateway**](PaymentGateway.md) | Ödeme kanalı nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


