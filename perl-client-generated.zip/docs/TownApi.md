# WWW::SwaggerClient::TownApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::TownApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**towns_get**](TownApi.md#towns_get) | **GET** /towns | İlçe Listesi Alma
[**towns_id_delete**](TownApi.md#towns_id_delete) | **DELETE** /towns/{id} | İlçe Silme
[**towns_id_get**](TownApi.md#towns_id_get) | **GET** /towns/{id} | İlçe Alma
[**towns_id_put**](TownApi.md#towns_id_put) | **PUT** /towns/{id} | İlçe Güncelleme
[**towns_post**](TownApi.md#towns_post) | **POST** /towns | İlçe Oluşturma


# **towns_get**
> Town towns_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, location => $location, town_group => $town_group, name => $name, status => $status)

İlçe Listesi Alma

İlçe listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::TownApi;
my $api_instance = WWW::SwaggerClient::TownApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $location = 56; # int | Şehir id
my $town_group = 56; # int | İlçe grubu id
my $name = 'name_example'; # string | İlçe adı.
my $status = 'status_example'; # string | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif

eval { 
    my $result = $api_instance->towns_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, location => $location, town_group => $town_group, name => $name, status => $status);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling TownApi->towns_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **location** | **int**| Şehir id | [optional] 
 **town_group** | **int**| İlçe grubu id | [optional] 
 **name** | **string**| İlçe adı. | [optional] 
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **towns_id_delete**
> towns_id_delete(id => $id)

İlçe Silme

Kalıcı olarak ilgili İlçeyi siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::TownApi;
my $api_instance = WWW::SwaggerClient::TownApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | İlçe nesnesinin id değeri

eval { 
    $api_instance->towns_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling TownApi->towns_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **towns_id_get**
> Town towns_id_get(id => $id)

İlçe Alma

İlgili İlçeyi getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::TownApi;
my $api_instance = WWW::SwaggerClient::TownApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | İlçe nesnesinin id değeri

eval { 
    my $result = $api_instance->towns_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling TownApi->towns_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe nesnesinin id değeri | 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **towns_id_put**
> Town towns_id_put(id => $id, town => $town)

İlçe Güncelleme

İlgili İlçeyi günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::TownApi;
my $api_instance = WWW::SwaggerClient::TownApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | İlçe nesnesinin id değeri
my $town = WWW::SwaggerClient::Object::Town->new(); # Town | Town nesnesi

eval { 
    my $result = $api_instance->towns_id_put(id => $id, town => $town);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling TownApi->towns_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe nesnesinin id değeri | 
 **town** | [**Town**](Town.md)| Town nesnesi | 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **towns_post**
> Town towns_post(town => $town)

İlçe Oluşturma

Yeni bir İlçe oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::TownApi;
my $api_instance = WWW::SwaggerClient::TownApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $town = WWW::SwaggerClient::Object::Town->new(); # Town | Town nesnesi

eval { 
    my $result = $api_instance->towns_post(town => $town);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling TownApi->towns_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **town** | [**Town**](Town.md)| Town nesnesi | 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

