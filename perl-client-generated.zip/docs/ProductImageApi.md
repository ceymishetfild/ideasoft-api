# WWW::SwaggerClient::ProductImageApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ProductImageApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_images_get**](ProductImageApi.md#product_images_get) | **GET** /product_images | Ürün Resim Listesi Alma
[**product_images_id_delete**](ProductImageApi.md#product_images_id_delete) | **DELETE** /product_images/{id} | Ürün Resim Silme
[**product_images_id_get**](ProductImageApi.md#product_images_id_get) | **GET** /product_images/{id} | Ürün Resim Alma
[**product_images_post**](ProductImageApi.md#product_images_post) | **POST** /product_images | Ürün Resim Oluşturma


# **product_images_get**
> ProductImage product_images_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, file_name => $file_name, product => $product)

Ürün Resim Listesi Alma

Ürün Resim listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductImageApi;
my $api_instance = WWW::SwaggerClient::ProductImageApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $file_name = 'file_name_example'; # string | Ürün Resim dosya adı
my $product = 56; # int | Ürün id

eval { 
    my $result = $api_instance->product_images_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, file_name => $file_name, product => $product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductImageApi->product_images_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **file_name** | **string**| Ürün Resim dosya adı | [optional] 
 **product** | **int**| Ürün id | [optional] 

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_images_id_delete**
> product_images_id_delete(id => $id)

Ürün Resim Silme

Kalıcı olarak ilgili Ürün Resmini siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductImageApi;
my $api_instance = WWW::SwaggerClient::ProductImageApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Resmi nesnesinin id değeri

eval { 
    $api_instance->product_images_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling ProductImageApi->product_images_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Resmi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_images_id_get**
> ProductImage product_images_id_get(id => $id)

Ürün Resim Alma

İlgili Ürün Resmini getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductImageApi;
my $api_instance = WWW::SwaggerClient::ProductImageApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Resmi nesnesinin id değeri

eval { 
    my $result = $api_instance->product_images_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductImageApi->product_images_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Resmi nesnesinin id değeri | 

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_images_post**
> ProductImage product_images_post(product_image => $product_image)

Ürün Resim Oluşturma

Yeni bir Ürün Resim oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductImageApi;
my $api_instance = WWW::SwaggerClient::ProductImageApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $product_image = WWW::SwaggerClient::Object::ProductImage->new(); # ProductImage | ProductImage nesnesi

eval { 
    my $result = $api_instance->product_images_post(product_image => $product_image);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductImageApi->product_images_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_image** | [**ProductImage**](ProductImage.md)| ProductImage nesnesi | 

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

