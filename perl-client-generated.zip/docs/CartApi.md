# WWW::SwaggerClient::CartApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::CartApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**carts_id_delete**](CartApi.md#carts_id_delete) | **DELETE** /carts/{id} | Sepet Silme
[**carts_id_get**](CartApi.md#carts_id_get) | **GET** /carts/{id} | Sepet Alma
[**carts_post**](CartApi.md#carts_post) | **POST** /carts | Sepet Oluşturma


# **carts_id_delete**
> carts_id_delete(id => $id)

Sepet Silme

Kalıcı olarak ilgili Sepeti siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::CartApi;
my $api_instance = WWW::SwaggerClient::CartApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sepet nesnesinin id değeri

eval { 
    $api_instance->carts_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling CartApi->carts_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sepet nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **carts_id_get**
> Cart carts_id_get(id => $id)

Sepet Alma

İlgili Sepet getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::CartApi;
my $api_instance = WWW::SwaggerClient::CartApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sepet nesnesinin id değeri

eval { 
    my $result = $api_instance->carts_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CartApi->carts_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sepet nesnesinin id değeri | 

### Return type

[**Cart**](Cart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **carts_post**
> Cart carts_post(cart => $cart)

Sepet Oluşturma

Yeni bir Sepet oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::CartApi;
my $api_instance = WWW::SwaggerClient::CartApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $cart = WWW::SwaggerClient::Object::Cart->new(); # Cart | Cart nesnesi

eval { 
    my $result = $api_instance->carts_post(cart => $cart);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CartApi->carts_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart** | [**Cart**](Cart.md)| Cart nesnesi | 

### Return type

[**Cart**](Cart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

