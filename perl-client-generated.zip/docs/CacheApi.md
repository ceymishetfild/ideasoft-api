# WWW::SwaggerClient::CacheApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::CacheApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cache_delete**](CacheApi.md#cache_delete) | **DELETE** /cache | Önbellek Silme


# **cache_delete**
> cache_delete()

Önbellek Silme

Kalıcı olarak Önbelleği siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::CacheApi;
my $api_instance = WWW::SwaggerClient::CacheApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);


eval { 
    $api_instance->cache_delete();
};
if ($@) {
    warn "Exception when calling CacheApi->cache_delete: $@\n";
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

