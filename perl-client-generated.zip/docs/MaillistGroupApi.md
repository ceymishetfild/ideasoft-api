# WWW::SwaggerClient::MaillistGroupApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::MaillistGroupApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**maillist_groups_get**](MaillistGroupApi.md#maillist_groups_get) | **GET** /maillist_groups | Mail Listesi Grubu Listesi Alma
[**maillist_groups_id_delete**](MaillistGroupApi.md#maillist_groups_id_delete) | **DELETE** /maillist_groups/{id} | Mail Listesi Grubu Silme
[**maillist_groups_id_get**](MaillistGroupApi.md#maillist_groups_id_get) | **GET** /maillist_groups/{id} | Mail Listesi Grubu Alma
[**maillist_groups_id_put**](MaillistGroupApi.md#maillist_groups_id_put) | **PUT** /maillist_groups/{id} | Mail Listesi Grubu Güncelleme
[**maillist_groups_post**](MaillistGroupApi.md#maillist_groups_post) | **POST** /maillist_groups | Mail Listesi Grubu Oluşturma


# **maillist_groups_get**
> MaillistGroup maillist_groups_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, name => $name)

Mail Listesi Grubu Listesi Alma

Mail Listesi Grubu listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MaillistGroupApi;
my $api_instance = WWW::SwaggerClient::MaillistGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $name = 'name_example'; # string | Mail Listesi Grubu adı

eval { 
    my $result = $api_instance->maillist_groups_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, name => $name);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MaillistGroupApi->maillist_groups_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **string**| Mail Listesi Grubu adı | [optional] 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillist_groups_id_delete**
> maillist_groups_id_delete(id => $id)

Mail Listesi Grubu Silme

Kalıcı olarak ilgili Mail Listesi Grubunu siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MaillistGroupApi;
my $api_instance = WWW::SwaggerClient::MaillistGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Mail Listesi Grubu nesnesinin id değeri

eval { 
    $api_instance->maillist_groups_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling MaillistGroupApi->maillist_groups_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillist_groups_id_get**
> MaillistGroup maillist_groups_id_get(id => $id)

Mail Listesi Grubu Alma

İlgili Mail Listesi Grubunu getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MaillistGroupApi;
my $api_instance = WWW::SwaggerClient::MaillistGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Mail Listesi Grubu nesnesinin id değeri

eval { 
    my $result = $api_instance->maillist_groups_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MaillistGroupApi->maillist_groups_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi Grubu nesnesinin id değeri | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillist_groups_id_put**
> MaillistGroup maillist_groups_id_put(id => $id, maillist_group => $maillist_group)

Mail Listesi Grubu Güncelleme

İlgili Mail Listesi Grubunu günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MaillistGroupApi;
my $api_instance = WWW::SwaggerClient::MaillistGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Mail Listesi Grubu nesnesinin id değeri
my $maillist_group = WWW::SwaggerClient::Object::MaillistGroup->new(); # MaillistGroup | MaillistGroup nesnesi

eval { 
    my $result = $api_instance->maillist_groups_id_put(id => $id, maillist_group => $maillist_group);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MaillistGroupApi->maillist_groups_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi Grubu nesnesinin id değeri | 
 **maillist_group** | [**MaillistGroup**](MaillistGroup.md)| MaillistGroup nesnesi | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillist_groups_post**
> MaillistGroup maillist_groups_post(maillist_group => $maillist_group)

Mail Listesi Grubu Oluşturma

Yeni bir Mail Listesi Grubu oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MaillistGroupApi;
my $api_instance = WWW::SwaggerClient::MaillistGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $maillist_group = WWW::SwaggerClient::Object::MaillistGroup->new(); # MaillistGroup | MaillistGroup nesnesi

eval { 
    my $result = $api_instance->maillist_groups_post(maillist_group => $maillist_group);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MaillistGroupApi->maillist_groups_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **maillist_group** | [**MaillistGroup**](MaillistGroup.md)| MaillistGroup nesnesi | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

