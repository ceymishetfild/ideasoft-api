# WWW::SwaggerClient::Object::Member

## Load the model package
```perl
use WWW::SwaggerClient::Object::Member;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Üye nesnesi kimlik değeri. | [optional] 
**firstname** | **string** | Üyenin ismi. | 
**surname** | **string** | Üyenin soy ismi. | 
**email** | **string** | Üyenin e-mail adresi. | 
**gender** | **string** | Üyenin cinsiyet bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın&lt;br&gt;&lt;/div&gt; | [optional] 
**birth_date** | **DateTime** | Üyenin doğum tarihi. | [optional] 
**phone_number** | **string** | Üyenin telefon numarası. | [optional] 
**mobile_phone_number** | **string** | Üyenin mobil telefon numarası. | [optional] 
**other_location** | **string** | Üyenin diğer şehir bilgileri. | [optional] 
**address** | **string** | Üyenin adres bilgileri. | [optional] 
**tax_number** | **string** | Üyenin vergi numarası. | [optional] 
**tc_id** | **string** | Üyenin TC kimlik numarası. | [optional] 
**status** | **string** | Üyenin durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;queue&lt;/code&gt; : Sırada&lt;br&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;suspended&lt;/code&gt; : Askıda&lt;br&gt;&lt;/div&gt; | 
**last_login_date** | **DateTime** | Üyenin son giriş yaptığı tarih. | [optional] 
**created_at** | **DateTime** | Üye nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Üye nesnesinin güncellenme zamanı. | [optional] 
**zip_code** | **string** | Üyenin posta kodu. | [optional] 
**commercial_name** | **string** | Üyenin kurumsal adı. | [optional] 
**tax_office** | **string** | Üyenin vergi dairesi. | [optional] 
**last_mail_sent_date** | **DateTime** | Üyeye gönderilen son e-mail tarihi. | [optional] 
**last_ip** | **string** | Üyenin en son giriş yaptığı IP adresi. | [optional] 
**gained_point_amount** | **double** | Üyenin kazandığı puan tutarı. | [optional] 
**spent_point_amount** | **double** | Üyenin harcadığı puan tutarı. | [optional] 
**allowed_to_campaigns** | **string** | Üyenin kampanyalara katılım için izin durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalar için izinli.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalar için izinsiz.&lt;br&gt;&lt;/div&gt; | [optional] 
**referred_member_gained_point_amount** | **double** | Üyenin tavsiye ettiği kişilerden dolayı kazandığı puan. | [optional] 
**district** | **string** | Üyenin ilçesi. | [optional] 
**device_type** | **string** | Üyenin kullandığı cihaz tipi. | 
**device_info** | **string** | Üyenin kullandığı cihaz bilgisi. | [optional] 
**country** | [**Country**](Country.md) |  | [optional] 
**location** | [**Location**](Location.md) |  | [optional] 
**member_group** | [**MemberGroup**](MemberGroup.md) |  | [optional] 
**referred_member** | [**Member**](Member.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


