# WWW::SwaggerClient::Object::OrderItemCustomization

## Load the model package
```perl
use WWW::SwaggerClient::Object::OrderItemCustomization;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sipariş kalemi özelleştirme kimlik değeri. | [optional] 
**product_customization_group_id** | **int** | Ürün özelleştirme grubu nesnesi kimlik değeri. | [optional] 
**product_customization_group_name** | **string** | Ürün özelleştirme grubu nesnesinin grup adı. | [optional] 
**product_customization_group_sort_order** | **int** | Ürün özelleştirme grubu nesnesinin sıralaması. | [optional] 
**product_customization_field_id** | **int** | Ürün özelleştirme nesnesi kimlik değeri.. | [optional] 
**product_customization_field_type** | **string** | Ürün özelleştirme nesnesinin alan tipi. | [optional] 
**product_customization_field_name** | **string** | Ürün özelleştirme nesnesinin alan adı. | [optional] 
**product_customization_field_value** | **string** | Ürün özelleştirme nesnesinin değeri. | [optional] 
**cart_item_attribute_id** | **int** | Sepet kalemi özelliği nesnesi kimlik değeri. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


