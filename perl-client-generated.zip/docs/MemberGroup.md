# WWW::SwaggerClient::Object::MemberGroup

## Load the model package
```perl
use WWW::SwaggerClient::Object::MemberGroup;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Üye Grubu nesnesi kimlik değeri. | [optional] 
**name** | **string** | Üye Grubu nesnesi için isim değeri. | 
**price_index** | **int** | Üye Grubunun fiyat indisi. Örnek Fiyat 2. | 
**allowed_payment_gateways** | **string** | Üye Grubunun izin verilmiş ödeme kanalları. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


