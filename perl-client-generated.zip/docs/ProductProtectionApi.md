# WWW::SwaggerClient::ProductProtectionApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ProductProtectionApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_protections_get**](ProductProtectionApi.md#product_protections_get) | **GET** /product_protections | Entegrasyon Seçeneği Listesi Alma
[**product_protections_id_delete**](ProductProtectionApi.md#product_protections_id_delete) | **DELETE** /product_protections/{id} | Entegrasyon Seçeneği Silme
[**product_protections_id_get**](ProductProtectionApi.md#product_protections_id_get) | **GET** /product_protections/{id} | Entegrasyon Seçeneği Alma
[**product_protections_id_put**](ProductProtectionApi.md#product_protections_id_put) | **PUT** /product_protections/{id} | Entegrasyon Seçeneği Güncelleme
[**product_protections_post**](ProductProtectionApi.md#product_protections_post) | **POST** /product_protections | Entegrasyon Seçeneği Oluşturma


# **product_protections_get**
> ProductProtection product_protections_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, is_price_protected => $is_price_protected, is_stock_protected => $is_stock_protected, product => $product)

Entegrasyon Seçeneği Listesi Alma

Entegrasyon Seçeneği listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductProtectionApi;
my $api_instance = WWW::SwaggerClient::ProductProtectionApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $is_price_protected = 56; # int | Fiyat korumalı ürünleri listeler<code>0</code><br><code>1</code>
my $is_stock_protected = 56; # int | Stok korumalı ürünleri listeler<code>0</code><br><code>1</code>
my $product = 56; # int | Ürün id

eval { 
    my $result = $api_instance->product_protections_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, is_price_protected => $is_price_protected, is_stock_protected => $is_stock_protected, product => $product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductProtectionApi->product_protections_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **is_price_protected** | **int**| Fiyat korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **is_stock_protected** | **int**| Stok korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **product** | **int**| Ürün id | [optional] 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_protections_id_delete**
> product_protections_id_delete(id => $id)

Entegrasyon Seçeneği Silme

Kalıcı olarak ilgili Entegrasyon Seçeneğini siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductProtectionApi;
my $api_instance = WWW::SwaggerClient::ProductProtectionApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Entegrasyon Seçeneği nesnesinin id değeri

eval { 
    $api_instance->product_protections_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling ProductProtectionApi->product_protections_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Entegrasyon Seçeneği nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_protections_id_get**
> ProductProtection product_protections_id_get(id => $id)

Entegrasyon Seçeneği Alma

İlgili Entegrasyon Seçeneğini getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductProtectionApi;
my $api_instance = WWW::SwaggerClient::ProductProtectionApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Entegrasyon Seçeneği nesnesinin id değeri

eval { 
    my $result = $api_instance->product_protections_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductProtectionApi->product_protections_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Entegrasyon Seçeneği nesnesinin id değeri | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_protections_id_put**
> ProductProtection product_protections_id_put(id => $id, product_protection => $product_protection)

Entegrasyon Seçeneği Güncelleme

İlgili Entegrasyon Seçeneğini günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductProtectionApi;
my $api_instance = WWW::SwaggerClient::ProductProtectionApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Entegrasyon Seçeneği nesnesinin id değeri
my $product_protection = WWW::SwaggerClient::Object::ProductProtection->new(); # ProductProtection | ProductProtection nesnesi

eval { 
    my $result = $api_instance->product_protections_id_put(id => $id, product_protection => $product_protection);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductProtectionApi->product_protections_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Entegrasyon Seçeneği nesnesinin id değeri | 
 **product_protection** | [**ProductProtection**](ProductProtection.md)| ProductProtection nesnesi | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_protections_post**
> ProductProtection product_protections_post(product_protection => $product_protection)

Entegrasyon Seçeneği Oluşturma

Yeni bir Entegrasyon Seçeneği oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductProtectionApi;
my $api_instance = WWW::SwaggerClient::ProductProtectionApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $product_protection = WWW::SwaggerClient::Object::ProductProtection->new(); # ProductProtection | ProductProtection nesnesi

eval { 
    my $result = $api_instance->product_protections_post(product_protection => $product_protection);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductProtectionApi->product_protections_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_protection** | [**ProductProtection**](ProductProtection.md)| ProductProtection nesnesi | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

