# WWW::SwaggerClient::ProductSpecialInfoApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ProductSpecialInfoApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_special_infos_get**](ProductSpecialInfoApi.md#product_special_infos_get) | **GET** /product_special_infos | Ürün Özel Bilgi Alanı Listesi Alma
[**product_special_infos_id_delete**](ProductSpecialInfoApi.md#product_special_infos_id_delete) | **DELETE** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**product_special_infos_id_get**](ProductSpecialInfoApi.md#product_special_infos_id_get) | **GET** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**product_special_infos_id_put**](ProductSpecialInfoApi.md#product_special_infos_id_put) | **PUT** /product_special_infos/{id} | Ürün Özel Bilgi Alanı Güncelleme
[**product_special_infos_post**](ProductSpecialInfoApi.md#product_special_infos_post) | **POST** /product_special_infos | Ürün Özel Bilgi Alanı Oluşturma


# **product_special_infos_get**
> ProductSpecialInfo product_special_infos_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, title => $title, status => $status, product => $product)

Ürün Özel Bilgi Alanı Listesi Alma

Ürün Özel Bilgi Alanı listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductSpecialInfoApi;
my $api_instance = WWW::SwaggerClient::ProductSpecialInfoApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $title = 'title_example'; # string | Ürün Özel Bilgi Alanı başlığı
my $status = 56; # int | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
my $product = 56; # int | Ürün id

eval { 
    my $result = $api_instance->product_special_infos_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, title => $title, status => $status, product => $product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductSpecialInfoApi->product_special_infos_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **title** | **string**| Ürün Özel Bilgi Alanı başlığı | [optional] 
 **status** | **int**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **product** | **int**| Ürün id | [optional] 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_special_infos_id_delete**
> product_special_infos_id_delete(id => $id)

Ürün Özel Bilgi Alanı

Kalıcı olarak ilgili Ürün Özel Bilgi Alanını siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductSpecialInfoApi;
my $api_instance = WWW::SwaggerClient::ProductSpecialInfoApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Özel Bilgi Alanı nesnesinin id değeri

eval { 
    $api_instance->product_special_infos_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling ProductSpecialInfoApi->product_special_infos_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_special_infos_id_get**
> ProductSpecialInfo product_special_infos_id_get(id => $id)

Ürün Özel Bilgi Alanı

İlgili Ürün Özel Bilgi Alanını getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductSpecialInfoApi;
my $api_instance = WWW::SwaggerClient::ProductSpecialInfoApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Özel Bilgi Alanı nesnesinin id değeri

eval { 
    my $result = $api_instance->product_special_infos_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductSpecialInfoApi->product_special_infos_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_special_infos_id_put**
> ProductSpecialInfo product_special_infos_id_put(id => $id, product_special_info => $product_special_info)

Ürün Özel Bilgi Alanı Güncelleme

İlgili Ürün Özel Bilgi Alanını günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductSpecialInfoApi;
my $api_instance = WWW::SwaggerClient::ProductSpecialInfoApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Özel Bilgi Alanı nesnesinin id değeri
my $product_special_info = WWW::SwaggerClient::Object::ProductSpecialInfo->new(); # ProductSpecialInfo | ProductSpecialInfo nesnesi

eval { 
    my $result = $api_instance->product_special_infos_id_put(id => $id, product_special_info => $product_special_info);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductSpecialInfoApi->product_special_infos_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 
 **product_special_info** | [**ProductSpecialInfo**](ProductSpecialInfo.md)| ProductSpecialInfo nesnesi | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_special_infos_post**
> ProductSpecialInfo product_special_infos_post(product_special_info => $product_special_info)

Ürün Özel Bilgi Alanı Oluşturma

Yeni bir Ürün Özel Bilgi Alanı oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductSpecialInfoApi;
my $api_instance = WWW::SwaggerClient::ProductSpecialInfoApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $product_special_info = WWW::SwaggerClient::Object::ProductSpecialInfo->new(); # ProductSpecialInfo | ProductSpecialInfo nesnesi

eval { 
    my $result = $api_instance->product_special_infos_post(product_special_info => $product_special_info);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductSpecialInfoApi->product_special_infos_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_special_info** | [**ProductSpecialInfo**](ProductSpecialInfo.md)| ProductSpecialInfo nesnesi | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

