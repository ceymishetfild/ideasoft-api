# WWW::SwaggerClient::ProductApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ProductApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**products_get**](ProductApi.md#products_get) | **GET** /products | Ürün Listesi Alma
[**products_id_delete**](ProductApi.md#products_id_delete) | **DELETE** /products/{id} | Ürün Silme
[**products_id_get**](ProductApi.md#products_id_get) | **GET** /products/{id} | Ürün Alma
[**products_id_put**](ProductApi.md#products_id_put) | **PUT** /products/{id} | Ürün Güncelleme
[**products_post**](ProductApi.md#products_post) | **POST** /products | Ürün Oluşturma


# **products_get**
> Product products_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, parent => $parent, brand => $brand, sku => $sku, name => $name, distributor => $distributor, q => $q, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at)

Ürün Listesi Alma

Ürün listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductApi;
my $api_instance = WWW::SwaggerClient::ProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $parent = 'parent_example'; # string | Ürün id
my $brand = 56; # int | Marka id
my $sku = 'sku_example'; # string | Ürün stok kodu.
my $name = 'name_example'; # string | Ürün adı.
my $distributor = 'distributor_example'; # string | Ürün distribütör.
my $q = []; # ARRAY[string] | Ürün arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;]
my $start_date = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | createdAt değeri için başlangıç tarihi
my $end_date = 'end_date_example'; # string | createdAt değeri için bitiş tarihi
my $start_updated_at = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | updatedAt değeri için başlangıç tarihi
my $end_updated_at = 'end_updated_at_example'; # string | updatedAt değeri için bitiş tarihi

eval { 
    my $result = $api_instance->products_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, parent => $parent, brand => $brand, sku => $sku, name => $name, distributor => $distributor, q => $q, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductApi->products_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **parent** | **string**| Ürün id | [optional] 
 **brand** | **int**| Marka id | [optional] 
 **sku** | **string**| Ürün stok kodu. | [optional] 
 **name** | **string**| Ürün adı. | [optional] 
 **distributor** | **string**| Ürün distribütör. | [optional] 
 **q** | [**ARRAY[string]**](string.md)| Ürün arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 
 **start_date** | **DateTime**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **DateTime**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **products_id_delete**
> products_id_delete(id => $id)

Ürün Silme

Kalıcı olarak ilgili Ürünü siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductApi;
my $api_instance = WWW::SwaggerClient::ProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün nesnesinin id değeri

eval { 
    $api_instance->products_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling ProductApi->products_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **products_id_get**
> Product products_id_get(id => $id)

Ürün Alma

İlgili Ürünü getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductApi;
my $api_instance = WWW::SwaggerClient::ProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün nesnesinin id değeri

eval { 
    my $result = $api_instance->products_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductApi->products_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün nesnesinin id değeri | 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **products_id_put**
> Product products_id_put(id => $id, product => $product)

Ürün Güncelleme

İlgili Ürünü günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductApi;
my $api_instance = WWW::SwaggerClient::ProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün nesnesinin id değeri
my $product = WWW::SwaggerClient::Object::Product->new(); # Product | Product nesnesi

eval { 
    my $result = $api_instance->products_id_put(id => $id, product => $product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductApi->products_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün nesnesinin id değeri | 
 **product** | [**Product**](Product.md)| Product nesnesi | 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **products_post**
> Product products_post(product => $product)

Ürün Oluşturma

Yeni bir Ürün oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductApi;
my $api_instance = WWW::SwaggerClient::ProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $product = WWW::SwaggerClient::Object::Product->new(); # Product | Product nesnesi

eval { 
    my $result = $api_instance->products_post(product => $product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductApi->products_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product** | [**Product**](Product.md)| Product nesnesi | 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

