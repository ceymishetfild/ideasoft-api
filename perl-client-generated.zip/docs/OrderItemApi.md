# WWW::SwaggerClient::OrderItemApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::OrderItemApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**order_items_get**](OrderItemApi.md#order_items_get) | **GET** /order_items | Sipariş Kalemi Listesi Alma
[**order_items_id_get**](OrderItemApi.md#order_items_id_get) | **GET** /order_items/{id} | Sipariş Kalemi Alma


# **order_items_get**
> OrderItem order_items_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, order => $order, product_name => $product_name, product_sku => $product_sku, product_barcode => $product_barcode, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at)

Sipariş Kalemi Listesi Alma

Sipariş Kalemi listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderItemApi;
my $api_instance = WWW::SwaggerClient::OrderItemApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $order = 56; # int | Sipariş id
my $product_name = 'product_name_example'; # string | Ürün adı
my $product_sku = 'product_sku_example'; # string | Ürün stok kodu
my $product_barcode = 'product_barcode_example'; # string | Ürün barkodu
my $start_date = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | createdAt değeri için başlangıç tarihi
my $end_date = 'end_date_example'; # string | createdAt değeri için bitiş tarihi
my $start_updated_at = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | updatedAt değeri için başlangıç tarihi
my $end_updated_at = 'end_updated_at_example'; # string | updatedAt değeri için bitiş tarihi

eval { 
    my $result = $api_instance->order_items_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, order => $order, product_name => $product_name, product_sku => $product_sku, product_barcode => $product_barcode, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderItemApi->order_items_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **int**| Sipariş id | [optional] 
 **product_name** | **string**| Ürün adı | [optional] 
 **product_sku** | **string**| Ürün stok kodu | [optional] 
 **product_barcode** | **string**| Ürün barkodu | [optional] 
 **start_date** | **DateTime**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **DateTime**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**OrderItem**](OrderItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_items_id_get**
> OrderItem order_items_id_get(id => $id)

Sipariş Kalemi Alma

İlgili Sipariş Kalemini getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderItemApi;
my $api_instance = WWW::SwaggerClient::OrderItemApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş Kalemi nesnesinin id değeri

eval { 
    my $result = $api_instance->order_items_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderItemApi->order_items_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Kalemi nesnesinin id değeri | 

### Return type

[**OrderItem**](OrderItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

