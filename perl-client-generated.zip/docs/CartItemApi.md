# WWW::SwaggerClient::CartItemApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::CartItemApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cart_items_id_delete**](CartItemApi.md#cart_items_id_delete) | **DELETE** /cart_items/{id} | Sepet Kalemi Silme
[**cart_items_id_put**](CartItemApi.md#cart_items_id_put) | **PUT** /cart_items/{id} | Sepet Kalemi Güncelleme
[**cart_items_post**](CartItemApi.md#cart_items_post) | **POST** /cart_items | Sepet Kalemi Oluşturma


# **cart_items_id_delete**
> cart_items_id_delete(id => $id)

Sepet Kalemi Silme

Kalıcı olarak ilgili Sepet Kalemini siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::CartItemApi;
my $api_instance = WWW::SwaggerClient::CartItemApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sepet Kalemi nesnesinin id değeri

eval { 
    $api_instance->cart_items_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling CartItemApi->cart_items_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sepet Kalemi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cart_items_id_put**
> CartItem cart_items_id_put(id => $id)

Sepet Kalemi Güncelleme

İlgili Sepet Kalemini günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::CartItemApi;
my $api_instance = WWW::SwaggerClient::CartItemApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sepet Kalemi nesnesinin id değeri

eval { 
    my $result = $api_instance->cart_items_id_put(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CartItemApi->cart_items_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sepet Kalemi nesnesinin id değeri | 

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cart_items_post**
> CartItem cart_items_post(cart_item => $cart_item)

Sepet Kalemi Oluşturma

Yeni bir Sepet Kalemi oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::CartItemApi;
my $api_instance = WWW::SwaggerClient::CartItemApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $cart_item = WWW::SwaggerClient::Object::CartItem->new(); # CartItem | CartItem nesnesi

eval { 
    my $result = $api_instance->cart_items_post(cart_item => $cart_item);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CartItemApi->cart_items_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_item** | [**CartItem**](CartItem.md)| CartItem nesnesi | 

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

