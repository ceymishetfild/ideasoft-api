# WWW::SwaggerClient::OptionsApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::OptionsApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**options_get**](OptionsApi.md#options_get) | **GET** /options | Varyant Listesi Alma
[**options_id_delete**](OptionsApi.md#options_id_delete) | **DELETE** /options/{id} | Varyant Silme
[**options_id_get**](OptionsApi.md#options_id_get) | **GET** /options/{id} | Varyant Alma
[**options_id_put**](OptionsApi.md#options_id_put) | **PUT** /options/{id} | Varyant Güncelleme
[**options_post**](OptionsApi.md#options_post) | **POST** /options | Varyant Oluşturma


# **options_get**
> Options options_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, title => $title, option_group => $option_group)

Varyant Listesi Alma

Varyant listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OptionsApi;
my $api_instance = WWW::SwaggerClient::OptionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $title = 'title_example'; # string | Varyant başlığı
my $option_group = 56; # int | Varyant Grubu id

eval { 
    my $result = $api_instance->options_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, title => $title, option_group => $option_group);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OptionsApi->options_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **title** | **string**| Varyant başlığı | [optional] 
 **option_group** | **int**| Varyant Grubu id | [optional] 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **options_id_delete**
> options_id_delete(id => $id)

Varyant Silme

Kalıcı olarak ilgili Varyantı siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OptionsApi;
my $api_instance = WWW::SwaggerClient::OptionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Varyant nesnesinin id değeri

eval { 
    $api_instance->options_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling OptionsApi->options_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **options_id_get**
> Options options_id_get(id => $id)

Varyant Alma

İlgili Varyantı getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OptionsApi;
my $api_instance = WWW::SwaggerClient::OptionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Varyant nesnesinin id değeri

eval { 
    my $result = $api_instance->options_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OptionsApi->options_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant nesnesinin id değeri | 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **options_id_put**
> Options options_id_put(id => $id, options => $options)

Varyant Güncelleme

İlgili Varyantı günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OptionsApi;
my $api_instance = WWW::SwaggerClient::OptionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Varyant nesnesinin id değeri
my $options = WWW::SwaggerClient::Object::Options->new(); # Options |  nesnesi

eval { 
    my $result = $api_instance->options_id_put(id => $id, options => $options);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OptionsApi->options_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant nesnesinin id değeri | 
 **options** | [**Options**](Options.md)|  nesnesi | 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **options_post**
> Options options_post(options => $options)

Varyant Oluşturma

Yeni bir Varyant oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OptionsApi;
my $api_instance = WWW::SwaggerClient::OptionsApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $options = WWW::SwaggerClient::Object::Options->new(); # Options |  nesnesi

eval { 
    my $result = $api_instance->options_post(options => $options);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OptionsApi->options_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **options** | [**Options**](Options.md)|  nesnesi | 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

