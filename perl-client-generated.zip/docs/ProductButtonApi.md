# WWW::SwaggerClient::ProductButtonApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ProductButtonApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_buttons_get**](ProductButtonApi.md#product_buttons_get) | **GET** /product_buttons | Ürün ve Stok Butonu Listesi Alma
[**product_buttons_id_delete**](ProductButtonApi.md#product_buttons_id_delete) | **DELETE** /product_buttons/{id} | Ürün ve Stok Butonu Silme
[**product_buttons_id_get**](ProductButtonApi.md#product_buttons_id_get) | **GET** /product_buttons/{id} | Ürün ve Stok Butonu Alma
[**product_buttons_id_put**](ProductButtonApi.md#product_buttons_id_put) | **PUT** /product_buttons/{id} | Ürün ve Stok Butonu Güncelleme
[**product_buttons_post**](ProductButtonApi.md#product_buttons_post) | **POST** /product_buttons | Ürün ve Stok Butonu Oluşturma


# **product_buttons_get**
> ProductButton product_buttons_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, fast_shipping => $fast_shipping, same_day_shipping => $same_day_shipping, three_days_delivery => $three_days_delivery, five_days_delivery => $five_days_delivery, seven_days_delivery => $seven_days_delivery, free_shipping => $free_shipping, delivery_from_stock => $delivery_from_stock, pre_ordered_product => $pre_ordered_product, ask_stock => $ask_stock, campaigned_product => $campaigned_product, product => $product)

Ürün ve Stok Butonu Listesi Alma

Ürün ve Stok Butonu listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductButtonApi;
my $api_instance = WWW::SwaggerClient::ProductButtonApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $fast_shipping = 'fast_shipping_example'; # string | Hızlı Gönderi butonuna sahip ürünler<code>0</code><br><code>1</code>
my $same_day_shipping = 'same_day_shipping_example'; # string | Aynı Gün Kargo butonuna sahip ürünler<code>0</code><br><code>1</code>
my $three_days_delivery = 'three_days_delivery_example'; # string | 3 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
my $five_days_delivery = 'five_days_delivery_example'; # string | 5 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
my $seven_days_delivery = 'seven_days_delivery_example'; # string | 7 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
my $free_shipping = 'free_shipping_example'; # string | Kargo Bedava butonuna sahip ürünler<code>0</code><br><code>1</code>
my $delivery_from_stock = 'delivery_from_stock_example'; # string | Stoktan Teslim butonuna sahip ürünler<code>0</code><br><code>1</code>
my $pre_ordered_product = 'pre_ordered_product_example'; # string | Ön Siparişli Ürün butonuna sahip ürünler<code>0</code><br><code>1</code>
my $ask_stock = 'ask_stock_example'; # string | Stok Sorunuz butonuna sahip ürünler<code>0</code><br><code>1</code>
my $campaigned_product = 'campaigned_product_example'; # string | Kampanyalı Ürün butonuna sahip ürünler<code>0</code><br><code>1</code>
my $product = 56; # int | Ürün id

eval { 
    my $result = $api_instance->product_buttons_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, fast_shipping => $fast_shipping, same_day_shipping => $same_day_shipping, three_days_delivery => $three_days_delivery, five_days_delivery => $five_days_delivery, seven_days_delivery => $seven_days_delivery, free_shipping => $free_shipping, delivery_from_stock => $delivery_from_stock, pre_ordered_product => $pre_ordered_product, ask_stock => $ask_stock, campaigned_product => $campaigned_product, product => $product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductButtonApi->product_buttons_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **fast_shipping** | **string**| Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **same_day_shipping** | **string**| Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **three_days_delivery** | **string**| 3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **five_days_delivery** | **string**| 5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **seven_days_delivery** | **string**| 7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **free_shipping** | **string**| Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **delivery_from_stock** | **string**| Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **pre_ordered_product** | **string**| Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **ask_stock** | **string**| Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **campaigned_product** | **string**| Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **product** | **int**| Ürün id | [optional] 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_buttons_id_delete**
> product_buttons_id_delete(id => $id)

Ürün ve Stok Butonu Silme

Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductButtonApi;
my $api_instance = WWW::SwaggerClient::ProductButtonApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün ve Stok Butonu nesnesinin id değeri

eval { 
    $api_instance->product_buttons_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling ProductButtonApi->product_buttons_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_buttons_id_get**
> ProductButton product_buttons_id_get(id => $id)

Ürün ve Stok Butonu Alma

İlgili Ürün ve Stok Butonunu getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductButtonApi;
my $api_instance = WWW::SwaggerClient::ProductButtonApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün ve Stok Butonu nesnesinin id değeri

eval { 
    my $result = $api_instance->product_buttons_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductButtonApi->product_buttons_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_buttons_id_put**
> ProductButton product_buttons_id_put(id => $id, product_button => $product_button)

Ürün ve Stok Butonu Güncelleme

İlgili Ürün ve Stok Butonunu günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductButtonApi;
my $api_instance = WWW::SwaggerClient::ProductButtonApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün ve Stok Butonu nesnesinin id değeri
my $product_button = WWW::SwaggerClient::Object::ProductButton->new(); # ProductButton |  nesnesi

eval { 
    my $result = $api_instance->product_buttons_id_put(id => $id, product_button => $product_button);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductButtonApi->product_buttons_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün ve Stok Butonu nesnesinin id değeri | 
 **product_button** | [**ProductButton**](ProductButton.md)|  nesnesi | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_buttons_post**
> ProductButton product_buttons_post(product_button => $product_button)

Ürün ve Stok Butonu Oluşturma

Yeni bir Ürün ve Stok Butonu oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductButtonApi;
my $api_instance = WWW::SwaggerClient::ProductButtonApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $product_button = WWW::SwaggerClient::Object::ProductButton->new(); # ProductButton |  nesnesi

eval { 
    my $result = $api_instance->product_buttons_post(product_button => $product_button);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductButtonApi->product_buttons_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_button** | [**ProductButton**](ProductButton.md)|  nesnesi | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

