# WWW::SwaggerClient::Object::ShopUserlevels

## Load the model package
```perl
use WWW::SwaggerClient::Object::ShopUserlevels;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Yönetici grubu nesnesinin benzersiz rakamsal kimlik değeri. | [optional] 
**label** | **string** | Yönetici grubu ismi. | [optional] 
**roles** | **string** | Yönetici grubunun sahip olduğu roller. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


