# WWW::SwaggerClient::ExtraInfoApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ExtraInfoApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extra_infos_get**](ExtraInfoApi.md#extra_infos_get) | **GET** /extra_infos | Ek Bilgi Listesi Alma
[**extra_infos_id_delete**](ExtraInfoApi.md#extra_infos_id_delete) | **DELETE** /extra_infos/{id} | Ek Bilgi Silme
[**extra_infos_id_get**](ExtraInfoApi.md#extra_infos_id_get) | **GET** /extra_infos/{id} | Ek Bilgi Alma
[**extra_infos_id_put**](ExtraInfoApi.md#extra_infos_id_put) | **PUT** /extra_infos/{id} | Ek Bilgi Güncelleme
[**extra_infos_post**](ExtraInfoApi.md#extra_infos_post) | **POST** /extra_infos | Ek Bilgi Oluşturma


# **extra_infos_get**
> ExtraInfo extra_infos_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name)

Ek Bilgi Listesi Alma

Ek Bilgi listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ExtraInfoApi;
my $api_instance = WWW::SwaggerClient::ExtraInfoApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $name = 'name_example'; # string | Ek Bilgi adı

eval { 
    my $result = $api_instance->extra_infos_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ExtraInfoApi->extra_infos_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **string**| Ek Bilgi adı | [optional] 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_infos_id_delete**
> extra_infos_id_delete(id => $id)

Ek Bilgi Silme

Kalıcı olarak ilgili Ek Bilgiyi siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ExtraInfoApi;
my $api_instance = WWW::SwaggerClient::ExtraInfoApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ek Bilgi nesnesinin id değeri

eval { 
    $api_instance->extra_infos_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling ExtraInfoApi->extra_infos_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_infos_id_get**
> ExtraInfo extra_infos_id_get(id => $id)

Ek Bilgi Alma

İlgili Ek Bilgiyi getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ExtraInfoApi;
my $api_instance = WWW::SwaggerClient::ExtraInfoApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ek Bilgi nesnesinin id değeri

eval { 
    my $result = $api_instance->extra_infos_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ExtraInfoApi->extra_infos_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi nesnesinin id değeri | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_infos_id_put**
> ExtraInfo extra_infos_id_put(id => $id, extra_info => $extra_info)

Ek Bilgi Güncelleme

İlgili Ek Bilgiyi günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ExtraInfoApi;
my $api_instance = WWW::SwaggerClient::ExtraInfoApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ek Bilgi nesnesinin id değeri
my $extra_info = WWW::SwaggerClient::Object::ExtraInfo->new(); # ExtraInfo |  nesnesi

eval { 
    my $result = $api_instance->extra_infos_id_put(id => $id, extra_info => $extra_info);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ExtraInfoApi->extra_infos_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi nesnesinin id değeri | 
 **extra_info** | [**ExtraInfo**](ExtraInfo.md)|  nesnesi | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_infos_post**
> ExtraInfo extra_infos_post(extra_info => $extra_info)

Ek Bilgi Oluşturma

Yeni bir Ek Bilgi oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ExtraInfoApi;
my $api_instance = WWW::SwaggerClient::ExtraInfoApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $extra_info = WWW::SwaggerClient::Object::ExtraInfo->new(); # ExtraInfo |  nesnesi

eval { 
    my $result = $api_instance->extra_infos_post(extra_info => $extra_info);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ExtraInfoApi->extra_infos_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extra_info** | [**ExtraInfo**](ExtraInfo.md)|  nesnesi | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

