# WWW::SwaggerClient::OptionToProductApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::OptionToProductApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**option_to_products_get**](OptionToProductApi.md#option_to_products_get) | **GET** /option_to_products | Varyant Ürün Bağı Listesi Alma
[**option_to_products_id_delete**](OptionToProductApi.md#option_to_products_id_delete) | **DELETE** /option_to_products/{id} | Varyant Ürün Bağı Silme
[**option_to_products_id_get**](OptionToProductApi.md#option_to_products_id_get) | **GET** /option_to_products/{id} | Varyant Ürün Bağı Alma
[**option_to_products_id_put**](OptionToProductApi.md#option_to_products_id_put) | **PUT** /option_to_products/{id} | Varyant Ürün Bağı Güncelleme
[**option_to_products_post**](OptionToProductApi.md#option_to_products_post) | **POST** /option_to_products | Varyant Ürün Bağı Oluşturma


# **option_to_products_get**
> OptionToProduct option_to_products_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, product => $product, option_group => $option_group, option => $option, parent_product_id => $parent_product_id)

Varyant Ürün Bağı Listesi Alma

Varyant Ürün Bağı listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OptionToProductApi;
my $api_instance = WWW::SwaggerClient::OptionToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $product = 56; # int | Ürün id
my $option_group = 56; # int | Varyant Grubu id
my $option = 56; # int | Varyant id
my $parent_product_id = 56; # int | Ana Ürün id

eval { 
    my $result = $api_instance->option_to_products_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, product => $product, option_group => $option_group, option => $option, parent_product_id => $parent_product_id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OptionToProductApi->option_to_products_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **product** | **int**| Ürün id | [optional] 
 **option_group** | **int**| Varyant Grubu id | [optional] 
 **option** | **int**| Varyant id | [optional] 
 **parent_product_id** | **int**| Ana Ürün id | [optional] 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **option_to_products_id_delete**
> option_to_products_id_delete(id => $id)

Varyant Ürün Bağı Silme

Kalıcı olarak ilgili Varyant Ürün Bağını siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OptionToProductApi;
my $api_instance = WWW::SwaggerClient::OptionToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Varyant Ürün Bağı nesnesinin id değeri

eval { 
    $api_instance->option_to_products_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling OptionToProductApi->option_to_products_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **option_to_products_id_get**
> OptionToProduct option_to_products_id_get(id => $id)

Varyant Ürün Bağı Alma

İlgili Varyant Ürün Bağını getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OptionToProductApi;
my $api_instance = WWW::SwaggerClient::OptionToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Varyant Ürün Bağı nesnesinin id değeri

eval { 
    my $result = $api_instance->option_to_products_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OptionToProductApi->option_to_products_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant Ürün Bağı nesnesinin id değeri | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **option_to_products_id_put**
> OptionToProduct option_to_products_id_put(id => $id, option_to_product => $option_to_product)

Varyant Ürün Bağı Güncelleme

İlgili Varyant Ürün Bağını günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OptionToProductApi;
my $api_instance = WWW::SwaggerClient::OptionToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Varyant Ürün Bağı nesnesinin id değeri
my $option_to_product = WWW::SwaggerClient::Object::OptionToProduct->new(); # OptionToProduct |  nesnesi

eval { 
    my $result = $api_instance->option_to_products_id_put(id => $id, option_to_product => $option_to_product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OptionToProductApi->option_to_products_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant Ürün Bağı nesnesinin id değeri | 
 **option_to_product** | [**OptionToProduct**](OptionToProduct.md)|  nesnesi | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **option_to_products_post**
> OptionToProduct option_to_products_post(option_to_product => $option_to_product)

Varyant Ürün Bağı Oluşturma

Yeni bir Varyant Ürün Bağı oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OptionToProductApi;
my $api_instance = WWW::SwaggerClient::OptionToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $option_to_product = WWW::SwaggerClient::Object::OptionToProduct->new(); # OptionToProduct |  nesnesi

eval { 
    my $result = $api_instance->option_to_products_post(option_to_product => $option_to_product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OptionToProductApi->option_to_products_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **option_to_product** | [**OptionToProduct**](OptionToProduct.md)|  nesnesi | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

