# WWW::SwaggerClient::PaymentGatewayApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::PaymentGatewayApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**payment_gateways_get**](PaymentGatewayApi.md#payment_gateways_get) | **GET** /payment_gateways | Ödeme Kanalı Listesi Alma
[**payment_gateways_id_get**](PaymentGatewayApi.md#payment_gateways_id_get) | **GET** /payment_gateways/{id} | Ödeme Kanalı Alma


# **payment_gateways_get**
> PaymentGateway payment_gateways_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, code => $code, name => $name)

Ödeme Kanalı Listesi Alma

Ödeme Kanalı listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PaymentGatewayApi;
my $api_instance = WWW::SwaggerClient::PaymentGatewayApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $code = 'code_example'; # string | Ödeme kanalı notu
my $name = 'name_example'; # string | Ödeme kanalı adı

eval { 
    my $result = $api_instance->payment_gateways_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, code => $code, name => $name);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling PaymentGatewayApi->payment_gateways_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **code** | **string**| Ödeme kanalı notu | [optional] 
 **name** | **string**| Ödeme kanalı adı | [optional] 

### Return type

[**PaymentGateway**](PaymentGateway.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **payment_gateways_id_get**
> PaymentGateway payment_gateways_id_get(id => $id)

Ödeme Kanalı Alma

İlgili Ödeme Kanalını getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PaymentGatewayApi;
my $api_instance = WWW::SwaggerClient::PaymentGatewayApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ödeme Kanalı nesnesinin id değeri

eval { 
    my $result = $api_instance->payment_gateways_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling PaymentGatewayApi->payment_gateways_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ödeme Kanalı nesnesinin id değeri | 

### Return type

[**PaymentGateway**](PaymentGateway.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

