# WWW::SwaggerClient::InstallmentRateApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::InstallmentRateApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**installment_rates_get**](InstallmentRateApi.md#installment_rates_get) | **GET** /installment_rates | Taksit Oranı Listesi Alma
[**installment_rates_id_get**](InstallmentRateApi.md#installment_rates_id_get) | **GET** /installment_rates/{id} | Taksit Oranı Alma


# **installment_rates_get**
> InstallmentRate installment_rates_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, payment_gateway => $payment_gateway)

Taksit Oranı Listesi Alma

Taksit Oranı listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstallmentRateApi;
my $api_instance = WWW::SwaggerClient::InstallmentRateApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $payment_gateway = 56; # int | Ödeme Kanalı id

eval { 
    my $result = $api_instance->installment_rates_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, payment_gateway => $payment_gateway);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstallmentRateApi->installment_rates_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **payment_gateway** | **int**| Ödeme Kanalı id | [optional] 

### Return type

[**InstallmentRate**](InstallmentRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **installment_rates_id_get**
> InstallmentRate installment_rates_id_get(id => $id)

Taksit Oranı Alma

İlgili Taksit Oranını getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::InstallmentRateApi;
my $api_instance = WWW::SwaggerClient::InstallmentRateApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Taksit Oranı nesnesinin id değeri

eval { 
    my $result = $api_instance->installment_rates_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling InstallmentRateApi->installment_rates_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Taksit Oranı nesnesinin id değeri | 

### Return type

[**InstallmentRate**](InstallmentRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

