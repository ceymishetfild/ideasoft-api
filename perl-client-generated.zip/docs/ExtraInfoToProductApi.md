# WWW::SwaggerClient::ExtraInfoToProductApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ExtraInfoToProductApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extra_info_to_products_get**](ExtraInfoToProductApi.md#extra_info_to_products_get) | **GET** /extra_info_to_products | Ek Bilgi Ürün Bağı Listesi Alma
[**extra_info_to_products_id_delete**](ExtraInfoToProductApi.md#extra_info_to_products_id_delete) | **DELETE** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Silme
[**extra_info_to_products_id_get**](ExtraInfoToProductApi.md#extra_info_to_products_id_get) | **GET** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Alma
[**extra_info_to_products_id_put**](ExtraInfoToProductApi.md#extra_info_to_products_id_put) | **PUT** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Güncelleme
[**extra_info_to_products_post**](ExtraInfoToProductApi.md#extra_info_to_products_post) | **POST** /extra_info_to_products | Ek Bilgi Ürün Bağı Oluşturma


# **extra_info_to_products_get**
> ExtraInfoToProduct extra_info_to_products_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, extra_info => $extra_info, product => $product)

Ek Bilgi Ürün Bağı Listesi Alma

Ek Bilgi Ürün Bağı listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ExtraInfoToProductApi;
my $api_instance = WWW::SwaggerClient::ExtraInfoToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $extra_info = 56; # int | Ek bilgi id
my $product = 56; # int | Ürün id

eval { 
    my $result = $api_instance->extra_info_to_products_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, extra_info => $extra_info, product => $product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ExtraInfoToProductApi->extra_info_to_products_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **extra_info** | **int**| Ek bilgi id | [optional] 
 **product** | **int**| Ürün id | [optional] 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_info_to_products_id_delete**
> extra_info_to_products_id_delete(id => $id)

Ek Bilgi Ürün Bağı Silme

Kalıcı olarak ilgili Ek Bilgi Ürün Bağını siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ExtraInfoToProductApi;
my $api_instance = WWW::SwaggerClient::ExtraInfoToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ek Bilgi Ürün Bağı nesnesinin id değeri

eval { 
    $api_instance->extra_info_to_products_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling ExtraInfoToProductApi->extra_info_to_products_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_info_to_products_id_get**
> ExtraInfoToProduct extra_info_to_products_id_get(id => $id)

Ek Bilgi Ürün Bağı Alma

İlgili Ek Bilgi Ürün Bağını getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ExtraInfoToProductApi;
my $api_instance = WWW::SwaggerClient::ExtraInfoToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ek Bilgi Ürün Bağı nesnesinin id değeri

eval { 
    my $result = $api_instance->extra_info_to_products_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ExtraInfoToProductApi->extra_info_to_products_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_info_to_products_id_put**
> ExtraInfoToProduct extra_info_to_products_id_put(id => $id, extra_info_to_product => $extra_info_to_product)

Ek Bilgi Ürün Bağı Güncelleme

İlgili Ek Bilgi Ürün Bağını günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ExtraInfoToProductApi;
my $api_instance = WWW::SwaggerClient::ExtraInfoToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ek Bilgi Ürün Bağı nesnesinin id değeri
my $extra_info_to_product = WWW::SwaggerClient::Object::ExtraInfoToProduct->new(); # ExtraInfoToProduct |  nesnesi

eval { 
    my $result = $api_instance->extra_info_to_products_id_put(id => $id, extra_info_to_product => $extra_info_to_product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ExtraInfoToProductApi->extra_info_to_products_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 
 **extra_info_to_product** | [**ExtraInfoToProduct**](ExtraInfoToProduct.md)|  nesnesi | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_info_to_products_post**
> ExtraInfoToProduct extra_info_to_products_post(extra_info_to_product => $extra_info_to_product)

Ek Bilgi Ürün Bağı Oluşturma

Yeni bir Ek Bilgi Ürün Bağı oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ExtraInfoToProductApi;
my $api_instance = WWW::SwaggerClient::ExtraInfoToProductApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $extra_info_to_product = WWW::SwaggerClient::Object::ExtraInfoToProduct->new(); # ExtraInfoToProduct |  nesnesi

eval { 
    my $result = $api_instance->extra_info_to_products_post(extra_info_to_product => $extra_info_to_product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ExtraInfoToProductApi->extra_info_to_products_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extra_info_to_product** | [**ExtraInfoToProduct**](ExtraInfoToProduct.md)|  nesnesi | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

