# WWW::SwaggerClient::DistributorApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::DistributorApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**distributors_get**](DistributorApi.md#distributors_get) | **GET** /distributors | Distribütör Listesi Alma
[**distributors_id_delete**](DistributorApi.md#distributors_id_delete) | **DELETE** /distributors/{id} | Distribütör Silme
[**distributors_id_get**](DistributorApi.md#distributors_id_get) | **GET** /distributors/{id} | Distribütör Alma
[**distributors_id_put**](DistributorApi.md#distributors_id_put) | **PUT** /distributors/{id} | Distribütör Güncelleme
[**distributors_post**](DistributorApi.md#distributors_post) | **POST** /distributors | Distribütör Oluşturma


# **distributors_get**
> Distributor distributors_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name, email => $email, phone => $phone, contact_person => $contact_person)

Distribütör Listesi Alma

Distribütör listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::DistributorApi;
my $api_instance = WWW::SwaggerClient::DistributorApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $name = 'name_example'; # string | Distribütör adı.
my $email = 'email_example'; # string | Distribütör email adresi
my $phone = 'phone_example'; # string | Distribütör telefonu
my $contact_person = 'contact_person_example'; # string | Distribütör sorumlu kişi

eval { 
    my $result = $api_instance->distributors_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name, email => $email, phone => $phone, contact_person => $contact_person);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling DistributorApi->distributors_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **string**| Distribütör adı. | [optional] 
 **email** | **string**| Distribütör email adresi | [optional] 
 **phone** | **string**| Distribütör telefonu | [optional] 
 **contact_person** | **string**| Distribütör sorumlu kişi | [optional] 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributors_id_delete**
> distributors_id_delete(id => $id)

Distribütör Silme

Kalıcı olarak ilgili Distribütörü siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::DistributorApi;
my $api_instance = WWW::SwaggerClient::DistributorApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Distribütör nesnesinin id değeri

eval { 
    $api_instance->distributors_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling DistributorApi->distributors_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Distribütör nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributors_id_get**
> Distributor distributors_id_get(id => $id)

Distribütör Alma

İlgili Distribütörü getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::DistributorApi;
my $api_instance = WWW::SwaggerClient::DistributorApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Distribütör nesnesinin id değeri

eval { 
    my $result = $api_instance->distributors_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling DistributorApi->distributors_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Distribütör nesnesinin id değeri | 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributors_id_put**
> Distributor distributors_id_put(id => $id, distributor => $distributor)

Distribütör Güncelleme

İlgili Distribütörü günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::DistributorApi;
my $api_instance = WWW::SwaggerClient::DistributorApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Distribütör nesnesinin id değeri
my $distributor = WWW::SwaggerClient::Object::Distributor->new(); # Distributor |  nesnesi

eval { 
    my $result = $api_instance->distributors_id_put(id => $id, distributor => $distributor);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling DistributorApi->distributors_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Distribütör nesnesinin id değeri | 
 **distributor** | [**Distributor**](Distributor.md)|  nesnesi | 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributors_post**
> Distributor distributors_post(distributor => $distributor)

Distribütör Oluşturma

Yeni bir Distribütör oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::DistributorApi;
my $api_instance = WWW::SwaggerClient::DistributorApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $distributor = WWW::SwaggerClient::Object::Distributor->new(); # Distributor |  nesnesi

eval { 
    my $result = $api_instance->distributors_post(distributor => $distributor);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling DistributorApi->distributors_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **distributor** | [**Distributor**](Distributor.md)|  nesnesi | 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

