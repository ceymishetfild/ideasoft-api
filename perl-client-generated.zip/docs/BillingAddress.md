# WWW::SwaggerClient::Object::BillingAddress

## Load the model package
```perl
use WWW::SwaggerClient::Object::BillingAddress;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sipariş adresi nesnesi kimlik değeri. | [optional] 
**firstname** | **string** | Müşterinin ismi. | 
**surname** | **string** | Müşterinin soy ismi. | 
**country** | **string** | Müşterinin ülke bilgisi. | 
**location** | **string** | Müşterinin şehir bilgisi. | 
**sub_location** | **string** | Müşterinin ilçe bilgisi. | [optional] 
**address** | **string** | Müşterinin adres bilgisi. | 
**phone_number** | **string** | Müşterinin telefon numarası. | 
**mobile_phone_number** | **string** | Müşterinin mobil telefon numarası. | [optional] 
**order** | [**Order**](Order.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


