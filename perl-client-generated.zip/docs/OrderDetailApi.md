# WWW::SwaggerClient::OrderDetailApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::OrderDetailApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**order_details_get**](OrderDetailApi.md#order_details_get) | **GET** /order_details | Sipariş Detayı Listesi Alma
[**order_details_id_delete**](OrderDetailApi.md#order_details_id_delete) | **DELETE** /order_details/{id} | Sipariş Detayı Silme
[**order_details_id_get**](OrderDetailApi.md#order_details_id_get) | **GET** /order_details/{id} | Sipariş Detayı Alma
[**order_details_id_put**](OrderDetailApi.md#order_details_id_put) | **PUT** /order_details/{id} | Sipariş Detayı Güncelleme
[**order_details_post**](OrderDetailApi.md#order_details_post) | **POST** /order_details | Sipariş Detayı Oluşturma


# **order_details_get**
> OrderDetail order_details_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, order => $order)

Sipariş Detayı Listesi Alma

Sipariş Detayı listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderDetailApi;
my $api_instance = WWW::SwaggerClient::OrderDetailApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $order = 56; # int | Sipariş id

eval { 
    my $result = $api_instance->order_details_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, order => $order);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderDetailApi->order_details_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **int**| Sipariş id | [optional] 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_details_id_delete**
> order_details_id_delete(id => $id)

Sipariş Detayı Silme

Kalıcı olarak ilgili Sipariş Detayı siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderDetailApi;
my $api_instance = WWW::SwaggerClient::OrderDetailApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş Detayı nesnesinin id değeri

eval { 
    $api_instance->order_details_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling OrderDetailApi->order_details_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Detayı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_details_id_get**
> OrderDetail order_details_id_get(id => $id)

Sipariş Detayı Alma

İlgili Sipariş Detayı getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderDetailApi;
my $api_instance = WWW::SwaggerClient::OrderDetailApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş Detayı nesnesinin id değeri

eval { 
    my $result = $api_instance->order_details_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderDetailApi->order_details_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Detayı nesnesinin id değeri | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_details_id_put**
> OrderDetail order_details_id_put(id => $id, order_detail => $order_detail)

Sipariş Detayı Güncelleme

İlgili Sipariş Detayı günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderDetailApi;
my $api_instance = WWW::SwaggerClient::OrderDetailApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş Detayı nesnesinin id değeri
my $order_detail = WWW::SwaggerClient::Object::OrderDetail->new(); # OrderDetail | OrderDetail nesnesi

eval { 
    my $result = $api_instance->order_details_id_put(id => $id, order_detail => $order_detail);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderDetailApi->order_details_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Detayı nesnesinin id değeri | 
 **order_detail** | [**OrderDetail**](OrderDetail.md)| OrderDetail nesnesi | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_details_post**
> OrderDetail order_details_post(order_detail => $order_detail)

Sipariş Detayı Oluşturma

Yeni bir Sipariş Detayı oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderDetailApi;
my $api_instance = WWW::SwaggerClient::OrderDetailApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $order_detail = WWW::SwaggerClient::Object::OrderDetail->new(); # OrderDetail | OrderDetail nesnesi

eval { 
    my $result = $api_instance->order_details_post(order_detail => $order_detail);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderDetailApi->order_details_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_detail** | [**OrderDetail**](OrderDetail.md)| OrderDetail nesnesi | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

