# WWW::SwaggerClient::ProductDetailApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ProductDetailApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_details_get**](ProductDetailApi.md#product_details_get) | **GET** /product_details | Ürün Detay Listesi Alma
[**product_details_id_delete**](ProductDetailApi.md#product_details_id_delete) | **DELETE** /product_details/{id} | Ürün Detay Silme
[**product_details_id_get**](ProductDetailApi.md#product_details_id_get) | **GET** /product_details/{id} | Ürün Detay Alma
[**product_details_id_put**](ProductDetailApi.md#product_details_id_put) | **PUT** /product_details/{id} | Ürün Detay Güncelleme
[**product_details_post**](ProductDetailApi.md#product_details_post) | **POST** /product_details | Ürün Detay Oluşturma


# **product_details_get**
> ProductDetail product_details_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, sku => $sku)

Ürün Detay Listesi Alma

Ürün Detay listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductDetailApi;
my $api_instance = WWW::SwaggerClient::ProductDetailApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $sku = 'sku_example'; # string | Ürün stok kodu

eval { 
    my $result = $api_instance->product_details_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, sku => $sku);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductDetailApi->product_details_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **sku** | **string**| Ürün stok kodu | [optional] 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_details_id_delete**
> product_details_id_delete(id => $id)

Ürün Detay Silme

Kalıcı olarak ilgili Ürün Detayını siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductDetailApi;
my $api_instance = WWW::SwaggerClient::ProductDetailApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Detay nesnesinin id değeri

eval { 
    $api_instance->product_details_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling ProductDetailApi->product_details_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Detay nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_details_id_get**
> ProductDetail product_details_id_get(id => $id)

Ürün Detay Alma

İlgili Ürün Detayını getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductDetailApi;
my $api_instance = WWW::SwaggerClient::ProductDetailApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Detay nesnesinin id değeri

eval { 
    my $result = $api_instance->product_details_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductDetailApi->product_details_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Detay nesnesinin id değeri | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_details_id_put**
> ProductDetail product_details_id_put(id => $id, product_detail => $product_detail)

Ürün Detay Güncelleme

İlgili Ürün Detayını günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductDetailApi;
my $api_instance = WWW::SwaggerClient::ProductDetailApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Detay nesnesinin id değeri
my $product_detail = WWW::SwaggerClient::Object::ProductDetail->new(); # ProductDetail |  nesnesi

eval { 
    my $result = $api_instance->product_details_id_put(id => $id, product_detail => $product_detail);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductDetailApi->product_details_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Detay nesnesinin id değeri | 
 **product_detail** | [**ProductDetail**](ProductDetail.md)|  nesnesi | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_details_post**
> ProductDetail product_details_post(product_detail => $product_detail)

Ürün Detay Oluşturma

Yeni bir Ürün Detay oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductDetailApi;
my $api_instance = WWW::SwaggerClient::ProductDetailApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $product_detail = WWW::SwaggerClient::Object::ProductDetail->new(); # ProductDetail |  nesnesi

eval { 
    my $result = $api_instance->product_details_post(product_detail => $product_detail);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductDetailApi->product_details_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_detail** | [**ProductDetail**](ProductDetail.md)|  nesnesi | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

