# WWW::SwaggerClient::Object::ProductDetail

## Load the model package
```perl
use WWW::SwaggerClient::Object::ProductDetail;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ürün detayı nesnesi kimlik değeri. | [optional] 
**sku** | **string** | Ürünün stok kodu. | [optional] 
**details** | **string** | Detay bilgisi. | [optional] 
**extra_details** | **string** | Ürün ekstra detaylı bilgi. | [optional] 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


