# WWW::SwaggerClient::ShippingRateApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ShippingRateApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipping_rates_get**](ShippingRateApi.md#shipping_rates_get) | **GET** /shipping_rates | Kargo Oranı Listesi Alma
[**shipping_rates_id_delete**](ShippingRateApi.md#shipping_rates_id_delete) | **DELETE** /shipping_rates/{id} | Kargo Oranı Silme
[**shipping_rates_id_get**](ShippingRateApi.md#shipping_rates_id_get) | **GET** /shipping_rates/{id} | Kargo Oranı Alma
[**shipping_rates_id_put**](ShippingRateApi.md#shipping_rates_id_put) | **PUT** /shipping_rates/{id} | Kargo Oranı Güncelleme
[**shipping_rates_post**](ShippingRateApi.md#shipping_rates_post) | **POST** /shipping_rates | Kargo Oranı Oluşturma


# **shipping_rates_get**
> ShippingRate shipping_rates_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, shipping_company => $shipping_company, region => $region)

Kargo Oranı Listesi Alma

Kargo Oranı listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ShippingRateApi;
my $api_instance = WWW::SwaggerClient::ShippingRateApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $shipping_company = 56; # int | Kargo firması id
my $region = 56; # int | Bölge id

eval { 
    my $result = $api_instance->shipping_rates_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, shipping_company => $shipping_company, region => $region);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ShippingRateApi->shipping_rates_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **shipping_company** | **int**| Kargo firması id | [optional] 
 **region** | **int**| Bölge id | [optional] 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipping_rates_id_delete**
> shipping_rates_id_delete(id => $id)

Kargo Oranı Silme

Kalıcı olarak ilgili Kargo Oranını siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ShippingRateApi;
my $api_instance = WWW::SwaggerClient::ShippingRateApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Kargo Oranı nesnesinin id değeri

eval { 
    $api_instance->shipping_rates_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling ShippingRateApi->shipping_rates_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kargo Oranı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipping_rates_id_get**
> ShippingRate shipping_rates_id_get(id => $id)

Kargo Oranı Alma

İlgili Kargo Oranını getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ShippingRateApi;
my $api_instance = WWW::SwaggerClient::ShippingRateApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Kargo Oranı nesnesinin id değeri

eval { 
    my $result = $api_instance->shipping_rates_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ShippingRateApi->shipping_rates_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kargo Oranı nesnesinin id değeri | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipping_rates_id_put**
> ShippingRate shipping_rates_id_put(id => $id, shipping_rate => $shipping_rate)

Kargo Oranı Güncelleme

İlgili Kargo Oranını günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ShippingRateApi;
my $api_instance = WWW::SwaggerClient::ShippingRateApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Kargo Oranı nesnesinin id değeri
my $shipping_rate = WWW::SwaggerClient::Object::ShippingRate->new(); # ShippingRate |  nesnesi

eval { 
    my $result = $api_instance->shipping_rates_id_put(id => $id, shipping_rate => $shipping_rate);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ShippingRateApi->shipping_rates_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kargo Oranı nesnesinin id değeri | 
 **shipping_rate** | [**ShippingRate**](ShippingRate.md)|  nesnesi | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipping_rates_post**
> ShippingRate shipping_rates_post(shipping_rate => $shipping_rate)

Kargo Oranı Oluşturma

Yeni bir Kargo Oranı oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ShippingRateApi;
my $api_instance = WWW::SwaggerClient::ShippingRateApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $shipping_rate = WWW::SwaggerClient::Object::ShippingRate->new(); # ShippingRate |  nesnesi

eval { 
    my $result = $api_instance->shipping_rates_post(shipping_rate => $shipping_rate);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ShippingRateApi->shipping_rates_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipping_rate** | [**ShippingRate**](ShippingRate.md)|  nesnesi | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

