# WWW::SwaggerClient::PaymentApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::PaymentApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**payments_get**](PaymentApi.md#payments_get) | **GET** /payments | Ödeme Listesi Alma
[**payments_id_delete**](PaymentApi.md#payments_id_delete) | **DELETE** /payments/{id} | Ödeme Silme
[**payments_id_get**](PaymentApi.md#payments_id_get) | **GET** /payments/{id} | Ödeme Alma
[**payments_id_put**](PaymentApi.md#payments_id_put) | **PUT** /payments/{id} | Ödeme Güncelleme
[**payments_post**](PaymentApi.md#payments_post) | **POST** /payments | Ödeme Oluşturma


# **payments_get**
> Payment payments_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, transaction_id => $transaction_id, member_email => $member_email, member => $member, status => $status, payment_type_name => $payment_type_name, start_date => $start_date, end_date => $end_date)

Ödeme Listesi Alma

Ödeme listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PaymentApi;
my $api_instance = WWW::SwaggerClient::PaymentApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $transaction_id = 'transaction_id_example'; # string | İşlem id.
my $member_email = 'member_email_example'; # string | Müşteri e-mail.
my $member = 56; # int | Üye id
my $status = 'status_example'; # string | Status şu değerleri alabilir: <br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br><code>deleted</code> : Silindi<br><code>failed</code> : Hatalı Ödemeler<br><code>in_transaction</code> : Sonuçlanmamış Ödemeler
my $payment_type_name = 'payment_type_name_example'; # string | Ödeme tipi adı şu değerleri alabilir: <br><code>Havale</code><br><code>Özel Ödeme Sistemi</code><br><code>Kredi Kartı</code><br><code>Paypal</code><br><code>GarantiPay</code><br><code>Mail Order</code><br><code>BKM Express</code><br><code>Kapıda Ödeme Nakit</code><br><code>Kapıda Ödeme Kredi Kartı</code>
my $start_date = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | createdAt değeri için başlangıç tarihi
my $end_date = 'end_date_example'; # string | createdAt değeri için bitiş tarihi

eval { 
    my $result = $api_instance->payments_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, transaction_id => $transaction_id, member_email => $member_email, member => $member, status => $status, payment_type_name => $payment_type_name, start_date => $start_date, end_date => $end_date);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling PaymentApi->payments_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **transaction_id** | **string**| İşlem id. | [optional] 
 **member_email** | **string**| Müşteri e-mail. | [optional] 
 **member** | **int**| Üye id | [optional] 
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler | [optional] 
 **payment_type_name** | **string**| Ödeme tipi adı şu değerleri alabilir: &lt;br&gt;&lt;code&gt;Havale&lt;/code&gt;&lt;br&gt;&lt;code&gt;Özel Ödeme Sistemi&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kredi Kartı&lt;/code&gt;&lt;br&gt;&lt;code&gt;Paypal&lt;/code&gt;&lt;br&gt;&lt;code&gt;GarantiPay&lt;/code&gt;&lt;br&gt;&lt;code&gt;Mail Order&lt;/code&gt;&lt;br&gt;&lt;code&gt;BKM Express&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kapıda Ödeme Nakit&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kapıda Ödeme Kredi Kartı&lt;/code&gt; | [optional] 
 **start_date** | **DateTime**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional] 

### Return type

[**Payment**](Payment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **payments_id_delete**
> payments_id_delete(id => $id)

Ödeme Silme

Kalıcı olarak ilgili Ödemeyi siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PaymentApi;
my $api_instance = WWW::SwaggerClient::PaymentApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ödeme nesnesinin id değeri

eval { 
    $api_instance->payments_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling PaymentApi->payments_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ödeme nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **payments_id_get**
> Payment payments_id_get(id => $id)

Ödeme Alma

İlgili Ödemeyi getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PaymentApi;
my $api_instance = WWW::SwaggerClient::PaymentApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ödeme nesnesinin id değeri

eval { 
    my $result = $api_instance->payments_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling PaymentApi->payments_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ödeme nesnesinin id değeri | 

### Return type

[**Payment**](Payment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **payments_id_put**
> Payment payments_id_put(id => $id, payment => $payment)

Ödeme Güncelleme

İlgili Ödemeyi günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PaymentApi;
my $api_instance = WWW::SwaggerClient::PaymentApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ödeme nesnesinin id değeri
my $payment = WWW::SwaggerClient::Object::Payment->new(); # Payment | Payment nesnesi

eval { 
    my $result = $api_instance->payments_id_put(id => $id, payment => $payment);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling PaymentApi->payments_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ödeme nesnesinin id değeri | 
 **payment** | [**Payment**](Payment.md)| Payment nesnesi | 

### Return type

[**Payment**](Payment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **payments_post**
> Payment payments_post(payment => $payment)

Ödeme Oluşturma

Yeni bir Ödeme oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PaymentApi;
my $api_instance = WWW::SwaggerClient::PaymentApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $payment = WWW::SwaggerClient::Object::Payment->new(); # Payment | Payment nesnesi

eval { 
    my $result = $api_instance->payments_post(payment => $payment);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling PaymentApi->payments_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **payment** | [**Payment**](Payment.md)| Payment nesnesi | 

### Return type

[**Payment**](Payment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

