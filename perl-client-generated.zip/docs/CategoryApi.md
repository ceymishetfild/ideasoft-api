# WWW::SwaggerClient::CategoryApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::CategoryApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**categories_get**](CategoryApi.md#categories_get) | **GET** /categories | Kategori Listesi Alma
[**categories_id_delete**](CategoryApi.md#categories_id_delete) | **DELETE** /categories/{id} | Kategori Silme
[**categories_id_get**](CategoryApi.md#categories_id_get) | **GET** /categories/{id} | Kategori Alma
[**categories_id_put**](CategoryApi.md#categories_id_put) | **PUT** /categories/{id} | Kategori Güncelleme
[**categories_post**](CategoryApi.md#categories_post) | **POST** /categories | Kategori Oluşturma


# **categories_get**
> Category categories_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name, status => $status, distributor => $distributor, parent => $parent, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at)

Kategori Listesi Alma

Kategori listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::CategoryApi;
my $api_instance = WWW::SwaggerClient::CategoryApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $name = 'name_example'; # string | Kategori adı
my $status = 'status_example'; # string | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
my $distributor = 'distributor_example'; # string | Kategori Distribütör
my $parent = 56; # int | Üst kategori id
my $start_date = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | createdAt değeri için başlangıç tarihi
my $end_date = 'end_date_example'; # string | createdAt değeri için bitiş tarihi
my $start_updated_at = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | updatedAt değeri için başlangıç tarihi
my $end_updated_at = 'end_updated_at_example'; # string | updatedAt değeri için bitiş tarihi

eval { 
    my $result = $api_instance->categories_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name, status => $status, distributor => $distributor, parent => $parent, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CategoryApi->categories_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **string**| Kategori adı | [optional] 
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **distributor** | **string**| Kategori Distribütör | [optional] 
 **parent** | **int**| Üst kategori id | [optional] 
 **start_date** | **DateTime**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **DateTime**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Category**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **categories_id_delete**
> categories_id_delete(id => $id)

Kategori Silme

Kalıcı olarak ilgili Kategoriyi siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::CategoryApi;
my $api_instance = WWW::SwaggerClient::CategoryApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Kategori nesnesinin id değeri

eval { 
    $api_instance->categories_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling CategoryApi->categories_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kategori nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **categories_id_get**
> Category categories_id_get(id => $id)

Kategori Alma

İlgili Kategoriyi getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::CategoryApi;
my $api_instance = WWW::SwaggerClient::CategoryApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Kategori nesnesinin id değeri

eval { 
    my $result = $api_instance->categories_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CategoryApi->categories_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kategori nesnesinin id değeri | 

### Return type

[**Category**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **categories_id_put**
> Category categories_id_put(id => $id, category => $category)

Kategori Güncelleme

İlgili Kategoriyi günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::CategoryApi;
my $api_instance = WWW::SwaggerClient::CategoryApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Kategori nesnesinin id değeri
my $category = WWW::SwaggerClient::Object::Category->new(); # Category |  nesnesi

eval { 
    my $result = $api_instance->categories_id_put(id => $id, category => $category);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CategoryApi->categories_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kategori nesnesinin id değeri | 
 **category** | [**Category**](Category.md)|  nesnesi | 

### Return type

[**Category**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **categories_post**
> Category categories_post(category => $category)

Kategori Oluşturma

Yeni bir Kategori oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::CategoryApi;
my $api_instance = WWW::SwaggerClient::CategoryApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $category = WWW::SwaggerClient::Object::Category->new(); # Category |  nesnesi

eval { 
    my $result = $api_instance->categories_post(category => $category);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CategoryApi->categories_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **category** | [**Category**](Category.md)|  nesnesi | 

### Return type

[**Category**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

