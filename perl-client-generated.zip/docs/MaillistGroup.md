# WWW::SwaggerClient::Object::MaillistGroup

## Load the model package
```perl
use WWW::SwaggerClient::Object::MaillistGroup;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Mail listesi grubu nesnesi kimlik değeri. | [optional] 
**name** | **string** | Mail listesi grubu nesnesi için isim değeri. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


