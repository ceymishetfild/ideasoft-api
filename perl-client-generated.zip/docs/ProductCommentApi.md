# WWW::SwaggerClient::ProductCommentApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ProductCommentApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_comments_get**](ProductCommentApi.md#product_comments_get) | **GET** /product_comments | Ürün Yorumları Listesi Alma
[**product_comments_id_delete**](ProductCommentApi.md#product_comments_id_delete) | **DELETE** /product_comments/{id} | Ürün Yorumu Silme
[**product_comments_id_get**](ProductCommentApi.md#product_comments_id_get) | **GET** /product_comments/{id} | Ürün Yorumu Alma
[**product_comments_id_put**](ProductCommentApi.md#product_comments_id_put) | **PUT** /product_comments/{id} | Ürün Yorumu Güncelleme
[**product_comments_post**](ProductCommentApi.md#product_comments_post) | **POST** /product_comments | Ürün Yorumu Oluşturma


# **product_comments_get**
> ProductComment product_comments_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, status => $status, is_anonymous => $is_anonymous, member => $member, product => $product, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at)

Ürün Yorumları Listesi Alma

Ürün Yorumları listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductCommentApi;
my $api_instance = WWW::SwaggerClient::ProductCommentApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
my $status = 'status_example'; # string | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
my $is_anonymous = 'is_anonymous_example'; # string | IsAnonymous şu değerleri alabilir: <br><code>0</code> : Anonim değil<br><code>1</code> : Anonim
my $member = 56; # int | Üye id
my $product = 56; # int | Ürün id
my $start_date = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | createdAt değeri için başlangıç tarihi
my $end_date = 'end_date_example'; # string | createdAt değeri için bitiş tarihi
my $start_updated_at = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | updatedAt değeri için başlangıç tarihi
my $end_updated_at = 'end_updated_at_example'; # string | updatedAt değeri için bitiş tarihi

eval { 
    my $result = $api_instance->product_comments_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, status => $status, is_anonymous => $is_anonymous, member => $member, product => $product, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductCommentApi->product_comments_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional] 
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **is_anonymous** | **string**| IsAnonymous şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Anonim değil&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Anonim | [optional] 
 **member** | **int**| Üye id | [optional] 
 **product** | **int**| Ürün id | [optional] 
 **start_date** | **DateTime**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **DateTime**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_comments_id_delete**
> product_comments_id_delete(id => $id)

Ürün Yorumu Silme

Kalıcı olarak ilgili Ürün Yorumunu siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductCommentApi;
my $api_instance = WWW::SwaggerClient::ProductCommentApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Yorumu nesnesinin id değeri

eval { 
    $api_instance->product_comments_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling ProductCommentApi->product_comments_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Yorumu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_comments_id_get**
> ProductComment product_comments_id_get(id => $id)

Ürün Yorumu Alma

İlgili Ürün Yorumunu getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductCommentApi;
my $api_instance = WWW::SwaggerClient::ProductCommentApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Yorumu nesnesinin id değeri

eval { 
    my $result = $api_instance->product_comments_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductCommentApi->product_comments_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Yorumu nesnesinin id değeri | 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_comments_id_put**
> ProductComment product_comments_id_put(id => $id, product_comment => $product_comment)

Ürün Yorumu Güncelleme

İlgili Ürün Yorumunu günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductCommentApi;
my $api_instance = WWW::SwaggerClient::ProductCommentApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Yorumu nesnesinin id değeri
my $product_comment = WWW::SwaggerClient::Object::ProductComment->new(); # ProductComment |  nesnesi

eval { 
    my $result = $api_instance->product_comments_id_put(id => $id, product_comment => $product_comment);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductCommentApi->product_comments_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Yorumu nesnesinin id değeri | 
 **product_comment** | [**ProductComment**](ProductComment.md)|  nesnesi | 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_comments_post**
> ProductComment product_comments_post(product_comment => $product_comment)

Ürün Yorumu Oluşturma

Yeni bir Ürün Yorumu oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductCommentApi;
my $api_instance = WWW::SwaggerClient::ProductCommentApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $product_comment = WWW::SwaggerClient::Object::ProductComment->new(); # ProductComment |  nesnesi

eval { 
    my $result = $api_instance->product_comments_post(product_comment => $product_comment);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductCommentApi->product_comments_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_comment** | [**ProductComment**](ProductComment.md)|  nesnesi | 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

