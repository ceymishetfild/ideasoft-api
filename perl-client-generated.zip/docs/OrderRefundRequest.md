# WWW::SwaggerClient::Object::OrderRefundRequest

## Load the model package
```perl
use WWW::SwaggerClient::Object::OrderRefundRequest;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sipariş iptal talebi nesnesi kimlik değeri. | [optional] 
**code** | **string** | Sipariş iptal talebi için oluşturulan benzersiz kod değeri. | 
**status** | **string** | Sipariş iptal talebi için durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı.&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor.&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi.&lt;br&gt;&lt;/div&gt; | 
**fee** | **double** | Müşteriye ödenecek miktar bilgisi. | 
**cancellation_reason** | **string** | Sipariş iptal talebinin oluşturulması sebebinin detaylı açıklaması. | [optional] 
**created_at** | **DateTime** | Sipariş iptal talebi nesnesinin oluşturulma zamanı. | 
**updated_at** | **DateTime** | Sipariş iptal talebi nesnesinin güncellenme zamanı. | 
**member** | [**Member**](Member.md) | Üye nesnesi. | [optional] 
**order** | [**Order**](Order.md) | Sipariş nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


