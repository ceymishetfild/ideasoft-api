# WWW::SwaggerClient::ShippingProviderApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ShippingProviderApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipping_providers_get**](ShippingProviderApi.md#shipping_providers_get) | **GET** /shipping_providers | Teslimat Hizmeti Sağlayıcısı Listesi Alma
[**shipping_providers_id_get**](ShippingProviderApi.md#shipping_providers_id_get) | **GET** /shipping_providers/{id} | Teslimat Hizmeti Sağlayıcısı Alma


# **shipping_providers_get**
> ShippingProvider shipping_providers_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, code => $code, name => $name)

Teslimat Hizmeti Sağlayıcısı Listesi Alma

Teslimat Hizmeti Sağlayıcısı listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ShippingProviderApi;
my $api_instance = WWW::SwaggerClient::ShippingProviderApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $code = 'code_example'; # string | Kargo firması kodu
my $name = 'name_example'; # string | Kargo firması adı

eval { 
    my $result = $api_instance->shipping_providers_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, code => $code, name => $name);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ShippingProviderApi->shipping_providers_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **code** | **string**| Kargo firması kodu | [optional] 
 **name** | **string**| Kargo firması adı | [optional] 

### Return type

[**ShippingProvider**](ShippingProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipping_providers_id_get**
> ShippingProvider shipping_providers_id_get(id => $id)

Teslimat Hizmeti Sağlayıcısı Alma

İlgili Teslimat Hizmeti Sağlayıcısını getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ShippingProviderApi;
my $api_instance = WWW::SwaggerClient::ShippingProviderApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Teslimat Hizmeti Sağlayıcısı nesnesinin id değeri

eval { 
    my $result = $api_instance->shipping_providers_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ShippingProviderApi->shipping_providers_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Teslimat Hizmeti Sağlayıcısı nesnesinin id değeri | 

### Return type

[**ShippingProvider**](ShippingProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

