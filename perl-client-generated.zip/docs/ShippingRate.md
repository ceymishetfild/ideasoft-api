# WWW::SwaggerClient::Object::ShippingRate

## Load the model package
```perl
use WWW::SwaggerClient::Object::ShippingRate;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Kargo oranı nesnesi kimlik değeri. | [optional] 
**volumetric_weight_start** | **int** | İlgili kargo firması, ilgili bölge ve ilgili orana ait minimum desi değeri. | 
**volumetric_weight_end** | **int** | İlgili kargo firması, ilgili bölge ve ilgili orana ait maximum desi değeri. | 
**rate** | **double** | Seçili bölge ve kargo firması için kargo oranı. | 
**region** | [**Region**](Region.md) | Bölge nesnesi. | [optional] 
**shipping_company** | [**ShippingCompany**](ShippingCompany.md) | Kargo firması nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


