# WWW::SwaggerClient::OrderApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::OrderApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**orders_get**](OrderApi.md#orders_get) | **GET** /orders | Sipariş Listesi Alma
[**orders_id_delete**](OrderApi.md#orders_id_delete) | **DELETE** /orders/{id} | Sipariş Silme
[**orders_id_get**](OrderApi.md#orders_id_get) | **GET** /orders/{id} | Sipariş Alma
[**orders_id_put**](OrderApi.md#orders_id_put) | **PUT** /orders/{id} | Sipariş Güncelleme
[**orders_post**](OrderApi.md#orders_post) | **POST** /orders | Sipariş Oluşturma


# **orders_get**
> Order orders_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, transaction_id => $transaction_id, customer_email => $customer_email, member => $member, status => $status, payment_status => $payment_status, payment_type_name => $payment_type_name, shipping_provider_code => $shipping_provider_code, q => $q, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at)

Sipariş Listesi Alma

Sipariş listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderApi;
my $api_instance = WWW::SwaggerClient::OrderApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $transaction_id = 'transaction_id_example'; # string | İşlem id.
my $customer_email = 'customer_email_example'; # string | Müşteri e-mail.
my $member = 56; # int | Üye id
my $status = 'status_example'; # string | Status şu değerleri alabilir: <br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br><code>deleted</code> : Silindi
my $payment_status = 'payment_status_example'; # string | Ödeme durumu şu değerleri alabilir: <br><code>success</code> : Başarılı<br><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br><code>failed</code> : Hatalı Ödemeler
my $payment_type_name = 'payment_type_name_example'; # string | Ödeme tipi şu değerleri alabilir: <br><code>Havale</code><br><code>Özel Ödeme Sistemi</code><br><code>Kredi Kartı</code><br><code>Paypal</code><br><code>GarantiPay</code><br><code>Mail Order</code><br><code>BKM Express</code><br><code>Kapıda Ödeme Nakit</code><br><code>Kapıda Ödeme Kredi Kartı</code>
my $shipping_provider_code = 'shipping_provider_code_example'; # string | Teslimat hizmeti sağlayıcıları kodu şu değerleri alabilir: <br><code>yurtici</code> : Yurtiçi Kargo<br><code>yurtici_self_service</code> : Yurtiçi Kargo (Self Service)<br><code>yurtici_api</code> : Yurtiçi Kargo (API)<br><code>ptt</code> : PTT Kargo<br><code>mng</code> : MNG Kargo<br><code>surat</code> : Sürat Kargo<br><code>ups</code> : UPS<br><code>aras</code> : Aras Kargo<br><code>other</code> : Diğer
my $q = []; # ARRAY[string] | Sipariş arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;]
my $start_date = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | createdAt değeri için başlangıç tarihi
my $end_date = 'end_date_example'; # string | createdAt değeri için bitiş tarihi
my $start_updated_at = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | updatedAt değeri için başlangıç tarihi
my $end_updated_at = 'end_updated_at_example'; # string | updatedAt değeri için bitiş tarihi

eval { 
    my $result = $api_instance->orders_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, transaction_id => $transaction_id, customer_email => $customer_email, member => $member, status => $status, payment_status => $payment_status, payment_type_name => $payment_type_name, shipping_provider_code => $shipping_provider_code, q => $q, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderApi->orders_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **transaction_id** | **string**| İşlem id. | [optional] 
 **customer_email** | **string**| Müşteri e-mail. | [optional] 
 **member** | **int**| Üye id | [optional] 
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi | [optional] 
 **payment_status** | **string**| Ödeme durumu şu değerleri alabilir: &lt;br&gt;&lt;code&gt;success&lt;/code&gt; : Başarılı&lt;br&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler | [optional] 
 **payment_type_name** | **string**| Ödeme tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;Havale&lt;/code&gt;&lt;br&gt;&lt;code&gt;Özel Ödeme Sistemi&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kredi Kartı&lt;/code&gt;&lt;br&gt;&lt;code&gt;Paypal&lt;/code&gt;&lt;br&gt;&lt;code&gt;GarantiPay&lt;/code&gt;&lt;br&gt;&lt;code&gt;Mail Order&lt;/code&gt;&lt;br&gt;&lt;code&gt;BKM Express&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kapıda Ödeme Nakit&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kapıda Ödeme Kredi Kartı&lt;/code&gt; | [optional] 
 **shipping_provider_code** | **string**| Teslimat hizmeti sağlayıcıları kodu şu değerleri alabilir: &lt;br&gt;&lt;code&gt;yurtici&lt;/code&gt; : Yurtiçi Kargo&lt;br&gt;&lt;code&gt;yurtici_self_service&lt;/code&gt; : Yurtiçi Kargo (Self Service)&lt;br&gt;&lt;code&gt;yurtici_api&lt;/code&gt; : Yurtiçi Kargo (API)&lt;br&gt;&lt;code&gt;ptt&lt;/code&gt; : PTT Kargo&lt;br&gt;&lt;code&gt;mng&lt;/code&gt; : MNG Kargo&lt;br&gt;&lt;code&gt;surat&lt;/code&gt; : Sürat Kargo&lt;br&gt;&lt;code&gt;ups&lt;/code&gt; : UPS&lt;br&gt;&lt;code&gt;aras&lt;/code&gt; : Aras Kargo&lt;br&gt;&lt;code&gt;other&lt;/code&gt; : Diğer | [optional] 
 **q** | [**ARRAY[string]**](string.md)| Sipariş arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 
 **start_date** | **DateTime**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **DateTime**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **orders_id_delete**
> orders_id_delete(id => $id)

Sipariş Silme

Kalıcı olarak ilgili Siparişi siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderApi;
my $api_instance = WWW::SwaggerClient::OrderApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş nesnesinin id değeri

eval { 
    $api_instance->orders_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling OrderApi->orders_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **orders_id_get**
> Order orders_id_get(id => $id)

Sipariş Alma

İlgili Siparişi getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderApi;
my $api_instance = WWW::SwaggerClient::OrderApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş nesnesinin id değeri

eval { 
    my $result = $api_instance->orders_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderApi->orders_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş nesnesinin id değeri | 

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **orders_id_put**
> Order orders_id_put(id => $id, order => $order)

Sipariş Güncelleme

İlgili Siparişi günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderApi;
my $api_instance = WWW::SwaggerClient::OrderApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş nesnesinin id değeri
my $order = WWW::SwaggerClient::Object::Order->new(); # Order | Order nesnesi

eval { 
    my $result = $api_instance->orders_id_put(id => $id, order => $order);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderApi->orders_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş nesnesinin id değeri | 
 **order** | [**Order**](Order.md)| Order nesnesi | 

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **orders_post**
> Order orders_post(order => $order)

Sipariş Oluşturma

Yeni bir Sipariş oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderApi;
my $api_instance = WWW::SwaggerClient::OrderApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $order = WWW::SwaggerClient::Object::Order->new(); # Order | Order nesnesi

eval { 
    my $result = $api_instance->orders_post(order => $order);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderApi->orders_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order** | [**Order**](Order.md)| Order nesnesi | 

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

