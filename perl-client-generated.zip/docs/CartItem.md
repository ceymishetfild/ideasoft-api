# WWW::SwaggerClient::Object::CartItem

## Load the model package
```perl
use WWW::SwaggerClient::Object::CartItem;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sepet kalemi nesnesi kimlik değeri. | [optional] 
**parent_product_id** | **int** | Ana ürünün benzersiz rakamsal kimlik değeri. | [optional] 
**quantity** | **double** | Sepetteki kalem adedi. | 
**category_id** | **int** | Sepetteki kaleme ait kategorinin benzersiz kimlik değeri. | [optional] 
**created_at** | **DateTime** | Sepet kalemi nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Sepet kalemi nesnesinin güncellenme zamanı. | [optional] 
**cart** | [**Cart**](Cart.md) |  | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 
**attributes** | [**ARRAY[CartItemAttribute]**](CartItemAttribute.md) | Sepet kalemi özelliği barındıran liste. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


