# WWW::SwaggerClient::Object::ProductToTag

## Load the model package
```perl
use WWW::SwaggerClient::Object::ProductToTag;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ürün SEO+ etiketi bağı nesnesi kimlik değeri. | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 
**tag** | [**Tag**](Tag.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


