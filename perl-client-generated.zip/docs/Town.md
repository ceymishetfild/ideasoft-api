# WWW::SwaggerClient::Object::Town

## Load the model package
```perl
use WWW::SwaggerClient::Object::Town;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | İlçe nesnesi kimlik değeri. | [optional] 
**name** | **string** | İlçe nesnesi için isim değeri. | 
**status** | **string** | İlçenin aktiflik bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**location** | [**Location**](Location.md) |  | [optional] 
**town_group** | [**TownGroup**](TownGroup.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


