# WWW::SwaggerClient::ShippingCompanyApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ShippingCompanyApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipping_companies_get**](ShippingCompanyApi.md#shipping_companies_get) | **GET** /shipping_companies | Kargo Firması Listesi Alma
[**shipping_companies_id_delete**](ShippingCompanyApi.md#shipping_companies_id_delete) | **DELETE** /shipping_companies/{id} | Kargo Firması Silme
[**shipping_companies_id_get**](ShippingCompanyApi.md#shipping_companies_id_get) | **GET** /shipping_companies/{id} | Kargo Firması Alma
[**shipping_companies_id_put**](ShippingCompanyApi.md#shipping_companies_id_put) | **PUT** /shipping_companies/{id} | Kargo Firması Güncelleme
[**shipping_companies_post**](ShippingCompanyApi.md#shipping_companies_post) | **POST** /shipping_companies | Kargo Firması Oluşturma


# **shipping_companies_get**
> ShippingCompany shipping_companies_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, name => $name, company_code => $company_code, payment_type => $payment_type, shipping_provider => $shipping_provider)

Kargo Firması Listesi Alma

Kargo Firması listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ShippingCompanyApi;
my $api_instance = WWW::SwaggerClient::ShippingCompanyApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $name = 'name_example'; # string | Kargo firması adı
my $company_code = 'company_code_example'; # string | Kargo firması kodu
my $payment_type = 'payment_type_example'; # string | Ödeme Tipi şu değerleri alabilir: <br><code>cash_on_delivery</code> : Alıcı ödemeli<br><code>standart_delivery</code> : Gönderici ödemeli<br><code>not_applicable</code> : Bu alan için uygulanabilir değil
my $shipping_provider = 56; # int | Teslimat Hizmeti Sağlayıcısı id

eval { 
    my $result = $api_instance->shipping_companies_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, name => $name, company_code => $company_code, payment_type => $payment_type, shipping_provider => $shipping_provider);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ShippingCompanyApi->shipping_companies_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **string**| Kargo firması adı | [optional] 
 **company_code** | **string**| Kargo firması kodu | [optional] 
 **payment_type** | **string**| Ödeme Tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil | [optional] 
 **shipping_provider** | **int**| Teslimat Hizmeti Sağlayıcısı id | [optional] 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipping_companies_id_delete**
> shipping_companies_id_delete(id => $id)

Kargo Firması Silme

Kalıcı olarak ilgili Kargo Firmasını siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ShippingCompanyApi;
my $api_instance = WWW::SwaggerClient::ShippingCompanyApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Kargo Firması nesnesinin id değeri

eval { 
    $api_instance->shipping_companies_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling ShippingCompanyApi->shipping_companies_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kargo Firması nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipping_companies_id_get**
> ShippingCompany shipping_companies_id_get(id => $id)

Kargo Firması Alma

İlgili Kargo Firmasını getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ShippingCompanyApi;
my $api_instance = WWW::SwaggerClient::ShippingCompanyApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Kargo Firması nesnesinin id değeri

eval { 
    my $result = $api_instance->shipping_companies_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ShippingCompanyApi->shipping_companies_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kargo Firması nesnesinin id değeri | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipping_companies_id_put**
> ShippingCompany shipping_companies_id_put(id => $id, shipping_company => $shipping_company)

Kargo Firması Güncelleme

İlgili Kargo Firmasını günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ShippingCompanyApi;
my $api_instance = WWW::SwaggerClient::ShippingCompanyApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Kargo Firması nesnesinin id değeri
my $shipping_company = WWW::SwaggerClient::Object::ShippingCompany->new(); # ShippingCompany | ShippingCompany nesnesi

eval { 
    my $result = $api_instance->shipping_companies_id_put(id => $id, shipping_company => $shipping_company);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ShippingCompanyApi->shipping_companies_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kargo Firması nesnesinin id değeri | 
 **shipping_company** | [**ShippingCompany**](ShippingCompany.md)| ShippingCompany nesnesi | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipping_companies_post**
> ShippingCompany shipping_companies_post(shipping_company => $shipping_company)

Kargo Firması Oluşturma

Yeni bir Kargo Firması oluşturur relationship.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ShippingCompanyApi;
my $api_instance = WWW::SwaggerClient::ShippingCompanyApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $shipping_company = WWW::SwaggerClient::Object::ShippingCompany->new(); # ShippingCompany | ShippingCompany nesnesi

eval { 
    my $result = $api_instance->shipping_companies_post(shipping_company => $shipping_company);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ShippingCompanyApi->shipping_companies_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipping_company** | [**ShippingCompany**](ShippingCompany.md)| ShippingCompany nesnesi | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

