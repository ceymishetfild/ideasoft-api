# WWW::SwaggerClient::MemberGroupApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::MemberGroupApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**member_groups_get**](MemberGroupApi.md#member_groups_get) | **GET** /member_groups | Üye Grubu Listesi Alma
[**member_groups_id_delete**](MemberGroupApi.md#member_groups_id_delete) | **DELETE** /member_groups/{id} | Üye Grubu Silme
[**member_groups_id_get**](MemberGroupApi.md#member_groups_id_get) | **GET** /member_groups/{id} | Üye Grubu Alma
[**member_groups_id_put**](MemberGroupApi.md#member_groups_id_put) | **PUT** /member_groups/{id} | Üye Grubu Güncelleme
[**member_groups_post**](MemberGroupApi.md#member_groups_post) | **POST** /member_groups | Üye Grubu Oluşturma


# **member_groups_get**
> MemberGroup member_groups_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name)

Üye Grubu Listesi Alma

Üye Grubu listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberGroupApi;
my $api_instance = WWW::SwaggerClient::MemberGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $name = 'name_example'; # string | Üye Grubu adı

eval { 
    my $result = $api_instance->member_groups_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MemberGroupApi->member_groups_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **string**| Üye Grubu adı | [optional] 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_groups_id_delete**
> member_groups_id_delete(id => $id)

Üye Grubu Silme

Kalıcı olarak ilgili Üye Grubunu siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberGroupApi;
my $api_instance = WWW::SwaggerClient::MemberGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Üye Grubu nesnesinin id değeri

eval { 
    $api_instance->member_groups_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling MemberGroupApi->member_groups_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_groups_id_get**
> MemberGroup member_groups_id_get(id => $id)

Üye Grubu Alma

İlgili Üye Grubunu getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberGroupApi;
my $api_instance = WWW::SwaggerClient::MemberGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Üye Grubu nesnesinin id değeri

eval { 
    my $result = $api_instance->member_groups_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MemberGroupApi->member_groups_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Grubu nesnesinin id değeri | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_groups_id_put**
> MemberGroup member_groups_id_put(id => $id, member_group => $member_group)

Üye Grubu Güncelleme

İlgili Üye Grubunu günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberGroupApi;
my $api_instance = WWW::SwaggerClient::MemberGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Üye Grubu nesnesinin id değeri
my $member_group = WWW::SwaggerClient::Object::MemberGroup->new(); # MemberGroup |  nesnesi

eval { 
    my $result = $api_instance->member_groups_id_put(id => $id, member_group => $member_group);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MemberGroupApi->member_groups_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Grubu nesnesinin id değeri | 
 **member_group** | [**MemberGroup**](MemberGroup.md)|  nesnesi | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_groups_post**
> MemberGroup member_groups_post(member_group => $member_group)

Üye Grubu Oluşturma

Yeni bir Üye Grubu oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MemberGroupApi;
my $api_instance = WWW::SwaggerClient::MemberGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $member_group = WWW::SwaggerClient::Object::MemberGroup->new(); # MemberGroup |  nesnesi

eval { 
    my $result = $api_instance->member_groups_post(member_group => $member_group);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MemberGroupApi->member_groups_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member_group** | [**MemberGroup**](MemberGroup.md)|  nesnesi | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

