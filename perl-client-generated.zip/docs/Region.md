# WWW::SwaggerClient::Object::Region

## Load the model package
```perl
use WWW::SwaggerClient::Object::Region;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Bölge nesnesi kimlik değeri. | [optional] 
**name** | **string** | Bölge nesnesi için isim değeri. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


