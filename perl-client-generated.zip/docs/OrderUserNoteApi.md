# WWW::SwaggerClient::OrderUserNoteApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::OrderUserNoteApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**order_user_notes_get**](OrderUserNoteApi.md#order_user_notes_get) | **GET** /order_user_notes | Sipariş Yönetici Notu Listesi Alma
[**order_user_notes_id_delete**](OrderUserNoteApi.md#order_user_notes_id_delete) | **DELETE** /order_user_notes/{id} | Sipariş Yönetici Notu Silme
[**order_user_notes_id_get**](OrderUserNoteApi.md#order_user_notes_id_get) | **GET** /order_user_notes/{id} | Sipariş Yönetici Notu Alma
[**order_user_notes_id_put**](OrderUserNoteApi.md#order_user_notes_id_put) | **PUT** /order_user_notes/{id} | Sipariş Yönetici Notu Güncelleme
[**order_user_notes_post**](OrderUserNoteApi.md#order_user_notes_post) | **POST** /order_user_notes | Sipariş Yönetici Notu Oluşturma


# **order_user_notes_get**
> OrderUserNote order_user_notes_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, order => $order, user_email => $user_email, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at)

Sipariş Yönetici Notu Listesi Alma

Sipariş Yönetici Notu listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderUserNoteApi;
my $api_instance = WWW::SwaggerClient::OrderUserNoteApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $order = 56; # int | Sipariş id
my $user_email = 'user_email_example'; # string | Yönetici e-mail
my $start_date = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | createdAt değeri için başlangıç tarihi
my $end_date = 'end_date_example'; # string | createdAt değeri için bitiş tarihi
my $start_updated_at = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | updatedAt değeri için başlangıç tarihi
my $end_updated_at = 'end_updated_at_example'; # string | updatedAt değeri için bitiş tarihi

eval { 
    my $result = $api_instance->order_user_notes_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, order => $order, user_email => $user_email, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderUserNoteApi->order_user_notes_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **int**| Sipariş id | [optional] 
 **user_email** | **string**| Yönetici e-mail | [optional] 
 **start_date** | **DateTime**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **DateTime**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_user_notes_id_delete**
> order_user_notes_id_delete(id => $id)

Sipariş Yönetici Notu Silme

Kalıcı olarak ilgili Sipariş Yönetici Notunu siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderUserNoteApi;
my $api_instance = WWW::SwaggerClient::OrderUserNoteApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş Yönetici Notu nesnesinin id değeri

eval { 
    $api_instance->order_user_notes_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling OrderUserNoteApi->order_user_notes_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Yönetici Notu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_user_notes_id_get**
> OrderUserNote order_user_notes_id_get(id => $id)

Sipariş Yönetici Notu Alma

İlgili Sipariş Yönetici Notunu getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderUserNoteApi;
my $api_instance = WWW::SwaggerClient::OrderUserNoteApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş Yönetici Notu nesnesinin id değeri

eval { 
    my $result = $api_instance->order_user_notes_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderUserNoteApi->order_user_notes_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Yönetici Notu nesnesinin id değeri | 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_user_notes_id_put**
> OrderUserNote order_user_notes_id_put(id => $id, order_user_note => $order_user_note)

Sipariş Yönetici Notu Güncelleme

İlgili Sipariş Yönetici Notunu günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderUserNoteApi;
my $api_instance = WWW::SwaggerClient::OrderUserNoteApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş Yönetici Notu nesnesinin id değeri
my $order_user_note = WWW::SwaggerClient::Object::OrderUserNote->new(); # OrderUserNote | OrderUserNote nesnesi

eval { 
    my $result = $api_instance->order_user_notes_id_put(id => $id, order_user_note => $order_user_note);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderUserNoteApi->order_user_notes_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Yönetici Notu nesnesinin id değeri | 
 **order_user_note** | [**OrderUserNote**](OrderUserNote.md)| OrderUserNote nesnesi | 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_user_notes_post**
> OrderUserNote order_user_notes_post(order_user_note => $order_user_note)

Sipariş Yönetici Notu Oluşturma

Yeni bir Sipariş Yönetici Notu oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderUserNoteApi;
my $api_instance = WWW::SwaggerClient::OrderUserNoteApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $order_user_note = WWW::SwaggerClient::Object::OrderUserNote->new(); # OrderUserNote | OrderUserNote nesnesi

eval { 
    my $result = $api_instance->order_user_notes_post(order_user_note => $order_user_note);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderUserNoteApi->order_user_notes_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_user_note** | [**OrderUserNote**](OrderUserNote.md)| OrderUserNote nesnesi | 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

