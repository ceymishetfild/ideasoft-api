# WWW::SwaggerClient::Object::Order

## Load the model package
```perl
use WWW::SwaggerClient::Object::Order;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sipariş nesnesi kimlik değeri. | [optional] 
**customer_firstname** | **string** | Müşterinin ismi. | 
**customer_surname** | **string** | Müşterinin soy ismi. | 
**customer_email** | **string** | Müşterinin e-mail adresi. | 
**customer_phone** | **string** | Müşterinin telefon numarası. | 
**payment_type_name** | **string** | Siparişin ödeme tipi. | 
**payment_provider_code** | **string** | Siparişin ödeme altyapısı sağlayıcısının kodu. Ön tanımlıdır. API otomatik oluşturur. | 
**payment_provider_name** | **string** | Siparişin ödeme altyapısı sağlayıcısının adı. Ön tanımlıdır. API otomatik oluşturur. | 
**payment_gateway_code** | **string** | Siparişin ödeme kanalının kodu. Ön tanımlıdır. API otomatik oluşturur. | 
**payment_gateway_name** | **string** | Siparişin ödeme kanalının adı. Ön tanımlıdır. API otomatik oluşturur. | 
**bank_name** | **string** | Siparişin banka adı. Ön tanımlıdır. API otomatik oluşturur. | [optional] 
**client_ip** | **string** | Müşterinin IP adresi. | 
**user_agent** | **string** | Siparişin gerçekleştiği tarayıcı bilgisi. | [optional] 
**currency** | **string** | Kur bilgisi. | 
**currency_rates** | **string** | Kur oranları. | 
**amount** | **double** | Siparişin vergi hariç fiyatı. | 
**coupon_discount** | **double** | Siparişte kullanılan hediye çeki indirimi tutarı. | 
**tax_amount** | **double** | Siparişin vergi tutarı. | 
**promotion_discount** | **double** | Siparişte kullanılan promosyon indirimi tutarı. | 
**general_amount** | **double** | Siparişin genel fiyat tutarı. orderAmount, couponDiscount, taxAmount, promotionDiscount, shippingAmount, additionalServiceAmount tutarlarının toplamı. | 
**shipping_amount** | **double** | Siparişin teslimat ücreti. | 
**additional_service_amount** | **double** | Siparişin ek hizmet bedeli ücreti. | 
**final_amount** | **double** | Siparişin son ödeme tutarı. generalAmount değerinin üzerine taksitten kaynaklı vade farkı bedeli eklenmiş hali. | 
**sum_of_gained_points** | **double** | Siparişten kazanılan puan tutarı. | [optional] 
**installment** | **int** | Siparişin taksit adeti. | [optional] 
**installment_rate** | **double** | Siparişin taksit oranı. | [optional] 
**extra_installment** | **int** | Siparişin ek taksit adeti. | [optional] 
**transaction_id** | **string** | Siparişin numarası. | [optional] 
**has_user_note** | **string** | Siparişin müşteri notuna sahiplik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sipariş müşteri notuna sahip.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sipariş müşteri notuna sahip değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**status** | **string** | Sipariş durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;/div&gt; | 
**payment_status** | **string** | Ödeme durumu bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;success&lt;/code&gt; : Başarılı&lt;br&gt;&lt;/div&gt; | 
**error_message** | **string** | Siparişin hata mesajı. | [optional] 
**device_type** | **string** | Siparişin gerçekleştiği cihaz bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil&lt;br&gt;&lt;code&gt;tablet&lt;/code&gt; : Tablet&lt;br&gt;&lt;/div&gt; | 
**referrer** | **string** | Siparişe yönlendiren web-sitesi adresi. Yönlendirmeyi yapan web-sitesinin tam URL bilgisini de içerir. API otomatik oluşturur. | [optional] 
**invoice_print_count** | **int** | Sipariş için alınan fatura çıktısı adedi. | [optional] 
**use_gift_package** | **string** | Hediye paketi istenilmesi durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hediye paketi istiyorum&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hediye paketi istemiyorum&lt;br&gt;&lt;/div&gt; | [optional] 
**gift_note** | **string** | Hediye notu. | [optional] 
**member_group_name** | **string** | Üye grubu adı. | [optional] 
**use_promotion** | **string** | Promosyon kullanılma durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Promosyon kullan&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Promosyon kullanma&lt;br&gt;&lt;/div&gt; | [optional] 
**shipping_provider_code** | **string** | Siparişin teslimat hizmeti sağlayıcısı kodu. Ön tanımlıdır. API otomatik oluşturur. | [optional] 
**shipping_provider_name** | **string** | Siparişin teslimat hizmeti sağlayıcısı adı. Ön tanımlıdır. | [optional] 
**shipping_company_name** | **string** | Siparişin kargo firması adı. Ön tanımlıdır. | [optional] 
**shipping_payment_type** | **string** | Siparişin kargo ödeme tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı Ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici Ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için geçerli değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**shipping_tracking_code** | **string** | Siparişin kargo takip kodu. | [optional] 
**source** | **string** | Siparişin kaynak bilgisi. Siparişin kaynak yazılımını belirtir. | 
**created_at** | **DateTime** | Sipariş nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Sipariş nesnesinin güncellenme zamanı. | [optional] 
**maillist** | [**Maillist**](Maillist.md) | Mail listesi nesnesi. | [optional] 
**member** | [**Member**](Member.md) | Üye nesnesi. | [optional] 
**order_details** | [**ARRAY[OrderDetail]**](OrderDetail.md) | Sipariş detayları. | [optional] 
**order_items** | [**ARRAY[OrderItem]**](OrderItem.md) | Sipariş kalemleri. | [optional] 
**shipping_address** | [**ShippingAddress**](ShippingAddress.md) | Teslimat adresi nesnesi. | [optional] 
**billing_address** | [**BillingAddress**](BillingAddress.md) | Fatura adresi nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


