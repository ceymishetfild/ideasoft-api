# WWW::SwaggerClient::CurrencyApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::CurrencyApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**currencies_get**](CurrencyApi.md#currencies_get) | **GET** /currencies | Kur Listesi Alma
[**currencies_id_get**](CurrencyApi.md#currencies_id_get) | **GET** /currencies/{id} | Kur Alma
[**currencies_id_put**](CurrencyApi.md#currencies_id_put) | **PUT** /currencies/{id} | Kur Güncelleme


# **currencies_get**
> Currency currencies_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, label => $label, abbr => $abbr, status => $status)

Kur Listesi Alma

Kur listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::CurrencyApi;
my $api_instance = WWW::SwaggerClient::CurrencyApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $label = 'label_example'; # string | Kur etiketi
my $abbr = 'abbr_example'; # string | Kur kısaltması
my $status = 'status_example'; # string | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif

eval { 
    my $result = $api_instance->currencies_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, label => $label, abbr => $abbr, status => $status);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CurrencyApi->currencies_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **label** | **string**| Kur etiketi | [optional] 
 **abbr** | **string**| Kur kısaltması | [optional] 
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 

### Return type

[**Currency**](Currency.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **currencies_id_get**
> Currency currencies_id_get(id => $id)

Kur Alma

İlgili Kur getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::CurrencyApi;
my $api_instance = WWW::SwaggerClient::CurrencyApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Kur nesnesinin id değeri

eval { 
    my $result = $api_instance->currencies_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CurrencyApi->currencies_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kur nesnesinin id değeri | 

### Return type

[**Currency**](Currency.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **currencies_id_put**
> Currency currencies_id_put(id => $id, currency => $currency)

Kur Güncelleme

İlgili Kur günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::CurrencyApi;
my $api_instance = WWW::SwaggerClient::CurrencyApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Kur nesnesinin id değeri
my $currency = WWW::SwaggerClient::Object::Currency->new(); # Currency |  nesnesi

eval { 
    my $result = $api_instance->currencies_id_put(id => $id, currency => $currency);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling CurrencyApi->currencies_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kur nesnesinin id değeri | 
 **currency** | [**Currency**](Currency.md)|  nesnesi | 

### Return type

[**Currency**](Currency.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

