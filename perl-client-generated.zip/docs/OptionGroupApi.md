# WWW::SwaggerClient::OptionGroupApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::OptionGroupApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**option_groups_get**](OptionGroupApi.md#option_groups_get) | **GET** /option_groups | Varyant Grubu Listesi Alma
[**option_groups_id_delete**](OptionGroupApi.md#option_groups_id_delete) | **DELETE** /option_groups/{id} | Varyant Grubu Silme
[**option_groups_id_get**](OptionGroupApi.md#option_groups_id_get) | **GET** /option_groups/{id} | Varyant Grubu Alma
[**option_groups_id_put**](OptionGroupApi.md#option_groups_id_put) | **PUT** /option_groups/{id} | Varyant Grubu Güncelleme
[**option_groups_post**](OptionGroupApi.md#option_groups_post) | **POST** /option_groups | Varyant Grubu Oluşturma


# **option_groups_get**
> OptionGroup option_groups_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, title => $title)

Varyant Grubu Listesi Alma

Varyant Grubu listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OptionGroupApi;
my $api_instance = WWW::SwaggerClient::OptionGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $title = 'title_example'; # string | Varyant Grubu başlığı.

eval { 
    my $result = $api_instance->option_groups_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, title => $title);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OptionGroupApi->option_groups_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **title** | **string**| Varyant Grubu başlığı. | [optional] 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **option_groups_id_delete**
> option_groups_id_delete(id => $id)

Varyant Grubu Silme

Kalıcı olarak ilgili Varyant Grubunu siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OptionGroupApi;
my $api_instance = WWW::SwaggerClient::OptionGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Varyant Grubu nesnesinin id değeri

eval { 
    $api_instance->option_groups_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling OptionGroupApi->option_groups_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **option_groups_id_get**
> OptionGroup option_groups_id_get(id => $id)

Varyant Grubu Alma

İlgili Varyant Grubunu getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OptionGroupApi;
my $api_instance = WWW::SwaggerClient::OptionGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Varyant Grubu nesnesinin id değeri

eval { 
    my $result = $api_instance->option_groups_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OptionGroupApi->option_groups_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant Grubu nesnesinin id değeri | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **option_groups_id_put**
> OptionGroup option_groups_id_put(id => $id, option_group => $option_group)

Varyant Grubu Güncelleme

İlgili Varyant Grubunu günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OptionGroupApi;
my $api_instance = WWW::SwaggerClient::OptionGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Varyant Grubu nesnesinin id değeri
my $option_group = WWW::SwaggerClient::Object::OptionGroup->new(); # OptionGroup |  nesnesi

eval { 
    my $result = $api_instance->option_groups_id_put(id => $id, option_group => $option_group);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OptionGroupApi->option_groups_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant Grubu nesnesinin id değeri | 
 **option_group** | [**OptionGroup**](OptionGroup.md)|  nesnesi | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **option_groups_post**
> OptionGroup option_groups_post(option_group => $option_group)

Varyant Grubu Oluşturma

Yeni bir Varyant Grubu oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OptionGroupApi;
my $api_instance = WWW::SwaggerClient::OptionGroupApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $option_group = WWW::SwaggerClient::Object::OptionGroup->new(); # OptionGroup |  nesnesi

eval { 
    my $result = $api_instance->option_groups_post(option_group => $option_group);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OptionGroupApi->option_groups_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **option_group** | [**OptionGroup**](OptionGroup.md)|  nesnesi | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

