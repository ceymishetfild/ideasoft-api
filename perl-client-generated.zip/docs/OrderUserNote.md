# WWW::SwaggerClient::Object::OrderUserNote

## Load the model package
```perl
use WWW::SwaggerClient::Object::OrderUserNote;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sipariş yönetici notu nesnesi kimlik değeri. | [optional] 
**user_email** | **string** | Yöneticinin(admin) e-mail adresi. | 
**user_firstname** | **string** | Yöneticinin(admin) ismi. | [optional] 
**user_surname** | **string** | Yöneticinin(admin) soy ismi. | [optional] 
**note** | **string** | Yöneticinin(admin) sipariş için girdiği not. | 
**created_at** | **DateTime** | Sipariş yönetici notu nesnesinin oluşturulma zamanı. | 
**updated_at** | **DateTime** | Sipariş yönetici notu nesnesinin güncellenme zamanı. | 
**order** | [**Order**](Order.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


