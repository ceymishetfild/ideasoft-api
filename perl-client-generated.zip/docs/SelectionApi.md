# WWW::SwaggerClient::SelectionApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::SelectionApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selections_get**](SelectionApi.md#selections_get) | **GET** /selections | Ek Özellik Listesi Alma
[**selections_id_delete**](SelectionApi.md#selections_id_delete) | **DELETE** /selections/{id} | Ek Özellik Silme
[**selections_id_get**](SelectionApi.md#selections_id_get) | **GET** /selections/{id} | Ek Özellik Alma
[**selections_id_put**](SelectionApi.md#selections_id_put) | **PUT** /selections/{id} | Ek Özellik Güncelleme
[**selections_post**](SelectionApi.md#selections_post) | **POST** /selections | Ek Özellik Oluşturma


# **selections_get**
> Selection selections_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, title => $title, selection_group => $selection_group)

Ek Özellik Listesi Alma

Ek Özellik listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SelectionApi;
my $api_instance = WWW::SwaggerClient::SelectionApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $title = 'title_example'; # string | Ek Özellik başlığı
my $selection_group = 56; # int | Ek Özellik Grubu id

eval { 
    my $result = $api_instance->selections_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, title => $title, selection_group => $selection_group);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SelectionApi->selections_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **title** | **string**| Ek Özellik başlığı | [optional] 
 **selection_group** | **int**| Ek Özellik Grubu id | [optional] 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selections_id_delete**
> selections_id_delete(id => $id)

Ek Özellik Silme

Kalıcı olarak ilgili Ek Özelliği siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SelectionApi;
my $api_instance = WWW::SwaggerClient::SelectionApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ek Özellik nesnesinin id değeri

eval { 
    $api_instance->selections_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling SelectionApi->selections_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selections_id_get**
> Selection selections_id_get(id => $id)

Ek Özellik Alma

İlgili Ek Özelliği getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SelectionApi;
my $api_instance = WWW::SwaggerClient::SelectionApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ek Özellik nesnesinin id değeri

eval { 
    my $result = $api_instance->selections_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SelectionApi->selections_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik nesnesinin id değeri | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selections_id_put**
> Selection selections_id_put(id => $id, selection => $selection)

Ek Özellik Güncelleme

İlgili Ek Özelliği günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SelectionApi;
my $api_instance = WWW::SwaggerClient::SelectionApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ek Özellik nesnesinin id değeri
my $selection = WWW::SwaggerClient::Object::Selection->new(); # Selection | Selection nesnesi

eval { 
    my $result = $api_instance->selections_id_put(id => $id, selection => $selection);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SelectionApi->selections_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik nesnesinin id değeri | 
 **selection** | [**Selection**](Selection.md)| Selection nesnesi | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selections_post**
> Selection selections_post(selection => $selection)

Ek Özellik Oluşturma

Yeni bir Ek Özellik oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::SelectionApi;
my $api_instance = WWW::SwaggerClient::SelectionApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $selection = WWW::SwaggerClient::Object::Selection->new(); # Selection | Selection nesnesi

eval { 
    my $result = $api_instance->selections_post(selection => $selection);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SelectionApi->selections_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selection** | [**Selection**](Selection.md)| Selection nesnesi | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

