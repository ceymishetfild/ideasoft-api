# WWW::SwaggerClient::Object::OptionToProduct

## Load the model package
```perl
use WWW::SwaggerClient::Object::OptionToProduct;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Varyant ürün bağı nesnesi kimlik değeri. | [optional] 
**parent_product_id** | **int** | Ana ürünün benzersiz kimlik değeri. | 
**option_group** | [**OptionGroup**](OptionGroup.md) |  | [optional] 
**option** | [**Options**](Options.md) |  | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


