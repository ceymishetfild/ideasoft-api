# WWW::SwaggerClient::OrderRefundRequestApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::OrderRefundRequestApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**order_refund_requests_get**](OrderRefundRequestApi.md#order_refund_requests_get) | **GET** /order_refund_requests | Sipariş İptal Talebi Listesi Alma
[**order_refund_requests_id_delete**](OrderRefundRequestApi.md#order_refund_requests_id_delete) | **DELETE** /order_refund_requests/{id} | Sipariş İptal Talebi Silme
[**order_refund_requests_id_get**](OrderRefundRequestApi.md#order_refund_requests_id_get) | **GET** /order_refund_requests/{id} | Sipariş İptal Talebi Alma
[**order_refund_requests_id_put**](OrderRefundRequestApi.md#order_refund_requests_id_put) | **PUT** /order_refund_requests/{id} | Sipariş İptal Talebi Güncelleme
[**order_refund_requests_post**](OrderRefundRequestApi.md#order_refund_requests_post) | **POST** /order_refund_requests | Sipariş İptal Talebi Oluşturma


# **order_refund_requests_get**
> OrderRefundRequest order_refund_requests_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, order => $order, member => $member, code => $code, status => $status, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at)

Sipariş İptal Talebi Listesi Alma

Sipariş İptal Talebi listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderRefundRequestApi;
my $api_instance = WWW::SwaggerClient::OrderRefundRequestApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $order = 56; # int | Sipariş id
my $member = 56; # int | Üye id
my $code = 'code_example'; # string | Sipariş İptal Talebi kodu
my $status = 'status_example'; # string | Status şu değerleri alabilir: <br><code>waiting_for_approval</code> : Onay bekliyor<br><code>approved</code> : Onaylandı<br><code>cancelled</code> : İptal edildi
my $start_date = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | createdAt değeri için başlangıç tarihi
my $end_date = 'end_date_example'; # string | createdAt değeri için bitiş tarihi
my $start_updated_at = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | updatedAt değeri için başlangıç tarihi
my $end_updated_at = 'end_updated_at_example'; # string | updatedAt değeri için bitiş tarihi

eval { 
    my $result = $api_instance->order_refund_requests_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, order => $order, member => $member, code => $code, status => $status, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderRefundRequestApi->order_refund_requests_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **int**| Sipariş id | [optional] 
 **member** | **int**| Üye id | [optional] 
 **code** | **string**| Sipariş İptal Talebi kodu | [optional] 
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi | [optional] 
 **start_date** | **DateTime**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **DateTime**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_refund_requests_id_delete**
> order_refund_requests_id_delete(id => $id)

Sipariş İptal Talebi Silme

Kalıcı olarak ilgili Sipariş İptal Talebini siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderRefundRequestApi;
my $api_instance = WWW::SwaggerClient::OrderRefundRequestApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş İptal Talebi nesnesinin id değeri

eval { 
    $api_instance->order_refund_requests_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling OrderRefundRequestApi->order_refund_requests_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş İptal Talebi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_refund_requests_id_get**
> OrderRefundRequest order_refund_requests_id_get(id => $id)

Sipariş İptal Talebi Alma

İlgili Sipariş İptal Talebini getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderRefundRequestApi;
my $api_instance = WWW::SwaggerClient::OrderRefundRequestApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş İptal Talebi nesnesinin id değeri

eval { 
    my $result = $api_instance->order_refund_requests_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderRefundRequestApi->order_refund_requests_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş İptal Talebi nesnesinin id değeri | 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_refund_requests_id_put**
> OrderRefundRequest order_refund_requests_id_put(id => $id, order_refund_request => $order_refund_request)

Sipariş İptal Talebi Güncelleme

İlgili Sipariş İptal Talebini günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderRefundRequestApi;
my $api_instance = WWW::SwaggerClient::OrderRefundRequestApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş İptal Talebi nesnesinin id değeri
my $order_refund_request = WWW::SwaggerClient::Object::OrderRefundRequest->new(); # OrderRefundRequest | OrderRefundRequest nesnesi

eval { 
    my $result = $api_instance->order_refund_requests_id_put(id => $id, order_refund_request => $order_refund_request);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderRefundRequestApi->order_refund_requests_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş İptal Talebi nesnesinin id değeri | 
 **order_refund_request** | [**OrderRefundRequest**](OrderRefundRequest.md)| OrderRefundRequest nesnesi | 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_refund_requests_post**
> OrderRefundRequest order_refund_requests_post(order_refund_request => $order_refund_request)

Sipariş İptal Talebi Oluşturma

Yeni bir Sipariş İptal Talebi oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::OrderRefundRequestApi;
my $api_instance = WWW::SwaggerClient::OrderRefundRequestApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $order_refund_request = WWW::SwaggerClient::Object::OrderRefundRequest->new(); # OrderRefundRequest | OrderRefundRequest nesnesi

eval { 
    my $result = $api_instance->order_refund_requests_post(order_refund_request => $order_refund_request);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling OrderRefundRequestApi->order_refund_requests_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_refund_request** | [**OrderRefundRequest**](OrderRefundRequest.md)| OrderRefundRequest nesnesi | 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

