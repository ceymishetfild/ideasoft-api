# WWW::SwaggerClient::PaymentProviderApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::PaymentProviderApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**payment_providers_get**](PaymentProviderApi.md#payment_providers_get) | **GET** /payment_providers | Ödeme Altyapısı Sağlayıcısı Listesi Alma
[**payment_providers_id_get**](PaymentProviderApi.md#payment_providers_id_get) | **GET** /payment_providers/{id} | Ödeme Altyapısı Sağlayıcısı Alma


# **payment_providers_get**
> PaymentProvider payment_providers_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, code => $code, name => $name)

Ödeme Altyapısı Sağlayıcısı Listesi Alma

Ödeme Altyapısı Sağlayıcısı listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PaymentProviderApi;
my $api_instance = WWW::SwaggerClient::PaymentProviderApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $code = 'code_example'; # string | Ödeme Altyapısı kodu
my $name = 'name_example'; # string | Ödeme Altyapısı adı

eval { 
    my $result = $api_instance->payment_providers_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, code => $code, name => $name);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling PaymentProviderApi->payment_providers_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **code** | **string**| Ödeme Altyapısı kodu | [optional] 
 **name** | **string**| Ödeme Altyapısı adı | [optional] 

### Return type

[**PaymentProvider**](PaymentProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **payment_providers_id_get**
> PaymentProvider payment_providers_id_get(id => $id)

Ödeme Altyapısı Sağlayıcısı Alma

İlgili Ödeme Altyapısı Sağlayıcısını getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PaymentProviderApi;
my $api_instance = WWW::SwaggerClient::PaymentProviderApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ödeme Altyapııs Sağlayıcısı nesnesinin id değeri

eval { 
    my $result = $api_instance->payment_providers_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling PaymentProviderApi->payment_providers_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ödeme Altyapııs Sağlayıcısı nesnesinin id değeri | 

### Return type

[**PaymentProvider**](PaymentProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

