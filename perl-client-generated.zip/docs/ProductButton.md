# WWW::SwaggerClient::Object::ProductButton

## Load the model package
```perl
use WWW::SwaggerClient::Object::ProductButton;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ürün ve stok butonu nesnesi kimlik değeri. | [optional] 
**fast_shipping** | **string** | Hızlı gönderi butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hızlı kargo butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hızlı kargo butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**same_day_shipping** | **string** | Aynı gün kargo butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aynı gün kargo butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Aynı gün kargo butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**three_days_delivery** | **string** | 3 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 3 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 3 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**five_days_delivery** | **string** | 5 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 5 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 5 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**seven_days_delivery** | **string** | 7 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 7 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 7 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**free_shipping** | **string** | Kargo bedava butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kargo bedava butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kargo bedava butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**delivery_from_stock** | **string** | Stoktan teslim butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Stoktan teslim butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Stoktan teslim butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**pre_ordered_product** | **string** | Ön siparişli stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Ön siparişli ürün butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Ön siparişli ürün butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**limited_stock** | **string** | Sınırlı stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sınırlı stok butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sınırlı stok butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**ask_stock** | **string** | Stok sorunuz butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Stok sorunuz butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Stok sorunuz butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**campaigned_product** | **string** | Kampanyalı stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalı ürün butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalı ürün butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


