# WWW::SwaggerClient::ProductPriceApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ProductPriceApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_prices_get**](ProductPriceApi.md#product_prices_get) | **GET** /product_prices | Ürün Fiyat Listesi Alma
[**product_prices_id_delete**](ProductPriceApi.md#product_prices_id_delete) | **DELETE** /product_prices/{id} | Ürün Fiyat Silme
[**product_prices_id_get**](ProductPriceApi.md#product_prices_id_get) | **GET** /product_prices/{id} | Ürün Fiyat Alma
[**product_prices_id_put**](ProductPriceApi.md#product_prices_id_put) | **PUT** /product_prices/{id} | Ürün Fiyat Güncelleme
[**product_prices_post**](ProductPriceApi.md#product_prices_post) | **POST** /product_prices | Ürün Fiyat Oluşturma


# **product_prices_get**
> ProductPrice product_prices_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, type => $type, product => $product)

Ürün Fiyat Listesi Alma

Ürün Fiyat listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductPriceApi;
my $api_instance = WWW::SwaggerClient::ProductPriceApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $type = 56; # int | Ürün fiyat tipi
my $product = 56; # int | Ürün id

eval { 
    my $result = $api_instance->product_prices_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, type => $type, product => $product);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductPriceApi->product_prices_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **type** | **int**| Ürün fiyat tipi | [optional] 
 **product** | **int**| Ürün id | [optional] 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_prices_id_delete**
> product_prices_id_delete(id => $id)

Ürün Fiyat Silme

Kalıcı olarak ilgili Ürün Fiyatını siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductPriceApi;
my $api_instance = WWW::SwaggerClient::ProductPriceApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Fiyat nesnesinin id değeri

eval { 
    $api_instance->product_prices_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling ProductPriceApi->product_prices_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Fiyat nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_prices_id_get**
> ProductPrice product_prices_id_get(id => $id)

Ürün Fiyat Alma

İlgili Ürün Fiyatını getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductPriceApi;
my $api_instance = WWW::SwaggerClient::ProductPriceApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Fiyat nesnesinin id değeri

eval { 
    my $result = $api_instance->product_prices_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductPriceApi->product_prices_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Fiyat nesnesinin id değeri | 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_prices_id_put**
> ProductPrice product_prices_id_put(id => $id, product_price => $product_price)

Ürün Fiyat Güncelleme

İlgili Ürün Fiyatını günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductPriceApi;
my $api_instance = WWW::SwaggerClient::ProductPriceApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Ürün Fiyat nesnesinin id değeri
my $product_price = WWW::SwaggerClient::Object::ProductPrice->new(); # ProductPrice | ProductPrice nesnesi

eval { 
    my $result = $api_instance->product_prices_id_put(id => $id, product_price => $product_price);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductPriceApi->product_prices_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Fiyat nesnesinin id değeri | 
 **product_price** | [**ProductPrice**](ProductPrice.md)| ProductPrice nesnesi | 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_prices_post**
> ProductPrice product_prices_post(product_price => $product_price)

Ürün Fiyat Oluşturma

Yeni bir Ürün Fiyat oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ProductPriceApi;
my $api_instance = WWW::SwaggerClient::ProductPriceApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $product_price = WWW::SwaggerClient::Object::ProductPrice->new(); # ProductPrice | ProductPrice nesnesi

eval { 
    my $result = $api_instance->product_prices_post(product_price => $product_price);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ProductPriceApi->product_prices_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_price** | [**ProductPrice**](ProductPrice.md)| ProductPrice nesnesi | 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

