# WWW::SwaggerClient::Object::ProductPrice

## Load the model package
```perl
use WWW::SwaggerClient::Object::ProductPrice;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ürün fiyatı nesnesi kimlik değeri. | [optional] 
**value** | **double** | Ürün fiyatı değeri. | 
**type** | **int** | Ürün fiyatı indexi. Fiyat 2, Fiyat 3 gibi. | 
**product** | [**Product**](Product.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


