# WWW::SwaggerClient::ShopPreferenceApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ShopPreferenceApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**preferences_get**](ShopPreferenceApi.md#preferences_get) | **GET** /preferences | Tanımlamalar Listesi Alma
[**preferences_id_get**](ShopPreferenceApi.md#preferences_id_get) | **GET** /preferences/{id} | Tanımlamalar Alma
[**preferences_id_put**](ShopPreferenceApi.md#preferences_id_put) | **PUT** /preferences/{id} | Tanımlamalar Güncelleme


# **preferences_get**
> ShopPreference preferences_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, var_key => $var_key)

Tanımlamalar Listesi Alma

Tanımlamalar listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ShopPreferenceApi;
my $api_instance = WWW::SwaggerClient::ShopPreferenceApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $var_key = 'var_key_example'; # string | Tanımlama varKey değeri

eval { 
    my $result = $api_instance->preferences_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, var_key => $var_key);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ShopPreferenceApi->preferences_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 100]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **var_key** | **string**| Tanımlama varKey değeri | [optional] 

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **preferences_id_get**
> ShopPreference preferences_id_get(id => $id)

Tanımlamalar Alma

İlgili Tanımlamayı getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ShopPreferenceApi;
my $api_instance = WWW::SwaggerClient::ShopPreferenceApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Tanımlama nesnesinin id değeri

eval { 
    my $result = $api_instance->preferences_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ShopPreferenceApi->preferences_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tanımlama nesnesinin id değeri | 

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **preferences_id_put**
> ShopPreference preferences_id_put(id => $id, shop_preference => $shop_preference)

Tanımlamalar Güncelleme

İlgili Tanımlamayı günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::ShopPreferenceApi;
my $api_instance = WWW::SwaggerClient::ShopPreferenceApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Tanımlama nesnesinin id değeri
my $shop_preference = WWW::SwaggerClient::Object::ShopPreference->new(); # ShopPreference |  nesnesi

eval { 
    my $result = $api_instance->preferences_id_put(id => $id, shop_preference => $shop_preference);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ShopPreferenceApi->preferences_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tanımlama nesnesinin id değeri | 
 **shop_preference** | [**ShopPreference**](ShopPreference.md)|  nesnesi | 

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

