# WWW::SwaggerClient::PreOrderInfoApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::PreOrderInfoApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**pre_order_infos_get**](PreOrderInfoApi.md#pre_order_infos_get) | **GET** /pre_order_infos | Sipariş Öncesi Bilgisi Listesi Alma
[**pre_order_infos_id_delete**](PreOrderInfoApi.md#pre_order_infos_id_delete) | **DELETE** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Silme
[**pre_order_infos_id_get**](PreOrderInfoApi.md#pre_order_infos_id_get) | **GET** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Alma
[**pre_order_infos_id_put**](PreOrderInfoApi.md#pre_order_infos_id_put) | **PUT** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Güncelleme
[**pre_order_infos_post**](PreOrderInfoApi.md#pre_order_infos_post) | **POST** /pre_order_infos | Sipariş Öncesi Bilgisi Oluşturma


# **pre_order_infos_get**
> PreOrderInfo pre_order_infos_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, session_id => $session_id, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at)

Sipariş Öncesi Bilgisi Listesi Alma

Sipariş Öncesi Bilgisi listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PreOrderInfoApi;
my $api_instance = WWW::SwaggerClient::PreOrderInfoApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $session_id = 'session_id_example'; # string | Sipariş Öncesi Bilgisi session id.
my $start_date = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | createdAt değeri için başlangıç tarihi
my $end_date = 'end_date_example'; # string | createdAt değeri için bitiş tarihi
my $start_updated_at = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | updatedAt değeri için başlangıç tarihi
my $end_updated_at = 'end_updated_at_example'; # string | updatedAt değeri için bitiş tarihi

eval { 
    my $result = $api_instance->pre_order_infos_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, session_id => $session_id, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling PreOrderInfoApi->pre_order_infos_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **session_id** | **string**| Sipariş Öncesi Bilgisi session id. | [optional] 
 **start_date** | **DateTime**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **DateTime**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **pre_order_infos_id_delete**
> pre_order_infos_id_delete(id => $id)

Sipariş Öncesi Bilgisi Silme

Kalıcı olarak ilgili Sipariş Öncesi Bilgisini siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PreOrderInfoApi;
my $api_instance = WWW::SwaggerClient::PreOrderInfoApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş Öncesi Bilgisi nesnesinin id değeri

eval { 
    $api_instance->pre_order_infos_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling PreOrderInfoApi->pre_order_infos_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **pre_order_infos_id_get**
> PreOrderInfo pre_order_infos_id_get(id => $id)

Sipariş Öncesi Bilgisi Alma

İlgili Sipariş Öncesi Bilgisini getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PreOrderInfoApi;
my $api_instance = WWW::SwaggerClient::PreOrderInfoApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş Öncesi Bilgisi nesnesinin id değeri

eval { 
    my $result = $api_instance->pre_order_infos_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling PreOrderInfoApi->pre_order_infos_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **pre_order_infos_id_put**
> PreOrderInfo pre_order_infos_id_put(id => $id, pre_order_info => $pre_order_info)

Sipariş Öncesi Bilgisi Güncelleme

İlgili Sipariş Öncesi Bilgisini günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PreOrderInfoApi;
my $api_instance = WWW::SwaggerClient::PreOrderInfoApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Sipariş Öncesi Bilgisi nesnesinin id değeri
my $pre_order_info = WWW::SwaggerClient::Object::PreOrderInfo->new(); # PreOrderInfo |  nesnesi

eval { 
    my $result = $api_instance->pre_order_infos_id_put(id => $id, pre_order_info => $pre_order_info);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling PreOrderInfoApi->pre_order_infos_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 
 **pre_order_info** | [**PreOrderInfo**](PreOrderInfo.md)|  nesnesi | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **pre_order_infos_post**
> PreOrderInfo pre_order_infos_post(pre_order_info => $pre_order_info)

Sipariş Öncesi Bilgisi Oluşturma

Yeni bir Sipariş Öncesi Bilgisi oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PreOrderInfoApi;
my $api_instance = WWW::SwaggerClient::PreOrderInfoApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $pre_order_info = WWW::SwaggerClient::Object::PreOrderInfo->new(); # PreOrderInfo |  nesnesi

eval { 
    my $result = $api_instance->pre_order_infos_post(pre_order_info => $pre_order_info);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling PreOrderInfoApi->pre_order_infos_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pre_order_info** | [**PreOrderInfo**](PreOrderInfo.md)|  nesnesi | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

