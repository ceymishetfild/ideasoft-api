# WWW::SwaggerClient::Object::Shipment

## Load the model package
```perl
use WWW::SwaggerClient::Object::Shipment;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Teslimat nesnesi kimlik değeri. | [optional] 
**barcode** | **string** | Teslimat barkodu. | [optional] 
**waybill_no** | **string** | Teslimat fatura numarası. | [optional] 
**invoice_key** | **string** | Teslimat irsaliye makbuzu numarası. | [optional] 
**cargo_office** | **string** | Teslimatın kargo şubesi | [optional] 
**code** | **string** | Teslimat kodu. Kargo takip kodu. | [optional] 
**delivery_type** | **string** | Teslimat tipi | [optional] 
**invoice_included** | **string** | Faturanın pakete dahillik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Dahil.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Dahil değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**pay_at_door_amount** | **double** | Kapıda ödeme hizmeti bedeli. | [optional] 
**created_at** | **DateTime** | Teslimat nesnesinin oluşturulma zamanı. | [optional] 
**status** | **int** | Teslimat nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**order** | [**Order**](Order.md) | Sipariş nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


