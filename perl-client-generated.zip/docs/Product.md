# WWW::SwaggerClient::Object::Product

## Load the model package
```perl
use WWW::SwaggerClient::Object::Product;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ürün nesnesi kimlik değeri. | [optional] 
**name** | **string** | Ürünün adı | 
**slug** | **string** | Slug değeri ilgili nesnenin Url değeridir. | [optional] 
**full_name** | **string** | Ürünün tam adı. Bu değer bir varyant için ana ürünün adı ve varyant adının birleşiminden oluşur. Örneğin Kırmızı varyantı için Kalem Kırmızı olur. | 
**sku** | **string** | Ürünün stok kodu. ID değeri gibi eşsiz bir kimlik değeridir. | 
**barcode** | **string** | Ürünün barkodu. | [optional] 
**price1** | **double** | Ürünün Fiyat 1 bilgisi. | 
**warranty** | **int** | Ürünün garanti süresi. | [optional] 
**tax** | **int** | Ürünün KDV oranı. | [optional] 
**stock_amount** | **double** | Ürünün stok tipi cinsinden miktarı. | [optional] 
**volumetric_weight** | **double** | Ürünün desisi. | [optional] 
**buying_price** | **double** | Ürünün alış fiyatı. | [optional] 
**stock_type_label** | **string** | Ürünün stok tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Piece&lt;/code&gt; : Stok tipi birimi Adet&lt;br&gt;&lt;code&gt;cm&lt;/code&gt; : Stok tipi birimi Santimetre&lt;br&gt;&lt;code&gt;Dozen&lt;/code&gt; : Stok tipi birimi Düzine&lt;br&gt;&lt;code&gt;gram&lt;/code&gt; : Stok tipi birimi Gram&lt;br&gt;&lt;code&gt;kg&lt;/code&gt; : Stok tipi birimi Kilogram&lt;br&gt;&lt;code&gt;Person&lt;/code&gt; : Stok tipi birimi Kişi&lt;br&gt;&lt;code&gt;Package&lt;/code&gt; : Stok tipi birimi Paket&lt;br&gt;&lt;code&gt;metre&lt;/code&gt; : Stok tipi birimi Metre&lt;br&gt;&lt;code&gt;m2&lt;/code&gt; : Stok tipi birimi Metrekare&lt;br&gt;&lt;code&gt;pair&lt;/code&gt; : Stok tipi birimi Çift&lt;br&gt;&lt;/div&gt; | [optional] 
**discount** | **double** | Ürünün indirim değeri. Örneğin; discountType 1 olursa %5, 0 olursa 5 tl anlamına gelir. | [optional] 
**discount_type** | **int** | Ürünün indirim tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : İndirim yüzdesi&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : İndirimli fiyat&lt;br&gt;&lt;/div&gt; | [optional] 
**money_order_discount** | **double** | Havale indirimi yüzdesi. | [optional] 
**status** | **int** | Ürün nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;/div&gt; | 
**tax_included** | **string** | Ürün fiyatlarına KDV dahil olup olmadığın belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : KDV Dahil&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : KDV Hariç&lt;br&gt;&lt;/div&gt; | [optional] 
**distributor** | **string** | Ürünün distribütör bilgisi | [optional] 
**is_gifted** | **string** | Ürünün hediyeli olup olmadığını belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hediyeli&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hediyeli Değil&lt;br&gt;&lt;/div&gt; | [optional] 
**gift** | **string** | Ürünün yanında hediye olarak vermek istediğiniz hediyeyi bu alanda metin ya da rakamla belirtebilirsiniz. | [optional] 
**custom_shipping_disabled** | **string** | Kargo ücreti için sistemin kullanılıp kullanılmama değerini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sistem seçeneği seçili&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sistem seçeneği seçili değil&lt;br&gt;&lt;/div&gt; | [optional] 
**custom_shipping_cost** | **double** | Sistem seçeneği seçilmemişse ürün için girilmesi gereken kargo ücreti. | [optional] 
**market_price_detail** | **string** | Ürünün piyasa fiyatı | [optional] 
**created_at** | **DateTime** | Ürün nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Ürün nesnesinin güncellenme zamanı. | [optional] 
**meta_keywords** | **string** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] 
**meta_description** | **string** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] 
**page_title** | **string** | Ürün nesnesinin etiket başlığı. | [optional] 
**has_option** | **string** | Ürünün varyantının olup olmadığı değerini belirtir. (API otomatik olarak bu değeri atar.)&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Varyantı var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Varyantı yok&lt;br&gt;&lt;/div&gt; | [optional] 
**short_details** | **string** | Ürünün kısa açıklaması. | [optional] 
**search_keywords** | **string** | Ziyaretçilerinizin site içindeki ürünlerinizin hangi anahtar kelimelerine göre bulacağını belirler.Kelimeler arasında virgül bırakılarak girilmelidir.(etiket1,etiket2) | [optional] 
**installment_threshold** | **string** | Ürüne özel yasal veya isteğe bağlı belirleyebiliceğiniz taksit adedini belirtir. Ürüne özel bir belirleme yapmak istemiyorsanız &#39;-&#39; işareti kullanabilirsiniz. | [optional] 
**home_sort_order** | **int** | Anasayfa vitrini sırası. | [optional] 
**popular_sort_order** | **int** | Popüler ürünler vitrini sırası. | [optional] 
**brand_sort_order** | **int** | Marka vitrini sırası. | [optional] 
**featured_sort_order** | **int** | Sponsor ürünler vitrini sırası | [optional] 
**campaigned_sort_order** | **int** | Kampanyalı ürünler vitrini sırası. | [optional] 
**new_sort_order** | **int** | Yeni ürünler vitrini sırası. | [optional] 
**discounted_sort_order** | **int** | İndirimli ürünler vitrini sırası | [optional] 
**brand** | [**Brand**](Brand.md) | Marka nesnesi. | [optional] 
**currency** | [**Currency**](Currency.md) | Kur nesnesi. | 
**parent** | [**Product**](Product.md) | Ana ürün olan ürün nesnesi. | [optional] 
**countdown** | [**ProductToCountDown**](ProductToCountDown.md) | Ürün geri sayım bağı nesnesi. | [optional] 
**prices** | [**ARRAY[ProductPrice]**](ProductPrice.md) | Ürünün fiyatları. | [optional] 
**images** | [**ARRAY[ProductImage]**](ProductImage.md) | Ürünün resimleri. | [optional] 
**product_to_categories** | [**ARRAY[ProductToCategory]**](ProductToCategory.md) | Ürünün kategorileri. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


