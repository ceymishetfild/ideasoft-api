# WWW::SwaggerClient::Object::PaymentProvider

## Load the model package
```perl
use WWW::SwaggerClient::Object::PaymentProvider;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ödeme altyapısı sağlayıcısı nesnesi kimlik değeri. | [optional] 
**code** | **string** | Ödeme altyapısı sağlayıcısı için ön tanımlanmış kod değeri. | 
**name** | **string** | Ödeme altyapısı sağlayıcısı için isim değeri. | 
**status** | **string** | Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer. | 
**payment_type** | [**PaymentType**](PaymentType.md) | Ödeme tipi nesnesi. | 
**settings** | [**ARRAY[PaymentProviderSetting]**](PaymentProviderSetting.md) | Ödeme altyapısı sağlayıcısı ayarları | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


