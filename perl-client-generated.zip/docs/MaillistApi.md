# WWW::SwaggerClient::MaillistApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::MaillistApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**maillists_get**](MaillistApi.md#maillists_get) | **GET** /maillists | Mail Listesi Listesi Alma
[**maillists_id_delete**](MaillistApi.md#maillists_id_delete) | **DELETE** /maillists/{id} | Mail Listesi Silme
[**maillists_id_get**](MaillistApi.md#maillists_id_get) | **GET** /maillists/{id} | Mail Listesi Alma
[**maillists_id_put**](MaillistApi.md#maillists_id_put) | **PUT** /maillists/{id} | Mail Listesi Güncelleme
[**maillists_post**](MaillistApi.md#maillists_post) | **POST** /maillists | Mail Listesi Oluşturma


# **maillists_get**
> Maillist maillists_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name, email => $email, maillist_group => $maillist_group, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at)

Mail Listesi Listesi Alma

Mail Listesi listesini verir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MaillistApi;
my $api_instance = WWW::SwaggerClient::MaillistApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $name = 'name_example'; # string | Mail Listesi adı.
my $email = 'email_example'; # string | Mail Listesi e-mail.
my $maillist_group = 56; # int | Mail Listesi Grubu id
my $start_date = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | createdAt değeri için başlangıç tarihi
my $end_date = 'end_date_example'; # string | createdAt değeri için bitiş tarihi
my $start_updated_at = DateTime->from_epoch(epoch => str2time('2013-10-20')); # DateTime | updatedAt değeri için başlangıç tarihi
my $end_updated_at = 'end_updated_at_example'; # string | updatedAt değeri için bitiş tarihi

eval { 
    my $result = $api_instance->maillists_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name, email => $email, maillist_group => $maillist_group, start_date => $start_date, end_date => $end_date, start_updated_at => $start_updated_at, end_updated_at => $end_updated_at);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MaillistApi->maillists_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **string**| Mail Listesi adı. | [optional] 
 **email** | **string**| Mail Listesi e-mail. | [optional] 
 **maillist_group** | **int**| Mail Listesi Grubu id | [optional] 
 **start_date** | **DateTime**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **DateTime**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillists_id_delete**
> maillists_id_delete(id => $id)

Mail Listesi Silme

Kalıcı olarak ilgili Mail Listesini siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MaillistApi;
my $api_instance = WWW::SwaggerClient::MaillistApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Mail Listesi nesnesinin id değeri

eval { 
    $api_instance->maillists_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling MaillistApi->maillists_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillists_id_get**
> Maillist maillists_id_get(id => $id)

Mail Listesi Alma

İlgili Mail Listesini getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MaillistApi;
my $api_instance = WWW::SwaggerClient::MaillistApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Mail Listesi nesnesinin id değeri

eval { 
    my $result = $api_instance->maillists_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MaillistApi->maillists_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi nesnesinin id değeri | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillists_id_put**
> Maillist maillists_id_put(id => $id, maillist => $maillist)

Mail Listesi Güncelleme

İlgili Mail Listesini günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MaillistApi;
my $api_instance = WWW::SwaggerClient::MaillistApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Mail Listesi nesnesinin id değeri
my $maillist = WWW::SwaggerClient::Object::Maillist->new(); # Maillist |  nesnesi

eval { 
    my $result = $api_instance->maillists_id_put(id => $id, maillist => $maillist);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MaillistApi->maillists_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi nesnesinin id değeri | 
 **maillist** | [**Maillist**](Maillist.md)|  nesnesi | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillists_post**
> Maillist maillists_post(maillist => $maillist)

Mail Listesi Oluşturma

Yeni bir Mail Listesini oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::MaillistApi;
my $api_instance = WWW::SwaggerClient::MaillistApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $maillist = WWW::SwaggerClient::Object::Maillist->new(); # Maillist |  nesnesi

eval { 
    my $result = $api_instance->maillists_post(maillist => $maillist);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling MaillistApi->maillists_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **maillist** | [**Maillist**](Maillist.md)|  nesnesi | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

