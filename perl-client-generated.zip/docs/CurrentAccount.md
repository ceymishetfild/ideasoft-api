# WWW::SwaggerClient::Object::CurrentAccount

## Load the model package
```perl
use WWW::SwaggerClient::Object::CurrentAccount;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Cari hesap nesnesi kimlik değeri. | [optional] 
**code** | **string** | Cari hesap için düzenlenebilir bir kod değeri. | [optional] 
**title** | **string** | Cari hesap nesnesinin başlığı. | 
**balance** | **double** | Cari hesabın bakiyesi. | [optional] 
**risk_limit** | **double** | Cari hesap için belirlenmiş risk limiti. | [optional] 
**created_at** | **DateTime** | Cari hesap nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Cari hesap nesnesinin güncellenme zamanı. | [optional] 
**member** | [**Member**](Member.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


