# WWW::SwaggerClient::QuickCartApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::QuickCartApi;
```

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**quick_carts_get**](QuickCartApi.md#quick_carts_get) | **GET** /quick_carts | Hızlı Satın Al Bağlantısı Alma
[**quick_carts_id_delete**](QuickCartApi.md#quick_carts_id_delete) | **DELETE** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Silme
[**quick_carts_id_get**](QuickCartApi.md#quick_carts_id_get) | **GET** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Alma
[**quick_carts_id_put**](QuickCartApi.md#quick_carts_id_put) | **PUT** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Güncelleme
[**quick_carts_post**](QuickCartApi.md#quick_carts_post) | **POST** /quick_carts | Hızlı Satın Al Bağlantısı Oluşturma


# **quick_carts_get**
> QuickCart quick_carts_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name)

Hızlı Satın Al Bağlantısı Alma

Hızlı Satın Al Bağlantısı döndürür.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::QuickCartApi;
my $api_instance = WWW::SwaggerClient::QuickCartApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $sort = 'sort_example'; # string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
my $limit = 56; # int | Bir sayfada gelecek sonuç adedi
my $page = 56; # int | Hangi sayfadan başlanacağı
my $since_id = 56; # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
my $ids = 'ids_example'; # string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
my $name = 'name_example'; # string | Hızlı Satın Al Bağlantısı adı

eval { 
    my $result = $api_instance->quick_carts_get(sort => $sort, limit => $limit, page => $page, since_id => $since_id, ids => $ids, name => $name);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling QuickCartApi->quick_carts_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **string**| Hızlı Satın Al Bağlantısı adı | [optional] 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **quick_carts_id_delete**
> quick_carts_id_delete(id => $id)

Hızlı Satın Al Bağlantısı Silme

Kalıcı olarak ilgili Hızlı Satın Al Bağlantısını siler.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::QuickCartApi;
my $api_instance = WWW::SwaggerClient::QuickCartApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Hızlı Satın Al nesnesinin id değeri

eval { 
    $api_instance->quick_carts_id_delete(id => $id);
};
if ($@) {
    warn "Exception when calling QuickCartApi->quick_carts_id_delete: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Hızlı Satın Al nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **quick_carts_id_get**
> QuickCart quick_carts_id_get(id => $id)

Hızlı Satın Al Bağlantısı Alma

İlgili Hızlı Satın Al Bağlantısını getirir.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::QuickCartApi;
my $api_instance = WWW::SwaggerClient::QuickCartApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Hızlı Satın Al nesnesinin id değeri

eval { 
    my $result = $api_instance->quick_carts_id_get(id => $id);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling QuickCartApi->quick_carts_id_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Hızlı Satın Al nesnesinin id değeri | 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **quick_carts_id_put**
> QuickCart quick_carts_id_put(id => $id, quick_cart => $quick_cart)

Hızlı Satın Al Bağlantısı Güncelleme

İlgili Hızlı Satın Al Bağlantısını günceller.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::QuickCartApi;
my $api_instance = WWW::SwaggerClient::QuickCartApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $id = 56; # int | Hızlı Satın Al nesnesinin id değeri
my $quick_cart = WWW::SwaggerClient::Object::QuickCart->new(); # QuickCart |  nesnesi

eval { 
    my $result = $api_instance->quick_carts_id_put(id => $id, quick_cart => $quick_cart);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling QuickCartApi->quick_carts_id_put: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Hızlı Satın Al nesnesinin id değeri | 
 **quick_cart** | [**QuickCart**](QuickCart.md)|  nesnesi | 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **quick_carts_post**
> QuickCart quick_carts_post(quick_cart => $quick_cart)

Hızlı Satın Al Bağlantısı Oluşturma

Yeni bir Hızlı Satın Al Bağlantısı oluşturur.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::QuickCartApi;
my $api_instance = WWW::SwaggerClient::QuickCartApi->new(

    # Configure OAuth2 access token for authorization: OAuth2
    access_token => 'YOUR_ACCESS_TOKEN',
);

my $quick_cart = WWW::SwaggerClient::Object::QuickCart->new(); # QuickCart |  nesnesi

eval { 
    my $result = $api_instance->quick_carts_post(quick_cart => $quick_cart);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling QuickCartApi->quick_carts_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **quick_cart** | [**QuickCart**](QuickCart.md)|  nesnesi | 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

