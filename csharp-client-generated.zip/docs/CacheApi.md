# IO.Swagger.Api.CacheApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CacheDelete**](CacheApi.md#cachedelete) | **DELETE** /cache | Önbellek Silme


<a name="cachedelete"></a>
# **CacheDelete**
> void CacheDelete ()

Önbellek Silme

Kalıcı olarak Önbelleği siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CacheDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CacheApi();

            try
            {
                // Önbellek Silme
                apiInstance.CacheDelete();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CacheApi.CacheDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

