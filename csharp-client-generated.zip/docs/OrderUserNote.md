# IO.Swagger.Model.OrderUserNote
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Sipariş yönetici notu nesnesi kimlik değeri. | [optional] 
**UserEmail** | **string** | Yöneticinin(admin) e-mail adresi. | 
**UserFirstname** | **string** | Yöneticinin(admin) ismi. | [optional] 
**UserSurname** | **string** | Yöneticinin(admin) soy ismi. | [optional] 
**Note** | **string** | Yöneticinin(admin) sipariş için girdiği not. | 
**CreatedAt** | **DateTime?** | Sipariş yönetici notu nesnesinin oluşturulma zamanı. | 
**UpdatedAt** | **DateTime?** | Sipariş yönetici notu nesnesinin güncellenme zamanı. | 
**Order** | [**Order**](Order.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

