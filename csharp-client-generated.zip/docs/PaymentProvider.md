# IO.Swagger.Model.PaymentProvider
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ödeme altyapısı sağlayıcısı nesnesi kimlik değeri. | [optional] 
**Code** | **string** | Ödeme altyapısı sağlayıcısı için ön tanımlanmış kod değeri. | 
**Name** | **string** | Ödeme altyapısı sağlayıcısı için isim değeri. | 
**Status** | **string** | Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer. | 
**PaymentType** | [**PaymentType**](PaymentType.md) | Ödeme tipi nesnesi. | 
**Settings** | [**List&lt;PaymentProviderSetting&gt;**](PaymentProviderSetting.md) | Ödeme altyapısı sağlayıcısı ayarları | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

