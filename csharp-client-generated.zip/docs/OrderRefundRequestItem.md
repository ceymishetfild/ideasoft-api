# IO.Swagger.Model.OrderRefundRequestItem
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Sipariş iptal talebi kalemi nesnesi kimlik değeri. | [optional] 
**Amount** | **float?** | Sipariş iptal talebi istenen ürün miktarı. | 
**Reason** | **string** | Sipariş iptal talebi sebebi. Tanımlı dört seçenekten biri seçilmelidir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Ürünü iade etmek istiyorum.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Ürünü değiştirmek istiyorum.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Faturadaki ürünler ile bana gelen ürünler farklı.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Diğer&lt;/code&gt; : &lt;br&gt;&lt;/div&gt; | 
**Details** | **string** | Sipariş iptal talebinin detaylı açıklaması. | 
**CreatedAt** | **DateTime?** | Sipariş iptal talebi kalemi nesnesinin oluşturulma zamanı. | [optional] 
**UpdatedAt** | **DateTime?** | Sipariş iptal talebi kalemi nesnesinin güncellenme zamanı. | [optional] 
**OrderItem** | [**OrderItem**](OrderItem.md) |  | [optional] 
**OrderRefundRequest** | [**OrderRefundRequest**](OrderRefundRequest.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

