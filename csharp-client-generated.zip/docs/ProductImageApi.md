# IO.Swagger.Api.ProductImageApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductImagesGet**](ProductImageApi.md#productimagesget) | **GET** /product_images | Ürün Resim Listesi Alma
[**ProductImagesIdDelete**](ProductImageApi.md#productimagesiddelete) | **DELETE** /product_images/{id} | Ürün Resim Silme
[**ProductImagesIdGet**](ProductImageApi.md#productimagesidget) | **GET** /product_images/{id} | Ürün Resim Alma
[**ProductImagesPost**](ProductImageApi.md#productimagespost) | **POST** /product_images | Ürün Resim Oluşturma


<a name="productimagesget"></a>
# **ProductImagesGet**
> ProductImage ProductImagesGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string ids = null, string fileName = null, int? product = null)

Ürün Resim Listesi Alma

Ürün Resim listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductImagesGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductImageApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var fileName = fileName_example;  // string | Ürün Resim dosya adı (optional) 
            var product = 56;  // int? | Ürün id (optional) 

            try
            {
                // Ürün Resim Listesi Alma
                ProductImage result = apiInstance.ProductImagesGet(sort, limit, page, sinceId, ids, fileName, product);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductImageApi.ProductImagesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **fileName** | **string**| Ürün Resim dosya adı | [optional] 
 **product** | **int?**| Ürün id | [optional] 

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productimagesiddelete"></a>
# **ProductImagesIdDelete**
> void ProductImagesIdDelete (int? id)

Ürün Resim Silme

Kalıcı olarak ilgili Ürün Resmini siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductImagesIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductImageApi();
            var id = 56;  // int? | Ürün Resmi nesnesinin id değeri

            try
            {
                // Ürün Resim Silme
                apiInstance.ProductImagesIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductImageApi.ProductImagesIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Resmi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productimagesidget"></a>
# **ProductImagesIdGet**
> ProductImage ProductImagesIdGet (int? id)

Ürün Resim Alma

İlgili Ürün Resmini getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductImagesIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductImageApi();
            var id = 56;  // int? | Ürün Resmi nesnesinin id değeri

            try
            {
                // Ürün Resim Alma
                ProductImage result = apiInstance.ProductImagesIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductImageApi.ProductImagesIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Resmi nesnesinin id değeri | 

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productimagespost"></a>
# **ProductImagesPost**
> ProductImage ProductImagesPost (ProductImage productImage)

Ürün Resim Oluşturma

Yeni bir Ürün Resim oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductImagesPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductImageApi();
            var productImage = new ProductImage(); // ProductImage |  nesnesi

            try
            {
                // Ürün Resim Oluşturma
                ProductImage result = apiInstance.ProductImagesPost(productImage);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductImageApi.ProductImagesPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productImage** | [**ProductImage**](ProductImage.md)|  nesnesi | 

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

