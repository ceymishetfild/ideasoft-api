# IO.Swagger.Api.SpecNameApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SpecNamesGet**](SpecNameApi.md#specnamesget) | **GET** /spec_names | Ürün Özelliği Listesi Alma
[**SpecNamesIdDelete**](SpecNameApi.md#specnamesiddelete) | **DELETE** /spec_names/{id} | Ürün Özelliği Silme
[**SpecNamesIdGet**](SpecNameApi.md#specnamesidget) | **GET** /spec_names/{id} | Ürün Özelliği Alma
[**SpecNamesIdPut**](SpecNameApi.md#specnamesidput) | **PUT** /spec_names/{id} | Ürün Özelliği Güncelleme
[**SpecNamesPost**](SpecNameApi.md#specnamespost) | **POST** /spec_names | Ürün Özelliği Oluşturma


<a name="specnamesget"></a>
# **SpecNamesGet**
> SpecName SpecNamesGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string ids = null, string name = null, int? specGroup = null, string choiceType = null)

Ürün Özelliği Listesi Alma

Ürün Özelliği listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecNamesGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecNameApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var name = name_example;  // string | Ürün Özelliği adı (optional) 
            var specGroup = 56;  // int? | Ürün özellik grubu id (optional) 
            var choiceType = choiceType_example;  // string | Status şu değerleri alabilir: <br><code>singular</code> : Tekil<br><code>plural</code> : Çoğul (optional) 

            try
            {
                // Ürün Özelliği Listesi Alma
                SpecName result = apiInstance.SpecNamesGet(sort, limit, page, sinceId, ids, name, specGroup, choiceType);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecNameApi.SpecNamesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **string**| Ürün Özelliği adı | [optional] 
 **specGroup** | **int?**| Ürün özellik grubu id | [optional] 
 **choiceType** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul | [optional] 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="specnamesiddelete"></a>
# **SpecNamesIdDelete**
> void SpecNamesIdDelete (int? id)

Ürün Özelliği Silme

Kalıcı olarak ilgili Ürün Özelliğini siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecNamesIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecNameApi();
            var id = 56;  // int? | Ürün Özellik nesnesinin id değeri

            try
            {
                // Ürün Özelliği Silme
                apiInstance.SpecNamesIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecNameApi.SpecNamesIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Özellik nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="specnamesidget"></a>
# **SpecNamesIdGet**
> SpecName SpecNamesIdGet (int? id)

Ürün Özelliği Alma

İlgili Ürün Özelliğini getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecNamesIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecNameApi();
            var id = 56;  // int? | Ürün Özellik nesnesinin id değeri

            try
            {
                // Ürün Özelliği Alma
                SpecName result = apiInstance.SpecNamesIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecNameApi.SpecNamesIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Özellik nesnesinin id değeri | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="specnamesidput"></a>
# **SpecNamesIdPut**
> SpecName SpecNamesIdPut (int? id, SpecName specName)

Ürün Özelliği Güncelleme

İlgili Ürün Özelliğini günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecNamesIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecNameApi();
            var id = 56;  // int? | Ürün Özellik nesnesinin id değeri
            var specName = new SpecName(); // SpecName |  nesnesi

            try
            {
                // Ürün Özelliği Güncelleme
                SpecName result = apiInstance.SpecNamesIdPut(id, specName);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecNameApi.SpecNamesIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Özellik nesnesinin id değeri | 
 **specName** | [**SpecName**](SpecName.md)|  nesnesi | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="specnamespost"></a>
# **SpecNamesPost**
> SpecName SpecNamesPost (SpecName specName)

Ürün Özelliği Oluşturma

Yeni bir Ürün Özelliği oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecNamesPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecNameApi();
            var specName = new SpecName(); // SpecName |  nesnesi

            try
            {
                // Ürün Özelliği Oluşturma
                SpecName result = apiInstance.SpecNamesPost(specName);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecNameApi.SpecNamesPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specName** | [**SpecName**](SpecName.md)|  nesnesi | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

