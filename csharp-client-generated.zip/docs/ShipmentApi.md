# IO.Swagger.Api.ShipmentApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ShipmentsGet**](ShipmentApi.md#shipmentsget) | **GET** /shipments | Teslimat Listesi Alma
[**ShipmentsIdDelete**](ShipmentApi.md#shipmentsiddelete) | **DELETE** /shipments/{id} | Teslimat Silme
[**ShipmentsIdGet**](ShipmentApi.md#shipmentsidget) | **GET** /shipments/{id} | Teslimat Alma
[**ShipmentsIdPut**](ShipmentApi.md#shipmentsidput) | **PUT** /shipments/{id} | Teslimat Güncelleme
[**ShipmentsPost**](ShipmentApi.md#shipmentspost) | **POST** /shipments | Teslimat Oluşturma


<a name="shipmentsget"></a>
# **ShipmentsGet**
> Shipment ShipmentsGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string code = null, string invoiceKey = null, string barcode = null, int? order = null, DateTime? startDate = null, string endDate = null, DateTime? startUpdatedAt = null, string endUpdatedAt = null)

Teslimat Listesi Alma

Teslimat listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShipmentsGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShipmentApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var code = code_example;  // string | Teslimat kodu (optional) 
            var invoiceKey = invoiceKey_example;  // string | Teslimat fatura anahtarı (optional) 
            var barcode = barcode_example;  // string | Teslimat barkodu (optional) 
            var order = 56;  // int? | Sipariş id (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 

            try
            {
                // Teslimat Listesi Alma
                Shipment result = apiInstance.ShipmentsGet(sort, limit, page, sinceId, code, invoiceKey, barcode, order, startDate, endDate, startUpdatedAt, endUpdatedAt);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShipmentApi.ShipmentsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **code** | **string**| Teslimat kodu | [optional] 
 **invoiceKey** | **string**| Teslimat fatura anahtarı | [optional] 
 **barcode** | **string**| Teslimat barkodu | [optional] 
 **order** | **int?**| Sipariş id | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shipmentsiddelete"></a>
# **ShipmentsIdDelete**
> void ShipmentsIdDelete (int? id)

Teslimat Silme

Kalıcı olarak ilgili Teslimatı siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShipmentsIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShipmentApi();
            var id = 56;  // int? | Teslimat nesnesinin id değeri

            try
            {
                // Teslimat Silme
                apiInstance.ShipmentsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShipmentApi.ShipmentsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Teslimat nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shipmentsidget"></a>
# **ShipmentsIdGet**
> Shipment ShipmentsIdGet (int? id)

Teslimat Alma

İlgili Teslimatı getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShipmentsIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShipmentApi();
            var id = 56;  // int? | Teslimat nesnesinin id değeri

            try
            {
                // Teslimat Alma
                Shipment result = apiInstance.ShipmentsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShipmentApi.ShipmentsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Teslimat nesnesinin id değeri | 

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shipmentsidput"></a>
# **ShipmentsIdPut**
> Shipment ShipmentsIdPut (int? id, Shipment shipment)

Teslimat Güncelleme

İlgili Teslimatı günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShipmentsIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShipmentApi();
            var id = 56;  // int? | Teslimat nesnesinin id değeri
            var shipment = new Shipment(); // Shipment | Shipment nesnesi

            try
            {
                // Teslimat Güncelleme
                Shipment result = apiInstance.ShipmentsIdPut(id, shipment);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShipmentApi.ShipmentsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Teslimat nesnesinin id değeri | 
 **shipment** | [**Shipment**](Shipment.md)| Shipment nesnesi | 

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shipmentspost"></a>
# **ShipmentsPost**
> Shipment ShipmentsPost (Shipment shipment)

Teslimat Oluşturma

Yeni bir Teslimat oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShipmentsPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShipmentApi();
            var shipment = new Shipment(); // Shipment | Shipment nesnesi

            try
            {
                // Teslimat Oluşturma
                Shipment result = apiInstance.ShipmentsPost(shipment);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShipmentApi.ShipmentsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipment** | [**Shipment**](Shipment.md)| Shipment nesnesi | 

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

