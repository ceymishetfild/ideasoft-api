# IO.Swagger.Model.InstallmentRate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Taksit oranı nesnesi kimlik değeri. | [optional] 
**Installment** | **int?** | Taksit adeti. | 
**Rate** | **float?** | Taksit adeti için oran bilgisi. | 
**PaymentGateway** | [**PaymentGateway**](PaymentGateway.md) | Ödeme kanalı nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

