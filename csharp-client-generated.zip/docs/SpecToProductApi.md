# IO.Swagger.Api.SpecToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SpecToProductsGet**](SpecToProductApi.md#spectoproductsget) | **GET** /spec_to_products | Ürün Özellik Ürün Bağı Listesi Alma
[**SpecToProductsIdDelete**](SpecToProductApi.md#spectoproductsiddelete) | **DELETE** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Silme
[**SpecToProductsIdGet**](SpecToProductApi.md#spectoproductsidget) | **GET** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Alma
[**SpecToProductsIdPut**](SpecToProductApi.md#spectoproductsidput) | **PUT** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Güncelleme
[**SpecToProductsPost**](SpecToProductApi.md#spectoproductspost) | **POST** /spec_to_products | Ürün Özellik Ürün Bağı Oluşturma


<a name="spectoproductsget"></a>
# **SpecToProductsGet**
> SpecToProduct SpecToProductsGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string ids = null, int? product = null, int? specGroup = null, int? specName = null, int? specValue = null)

Ürün Özellik Ürün Bağı Listesi Alma

Ürün Özellik Ürün Bağı listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecToProductsGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecToProductApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var product = 56;  // int? | Ürün id (optional) 
            var specGroup = 56;  // int? | Ürün özellik grubu id (optional) 
            var specName = 56;  // int? | Ürün özellik id (optional) 
            var specValue = 56;  // int? | Ürün özellik değeri id (optional) 

            try
            {
                // Ürün Özellik Ürün Bağı Listesi Alma
                SpecToProduct result = apiInstance.SpecToProductsGet(sort, limit, page, sinceId, ids, product, specGroup, specName, specValue);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecToProductApi.SpecToProductsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **product** | **int?**| Ürün id | [optional] 
 **specGroup** | **int?**| Ürün özellik grubu id | [optional] 
 **specName** | **int?**| Ürün özellik id | [optional] 
 **specValue** | **int?**| Ürün özellik değeri id | [optional] 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="spectoproductsiddelete"></a>
# **SpecToProductsIdDelete**
> void SpecToProductsIdDelete (int? id)

Ürün Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecToProductsIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecToProductApi();
            var id = 56;  // int? | Ürün Özellik Ürün Bağı nesnesinin id değeri

            try
            {
                // Ürün Özellik Ürün Bağı Silme
                apiInstance.SpecToProductsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecToProductApi.SpecToProductsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="spectoproductsidget"></a>
# **SpecToProductsIdGet**
> SpecToProduct SpecToProductsIdGet (int? id)

Ürün Özellik Ürün Bağı Alma

İlgili Ürün Özellik Ürün Bağını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecToProductsIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecToProductApi();
            var id = 56;  // int? | Ürün Özellik Ürün Bağı nesnesinin id değeri

            try
            {
                // Ürün Özellik Ürün Bağı Alma
                SpecToProduct result = apiInstance.SpecToProductsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecToProductApi.SpecToProductsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="spectoproductsidput"></a>
# **SpecToProductsIdPut**
> SpecToProduct SpecToProductsIdPut (int? id, SpecToProduct specToProduct)

Ürün Özellik Ürün Bağı Güncelleme

İlgili Ürün Özellik Ürün Bağını günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecToProductsIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecToProductApi();
            var id = 56;  // int? | Ürün Özellik Ürün Bağı nesnesinin id değeri
            var specToProduct = new SpecToProduct(); // SpecToProduct |  nesnesi

            try
            {
                // Ürün Özellik Ürün Bağı Güncelleme
                SpecToProduct result = apiInstance.SpecToProductsIdPut(id, specToProduct);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecToProductApi.SpecToProductsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 
 **specToProduct** | [**SpecToProduct**](SpecToProduct.md)|  nesnesi | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="spectoproductspost"></a>
# **SpecToProductsPost**
> SpecToProduct SpecToProductsPost (SpecToProduct specToProduct)

Ürün Özellik Ürün Bağı Oluşturma

Yeni bir Ürün Özellik Ürün Bağı oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecToProductsPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecToProductApi();
            var specToProduct = new SpecToProduct(); // SpecToProduct |  nesnesi

            try
            {
                // Ürün Özellik Ürün Bağı Oluşturma
                SpecToProduct result = apiInstance.SpecToProductsPost(specToProduct);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecToProductApi.SpecToProductsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specToProduct** | [**SpecToProduct**](SpecToProduct.md)|  nesnesi | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

