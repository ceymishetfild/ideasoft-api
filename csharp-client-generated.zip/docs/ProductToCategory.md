# IO.Swagger.Model.ProductToCategory
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ürün kategori bağı nesnesi kimlik değeri. | [optional] 
**SortOrder** | **int?** | Ürün kategori bağının sıralama değeri. Özel sıra belirtmek istemiyorsanız 9999 olarak iletebilirsiniz. | [optional] 
**Product** | [**Product**](Product.md) | Ürün nesnesi. | 
**Category** | [**Category**](Category.md) | Kategori nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

