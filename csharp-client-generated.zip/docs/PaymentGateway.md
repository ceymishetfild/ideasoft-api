# IO.Swagger.Model.PaymentGateway
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ödeme kanalı nesnesi kimlik değeri. | [optional] 
**Code** | **string** | Ödeme kanalı için ön tanımlanmış kod değeri. | 
**Name** | **string** | Ödeme kanalı nesnesi için isim değeri. | 
**Status** | **string** | Ödeme kanalının aktiflik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;/div&gt; | 
**SortOrder** | **int?** | Ödeme kanalı nesnesi için sıralama değeri. | [optional] 
**PaymentProvider** | [**PaymentProvider**](PaymentProvider.md) |  | [optional] 
**Settings** | [**List&lt;PaymentGatewaySetting&gt;**](PaymentGatewaySetting.md) | Ödeme kanalı ayarları. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

