# IO.Swagger.Model.Brand
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Marka nesnesi kimlik değeri. | [optional] 
**Name** | **string** | Marka nesnesi için isim değeri. | 
**Slug** | **string** | Slug değeri ilgili nesnenin Url değeridir. | [optional] 
**SortOrder** | **int?** | Marka nesnesi için sıralama değeri. | [optional] 
**Status** | **string** | Marka nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**Distributor** | **string** | Markanın tedarikçisi. | [optional] 
**ImageFile** | **string** | Marka nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF | [optional] 
**ShowcaseContent** | **string** | Marka nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir. | [optional] 
**DisplayShowcaseContent** | **string** | Marka nesnesi üst içerik metninin gösterim durumu. | [optional] 
**MetaKeywords** | **string** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] 
**MetaDescription** | **string** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] 
**PageTitle** | **string** | Marka nesnesinin etiket başlığı. | [optional] 
**Attachment** | **string** | Marka nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. | [optional] 
**CreatedAt** | **DateTime?** | Marka nesnesinin oluşturulma zamanı. | [optional] 
**UpdatedAt** | **DateTime?** | Marka nesnesinin güncellenme zamanı. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

