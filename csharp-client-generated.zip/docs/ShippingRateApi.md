# IO.Swagger.Api.ShippingRateApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ShippingRatesGet**](ShippingRateApi.md#shippingratesget) | **GET** /shipping_rates | Kargo Oranı Listesi Alma
[**ShippingRatesIdDelete**](ShippingRateApi.md#shippingratesiddelete) | **DELETE** /shipping_rates/{id} | Kargo Oranı Silme
[**ShippingRatesIdGet**](ShippingRateApi.md#shippingratesidget) | **GET** /shipping_rates/{id} | Kargo Oranı Alma
[**ShippingRatesIdPut**](ShippingRateApi.md#shippingratesidput) | **PUT** /shipping_rates/{id} | Kargo Oranı Güncelleme
[**ShippingRatesPost**](ShippingRateApi.md#shippingratespost) | **POST** /shipping_rates | Kargo Oranı Oluşturma


<a name="shippingratesget"></a>
# **ShippingRatesGet**
> ShippingRate ShippingRatesGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string ids = null, int? shippingCompany = null, int? region = null)

Kargo Oranı Listesi Alma

Kargo Oranı listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShippingRatesGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShippingRateApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var shippingCompany = 56;  // int? | Kargo firması id (optional) 
            var region = 56;  // int? | Bölge id (optional) 

            try
            {
                // Kargo Oranı Listesi Alma
                ShippingRate result = apiInstance.ShippingRatesGet(sort, limit, page, sinceId, ids, shippingCompany, region);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShippingRateApi.ShippingRatesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **shippingCompany** | **int?**| Kargo firması id | [optional] 
 **region** | **int?**| Bölge id | [optional] 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shippingratesiddelete"></a>
# **ShippingRatesIdDelete**
> void ShippingRatesIdDelete (int? id)

Kargo Oranı Silme

Kalıcı olarak ilgili Kargo Oranını siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShippingRatesIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShippingRateApi();
            var id = 56;  // int? | Kargo Oranı nesnesinin id değeri

            try
            {
                // Kargo Oranı Silme
                apiInstance.ShippingRatesIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShippingRateApi.ShippingRatesIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Kargo Oranı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shippingratesidget"></a>
# **ShippingRatesIdGet**
> ShippingRate ShippingRatesIdGet (int? id)

Kargo Oranı Alma

İlgili Kargo Oranını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShippingRatesIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShippingRateApi();
            var id = 56;  // int? | Kargo Oranı nesnesinin id değeri

            try
            {
                // Kargo Oranı Alma
                ShippingRate result = apiInstance.ShippingRatesIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShippingRateApi.ShippingRatesIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Kargo Oranı nesnesinin id değeri | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shippingratesidput"></a>
# **ShippingRatesIdPut**
> ShippingRate ShippingRatesIdPut (int? id, ShippingRate shippingRate)

Kargo Oranı Güncelleme

İlgili Kargo Oranını günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShippingRatesIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShippingRateApi();
            var id = 56;  // int? | Kargo Oranı nesnesinin id değeri
            var shippingRate = new ShippingRate(); // ShippingRate |  nesnesi

            try
            {
                // Kargo Oranı Güncelleme
                ShippingRate result = apiInstance.ShippingRatesIdPut(id, shippingRate);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShippingRateApi.ShippingRatesIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Kargo Oranı nesnesinin id değeri | 
 **shippingRate** | [**ShippingRate**](ShippingRate.md)|  nesnesi | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shippingratespost"></a>
# **ShippingRatesPost**
> ShippingRate ShippingRatesPost (ShippingRate shippingRate)

Kargo Oranı Oluşturma

Yeni bir Kargo Oranı oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShippingRatesPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShippingRateApi();
            var shippingRate = new ShippingRate(); // ShippingRate |  nesnesi

            try
            {
                // Kargo Oranı Oluşturma
                ShippingRate result = apiInstance.ShippingRatesPost(shippingRate);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShippingRateApi.ShippingRatesPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shippingRate** | [**ShippingRate**](ShippingRate.md)|  nesnesi | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

