# IO.Swagger.Model.CartItem
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Sepet kalemi nesnesi kimlik değeri. | [optional] 
**ParentProductId** | **int?** | Ana ürünün benzersiz rakamsal kimlik değeri. | [optional] 
**Quantity** | **float?** | Sepetteki kalem adedi. | 
**CategoryId** | **int?** | Sepetteki kaleme ait kategorinin benzersiz kimlik değeri. | [optional] 
**CreatedAt** | **DateTime?** | Sepet kalemi nesnesinin oluşturulma zamanı. | [optional] 
**UpdatedAt** | **DateTime?** | Sepet kalemi nesnesinin güncellenme zamanı. | [optional] 
**Cart** | [**Cart**](Cart.md) |  | [optional] 
**Product** | [**Product**](Product.md) |  | [optional] 
**Attributes** | [**List&lt;CartItemAttribute&gt;**](CartItemAttribute.md) | Sepet kalemi özelliği barındıran liste. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

