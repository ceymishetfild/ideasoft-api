# IO.Swagger.Api.ProductButtonApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductButtonsGet**](ProductButtonApi.md#productbuttonsget) | **GET** /product_buttons | Ürün ve Stok Butonu Listesi Alma
[**ProductButtonsIdDelete**](ProductButtonApi.md#productbuttonsiddelete) | **DELETE** /product_buttons/{id} | Ürün ve Stok Butonu Silme
[**ProductButtonsIdGet**](ProductButtonApi.md#productbuttonsidget) | **GET** /product_buttons/{id} | Ürün ve Stok Butonu Alma
[**ProductButtonsIdPut**](ProductButtonApi.md#productbuttonsidput) | **PUT** /product_buttons/{id} | Ürün ve Stok Butonu Güncelleme
[**ProductButtonsPost**](ProductButtonApi.md#productbuttonspost) | **POST** /product_buttons | Ürün ve Stok Butonu Oluşturma


<a name="productbuttonsget"></a>
# **ProductButtonsGet**
> ProductButton ProductButtonsGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string ids = null, string fastShipping = null, string sameDayShipping = null, string threeDaysDelivery = null, string fiveDaysDelivery = null, string sevenDaysDelivery = null, string freeShipping = null, string deliveryFromStock = null, string preOrderedProduct = null, string askStock = null, string campaignedProduct = null, int? product = null)

Ürün ve Stok Butonu Listesi Alma

Ürün ve Stok Butonu listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductButtonsGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductButtonApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var fastShipping = fastShipping_example;  // string | Hızlı Gönderi butonuna sahip ürünler<code>0</code><br><code>1</code> (optional) 
            var sameDayShipping = sameDayShipping_example;  // string | Aynı Gün Kargo butonuna sahip ürünler<code>0</code><br><code>1</code> (optional) 
            var threeDaysDelivery = threeDaysDelivery_example;  // string | 3 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code> (optional) 
            var fiveDaysDelivery = fiveDaysDelivery_example;  // string | 5 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code> (optional) 
            var sevenDaysDelivery = sevenDaysDelivery_example;  // string | 7 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code> (optional) 
            var freeShipping = freeShipping_example;  // string | Kargo Bedava butonuna sahip ürünler<code>0</code><br><code>1</code> (optional) 
            var deliveryFromStock = deliveryFromStock_example;  // string | Stoktan Teslim butonuna sahip ürünler<code>0</code><br><code>1</code> (optional) 
            var preOrderedProduct = preOrderedProduct_example;  // string | Ön Siparişli Ürün butonuna sahip ürünler<code>0</code><br><code>1</code> (optional) 
            var askStock = askStock_example;  // string | Stok Sorunuz butonuna sahip ürünler<code>0</code><br><code>1</code> (optional) 
            var campaignedProduct = campaignedProduct_example;  // string | Kampanyalı Ürün butonuna sahip ürünler<code>0</code><br><code>1</code> (optional) 
            var product = 56;  // int? | Ürün id (optional) 

            try
            {
                // Ürün ve Stok Butonu Listesi Alma
                ProductButton result = apiInstance.ProductButtonsGet(sort, limit, page, sinceId, ids, fastShipping, sameDayShipping, threeDaysDelivery, fiveDaysDelivery, sevenDaysDelivery, freeShipping, deliveryFromStock, preOrderedProduct, askStock, campaignedProduct, product);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductButtonApi.ProductButtonsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **fastShipping** | **string**| Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **sameDayShipping** | **string**| Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **threeDaysDelivery** | **string**| 3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **fiveDaysDelivery** | **string**| 5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **sevenDaysDelivery** | **string**| 7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **freeShipping** | **string**| Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **deliveryFromStock** | **string**| Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **preOrderedProduct** | **string**| Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **askStock** | **string**| Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **campaignedProduct** | **string**| Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **product** | **int?**| Ürün id | [optional] 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productbuttonsiddelete"></a>
# **ProductButtonsIdDelete**
> void ProductButtonsIdDelete (int? id)

Ürün ve Stok Butonu Silme

Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductButtonsIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductButtonApi();
            var id = 56;  // int? | Ürün ve Stok Butonu nesnesinin id değeri

            try
            {
                // Ürün ve Stok Butonu Silme
                apiInstance.ProductButtonsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductButtonApi.ProductButtonsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productbuttonsidget"></a>
# **ProductButtonsIdGet**
> ProductButton ProductButtonsIdGet (int? id)

Ürün ve Stok Butonu Alma

İlgili Ürün ve Stok Butonunu getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductButtonsIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductButtonApi();
            var id = 56;  // int? | Ürün ve Stok Butonu nesnesinin id değeri

            try
            {
                // Ürün ve Stok Butonu Alma
                ProductButton result = apiInstance.ProductButtonsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductButtonApi.ProductButtonsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productbuttonsidput"></a>
# **ProductButtonsIdPut**
> ProductButton ProductButtonsIdPut (int? id, ProductButton productButton)

Ürün ve Stok Butonu Güncelleme

İlgili Ürün ve Stok Butonunu günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductButtonsIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductButtonApi();
            var id = 56;  // int? | Ürün ve Stok Butonu nesnesinin id değeri
            var productButton = new ProductButton(); // ProductButton |  nesnesi

            try
            {
                // Ürün ve Stok Butonu Güncelleme
                ProductButton result = apiInstance.ProductButtonsIdPut(id, productButton);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductButtonApi.ProductButtonsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün ve Stok Butonu nesnesinin id değeri | 
 **productButton** | [**ProductButton**](ProductButton.md)|  nesnesi | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productbuttonspost"></a>
# **ProductButtonsPost**
> ProductButton ProductButtonsPost (ProductButton productButton)

Ürün ve Stok Butonu Oluşturma

Yeni bir Ürün ve Stok Butonu oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductButtonsPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductButtonApi();
            var productButton = new ProductButton(); // ProductButton |  nesnesi

            try
            {
                // Ürün ve Stok Butonu Oluşturma
                ProductButton result = apiInstance.ProductButtonsPost(productButton);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductButtonApi.ProductButtonsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productButton** | [**ProductButton**](ProductButton.md)|  nesnesi | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

