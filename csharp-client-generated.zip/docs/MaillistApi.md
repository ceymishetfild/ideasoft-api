# IO.Swagger.Api.MaillistApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**MaillistsGet**](MaillistApi.md#maillistsget) | **GET** /maillists | Mail Listesi Listesi Alma
[**MaillistsIdDelete**](MaillistApi.md#maillistsiddelete) | **DELETE** /maillists/{id} | Mail Listesi Silme
[**MaillistsIdGet**](MaillistApi.md#maillistsidget) | **GET** /maillists/{id} | Mail Listesi Alma
[**MaillistsIdPut**](MaillistApi.md#maillistsidput) | **PUT** /maillists/{id} | Mail Listesi Güncelleme
[**MaillistsPost**](MaillistApi.md#maillistspost) | **POST** /maillists | Mail Listesi Oluşturma


<a name="maillistsget"></a>
# **MaillistsGet**
> Maillist MaillistsGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string name = null, string email = null, int? maillistGroup = null, DateTime? startDate = null, string endDate = null, DateTime? startUpdatedAt = null, string endUpdatedAt = null)

Mail Listesi Listesi Alma

Mail Listesi listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MaillistsGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MaillistApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var name = name_example;  // string | Mail Listesi adı. (optional) 
            var email = email_example;  // string | Mail Listesi e-mail. (optional) 
            var maillistGroup = 56;  // int? | Mail Listesi Grubu id (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 

            try
            {
                // Mail Listesi Listesi Alma
                Maillist result = apiInstance.MaillistsGet(sort, limit, page, sinceId, name, email, maillistGroup, startDate, endDate, startUpdatedAt, endUpdatedAt);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MaillistApi.MaillistsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **string**| Mail Listesi adı. | [optional] 
 **email** | **string**| Mail Listesi e-mail. | [optional] 
 **maillistGroup** | **int?**| Mail Listesi Grubu id | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="maillistsiddelete"></a>
# **MaillistsIdDelete**
> void MaillistsIdDelete (int? id)

Mail Listesi Silme

Kalıcı olarak ilgili Mail Listesini siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MaillistsIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MaillistApi();
            var id = 56;  // int? | Mail Listesi nesnesinin id değeri

            try
            {
                // Mail Listesi Silme
                apiInstance.MaillistsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MaillistApi.MaillistsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Mail Listesi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="maillistsidget"></a>
# **MaillistsIdGet**
> Maillist MaillistsIdGet (int? id)

Mail Listesi Alma

İlgili Mail Listesini getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MaillistsIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MaillistApi();
            var id = 56;  // int? | Mail Listesi nesnesinin id değeri

            try
            {
                // Mail Listesi Alma
                Maillist result = apiInstance.MaillistsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MaillistApi.MaillistsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Mail Listesi nesnesinin id değeri | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="maillistsidput"></a>
# **MaillistsIdPut**
> Maillist MaillistsIdPut (int? id, Maillist maillist)

Mail Listesi Güncelleme

İlgili Mail Listesini günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MaillistsIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MaillistApi();
            var id = 56;  // int? | Mail Listesi nesnesinin id değeri
            var maillist = new Maillist(); // Maillist | Maillist nesnesi

            try
            {
                // Mail Listesi Güncelleme
                Maillist result = apiInstance.MaillistsIdPut(id, maillist);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MaillistApi.MaillistsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Mail Listesi nesnesinin id değeri | 
 **maillist** | [**Maillist**](Maillist.md)| Maillist nesnesi | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="maillistspost"></a>
# **MaillistsPost**
> Maillist MaillistsPost (Maillist maillist)

Mail Listesi Oluşturma

Yeni bir Mail Listesini oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MaillistsPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MaillistApi();
            var maillist = new Maillist(); // Maillist | Maillist nesnesi

            try
            {
                // Mail Listesi Oluşturma
                Maillist result = apiInstance.MaillistsPost(maillist);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MaillistApi.MaillistsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **maillist** | [**Maillist**](Maillist.md)| Maillist nesnesi | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

