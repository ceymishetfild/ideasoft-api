# IO.Swagger.Api.QuickCartApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**QuickCartsGet**](QuickCartApi.md#quickcartsget) | **GET** /quick_carts | Hızlı Satın Al Bağlantısı Alma
[**QuickCartsIdDelete**](QuickCartApi.md#quickcartsiddelete) | **DELETE** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Silme
[**QuickCartsIdGet**](QuickCartApi.md#quickcartsidget) | **GET** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Alma
[**QuickCartsIdPut**](QuickCartApi.md#quickcartsidput) | **PUT** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Güncelleme
[**QuickCartsPost**](QuickCartApi.md#quickcartspost) | **POST** /quick_carts | Hızlı Satın Al Bağlantısı Oluşturma


<a name="quickcartsget"></a>
# **QuickCartsGet**
> QuickCart QuickCartsGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string name = null)

Hızlı Satın Al Bağlantısı Alma

Hızlı Satın Al Bağlantısı döndürür.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class QuickCartsGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new QuickCartApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var name = name_example;  // string | Hızlı Satın Al Bağlantısı adı (optional) 

            try
            {
                // Hızlı Satın Al Bağlantısı Alma
                QuickCart result = apiInstance.QuickCartsGet(sort, limit, page, sinceId, name);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling QuickCartApi.QuickCartsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **string**| Hızlı Satın Al Bağlantısı adı | [optional] 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="quickcartsiddelete"></a>
# **QuickCartsIdDelete**
> void QuickCartsIdDelete (int? id)

Hızlı Satın Al Bağlantısı Silme

Kalıcı olarak ilgili Hızlı Satın Al Bağlantısını siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class QuickCartsIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new QuickCartApi();
            var id = 56;  // int? | Hızlı Satın Al nesnesinin id değeri

            try
            {
                // Hızlı Satın Al Bağlantısı Silme
                apiInstance.QuickCartsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling QuickCartApi.QuickCartsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Hızlı Satın Al nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="quickcartsidget"></a>
# **QuickCartsIdGet**
> QuickCart QuickCartsIdGet (int? id)

Hızlı Satın Al Bağlantısı Alma

İlgili Hızlı Satın Al Bağlantısını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class QuickCartsIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new QuickCartApi();
            var id = 56;  // int? | Hızlı Satın Al nesnesinin id değeri

            try
            {
                // Hızlı Satın Al Bağlantısı Alma
                QuickCart result = apiInstance.QuickCartsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling QuickCartApi.QuickCartsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Hızlı Satın Al nesnesinin id değeri | 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="quickcartsidput"></a>
# **QuickCartsIdPut**
> QuickCart QuickCartsIdPut (int? id, QuickCart quickCart)

Hızlı Satın Al Bağlantısı Güncelleme

İlgili Hızlı Satın Al Bağlantısını günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class QuickCartsIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new QuickCartApi();
            var id = 56;  // int? | Hızlı Satın Al nesnesinin id değeri
            var quickCart = new QuickCart(); // QuickCart | QuickCart nesnesi

            try
            {
                // Hızlı Satın Al Bağlantısı Güncelleme
                QuickCart result = apiInstance.QuickCartsIdPut(id, quickCart);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling QuickCartApi.QuickCartsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Hızlı Satın Al nesnesinin id değeri | 
 **quickCart** | [**QuickCart**](QuickCart.md)| QuickCart nesnesi | 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="quickcartspost"></a>
# **QuickCartsPost**
> QuickCart QuickCartsPost (QuickCart quickCart)

Hızlı Satın Al Bağlantısı Oluşturma

Yeni bir Hızlı Satın Al Bağlantısı oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class QuickCartsPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new QuickCartApi();
            var quickCart = new QuickCart(); // QuickCart | QuickCart nesnesi

            try
            {
                // Hızlı Satın Al Bağlantısı Oluşturma
                QuickCart result = apiInstance.QuickCartsPost(quickCart);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling QuickCartApi.QuickCartsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **quickCart** | [**QuickCart**](QuickCart.md)| QuickCart nesnesi | 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

