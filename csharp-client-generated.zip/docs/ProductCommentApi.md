# IO.Swagger.Api.ProductCommentApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductCommentsGet**](ProductCommentApi.md#productcommentsget) | **GET** /product_comments | Ürün Yorumları Listesi Alma
[**ProductCommentsIdDelete**](ProductCommentApi.md#productcommentsiddelete) | **DELETE** /product_comments/{id} | Ürün Yorumu Silme
[**ProductCommentsIdGet**](ProductCommentApi.md#productcommentsidget) | **GET** /product_comments/{id} | Ürün Yorumu Alma
[**ProductCommentsIdPut**](ProductCommentApi.md#productcommentsidput) | **PUT** /product_comments/{id} | Ürün Yorumu Güncelleme
[**ProductCommentsPost**](ProductCommentApi.md#productcommentspost) | **POST** /product_comments | Ürün Yorumu Oluşturma


<a name="productcommentsget"></a>
# **ProductCommentsGet**
> ProductComment ProductCommentsGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string status = null, string isAnonymous = null, int? member = null, int? product = null, DateTime? startDate = null, string endDate = null, DateTime? startUpdatedAt = null, string endUpdatedAt = null)

Ürün Yorumları Listesi Alma

Ürün Yorumları listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductCommentsGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductCommentApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir (optional) 
            var status = status_example;  // string | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif (optional) 
            var isAnonymous = isAnonymous_example;  // string | IsAnonymous şu değerleri alabilir: <br><code>0</code> : Anonim değil<br><code>1</code> : Anonim (optional) 
            var member = 56;  // int? | Üye id (optional) 
            var product = 56;  // int? | Ürün id (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 

            try
            {
                // Ürün Yorumları Listesi Alma
                ProductComment result = apiInstance.ProductCommentsGet(sort, limit, page, sinceId, status, isAnonymous, member, product, startDate, endDate, startUpdatedAt, endUpdatedAt);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductCommentApi.ProductCommentsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional] 
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **isAnonymous** | **string**| IsAnonymous şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Anonim değil&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Anonim | [optional] 
 **member** | **int?**| Üye id | [optional] 
 **product** | **int?**| Ürün id | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productcommentsiddelete"></a>
# **ProductCommentsIdDelete**
> void ProductCommentsIdDelete (int? id)

Ürün Yorumu Silme

Kalıcı olarak ilgili Ürün Yorumunu siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductCommentsIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductCommentApi();
            var id = 56;  // int? | Ürün Yorumu nesnesinin id değeri

            try
            {
                // Ürün Yorumu Silme
                apiInstance.ProductCommentsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductCommentApi.ProductCommentsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Yorumu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productcommentsidget"></a>
# **ProductCommentsIdGet**
> ProductComment ProductCommentsIdGet (int? id)

Ürün Yorumu Alma

İlgili Ürün Yorumunu getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductCommentsIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductCommentApi();
            var id = 56;  // int? | Ürün Yorumu nesnesinin id değeri

            try
            {
                // Ürün Yorumu Alma
                ProductComment result = apiInstance.ProductCommentsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductCommentApi.ProductCommentsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Yorumu nesnesinin id değeri | 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productcommentsidput"></a>
# **ProductCommentsIdPut**
> ProductComment ProductCommentsIdPut (int? id, ProductComment productComment)

Ürün Yorumu Güncelleme

İlgili Ürün Yorumunu günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductCommentsIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductCommentApi();
            var id = 56;  // int? | Ürün Yorumu nesnesinin id değeri
            var productComment = new ProductComment(); // ProductComment |  nesnesi

            try
            {
                // Ürün Yorumu Güncelleme
                ProductComment result = apiInstance.ProductCommentsIdPut(id, productComment);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductCommentApi.ProductCommentsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Yorumu nesnesinin id değeri | 
 **productComment** | [**ProductComment**](ProductComment.md)|  nesnesi | 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productcommentspost"></a>
# **ProductCommentsPost**
> ProductComment ProductCommentsPost (ProductComment productComment)

Ürün Yorumu Oluşturma

Yeni bir Ürün Yorumu oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductCommentsPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductCommentApi();
            var productComment = new ProductComment(); // ProductComment |  nesnesi

            try
            {
                // Ürün Yorumu Oluşturma
                ProductComment result = apiInstance.ProductCommentsPost(productComment);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductCommentApi.ProductCommentsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productComment** | [**ProductComment**](ProductComment.md)|  nesnesi | 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

