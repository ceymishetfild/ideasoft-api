# IO.Swagger.Model.PaymentProviderSetting
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ödeme altyapısı sağlayıcısı ayarı nesnesi kimlik değeri. | [optional] 
**VarKey** | **string** | Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken anahtarı. | 
**VarValue** | **string** | Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken değeri. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

