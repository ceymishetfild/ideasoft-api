# IO.Swagger.Api.ExtraInfoToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ExtraInfoToProductsGet**](ExtraInfoToProductApi.md#extrainfotoproductsget) | **GET** /extra_info_to_products | Ek Bilgi Ürün Bağı Listesi Alma
[**ExtraInfoToProductsIdDelete**](ExtraInfoToProductApi.md#extrainfotoproductsiddelete) | **DELETE** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Silme
[**ExtraInfoToProductsIdGet**](ExtraInfoToProductApi.md#extrainfotoproductsidget) | **GET** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Alma
[**ExtraInfoToProductsIdPut**](ExtraInfoToProductApi.md#extrainfotoproductsidput) | **PUT** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Güncelleme
[**ExtraInfoToProductsPost**](ExtraInfoToProductApi.md#extrainfotoproductspost) | **POST** /extra_info_to_products | Ek Bilgi Ürün Bağı Oluşturma


<a name="extrainfotoproductsget"></a>
# **ExtraInfoToProductsGet**
> ExtraInfoToProduct ExtraInfoToProductsGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, int? extraInfo = null, int? product = null)

Ek Bilgi Ürün Bağı Listesi Alma

Ek Bilgi Ürün Bağı listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ExtraInfoToProductsGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ExtraInfoToProductApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var extraInfo = 56;  // int? | Ek bilgi id (optional) 
            var product = 56;  // int? | Ürün id (optional) 

            try
            {
                // Ek Bilgi Ürün Bağı Listesi Alma
                ExtraInfoToProduct result = apiInstance.ExtraInfoToProductsGet(sort, limit, page, sinceId, extraInfo, product);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ExtraInfoToProductApi.ExtraInfoToProductsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **extraInfo** | **int?**| Ek bilgi id | [optional] 
 **product** | **int?**| Ürün id | [optional] 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="extrainfotoproductsiddelete"></a>
# **ExtraInfoToProductsIdDelete**
> void ExtraInfoToProductsIdDelete (int? id)

Ek Bilgi Ürün Bağı Silme

Kalıcı olarak ilgili Ek Bilgi Ürün Bağını siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ExtraInfoToProductsIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ExtraInfoToProductApi();
            var id = 56;  // int? | Ek Bilgi Ürün Bağı nesnesinin id değeri

            try
            {
                // Ek Bilgi Ürün Bağı Silme
                apiInstance.ExtraInfoToProductsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ExtraInfoToProductApi.ExtraInfoToProductsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="extrainfotoproductsidget"></a>
# **ExtraInfoToProductsIdGet**
> ExtraInfoToProduct ExtraInfoToProductsIdGet (int? id)

Ek Bilgi Ürün Bağı Alma

İlgili Ek Bilgi Ürün Bağını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ExtraInfoToProductsIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ExtraInfoToProductApi();
            var id = 56;  // int? | Ek Bilgi Ürün Bağı nesnesinin id değeri

            try
            {
                // Ek Bilgi Ürün Bağı Alma
                ExtraInfoToProduct result = apiInstance.ExtraInfoToProductsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ExtraInfoToProductApi.ExtraInfoToProductsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="extrainfotoproductsidput"></a>
# **ExtraInfoToProductsIdPut**
> ExtraInfoToProduct ExtraInfoToProductsIdPut (int? id, ExtraInfoToProduct extraInfoToProduct)

Ek Bilgi Ürün Bağı Güncelleme

İlgili Ek Bilgi Ürün Bağını günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ExtraInfoToProductsIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ExtraInfoToProductApi();
            var id = 56;  // int? | Ek Bilgi Ürün Bağı nesnesinin id değeri
            var extraInfoToProduct = new ExtraInfoToProduct(); // ExtraInfoToProduct | ExtraInfoToProduct nesnesi

            try
            {
                // Ek Bilgi Ürün Bağı Güncelleme
                ExtraInfoToProduct result = apiInstance.ExtraInfoToProductsIdPut(id, extraInfoToProduct);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ExtraInfoToProductApi.ExtraInfoToProductsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 
 **extraInfoToProduct** | [**ExtraInfoToProduct**](ExtraInfoToProduct.md)| ExtraInfoToProduct nesnesi | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="extrainfotoproductspost"></a>
# **ExtraInfoToProductsPost**
> ExtraInfoToProduct ExtraInfoToProductsPost (ExtraInfoToProduct extraInfoToProduct)

Ek Bilgi Ürün Bağı Oluşturma

Yeni bir Ek Bilgi Ürün Bağı oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ExtraInfoToProductsPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ExtraInfoToProductApi();
            var extraInfoToProduct = new ExtraInfoToProduct(); // ExtraInfoToProduct | ExtraInfoToProduct nesnesi

            try
            {
                // Ek Bilgi Ürün Bağı Oluşturma
                ExtraInfoToProduct result = apiInstance.ExtraInfoToProductsPost(extraInfoToProduct);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ExtraInfoToProductApi.ExtraInfoToProductsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extraInfoToProduct** | [**ExtraInfoToProduct**](ExtraInfoToProduct.md)| ExtraInfoToProduct nesnesi | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

