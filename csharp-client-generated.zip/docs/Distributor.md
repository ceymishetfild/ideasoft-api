# IO.Swagger.Model.Distributor
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Distributor nesnesi kimlik değeri. | [optional] 
**Name** | **string** | Distributor nesnesi için isim değeri. | 
**Email** | **string** | E-mail adresi. | [optional] 
**Phone** | **string** | Telefon numarası. | [optional] 
**ContactPerson** | **string** | İletişim kişisi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

