# IO.Swagger.Model.Maillist
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Mail listesi nesnesi kimlik değeri. | [optional] 
**Name** | **string** | Mail listesi nesnesi için isim değeri. | 
**Email** | **string** | Ziyaretçi veya üyenin mail adresi. | 
**LastMailSentDate** | **DateTime?** | En son e-mail gönderilen zaman. | [optional] 
**CreatorIpAddress** | **string** | Mail listesi nesnesini oluşturan kişinin IP adresi. | [optional] 
**CreatedAt** | **DateTime?** | Mail listesi nesnesinin oluşturulma zamanı. | 
**UpdatedAt** | **DateTime?** | Mail listesi nesnesinin güncellenme zamanı. | 
**MaillistGroup** | [**MaillistGroup**](MaillistGroup.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

