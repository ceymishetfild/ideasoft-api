# IO.Swagger.Model.ShopUserlevels
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Yönetici grubu nesnesinin benzersiz rakamsal kimlik değeri. | [optional] 
**Label** | **string** | Yönetici grubu ismi. | [optional] 
**Roles** | **string** | Yönetici grubunun sahip olduğu roller. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

