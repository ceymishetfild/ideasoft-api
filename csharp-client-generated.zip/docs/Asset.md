# IO.Swagger.Model.Asset
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Key** | **string** | Tema Dosyası nesnesi anahtar değeri. | [optional] 
**ContentType** | **string** | Tema Dosyası içerik tipi. Geçerli bir MIME Content-Type verilmelidir. | [optional] 
**Attachment** | **string** | Tema Dosyası içeriği. | [optional] 
**CreatedAt** | **DateTime?** | Tema Dosyası nesnesinin oluşturulma zamanı. | [optional] 
**UpdatedAt** | **DateTime?** | Tema Dosyası nesnesinin güncellenme zamanı. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

