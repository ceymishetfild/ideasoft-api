# IO.Swagger.Api.ProductToCategoryApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductToCategoriesGet**](ProductToCategoryApi.md#producttocategoriesget) | **GET** /product_to_categories | Ürün Kategori Bağı Listesi Alma
[**ProductToCategoriesIdDelete**](ProductToCategoryApi.md#producttocategoriesiddelete) | **DELETE** /product_to_categories/{id} | Ürün Kategori Bağı Silme
[**ProductToCategoriesIdGet**](ProductToCategoryApi.md#producttocategoriesidget) | **GET** /product_to_categories/{id} | Ürün Kategori Bağı Alma
[**ProductToCategoriesIdPut**](ProductToCategoryApi.md#producttocategoriesidput) | **PUT** /product_to_categories/{id} | Ürün Kategori Bağı Güncelleme
[**ProductToCategoriesPost**](ProductToCategoryApi.md#producttocategoriespost) | **POST** /product_to_categories | Ürün Kategori Bağı Oluşturma


<a name="producttocategoriesget"></a>
# **ProductToCategoriesGet**
> ProductToCategory ProductToCategoriesGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, int? product = null, int? category = null)

Ürün Kategori Bağı Listesi Alma

Ürün Kategori Bağı listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductToCategoriesGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductToCategoryApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var product = 56;  // int? | Ürün id (optional) 
            var category = 56;  // int? | Kategori id (optional) 

            try
            {
                // Ürün Kategori Bağı Listesi Alma
                ProductToCategory result = apiInstance.ProductToCategoriesGet(sort, limit, page, sinceId, product, category);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductToCategoryApi.ProductToCategoriesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **product** | **int?**| Ürün id | [optional] 
 **category** | **int?**| Kategori id | [optional] 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="producttocategoriesiddelete"></a>
# **ProductToCategoriesIdDelete**
> void ProductToCategoriesIdDelete (int? id)

Ürün Kategori Bağı Silme

Kalıcı olarak ilgili Ürün Kategori Bağını siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductToCategoriesIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductToCategoryApi();
            var id = 56;  // int? | Ürün Kategori Bağı nesnesinin id değeri

            try
            {
                // Ürün Kategori Bağı Silme
                apiInstance.ProductToCategoriesIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductToCategoryApi.ProductToCategoriesIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Kategori Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="producttocategoriesidget"></a>
# **ProductToCategoriesIdGet**
> ProductToCategory ProductToCategoriesIdGet (int? id)

Ürün Kategori Bağı Alma

İlgili Ürün Kategori Bağını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductToCategoriesIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductToCategoryApi();
            var id = 56;  // int? | Ürün Kategori Bağı nesnesinin id değeri

            try
            {
                // Ürün Kategori Bağı Alma
                ProductToCategory result = apiInstance.ProductToCategoriesIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductToCategoryApi.ProductToCategoriesIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Kategori Bağı nesnesinin id değeri | 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="producttocategoriesidput"></a>
# **ProductToCategoriesIdPut**
> ProductToCategory ProductToCategoriesIdPut (int? id, ProductToCategory productToCategory)

Ürün Kategori Bağı Güncelleme

İlgili Ürün Kategori Bağını günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductToCategoriesIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductToCategoryApi();
            var id = 56;  // int? | Ürün Kategori Bağı nesnesinin id değeri
            var productToCategory = new ProductToCategory(); // ProductToCategory | ProductToCategory nesnesi

            try
            {
                // Ürün Kategori Bağı Güncelleme
                ProductToCategory result = apiInstance.ProductToCategoriesIdPut(id, productToCategory);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductToCategoryApi.ProductToCategoriesIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Kategori Bağı nesnesinin id değeri | 
 **productToCategory** | [**ProductToCategory**](ProductToCategory.md)| ProductToCategory nesnesi | 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="producttocategoriespost"></a>
# **ProductToCategoriesPost**
> ProductToCategory ProductToCategoriesPost (ProductToCategory productToCategory)

Ürün Kategori Bağı Oluşturma

Yeni bir Ürün Kategori Bağı oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductToCategoriesPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductToCategoryApi();
            var productToCategory = new ProductToCategory(); // ProductToCategory | ProductToCategory nesnesi

            try
            {
                // Ürün Kategori Bağı Oluşturma
                ProductToCategory result = apiInstance.ProductToCategoriesPost(productToCategory);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductToCategoryApi.ProductToCategoriesPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productToCategory** | [**ProductToCategory**](ProductToCategory.md)| ProductToCategory nesnesi | 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

