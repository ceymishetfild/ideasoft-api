# IO.Swagger.Api.DistributorApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DistributorsGet**](DistributorApi.md#distributorsget) | **GET** /distributors | Distribütör Listesi Alma
[**DistributorsIdDelete**](DistributorApi.md#distributorsiddelete) | **DELETE** /distributors/{id} | Distribütör Silme
[**DistributorsIdGet**](DistributorApi.md#distributorsidget) | **GET** /distributors/{id} | Distribütör Alma
[**DistributorsIdPut**](DistributorApi.md#distributorsidput) | **PUT** /distributors/{id} | Distribütör Güncelleme
[**DistributorsPost**](DistributorApi.md#distributorspost) | **POST** /distributors | Distribütör Oluşturma


<a name="distributorsget"></a>
# **DistributorsGet**
> Distributor DistributorsGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string ids = null, string name = null, string email = null, string phone = null, string contactPerson = null)

Distribütör Listesi Alma

Distribütör listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DistributorsGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new DistributorApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var name = name_example;  // string | Distribütör adı. (optional) 
            var email = email_example;  // string | Distribütör email adresi (optional) 
            var phone = phone_example;  // string | Distribütör telefonu (optional) 
            var contactPerson = contactPerson_example;  // string | Distribütör sorumlu kişi (optional) 

            try
            {
                // Distribütör Listesi Alma
                Distributor result = apiInstance.DistributorsGet(sort, limit, page, sinceId, ids, name, email, phone, contactPerson);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DistributorApi.DistributorsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **string**| Distribütör adı. | [optional] 
 **email** | **string**| Distribütör email adresi | [optional] 
 **phone** | **string**| Distribütör telefonu | [optional] 
 **contactPerson** | **string**| Distribütör sorumlu kişi | [optional] 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="distributorsiddelete"></a>
# **DistributorsIdDelete**
> void DistributorsIdDelete (int? id)

Distribütör Silme

Kalıcı olarak ilgili Distribütörü siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DistributorsIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new DistributorApi();
            var id = 56;  // int? | Distribütör nesnesinin id değeri

            try
            {
                // Distribütör Silme
                apiInstance.DistributorsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DistributorApi.DistributorsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Distribütör nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="distributorsidget"></a>
# **DistributorsIdGet**
> Distributor DistributorsIdGet (int? id)

Distribütör Alma

İlgili Distribütörü getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DistributorsIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new DistributorApi();
            var id = 56;  // int? | Distribütör nesnesinin id değeri

            try
            {
                // Distribütör Alma
                Distributor result = apiInstance.DistributorsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DistributorApi.DistributorsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Distribütör nesnesinin id değeri | 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="distributorsidput"></a>
# **DistributorsIdPut**
> Distributor DistributorsIdPut (int? id, Distributor distributor)

Distribütör Güncelleme

İlgili Distribütörü günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DistributorsIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new DistributorApi();
            var id = 56;  // int? | Distribütör nesnesinin id değeri
            var distributor = new Distributor(); // Distributor |  nesnesi

            try
            {
                // Distribütör Güncelleme
                Distributor result = apiInstance.DistributorsIdPut(id, distributor);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DistributorApi.DistributorsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Distribütör nesnesinin id değeri | 
 **distributor** | [**Distributor**](Distributor.md)|  nesnesi | 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="distributorspost"></a>
# **DistributorsPost**
> Distributor DistributorsPost (Distributor distributor)

Distribütör Oluşturma

Yeni bir Distribütör oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DistributorsPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new DistributorApi();
            var distributor = new Distributor(); // Distributor |  nesnesi

            try
            {
                // Distribütör Oluşturma
                Distributor result = apiInstance.DistributorsPost(distributor);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DistributorApi.DistributorsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **distributor** | [**Distributor**](Distributor.md)|  nesnesi | 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

