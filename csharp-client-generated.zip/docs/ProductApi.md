# IO.Swagger.Api.ProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductsGet**](ProductApi.md#productsget) | **GET** /products | Ürün Listesi Alma
[**ProductsIdDelete**](ProductApi.md#productsiddelete) | **DELETE** /products/{id} | Ürün Silme
[**ProductsIdGet**](ProductApi.md#productsidget) | **GET** /products/{id} | Ürün Alma
[**ProductsIdPut**](ProductApi.md#productsidput) | **PUT** /products/{id} | Ürün Güncelleme
[**ProductsPost**](ProductApi.md#productspost) | **POST** /products | Ürün Oluşturma


<a name="productsget"></a>
# **ProductsGet**
> Product ProductsGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string ids = null, string ids2 = null, string parent = null, int? brand = null, string sku = null, string name = null, string distributor = null, List<string> q = null, DateTime? startDate = null, string endDate = null, DateTime? startUpdatedAt = null, string endUpdatedAt = null)

Ürün Listesi Alma

Ürün listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductsGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var ids2 = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var parent = parent_example;  // string | Ürün id (optional) 
            var brand = 56;  // int? | Marka id (optional) 
            var sku = sku_example;  // string | Ürün stok kodu. (optional) 
            var name = name_example;  // string | Ürün adı. (optional) 
            var distributor = distributor_example;  // string | Ürün distribütör. (optional) 
            var q = new List<string>(); // List<string> | Ürün arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;] (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 

            try
            {
                // Ürün Listesi Alma
                Product result = apiInstance.ProductsGet(sort, limit, page, sinceId, ids, ids2, parent, brand, sku, name, distributor, q, startDate, endDate, startUpdatedAt, endUpdatedAt);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductApi.ProductsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **ids2** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **parent** | **string**| Ürün id | [optional] 
 **brand** | **int?**| Marka id | [optional] 
 **sku** | **string**| Ürün stok kodu. | [optional] 
 **name** | **string**| Ürün adı. | [optional] 
 **distributor** | **string**| Ürün distribütör. | [optional] 
 **q** | [**List&lt;string&gt;**](string.md)| Ürün arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productsiddelete"></a>
# **ProductsIdDelete**
> void ProductsIdDelete (int? id)

Ürün Silme

Kalıcı olarak ilgili Ürünü siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductsIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductApi();
            var id = 56;  // int? | Ürün nesnesinin id değeri

            try
            {
                // Ürün Silme
                apiInstance.ProductsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductApi.ProductsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productsidget"></a>
# **ProductsIdGet**
> Product ProductsIdGet (int? id)

Ürün Alma

İlgili Ürünü getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductsIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductApi();
            var id = 56;  // int? | Ürün nesnesinin id değeri

            try
            {
                // Ürün Alma
                Product result = apiInstance.ProductsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductApi.ProductsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün nesnesinin id değeri | 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productsidput"></a>
# **ProductsIdPut**
> Product ProductsIdPut (int? id, Product product)

Ürün Güncelleme

İlgili Ürünü günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductsIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductApi();
            var id = 56;  // int? | Ürün nesnesinin id değeri
            var product = new Product(); // Product |  nesnesi

            try
            {
                // Ürün Güncelleme
                Product result = apiInstance.ProductsIdPut(id, product);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductApi.ProductsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün nesnesinin id değeri | 
 **product** | [**Product**](Product.md)|  nesnesi | 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productspost"></a>
# **ProductsPost**
> Product ProductsPost (Product product)

Ürün Oluşturma

Yeni bir Ürün oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductsPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductApi();
            var product = new Product(); // Product |  nesnesi

            try
            {
                // Ürün Oluşturma
                Product result = apiInstance.ProductsPost(product);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductApi.ProductsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product** | [**Product**](Product.md)|  nesnesi | 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

