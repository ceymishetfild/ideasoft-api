# IO.Swagger.Model.ProductDetail
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ürün detayı nesnesi kimlik değeri. | [optional] 
**Sku** | **string** | Ürünün stok kodu. | [optional] 
**Details** | **string** | Detay bilgisi. | [optional] 
**ExtraDetails** | **string** | Ürün ekstra detaylı bilgi. | [optional] 
**Product** | [**Product**](Product.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

