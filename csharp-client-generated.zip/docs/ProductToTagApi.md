# IO.Swagger.Api.ProductToTagApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductToTagsGet**](ProductToTagApi.md#producttotagsget) | **GET** /product_to_tags | Ürün SEO+ Bağı Listesi Alma
[**ProductToTagsIdDelete**](ProductToTagApi.md#producttotagsiddelete) | **DELETE** /product_to_tags/{id} | Ürün SEO+ Bağı Silme
[**ProductToTagsIdGet**](ProductToTagApi.md#producttotagsidget) | **GET** /product_to_tags/{id} | Ürün SEO+ Bağı Alma
[**ProductToTagsIdPut**](ProductToTagApi.md#producttotagsidput) | **PUT** /product_to_tags/{id} | Ürün SEO+ Bağı Güncelleme
[**ProductToTagsPost**](ProductToTagApi.md#producttotagspost) | **POST** /product_to_tags | Ürün SEO+ Bağı Oluşturma


<a name="producttotagsget"></a>
# **ProductToTagsGet**
> ProductToTag ProductToTagsGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string ids = null, int? product = null, int? tag = null)

Ürün SEO+ Bağı Listesi Alma

Ürün SEO+ Bağı listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductToTagsGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductToTagApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var product = 56;  // int? | Ürün id (optional) 
            var tag = 56;  // int? | Etiket id (optional) 

            try
            {
                // Ürün SEO+ Bağı Listesi Alma
                ProductToTag result = apiInstance.ProductToTagsGet(sort, limit, page, sinceId, ids, product, tag);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductToTagApi.ProductToTagsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **product** | **int?**| Ürün id | [optional] 
 **tag** | **int?**| Etiket id | [optional] 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="producttotagsiddelete"></a>
# **ProductToTagsIdDelete**
> void ProductToTagsIdDelete (int? id)

Ürün SEO+ Bağı Silme

Kalıcı olarak ilgili Ürün SEO+ Bağını siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductToTagsIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductToTagApi();
            var id = 56;  // int? | Ürün SEO+ nesnesinin id değeri

            try
            {
                // Ürün SEO+ Bağı Silme
                apiInstance.ProductToTagsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductToTagApi.ProductToTagsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün SEO+ nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="producttotagsidget"></a>
# **ProductToTagsIdGet**
> ProductToTag ProductToTagsIdGet (int? id)

Ürün SEO+ Bağı Alma

İlgili Ürün SEO+ Bağını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductToTagsIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductToTagApi();
            var id = 56;  // int? | Ürün SEO+ nesnesinin id değeri

            try
            {
                // Ürün SEO+ Bağı Alma
                ProductToTag result = apiInstance.ProductToTagsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductToTagApi.ProductToTagsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün SEO+ nesnesinin id değeri | 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="producttotagsidput"></a>
# **ProductToTagsIdPut**
> ProductToTag ProductToTagsIdPut (int? id, ProductToTag productToTag)

Ürün SEO+ Bağı Güncelleme

İlgili Ürün SEO+ Bağını günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductToTagsIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductToTagApi();
            var id = 56;  // int? | Ürün SEO+ nesnesinin id değeri
            var productToTag = new ProductToTag(); // ProductToTag |  nesnesi

            try
            {
                // Ürün SEO+ Bağı Güncelleme
                ProductToTag result = apiInstance.ProductToTagsIdPut(id, productToTag);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductToTagApi.ProductToTagsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün SEO+ nesnesinin id değeri | 
 **productToTag** | [**ProductToTag**](ProductToTag.md)|  nesnesi | 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="producttotagspost"></a>
# **ProductToTagsPost**
> ProductToTag ProductToTagsPost (ProductToTag productToTag)

Ürün SEO+ Bağı Oluşturma

Yeni bir Ürün SEO+ Bağı oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductToTagsPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductToTagApi();
            var productToTag = new ProductToTag(); // ProductToTag |  nesnesi

            try
            {
                // Ürün SEO+ Bağı Oluşturma
                ProductToTag result = apiInstance.ProductToTagsPost(productToTag);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductToTagApi.ProductToTagsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productToTag** | [**ProductToTag**](ProductToTag.md)|  nesnesi | 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

