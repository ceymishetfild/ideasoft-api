# IO.Swagger.Api.ShippingAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ShippingAddressesGet**](ShippingAddressApi.md#shippingaddressesget) | **GET** /shipping_addresses | Teslimat Adresi Listesi Alma
[**ShippingAddressesIdGet**](ShippingAddressApi.md#shippingaddressesidget) | **GET** /shipping_addresses/{id} | Teslimat Adresi Alma
[**ShippingAddressesIdPut**](ShippingAddressApi.md#shippingaddressesidput) | **PUT** /shipping_addresses/{id} | Teslimat Adresi Güncelleme
[**ShippingAddressesPost**](ShippingAddressApi.md#shippingaddressespost) | **POST** /shipping_addresses | Teslimat Adresi Oluşturma


<a name="shippingaddressesget"></a>
# **ShippingAddressesGet**
> ShippingAddress ShippingAddressesGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, int? order = null, DateTime? startDate = null, string endDate = null, DateTime? startUpdatedAt = null, string endUpdatedAt = null)

Teslimat Adresi Listesi Alma

Teslimat Adresi listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShippingAddressesGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShippingAddressApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var order = 56;  // int? | Sipariş id (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 

            try
            {
                // Teslimat Adresi Listesi Alma
                ShippingAddress result = apiInstance.ShippingAddressesGet(sort, limit, page, sinceId, order, startDate, endDate, startUpdatedAt, endUpdatedAt);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShippingAddressApi.ShippingAddressesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **int?**| Sipariş id | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shippingaddressesidget"></a>
# **ShippingAddressesIdGet**
> ShippingAddress ShippingAddressesIdGet (int? id)

Teslimat Adresi Alma

İlgili Teslimat Adresi getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShippingAddressesIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShippingAddressApi();
            var id = 56;  // int? | Teslimat Adresi nesnesinin id değeri

            try
            {
                // Teslimat Adresi Alma
                ShippingAddress result = apiInstance.ShippingAddressesIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShippingAddressApi.ShippingAddressesIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Teslimat Adresi nesnesinin id değeri | 

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shippingaddressesidput"></a>
# **ShippingAddressesIdPut**
> ShippingAddress ShippingAddressesIdPut (int? id, ShippingAddress shippingAddress)

Teslimat Adresi Güncelleme

İlgili Teslimat Adresi günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShippingAddressesIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShippingAddressApi();
            var id = 56;  // int? | Teslimat Adresi nesnesinin id değeri
            var shippingAddress = new ShippingAddress(); // ShippingAddress | ShippingAddress nesnesi

            try
            {
                // Teslimat Adresi Güncelleme
                ShippingAddress result = apiInstance.ShippingAddressesIdPut(id, shippingAddress);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShippingAddressApi.ShippingAddressesIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Teslimat Adresi nesnesinin id değeri | 
 **shippingAddress** | [**ShippingAddress**](ShippingAddress.md)| ShippingAddress nesnesi | 

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shippingaddressespost"></a>
# **ShippingAddressesPost**
> ShippingAddress ShippingAddressesPost (ShippingAddress shippingAddress)

Teslimat Adresi Oluşturma

Yeni bir Teslimat Adresi oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShippingAddressesPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShippingAddressApi();
            var shippingAddress = new ShippingAddress(); // ShippingAddress | ShippingAddress nesnesi

            try
            {
                // Teslimat Adresi Oluşturma
                ShippingAddress result = apiInstance.ShippingAddressesPost(shippingAddress);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShippingAddressApi.ShippingAddressesPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shippingAddress** | [**ShippingAddress**](ShippingAddress.md)| ShippingAddress nesnesi | 

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

