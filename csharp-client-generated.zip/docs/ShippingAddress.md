# IO.Swagger.Model.ShippingAddress
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Sipariş adresi nesnesi kimlik değeri. | [optional] 
**Firstname** | **string** | Müşterinin ismi. | 
**Surname** | **string** | Müşterinin soy ismi. | 
**Country** | **string** | Müşterinin ülke bilgisi. | 
**Location** | **string** | Müşterinin şehir bilgisi. | 
**SubLocation** | **string** | Müşterinin ilçe bilgisi. | [optional] 
**Address** | **string** | Müşterinin adres bilgisi. | 
**PhoneNumber** | **string** | Müşterinin telefon numarası. | 
**MobilePhoneNumber** | **string** | Müşterinin mobil telefon numarası. | [optional] 
**Order** | [**Order**](Order.md) | Sipariş nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

