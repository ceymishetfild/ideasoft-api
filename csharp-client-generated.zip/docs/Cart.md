# IO.Swagger.Model.Cart
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Sepet nesnesi kimlik değeri. | [optional] 
**SessionId** | **string** | Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri. | 
**Locked** | **string** | Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz. | [optional] 
**CreatedAt** | **DateTime?** | Sepet nesnesinin oluşturulma zamanı. | [optional] 
**UpdatedAt** | **DateTime?** | Sepet nesnesinin güncellenme zamanı. | [optional] 
**ChosenPromotion** | [**ShopCampaigns**](ShopCampaigns.md) |  | [optional] 
**Member** | [**Member**](Member.md) |  | [optional] 
**ChosenToken** | [**ShopTokens**](ShopTokens.md) |  | [optional] 
**Items** | [**List&lt;CartItem&gt;**](CartItem.md) | Sepet kalemi nesnelerini barındıran liste. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

