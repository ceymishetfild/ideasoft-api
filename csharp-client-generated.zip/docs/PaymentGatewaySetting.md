# IO.Swagger.Model.PaymentGatewaySetting
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ödeme kanalı ayarı nesnesi kimlik değeri. | [optional] 
**VarKey** | **string** | Ödeme kanalı ayarı nesnesi için değişken anahtarı. | 
**VarValue** | **string** | Ödeme kanalı ayarı nesnesi için değişken değeri. | 
**PaymentGateway** | [**PaymentGateway**](PaymentGateway.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

