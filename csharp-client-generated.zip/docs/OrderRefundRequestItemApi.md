# IO.Swagger.Api.OrderRefundRequestItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**OrderRefundRequestItemsGet**](OrderRefundRequestItemApi.md#orderrefundrequestitemsget) | **GET** /order_refund_request_items | Sipariş İptal Talebi Kalemi Listesi Alma
[**OrderRefundRequestItemsIdDelete**](OrderRefundRequestItemApi.md#orderrefundrequestitemsiddelete) | **DELETE** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Silme
[**OrderRefundRequestItemsIdGet**](OrderRefundRequestItemApi.md#orderrefundrequestitemsidget) | **GET** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Alma
[**OrderRefundRequestItemsIdPut**](OrderRefundRequestItemApi.md#orderrefundrequestitemsidput) | **PUT** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Güncelleme
[**OrderRefundRequestItemsPost**](OrderRefundRequestItemApi.md#orderrefundrequestitemspost) | **POST** /order_refund_request_items | Sipariş İptal Talebi Kalemi Oluşturma


<a name="orderrefundrequestitemsget"></a>
# **OrderRefundRequestItemsGet**
> OrderRefundRequestItem OrderRefundRequestItemsGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string ids = null, int? orderRefundRequest = null, int? orderItem = null, DateTime? startDate = null, string endDate = null, DateTime? startUpdatedAt = null, string endUpdatedAt = null)

Sipariş İptal Talebi Kalemi Listesi Alma

Sipariş İptal Talebi Kalemi listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderRefundRequestItemsGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderRefundRequestItemApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var orderRefundRequest = 56;  // int? | Sipariş iptal talebi id (optional) 
            var orderItem = 56;  // int? | Sipariş ürünü id (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 

            try
            {
                // Sipariş İptal Talebi Kalemi Listesi Alma
                OrderRefundRequestItem result = apiInstance.OrderRefundRequestItemsGet(sort, limit, page, sinceId, ids, orderRefundRequest, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderRefundRequestItemApi.OrderRefundRequestItemsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **orderRefundRequest** | **int?**| Sipariş iptal talebi id | [optional] 
 **orderItem** | **int?**| Sipariş ürünü id | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderrefundrequestitemsiddelete"></a>
# **OrderRefundRequestItemsIdDelete**
> void OrderRefundRequestItemsIdDelete (int? id)

Sipariş İptal Talebi Kalemi Silme

Kalıcı olarak ilgili Sipariş İptal Talebi Kalemini siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderRefundRequestItemsIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderRefundRequestItemApi();
            var id = 56;  // int? | Sipariş İptal Talebi Kalemi nesnesinin id değeri

            try
            {
                // Sipariş İptal Talebi Kalemi Silme
                apiInstance.OrderRefundRequestItemsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderRefundRequestItemApi.OrderRefundRequestItemsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş İptal Talebi Kalemi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderrefundrequestitemsidget"></a>
# **OrderRefundRequestItemsIdGet**
> OrderRefundRequestItem OrderRefundRequestItemsIdGet (int? id)

Sipariş İptal Talebi Kalemi Alma

İlgili Sipariş İptal Talebi Kalemini getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderRefundRequestItemsIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderRefundRequestItemApi();
            var id = 56;  // int? | Sipariş İptal Talebi Kalemi nesnesinin id değeri

            try
            {
                // Sipariş İptal Talebi Kalemi Alma
                OrderRefundRequestItem result = apiInstance.OrderRefundRequestItemsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderRefundRequestItemApi.OrderRefundRequestItemsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş İptal Talebi Kalemi nesnesinin id değeri | 

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderrefundrequestitemsidput"></a>
# **OrderRefundRequestItemsIdPut**
> OrderRefundRequestItem OrderRefundRequestItemsIdPut (int? id, OrderRefundRequestItem orderRefundRequestItem)

Sipariş İptal Talebi Kalemi Güncelleme

İlgili Sipariş İptal Talebi Kalemini günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderRefundRequestItemsIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderRefundRequestItemApi();
            var id = 56;  // int? | Sipariş İptal Talebi Kalemi nesnesinin id değeri
            var orderRefundRequestItem = new OrderRefundRequestItem(); // OrderRefundRequestItem |  nesnesi

            try
            {
                // Sipariş İptal Talebi Kalemi Güncelleme
                OrderRefundRequestItem result = apiInstance.OrderRefundRequestItemsIdPut(id, orderRefundRequestItem);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderRefundRequestItemApi.OrderRefundRequestItemsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş İptal Talebi Kalemi nesnesinin id değeri | 
 **orderRefundRequestItem** | [**OrderRefundRequestItem**](OrderRefundRequestItem.md)|  nesnesi | 

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderrefundrequestitemspost"></a>
# **OrderRefundRequestItemsPost**
> OrderRefundRequestItem OrderRefundRequestItemsPost (OrderRefundRequestItem orderRefundRequestItem)

Sipariş İptal Talebi Kalemi Oluşturma

Yeni bir Sipariş İptal Talebi Kalemi oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderRefundRequestItemsPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderRefundRequestItemApi();
            var orderRefundRequestItem = new OrderRefundRequestItem(); // OrderRefundRequestItem |  nesnesi

            try
            {
                // Sipariş İptal Talebi Kalemi Oluşturma
                OrderRefundRequestItem result = apiInstance.OrderRefundRequestItemsPost(orderRefundRequestItem);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderRefundRequestItemApi.OrderRefundRequestItemsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orderRefundRequestItem** | [**OrderRefundRequestItem**](OrderRefundRequestItem.md)|  nesnesi | 

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

