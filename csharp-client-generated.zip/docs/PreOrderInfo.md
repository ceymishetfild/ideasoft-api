# IO.Swagger.Model.PreOrderInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Sipariş öncesi bilgisi nesnesi kimlik değeri. | [optional] 
**SessionId** | **string** | Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri. | 
**CustomerFirstname** | **string** | Müşterinin ismi. | [optional] 
**CustomerSurname** | **string** | Müşterinin soy ismi. | [optional] 
**CustomerEmail** | **string** | Müşterinin e-mail adresi. | [optional] 
**ShippingFirstname** | **string** | Teslimat yapılacak kişinin ismi. | 
**ShippingSurname** | **string** | Teslimat yapılacak kişinin soy ismi. | 
**ShippingAddress** | **string** | Teslimat adresi bilgileri. | 
**ShippingPhoneNumber** | **string** | Teslimat yapılacak kişinin telefon numarası. | 
**ShippingMobilePhoneNumber** | **string** | Teslimat yapılacak kişinin mobil telefon numarası. | 
**ShippingLocationName** | **string** | Teslimat şehri. | 
**ShippingTown** | **string** | Teslimat ilçesi. | 
**DifferentBillingAddress** | **string** | Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yok&lt;br&gt;&lt;/div&gt; | [optional] 
**BillingFirstname** | **string** | Fatura kesilen kişinin ismi. | 
**BillingSurname** | **string** | Fatura kesilen kişinin soy ismi. | 
**BillingAddress** | **string** | Fatura adresi bilgileri. | 
**BillingPhoneNumber** | **string** | Fatura kesilen kişinin telefon numarası. | 
**BillingMobilePhoneNumber** | **string** | Fatura kesilen kişinin mobil telefon numarası. | 
**BillingLocationName** | **string** | Fatura adresi şehri | 
**BillingTown** | **string** | Fatura adresi ilçesi. | 
**BillingInvoiceType** | **string** | Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt; | 
**BillingIdentityRegistrationNumber** | **string** | Fatura kesilen kişinin TC kimlik numarası. | [optional] 
**BillingTaxOffice** | **string** | Fatura kesilen kişi/kurumun vergi dairesi. | [optional] 
**BillingTaxNo** | **string** | Fatura kesilen kişi/kurum vergi numarası. | [optional] 
**IsEinvoiceUser** | **string** | Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] 
**UseGiftPackage** | **string** | Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] 
**GiftNote** | **string** | Hediye notu bilgisi. | [optional] 
**ImageFile** | **string** | Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif | [optional] 
**DeliveryDate** | **DateTime?** | Müşterinin teslimatın gerçekleşmisini istediği tarih. | [optional] 
**DeliveryTime** | **string** | API bu değeri otomatik oluşturur. | [optional] 
**CreatedAt** | **DateTime?** | Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı. | [optional] 
**UpdatedAt** | **DateTime?** | Sipariş öncesi bilgisi nesnesinin güncellenme zamanı. | [optional] 
**BillingCountry** | [**Country**](Country.md) | Ülke nesnesi. | 
**BillingLocation** | [**Location**](Location.md) | Şehir nesnesi. | 
**ShippingCompany** | [**ShippingCompany**](ShippingCompany.md) | Kargo firması nesnesi. | 
**ShippingCountry** | [**Country**](Country.md) | Ülke nesnesi. | 
**ShippingLocation** | [**Location**](Location.md) | Şehir nesnesi. | 
**MemberShippingAddress** | [**MemberAddress**](MemberAddress.md) | Üye adresi nesnesi. | [optional] 
**MemberBillingAddress** | [**MemberAddress**](MemberAddress.md) | Üye adresi nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

