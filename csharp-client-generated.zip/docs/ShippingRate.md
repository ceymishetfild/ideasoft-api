# IO.Swagger.Model.ShippingRate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Kargo oranı nesnesi kimlik değeri. | [optional] 
**VolumetricWeightStart** | **int?** | İlgili kargo firması, ilgili bölge ve ilgili orana ait minimum desi değeri. | 
**VolumetricWeightEnd** | **int?** | İlgili kargo firması, ilgili bölge ve ilgili orana ait maximum desi değeri. | 
**Rate** | **float?** | Seçili bölge ve kargo firması için kargo oranı. | 
**Region** | [**Region**](Region.md) | Bölge nesnesi. | [optional] 
**ShippingCompany** | [**ShippingCompany**](ShippingCompany.md) | Kargo firması nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

