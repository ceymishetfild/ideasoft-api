# IO.Swagger.Model.OrderRefundRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Sipariş iptal talebi nesnesi kimlik değeri. | [optional] 
**Code** | **string** | Sipariş iptal talebi için oluşturulan benzersiz kod değeri. | 
**Status** | **string** | Sipariş iptal talebi için durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı.&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor.&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi.&lt;br&gt;&lt;/div&gt; | 
**Fee** | **float?** | Müşteriye ödenecek miktar bilgisi. | 
**CancellationReason** | **string** | Sipariş iptal talebinin oluşturulması sebebinin detaylı açıklaması. | [optional] 
**CreatedAt** | **DateTime?** | Sipariş iptal talebi nesnesinin oluşturulma zamanı. | 
**UpdatedAt** | **DateTime?** | Sipariş iptal talebi nesnesinin güncellenme zamanı. | 
**Member** | [**Member**](Member.md) |  | [optional] 
**Order** | [**Order**](Order.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

