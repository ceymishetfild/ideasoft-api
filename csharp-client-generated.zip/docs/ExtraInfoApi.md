# IO.Swagger.Api.ExtraInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ExtraInfosGet**](ExtraInfoApi.md#extrainfosget) | **GET** /extra_infos | Ek Bilgi Listesi Alma
[**ExtraInfosIdDelete**](ExtraInfoApi.md#extrainfosiddelete) | **DELETE** /extra_infos/{id} | Ek Bilgi Silme
[**ExtraInfosIdGet**](ExtraInfoApi.md#extrainfosidget) | **GET** /extra_infos/{id} | Ek Bilgi Alma
[**ExtraInfosIdPut**](ExtraInfoApi.md#extrainfosidput) | **PUT** /extra_infos/{id} | Ek Bilgi Güncelleme
[**ExtraInfosPost**](ExtraInfoApi.md#extrainfospost) | **POST** /extra_infos | Ek Bilgi Oluşturma


<a name="extrainfosget"></a>
# **ExtraInfosGet**
> ExtraInfo ExtraInfosGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string name = null)

Ek Bilgi Listesi Alma

Ek Bilgi listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ExtraInfosGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ExtraInfoApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var name = name_example;  // string | Ek Bilgi adı (optional) 

            try
            {
                // Ek Bilgi Listesi Alma
                ExtraInfo result = apiInstance.ExtraInfosGet(sort, limit, page, sinceId, name);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ExtraInfoApi.ExtraInfosGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **string**| Ek Bilgi adı | [optional] 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="extrainfosiddelete"></a>
# **ExtraInfosIdDelete**
> void ExtraInfosIdDelete (int? id)

Ek Bilgi Silme

Kalıcı olarak ilgili Ek Bilgiyi siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ExtraInfosIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ExtraInfoApi();
            var id = 56;  // int? | Ek Bilgi nesnesinin id değeri

            try
            {
                // Ek Bilgi Silme
                apiInstance.ExtraInfosIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ExtraInfoApi.ExtraInfosIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ek Bilgi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="extrainfosidget"></a>
# **ExtraInfosIdGet**
> ExtraInfo ExtraInfosIdGet (int? id)

Ek Bilgi Alma

İlgili Ek Bilgiyi getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ExtraInfosIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ExtraInfoApi();
            var id = 56;  // int? | Ek Bilgi nesnesinin id değeri

            try
            {
                // Ek Bilgi Alma
                ExtraInfo result = apiInstance.ExtraInfosIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ExtraInfoApi.ExtraInfosIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ek Bilgi nesnesinin id değeri | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="extrainfosidput"></a>
# **ExtraInfosIdPut**
> ExtraInfo ExtraInfosIdPut (int? id, ExtraInfo extraInfo)

Ek Bilgi Güncelleme

İlgili Ek Bilgiyi günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ExtraInfosIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ExtraInfoApi();
            var id = 56;  // int? | Ek Bilgi nesnesinin id değeri
            var extraInfo = new ExtraInfo(); // ExtraInfo | ExtraInfo nesnesi

            try
            {
                // Ek Bilgi Güncelleme
                ExtraInfo result = apiInstance.ExtraInfosIdPut(id, extraInfo);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ExtraInfoApi.ExtraInfosIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ek Bilgi nesnesinin id değeri | 
 **extraInfo** | [**ExtraInfo**](ExtraInfo.md)| ExtraInfo nesnesi | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="extrainfospost"></a>
# **ExtraInfosPost**
> ExtraInfo ExtraInfosPost (ExtraInfo extraInfo)

Ek Bilgi Oluşturma

Yeni bir Ek Bilgi oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ExtraInfosPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ExtraInfoApi();
            var extraInfo = new ExtraInfo(); // ExtraInfo | ExtraInfo nesnesi

            try
            {
                // Ek Bilgi Oluşturma
                ExtraInfo result = apiInstance.ExtraInfosPost(extraInfo);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ExtraInfoApi.ExtraInfosPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extraInfo** | [**ExtraInfo**](ExtraInfo.md)| ExtraInfo nesnesi | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

