# IO.Swagger.Api.BrandApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**BrandsGet**](BrandApi.md#brandsget) | **GET** /brands | Marka Listesi Alma
[**BrandsIdDelete**](BrandApi.md#brandsiddelete) | **DELETE** /brands/{id} | Marka Silme
[**BrandsIdGet**](BrandApi.md#brandsidget) | **GET** /brands/{id} | Marka Alma
[**BrandsIdPut**](BrandApi.md#brandsidput) | **PUT** /brands/{id} | Marka Güncelleme
[**BrandsPost**](BrandApi.md#brandspost) | **POST** /brands | Marka Oluşturma


<a name="brandsget"></a>
# **BrandsGet**
> Brand BrandsGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string ids = null, string name = null, string status = null, string distributor = null, DateTime? startDate = null, string endDate = null, DateTime? startUpdatedAt = null, string endUpdatedAt = null, List<string> q = null)

Marka Listesi Alma

Marka listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BrandsGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BrandApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var name = name_example;  // string | Marka adı. (optional) 
            var status = status_example;  // string | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif (optional) 
            var distributor = distributor_example;  // string | Marka distribörü (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 
            var q = new List<string>(); // List<string> | Marka arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;] (optional) 

            try
            {
                // Marka Listesi Alma
                Brand result = apiInstance.BrandsGet(sort, limit, page, sinceId, ids, name, status, distributor, startDate, endDate, startUpdatedAt, endUpdatedAt, q);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BrandApi.BrandsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **string**| Marka adı. | [optional] 
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **distributor** | **string**| Marka distribörü | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 
 **q** | [**List&lt;string&gt;**](string.md)| Marka arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="brandsiddelete"></a>
# **BrandsIdDelete**
> void BrandsIdDelete (int? id)

Marka Silme

Kalıcı olarak ilgili Markayı siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BrandsIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BrandApi();
            var id = 56;  // int? | Marka nesnesinin id değeri

            try
            {
                // Marka Silme
                apiInstance.BrandsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BrandApi.BrandsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Marka nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="brandsidget"></a>
# **BrandsIdGet**
> Brand BrandsIdGet (int? id)

Marka Alma

İlgili Markayı getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BrandsIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BrandApi();
            var id = 56;  // int? | Marka nesnesinin id değeri

            try
            {
                // Marka Alma
                Brand result = apiInstance.BrandsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BrandApi.BrandsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Marka nesnesinin id değeri | 

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="brandsidput"></a>
# **BrandsIdPut**
> Brand BrandsIdPut (int? id, Brand brand)

Marka Güncelleme

İlgili Markayı günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BrandsIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BrandApi();
            var id = 56;  // int? | Marka nesnesinin id değeri
            var brand = new Brand(); // Brand |  nesnesi

            try
            {
                // Marka Güncelleme
                Brand result = apiInstance.BrandsIdPut(id, brand);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BrandApi.BrandsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Marka nesnesinin id değeri | 
 **brand** | [**Brand**](Brand.md)|  nesnesi | 

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="brandspost"></a>
# **BrandsPost**
> Brand BrandsPost (Brand brand)

Marka Oluşturma

Yeni bir Marka oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BrandsPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BrandApi();
            var brand = new Brand(); // Brand |  nesnesi

            try
            {
                // Marka Oluşturma
                Brand result = apiInstance.BrandsPost(brand);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BrandApi.BrandsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **brand** | [**Brand**](Brand.md)|  nesnesi | 

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

