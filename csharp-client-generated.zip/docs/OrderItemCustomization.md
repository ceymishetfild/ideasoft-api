# IO.Swagger.Model.OrderItemCustomization
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Sipariş kalemi özelleştirme kimlik değeri. | [optional] 
**ProductCustomizationGroupId** | **int?** | Ürün özelleştirme grubu nesnesi kimlik değeri. | [optional] 
**ProductCustomizationGroupName** | **string** | Ürün özelleştirme grubu nesnesinin grup adı. | [optional] 
**ProductCustomizationGroupSortOrder** | **int?** | Ürün özelleştirme grubu nesnesinin sıralaması. | [optional] 
**ProductCustomizationFieldId** | **int?** | Ürün özelleştirme nesnesi kimlik değeri.. | [optional] 
**ProductCustomizationFieldType** | **string** | Ürün özelleştirme nesnesinin alan tipi. | [optional] 
**ProductCustomizationFieldName** | **string** | Ürün özelleştirme nesnesinin alan adı. | [optional] 
**ProductCustomizationFieldValue** | **string** | Ürün özelleştirme nesnesinin değeri. | [optional] 
**CartItemAttributeId** | **int?** | Sepet kalemi özelliği nesnesi kimlik değeri. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

