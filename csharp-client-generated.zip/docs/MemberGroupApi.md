# IO.Swagger.Api.MemberGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**MemberGroupsGet**](MemberGroupApi.md#membergroupsget) | **GET** /member_groups | Üye Grubu Listesi Alma
[**MemberGroupsIdDelete**](MemberGroupApi.md#membergroupsiddelete) | **DELETE** /member_groups/{id} | Üye Grubu Silme
[**MemberGroupsIdGet**](MemberGroupApi.md#membergroupsidget) | **GET** /member_groups/{id} | Üye Grubu Alma
[**MemberGroupsIdPut**](MemberGroupApi.md#membergroupsidput) | **PUT** /member_groups/{id} | Üye Grubu Güncelleme
[**MemberGroupsPost**](MemberGroupApi.md#membergroupspost) | **POST** /member_groups | Üye Grubu Oluşturma


<a name="membergroupsget"></a>
# **MemberGroupsGet**
> MemberGroup MemberGroupsGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string name = null)

Üye Grubu Listesi Alma

Üye Grubu listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MemberGroupsGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberGroupApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var name = name_example;  // string | Üye Grubu adı (optional) 

            try
            {
                // Üye Grubu Listesi Alma
                MemberGroup result = apiInstance.MemberGroupsGet(sort, limit, page, sinceId, name);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberGroupApi.MemberGroupsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **string**| Üye Grubu adı | [optional] 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="membergroupsiddelete"></a>
# **MemberGroupsIdDelete**
> void MemberGroupsIdDelete (int? id)

Üye Grubu Silme

Kalıcı olarak ilgili Üye Grubunu siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MemberGroupsIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberGroupApi();
            var id = 56;  // int? | Üye Grubu nesnesinin id değeri

            try
            {
                // Üye Grubu Silme
                apiInstance.MemberGroupsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberGroupApi.MemberGroupsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Üye Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="membergroupsidget"></a>
# **MemberGroupsIdGet**
> MemberGroup MemberGroupsIdGet (int? id)

Üye Grubu Alma

İlgili Üye Grubunu getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MemberGroupsIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberGroupApi();
            var id = 56;  // int? | Üye Grubu nesnesinin id değeri

            try
            {
                // Üye Grubu Alma
                MemberGroup result = apiInstance.MemberGroupsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberGroupApi.MemberGroupsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Üye Grubu nesnesinin id değeri | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="membergroupsidput"></a>
# **MemberGroupsIdPut**
> MemberGroup MemberGroupsIdPut (int? id, MemberGroup memberGroup)

Üye Grubu Güncelleme

İlgili Üye Grubunu günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MemberGroupsIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberGroupApi();
            var id = 56;  // int? | Üye Grubu nesnesinin id değeri
            var memberGroup = new MemberGroup(); // MemberGroup | MemberGroup nesnesi

            try
            {
                // Üye Grubu Güncelleme
                MemberGroup result = apiInstance.MemberGroupsIdPut(id, memberGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberGroupApi.MemberGroupsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Üye Grubu nesnesinin id değeri | 
 **memberGroup** | [**MemberGroup**](MemberGroup.md)| MemberGroup nesnesi | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="membergroupspost"></a>
# **MemberGroupsPost**
> MemberGroup MemberGroupsPost (MemberGroup memberGroup)

Üye Grubu Oluşturma

Yeni bir Üye Grubu oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MemberGroupsPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberGroupApi();
            var memberGroup = new MemberGroup(); // MemberGroup | MemberGroup nesnesi

            try
            {
                // Üye Grubu Oluşturma
                MemberGroup result = apiInstance.MemberGroupsPost(memberGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberGroupApi.MemberGroupsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **memberGroup** | [**MemberGroup**](MemberGroup.md)| MemberGroup nesnesi | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

