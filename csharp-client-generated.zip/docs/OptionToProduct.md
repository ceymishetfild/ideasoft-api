# IO.Swagger.Model.OptionToProduct
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Varyant ürün bağı nesnesi kimlik değeri. | [optional] 
**ParentProductId** | **int?** | Ana ürünün benzersiz kimlik değeri. | 
**OptionGroup** | [**OptionGroup**](OptionGroup.md) | Varyant grubu nesnesi. | 
**Option** | [**Options**](Options.md) | Varyant nesnesi. | 
**Product** | [**Product**](Product.md) | Ürün nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

