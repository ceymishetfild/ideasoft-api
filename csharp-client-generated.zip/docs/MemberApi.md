# IO.Swagger.Api.MemberApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**MembersChartsGet**](MemberApi.md#memberschartsget) | **GET** /members/charts | Üye Grafik Aksiyonu
[**MembersCombinedGet**](MemberApi.md#memberscombinedget) | **GET** /members/combined | Üye Birleşik Aksiyonu
[**MembersGet**](MemberApi.md#membersget) | **GET** /members | Üye Listesi Alma
[**MembersIdDelete**](MemberApi.md#membersiddelete) | **DELETE** /members/{id} | Üye Silme
[**MembersIdGet**](MemberApi.md#membersidget) | **GET** /members/{id} | Üye Alma
[**MembersIdPut**](MemberApi.md#membersidput) | **PUT** /members/{id} | Üye Güncelleme
[**MembersPost**](MemberApi.md#memberspost) | **POST** /members | Üye Oluşturma


<a name="memberschartsget"></a>
# **MembersChartsGet**
> Member MembersChartsGet (string timeFrame, string startDate)

Üye Grafik Aksiyonu

Zaman bazında üye genel istatistiklerini getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MembersChartsGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberApi();
            var timeFrame = timeFrame_example;  // string | Şu değerleri olabilir: full, year, month or week
            var startDate = startDate_example;  // string | Zaman aralığının başlangıcı

            try
            {
                // Üye Grafik Aksiyonu
                Member result = apiInstance.MembersChartsGet(timeFrame, startDate);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberApi.MembersChartsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timeFrame** | **string**| Şu değerleri olabilir: full, year, month or week | 
 **startDate** | **string**| Zaman aralığının başlangıcı | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="memberscombinedget"></a>
# **MembersCombinedGet**
> Member MembersCombinedGet ()

Üye Birleşik Aksiyonu

Bugün, aylık, yıllık ve toplam üye oturum açma istatistiklerini totalCount cinsinden getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MembersCombinedGetExample
    {
        public void main()
        {
            var apiInstance = new MemberApi();

            try
            {
                // Üye Birleşik Aksiyonu
                Member result = apiInstance.MembersCombinedGet();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberApi.MembersCombinedGet: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Member**](Member.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="membersget"></a>
# **MembersGet**
> Member MembersGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string ids = null, string firstname = null, string surname = null, string email = null, string password = null, string gender = null, string mobilePhoneNumber = null, string phoneNumber = null, int? memberGroup = null, int? location = null, int? country = null, int? referredMember = null, List<string> q = null, DateTime? startDate = null, string endDate = null, DateTime? startUpdatedAt = null, string endUpdatedAt = null)

Üye Listesi Alma

Üye listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MembersGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var firstname = firstname_example;  // string | Adı (optional) 
            var surname = surname_example;  // string | Soyadı (optional) 
            var email = email_example;  // string | e-mail adresi (optional) 
            var password = password_example;  // string | Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri (optional) 
            var gender = gender_example;  // string | Cinsiyet şu değerleri alabilir: <br><code>male</code> : Erkek<br><code>female</code> : Kadın (optional) 
            var mobilePhoneNumber = mobilePhoneNumber_example;  // string | Üye mobil telefon numarası (optional) 
            var phoneNumber = phoneNumber_example;  // string | Üye telefon numarası (optional) 
            var memberGroup = 56;  // int? | Üye Grubu id (optional) 
            var location = 56;  // int? | Şehir id (optional) 
            var country = 56;  // int? | Ülke id (optional) 
            var referredMember = 56;  // int? | Tavsiye Üye id (optional) 
            var q = new List<string>(); // List<string> | Üye arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;] (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 

            try
            {
                // Üye Listesi Alma
                Member result = apiInstance.MembersGet(sort, limit, page, sinceId, ids, firstname, surname, email, password, gender, mobilePhoneNumber, phoneNumber, memberGroup, location, country, referredMember, q, startDate, endDate, startUpdatedAt, endUpdatedAt);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberApi.MembersGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **firstname** | **string**| Adı | [optional] 
 **surname** | **string**| Soyadı | [optional] 
 **email** | **string**| e-mail adresi | [optional] 
 **password** | **string**| Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri | [optional] 
 **gender** | **string**| Cinsiyet şu değerleri alabilir: &lt;br&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın | [optional] 
 **mobilePhoneNumber** | **string**| Üye mobil telefon numarası | [optional] 
 **phoneNumber** | **string**| Üye telefon numarası | [optional] 
 **memberGroup** | **int?**| Üye Grubu id | [optional] 
 **location** | **int?**| Şehir id | [optional] 
 **country** | **int?**| Ülke id | [optional] 
 **referredMember** | **int?**| Tavsiye Üye id | [optional] 
 **q** | [**List&lt;string&gt;**](string.md)| Üye arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="membersiddelete"></a>
# **MembersIdDelete**
> void MembersIdDelete (int? id)

Üye Silme

Kalıcı olarak ilgili Üyeyi siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MembersIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberApi();
            var id = 56;  // int? | Üye nesnesinin id değeri

            try
            {
                // Üye Silme
                apiInstance.MembersIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberApi.MembersIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Üye nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="membersidget"></a>
# **MembersIdGet**
> Member MembersIdGet (int? id)

Üye Alma

İlgili Üyeyi getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MembersIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberApi();
            var id = 56;  // int? | Üye nesnesinin id değeri

            try
            {
                // Üye Alma
                Member result = apiInstance.MembersIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberApi.MembersIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Üye nesnesinin id değeri | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="membersidput"></a>
# **MembersIdPut**
> Member MembersIdPut (int? id, Member member)

Üye Güncelleme

İlgili Üyeyi günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MembersIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberApi();
            var id = 56;  // int? | Üye nesnesinin id değeri
            var member = new Member(); // Member |  nesnesi

            try
            {
                // Üye Güncelleme
                Member result = apiInstance.MembersIdPut(id, member);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberApi.MembersIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Üye nesnesinin id değeri | 
 **member** | [**Member**](Member.md)|  nesnesi | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="memberspost"></a>
# **MembersPost**
> Member MembersPost (Member member)

Üye Oluşturma

Yeni bir Üye oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MembersPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberApi();
            var member = new Member(); // Member |  nesnesi

            try
            {
                // Üye Oluşturma
                Member result = apiInstance.MembersPost(member);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberApi.MembersPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member** | [**Member**](Member.md)|  nesnesi | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

