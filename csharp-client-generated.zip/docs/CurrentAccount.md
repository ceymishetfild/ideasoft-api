# IO.Swagger.Model.CurrentAccount
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Cari hesap nesnesi kimlik değeri. | [optional] 
**Code** | **string** | Cari hesap için düzenlenebilir bir kod değeri. | [optional] 
**Title** | **string** | Cari hesap nesnesinin başlığı. | 
**Balance** | **float?** | Cari hesabın bakiyesi. | [optional] 
**RiskLimit** | **float?** | Cari hesap için belirlenmiş risk limiti. | [optional] 
**CreatedAt** | **DateTime?** | Cari hesap nesnesinin oluşturulma zamanı. | [optional] 
**UpdatedAt** | **DateTime?** | Cari hesap nesnesinin güncellenme zamanı. | [optional] 
**Member** | [**Member**](Member.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

