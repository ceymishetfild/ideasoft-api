# IO.Swagger.Model.OrderItem
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Sipariş kalemi nesnesi kimlik değeri. | [optional] 
**ProductName** | **string** | Ürünün adı. | 
**ProductSku** | **string** | Ürünün stok kodu. | 
**ProductBarcode** | **string** | Ürünün barkodu. | [optional] 
**ProductPrice** | **float?** | Ürünün fiyatı. | 
**ProductCurrency** | **string** | Ürünün kuru. | 
**ProductQuantity** | **float?** | Ürünün stok tipi cinsinden miktarı. | 
**ProductTax** | **int?** | Ürünün vergisi | 
**ProductDiscount** | **float?** | Ürünün standart indirim değeri. | 
**ProductMoneyOrderDiscount** | **float?** | Ürünün havale indirim değeri. | 
**ProductWeight** | **float?** | Ürünün ağırlığı. | 
**ProductStockTypeLabel** | **string** | Ürünün stok tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Adet&lt;/code&gt; : Stok tipi birimi Adet&lt;br&gt;&lt;code&gt;cm&lt;/code&gt; : Stok tipi birimi Santimetre&lt;br&gt;&lt;code&gt;Düzine&lt;/code&gt; : Stok tipi birimi Düzine&lt;br&gt;&lt;code&gt;gram&lt;/code&gt; : Stok tipi birimi Gram&lt;br&gt;&lt;code&gt;kg&lt;/code&gt; : Stok tipi birimi Kilogram&lt;br&gt;&lt;code&gt;Kişi&lt;/code&gt; : Stok tipi birimi Kişi&lt;br&gt;&lt;code&gt;Paket&lt;/code&gt; : Stok tipi birimi Paket&lt;br&gt;&lt;code&gt;metre&lt;/code&gt; : Stok tipi birimi Metre&lt;br&gt;&lt;code&gt;m2&lt;/code&gt; : Stok tipi birimi Metre kare&lt;br&gt;&lt;code&gt;Çift&lt;/code&gt; : Stok tipi birimi Çift&lt;br&gt;&lt;/div&gt; | 
**IsProductPromotioned** | **string** | Ürünün promosyon olup olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;0&lt;/code&gt; : Ürün promosyon değil.&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Ürün promosyon.&lt;br&gt;&lt;/div&gt; | [optional] 
**Discount** | **float?** | Ürünün hediye çeki indirim değeri. | 
**Order** | [**Order**](Order.md) | Sipariş nesnesi. | [optional] 
**Product** | [**Product**](Product.md) | Ürün nesnesi. | [optional] 
**OrderItemSubscription** | [**OrderItemSubscription**](OrderItemSubscription.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

