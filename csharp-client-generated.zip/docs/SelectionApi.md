# IO.Swagger.Api.SelectionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SelectionsGet**](SelectionApi.md#selectionsget) | **GET** /selections | Ek Özellik Listesi Alma
[**SelectionsIdDelete**](SelectionApi.md#selectionsiddelete) | **DELETE** /selections/{id} | Ek Özellik Silme
[**SelectionsIdGet**](SelectionApi.md#selectionsidget) | **GET** /selections/{id} | Ek Özellik Alma
[**SelectionsIdPut**](SelectionApi.md#selectionsidput) | **PUT** /selections/{id} | Ek Özellik Güncelleme
[**SelectionsPost**](SelectionApi.md#selectionspost) | **POST** /selections | Ek Özellik Oluşturma


<a name="selectionsget"></a>
# **SelectionsGet**
> Selection SelectionsGet (string sort = null, int? limit = null, int? page = null, int? sinceId = null, string ids = null, string title = null, int? selectionGroup = null)

Ek Özellik Listesi Alma

Ek Özellik listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SelectionsGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SelectionApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var title = title_example;  // string | Ek Özellik başlığı (optional) 
            var selectionGroup = 56;  // int? | Ek Özellik Grubu id (optional) 

            try
            {
                // Ek Özellik Listesi Alma
                Selection result = apiInstance.SelectionsGet(sort, limit, page, sinceId, ids, title, selectionGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SelectionApi.SelectionsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **title** | **string**| Ek Özellik başlığı | [optional] 
 **selectionGroup** | **int?**| Ek Özellik Grubu id | [optional] 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="selectionsiddelete"></a>
# **SelectionsIdDelete**
> void SelectionsIdDelete (int? id)

Ek Özellik Silme

Kalıcı olarak ilgili Ek Özelliği siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SelectionsIdDeleteExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SelectionApi();
            var id = 56;  // int? | Ek Özellik nesnesinin id değeri

            try
            {
                // Ek Özellik Silme
                apiInstance.SelectionsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SelectionApi.SelectionsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ek Özellik nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="selectionsidget"></a>
# **SelectionsIdGet**
> Selection SelectionsIdGet (int? id)

Ek Özellik Alma

İlgili Ek Özelliği getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SelectionsIdGetExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SelectionApi();
            var id = 56;  // int? | Ek Özellik nesnesinin id değeri

            try
            {
                // Ek Özellik Alma
                Selection result = apiInstance.SelectionsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SelectionApi.SelectionsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ek Özellik nesnesinin id değeri | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="selectionsidput"></a>
# **SelectionsIdPut**
> Selection SelectionsIdPut (int? id, Selection selection)

Ek Özellik Güncelleme

İlgili Ek Özelliği günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SelectionsIdPutExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SelectionApi();
            var id = 56;  // int? | Ek Özellik nesnesinin id değeri
            var selection = new Selection(); // Selection |  nesnesi

            try
            {
                // Ek Özellik Güncelleme
                Selection result = apiInstance.SelectionsIdPut(id, selection);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SelectionApi.SelectionsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ek Özellik nesnesinin id değeri | 
 **selection** | [**Selection**](Selection.md)|  nesnesi | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="selectionspost"></a>
# **SelectionsPost**
> Selection SelectionsPost (Selection selection)

Ek Özellik Oluşturma

Yeni bir Ek Özellik oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SelectionsPostExample
    {
        public void main()
        {
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SelectionApi();
            var selection = new Selection(); // Selection |  nesnesi

            try
            {
                // Ek Özellik Oluşturma
                Selection result = apiInstance.SelectionsPost(selection);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SelectionApi.SelectionsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selection** | [**Selection**](Selection.md)|  nesnesi | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

