import { NgModule, ModuleWithProviders, SkipSelf, Optional } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Configuration } from './configuration';

import { BillingAddressService } from './api/billingAddress.service';
import { BrandService } from './api/brand.service';
import { CacheService } from './api/cache.service';
import { CartService } from './api/cart.service';
import { CartItemService } from './api/cartItem.service';
import { CategoryService } from './api/category.service';
import { CurrencyService } from './api/currency.service';
import { CurrentAccountService } from './api/currentAccount.service';
import { DistributorService } from './api/distributor.service';
import { DistributorToProductService } from './api/distributorToProduct.service';
import { ExtraInfoService } from './api/extraInfo.service';
import { ExtraInfoToProductService } from './api/extraInfoToProduct.service';
import { FavouritedProductService } from './api/favouritedProduct.service';
import { InstallmentRateService } from './api/installmentRate.service';
import { LocationService } from './api/location.service';
import { MaillistService } from './api/maillist.service';
import { MaillistGroupService } from './api/maillistGroup.service';
import { MemberService } from './api/member.service';
import { MemberAddressService } from './api/memberAddress.service';
import { MemberGroupService } from './api/memberGroup.service';
import { OptionGroupService } from './api/optionGroup.service';
import { OptionToProductService } from './api/optionToProduct.service';
import { OptionsService } from './api/options.service';
import { OrderService } from './api/order.service';
import { OrderDetailService } from './api/orderDetail.service';
import { OrderItemService } from './api/orderItem.service';
import { OrderRefundRequestService } from './api/orderRefundRequest.service';
import { OrderRefundRequestItemService } from './api/orderRefundRequestItem.service';
import { OrderUserNoteService } from './api/orderUserNote.service';
import { PaymentService } from './api/payment.service';
import { PaymentGatewayService } from './api/paymentGateway.service';
import { PaymentProviderService } from './api/paymentProvider.service';
import { PreOrderInfoService } from './api/preOrderInfo.service';
import { ProductService } from './api/product.service';
import { ProductButtonService } from './api/productButton.service';
import { ProductCommentService } from './api/productComment.service';
import { ProductDetailService } from './api/productDetail.service';
import { ProductImageService } from './api/productImage.service';
import { ProductPriceService } from './api/productPrice.service';
import { ProductProtectionService } from './api/productProtection.service';
import { ProductSpecialInfoService } from './api/productSpecialInfo.service';
import { ProductToCategoryService } from './api/productToCategory.service';
import { ProductToCountDownService } from './api/productToCountDown.service';
import { ProductToTagService } from './api/productToTag.service';
import { QuickCartService } from './api/quickCart.service';
import { RegionService } from './api/region.service';
import { SelectionService } from './api/selection.service';
import { SelectionGroupService } from './api/selectionGroup.service';
import { SelectionToProductService } from './api/selectionToProduct.service';
import { ShipmentService } from './api/shipment.service';
import { ShipmentItemService } from './api/shipmentItem.service';
import { ShippingAddressService } from './api/shippingAddress.service';
import { ShippingCompanyService } from './api/shippingCompany.service';
import { ShippingProviderService } from './api/shippingProvider.service';
import { ShippingRateService } from './api/shippingRate.service';
import { ShopPreferenceService } from './api/shopPreference.service';
import { SpecGroupService } from './api/specGroup.service';
import { SpecNameService } from './api/specName.service';
import { SpecToProductService } from './api/specToProduct.service';
import { SpecValueService } from './api/specValue.service';
import { TagService } from './api/tag.service';
import { ThemeService } from './api/theme.service';
import { TownService } from './api/town.service';
import { TownGroupService } from './api/townGroup.service';
import { UserService } from './api/user.service';

@NgModule({
  imports:      [ CommonModule, HttpClientModule ],
  declarations: [],
  exports:      [],
  providers: [
    BillingAddressService,
    BrandService,
    CacheService,
    CartService,
    CartItemService,
    CategoryService,
    CurrencyService,
    CurrentAccountService,
    DistributorService,
    DistributorToProductService,
    ExtraInfoService,
    ExtraInfoToProductService,
    FavouritedProductService,
    InstallmentRateService,
    LocationService,
    MaillistService,
    MaillistGroupService,
    MemberService,
    MemberAddressService,
    MemberGroupService,
    OptionGroupService,
    OptionToProductService,
    OptionsService,
    OrderService,
    OrderDetailService,
    OrderItemService,
    OrderRefundRequestService,
    OrderRefundRequestItemService,
    OrderUserNoteService,
    PaymentService,
    PaymentGatewayService,
    PaymentProviderService,
    PreOrderInfoService,
    ProductService,
    ProductButtonService,
    ProductCommentService,
    ProductDetailService,
    ProductImageService,
    ProductPriceService,
    ProductProtectionService,
    ProductSpecialInfoService,
    ProductToCategoryService,
    ProductToCountDownService,
    ProductToTagService,
    QuickCartService,
    RegionService,
    SelectionService,
    SelectionGroupService,
    SelectionToProductService,
    ShipmentService,
    ShipmentItemService,
    ShippingAddressService,
    ShippingCompanyService,
    ShippingProviderService,
    ShippingRateService,
    ShopPreferenceService,
    SpecGroupService,
    SpecNameService,
    SpecToProductService,
    SpecValueService,
    TagService,
    ThemeService,
    TownService,
    TownGroupService,
    UserService ]
})
export class ApiModule {
    public static forRoot(configurationFactory: () => Configuration): ModuleWithProviders {
        return {
            ngModule: ApiModule,
            providers: [ { provide: Configuration, useFactory: configurationFactory } ]
        }
    }

    constructor( @Optional() @SkipSelf() parentModule: ApiModule) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import your base AppModule only.');
        }
    }
}
