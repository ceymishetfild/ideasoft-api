goog.provide('API.Client.Brand');

/**
 * @record
 */
API.Client.Brand = function() {}

/**
 * Marka nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Brand.prototype.id;

/**
 * Marka nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.Brand.prototype.name;

/**
 * Slug değeri ilgili nesnenin Url değeridir.
 * @type {!string}
 * @export
 */
API.Client.Brand.prototype.slug;

/**
 * Marka nesnesi için sıralama değeri.
 * @type {!number}
 * @export
 */
API.Client.Brand.prototype.sortOrder;

/**
 * Marka nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.Brand.prototype.status;

/**
 * Markanın tedarikçisi.
 * @type {!string}
 * @export
 */
API.Client.Brand.prototype.distributor;

/**
 * Marka nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF
 * @type {!string}
 * @export
 */
API.Client.Brand.prototype.imageFile;

/**
 * Marka nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir.
 * @type {!string}
 * @export
 */
API.Client.Brand.prototype.showcaseContent;

/**
 * Marka nesnesi üst içerik metninin gösterim durumu.
 * @type {!string}
 * @export
 */
API.Client.Brand.prototype.displayShowcaseContent;

/**
 * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.
 * @type {!string}
 * @export
 */
API.Client.Brand.prototype.metaKeywords;

/**
 * Arama motorları tarafından tespit edilebilecek açıklama yazısı.
 * @type {!string}
 * @export
 */
API.Client.Brand.prototype.metaDescription;

/**
 * Marka nesnesinin etiket başlığı.
 * @type {!string}
 * @export
 */
API.Client.Brand.prototype.pageTitle;

/**
 * Marka nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
 * @type {!string}
 * @export
 */
API.Client.Brand.prototype.attachment;

/**
 * Marka nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Brand.prototype.createdAt;

/**
 * Marka nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Brand.prototype.updatedAt;

/** @enum {string} */
API.Client.Brand.StatusEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.Brand.DisplayShowcaseContentEnum = { 
  0: '0',
  1: '1',
}
