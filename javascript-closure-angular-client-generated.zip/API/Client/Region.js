goog.provide('API.Client.Region');

/**
 * @record
 */
API.Client.Region = function() {}

/**
 * Bölge nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Region.prototype.id;

/**
 * Bölge nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.Region.prototype.name;

