goog.provide('API.Client.Member');

/**
 * @record
 */
API.Client.Member = function() {}

/**
 * Üye nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Member.prototype.id;

/**
 * Üyenin ismi.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.firstname;

/**
 * Üyenin soy ismi.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.surname;

/**
 * Üyenin e-mail adresi.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.email;

/**
 * Üyenin cinsiyet bilgisi.<div class='idea_choice_list'><code>male</code> : Erkek<br><code>female</code> : Kadın<br></div>
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.gender;

/**
 * Üyenin doğum tarihi.
 * @type {!Date}
 * @export
 */
API.Client.Member.prototype.birthDate;

/**
 * Üyenin telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.phoneNumber;

/**
 * Üyenin mobil telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.mobilePhoneNumber;

/**
 * Üyenin diğer şehir bilgileri.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.otherLocation;

/**
 * Üyenin adres bilgileri.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.address;

/**
 * Üyenin vergi numarası.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.taxNumber;

/**
 * Üyenin TC kimlik numarası.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.tcId;

/**
 * Üyenin durum bilgisi.<div class='idea_choice_list'><code>queue</code> : Sırada<br><code>active</code> : Aktif<br><code>passive</code> : Pasif<br><code>suspended</code> : Askıda<br></div>
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.status;

/**
 * Üyenin son giriş yaptığı tarih.
 * @type {!Date}
 * @export
 */
API.Client.Member.prototype.lastLoginDate;

/**
 * Üye nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Member.prototype.createdAt;

/**
 * Üye nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Member.prototype.updatedAt;

/**
 * Üyenin posta kodu.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.zipCode;

/**
 * Üyenin kurumsal adı.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.commercialName;

/**
 * Üyenin vergi dairesi.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.taxOffice;

/**
 * Üyeye gönderilen son e-mail tarihi.
 * @type {!Date}
 * @export
 */
API.Client.Member.prototype.lastMailSentDate;

/**
 * Üyenin en son giriş yaptığı IP adresi.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.lastIp;

/**
 * Üyenin kazandığı puan tutarı.
 * @type {!number}
 * @export
 */
API.Client.Member.prototype.gainedPointAmount;

/**
 * Üyenin harcadığı puan tutarı.
 * @type {!number}
 * @export
 */
API.Client.Member.prototype.spentPointAmount;

/**
 * Üyenin kampanyalara katılım için izin durumu.<div class='idea_choice_list'><code>1</code> : Kampanyalar için izinli.<br><code>0</code> : Kampanyalar için izinsiz.<br></div>
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.allowedToCampaigns;

/**
 * Üyenin tavsiye ettiği kişilerden dolayı kazandığı puan.
 * @type {!number}
 * @export
 */
API.Client.Member.prototype.referredMemberGainedPointAmount;

/**
 * Üyenin ilçesi.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.district;

/**
 * Üyenin kullandığı cihaz tipi.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.deviceType;

/**
 * Üyenin kullandığı cihaz bilgisi.
 * @type {!string}
 * @export
 */
API.Client.Member.prototype.deviceInfo;

/**
 * @type {!API.Client.Country}
 * @export
 */
API.Client.Member.prototype.country;

/**
 * @type {!API.Client.Location}
 * @export
 */
API.Client.Member.prototype.location;

/**
 * @type {!API.Client.MemberGroup}
 * @export
 */
API.Client.Member.prototype.memberGroup;

/**
 * @type {!API.Client.Member}
 * @export
 */
API.Client.Member.prototype.referredMember;

/** @enum {string} */
API.Client.Member.GenderEnum = { 
  male: 'male',
  female: 'female',
}
/** @enum {string} */
API.Client.Member.StatusEnum = { 
  queue: 'queue',
  active: 'active',
  passive: 'passive',
  suspended: 'suspended',
}
/** @enum {string} */
API.Client.Member.AllowedToCampaignsEnum = { 
  0: '0',
  1: '1',
}
