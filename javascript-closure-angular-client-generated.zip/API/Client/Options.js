goog.provide('API.Client.Options');

/**
 * @record
 */
API.Client.Options = function() {}

/**
 * Varyant nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Options.prototype.id;

/**
 * Varyant başlığı. Varyant Grubu renk is bu değer kırmızı olabilir.
 * @type {!string}
 * @export
 */
API.Client.Options.prototype.title;

/**
 * Varyant nesnesi için sıralama değeri.
 * @type {!number}
 * @export
 */
API.Client.Options.prototype.sortOrder;

/**
 * Logo görselinin adı.<div class='idea_choice_list'><code>jpg</code> : jpg dosyası için geçerli uzantı.<br><code>png</code> : png dosyası için geçerli uzantı.<br><code>gif</code> : gif dosyası için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyası için geçerli uzantı.<br></div>
 * @type {!string}
 * @export
 */
API.Client.Options.prototype.logo;

/**
 * @type {!API.Client.OptionGroup}
 * @export
 */
API.Client.Options.prototype.optionGroup;

/**
 * Varyant nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
 * @type {!string}
 * @export
 */
API.Client.Options.prototype.attachment;

/** @enum {string} */
API.Client.Options.LogoEnum = { 
  jpg: 'jpg',
  png: 'png',
  gif: 'gif',
  jpeg: 'jpeg',
}
