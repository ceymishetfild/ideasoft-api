goog.provide('API.Client.ProductToTag');

/**
 * @record
 */
API.Client.ProductToTag = function() {}

/**
 * Ürün SEO+ etiketi bağı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ProductToTag.prototype.id;

/**
 * Ürün nesnesi.
 * @type {!API.Client.Product}
 * @export
 */
API.Client.ProductToTag.prototype.product;

/**
 * SEO+ etiketi nesnesi.
 * @type {!API.Client.Tag}
 * @export
 */
API.Client.ProductToTag.prototype.tag;

