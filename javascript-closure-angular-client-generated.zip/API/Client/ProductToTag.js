goog.provide('API.Client.ProductToTag');

/**
 * @record
 */
API.Client.ProductToTag = function() {}

/**
 * Ürün SEO+ etiketi bağı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ProductToTag.prototype.id;

/**
 * @type {!API.Client.Product}
 * @export
 */
API.Client.ProductToTag.prototype.product;

/**
 * @type {!API.Client.Tag}
 * @export
 */
API.Client.ProductToTag.prototype.tag;

