goog.provide('API.Client.Asset');

/**
 * @record
 */
API.Client.Asset = function() {}

/**
 * Tema Dosyası nesnesi anahtar değeri.
 * @type {!string}
 * @export
 */
API.Client.Asset.prototype.key;

/**
 * Tema Dosyası içerik tipi. Geçerli bir MIME Content-Type verilmelidir.
 * @type {!string}
 * @export
 */
API.Client.Asset.prototype.contentType;

/**
 * Tema Dosyası içeriği.
 * @type {!string}
 * @export
 */
API.Client.Asset.prototype.attachment;

/**
 * Tema Dosyası nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Asset.prototype.createdAt;

/**
 * Tema Dosyası nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Asset.prototype.updatedAt;

