goog.provide('API.Client.Distributor');

/**
 * @record
 */
API.Client.Distributor = function() {}

/**
 * Distributor nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Distributor.prototype.id;

/**
 * Distributor nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.Distributor.prototype.name;

/**
 * E-mail adresi.
 * @type {!string}
 * @export
 */
API.Client.Distributor.prototype.email;

/**
 * Telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.Distributor.prototype.phone;

/**
 * İletişim kişisi.
 * @type {!string}
 * @export
 */
API.Client.Distributor.prototype.contactPerson;

