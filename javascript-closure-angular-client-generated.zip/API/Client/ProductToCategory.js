goog.provide('API.Client.ProductToCategory');

/**
 * @record
 */
API.Client.ProductToCategory = function() {}

/**
 * Ürün kategori bağı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ProductToCategory.prototype.id;

/**
 * Ürün kategori bağının sıralama değeri. Özel sıra belirtmek istemiyorsanız 9999 olarak iletebilirsiniz.
 * @type {!number}
 * @export
 */
API.Client.ProductToCategory.prototype.sortOrder;

/**
 * Ürün nesnesi.
 * @type {!API.Client.Product}
 * @export
 */
API.Client.ProductToCategory.prototype.product;

/**
 * Kategori nesnesi.
 * @type {!API.Client.Category}
 * @export
 */
API.Client.ProductToCategory.prototype.category;

