goog.provide('API.Client.MemberGroup');

/**
 * @record
 */
API.Client.MemberGroup = function() {}

/**
 * Üye Grubu nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.MemberGroup.prototype.id;

/**
 * Üye Grubu nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.MemberGroup.prototype.name;

/**
 * Üye Grubunun fiyat indisi. Örnek Fiyat 2.
 * @type {!number}
 * @export
 */
API.Client.MemberGroup.prototype.priceIndex;

/**
 * Üye Grubunun izin verilmiş ödeme kanalları.
 * @type {!string}
 * @export
 */
API.Client.MemberGroup.prototype.allowedPaymentGateways;

