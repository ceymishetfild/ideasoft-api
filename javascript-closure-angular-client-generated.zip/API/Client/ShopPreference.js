goog.provide('API.Client.ShopPreference');

/**
 * @record
 */
API.Client.ShopPreference = function() {}

/**
 * Tanımlama nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ShopPreference.prototype.id;

/**
 * Tanımlama nesnesi için değişken anahtarı.
 * @type {!string}
 * @export
 */
API.Client.ShopPreference.prototype.varKey;

/**
 * Tanımlama nesnesi için değişken değeri.
 * @type {!string}
 * @export
 */
API.Client.ShopPreference.prototype.varValue;

