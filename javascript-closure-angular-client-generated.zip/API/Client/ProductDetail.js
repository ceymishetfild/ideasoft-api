goog.provide('API.Client.ProductDetail');

/**
 * @record
 */
API.Client.ProductDetail = function() {}

/**
 * Ürün detayı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ProductDetail.prototype.id;

/**
 * Ürünün stok kodu.
 * @type {!string}
 * @export
 */
API.Client.ProductDetail.prototype.sku;

/**
 * Detay bilgisi.
 * @type {!string}
 * @export
 */
API.Client.ProductDetail.prototype.details;

/**
 * Ürün ekstra detaylı bilgi.
 * @type {!string}
 * @export
 */
API.Client.ProductDetail.prototype.extraDetails;

/**
 * Ürün nesnesi.
 * @type {!API.Client.Product}
 * @export
 */
API.Client.ProductDetail.prototype.product;

