goog.provide('API.Client.Error');

/**
 * @record
 */
API.Client.Error = function() {}

/**
 * HTTP Hata kodu.
 * @type {!number}
 * @export
 */
API.Client.Error.prototype.code;

/**
 * Hata mesajı. Hata mesajları İngilizce dilindedir.
 * @type {!string}
 * @export
 */
API.Client.Error.prototype.errorMessage;

/**
 * Hata kodu. Eğer ek bir hata kodu varsa bu alanda belirtilir.
 * @type {!number}
 * @export
 */
API.Client.Error.prototype.errorCode;

