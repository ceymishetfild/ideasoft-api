goog.provide('API.Client.ExtraInfoToProduct');

/**
 * @record
 */
API.Client.ExtraInfoToProduct = function() {}

/**
 * Ek bilgi ürün bağı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ExtraInfoToProduct.prototype.id;

/**
 * Ek bilgi ürün bağı değeridir. Ek bilgi renk ise bu değer kırmızı olabilir.
 * @type {!string}
 * @export
 */
API.Client.ExtraInfoToProduct.prototype.value;

/**
 * Ek bilgi nesnesi.
 * @type {!API.Client.ExtraInfo}
 * @export
 */
API.Client.ExtraInfoToProduct.prototype.extraInfo;

/**
 * Ürün nesnesi.
 * @type {!API.Client.Product}
 * @export
 */
API.Client.ExtraInfoToProduct.prototype.product;

