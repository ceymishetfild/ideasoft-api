goog.provide('API.Client.CartItemAttribute');

/**
 * @record
 */
API.Client.CartItemAttribute = function() {}

/**
 * Sepet kalemi özelliği nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.CartItemAttribute.prototype.id;

/**
 * Sepet kalemi özelliği nesnesinin isim değeri. Örneğin, sepet kalemi kalem ise bu değer renk olabilir.
 * @type {!string}
 * @export
 */
API.Client.CartItemAttribute.prototype.name;

/**
 * Sepet kalemi özelliği nesnesinin değeri. Örneğin, sepet kalemi kalem, isim değeri renk ise bu değer kırmızı olabilir.
 * @type {!string}
 * @export
 */
API.Client.CartItemAttribute.prototype.value;

/**
 * Sepet kalemi özelliği nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.CartItemAttribute.prototype.createdAt;

/**
 * @type {!API.Client.CartItem}
 * @export
 */
API.Client.CartItemAttribute.prototype.cartItem;

