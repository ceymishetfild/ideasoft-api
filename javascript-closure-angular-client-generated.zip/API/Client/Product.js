goog.provide('API.Client.Product');

/**
 * @record
 */
API.Client.Product = function() {}

/**
 * Ürün nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.id;

/**
 * Ürünün adı
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.name;

/**
 * Slug değeri ilgili nesnenin Url değeridir.
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.slug;

/**
 * Ürünün tam adı. Bu değer bir varyant için ana ürünün adı ve varyant adının birleşiminden oluşur. Örneğin Kırmızı varyantı için Kalem Kırmızı olur.
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.fullName;

/**
 * Ürünün stok kodu. ID değeri gibi eşsiz bir kimlik değeridir.
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.sku;

/**
 * Ürünün barkodu.
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.barcode;

/**
 * Ürünün Fiyat 1 bilgisi.
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.price1;

/**
 * Ürünün garanti süresi.
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.warranty;

/**
 * Ürünün KDV oranı.
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.tax;

/**
 * Ürünün stok tipi cinsinden miktarı.
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.stockAmount;

/**
 * Ürünün desisi.
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.volumetricWeight;

/**
 * Ürünün alış fiyatı.
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.buyingPrice;

/**
 * Ürünün stok tipi.<div class='idea_choice_list'><code>Piece</code> : Stok tipi birimi Adet<br><code>cm</code> : Stok tipi birimi Santimetre<br><code>Dozen</code> : Stok tipi birimi Düzine<br><code>gram</code> : Stok tipi birimi Gram<br><code>kg</code> : Stok tipi birimi Kilogram<br><code>Person</code> : Stok tipi birimi Kişi<br><code>Package</code> : Stok tipi birimi Paket<br><code>metre</code> : Stok tipi birimi Metre<br><code>m2</code> : Stok tipi birimi Metrekare<br><code>pair</code> : Stok tipi birimi Çift<br></div>
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.stockTypeLabel;

/**
 * Ürünün indirim değeri. Örneğin; discountType 1 olursa %5, 0 olursa 5 tl anlamına gelir.
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.discount;

/**
 * Ürünün indirim tipini belirtir.<div class='idea_choice_list'><code>1</code> : İndirim yüzdesi<br><code>0</code> : İndirimli fiyat<br></div>
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.discountType;

/**
 * Havale indirimi yüzdesi.
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.moneyOrderDiscount;

/**
 * Ürün nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif<br><code>0</code> : Pasif<br></div>
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.status;

/**
 * Ürün fiyatlarına KDV dahil olup olmadığın belirten değer.<div class='idea_choice_list'><code>1</code> : KDV Dahil<br><code>0</code> : KDV Hariç<br></div>
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.taxIncluded;

/**
 * Ürünün distribütör bilgisi
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.distributor;

/**
 * Ürünün hediyeli olup olmadığını belirtir.<div class='idea_choice_list'><code>1</code> : Hediyeli<br><code>0</code> : Hediyeli Değil<br></div>
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.isGifted;

/**
 * Ürünün yanında hediye olarak vermek istediğiniz hediyeyi bu alanda metin ya da rakamla belirtebilirsiniz.
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.gift;

/**
 * Kargo ücreti için sistemin kullanılıp kullanılmama değerini belirtir.<div class='idea_choice_list'><code>1</code> : Sistem seçeneği seçili<br><code>0</code> : Sistem seçeneği seçili değil<br></div>
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.customShippingDisabled;

/**
 * Sistem seçeneği seçilmemişse ürün için girilmesi gereken kargo ücreti.
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.customShippingCost;

/**
 * Ürünün piyasa fiyatı
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.marketPriceDetail;

/**
 * Ürün nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Product.prototype.createdAt;

/**
 * Ürün nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Product.prototype.updatedAt;

/**
 * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.metaKeywords;

/**
 * Arama motorları tarafından tespit edilebilecek açıklama yazısı.
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.metaDescription;

/**
 * Ürün nesnesinin etiket başlığı.
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.pageTitle;

/**
 * Ürünün varyantının olup olmadığı değerini belirtir. (API otomatik olarak bu değeri atar.)<div class='idea_choice_list'><code>1</code> : Varyantı var<br><code>0</code> : Varyantı yok<br></div>
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.hasOption;

/**
 * Ürünün kısa açıklaması.
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.shortDetails;

/**
 * Ziyaretçilerinizin site içindeki ürünlerinizin hangi anahtar kelimelerine göre bulacağını belirler.Kelimeler arasında virgül bırakılarak girilmelidir.(etiket1,etiket2)
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.searchKeywords;

/**
 * Ürüne özel yasal veya isteğe bağlı belirleyebiliceğiniz taksit adedini belirtir. Ürüne özel bir belirleme yapmak istemiyorsanız '-' işareti kullanabilirsiniz.
 * @type {!string}
 * @export
 */
API.Client.Product.prototype.installmentThreshold;

/**
 * Anasayfa vitrini sırası.
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.homeSortOrder;

/**
 * Popüler ürünler vitrini sırası.
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.popularSortOrder;

/**
 * Marka vitrini sırası.
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.brandSortOrder;

/**
 * Sponsor ürünler vitrini sırası
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.featuredSortOrder;

/**
 * Kampanyalı ürünler vitrini sırası.
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.campaignedSortOrder;

/**
 * Yeni ürünler vitrini sırası.
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.newSortOrder;

/**
 * İndirimli ürünler vitrini sırası
 * @type {!number}
 * @export
 */
API.Client.Product.prototype.discountedSortOrder;

/**
 * Marka nesnesi.
 * @type {!API.Client.Brand}
 * @export
 */
API.Client.Product.prototype.brand;

/**
 * Kur nesnesi.
 * @type {!API.Client.Currency}
 * @export
 */
API.Client.Product.prototype.currency;

/**
 * Ana ürün olan ürün nesnesi.
 * @type {!API.Client.Product}
 * @export
 */
API.Client.Product.prototype.parent;

/**
 * Ürün geri sayım bağı nesnesi.
 * @type {!API.Client.ProductToCountDown}
 * @export
 */
API.Client.Product.prototype.countdown;

/**
 * Ürünün fiyatları.
 * @type {!Array<!API.Client.ProductPrice>}
 * @export
 */
API.Client.Product.prototype.prices;

/**
 * Ürünün resimleri.
 * @type {!Array<!API.Client.ProductImage>}
 * @export
 */
API.Client.Product.prototype.images;

/**
 * Ürünün kategorileri.
 * @type {!Array<!API.Client.ProductToCategory>}
 * @export
 */
API.Client.Product.prototype.productToCategories;

/** @enum {string} */
API.Client.Product.StockTypeLabelEnum = { 
  Piece: 'Piece',
  cm: 'cm',
  Dozen: 'Dozen',
  gram: 'gram',
  kg: 'kg',
  Person: 'Person',
  Package: 'Package',
  metre: 'metre',
  m2: 'm2',
  pair: 'pair',
}
/** @enum {string} */
API.Client.Product.DiscountTypeEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.Product.StatusEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.Product.TaxIncludedEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.Product.IsGiftedEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.Product.CustomShippingDisabledEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.Product.HasOptionEnum = { 
  0: '0',
  1: '1',
}
