goog.provide('API.Client.OrderItem');

/**
 * @record
 */
API.Client.OrderItem = function() {}

/**
 * Sipariş kalemi nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.OrderItem.prototype.id;

/**
 * Ürünün adı.
 * @type {!string}
 * @export
 */
API.Client.OrderItem.prototype.productName;

/**
 * Ürünün stok kodu.
 * @type {!string}
 * @export
 */
API.Client.OrderItem.prototype.productSku;

/**
 * Ürünün barkodu.
 * @type {!string}
 * @export
 */
API.Client.OrderItem.prototype.productBarcode;

/**
 * Ürünün fiyatı.
 * @type {!number}
 * @export
 */
API.Client.OrderItem.prototype.productPrice;

/**
 * Ürünün kuru.
 * @type {!string}
 * @export
 */
API.Client.OrderItem.prototype.productCurrency;

/**
 * Ürünün stok tipi cinsinden miktarı.
 * @type {!number}
 * @export
 */
API.Client.OrderItem.prototype.productQuantity;

/**
 * Ürünün vergisi
 * @type {!number}
 * @export
 */
API.Client.OrderItem.prototype.productTax;

/**
 * Ürünün standart indirim değeri.
 * @type {!number}
 * @export
 */
API.Client.OrderItem.prototype.productDiscount;

/**
 * Ürünün havale indirim değeri.
 * @type {!number}
 * @export
 */
API.Client.OrderItem.prototype.productMoneyOrderDiscount;

/**
 * Ürünün ağırlığı.
 * @type {!number}
 * @export
 */
API.Client.OrderItem.prototype.productWeight;

/**
 * Ürünün stok tipi.<div class='idea_choice_list'><code>Adet</code> : Stok tipi birimi Adet<br><code>cm</code> : Stok tipi birimi Santimetre<br><code>Düzine</code> : Stok tipi birimi Düzine<br><code>gram</code> : Stok tipi birimi Gram<br><code>kg</code> : Stok tipi birimi Kilogram<br><code>Kişi</code> : Stok tipi birimi Kişi<br><code>Paket</code> : Stok tipi birimi Paket<br><code>metre</code> : Stok tipi birimi Metre<br><code>m2</code> : Stok tipi birimi Metre kare<br><code>Çift</code> : Stok tipi birimi Çift<br></div>
 * @type {!string}
 * @export
 */
API.Client.OrderItem.prototype.productStockTypeLabel;

/**
 * Ürünün promosyon olup olmadığını belirten değer.<div class='idea_choice_list'><code>0</code> : Ürün promosyon değil.<br><code>1</code> : Ürün promosyon.<br></div>
 * @type {!string}
 * @export
 */
API.Client.OrderItem.prototype.isProductPromotioned;

/**
 * Ürünün hediye çeki indirim değeri.
 * @type {!number}
 * @export
 */
API.Client.OrderItem.prototype.discount;

/**
 * @type {!API.Client.Order}
 * @export
 */
API.Client.OrderItem.prototype.order;

/**
 * @type {!API.Client.Product}
 * @export
 */
API.Client.OrderItem.prototype.product;

/**
 * @type {!API.Client.OrderItemSubscription}
 * @export
 */
API.Client.OrderItem.prototype.orderItemSubscription;

/** @enum {string} */
API.Client.OrderItem.IsProductPromotionedEnum = { 
  0: '0',
  1: '1',
}
