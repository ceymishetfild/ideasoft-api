goog.provide('API.Client.Tag');

/**
 * @record
 */
API.Client.Tag = function() {}

/**
 * SEO+ etiketi nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Tag.prototype.id;

/**
 * SEO+ etiketi nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.Tag.prototype.name;

/**
 * SEO+ etiketinin kaç kez kullanıldığı bilgisi.
 * @type {!number}
 * @export
 */
API.Client.Tag.prototype.count;

/**
 * SEO+ etiketi nesnesinin etiket başlığı.
 * @type {!string}
 * @export
 */
API.Client.Tag.prototype.pageTitle;

/**
 * Arama motorları tarafından tespit edilebilecek açıklama yazısı.
 * @type {!string}
 * @export
 */
API.Client.Tag.prototype.metaDescription;

/**
 * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.
 * @type {!string}
 * @export
 */
API.Client.Tag.prototype.metaKeywords;

