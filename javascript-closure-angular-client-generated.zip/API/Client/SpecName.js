goog.provide('API.Client.SpecName');

/**
 * @record
 */
API.Client.SpecName = function() {}

/**
 * Ürün özelliği nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.SpecName.prototype.id;

/**
 * Ürün özelliği nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.SpecName.prototype.name;

/**
 * Özellik tipini belirtir.<div class='idea_choice_list'><code>singular</code> : Tekil<br><code>plural</code> : Çoğul<br></div>
 * @type {!string}
 * @export
 */
API.Client.SpecName.prototype.choiceType;

/**
 * Ürün özelliği sıralama değeri.
 * @type {!number}
 * @export
 */
API.Client.SpecName.prototype.sortOrder;

/**
 * Ürün özelliği aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.SpecName.prototype.status;

/**
 * specGroup
 * @type {!API.Client.SpecGroup}
 * @export
 */
API.Client.SpecName.prototype.specGroup;

/** @enum {string} */
API.Client.SpecName.ChoiceTypeEnum = { 
  singular: 'singular',
  plural: 'plural',
}
/** @enum {string} */
API.Client.SpecName.StatusEnum = { 
  0: '0',
  1: '1',
}
