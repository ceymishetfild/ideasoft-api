goog.provide('API.Client.ShippingAddress');

/**
 * @record
 */
API.Client.ShippingAddress = function() {}

/**
 * Sipariş adresi nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ShippingAddress.prototype.id;

/**
 * Müşterinin ismi.
 * @type {!string}
 * @export
 */
API.Client.ShippingAddress.prototype.firstname;

/**
 * Müşterinin soy ismi.
 * @type {!string}
 * @export
 */
API.Client.ShippingAddress.prototype.surname;

/**
 * Müşterinin ülke bilgisi.
 * @type {!string}
 * @export
 */
API.Client.ShippingAddress.prototype.country;

/**
 * Müşterinin şehir bilgisi.
 * @type {!string}
 * @export
 */
API.Client.ShippingAddress.prototype.location;

/**
 * Müşterinin ilçe bilgisi.
 * @type {!string}
 * @export
 */
API.Client.ShippingAddress.prototype.subLocation;

/**
 * Müşterinin adres bilgisi.
 * @type {!string}
 * @export
 */
API.Client.ShippingAddress.prototype.address;

/**
 * Müşterinin telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.ShippingAddress.prototype.phoneNumber;

/**
 * Müşterinin mobil telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.ShippingAddress.prototype.mobilePhoneNumber;

/**
 * Sipariş nesnesi.
 * @type {!API.Client.Order}
 * @export
 */
API.Client.ShippingAddress.prototype.order;

