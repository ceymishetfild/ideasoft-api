goog.provide('API.Client.ShipmentItem');

/**
 * @record
 */
API.Client.ShipmentItem = function() {}

/**
 * Teslimat Kalemi nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ShipmentItem.prototype.id;

/**
 * Ana ürünün id değeri.
 * @type {!number}
 * @export
 */
API.Client.ShipmentItem.prototype.rootProductId;

/**
 * Ürünün stok tipi cinsinden miktarı.
 * @type {!number}
 * @export
 */
API.Client.ShipmentItem.prototype.amount;

/**
 * Ürünün fiyatı.
 * @type {!number}
 * @export
 */
API.Client.ShipmentItem.prototype.price;

/**
 * Ürün başlığı.
 * @type {!string}
 * @export
 */
API.Client.ShipmentItem.prototype.productLabel;

/**
 * Ürünün kur bilgisi.<div class='idea_choice_list'><code>USD</code> : Amerikan Doları<br><code>EUR</code> : Euro<br><code>TL</code> : Türk Lirası<br><code>GBP</code> : İngiliz Sterlini<br><code>JPY</code> : Japon Yeni<br><code>CNY</code> : Çin Yuanı<br><code>GR</code> : Gram Altın<br><code>CHF</code> : İsviçre Frangı<br></div>
 * @type {!string}
 * @export
 */
API.Client.ShipmentItem.prototype.currency;

/**
 * Ürünün vergi değeri.
 * @type {!number}
 * @export
 */
API.Client.ShipmentItem.prototype.tax;

/**
 * Ürünün desi bilgisi.
 * @type {!number}
 * @export
 */
API.Client.ShipmentItem.prototype.dm3;

/**
 * Teslimat Kalemi nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.ShipmentItem.prototype.createdAt;

/**
 * Teslimat Kalemi nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
 * @type {!number}
 * @export
 */
API.Client.ShipmentItem.prototype.status;

/**
 * Teslimat Kalemi nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.ShipmentItem.prototype.updatedAt;

/**
 * Sipariş kalemi nesnesi.
 * @type {!API.Client.OrderItem}
 * @export
 */
API.Client.ShipmentItem.prototype.orderItem;

/**
 * Ürün nesnesi.
 * @type {!API.Client.Product}
 * @export
 */
API.Client.ShipmentItem.prototype.product;

/**
 * Teslimat nesnesi.
 * @type {!API.Client.Shipment}
 * @export
 */
API.Client.ShipmentItem.prototype.shipment;

/** @enum {string} */
API.Client.ShipmentItem.CurrencyEnum = { 
  USD: 'USD',
  EUR: 'EUR',
  TL: 'TL',
  GBP: 'GBP',
  JPY: 'JPY',
  CNY: 'CNY',
  GR: 'GR',
  CHF: 'CHF',
}
/** @enum {string} */
API.Client.ShipmentItem.StatusEnum = { 
  0: '0',
  1: '1',
}
