goog.provide('API.Client.Category');

/**
 * @record
 */
API.Client.Category = function() {}

/**
 * Kategori nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Category.prototype.id;

/**
 * Kategori nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.name;

/**
 * Slug değeri ilgili nesnenin Url değeridir.
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.slug;

/**
 * Kategori nesnesi için sıralama değeri.
 * @type {!number}
 * @export
 */
API.Client.Category.prototype.sortOrder;

/**
 * Kategori nesnesinin aktiflik durumunu belirten değer.
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.status;

/**
 * Kategori nesnesinin fiyat katsayısı.
 * @type {!number}
 * @export
 */
API.Client.Category.prototype.percent;

/**
 * Kategori nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.imageFile;

/**
 * Her zaman null değer alır. Pratikte kullanımı yoktur.
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.distributor;

/**
 * Kategori nesnesinin üst içerik metninin gösterim durumu.
 * @type {!number}
 * @export
 */
API.Client.Category.prototype.displayShowcaseContent;

/**
 * Kategori nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir.
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.showcaseContent;

/**
 * Kategori nesnesinin üst içerik metninin gösterim tipi.<div class='idea_choice_list'><code>1</code> : Kategori içeriği.<br><code>2</code> : Kategori ve üst kategori içeriği.<br><code>3</code> : Kategori ve tüm üst kategoriler.<br></div>
 * @type {!number}
 * @export
 */
API.Client.Category.prototype.showcaseContentDisplayType;

/**
 * Kategori nesnesinin alt kategori barındırma durumu. Bu değer otomatik oluşturulur.
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.hasChildren;

/**
 * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.metaKeywords;

/**
 * Arama motorları tarafından tespit edilebilecek açıklama yazısı.
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.metaDescription;

/**
 * Kategori nesnesinin etiket başlığı.
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.pageTitle;

/**
 * @type {!API.Client.Category}
 * @export
 */
API.Client.Category.prototype.parent;

/**
 * Kategori nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.attachment;

/**
 * Kategori nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Category.prototype.createdAt;

/**
 * Kategori nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Category.prototype.updatedAt;

/** @enum {string} */
API.Client.Category.StatusEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.Category.HasChildrenEnum = { 
  0: '0',
  1: '1',
}
