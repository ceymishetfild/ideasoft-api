goog.provide('API.Client.SpecToProduct');

/**
 * @record
 */
API.Client.SpecToProduct = function() {}

/**
 * Ürün özellik ürün bağı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.SpecToProduct.prototype.id;

/**
 * @type {!API.Client.Product}
 * @export
 */
API.Client.SpecToProduct.prototype.product;

/**
 * @type {!API.Client.SpecGroup}
 * @export
 */
API.Client.SpecToProduct.prototype.specGroup;

/**
 * @type {!API.Client.SpecName}
 * @export
 */
API.Client.SpecToProduct.prototype.specName;

/**
 * @type {!API.Client.SpecValue}
 * @export
 */
API.Client.SpecToProduct.prototype.specValue;

