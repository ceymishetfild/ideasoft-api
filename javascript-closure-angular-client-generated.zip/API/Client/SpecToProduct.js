goog.provide('API.Client.SpecToProduct');

/**
 * @record
 */
API.Client.SpecToProduct = function() {}

/**
 * Ürün özellik ürün bağı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.SpecToProduct.prototype.id;

/**
 * Ürün nesnesi.
 * @type {!API.Client.Product}
 * @export
 */
API.Client.SpecToProduct.prototype.product;

/**
 * Ürün özelliği grubu nesnesi.
 * @type {!API.Client.SpecGroup}
 * @export
 */
API.Client.SpecToProduct.prototype.specGroup;

/**
 * Ürün özelliği nesnesi.
 * @type {!API.Client.SpecName}
 * @export
 */
API.Client.SpecToProduct.prototype.specName;

/**
 * Ürün özellik grubu nesnesi.
 * @type {!API.Client.SpecValue}
 * @export
 */
API.Client.SpecToProduct.prototype.specValue;

