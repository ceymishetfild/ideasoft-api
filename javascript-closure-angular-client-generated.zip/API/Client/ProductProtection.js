goog.provide('API.Client.ProductProtection');

/**
 * @record
 */
API.Client.ProductProtection = function() {}

/**
 * Entegrasyon seçeneği nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ProductProtection.prototype.id;

/**
 * Ürün fiyatının korumalı olup olmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Korumalı.<br><code>0</code> : Korumasız.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ProductProtection.prototype.isPriceProtected;

/**
 * Ürün stoğunun korumalı olup olmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Korumalı.<br><code>0</code> : Korumasız.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ProductProtection.prototype.isStockProtected;

/**
 * @type {!API.Client.Product}
 * @export
 */
API.Client.ProductProtection.prototype.product;

/** @enum {string} */
API.Client.ProductProtection.IsPriceProtectedEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.ProductProtection.IsStockProtectedEnum = { 
  0: '0',
  1: '1',
}
