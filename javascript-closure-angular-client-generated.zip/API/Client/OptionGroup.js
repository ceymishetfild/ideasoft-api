goog.provide('API.Client.OptionGroup');

/**
 * @record
 */
API.Client.OptionGroup = function() {}

/**
 * Varyant grubu nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.OptionGroup.prototype.id;

/**
 * Varyant grubunun başlığı. Varyant değeri kırmızı ise bu değer renk olabilir.
 * @type {!string}
 * @export
 */
API.Client.OptionGroup.prototype.title;

/**
 * Varyant grubunun sıralama değeri.
 * @type {!number}
 * @export
 */
API.Client.OptionGroup.prototype.sortOrder;

/**
 * Varyant grubunun filtre menüsündeki gösterim durumu.<div class='idea_choice_list'><code>1</code> : Gösterilsin.<br><code>0</code> : Gösterilmesin.<br></div>
 * @type {!string}
 * @export
 */
API.Client.OptionGroup.prototype.filterStatus;

/** @enum {string} */
API.Client.OptionGroup.FilterStatusEnum = { 
  0: '0',
  1: '1',
}
