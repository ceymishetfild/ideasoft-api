goog.provide('API.Client.ProductImage');

/**
 * @record
 */
API.Client.ProductImage = function() {}

/**
 * Ürün resmi nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ProductImage.prototype.id;

/**
 * Ürün resminin dosya adı. Uzantı olmadan yazılmalıdır.
 * @type {!string}
 * @export
 */
API.Client.ProductImage.prototype.filename;

/**
 * Resim için geçerli dosya uzantıları.<div class='idea_choice_list'><code>jpg</code> : jpg dosyaları için geçerli uzantı.<br><code>png</code> : png dosyaları için geçerli uzantı.<br><code>gif</code> : gif dosyaları için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyaları için geçerli uzantı.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ProductImage.prototype.extension;

/**
 * Dosya konumu adı. API otomatik oluşturur.
 * @type {!string}
 * @export
 */
API.Client.ProductImage.prototype.directoryName;

/**
 * Revision değeri aynı isimle eklediğiniz resimlerin ön bellekten yüklenmesini engellemek için gerekli bir değerdir. Aynı isimle tekrardan resim yüklenirken bir önceki resimden farklı bir değer almalıdır.
 * @type {!string}
 * @export
 */
API.Client.ProductImage.prototype.revision;

/**
 * Resmin sıralama değeri. Ürün içerisindeki 8 fotoğraf içinden hangisi olacağını belirler.
 * @type {!number}
 * @export
 */
API.Client.ProductImage.prototype.sortOrder;

/**
 * @type {!API.Client.Product}
 * @export
 */
API.Client.ProductImage.prototype.product;

/**
 * Ürün resminin base64 formatına çevrilmiş resim kodu. Oluşturma(POST) isteği esnasında başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
 * @type {!string}
 * @export
 */
API.Client.ProductImage.prototype.attachment;

/** @enum {string} */
API.Client.ProductImage.ExtensionEnum = { 
  jpg: 'jpg',
  png: 'png',
  gif: 'gif',
  jpeg: 'jpeg',
}
