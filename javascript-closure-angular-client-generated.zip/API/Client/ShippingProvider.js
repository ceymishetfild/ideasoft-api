goog.provide('API.Client.ShippingProvider');

/**
 * @record
 */
API.Client.ShippingProvider = function() {}

/**
 * Teslimat hizmeti sağlayıcısı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ShippingProvider.prototype.id;

/**
 * Teslimat hizmeti sağlayıcısı kodu. Benzersiz olmalıdır.
 * @type {!string}
 * @export
 */
API.Client.ShippingProvider.prototype.code;

/**
 * Teslimat hizmeti sağlayıcısı nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.ShippingProvider.prototype.name;

/**
 * Kargo takip url.
 * @type {!string}
 * @export
 */
API.Client.ShippingProvider.prototype.trackingUrl;

/**
 * Kargo takip formu almak için kullanılacak method.<div class='idea_choice_list'><code>get</code> : GET methodu.<br><code>post</code> : POST methodu.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ShippingProvider.prototype.trackingFormMethod;

/**
 * İlgili kargo takip formu almak için kullanılacak yük.
 * @type {!string}
 * @export
 */
API.Client.ShippingProvider.prototype.payload;

/**
 * Teslimat hizmeti sağlayıcısı için ayarlar.
 * @type {!Array<!API.Client.ShippingProviderSetting>}
 * @export
 */
API.Client.ShippingProvider.prototype.settings;

/** @enum {string} */
API.Client.ShippingProvider.TrackingFormMethodEnum = { 
  get: 'get',
  post: 'post',
}
