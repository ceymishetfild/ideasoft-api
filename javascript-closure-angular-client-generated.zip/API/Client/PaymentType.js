goog.provide('API.Client.PaymentType');

/**
 * @record
 */
API.Client.PaymentType = function() {}

/**
 * Ödeme tipi nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.PaymentType.prototype.id;

/**
 * Ödeme tipi nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.PaymentType.prototype.name;

