goog.provide('API.Client.ShippingRate');

/**
 * @record
 */
API.Client.ShippingRate = function() {}

/**
 * Kargo oranı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ShippingRate.prototype.id;

/**
 * İlgili kargo firması, ilgili bölge ve ilgili orana ait minimum desi değeri.
 * @type {!number}
 * @export
 */
API.Client.ShippingRate.prototype.volumetricWeightStart;

/**
 * İlgili kargo firması, ilgili bölge ve ilgili orana ait maximum desi değeri.
 * @type {!number}
 * @export
 */
API.Client.ShippingRate.prototype.volumetricWeightEnd;

/**
 * Seçili bölge ve kargo firması için kargo oranı.
 * @type {!number}
 * @export
 */
API.Client.ShippingRate.prototype.rate;

/**
 * Bölge nesnesi.
 * @type {!API.Client.Region}
 * @export
 */
API.Client.ShippingRate.prototype.region;

/**
 * Kargo firması nesnesi.
 * @type {!API.Client.ShippingCompany}
 * @export
 */
API.Client.ShippingRate.prototype.shippingCompany;

