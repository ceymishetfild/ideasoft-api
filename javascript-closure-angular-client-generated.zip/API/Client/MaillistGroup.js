goog.provide('API.Client.MaillistGroup');

/**
 * @record
 */
API.Client.MaillistGroup = function() {}

/**
 * Mail listesi grubu nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.MaillistGroup.prototype.id;

/**
 * Mail listesi grubu nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.MaillistGroup.prototype.name;

