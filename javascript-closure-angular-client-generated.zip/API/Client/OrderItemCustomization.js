goog.provide('API.Client.OrderItemCustomization');

/**
 * @record
 */
API.Client.OrderItemCustomization = function() {}

/**
 * Sipariş kalemi özelleştirme kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.OrderItemCustomization.prototype.id;

/**
 * Ürün özelleştirme grubu nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.OrderItemCustomization.prototype.productCustomizationGroupId;

/**
 * Ürün özelleştirme grubu nesnesinin grup adı.
 * @type {!string}
 * @export
 */
API.Client.OrderItemCustomization.prototype.productCustomizationGroupName;

/**
 * Ürün özelleştirme grubu nesnesinin sıralaması.
 * @type {!number}
 * @export
 */
API.Client.OrderItemCustomization.prototype.productCustomizationGroupSortOrder;

/**
 * Ürün özelleştirme nesnesi kimlik değeri..
 * @type {!number}
 * @export
 */
API.Client.OrderItemCustomization.prototype.productCustomizationFieldId;

/**
 * Ürün özelleştirme nesnesinin alan tipi.
 * @type {!string}
 * @export
 */
API.Client.OrderItemCustomization.prototype.productCustomizationFieldType;

/**
 * Ürün özelleştirme nesnesinin alan adı.
 * @type {!string}
 * @export
 */
API.Client.OrderItemCustomization.prototype.productCustomizationFieldName;

/**
 * Ürün özelleştirme nesnesinin değeri.
 * @type {!string}
 * @export
 */
API.Client.OrderItemCustomization.prototype.productCustomizationFieldValue;

/**
 * Sepet kalemi özelliği nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.OrderItemCustomization.prototype.cartItemAttributeId;

