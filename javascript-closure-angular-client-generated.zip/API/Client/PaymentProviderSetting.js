goog.provide('API.Client.PaymentProviderSetting');

/**
 * @record
 */
API.Client.PaymentProviderSetting = function() {}

/**
 * Ödeme altyapısı sağlayıcısı ayarı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.PaymentProviderSetting.prototype.id;

/**
 * Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken anahtarı.
 * @type {!string}
 * @export
 */
API.Client.PaymentProviderSetting.prototype.varKey;

/**
 * Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken değeri.
 * @type {!string}
 * @export
 */
API.Client.PaymentProviderSetting.prototype.varValue;

