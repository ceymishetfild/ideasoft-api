goog.provide('API.Client.PreOrderInfo');

/**
 * @record
 */
API.Client.PreOrderInfo = function() {}

/**
 * Sipariş öncesi bilgisi nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.PreOrderInfo.prototype.id;

/**
 * Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.sessionId;

/**
 * Müşterinin ismi.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.customerFirstname;

/**
 * Müşterinin soy ismi.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.customerSurname;

/**
 * Müşterinin e-mail adresi.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.customerEmail;

/**
 * Teslimat yapılacak kişinin ismi.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.shippingFirstname;

/**
 * Teslimat yapılacak kişinin soy ismi.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.shippingSurname;

/**
 * Teslimat adresi bilgileri.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.shippingAddress;

/**
 * Teslimat yapılacak kişinin telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.shippingPhoneNumber;

/**
 * Teslimat yapılacak kişinin mobil telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.shippingMobilePhoneNumber;

/**
 * Teslimat şehri.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.shippingLocationName;

/**
 * Teslimat ilçesi.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.shippingTown;

/**
 * Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.<div class='idea_choice_list'><code>1</code> : Var<br><code>0</code> : Yok<br></div>
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.differentBillingAddress;

/**
 * Fatura kesilen kişinin ismi.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.billingFirstname;

/**
 * Fatura kesilen kişinin soy ismi.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.billingSurname;

/**
 * Fatura adresi bilgileri.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.billingAddress;

/**
 * Fatura kesilen kişinin telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.billingPhoneNumber;

/**
 * Fatura kesilen kişinin mobil telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.billingMobilePhoneNumber;

/**
 * Fatura adresi şehri
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.billingLocationName;

/**
 * Fatura adresi ilçesi.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.billingTown;

/**
 * Fatura tipini belirtir.<div class='idea_choice_list'><code>individual</code> : Bireysel<br><code>corporate</code> : Kurumsal<br></div>
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.billingInvoiceType;

/**
 * Fatura kesilen kişinin TC kimlik numarası.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.billingIdentityRegistrationNumber;

/**
 * Fatura kesilen kişi/kurumun vergi dairesi.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.billingTaxOffice;

/**
 * Fatura kesilen kişi/kurum vergi numarası.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.billingTaxNo;

/**
 * Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div>
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.isEinvoiceUser;

/**
 * Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div>
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.useGiftPackage;

/**
 * Hediye notu bilgisi.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.giftNote;

/**
 * Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.imageFile;

/**
 * Müşterinin teslimatın gerçekleşmisini istediği tarih.
 * @type {!API.Client.date}
 * @export
 */
API.Client.PreOrderInfo.prototype.deliveryDate;

/**
 * API bu değeri otomatik oluşturur.
 * @type {!string}
 * @export
 */
API.Client.PreOrderInfo.prototype.deliveryTime;

/**
 * Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.PreOrderInfo.prototype.createdAt;

/**
 * Sipariş öncesi bilgisi nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.PreOrderInfo.prototype.updatedAt;

/**
 * @type {!API.Client.Country}
 * @export
 */
API.Client.PreOrderInfo.prototype.billingCountry;

/**
 * @type {!API.Client.Location}
 * @export
 */
API.Client.PreOrderInfo.prototype.billingLocation;

/**
 * @type {!API.Client.ShippingCompany}
 * @export
 */
API.Client.PreOrderInfo.prototype.shippingCompany;

/**
 * @type {!API.Client.Country}
 * @export
 */
API.Client.PreOrderInfo.prototype.shippingCountry;

/**
 * @type {!API.Client.Location}
 * @export
 */
API.Client.PreOrderInfo.prototype.shippingLocation;

/**
 * @type {!API.Client.MemberAddress}
 * @export
 */
API.Client.PreOrderInfo.prototype.memberShippingAddress;

/**
 * @type {!API.Client.MemberAddress}
 * @export
 */
API.Client.PreOrderInfo.prototype.memberBillingAddress;

/** @enum {string} */
API.Client.PreOrderInfo.DifferentBillingAddressEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.PreOrderInfo.BillingInvoiceTypeEnum = { 
  individual: 'individual',
  corporate: 'corporate',
}
/** @enum {string} */
API.Client.PreOrderInfo.IsEinvoiceUserEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.PreOrderInfo.UseGiftPackageEnum = { 
  0: '0',
  1: '1',
}
