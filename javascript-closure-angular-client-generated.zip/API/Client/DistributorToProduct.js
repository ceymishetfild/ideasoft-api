goog.provide('API.Client.DistributorToProduct');

/**
 * @record
 */
API.Client.DistributorToProduct = function() {}

/**
 * Distribütor ürün bağı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.DistributorToProduct.prototype.id;

/**
 * The description of the Distributor.
 * @type {!API.Client.Distributor}
 * @export
 */
API.Client.DistributorToProduct.prototype.distributor;

/**
 * The description of the Product.
 * @type {!API.Client.Product}
 * @export
 */
API.Client.DistributorToProduct.prototype.product;

