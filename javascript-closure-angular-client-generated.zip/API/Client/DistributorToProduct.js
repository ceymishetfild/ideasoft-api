goog.provide('API.Client.DistributorToProduct');

/**
 * @record
 */
API.Client.DistributorToProduct = function() {}

/**
 * Distribütor ürün bağı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.DistributorToProduct.prototype.id;

/**
 * @type {!API.Client.Distributor}
 * @export
 */
API.Client.DistributorToProduct.prototype.distributor;

/**
 * @type {!API.Client.Product}
 * @export
 */
API.Client.DistributorToProduct.prototype.product;

