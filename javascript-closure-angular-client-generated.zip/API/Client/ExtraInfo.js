goog.provide('API.Client.ExtraInfo');

/**
 * @record
 */
API.Client.ExtraInfo = function() {}

/**
 * Ek bilgi nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ExtraInfo.prototype.id;

/**
 * Ek bilgi nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.ExtraInfo.prototype.name;

/**
 * Ek bilgi nesnesi için sıralama değeri.
 * @type {!number}
 * @export
 */
API.Client.ExtraInfo.prototype.sortOrder;

