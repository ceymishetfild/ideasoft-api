goog.provide('API.Client.FavouritedProduct');

/**
 * @record
 */
API.Client.FavouritedProduct = function() {}

/**
 * Favori ürün nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.FavouritedProduct.prototype.id;

/**
 * Üye nesnesi.
 * @type {!API.Client.Member}
 * @export
 */
API.Client.FavouritedProduct.prototype.member;

/**
 * Ürün nesnesi.
 * @type {!API.Client.Product}
 * @export
 */
API.Client.FavouritedProduct.prototype.product;

