goog.provide('API.Client.Payment');

/**
 * @record
 */
API.Client.Payment = function() {}

/**
 * Ödeme nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Payment.prototype.id;

/**
 * Üyenin ismi.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.memberFirstname;

/**
 * Üyenin soy ismi.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.memberSurname;

/**
 * Üyenin e-mail adresi.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.memberEmail;

/**
 * Üyenin telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.memberPhone;

/**
 * Ödeme tipi
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.paymentTypeName;

/**
 * Ödeme hizmeti sağlayıcısı kodu. Bu değer ön tanımlıdır.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.paymentProviderCode;

/**
 * Ödeme hizmeti sağlayıcısı adı. Bu değer ön tanımlıdır.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.paymentProviderName;

/**
 * Ödeme kanalı adı. Bu değer ön tanımlıdır.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.paymentGatewayName;

/**
 * Ödeme kanalı kodu. Bu değer ön tanımlıdır.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.paymentGatewayCode;

/**
 * Ödeme yapılan banka. Bu değer ön tanımlıdır.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.bankName;

/**
 * Ödemenin gerçekleştiği cihaz bilgisi.<div class='idea_choice_list'><code>desktop</code> : Masaüstü<br><code>mobile</code> : Mobil<br><code>tablet</code> : Tablet<br></div>
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.deviceType;

/**
 * Müşterinin IP adresi.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.clientIp;

/**
 * Kur oranları.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.currencyRates;

/**
 * Ödemenin saf fiyatı.
 * @type {!number}
 * @export
 */
API.Client.Payment.prototype.amount;

/**
 * Ödemenin son fiyatı.
 * @type {!number}
 * @export
 */
API.Client.Payment.prototype.finalAmount;

/**
 * Ödemeden kazanılan toplam puan.
 * @type {!number}
 * @export
 */
API.Client.Payment.prototype.sumOfGainedPoints;

/**
 * Ödemenin standart taksit sayısı.
 * @type {!number}
 * @export
 */
API.Client.Payment.prototype.installment;

/**
 * Ödemenin taksit oranı.
 * @type {!number}
 * @export
 */
API.Client.Payment.prototype.installmentRate;

/**
 * Ödemenin ekstra taksit sayısı.
 * @type {!number}
 * @export
 */
API.Client.Payment.prototype.extraInstallment;

/**
 * Kur bilgisi.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.currency;

/**
 * Siparişin numarası.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.transactionId;

/**
 * Müşterinin ödeme notu.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.memberNote;

/**
 * Yönetici(admin) ödeme notu.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.userNote;

/**
 * Ödeme durumu.<div class='idea_choice_list'><code>deleted</code> : Silindi<br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br><code>failed</code> : Hatalı Ödemeler<br><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br></div>
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.status;

/**
 * Ödemenin hata mesajı.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.errorMessage;

/**
 * Kart saklama sistemi.
 * @type {!string}
 * @export
 */
API.Client.Payment.prototype.cardSavingSystem;

/**
 * Ödeme nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Payment.prototype.createdAt;

/**
 * Üye nesnesi.
 * @type {!API.Client.Member}
 * @export
 */
API.Client.Payment.prototype.member;

/** @enum {string} */
API.Client.Payment.DeviceTypeEnum = { 
  desktop: 'desktop',
  mobile: 'mobile',
  tablet: 'tablet',
}
/** @enum {string} */
API.Client.Payment.StatusEnum = { 
  deleted: 'deleted',
  waiting_for_approval: 'waiting_for_approval',
  approved: 'approved',
  fulfilled: 'fulfilled',
  cancelled: 'cancelled',
  delivered: 'delivered',
  on_accumulation: 'on_accumulation',
  waiting_for_payment: 'waiting_for_payment',
  being_prepared: 'being_prepared',
  refunded: 'refunded',
  personal_status_1: 'personal_status_1',
  personal_status_2: 'personal_status_2',
  personal_status_3: 'personal_status_3',
  failed: 'failed',
  in_transaction: 'in_transaction',
}
