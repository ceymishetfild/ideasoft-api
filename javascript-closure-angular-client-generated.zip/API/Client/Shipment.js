goog.provide('API.Client.Shipment');

/**
 * @record
 */
API.Client.Shipment = function() {}

/**
 * Teslimat nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Shipment.prototype.id;

/**
 * Teslimat barkodu.
 * @type {!string}
 * @export
 */
API.Client.Shipment.prototype.barcode;

/**
 * Teslimat fatura numarası.
 * @type {!string}
 * @export
 */
API.Client.Shipment.prototype.waybillNo;

/**
 * Teslimat irsaliye makbuzu numarası.
 * @type {!string}
 * @export
 */
API.Client.Shipment.prototype.invoiceKey;

/**
 * Teslimatın kargo şubesi
 * @type {!string}
 * @export
 */
API.Client.Shipment.prototype.cargoOffice;

/**
 * Teslimat kodu. Kargo takip kodu.
 * @type {!string}
 * @export
 */
API.Client.Shipment.prototype.code;

/**
 * Teslimat tipi
 * @type {!string}
 * @export
 */
API.Client.Shipment.prototype.deliveryType;

/**
 * Faturanın pakete dahillik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Dahil.<br><code>0</code> : Dahil değil.<br></div>
 * @type {!string}
 * @export
 */
API.Client.Shipment.prototype.invoiceIncluded;

/**
 * Kapıda ödeme hizmeti bedeli.
 * @type {!number}
 * @export
 */
API.Client.Shipment.prototype.payAtDoorAmount;

/**
 * Teslimat nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Shipment.prototype.createdAt;

/**
 * Teslimat nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
 * @type {!number}
 * @export
 */
API.Client.Shipment.prototype.status;

/**
 * Sipariş nesnesi.
 * @type {!API.Client.Order}
 * @export
 */
API.Client.Shipment.prototype.order;

/** @enum {string} */
API.Client.Shipment.InvoiceIncludedEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.Shipment.StatusEnum = { 
  0: '0',
  1: '1',
}
