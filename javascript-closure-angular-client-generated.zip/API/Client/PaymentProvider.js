goog.provide('API.Client.PaymentProvider');

/**
 * @record
 */
API.Client.PaymentProvider = function() {}

/**
 * Ödeme altyapısı sağlayıcısı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.PaymentProvider.prototype.id;

/**
 * Ödeme altyapısı sağlayıcısı için ön tanımlanmış kod değeri.
 * @type {!string}
 * @export
 */
API.Client.PaymentProvider.prototype.code;

/**
 * Ödeme altyapısı sağlayıcısı için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.PaymentProvider.prototype.name;

/**
 * Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer.
 * @type {!string}
 * @export
 */
API.Client.PaymentProvider.prototype.status;

/**
 * @type {!API.Client.PaymentType}
 * @export
 */
API.Client.PaymentProvider.prototype.paymentType;

/**
 * Ödeme altyapısı sağlayıcısı ayarları
 * @type {!Array<!API.Client.PaymentProviderSetting>}
 * @export
 */
API.Client.PaymentProvider.prototype.settings;

/** @enum {string} */
API.Client.PaymentProvider.StatusEnum = { 
  0: '0',
  1: '1',
}
