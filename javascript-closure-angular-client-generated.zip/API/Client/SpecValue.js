goog.provide('API.Client.SpecValue');

/**
 * @record
 */
API.Client.SpecValue = function() {}

/**
 * Ürün özellik değeri nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.SpecValue.prototype.id;

/**
 * Ürün özellik değeri nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.SpecValue.prototype.name;

/**
 * Ürün özellik değeri nesnesi için sıralama değeri.
 * @type {!number}
 * @export
 */
API.Client.SpecValue.prototype.sortOrder;

/**
 * Ürün özellik değeri logo görseli için geçerli dosya uzantıları.<div class='idea_choice_list'><code>jpg</code> : jpg dosyaları için geçerli uzantı.<br><code>png</code> : png dosyaları için geçerli uzantı.<br><code>gif</code> : gif dosyaları için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyaları için geçerli uzantı.<br></div>
 * @type {!string}
 * @export
 */
API.Client.SpecValue.prototype.logo;

/**
 * Ürün özellik değerinin aktiflik bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.SpecValue.prototype.status;

/**
 * Ürün görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
 * @type {!string}
 * @export
 */
API.Client.SpecValue.prototype.attachment;

/**
 * Ürün özelliği grubu nesnesi.
 * @type {!API.Client.SpecGroup}
 * @export
 */
API.Client.SpecValue.prototype.specGroup;

/**
 * Ürün özelliği nesnesi.
 * @type {!API.Client.SpecName}
 * @export
 */
API.Client.SpecValue.prototype.specName;

/** @enum {string} */
API.Client.SpecValue.LogoEnum = { 
  jpg: 'jpg',
  png: 'png',
  gif: 'gif',
  jpeg: 'jpeg',
}
/** @enum {string} */
API.Client.SpecValue.StatusEnum = { 
  0: '0',
  1: '1',
}
