goog.provide('API.Client.ShippingCompany');

/**
 * @record
 */
API.Client.ShippingCompany = function() {}

/**
 * Kargo firması nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ShippingCompany.prototype.id;

/**
 * Kargo firması nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.ShippingCompany.prototype.name;

/**
 * Kargo firması nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>active</code> : Aktif.<br><code>passive</code> : Pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ShippingCompany.prototype.status;

/**
 * Kargo firması için sabit ücret. Sabit bir kargo ücreti uygulayacaksanız her sipariş için sabit kargo ücreti girebilirsiniz. Desi bilgilerini kaydetmeniz durumunda desi toplamlarının üzerine sabit ücret eklenecektir.
 * @type {!number}
 * @export
 */
API.Client.ShippingCompany.prototype.extraPrice;

/**
 * Kargo firması için girmiş olduğunuz desi bilgileri 50 Desiye kadar girilebilmektedir. 50'nin üzeri veya girmiş olduğunuz desi miktarının üzerine her +1 desi için eklenecek olan kargo ücreti.
 * @type {!number}
 * @export
 */
API.Client.ShippingCompany.prototype.extraVolumetricWeightPrice;

/**
 * Alışveriş sepeti toplamı belirlediğiniz Ücretsiz kargo limitini geçtiğinde müşterileriniz ücretsiz kargo hizmetinden faydalanabilirler.(Örn: X Lira üzeri ücretsiz Kargo!)
 * @type {!number}
 * @export
 */
API.Client.ShippingCompany.prototype.freeShipmentOrderPrice;

/**
 * Ücretsiz kargo miktarı için maksimum ücretsiz desi miktarıdır. Alışveriş sırasındaki desi miktarı ücretsiz desi miktarından fazlaysa, + Desi miktarını sipariş sırasında sistem müşteriden tahsil eder.(Örn: X TL üzeri ücretsiz kargo! Fakat X desiye kadar)Üzeri müşteriden tahsil edilir.
 * @type {!number}
 * @export
 */
API.Client.ShippingCompany.prototype.freeShipmentVolumetricWeightLimit;

/**
 * Kargo firması nesnesi için sıralama değeri.
 * @type {!number}
 * @export
 */
API.Client.ShippingCompany.prototype.sortOrder;

/**
 * API tarafından otomatik oluşturulan kargo firması kodu.
 * @type {!string}
 * @export
 */
API.Client.ShippingCompany.prototype.companyCode;

/**
 * Kargo firması için ödeme tipi.<div class='idea_choice_list'><code>cash_on_delivery</code> : Alıcı ödemeli.<br><code>standart_delivery</code> : Gönderici ödemeli.<br><code>not_applicable</code> : Bu alan için uygulanabilir değil.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ShippingCompany.prototype.paymentType;

/**
 * Teslimat hizmeti sağlayıcısı nesnesi.
 * @type {!API.Client.ShippingProvider}
 * @export
 */
API.Client.ShippingCompany.prototype.shippingProvider;

/** @enum {string} */
API.Client.ShippingCompany.StatusEnum = { 
  active: 'active',
  passive: 'passive',
}
/** @enum {string} */
API.Client.ShippingCompany.PaymentTypeEnum = { 
  cash_on_delivery: 'cash_on_delivery',
  standart_delivery: 'standart_delivery',
  not_applicable: 'not_applicable',
}
