goog.provide('API.Client.SelectionGroup');

/**
 * @record
 */
API.Client.SelectionGroup = function() {}

/**
 * Ek özellik grubu nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.SelectionGroup.prototype.id;

/**
 * Ek özellik grubu nesnesinin başlığı.
 * @type {!string}
 * @export
 */
API.Client.SelectionGroup.prototype.title;

/**
 * Ek özellik grubu nesnesi için sıralama değeri.
 * @type {!number}
 * @export
 */
API.Client.SelectionGroup.prototype.sortOrder;

