goog.provide('API.Client.QuickCart');

/**
 * @record
 */
API.Client.QuickCart = function() {}

/**
 * Hızlı satın al bağlantısı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.QuickCart.prototype.id;

/**
 * Hızlı satın al bağlantısı nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.QuickCart.prototype.name;

/**
 * Hızlı satın al bağlantısı url'si.
 * @type {!string}
 * @export
 */
API.Client.QuickCart.prototype.url;

/**
 * Hızlı satın al bağlantısı için kısaltılmış url.
 * @type {!string}
 * @export
 */
API.Client.QuickCart.prototype.shortUrl;

