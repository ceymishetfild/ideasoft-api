goog.provide('API.Client.PaymentGatewaySetting');

/**
 * @record
 */
API.Client.PaymentGatewaySetting = function() {}

/**
 * Ödeme kanalı ayarı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.PaymentGatewaySetting.prototype.id;

/**
 * Ödeme kanalı ayarı nesnesi için değişken anahtarı.
 * @type {!string}
 * @export
 */
API.Client.PaymentGatewaySetting.prototype.varKey;

/**
 * Ödeme kanalı ayarı nesnesi için değişken değeri.
 * @type {!string}
 * @export
 */
API.Client.PaymentGatewaySetting.prototype.varValue;

/**
 * @type {!API.Client.PaymentGateway}
 * @export
 */
API.Client.PaymentGatewaySetting.prototype.paymentGateway;

