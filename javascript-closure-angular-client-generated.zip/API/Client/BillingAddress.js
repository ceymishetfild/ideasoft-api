goog.provide('API.Client.BillingAddress');

/**
 * @record
 */
API.Client.BillingAddress = function() {}

/**
 * Sipariş adresi nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.BillingAddress.prototype.id;

/**
 * Müşterinin ismi.
 * @type {!string}
 * @export
 */
API.Client.BillingAddress.prototype.firstname;

/**
 * Müşterinin soy ismi.
 * @type {!string}
 * @export
 */
API.Client.BillingAddress.prototype.surname;

/**
 * Müşterinin ülke bilgisi.
 * @type {!string}
 * @export
 */
API.Client.BillingAddress.prototype.country;

/**
 * Müşterinin şehir bilgisi.
 * @type {!string}
 * @export
 */
API.Client.BillingAddress.prototype.location;

/**
 * Müşterinin ilçe bilgisi.
 * @type {!string}
 * @export
 */
API.Client.BillingAddress.prototype.subLocation;

/**
 * Müşterinin adres bilgisi.
 * @type {!string}
 * @export
 */
API.Client.BillingAddress.prototype.address;

/**
 * Müşterinin telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.BillingAddress.prototype.phoneNumber;

/**
 * Müşterinin mobil telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.BillingAddress.prototype.mobilePhoneNumber;

/**
 * @type {!API.Client.Order}
 * @export
 */
API.Client.BillingAddress.prototype.order;

