goog.provide('API.Client.Order');

/**
 * @record
 */
API.Client.Order = function() {}

/**
 * Sipariş nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Order.prototype.id;

/**
 * Müşterinin ismi.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.customerFirstname;

/**
 * Müşterinin soy ismi.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.customerSurname;

/**
 * Müşterinin e-mail adresi.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.customerEmail;

/**
 * Müşterinin telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.customerPhone;

/**
 * Siparişin ödeme tipi.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.paymentTypeName;

/**
 * Siparişin ödeme altyapısı sağlayıcısının kodu. Ön tanımlıdır. API otomatik oluşturur.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.paymentProviderCode;

/**
 * Siparişin ödeme altyapısı sağlayıcısının adı. Ön tanımlıdır. API otomatik oluşturur.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.paymentProviderName;

/**
 * Siparişin ödeme kanalının kodu. Ön tanımlıdır. API otomatik oluşturur.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.paymentGatewayCode;

/**
 * Siparişin ödeme kanalının adı. Ön tanımlıdır. API otomatik oluşturur.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.paymentGatewayName;

/**
 * Siparişin banka adı. Ön tanımlıdır. API otomatik oluşturur.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.bankName;

/**
 * Müşterinin IP adresi.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.clientIp;

/**
 * Siparişin gerçekleştiği tarayıcı bilgisi.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.userAgent;

/**
 * Kur bilgisi.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.currency;

/**
 * Kur oranları.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.currencyRates;

/**
 * Siparişin vergi hariç fiyatı.
 * @type {!number}
 * @export
 */
API.Client.Order.prototype.amount;

/**
 * Siparişte kullanılan hediye çeki indirimi tutarı.
 * @type {!number}
 * @export
 */
API.Client.Order.prototype.couponDiscount;

/**
 * Siparişin vergi tutarı.
 * @type {!number}
 * @export
 */
API.Client.Order.prototype.taxAmount;

/**
 * Siparişte kullanılan promosyon indirimi tutarı.
 * @type {!number}
 * @export
 */
API.Client.Order.prototype.promotionDiscount;

/**
 * Siparişin genel fiyat tutarı. orderAmount, couponDiscount, taxAmount, promotionDiscount, shippingAmount, additionalServiceAmount tutarlarının toplamı.
 * @type {!number}
 * @export
 */
API.Client.Order.prototype.generalAmount;

/**
 * Siparişin teslimat ücreti.
 * @type {!number}
 * @export
 */
API.Client.Order.prototype.shippingAmount;

/**
 * Siparişin ek hizmet bedeli ücreti.
 * @type {!number}
 * @export
 */
API.Client.Order.prototype.additionalServiceAmount;

/**
 * Siparişin son ödeme tutarı. generalAmount değerinin üzerine taksitten kaynaklı vade farkı bedeli eklenmiş hali.
 * @type {!number}
 * @export
 */
API.Client.Order.prototype.finalAmount;

/**
 * Siparişten kazanılan puan tutarı.
 * @type {!number}
 * @export
 */
API.Client.Order.prototype.sumOfGainedPoints;

/**
 * Siparişin taksit adeti.
 * @type {!number}
 * @export
 */
API.Client.Order.prototype.installment;

/**
 * Siparişin taksit oranı.
 * @type {!number}
 * @export
 */
API.Client.Order.prototype.installmentRate;

/**
 * Siparişin ek taksit adeti.
 * @type {!number}
 * @export
 */
API.Client.Order.prototype.extraInstallment;

/**
 * Siparişin numarası.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.transactionId;

/**
 * Siparişin müşteri notuna sahiplik durumu.<div class='idea_choice_list'><code>1</code> : Sipariş müşteri notuna sahip.<br><code>0</code> : Sipariş müşteri notuna sahip değil.<br></div>
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.hasUserNote;

/**
 * Sipariş durumu.<div class='idea_choice_list'><code>deleted</code> : Silindi<br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br></div>
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.status;

/**
 * Ödeme durumu bilgisi.<div class='idea_choice_list'><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br><code>failed</code> : Hatalı Ödemeler<br><code>success</code> : Başarılı<br></div>
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.paymentStatus;

/**
 * Siparişin hata mesajı.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.errorMessage;

/**
 * Siparişin gerçekleştiği cihaz bilgisi.<div class='idea_choice_list'><code>desktop</code> : Masaüstü<br><code>mobile</code> : Mobil<br><code>tablet</code> : Tablet<br></div>
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.deviceType;

/**
 * Siparişe yönlendiren web-sitesi adresi. Yönlendirmeyi yapan web-sitesinin tam URL bilgisini de içerir. API otomatik oluşturur.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.referrer;

/**
 * Sipariş için alınan fatura çıktısı adedi.
 * @type {!number}
 * @export
 */
API.Client.Order.prototype.invoicePrintCount;

/**
 * Hediye paketi istenilmesi durumu.<div class='idea_choice_list'><code>1</code> : Hediye paketi istiyorum<br><code>0</code> : Hediye paketi istemiyorum<br></div>
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.useGiftPackage;

/**
 * Hediye notu.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.giftNote;

/**
 * Üye grubu adı.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.memberGroupName;

/**
 * Promosyon kullanılma durumu.<div class='idea_choice_list'><code>1</code> : Promosyon kullan<br><code>0</code> : Promosyon kullanma<br></div>
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.usePromotion;

/**
 * Siparişin teslimat hizmeti sağlayıcısı kodu. Ön tanımlıdır. API otomatik oluşturur.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.shippingProviderCode;

/**
 * Siparişin teslimat hizmeti sağlayıcısı adı. Ön tanımlıdır.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.shippingProviderName;

/**
 * Siparişin kargo firması adı. Ön tanımlıdır.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.shippingCompanyName;

/**
 * Siparişin kargo ödeme tipi.<div class='idea_choice_list'><code>cash_on_delivery</code> : Alıcı Ödemeli<br><code>standart_delivery</code> : Gönderici Ödemeli<br><code>not_applicable</code> : Bu alan için geçerli değil.<br></div>
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.shippingPaymentType;

/**
 * Siparişin kargo takip kodu.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.shippingTrackingCode;

/**
 * Siparişin kaynak bilgisi. Siparişin kaynak yazılımını belirtir.
 * @type {!string}
 * @export
 */
API.Client.Order.prototype.source;

/**
 * Sipariş nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Order.prototype.createdAt;

/**
 * Sipariş nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Order.prototype.updatedAt;

/**
 * @type {!API.Client.Maillist}
 * @export
 */
API.Client.Order.prototype.maillist;

/**
 * @type {!API.Client.Member}
 * @export
 */
API.Client.Order.prototype.member;

/**
 * Sipariş detayları.
 * @type {!Array<!API.Client.OrderDetail>}
 * @export
 */
API.Client.Order.prototype.orderDetails;

/**
 * Sipariş kalemleri.
 * @type {!Array<!API.Client.OrderItem>}
 * @export
 */
API.Client.Order.prototype.orderItems;

/**
 * @type {!API.Client.ShippingAddress}
 * @export
 */
API.Client.Order.prototype.shippingAddress;

/**
 * @type {!API.Client.BillingAddress}
 * @export
 */
API.Client.Order.prototype.billingAddress;

/** @enum {string} */
API.Client.Order.HasUserNoteEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.Order.StatusEnum = { 
  deleted: 'deleted',
  waiting_for_approval: 'waiting_for_approval',
  approved: 'approved',
  fulfilled: 'fulfilled',
  cancelled: 'cancelled',
  delivered: 'delivered',
  on_accumulation: 'on_accumulation',
  waiting_for_payment: 'waiting_for_payment',
  being_prepared: 'being_prepared',
  refunded: 'refunded',
  personal_status_1: 'personal_status_1',
  personal_status_2: 'personal_status_2',
  personal_status_3: 'personal_status_3',
}
/** @enum {string} */
API.Client.Order.PaymentStatusEnum = { 
  in_transaction: 'in_transaction',
  failed: 'failed',
  success: 'success',
}
/** @enum {string} */
API.Client.Order.DeviceTypeEnum = { 
  desktop: 'desktop',
  mobile: 'mobile',
  tablet: 'tablet',
}
/** @enum {string} */
API.Client.Order.UseGiftPackageEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.Order.UsePromotionEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.Order.ShippingPaymentTypeEnum = { 
  cash_on_delivery: 'cash_on_delivery',
  standart_delivery: 'standart_delivery',
  not_applicable: 'not_applicable',
}
