goog.provide('API.Client.MemberAddress');

/**
 * @record
 */
API.Client.MemberAddress = function() {}

/**
 * Üye adresi nesnesinin benzersiz rakamsal kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.MemberAddress.prototype.id;

/**
 * Üye Adresi adı.
 * @type {!string}
 * @export
 */
API.Client.MemberAddress.prototype.name;

/**
 * Üye Adresi tipi.<div class='idea_choice_list'><code>shipping</code> : Teslimat adresi.<br><code>billing</code> : Fatura adresi.<br></div>
 * @type {!string}
 * @export
 */
API.Client.MemberAddress.prototype.type;

/**
 * Üyenin ismi.
 * @type {!string}
 * @export
 */
API.Client.MemberAddress.prototype.firstname;

/**
 * Üyenin soy ismi.
 * @type {!string}
 * @export
 */
API.Client.MemberAddress.prototype.surname;

/**
 * Üyenin adres bilgileri.
 * @type {!string}
 * @export
 */
API.Client.MemberAddress.prototype.address;

/**
 * İlçe adı.
 * @type {!string}
 * @export
 */
API.Client.MemberAddress.prototype.subLocationName;

/**
 * Üyenin telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.MemberAddress.prototype.phoneNumber;

/**
 * Üyenin mobil telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.MemberAddress.prototype.mobilePhoneNumber;

/**
 * Üyenin TC kimlik numarası.
 * @type {!string}
 * @export
 */
API.Client.MemberAddress.prototype.tcId;

/**
 * Üyenin vergi numarası.
 * @type {!string}
 * @export
 */
API.Client.MemberAddress.prototype.taxNumber;

/**
 * Üyenin vergi dairesi.
 * @type {!string}
 * @export
 */
API.Client.MemberAddress.prototype.taxOffice;

/**
 * Fatura tipini belirtir.<div class='idea_choice_list'><code>individual</code> : Bireysel<br><code>corporate</code> : Kurumsal<br></div>
 * @type {!string}
 * @export
 */
API.Client.MemberAddress.prototype.invoiceType;

/**
 * Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div>
 * @type {!boolean}
 * @export
 */
API.Client.MemberAddress.prototype.isEinvoiceUser;

/**
 * Tema nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.MemberAddress.prototype.createdAt;

/**
 * Tema nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.MemberAddress.prototype.updatedAt;

/**
 * Üye nesnesi
 * @type {!API.Client.Member}
 * @export
 */
API.Client.MemberAddress.prototype.member;

/**
 * Ülke nesnesi.
 * @type {!API.Client.Country}
 * @export
 */
API.Client.MemberAddress.prototype.country;

/**
 * Şehir nesnesi.
 * @type {!API.Client.Location}
 * @export
 */
API.Client.MemberAddress.prototype.location;

/**
 * İlçe nesnesi.
 * @type {!API.Client.Town}
 * @export
 */
API.Client.MemberAddress.prototype.subLocation;

