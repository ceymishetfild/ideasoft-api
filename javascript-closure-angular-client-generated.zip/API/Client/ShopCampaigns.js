goog.provide('API.Client.ShopCampaigns');

/**
 * @record
 */
API.Client.ShopCampaigns = function() {}

/**
 * Promosyon nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ShopCampaigns.prototype.id;

/**
 * Promosyon adı.
 * @type {!string}
 * @export
 */
API.Client.ShopCampaigns.prototype.label;

