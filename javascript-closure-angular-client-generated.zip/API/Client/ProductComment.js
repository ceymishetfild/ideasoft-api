goog.provide('API.Client.ProductComment');

/**
 * @record
 */
API.Client.ProductComment = function() {}

/**
 * Ürün yorumu nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ProductComment.prototype.id;

/**
 * Ürün yorumu başlığı.
 * @type {!string}
 * @export
 */
API.Client.ProductComment.prototype.title;

/**
 * Ürün yorumu içeriği.
 * @type {!string}
 * @export
 */
API.Client.ProductComment.prototype.content;

/**
 * Ürün yorumu durumu.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
 * @type {!boolean}
 * @export
 */
API.Client.ProductComment.prototype.status;

/**
 * Ürün yorumunda ürüne verilen puan.<div class='idea_choice_list'><code>1</code> : 1 puan.<br><code>2</code> : 2 puan.<br><code>3</code> : 3 puan.<br><code>4</code> : 4 puan.<br><code>5</code> : 5 puan.<br></div>
 * @type {!number}
 * @export
 */
API.Client.ProductComment.prototype.rank;

/**
 * Ürün yorumu yapan kişinin anonim olup olmadığı bilgisi.<div class='idea_choice_list'><code>1</code> : Anonim.<br><code>0</code> : Anonim değil.<br></div>
 * @type {!boolean}
 * @export
 */
API.Client.ProductComment.prototype.isAnonymous;

/**
 * Ürün yorumu nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.ProductComment.prototype.createdAt;

/**
 * Ürün yorumu nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.ProductComment.prototype.updatedAt;

/**
 * Yorumu yapan üye.
 * @type {!API.Client.Member}
 * @export
 */
API.Client.ProductComment.prototype.member;

/**
 * Yorum yapılan ürün.
 * @type {!API.Client.Product}
 * @export
 */
API.Client.ProductComment.prototype.product;

/** @enum {string} */
API.Client.ProductComment.RankEnum = { 
  1: '1',
  2: '2',
  3: '3',
  4: '4',
  5: '5',
}
