goog.provide('API.Client.OrderDetail');

/**
 * @record
 */
API.Client.OrderDetail = function() {}

/**
 * Sipariş detayı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.OrderDetail.prototype.id;

/**
 * Sipariş detayı nesnesi için değişken anahtarı.
 * @type {!string}
 * @export
 */
API.Client.OrderDetail.prototype.varKey;

/**
 * Sipariş detayı nesnesi için değişken değeri.
 * @type {!string}
 * @export
 */
API.Client.OrderDetail.prototype.varValue;

/**
 * Sipariş nesnesi.
 * @type {!API.Client.Order}
 * @export
 */
API.Client.OrderDetail.prototype.order;

