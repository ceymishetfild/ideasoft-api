goog.provide('API.Client.Maillist');

/**
 * @record
 */
API.Client.Maillist = function() {}

/**
 * Mail listesi nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Maillist.prototype.id;

/**
 * Mail listesi nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.Maillist.prototype.name;

/**
 * Ziyaretçi veya üyenin mail adresi.
 * @type {!string}
 * @export
 */
API.Client.Maillist.prototype.email;

/**
 * En son e-mail gönderilen zaman.
 * @type {!Date}
 * @export
 */
API.Client.Maillist.prototype.lastMailSentDate;

/**
 * Mail listesi nesnesini oluşturan kişinin IP adresi.
 * @type {!string}
 * @export
 */
API.Client.Maillist.prototype.creatorIpAddress;

/**
 * Mail listesi nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Maillist.prototype.createdAt;

/**
 * Mail listesi nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Maillist.prototype.updatedAt;

/**
 * @type {!API.Client.MaillistGroup}
 * @export
 */
API.Client.Maillist.prototype.maillistGroup;

