goog.provide('API.Client.Selection');

/**
 * @record
 */
API.Client.Selection = function() {}

/**
 * Ek özellik nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Selection.prototype.id;

/**
 * Ek özellik nesnesinin başlığı.
 * @type {!string}
 * @export
 */
API.Client.Selection.prototype.title;

/**
 * Ek özellik nesnesi için sıralama değeri.
 * @type {!number}
 * @export
 */
API.Client.Selection.prototype.sortOrder;

/**
 * @type {!API.Client.SelectionGroup}
 * @export
 */
API.Client.Selection.prototype.selectionGroup;

