goog.provide('API.Client.PaymentGateway');

/**
 * @record
 */
API.Client.PaymentGateway = function() {}

/**
 * Ödeme kanalı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.PaymentGateway.prototype.id;

/**
 * Ödeme kanalı için ön tanımlanmış kod değeri.
 * @type {!string}
 * @export
 */
API.Client.PaymentGateway.prototype.code;

/**
 * Ödeme kanalı nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.PaymentGateway.prototype.name;

/**
 * Ödeme kanalının aktiflik durumu.<div class='idea_choice_list'><code>active</code> : Aktif<br><code>passive</code> : Pasif<br></div>
 * @type {!string}
 * @export
 */
API.Client.PaymentGateway.prototype.status;

/**
 * Ödeme kanalı nesnesi için sıralama değeri.
 * @type {!number}
 * @export
 */
API.Client.PaymentGateway.prototype.sortOrder;

/**
 * @type {!API.Client.PaymentProvider}
 * @export
 */
API.Client.PaymentGateway.prototype.paymentProvider;

/**
 * Ödeme kanalı ayarları.
 * @type {!Array<!API.Client.PaymentGatewaySetting>}
 * @export
 */
API.Client.PaymentGateway.prototype.settings;

/** @enum {string} */
API.Client.PaymentGateway.StatusEnum = { 
  active: 'active',
  passive: 'passive',
}
