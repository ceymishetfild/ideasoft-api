goog.provide('API.Client.ShopTokens');

/**
 * @record
 */
API.Client.ShopTokens = function() {}

/**
 * Hediye çeki nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ShopTokens.prototype.id;

/**
 * Hediye çekinin benzersiz kodu. Admin panelinden düzenlenebilir.
 * @type {!string}
 * @export
 */
API.Client.ShopTokens.prototype.code;

