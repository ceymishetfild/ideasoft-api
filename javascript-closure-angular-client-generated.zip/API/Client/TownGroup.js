goog.provide('API.Client.TownGroup');

/**
 * @record
 */
API.Client.TownGroup = function() {}

/**
 * İlçe grubu nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.TownGroup.prototype.id;

/**
 * İlçe grubu nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.TownGroup.prototype.name;

/**
 * İlçe grubunun aktiflik bilgisini içerir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
 * @type {!boolean}
 * @export
 */
API.Client.TownGroup.prototype.status;

