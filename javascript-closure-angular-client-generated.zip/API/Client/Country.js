goog.provide('API.Client.Country');

/**
 * @record
 */
API.Client.Country = function() {}

/**
 * Ülke nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Country.prototype.id;

/**
 * Ülke nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.Country.prototype.name;

/**
 * Ülkenin aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.Country.prototype.status;

/** @enum {string} */
API.Client.Country.StatusEnum = { 
  0: '0',
  1: '1',
}
