goog.provide('API.Client.Currency');

/**
 * @record
 */
API.Client.Currency = function() {}

/**
 * Kur nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Currency.prototype.id;

/**
 * Kur etiketi.
 * @type {!string}
 * @export
 */
API.Client.Currency.prototype.label;

/**
 * Kurun alış fiyatı.
 * @type {!number}
 * @export
 */
API.Client.Currency.prototype.buyingPrice;

/**
 * Kurun satış fiyatı.
 * @type {!number}
 * @export
 */
API.Client.Currency.prototype.sellingPrice;

/**
 * Kurun kısaltması.
 * @type {!string}
 * @export
 */
API.Client.Currency.prototype.abbr;

/**
 * Kur nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Currency.prototype.updatedAt;

/**
 * Kur nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.Currency.prototype.status;

/**
 * Kurun birincil kur olup olmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Birincil kur.<br><code>0</code> : Birincil kur değil.<br></div>
 * @type {!string}
 * @export
 */
API.Client.Currency.prototype.isPrimary;

/** @enum {string} */
API.Client.Currency.StatusEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.Currency.IsPrimaryEnum = { 
  0: '0',
  1: '1',
}
