goog.provide('API.Client.OrderUserNote');

/**
 * @record
 */
API.Client.OrderUserNote = function() {}

/**
 * Sipariş yönetici notu nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.OrderUserNote.prototype.id;

/**
 * Yöneticinin(admin) e-mail adresi.
 * @type {!string}
 * @export
 */
API.Client.OrderUserNote.prototype.userEmail;

/**
 * Yöneticinin(admin) ismi.
 * @type {!string}
 * @export
 */
API.Client.OrderUserNote.prototype.userFirstname;

/**
 * Yöneticinin(admin) soy ismi.
 * @type {!string}
 * @export
 */
API.Client.OrderUserNote.prototype.userSurname;

/**
 * Yöneticinin(admin) sipariş için girdiği not.
 * @type {!string}
 * @export
 */
API.Client.OrderUserNote.prototype.note;

/**
 * Sipariş yönetici notu nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.OrderUserNote.prototype.createdAt;

/**
 * Sipariş yönetici notu nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.OrderUserNote.prototype.updatedAt;

/**
 * Sipariş nesnesi.
 * @type {!API.Client.Order}
 * @export
 */
API.Client.OrderUserNote.prototype.order;

