goog.provide('API.Client.SelectionToProduct');

/**
 * @record
 */
API.Client.SelectionToProduct = function() {}

/**
 * Ek özellik ürün bağı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.SelectionToProduct.prototype.id;

/**
 * Ek özellik nesnesi.
 * @type {!API.Client.Selection}
 * @export
 */
API.Client.SelectionToProduct.prototype.selection;

/**
 * Ürün nesnesi.
 * @type {!API.Client.Product}
 * @export
 */
API.Client.SelectionToProduct.prototype.product;

