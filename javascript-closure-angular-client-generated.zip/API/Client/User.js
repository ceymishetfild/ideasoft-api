goog.provide('API.Client.User');

/**
 * @record
 */
API.Client.User = function() {}

/**
 * Yönetici nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.User.prototype.id;

/**
 * Yöneticinin ismi.
 * @type {!string}
 * @export
 */
API.Client.User.prototype.firstname;

/**
 * Yöneticinin soy ismi.
 * @type {!string}
 * @export
 */
API.Client.User.prototype.surname;

/**
 * Yöneticinin e-mail adresi.
 * @type {!string}
 * @export
 */
API.Client.User.prototype.email;

/**
 * Yöneticinin kullanıcı adı.
 * @type {!string}
 * @export
 */
API.Client.User.prototype.username;

/**
 * Yöneticinin telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.User.prototype.phoneNumber;

/**
 * Yöneticinin aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br><code>2</code> : Askıya alınmış.<br></div>
 * @type {!number}
 * @export
 */
API.Client.User.prototype.status;

/**
 * Yöneticinin site sahibi olma durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Site sahibi.<br><code>0</code> : Site sahibi değil.<br></div>
 * @type {!string}
 * @export
 */
API.Client.User.prototype.isOwner;

/**
 * İlgili üye grubu.
 * @type {!Array<!API.Client.MemberGroup>}
 * @export
 */
API.Client.User.prototype.membergroups;

/**
 * Yöneticinin SMS verifikasyonu yapılma bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : SMS verifikasyon yapılmış.<br><code>0</code> : SMS verifikasyon yapılmamış.<br></div>
 * @type {!string}
 * @export
 */
API.Client.User.prototype.smsApproved;

/**
 * Yönetici grubu nesnesi.
 * @type {!API.Client.ShopUserlevels}
 * @export
 */
API.Client.User.prototype.userlevel;

/** @enum {string} */
API.Client.User.StatusEnum = { 
  0: '0',
  1: '1',
  2: '2',
}
/** @enum {string} */
API.Client.User.IsOwnerEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.User.SmsApprovedEnum = { 
  0: '0',
  1: '1',
}
