goog.provide('API.Client.OrderAddress');

/**
 * @record
 */
API.Client.OrderAddress = function() {}

/**
 * Sipariş adresi nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.OrderAddress.prototype.id;

/**
 * Müşterinin ismi.
 * @type {!string}
 * @export
 */
API.Client.OrderAddress.prototype.firstname;

/**
 * Müşterinin soy ismi.
 * @type {!string}
 * @export
 */
API.Client.OrderAddress.prototype.surname;

/**
 * Müşterinin ülke bilgisi.
 * @type {!string}
 * @export
 */
API.Client.OrderAddress.prototype.country;

/**
 * Müşterinin şehir bilgisi.
 * @type {!string}
 * @export
 */
API.Client.OrderAddress.prototype.location;

/**
 * Müşterinin ilçe bilgisi.
 * @type {!string}
 * @export
 */
API.Client.OrderAddress.prototype.subLocation;

/**
 * Müşterinin adres bilgisi.
 * @type {!string}
 * @export
 */
API.Client.OrderAddress.prototype.address;

/**
 * Müşterinin telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.OrderAddress.prototype.phoneNumber;

/**
 * Müşterinin mobil telefon numarası.
 * @type {!string}
 * @export
 */
API.Client.OrderAddress.prototype.mobilePhoneNumber;

/**
 * Sipariş nesnesi.
 * @type {!API.Client.Order}
 * @export
 */
API.Client.OrderAddress.prototype.order;

