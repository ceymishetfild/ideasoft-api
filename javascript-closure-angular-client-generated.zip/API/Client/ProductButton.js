goog.provide('API.Client.ProductButton');

/**
 * @record
 */
API.Client.ProductButton = function() {}

/**
 * Ürün ve stok butonu nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ProductButton.prototype.id;

/**
 * Hızlı gönderi butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Hızlı kargo butonu aktif.<br><code>0</code> : Hızlı kargo butonu pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ProductButton.prototype.fastShipping;

/**
 * Aynı gün kargo butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aynı gün kargo butonu aktif.<br><code>0</code> : Aynı gün kargo butonu pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ProductButton.prototype.sameDayShipping;

/**
 * 3 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 3 günde teslimat butonu aktif.<br><code>0</code> : 3 günde teslimat butonu pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ProductButton.prototype.threeDaysDelivery;

/**
 * 5 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 5 günde teslimat butonu aktif.<br><code>0</code> : 5 günde teslimat butonu pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ProductButton.prototype.fiveDaysDelivery;

/**
 * 7 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 7 günde teslimat butonu aktif.<br><code>0</code> : 7 günde teslimat butonu pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ProductButton.prototype.sevenDaysDelivery;

/**
 * Kargo bedava butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Kargo bedava butonu aktif.<br><code>0</code> : Kargo bedava butonu pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ProductButton.prototype.freeShipping;

/**
 * Stoktan teslim butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Stoktan teslim butonu aktif.<br><code>0</code> : Stoktan teslim butonu pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ProductButton.prototype.deliveryFromStock;

/**
 * Ön siparişli stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Ön siparişli ürün butonu aktif.<br><code>0</code> : Ön siparişli ürün butonu pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ProductButton.prototype.preOrderedProduct;

/**
 * Sınırlı stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Sınırlı stok butonu aktif.<br><code>0</code> : Sınırlı stok butonu pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ProductButton.prototype.limitedStock;

/**
 * Stok sorunuz butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Stok sorunuz butonu aktif.<br><code>0</code> : Stok sorunuz butonu pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ProductButton.prototype.askStock;

/**
 * Kampanyalı stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Kampanyalı ürün butonu aktif.<br><code>0</code> : Kampanyalı ürün butonu pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ProductButton.prototype.campaignedProduct;

/**
 * Ürün nesnesi.
 * @type {!API.Client.Product}
 * @export
 */
API.Client.ProductButton.prototype.product;

/** @enum {string} */
API.Client.ProductButton.FastShippingEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.ProductButton.SameDayShippingEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.ProductButton.ThreeDaysDeliveryEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.ProductButton.FiveDaysDeliveryEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.ProductButton.SevenDaysDeliveryEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.ProductButton.FreeShippingEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.ProductButton.DeliveryFromStockEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.ProductButton.PreOrderedProductEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.ProductButton.LimitedStockEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.ProductButton.AskStockEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.ProductButton.CampaignedProductEnum = { 
  0: '0',
  1: '1',
}
