goog.provide('API.Client.Town');

/**
 * @record
 */
API.Client.Town = function() {}

/**
 * İlçe nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Town.prototype.id;

/**
 * İlçe nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.Town.prototype.name;

/**
 * İlçenin aktiflik bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.Town.prototype.status;

/**
 * @type {!API.Client.Location}
 * @export
 */
API.Client.Town.prototype.location;

/**
 * @type {!API.Client.TownGroup}
 * @export
 */
API.Client.Town.prototype.townGroup;

/** @enum {string} */
API.Client.Town.StatusEnum = { 
  0: '0',
  1: '1',
}
