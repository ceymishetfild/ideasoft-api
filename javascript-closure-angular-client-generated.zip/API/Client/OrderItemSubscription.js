goog.provide('API.Client.OrderItemSubscription');

/**
 * @record
 */
API.Client.OrderItemSubscription = function() {}

/**
 * Sipariş kalemi aboneliği kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.OrderItemSubscription.prototype.id;

