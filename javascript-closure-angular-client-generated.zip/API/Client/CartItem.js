goog.provide('API.Client.CartItem');

/**
 * @record
 */
API.Client.CartItem = function() {}

/**
 * Sepet kalemi nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.CartItem.prototype.id;

/**
 * Ana ürünün benzersiz rakamsal kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.CartItem.prototype.parentProductId;

/**
 * Sepetteki kalem adedi.
 * @type {!number}
 * @export
 */
API.Client.CartItem.prototype.quantity;

/**
 * Sepetteki kaleme ait kategorinin benzersiz kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.CartItem.prototype.categoryId;

/**
 * Sepet kalemi nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.CartItem.prototype.createdAt;

/**
 * Sepet kalemi nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.CartItem.prototype.updatedAt;

/**
 * @type {!API.Client.Cart}
 * @export
 */
API.Client.CartItem.prototype.cart;

/**
 * @type {!API.Client.Product}
 * @export
 */
API.Client.CartItem.prototype.product;

/**
 * Sepet kalemi özelliği barındıran liste.
 * @type {!Array<!API.Client.CartItemAttribute>}
 * @export
 */
API.Client.CartItem.prototype.attributes;

