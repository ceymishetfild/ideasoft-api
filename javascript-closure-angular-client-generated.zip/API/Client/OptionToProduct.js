goog.provide('API.Client.OptionToProduct');

/**
 * @record
 */
API.Client.OptionToProduct = function() {}

/**
 * Varyant ürün bağı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.OptionToProduct.prototype.id;

/**
 * Ana ürünün benzersiz kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.OptionToProduct.prototype.parentProductId;

/**
 * @type {!API.Client.OptionGroup}
 * @export
 */
API.Client.OptionToProduct.prototype.optionGroup;

/**
 * @type {!API.Client.Options}
 * @export
 */
API.Client.OptionToProduct.prototype.option;

/**
 * @type {!API.Client.Product}
 * @export
 */
API.Client.OptionToProduct.prototype.product;

