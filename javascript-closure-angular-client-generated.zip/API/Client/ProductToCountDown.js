goog.provide('API.Client.ProductToCountDown');

/**
 * @record
 */
API.Client.ProductToCountDown = function() {}

/**
 * Ürün geri sayım bağı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ProductToCountDown.prototype.id;

/**
 * Geri sayımın başlangıç tarihi.
 * @type {!Date}
 * @export
 */
API.Client.ProductToCountDown.prototype.startDate;

/**
 * Geri sayımın bitiş tarihi.
 * @type {!Date}
 * @export
 */
API.Client.ProductToCountDown.prototype.endDate;

/**
 * Geri sayımın ürün için geçersiz olma tarihi.
 * @type {!Date}
 * @export
 */
API.Client.ProductToCountDown.prototype.expireDate;

/**
 * Geri sayımın aktiflik durumu bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.ProductToCountDown.prototype.useCountDown;

/**
 * Ürün nesnesi.
 * @type {!API.Client.Product}
 * @export
 */
API.Client.ProductToCountDown.prototype.product;

/** @enum {string} */
API.Client.ProductToCountDown.UseCountDownEnum = { 
  0: '0',
  1: '1',
}
