goog.provide('API.Client.ProductSpecialInfo');

/**
 * @record
 */
API.Client.ProductSpecialInfo = function() {}

/**
 * Özel bilgi alanı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ProductSpecialInfo.prototype.id;

/**
 * Özel bilgi alanı başlığı.
 * @type {!string}
 * @export
 */
API.Client.ProductSpecialInfo.prototype.title;

/**
 * Özel bilgi alanı içeriği.
 * @type {!string}
 * @export
 */
API.Client.ProductSpecialInfo.prototype.content;

/**
 * Özel bilgi alanı aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
 * @type {!number}
 * @export
 */
API.Client.ProductSpecialInfo.prototype.status;

/**
 * Ürün nesnesi.
 * @type {!API.Client.Product}
 * @export
 */
API.Client.ProductSpecialInfo.prototype.product;

