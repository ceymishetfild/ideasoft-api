goog.provide('API.Client.OrderRefundRequestItem');

/**
 * @record
 */
API.Client.OrderRefundRequestItem = function() {}

/**
 * Sipariş iptal talebi kalemi nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.OrderRefundRequestItem.prototype.id;

/**
 * Sipariş iptal talebi istenen ürün miktarı.
 * @type {!number}
 * @export
 */
API.Client.OrderRefundRequestItem.prototype.amount;

/**
 * Sipariş iptal talebi sebebi. Tanımlı dört seçenekten biri seçilmelidir.<div class='idea_choice_list'><code>Ürünü iade etmek istiyorum.</code> : <br><code>Ürünü değiştirmek istiyorum.</code> : <br><code>Faturadaki ürünler ile bana gelen ürünler farklı.</code> : <br><code>Diğer</code> : <br></div>
 * @type {!string}
 * @export
 */
API.Client.OrderRefundRequestItem.prototype.reason;

/**
 * Sipariş iptal talebinin detaylı açıklaması.
 * @type {!string}
 * @export
 */
API.Client.OrderRefundRequestItem.prototype.details;

/**
 * Sipariş iptal talebi kalemi nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.OrderRefundRequestItem.prototype.createdAt;

/**
 * Sipariş iptal talebi kalemi nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.OrderRefundRequestItem.prototype.updatedAt;

/**
 * @type {!API.Client.OrderItem}
 * @export
 */
API.Client.OrderRefundRequestItem.prototype.orderItem;

/**
 * @type {!API.Client.OrderRefundRequest}
 * @export
 */
API.Client.OrderRefundRequestItem.prototype.orderRefundRequest;

