goog.provide('API.Client.SpecGroup');

/**
 * @record
 */
API.Client.SpecGroup = function() {}

/**
 * Ürün özelliği grubu nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.SpecGroup.prototype.id;

/**
 * Ürün özelliği grubu nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.SpecGroup.prototype.name;

/**
 * Ürün özelliği grubu nesnesi için sıralama değeri.
 * @type {!number}
 * @export
 */
API.Client.SpecGroup.prototype.sortOrder;

/**
 * Ürün özelliği grubu nesnesi için aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
 * @type {!string}
 * @export
 */
API.Client.SpecGroup.prototype.status;

/** @enum {string} */
API.Client.SpecGroup.StatusEnum = { 
  0: '0',
  1: '1',
}
