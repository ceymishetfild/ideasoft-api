goog.provide('API.Client.Theme');

/**
 * @record
 */
API.Client.Theme = function() {}

/**
 * Tema nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Theme.prototype.id;

/**
 * Temanın kullanılacağı platform.<div class='idea_choice_list'><code>desktop</code> : Masaüstü.<br><code>mobile</code> : Mobil.<br></div>
 * @type {!string}
 * @export
 */
API.Client.Theme.prototype.platform;

/**
 * Tema tipi.<div class='idea_choice_list'><code>self</code> : Kişisel Tema.<br><code>standard</code> : Standart Tema.<br></div>
 * @type {!string}
 * @export
 */
API.Client.Theme.prototype.type;

/**
 * Tema adı.
 * @type {!string}
 * @export
 */
API.Client.Theme.prototype.name;

/**
 * Temanın rengi.
 * @type {!string}
 * @export
 */
API.Client.Theme.prototype.preset;

/**
 * Temanın dizini.
 * @type {!string}
 * @export
 */
API.Client.Theme.prototype.directoryName;

/**
 * Temanın durumu.
 * @type {!string}
 * @export
 */
API.Client.Theme.prototype.status;

/**
 * Temanın revisionı.
 * @type {!number}
 * @export
 */
API.Client.Theme.prototype.revision;

/**
 * Tema nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Theme.prototype.createdAt;

/**
 * Tema nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Theme.prototype.updatedAt;

/**
 * @type {!string}
 * @export
 */
API.Client.Theme.prototype.attachment;

/** @enum {string} */
API.Client.Theme.PlatformEnum = { 
  desktop: 'desktop',
  mobile: 'mobile',
}
/** @enum {string} */
API.Client.Theme.TypeEnum = { 
  self: 'self',
  standard: 'standard',
}
/** @enum {string} */
API.Client.Theme.StatusEnum = { 
  0: '0',
  1: '1',
}
