goog.provide('API.Client.Location');

/**
 * @record
 */
API.Client.Location = function() {}

/**
 * Şehir nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Location.prototype.id;

/**
 * Şehir nesnesi için isim değeri.
 * @type {!string}
 * @export
 */
API.Client.Location.prototype.name;

/**
 * Şehir nesnesinin aktiflik durumunu belirten değer.
 * @type {!string}
 * @export
 */
API.Client.Location.prototype.status;

/**
 * Şehir nesnesinin öntanımlı olup olmadığını belirtir.<div class='idea_choice_list'><code>1</code> : Öntanımlı şehir.<br><code>0</code> : Yeni eklenmiş şehir.<br></div>
 * @type {!string}
 * @export
 */
API.Client.Location.prototype.predefined;

/**
 * @type {!API.Client.Country}
 * @export
 */
API.Client.Location.prototype.country;

/**
 * @type {!API.Client.Region}
 * @export
 */
API.Client.Location.prototype.region;

/** @enum {string} */
API.Client.Location.StatusEnum = { 
  0: '0',
  1: '1',
}
/** @enum {string} */
API.Client.Location.PredefinedEnum = { 
  0: '0',
  1: '1',
}
