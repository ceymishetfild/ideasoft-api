goog.provide('API.Client.ShopUserlevels');

/**
 * @record
 */
API.Client.ShopUserlevels = function() {}

/**
 * Yönetici grubu nesnesinin benzersiz rakamsal kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ShopUserlevels.prototype.id;

/**
 * Yönetici grubu ismi.
 * @type {!string}
 * @export
 */
API.Client.ShopUserlevels.prototype.label;

/**
 * Yönetici grubunun sahip olduğu roller.
 * @type {!string}
 * @export
 */
API.Client.ShopUserlevels.prototype.roles;

