goog.provide('API.Client.CurrentAccount');

/**
 * @record
 */
API.Client.CurrentAccount = function() {}

/**
 * Cari hesap nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.CurrentAccount.prototype.id;

/**
 * Cari hesap için düzenlenebilir bir kod değeri.
 * @type {!string}
 * @export
 */
API.Client.CurrentAccount.prototype.code;

/**
 * Cari hesap nesnesinin başlığı.
 * @type {!string}
 * @export
 */
API.Client.CurrentAccount.prototype.title;

/**
 * Cari hesabın bakiyesi.
 * @type {!number}
 * @export
 */
API.Client.CurrentAccount.prototype.balance;

/**
 * Cari hesap için belirlenmiş risk limiti.
 * @type {!number}
 * @export
 */
API.Client.CurrentAccount.prototype.riskLimit;

/**
 * Cari hesap nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.CurrentAccount.prototype.createdAt;

/**
 * Cari hesap nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.CurrentAccount.prototype.updatedAt;

/**
 * @type {!API.Client.Member}
 * @export
 */
API.Client.CurrentAccount.prototype.member;

