goog.provide('API.Client.Cart');

/**
 * @record
 */
API.Client.Cart = function() {}

/**
 * Sepet nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.Cart.prototype.id;

/**
 * Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri.
 * @type {!string}
 * @export
 */
API.Client.Cart.prototype.sessionId;

/**
 * Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz.
 * @type {!string}
 * @export
 */
API.Client.Cart.prototype.locked;

/**
 * Sepet nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Cart.prototype.createdAt;

/**
 * Sepet nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.Cart.prototype.updatedAt;

/**
 * Promosyon nesnesi.
 * @type {!API.Client.ShopCampaigns}
 * @export
 */
API.Client.Cart.prototype.chosenPromotion;

/**
 * Üye nesnesi.
 * @type {!API.Client.Member}
 * @export
 */
API.Client.Cart.prototype.member;

/**
 * Hediye çeki nesnesi.
 * @type {!API.Client.ShopTokens}
 * @export
 */
API.Client.Cart.prototype.chosenToken;

/**
 * Sepet kalemi nesnelerini barındıran liste.
 * @type {!Array<!API.Client.CartItem>}
 * @export
 */
API.Client.Cart.prototype.items;

/** @enum {string} */
API.Client.Cart.LockedEnum = { 
  0: '0',
  1: '1',
}
