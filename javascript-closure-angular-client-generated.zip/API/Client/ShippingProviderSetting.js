goog.provide('API.Client.ShippingProviderSetting');

/**
 * @record
 */
API.Client.ShippingProviderSetting = function() {}

/**
 * Teslimat hizmeti sağlayıcısı ayarı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ShippingProviderSetting.prototype.id;

/**
 * Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken anahtarı.
 * @type {!string}
 * @export
 */
API.Client.ShippingProviderSetting.prototype.varKey;

/**
 * Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken değeri.
 * @type {!string}
 * @export
 */
API.Client.ShippingProviderSetting.prototype.varValue;

/**
 * Teslimat hizmeti sağlayıcısı nesnesi.
 * @type {!API.Client.ShippingProvider}
 * @export
 */
API.Client.ShippingProviderSetting.prototype.shippingProvider;

