goog.provide('API.Client.InstallmentRate');

/**
 * @record
 */
API.Client.InstallmentRate = function() {}

/**
 * Taksit oranı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.InstallmentRate.prototype.id;

/**
 * Taksit adeti.
 * @type {!number}
 * @export
 */
API.Client.InstallmentRate.prototype.installment;

/**
 * Taksit adeti için oran bilgisi.
 * @type {!number}
 * @export
 */
API.Client.InstallmentRate.prototype.rate;

/**
 * @type {!API.Client.PaymentGateway}
 * @export
 */
API.Client.InstallmentRate.prototype.paymentGateway;

