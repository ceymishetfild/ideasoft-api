goog.provide('API.Client.OrderRefundRequest');

/**
 * @record
 */
API.Client.OrderRefundRequest = function() {}

/**
 * Sipariş iptal talebi nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.OrderRefundRequest.prototype.id;

/**
 * Sipariş iptal talebi için oluşturulan benzersiz kod değeri.
 * @type {!string}
 * @export
 */
API.Client.OrderRefundRequest.prototype.code;

/**
 * Sipariş iptal talebi için durum bilgisi.<div class='idea_choice_list'><code>approved</code> : Onaylandı.<br><code>waiting_for_approval</code> : Onay bekliyor.<br><code>cancelled</code> : İptal edildi.<br></div>
 * @type {!string}
 * @export
 */
API.Client.OrderRefundRequest.prototype.status;

/**
 * Müşteriye ödenecek miktar bilgisi.
 * @type {!number}
 * @export
 */
API.Client.OrderRefundRequest.prototype.fee;

/**
 * Sipariş iptal talebinin oluşturulması sebebinin detaylı açıklaması.
 * @type {!string}
 * @export
 */
API.Client.OrderRefundRequest.prototype.cancellationReason;

/**
 * Sipariş iptal talebi nesnesinin oluşturulma zamanı.
 * @type {!Date}
 * @export
 */
API.Client.OrderRefundRequest.prototype.createdAt;

/**
 * Sipariş iptal talebi nesnesinin güncellenme zamanı.
 * @type {!Date}
 * @export
 */
API.Client.OrderRefundRequest.prototype.updatedAt;

/**
 * @type {!API.Client.Member}
 * @export
 */
API.Client.OrderRefundRequest.prototype.member;

/**
 * @type {!API.Client.Order}
 * @export
 */
API.Client.OrderRefundRequest.prototype.order;

/** @enum {string} */
API.Client.OrderRefundRequest.StatusEnum = { 
  approved: 'approved',
  waiting_for_approval: 'waiting_for_approval',
  cancelled: 'cancelled',
}
