goog.provide('API.Client.ProductPrice');

/**
 * @record
 */
API.Client.ProductPrice = function() {}

/**
 * Ürün fiyatı nesnesi kimlik değeri.
 * @type {!number}
 * @export
 */
API.Client.ProductPrice.prototype.id;

/**
 * Ürün fiyatı değeri.
 * @type {!number}
 * @export
 */
API.Client.ProductPrice.prototype.value;

/**
 * Ürün fiyatı indexi. Fiyat 2, Fiyat 3 gibi.
 * @type {!number}
 * @export
 */
API.Client.ProductPrice.prototype.type;

/**
 * Ürün nesnesi.
 * @type {!API.Client.Product}
 * @export
 */
API.Client.ProductPrice.prototype.product;

