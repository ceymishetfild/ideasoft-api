(ns idea-soft-api.api.product-button
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn product-buttons-get-with-http-info
  "Ürün ve Stok Butonu Listesi Alma
  Ürün ve Stok Butonu listesini verir."
  ([] (product-buttons-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids fast-shipping same-day-shipping three-days-delivery five-days-delivery seven-days-delivery free-shipping delivery-from-stock pre-ordered-product ask-stock campaigned-product product ]}]
   (call-api "/product_buttons" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "fastShipping" fast-shipping "sameDayShipping" same-day-shipping "threeDaysDelivery" three-days-delivery "fiveDaysDelivery" five-days-delivery "sevenDaysDelivery" seven-days-delivery "freeShipping" free-shipping "deliveryFromStock" delivery-from-stock "preOrderedProduct" pre-ordered-product "askStock" ask-stock "campaignedProduct" campaigned-product "product" product }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn product-buttons-get
  "Ürün ve Stok Butonu Listesi Alma
  Ürün ve Stok Butonu listesini verir."
  ([] (product-buttons-get nil))
  ([optional-params]
   (:data (product-buttons-get-with-http-info optional-params))))

(defn product-buttons-id-delete-with-http-info
  "Ürün ve Stok Butonu Silme
  Kalıcı olarak ilgili Ürün ve Stok Butonunu siler."
  [id ]
  (check-required-params id)
  (call-api "/product_buttons/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-buttons-id-delete
  "Ürün ve Stok Butonu Silme
  Kalıcı olarak ilgili Ürün ve Stok Butonunu siler."
  [id ]
  (:data (product-buttons-id-delete-with-http-info id)))

(defn product-buttons-id-get-with-http-info
  "Ürün ve Stok Butonu Alma
  İlgili Ürün ve Stok Butonunu getirir."
  [id ]
  (check-required-params id)
  (call-api "/product_buttons/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-buttons-id-get
  "Ürün ve Stok Butonu Alma
  İlgili Ürün ve Stok Butonunu getirir."
  [id ]
  (:data (product-buttons-id-get-with-http-info id)))

(defn product-buttons-id-put-with-http-info
  "Ürün ve Stok Butonu Güncelleme
  İlgili Ürün ve Stok Butonunu günceller."
  [id product-button ]
  (check-required-params id product-button)
  (call-api "/product_buttons/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-button
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-buttons-id-put
  "Ürün ve Stok Butonu Güncelleme
  İlgili Ürün ve Stok Butonunu günceller."
  [id product-button ]
  (:data (product-buttons-id-put-with-http-info id product-button)))

(defn product-buttons-post-with-http-info
  "Ürün ve Stok Butonu Oluşturma
  Yeni bir Ürün ve Stok Butonu oluşturur."
  [product-button ]
  (check-required-params product-button)
  (call-api "/product_buttons" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-button
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-buttons-post
  "Ürün ve Stok Butonu Oluşturma
  Yeni bir Ürün ve Stok Butonu oluşturur."
  [product-button ]
  (:data (product-buttons-post-with-http-info product-button)))

