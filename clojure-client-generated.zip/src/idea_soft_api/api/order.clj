(ns idea-soft-api.api.order
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn orders-get-with-http-info
  "Sipariş Listesi Alma
  Sipariş listesini verir."
  ([] (orders-get-with-http-info nil))
  ([{:keys [sort limit page since-id transaction-id customer-email member status payment-status payment-type-name shipping-provider-code q start-date end-date start-updated-at end-updated-at ]}]
   (call-api "/orders" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "transactionId" transaction-id "customerEmail" customer-email "member" member "status" status "paymentStatus" payment-status "paymentTypeName" payment-type-name "shippingProviderCode" shipping-provider-code "q" (with-collection-format q :multi) "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn orders-get
  "Sipariş Listesi Alma
  Sipariş listesini verir."
  ([] (orders-get nil))
  ([optional-params]
   (:data (orders-get-with-http-info optional-params))))

(defn orders-id-delete-with-http-info
  "Sipariş Silme
  Kalıcı olarak ilgili Siparişi siler."
  [id ]
  (check-required-params id)
  (call-api "/orders/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn orders-id-delete
  "Sipariş Silme
  Kalıcı olarak ilgili Siparişi siler."
  [id ]
  (:data (orders-id-delete-with-http-info id)))

(defn orders-id-get-with-http-info
  "Sipariş Alma
  İlgili Siparişi getirir."
  [id ]
  (check-required-params id)
  (call-api "/orders/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn orders-id-get
  "Sipariş Alma
  İlgili Siparişi getirir."
  [id ]
  (:data (orders-id-get-with-http-info id)))

(defn orders-id-put-with-http-info
  "Sipariş Güncelleme
  İlgili Siparişi günceller."
  [id order ]
  (check-required-params id order)
  (call-api "/orders/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    order
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn orders-id-put
  "Sipariş Güncelleme
  İlgili Siparişi günceller."
  [id order ]
  (:data (orders-id-put-with-http-info id order)))

(defn orders-post-with-http-info
  "Sipariş Oluşturma
  Yeni bir Sipariş oluşturur."
  [order ]
  (check-required-params order)
  (call-api "/orders" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    order
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn orders-post
  "Sipariş Oluşturma
  Yeni bir Sipariş oluşturur."
  [order ]
  (:data (orders-post-with-http-info order)))

