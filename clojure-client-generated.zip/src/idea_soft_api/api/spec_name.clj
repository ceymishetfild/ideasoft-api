(ns idea-soft-api.api.spec-name
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn spec-names-get-with-http-info
  "Ürün Özelliği Listesi Alma
  Ürün Özelliği listesini verir."
  ([] (spec-names-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids name spec-group choice-type ]}]
   (call-api "/spec_names" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "name" name "specGroup" spec-group "choiceType" choice-type }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn spec-names-get
  "Ürün Özelliği Listesi Alma
  Ürün Özelliği listesini verir."
  ([] (spec-names-get nil))
  ([optional-params]
   (:data (spec-names-get-with-http-info optional-params))))

(defn spec-names-id-delete-with-http-info
  "Ürün Özelliği Silme
  Kalıcı olarak ilgili Ürün Özelliğini siler."
  [id ]
  (check-required-params id)
  (call-api "/spec_names/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-names-id-delete
  "Ürün Özelliği Silme
  Kalıcı olarak ilgili Ürün Özelliğini siler."
  [id ]
  (:data (spec-names-id-delete-with-http-info id)))

(defn spec-names-id-get-with-http-info
  "Ürün Özelliği Alma
  İlgili Ürün Özelliğini getirir."
  [id ]
  (check-required-params id)
  (call-api "/spec_names/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-names-id-get
  "Ürün Özelliği Alma
  İlgili Ürün Özelliğini getirir."
  [id ]
  (:data (spec-names-id-get-with-http-info id)))

(defn spec-names-id-put-with-http-info
  "Ürün Özelliği Güncelleme
  İlgili Ürün Özelliğini günceller."
  [id spec-name ]
  (check-required-params id spec-name)
  (call-api "/spec_names/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    spec-name
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-names-id-put
  "Ürün Özelliği Güncelleme
  İlgili Ürün Özelliğini günceller."
  [id spec-name ]
  (:data (spec-names-id-put-with-http-info id spec-name)))

(defn spec-names-post-with-http-info
  "Ürün Özelliği Oluşturma
  Yeni bir Ürün Özelliği oluşturur."
  [spec-name ]
  (check-required-params spec-name)
  (call-api "/spec_names" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    spec-name
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-names-post
  "Ürün Özelliği Oluşturma
  Yeni bir Ürün Özelliği oluşturur."
  [spec-name ]
  (:data (spec-names-post-with-http-info spec-name)))

