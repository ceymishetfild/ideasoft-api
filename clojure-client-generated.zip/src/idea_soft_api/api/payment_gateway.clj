(ns idea-soft-api.api.payment-gateway
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn payment-gateways-get-with-http-info
  "Ödeme Kanalı Listesi Alma
  Ödeme Kanalı listesini verir."
  ([] (payment-gateways-get-with-http-info nil))
  ([{:keys [sort limit page since-id code name ]}]
   (call-api "/payment_gateways" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "code" code "name" name }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn payment-gateways-get
  "Ödeme Kanalı Listesi Alma
  Ödeme Kanalı listesini verir."
  ([] (payment-gateways-get nil))
  ([optional-params]
   (:data (payment-gateways-get-with-http-info optional-params))))

(defn payment-gateways-id-get-with-http-info
  "Ödeme Kanalı Alma
  İlgili Ödeme Kanalını getirir."
  [id ]
  (check-required-params id)
  (call-api "/payment_gateways/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn payment-gateways-id-get
  "Ödeme Kanalı Alma
  İlgili Ödeme Kanalını getirir."
  [id ]
  (:data (payment-gateways-id-get-with-http-info id)))

