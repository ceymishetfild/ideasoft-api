(ns idea-soft-api.api.shop-preference
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn preferences-get-with-http-info
  "Tanımlamalar Listesi Alma
  Tanımlamalar listesini verir."
  ([] (preferences-get-with-http-info nil))
  ([{:keys [sort limit page since-id var-key ]}]
   (call-api "/preferences" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "varKey" var-key }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn preferences-get
  "Tanımlamalar Listesi Alma
  Tanımlamalar listesini verir."
  ([] (preferences-get nil))
  ([optional-params]
   (:data (preferences-get-with-http-info optional-params))))

(defn preferences-id-get-with-http-info
  "Tanımlamalar Alma
  İlgili Tanımlamayı getirir."
  [id ]
  (check-required-params id)
  (call-api "/preferences/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn preferences-id-get
  "Tanımlamalar Alma
  İlgili Tanımlamayı getirir."
  [id ]
  (:data (preferences-id-get-with-http-info id)))

(defn preferences-id-put-with-http-info
  "Tanımlamalar Güncelleme
  İlgili Tanımlamayı günceller."
  [id shop-preference ]
  (check-required-params id shop-preference)
  (call-api "/preferences/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    shop-preference
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn preferences-id-put
  "Tanımlamalar Güncelleme
  İlgili Tanımlamayı günceller."
  [id shop-preference ]
  (:data (preferences-id-put-with-http-info id shop-preference)))

