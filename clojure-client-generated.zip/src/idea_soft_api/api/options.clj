(ns idea-soft-api.api.options
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn options-get-with-http-info
  "Varyant Listesi Alma
  Varyant listesini verir."
  ([] (options-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids title option-group ]}]
   (call-api "/options" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "title" title "optionGroup" option-group }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn options-get
  "Varyant Listesi Alma
  Varyant listesini verir."
  ([] (options-get nil))
  ([optional-params]
   (:data (options-get-with-http-info optional-params))))

(defn options-id-delete-with-http-info
  "Varyant Silme
  Kalıcı olarak ilgili Varyantı siler."
  [id ]
  (check-required-params id)
  (call-api "/options/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn options-id-delete
  "Varyant Silme
  Kalıcı olarak ilgili Varyantı siler."
  [id ]
  (:data (options-id-delete-with-http-info id)))

(defn options-id-get-with-http-info
  "Varyant Alma
  İlgili Varyantı getirir."
  [id ]
  (check-required-params id)
  (call-api "/options/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn options-id-get
  "Varyant Alma
  İlgili Varyantı getirir."
  [id ]
  (:data (options-id-get-with-http-info id)))

(defn options-id-put-with-http-info
  "Varyant Güncelleme
  İlgili Varyantı günceller."
  [id options ]
  (check-required-params id options)
  (call-api "/options/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    options
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn options-id-put
  "Varyant Güncelleme
  İlgili Varyantı günceller."
  [id options ]
  (:data (options-id-put-with-http-info id options)))

(defn options-post-with-http-info
  "Varyant Oluşturma
  Yeni bir Varyant oluşturur."
  [options ]
  (check-required-params options)
  (call-api "/options" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    options
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn options-post
  "Varyant Oluşturma
  Yeni bir Varyant oluşturur."
  [options ]
  (:data (options-post-with-http-info options)))

