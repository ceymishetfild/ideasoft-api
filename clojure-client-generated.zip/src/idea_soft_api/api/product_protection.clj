(ns idea-soft-api.api.product-protection
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn product-protections-get-with-http-info
  "Entegrasyon Seçeneği Listesi Alma
  Entegrasyon Seçeneği listesini verir."
  ([] (product-protections-get-with-http-info nil))
  ([{:keys [sort limit page since-id is-price-protected is-stock-protected product ]}]
   (call-api "/product_protections" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "isPriceProtected" is-price-protected "isStockProtected" is-stock-protected "product" product }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn product-protections-get
  "Entegrasyon Seçeneği Listesi Alma
  Entegrasyon Seçeneği listesini verir."
  ([] (product-protections-get nil))
  ([optional-params]
   (:data (product-protections-get-with-http-info optional-params))))

(defn product-protections-id-delete-with-http-info
  "Entegrasyon Seçeneği Silme
  Kalıcı olarak ilgili Entegrasyon Seçeneğini siler."
  [id ]
  (check-required-params id)
  (call-api "/product_protections/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-protections-id-delete
  "Entegrasyon Seçeneği Silme
  Kalıcı olarak ilgili Entegrasyon Seçeneğini siler."
  [id ]
  (:data (product-protections-id-delete-with-http-info id)))

(defn product-protections-id-get-with-http-info
  "Entegrasyon Seçeneği Alma
  İlgili Entegrasyon Seçeneğini getirir."
  [id ]
  (check-required-params id)
  (call-api "/product_protections/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-protections-id-get
  "Entegrasyon Seçeneği Alma
  İlgili Entegrasyon Seçeneğini getirir."
  [id ]
  (:data (product-protections-id-get-with-http-info id)))

(defn product-protections-id-put-with-http-info
  "Entegrasyon Seçeneği Güncelleme
  İlgili Entegrasyon Seçeneğini günceller."
  [id product-protection ]
  (check-required-params id product-protection)
  (call-api "/product_protections/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-protection
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-protections-id-put
  "Entegrasyon Seçeneği Güncelleme
  İlgili Entegrasyon Seçeneğini günceller."
  [id product-protection ]
  (:data (product-protections-id-put-with-http-info id product-protection)))

(defn product-protections-post-with-http-info
  "Entegrasyon Seçeneği Oluşturma
  Yeni bir Entegrasyon Seçeneği oluşturur."
  [product-protection ]
  (check-required-params product-protection)
  (call-api "/product_protections" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-protection
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-protections-post
  "Entegrasyon Seçeneği Oluşturma
  Yeni bir Entegrasyon Seçeneği oluşturur."
  [product-protection ]
  (:data (product-protections-post-with-http-info product-protection)))

