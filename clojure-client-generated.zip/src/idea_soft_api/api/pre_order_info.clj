(ns idea-soft-api.api.pre-order-info
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn pre-order-infos-get-with-http-info
  "Sipariş Öncesi Bilgisi Listesi Alma
  Sipariş Öncesi Bilgisi listesini verir."
  ([] (pre-order-infos-get-with-http-info nil))
  ([{:keys [sort limit page since-id session-id start-date end-date start-updated-at end-updated-at ]}]
   (call-api "/pre_order_infos" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "sessionId" session-id "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn pre-order-infos-get
  "Sipariş Öncesi Bilgisi Listesi Alma
  Sipariş Öncesi Bilgisi listesini verir."
  ([] (pre-order-infos-get nil))
  ([optional-params]
   (:data (pre-order-infos-get-with-http-info optional-params))))

(defn pre-order-infos-id-delete-with-http-info
  "Sipariş Öncesi Bilgisi Silme
  Kalıcı olarak ilgili Sipariş Öncesi Bilgisini siler."
  [id ]
  (check-required-params id)
  (call-api "/pre_order_infos/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn pre-order-infos-id-delete
  "Sipariş Öncesi Bilgisi Silme
  Kalıcı olarak ilgili Sipariş Öncesi Bilgisini siler."
  [id ]
  (:data (pre-order-infos-id-delete-with-http-info id)))

(defn pre-order-infos-id-get-with-http-info
  "Sipariş Öncesi Bilgisi Alma
  İlgili Sipariş Öncesi Bilgisini getirir."
  [id ]
  (check-required-params id)
  (call-api "/pre_order_infos/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn pre-order-infos-id-get
  "Sipariş Öncesi Bilgisi Alma
  İlgili Sipariş Öncesi Bilgisini getirir."
  [id ]
  (:data (pre-order-infos-id-get-with-http-info id)))

(defn pre-order-infos-id-put-with-http-info
  "Sipariş Öncesi Bilgisi Güncelleme
  İlgili Sipariş Öncesi Bilgisini günceller."
  [id pre-order-info ]
  (check-required-params id pre-order-info)
  (call-api "/pre_order_infos/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    pre-order-info
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn pre-order-infos-id-put
  "Sipariş Öncesi Bilgisi Güncelleme
  İlgili Sipariş Öncesi Bilgisini günceller."
  [id pre-order-info ]
  (:data (pre-order-infos-id-put-with-http-info id pre-order-info)))

(defn pre-order-infos-post-with-http-info
  "Sipariş Öncesi Bilgisi Oluşturma
  Yeni bir Sipariş Öncesi Bilgisi oluşturur."
  [pre-order-info ]
  (check-required-params pre-order-info)
  (call-api "/pre_order_infos" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    pre-order-info
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn pre-order-infos-post
  "Sipariş Öncesi Bilgisi Oluşturma
  Yeni bir Sipariş Öncesi Bilgisi oluşturur."
  [pre-order-info ]
  (:data (pre-order-infos-post-with-http-info pre-order-info)))

