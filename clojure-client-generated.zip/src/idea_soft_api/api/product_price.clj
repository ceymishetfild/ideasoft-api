(ns idea-soft-api.api.product-price
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn product-prices-get-with-http-info
  "Ürün Fiyat Listesi Alma
  Ürün Fiyat listesini verir."
  ([] (product-prices-get-with-http-info nil))
  ([{:keys [sort limit page since-id type product ]}]
   (call-api "/product_prices" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "type" type "product" product }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn product-prices-get
  "Ürün Fiyat Listesi Alma
  Ürün Fiyat listesini verir."
  ([] (product-prices-get nil))
  ([optional-params]
   (:data (product-prices-get-with-http-info optional-params))))

(defn product-prices-id-delete-with-http-info
  "Ürün Fiyat Silme
  Kalıcı olarak ilgili Ürün Fiyatını siler."
  [id ]
  (check-required-params id)
  (call-api "/product_prices/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-prices-id-delete
  "Ürün Fiyat Silme
  Kalıcı olarak ilgili Ürün Fiyatını siler."
  [id ]
  (:data (product-prices-id-delete-with-http-info id)))

(defn product-prices-id-get-with-http-info
  "Ürün Fiyat Alma
  İlgili Ürün Fiyatını getirir."
  [id ]
  (check-required-params id)
  (call-api "/product_prices/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-prices-id-get
  "Ürün Fiyat Alma
  İlgili Ürün Fiyatını getirir."
  [id ]
  (:data (product-prices-id-get-with-http-info id)))

(defn product-prices-id-put-with-http-info
  "Ürün Fiyat Güncelleme
  İlgili Ürün Fiyatını günceller."
  [id product-price ]
  (check-required-params id product-price)
  (call-api "/product_prices/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-price
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-prices-id-put
  "Ürün Fiyat Güncelleme
  İlgili Ürün Fiyatını günceller."
  [id product-price ]
  (:data (product-prices-id-put-with-http-info id product-price)))

(defn product-prices-post-with-http-info
  "Ürün Fiyat Oluşturma
  Yeni bir Ürün Fiyat oluşturur."
  [product-price ]
  (check-required-params product-price)
  (call-api "/product_prices" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-price
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-prices-post
  "Ürün Fiyat Oluşturma
  Yeni bir Ürün Fiyat oluşturur."
  [product-price ]
  (:data (product-prices-post-with-http-info product-price)))

