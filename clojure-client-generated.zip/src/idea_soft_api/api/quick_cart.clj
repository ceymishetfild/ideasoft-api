(ns idea-soft-api.api.quick-cart
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn quick-carts-get-with-http-info
  "Hızlı Satın Al Bağlantısı Alma
  Hızlı Satın Al Bağlantısı döndürür."
  ([] (quick-carts-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids name ]}]
   (call-api "/quick_carts" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "name" name }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn quick-carts-get
  "Hızlı Satın Al Bağlantısı Alma
  Hızlı Satın Al Bağlantısı döndürür."
  ([] (quick-carts-get nil))
  ([optional-params]
   (:data (quick-carts-get-with-http-info optional-params))))

(defn quick-carts-id-delete-with-http-info
  "Hızlı Satın Al Bağlantısı Silme
  Kalıcı olarak ilgili Hızlı Satın Al Bağlantısını siler."
  [id ]
  (check-required-params id)
  (call-api "/quick_carts/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn quick-carts-id-delete
  "Hızlı Satın Al Bağlantısı Silme
  Kalıcı olarak ilgili Hızlı Satın Al Bağlantısını siler."
  [id ]
  (:data (quick-carts-id-delete-with-http-info id)))

(defn quick-carts-id-get-with-http-info
  "Hızlı Satın Al Bağlantısı Alma
  İlgili Hızlı Satın Al Bağlantısını getirir."
  [id ]
  (check-required-params id)
  (call-api "/quick_carts/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn quick-carts-id-get
  "Hızlı Satın Al Bağlantısı Alma
  İlgili Hızlı Satın Al Bağlantısını getirir."
  [id ]
  (:data (quick-carts-id-get-with-http-info id)))

(defn quick-carts-id-put-with-http-info
  "Hızlı Satın Al Bağlantısı Güncelleme
  İlgili Hızlı Satın Al Bağlantısını günceller."
  [id quick-cart ]
  (check-required-params id quick-cart)
  (call-api "/quick_carts/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    quick-cart
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn quick-carts-id-put
  "Hızlı Satın Al Bağlantısı Güncelleme
  İlgili Hızlı Satın Al Bağlantısını günceller."
  [id quick-cart ]
  (:data (quick-carts-id-put-with-http-info id quick-cart)))

(defn quick-carts-post-with-http-info
  "Hızlı Satın Al Bağlantısı Oluşturma
  Yeni bir Hızlı Satın Al Bağlantısı oluşturur."
  [quick-cart ]
  (check-required-params quick-cart)
  (call-api "/quick_carts" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    quick-cart
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn quick-carts-post
  "Hızlı Satın Al Bağlantısı Oluşturma
  Yeni bir Hızlı Satın Al Bağlantısı oluşturur."
  [quick-cart ]
  (:data (quick-carts-post-with-http-info quick-cart)))

