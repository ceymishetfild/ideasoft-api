(ns idea-soft-api.api.location
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn locations-get-with-http-info
  "Şehir Listesi Alma
  Şehir listesini verir."
  ([] (locations-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids name country region ]}]
   (call-api "/locations" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "name" name "country" country "region" region }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn locations-get
  "Şehir Listesi Alma
  Şehir listesini verir."
  ([] (locations-get nil))
  ([optional-params]
   (:data (locations-get-with-http-info optional-params))))

(defn locations-id-get-with-http-info
  "Şehir Alma
  İlgili Şehir getirir."
  [id ]
  (check-required-params id)
  (call-api "/locations/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn locations-id-get
  "Şehir Alma
  İlgili Şehir getirir."
  [id ]
  (:data (locations-id-get-with-http-info id)))

