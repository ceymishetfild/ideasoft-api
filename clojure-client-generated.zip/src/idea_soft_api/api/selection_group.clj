(ns idea-soft-api.api.selection-group
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn selection-groups-get-with-http-info
  "Ek Özellik Grubu Listesi Alma
  Ek Özellik Grubu listesini verir."
  ([] (selection-groups-get-with-http-info nil))
  ([{:keys [sort limit page since-id title ]}]
   (call-api "/selection_groups" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "title" title }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn selection-groups-get
  "Ek Özellik Grubu Listesi Alma
  Ek Özellik Grubu listesini verir."
  ([] (selection-groups-get nil))
  ([optional-params]
   (:data (selection-groups-get-with-http-info optional-params))))

(defn selection-groups-id-delete-with-http-info
  "Ek Özellik Grubu Silme
  Kalıcı olarak ilgili Ek Özellik Grubunu siler."
  [id ]
  (check-required-params id)
  (call-api "/selection_groups/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn selection-groups-id-delete
  "Ek Özellik Grubu Silme
  Kalıcı olarak ilgili Ek Özellik Grubunu siler."
  [id ]
  (:data (selection-groups-id-delete-with-http-info id)))

(defn selection-groups-id-get-with-http-info
  "Ek Özellik Grubu Alma
  İlgili Ek Özellik Grubunu getirir."
  [id ]
  (check-required-params id)
  (call-api "/selection_groups/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn selection-groups-id-get
  "Ek Özellik Grubu Alma
  İlgili Ek Özellik Grubunu getirir."
  [id ]
  (:data (selection-groups-id-get-with-http-info id)))

(defn selection-groups-id-put-with-http-info
  "Ek Özellik Grubu Güncelleme
  İlgili Ek Özellik Grubunu günceller."
  [id selection-group ]
  (check-required-params id selection-group)
  (call-api "/selection_groups/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    selection-group
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn selection-groups-id-put
  "Ek Özellik Grubu Güncelleme
  İlgili Ek Özellik Grubunu günceller."
  [id selection-group ]
  (:data (selection-groups-id-put-with-http-info id selection-group)))

(defn selection-groups-post-with-http-info
  "Ek Özellik Grubu Oluşturma
  Yeni bir Ek Özellik Grubu oluşturur."
  [selection-group ]
  (check-required-params selection-group)
  (call-api "/selection_groups" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    selection-group
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn selection-groups-post
  "Ek Özellik Grubu Oluşturma
  Yeni bir Ek Özellik Grubu oluşturur."
  [selection-group ]
  (:data (selection-groups-post-with-http-info selection-group)))

