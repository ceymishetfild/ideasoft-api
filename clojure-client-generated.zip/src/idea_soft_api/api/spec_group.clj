(ns idea-soft-api.api.spec-group
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn spec-groups-get-with-http-info
  "Ürün Özellik Grubu Listesi Alma
  Ürün Özellik Grubu listesini verir."
  ([] (spec-groups-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids name ]}]
   (call-api "/spec_groups" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "name" name }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn spec-groups-get
  "Ürün Özellik Grubu Listesi Alma
  Ürün Özellik Grubu listesini verir."
  ([] (spec-groups-get nil))
  ([optional-params]
   (:data (spec-groups-get-with-http-info optional-params))))

(defn spec-groups-id-delete-with-http-info
  "Ürün Özellik Grubu Silme
  Kalıcı olarak ilgili Ürün Özellik Grubunu siler."
  [id ]
  (check-required-params id)
  (call-api "/spec_groups/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-groups-id-delete
  "Ürün Özellik Grubu Silme
  Kalıcı olarak ilgili Ürün Özellik Grubunu siler."
  [id ]
  (:data (spec-groups-id-delete-with-http-info id)))

(defn spec-groups-id-get-with-http-info
  "Ürün Özellik Grubu Alma
  İlgili Ürün Özellik Grubunu getirir."
  [id ]
  (check-required-params id)
  (call-api "/spec_groups/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-groups-id-get
  "Ürün Özellik Grubu Alma
  İlgili Ürün Özellik Grubunu getirir."
  [id ]
  (:data (spec-groups-id-get-with-http-info id)))

(defn spec-groups-id-put-with-http-info
  "Ürün Özellik Grubu Güncelleme
  İlgili Ürün Özellik Grubunu günceller."
  [id spec-group ]
  (check-required-params id spec-group)
  (call-api "/spec_groups/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    spec-group
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-groups-id-put
  "Ürün Özellik Grubu Güncelleme
  İlgili Ürün Özellik Grubunu günceller."
  [id spec-group ]
  (:data (spec-groups-id-put-with-http-info id spec-group)))

(defn spec-groups-post-with-http-info
  "Ürün Özellik Grubu Oluşturma
  Yeni bir Ürün Özellik Grubu oluşturur."
  [spec-group ]
  (check-required-params spec-group)
  (call-api "/spec_groups" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    spec-group
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-groups-post
  "Ürün Özellik Grubu Oluşturma
  Yeni bir Ürün Özellik Grubu oluşturur."
  [spec-group ]
  (:data (spec-groups-post-with-http-info spec-group)))

