(ns idea-soft-api.api.selection-to-product
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn selection-to-products-get-with-http-info
  "Ek Özellik Ürün Bağı Listesi Alma
  Ek Özellik Ürün Bağı listesini verir."
  ([] (selection-to-products-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids selection product ]}]
   (call-api "/selection_to_products" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "selection" selection "product" product }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn selection-to-products-get
  "Ek Özellik Ürün Bağı Listesi Alma
  Ek Özellik Ürün Bağı listesini verir."
  ([] (selection-to-products-get nil))
  ([optional-params]
   (:data (selection-to-products-get-with-http-info optional-params))))

(defn selection-to-products-id-delete-with-http-info
  "Ek Özellik Ürün Bağı Silme
  Kalıcı olarak ilgili Ek Özellik Ürün Bağını siler."
  [id ]
  (check-required-params id)
  (call-api "/selection_to_products/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn selection-to-products-id-delete
  "Ek Özellik Ürün Bağı Silme
  Kalıcı olarak ilgili Ek Özellik Ürün Bağını siler."
  [id ]
  (:data (selection-to-products-id-delete-with-http-info id)))

(defn selection-to-products-id-get-with-http-info
  "Ek Özellik Ürün Bağı Alma
  İlgili Ek Özellik Ürün Bağını getirir."
  [id ]
  (check-required-params id)
  (call-api "/selection_to_products/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn selection-to-products-id-get
  "Ek Özellik Ürün Bağı Alma
  İlgili Ek Özellik Ürün Bağını getirir."
  [id ]
  (:data (selection-to-products-id-get-with-http-info id)))

(defn selection-to-products-id-put-with-http-info
  "Ek Özellik Ürün Bağı Güncelleme
  İlgili Ek Özellik Ürün Bağını günceller."
  [id selection-to-product ]
  (check-required-params id selection-to-product)
  (call-api "/selection_to_products/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    selection-to-product
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn selection-to-products-id-put
  "Ek Özellik Ürün Bağı Güncelleme
  İlgili Ek Özellik Ürün Bağını günceller."
  [id selection-to-product ]
  (:data (selection-to-products-id-put-with-http-info id selection-to-product)))

(defn selection-to-products-post-with-http-info
  "Ek Özellik Ürün Bağı Oluşturma
  Yeni bir Ek Özellik Ürün Bağı oluşturur."
  [selection-to-product ]
  (check-required-params selection-to-product)
  (call-api "/selection_to_products" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    selection-to-product
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn selection-to-products-post
  "Ek Özellik Ürün Bağı Oluşturma
  Yeni bir Ek Özellik Ürün Bağı oluşturur."
  [selection-to-product ]
  (:data (selection-to-products-post-with-http-info selection-to-product)))

