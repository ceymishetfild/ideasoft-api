(ns idea-soft-api.api.shipping-address
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn shipping-addresses-get-with-http-info
  "Teslimat Adresi Listesi Alma
  Teslimat Adresi listesini verir."
  ([] (shipping-addresses-get-with-http-info nil))
  ([{:keys [sort limit page since-id order start-date end-date start-updated-at end-updated-at ]}]
   (call-api "/shipping_addresses" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "order" order "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn shipping-addresses-get
  "Teslimat Adresi Listesi Alma
  Teslimat Adresi listesini verir."
  ([] (shipping-addresses-get nil))
  ([optional-params]
   (:data (shipping-addresses-get-with-http-info optional-params))))

(defn shipping-addresses-id-get-with-http-info
  "Teslimat Adresi Alma
  İlgili Teslimat Adresi getirir."
  [id ]
  (check-required-params id)
  (call-api "/shipping_addresses/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipping-addresses-id-get
  "Teslimat Adresi Alma
  İlgili Teslimat Adresi getirir."
  [id ]
  (:data (shipping-addresses-id-get-with-http-info id)))

(defn shipping-addresses-id-put-with-http-info
  "Teslimat Adresi Güncelleme
  İlgili Teslimat Adresi günceller."
  [id shipping-address ]
  (check-required-params id shipping-address)
  (call-api "/shipping_addresses/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    shipping-address
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipping-addresses-id-put
  "Teslimat Adresi Güncelleme
  İlgili Teslimat Adresi günceller."
  [id shipping-address ]
  (:data (shipping-addresses-id-put-with-http-info id shipping-address)))

(defn shipping-addresses-post-with-http-info
  "Teslimat Adresi Oluşturma
  Yeni bir Teslimat Adresi oluşturur."
  [shipping-address ]
  (check-required-params shipping-address)
  (call-api "/shipping_addresses" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    shipping-address
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipping-addresses-post
  "Teslimat Adresi Oluşturma
  Yeni bir Teslimat Adresi oluşturur."
  [shipping-address ]
  (:data (shipping-addresses-post-with-http-info shipping-address)))

