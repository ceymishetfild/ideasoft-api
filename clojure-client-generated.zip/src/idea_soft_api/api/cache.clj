(ns idea-soft-api.api.cache
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn cache-delete-with-http-info
  "Önbellek Silme
  Kalıcı olarak Önbelleği siler."
  []
  (call-api "/cache" :delete
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn cache-delete
  "Önbellek Silme
  Kalıcı olarak Önbelleği siler."
  []
  (:data (cache-delete-with-http-info)))

