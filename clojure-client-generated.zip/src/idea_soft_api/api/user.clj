(ns idea-soft-api.api.user
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn users-get-with-http-info
  "Yönetici Listesi Alma
  Yönetici listesini verir."
  ([] (users-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids firstname surname email username phone-number is-owner status start-date end-date start-updated-at end-updated-at ]}]
   (call-api "/users" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "firstname" firstname "surname" surname "email" email "username" username "phoneNumber" phone-number "isOwner" is-owner "status" status "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn users-get
  "Yönetici Listesi Alma
  Yönetici listesini verir."
  ([] (users-get nil))
  ([optional-params]
   (:data (users-get-with-http-info optional-params))))

(defn users-id-get-with-http-info
  "Yönetici Alma
  İlgili Yöneticiyi  getirir."
  [id ]
  (check-required-params id)
  (call-api "/users/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn users-id-get
  "Yönetici Alma
  İlgili Yöneticiyi  getirir."
  [id ]
  (:data (users-id-get-with-http-info id)))

