(ns idea-soft-api.api.distributor-to-product
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn distributor-to-products-get-with-http-info
  "Distribütör Ürün Bağı Listesi Alma
  Distribütör Ürün Bağı listesini verir."
  ([] (distributor-to-products-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids distributor product ]}]
   (call-api "/distributor_to_products" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "distributor" distributor "product" product }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn distributor-to-products-get
  "Distribütör Ürün Bağı Listesi Alma
  Distribütör Ürün Bağı listesini verir."
  ([] (distributor-to-products-get nil))
  ([optional-params]
   (:data (distributor-to-products-get-with-http-info optional-params))))

(defn distributor-to-products-id-delete-with-http-info
  "Distribütör Ürün Bağı Silme
  Kalıcı olarak ilgili Distribütör Ürün Bağını siler"
  [id ]
  (check-required-params id)
  (call-api "/distributor_to_products/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn distributor-to-products-id-delete
  "Distribütör Ürün Bağı Silme
  Kalıcı olarak ilgili Distribütör Ürün Bağını siler"
  [id ]
  (:data (distributor-to-products-id-delete-with-http-info id)))

(defn distributor-to-products-id-get-with-http-info
  "Distribütör Ürün Bağı Alma
  İlgili Distribütör Ürün Bağını getirir."
  [id ]
  (check-required-params id)
  (call-api "/distributor_to_products/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn distributor-to-products-id-get
  "Distribütör Ürün Bağı Alma
  İlgili Distribütör Ürün Bağını getirir."
  [id ]
  (:data (distributor-to-products-id-get-with-http-info id)))

(defn distributor-to-products-id-put-with-http-info
  "Distribütör Ürün Bağı Güncelleme
  İlgili Distribütör Ürün Bağını günceller."
  [id distributor-to-product ]
  (check-required-params id distributor-to-product)
  (call-api "/distributor_to_products/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    distributor-to-product
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn distributor-to-products-id-put
  "Distribütör Ürün Bağı Güncelleme
  İlgili Distribütör Ürün Bağını günceller."
  [id distributor-to-product ]
  (:data (distributor-to-products-id-put-with-http-info id distributor-to-product)))

(defn distributor-to-products-post-with-http-info
  "Distribütör Ürün Bağı Oluşturma
  Yeni bir Distribütör Ürün Bağı oluşturur."
  [distributor-to-product ]
  (check-required-params distributor-to-product)
  (call-api "/distributor_to_products" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    distributor-to-product
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn distributor-to-products-post
  "Distribütör Ürün Bağı Oluşturma
  Yeni bir Distribütör Ürün Bağı oluşturur."
  [distributor-to-product ]
  (:data (distributor-to-products-post-with-http-info distributor-to-product)))

