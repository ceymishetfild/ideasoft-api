(ns idea-soft-api.api.region
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn regions-get-with-http-info
  "Bölge Listesi Alma
  Bölge listesini verir."
  ([] (regions-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids name ]}]
   (call-api "/regions" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "name" name }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn regions-get
  "Bölge Listesi Alma
  Bölge listesini verir."
  ([] (regions-get nil))
  ([optional-params]
   (:data (regions-get-with-http-info optional-params))))

(defn regions-id-get-with-http-info
  "Bölge Alma
  İlgili Bölgeyi getirir."
  [id ]
  (check-required-params id)
  (call-api "/regions/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn regions-id-get
  "Bölge Alma
  İlgili Bölgeyi getirir."
  [id ]
  (:data (regions-id-get-with-http-info id)))

