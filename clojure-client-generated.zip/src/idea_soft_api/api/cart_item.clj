(ns idea-soft-api.api.cart-item
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn cart-items-id-delete-with-http-info
  "Sepet Kalemi Silme
  Kalıcı olarak ilgili Sepet Kalemini siler."
  [id ]
  (check-required-params id)
  (call-api "/cart_items/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn cart-items-id-delete
  "Sepet Kalemi Silme
  Kalıcı olarak ilgili Sepet Kalemini siler."
  [id ]
  (:data (cart-items-id-delete-with-http-info id)))

(defn cart-items-id-put-with-http-info
  "Sepet Kalemi Güncelleme
  İlgili Sepet Kalemini günceller."
  [id ]
  (check-required-params id)
  (call-api "/cart_items/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn cart-items-id-put
  "Sepet Kalemi Güncelleme
  İlgili Sepet Kalemini günceller."
  [id ]
  (:data (cart-items-id-put-with-http-info id)))

(defn cart-items-post-with-http-info
  "Sepet Kalemi Oluşturma
  Yeni bir Sepet Kalemi oluşturur."
  [cart-item ]
  (check-required-params cart-item)
  (call-api "/cart_items" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    cart-item
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn cart-items-post
  "Sepet Kalemi Oluşturma
  Yeni bir Sepet Kalemi oluşturur."
  [cart-item ]
  (:data (cart-items-post-with-http-info cart-item)))

