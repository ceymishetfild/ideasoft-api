(ns idea-soft-api.api.option-to-product
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn option-to-products-get-with-http-info
  "Varyant Ürün Bağı Listesi Alma
  Varyant Ürün Bağı listesini verir."
  ([] (option-to-products-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids product option-group option parent-product-id ]}]
   (call-api "/option_to_products" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "product" product "optionGroup" option-group "option" option "parentProductId" parent-product-id }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn option-to-products-get
  "Varyant Ürün Bağı Listesi Alma
  Varyant Ürün Bağı listesini verir."
  ([] (option-to-products-get nil))
  ([optional-params]
   (:data (option-to-products-get-with-http-info optional-params))))

(defn option-to-products-id-delete-with-http-info
  "Varyant Ürün Bağı Silme
  Kalıcı olarak ilgili Varyant Ürün Bağını siler."
  [id ]
  (check-required-params id)
  (call-api "/option_to_products/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn option-to-products-id-delete
  "Varyant Ürün Bağı Silme
  Kalıcı olarak ilgili Varyant Ürün Bağını siler."
  [id ]
  (:data (option-to-products-id-delete-with-http-info id)))

(defn option-to-products-id-get-with-http-info
  "Varyant Ürün Bağı Alma
  İlgili Varyant Ürün Bağını getirir."
  [id ]
  (check-required-params id)
  (call-api "/option_to_products/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn option-to-products-id-get
  "Varyant Ürün Bağı Alma
  İlgili Varyant Ürün Bağını getirir."
  [id ]
  (:data (option-to-products-id-get-with-http-info id)))

(defn option-to-products-id-put-with-http-info
  "Varyant Ürün Bağı Güncelleme
  İlgili Varyant Ürün Bağını günceller."
  [id option-to-product ]
  (check-required-params id option-to-product)
  (call-api "/option_to_products/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    option-to-product
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn option-to-products-id-put
  "Varyant Ürün Bağı Güncelleme
  İlgili Varyant Ürün Bağını günceller."
  [id option-to-product ]
  (:data (option-to-products-id-put-with-http-info id option-to-product)))

(defn option-to-products-post-with-http-info
  "Varyant Ürün Bağı Oluşturma
  Yeni bir Varyant Ürün Bağı oluşturur."
  [option-to-product ]
  (check-required-params option-to-product)
  (call-api "/option_to_products" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    option-to-product
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn option-to-products-post
  "Varyant Ürün Bağı Oluşturma
  Yeni bir Varyant Ürün Bağı oluşturur."
  [option-to-product ]
  (:data (option-to-products-post-with-http-info option-to-product)))

