(ns idea-soft-api.api.product-image
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn product-images-get-with-http-info
  "Ürün Resim Listesi Alma
  Ürün Resim listesini verir."
  ([] (product-images-get-with-http-info nil))
  ([{:keys [sort limit page since-id file-name product ]}]
   (call-api "/product_images" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "fileName" file-name "product" product }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn product-images-get
  "Ürün Resim Listesi Alma
  Ürün Resim listesini verir."
  ([] (product-images-get nil))
  ([optional-params]
   (:data (product-images-get-with-http-info optional-params))))

(defn product-images-id-delete-with-http-info
  "Ürün Resim Silme
  Kalıcı olarak ilgili Ürün Resmini siler."
  [id ]
  (check-required-params id)
  (call-api "/product_images/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-images-id-delete
  "Ürün Resim Silme
  Kalıcı olarak ilgili Ürün Resmini siler."
  [id ]
  (:data (product-images-id-delete-with-http-info id)))

(defn product-images-id-get-with-http-info
  "Ürün Resim Alma
  İlgili Ürün Resmini getirir."
  [id ]
  (check-required-params id)
  (call-api "/product_images/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-images-id-get
  "Ürün Resim Alma
  İlgili Ürün Resmini getirir."
  [id ]
  (:data (product-images-id-get-with-http-info id)))

(defn product-images-post-with-http-info
  "Ürün Resim Oluşturma
  Yeni bir Ürün Resim oluşturur."
  [product-image ]
  (check-required-params product-image)
  (call-api "/product_images" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-image
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-images-post
  "Ürün Resim Oluşturma
  Yeni bir Ürün Resim oluşturur."
  [product-image ]
  (:data (product-images-post-with-http-info product-image)))

