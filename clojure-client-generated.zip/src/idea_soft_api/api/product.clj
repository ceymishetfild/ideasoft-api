(ns idea-soft-api.api.product
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn products-get-with-http-info
  "Ürün Listesi Alma
  Ürün listesini verir."
  ([] (products-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids ids2 parent brand sku name distributor q start-date end-date start-updated-at end-updated-at ]}]
   (call-api "/products" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "ids" ids2 "parent" parent "brand" brand "sku" sku "name" name "distributor" distributor "q" (with-collection-format q :multi) "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn products-get
  "Ürün Listesi Alma
  Ürün listesini verir."
  ([] (products-get nil))
  ([optional-params]
   (:data (products-get-with-http-info optional-params))))

(defn products-id-delete-with-http-info
  "Ürün Silme
  Kalıcı olarak ilgili Ürünü siler."
  [id ]
  (check-required-params id)
  (call-api "/products/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn products-id-delete
  "Ürün Silme
  Kalıcı olarak ilgili Ürünü siler."
  [id ]
  (:data (products-id-delete-with-http-info id)))

(defn products-id-get-with-http-info
  "Ürün Alma
  İlgili Ürünü getirir."
  [id ]
  (check-required-params id)
  (call-api "/products/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn products-id-get
  "Ürün Alma
  İlgili Ürünü getirir."
  [id ]
  (:data (products-id-get-with-http-info id)))

(defn products-id-put-with-http-info
  "Ürün Güncelleme
  İlgili Ürünü günceller."
  [id product ]
  (check-required-params id product)
  (call-api "/products/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn products-id-put
  "Ürün Güncelleme
  İlgili Ürünü günceller."
  [id product ]
  (:data (products-id-put-with-http-info id product)))

(defn products-post-with-http-info
  "Ürün Oluşturma
  Yeni bir Ürün oluşturur."
  [product ]
  (check-required-params product)
  (call-api "/products" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn products-post
  "Ürün Oluşturma
  Yeni bir Ürün oluşturur."
  [product ]
  (:data (products-post-with-http-info product)))

