(ns idea-soft-api.api.spec-value
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn spec-values-get-with-http-info
  "Ürün Özellik Değeri Listesi Alma
  Ürün Özellik Değeri listesini verir."
  ([] (spec-values-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids name spec-name spec-value ]}]
   (call-api "/spec_values" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "name" name "specName" spec-name "specValue" spec-value }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn spec-values-get
  "Ürün Özellik Değeri Listesi Alma
  Ürün Özellik Değeri listesini verir."
  ([] (spec-values-get nil))
  ([optional-params]
   (:data (spec-values-get-with-http-info optional-params))))

(defn spec-values-id-delete-with-http-info
  "Ürün Özellik Değeri Silme
  Kalıcı olarak ilgili Ürün Özellik Değerini siler."
  [id ]
  (check-required-params id)
  (call-api "/spec_values/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-values-id-delete
  "Ürün Özellik Değeri Silme
  Kalıcı olarak ilgili Ürün Özellik Değerini siler."
  [id ]
  (:data (spec-values-id-delete-with-http-info id)))

(defn spec-values-id-get-with-http-info
  "Ürün Özellik Değeri Alma
  İlgili Ürün Özellik Değerini getirir."
  [id ]
  (check-required-params id)
  (call-api "/spec_values/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-values-id-get
  "Ürün Özellik Değeri Alma
  İlgili Ürün Özellik Değerini getirir."
  [id ]
  (:data (spec-values-id-get-with-http-info id)))

(defn spec-values-id-put-with-http-info
  "Ürün Özellik Değeri Güncelleme
  İlgili Ürün Özellik Değerini günceller."
  [id spec-value ]
  (check-required-params id spec-value)
  (call-api "/spec_values/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    spec-value
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-values-id-put
  "Ürün Özellik Değeri Güncelleme
  İlgili Ürün Özellik Değerini günceller."
  [id spec-value ]
  (:data (spec-values-id-put-with-http-info id spec-value)))

(defn spec-values-post-with-http-info
  "Ürün Özellik Değeri Oluşturma
  Yeni bir Ürün Özellik Değeri oluşturur."
  [spec-value ]
  (check-required-params spec-value)
  (call-api "/spec_values" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    spec-value
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-values-post
  "Ürün Özellik Değeri Oluşturma
  Yeni bir Ürün Özellik Değeri oluşturur."
  [spec-value ]
  (:data (spec-values-post-with-http-info spec-value)))

