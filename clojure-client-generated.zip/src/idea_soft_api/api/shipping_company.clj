(ns idea-soft-api.api.shipping-company
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn shipping-companies-get-with-http-info
  "Kargo Firması Listesi Alma
  Kargo Firması listesini verir."
  ([] (shipping-companies-get-with-http-info nil))
  ([{:keys [sort limit page since-id name company-code payment-type shipping-provider ]}]
   (call-api "/shipping_companies" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "name" name "companyCode" company-code "paymentType" payment-type "shippingProvider" shipping-provider }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn shipping-companies-get
  "Kargo Firması Listesi Alma
  Kargo Firması listesini verir."
  ([] (shipping-companies-get nil))
  ([optional-params]
   (:data (shipping-companies-get-with-http-info optional-params))))

(defn shipping-companies-id-delete-with-http-info
  "Kargo Firması Silme
  Kalıcı olarak ilgili Kargo Firmasını siler."
  [id ]
  (check-required-params id)
  (call-api "/shipping_companies/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipping-companies-id-delete
  "Kargo Firması Silme
  Kalıcı olarak ilgili Kargo Firmasını siler."
  [id ]
  (:data (shipping-companies-id-delete-with-http-info id)))

(defn shipping-companies-id-get-with-http-info
  "Kargo Firması Alma
  İlgili Kargo Firmasını getirir."
  [id ]
  (check-required-params id)
  (call-api "/shipping_companies/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipping-companies-id-get
  "Kargo Firması Alma
  İlgili Kargo Firmasını getirir."
  [id ]
  (:data (shipping-companies-id-get-with-http-info id)))

(defn shipping-companies-id-put-with-http-info
  "Kargo Firması Güncelleme
  İlgili Kargo Firmasını günceller."
  [id shipping-company ]
  (check-required-params id shipping-company)
  (call-api "/shipping_companies/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    shipping-company
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipping-companies-id-put
  "Kargo Firması Güncelleme
  İlgili Kargo Firmasını günceller."
  [id shipping-company ]
  (:data (shipping-companies-id-put-with-http-info id shipping-company)))

(defn shipping-companies-post-with-http-info
  "Kargo Firması Oluşturma
  Yeni bir Kargo Firması oluşturur relationship."
  [shipping-company ]
  (check-required-params shipping-company)
  (call-api "/shipping_companies" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    shipping-company
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipping-companies-post
  "Kargo Firması Oluşturma
  Yeni bir Kargo Firması oluşturur relationship."
  [shipping-company ]
  (:data (shipping-companies-post-with-http-info shipping-company)))

