(ns idea-soft-api.api.product-to-category
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn product-to-categories-get-with-http-info
  "Ürün Kategori Bağı Listesi Alma
  Ürün Kategori Bağı listesini verir."
  ([] (product-to-categories-get-with-http-info nil))
  ([{:keys [sort limit page since-id product category ]}]
   (call-api "/product_to_categories" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "product" product "category" category }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn product-to-categories-get
  "Ürün Kategori Bağı Listesi Alma
  Ürün Kategori Bağı listesini verir."
  ([] (product-to-categories-get nil))
  ([optional-params]
   (:data (product-to-categories-get-with-http-info optional-params))))

(defn product-to-categories-id-delete-with-http-info
  "Ürün Kategori Bağı Silme
  Kalıcı olarak ilgili Ürün Kategori Bağını siler."
  [id ]
  (check-required-params id)
  (call-api "/product_to_categories/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-to-categories-id-delete
  "Ürün Kategori Bağı Silme
  Kalıcı olarak ilgili Ürün Kategori Bağını siler."
  [id ]
  (:data (product-to-categories-id-delete-with-http-info id)))

(defn product-to-categories-id-get-with-http-info
  "Ürün Kategori Bağı Alma
  İlgili Ürün Kategori Bağını getirir."
  [id ]
  (check-required-params id)
  (call-api "/product_to_categories/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-to-categories-id-get
  "Ürün Kategori Bağı Alma
  İlgili Ürün Kategori Bağını getirir."
  [id ]
  (:data (product-to-categories-id-get-with-http-info id)))

(defn product-to-categories-id-put-with-http-info
  "Ürün Kategori Bağı Güncelleme
  İlgili Ürün Kategori Bağını günceller."
  [id product-to-category ]
  (check-required-params id product-to-category)
  (call-api "/product_to_categories/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-to-category
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-to-categories-id-put
  "Ürün Kategori Bağı Güncelleme
  İlgili Ürün Kategori Bağını günceller."
  [id product-to-category ]
  (:data (product-to-categories-id-put-with-http-info id product-to-category)))

(defn product-to-categories-post-with-http-info
  "Ürün Kategori Bağı Oluşturma
  Yeni bir Ürün Kategori Bağı oluşturur."
  [product-to-category ]
  (check-required-params product-to-category)
  (call-api "/product_to_categories" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-to-category
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-to-categories-post
  "Ürün Kategori Bağı Oluşturma
  Yeni bir Ürün Kategori Bağı oluşturur."
  [product-to-category ]
  (:data (product-to-categories-post-with-http-info product-to-category)))

