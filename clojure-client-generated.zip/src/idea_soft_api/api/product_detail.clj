(ns idea-soft-api.api.product-detail
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn product-details-get-with-http-info
  "Ürün Detay Listesi Alma
  Ürün Detay listesini verir."
  ([] (product-details-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids sku ]}]
   (call-api "/product_details" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "sku" sku }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn product-details-get
  "Ürün Detay Listesi Alma
  Ürün Detay listesini verir."
  ([] (product-details-get nil))
  ([optional-params]
   (:data (product-details-get-with-http-info optional-params))))

(defn product-details-id-delete-with-http-info
  "Ürün Detay Silme
  Kalıcı olarak ilgili Ürün Detayını siler."
  [id ]
  (check-required-params id)
  (call-api "/product_details/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-details-id-delete
  "Ürün Detay Silme
  Kalıcı olarak ilgili Ürün Detayını siler."
  [id ]
  (:data (product-details-id-delete-with-http-info id)))

(defn product-details-id-get-with-http-info
  "Ürün Detay Alma
  İlgili Ürün Detayını getirir."
  [id ]
  (check-required-params id)
  (call-api "/product_details/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-details-id-get
  "Ürün Detay Alma
  İlgili Ürün Detayını getirir."
  [id ]
  (:data (product-details-id-get-with-http-info id)))

(defn product-details-id-put-with-http-info
  "Ürün Detay Güncelleme
  İlgili Ürün Detayını günceller."
  [id product-detail ]
  (check-required-params id product-detail)
  (call-api "/product_details/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-detail
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-details-id-put
  "Ürün Detay Güncelleme
  İlgili Ürün Detayını günceller."
  [id product-detail ]
  (:data (product-details-id-put-with-http-info id product-detail)))

(defn product-details-post-with-http-info
  "Ürün Detay Oluşturma
  Yeni bir Ürün Detay oluşturur."
  [product-detail ]
  (check-required-params product-detail)
  (call-api "/product_details" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-detail
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-details-post
  "Ürün Detay Oluşturma
  Yeni bir Ürün Detay oluşturur."
  [product-detail ]
  (:data (product-details-post-with-http-info product-detail)))

