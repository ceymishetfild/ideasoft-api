(ns idea-soft-api.api.spec-to-product
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn spec-to-products-get-with-http-info
  "Ürün Özellik Ürün Bağı Listesi Alma
  Ürün Özellik Ürün Bağı listesini verir."
  ([] (spec-to-products-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids product spec-group spec-name spec-value ]}]
   (call-api "/spec_to_products" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "product" product "specGroup" spec-group "specName" spec-name "specValue" spec-value }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn spec-to-products-get
  "Ürün Özellik Ürün Bağı Listesi Alma
  Ürün Özellik Ürün Bağı listesini verir."
  ([] (spec-to-products-get nil))
  ([optional-params]
   (:data (spec-to-products-get-with-http-info optional-params))))

(defn spec-to-products-id-delete-with-http-info
  "Ürün Özellik Ürün Bağı Silme
  Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler."
  [id ]
  (check-required-params id)
  (call-api "/spec_to_products/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-to-products-id-delete
  "Ürün Özellik Ürün Bağı Silme
  Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler."
  [id ]
  (:data (spec-to-products-id-delete-with-http-info id)))

(defn spec-to-products-id-get-with-http-info
  "Ürün Özellik Ürün Bağı Alma
  İlgili Ürün Özellik Ürün Bağını getirir."
  [id ]
  (check-required-params id)
  (call-api "/spec_to_products/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-to-products-id-get
  "Ürün Özellik Ürün Bağı Alma
  İlgili Ürün Özellik Ürün Bağını getirir."
  [id ]
  (:data (spec-to-products-id-get-with-http-info id)))

(defn spec-to-products-id-put-with-http-info
  "Ürün Özellik Ürün Bağı Güncelleme
  İlgili Ürün Özellik Ürün Bağını günceller."
  [id spec-to-product ]
  (check-required-params id spec-to-product)
  (call-api "/spec_to_products/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    spec-to-product
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-to-products-id-put
  "Ürün Özellik Ürün Bağı Güncelleme
  İlgili Ürün Özellik Ürün Bağını günceller."
  [id spec-to-product ]
  (:data (spec-to-products-id-put-with-http-info id spec-to-product)))

(defn spec-to-products-post-with-http-info
  "Ürün Özellik Ürün Bağı Oluşturma
  Yeni bir Ürün Özellik Ürün Bağı oluşturur."
  [spec-to-product ]
  (check-required-params spec-to-product)
  (call-api "/spec_to_products" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    spec-to-product
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn spec-to-products-post
  "Ürün Özellik Ürün Bağı Oluşturma
  Yeni bir Ürün Özellik Ürün Bağı oluşturur."
  [spec-to-product ]
  (:data (spec-to-products-post-with-http-info spec-to-product)))

