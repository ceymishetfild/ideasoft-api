(ns idea-soft-api.api.member-address
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn member-addresses-get-with-http-info
  "Üye Adresi Listeleme
  Üye Adresi listesi verir."
  ([] (member-addresses-get-with-http-info nil))
  ([{:keys [sort limit page since-id member start-date end-date ]}]
   (call-api "/member_addresses" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "member" member "startDate" start-date "endDate" end-date }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn member-addresses-get
  "Üye Adresi Listeleme
  Üye Adresi listesi verir."
  ([] (member-addresses-get nil))
  ([optional-params]
   (:data (member-addresses-get-with-http-info optional-params))))

(defn member-addresses-id-delete-with-http-info
  "Üye Adresi Silme
  Kalıcı olarak ilgili Üye Adresini siler."
  [id ]
  (check-required-params id)
  (call-api "/member_addresses/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn member-addresses-id-delete
  "Üye Adresi Silme
  Kalıcı olarak ilgili Üye Adresini siler."
  [id ]
  (:data (member-addresses-id-delete-with-http-info id)))

(defn member-addresses-id-get-with-http-info
  "Üye Adresi Alma
  İlgili Üye Adresini getirir."
  [id ]
  (check-required-params id)
  (call-api "/member_addresses/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn member-addresses-id-get
  "Üye Adresi Alma
  İlgili Üye Adresini getirir."
  [id ]
  (:data (member-addresses-id-get-with-http-info id)))

(defn member-addresses-id-put-with-http-info
  "Üye Adresi Güncelleme
  İlgili Üye Adresini günceller."
  [id member-address ]
  (check-required-params id member-address)
  (call-api "/member_addresses/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    member-address
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn member-addresses-id-put
  "Üye Adresi Güncelleme
  İlgili Üye Adresini günceller."
  [id member-address ]
  (:data (member-addresses-id-put-with-http-info id member-address)))

(defn member-addresses-post-with-http-info
  "Üye Adresi Oluşturma
  Yeni bir Üye Adresi oluşturur."
  [member-address ]
  (check-required-params member-address)
  (call-api "/member_addresses" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    member-address
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn member-addresses-post
  "Üye Adresi Oluşturma
  Yeni bir Üye Adresi oluşturur."
  [member-address ]
  (:data (member-addresses-post-with-http-info member-address)))

