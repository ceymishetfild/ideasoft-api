(ns idea-soft-api.api.product-to-tag
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn product-to-tags-get-with-http-info
  "Ürün SEO+ Bağı Listesi Alma
  Ürün SEO+ Bağı listesini verir."
  ([] (product-to-tags-get-with-http-info nil))
  ([{:keys [sort limit page since-id product tag ]}]
   (call-api "/product_to_tags" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "product" product "tag" tag }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn product-to-tags-get
  "Ürün SEO+ Bağı Listesi Alma
  Ürün SEO+ Bağı listesini verir."
  ([] (product-to-tags-get nil))
  ([optional-params]
   (:data (product-to-tags-get-with-http-info optional-params))))

(defn product-to-tags-id-delete-with-http-info
  "Ürün SEO+ Bağı Silme
  Kalıcı olarak ilgili Ürün SEO+ Bağını siler."
  [id ]
  (check-required-params id)
  (call-api "/product_to_tags/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-to-tags-id-delete
  "Ürün SEO+ Bağı Silme
  Kalıcı olarak ilgili Ürün SEO+ Bağını siler."
  [id ]
  (:data (product-to-tags-id-delete-with-http-info id)))

(defn product-to-tags-id-get-with-http-info
  "Ürün SEO+ Bağı Alma
  İlgili Ürün SEO+ Bağını getirir."
  [id ]
  (check-required-params id)
  (call-api "/product_to_tags/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-to-tags-id-get
  "Ürün SEO+ Bağı Alma
  İlgili Ürün SEO+ Bağını getirir."
  [id ]
  (:data (product-to-tags-id-get-with-http-info id)))

(defn product-to-tags-id-put-with-http-info
  "Ürün SEO+ Bağı Güncelleme
  İlgili Ürün SEO+ Bağını günceller."
  [id product-to-tag ]
  (check-required-params id product-to-tag)
  (call-api "/product_to_tags/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-to-tag
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-to-tags-id-put
  "Ürün SEO+ Bağı Güncelleme
  İlgili Ürün SEO+ Bağını günceller."
  [id product-to-tag ]
  (:data (product-to-tags-id-put-with-http-info id product-to-tag)))

(defn product-to-tags-post-with-http-info
  "Ürün SEO+ Bağı Oluşturma
  Yeni bir Ürün SEO+ Bağı oluşturur."
  [product-to-tag ]
  (check-required-params product-to-tag)
  (call-api "/product_to_tags" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-to-tag
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-to-tags-post
  "Ürün SEO+ Bağı Oluşturma
  Yeni bir Ürün SEO+ Bağı oluşturur."
  [product-to-tag ]
  (:data (product-to-tags-post-with-http-info product-to-tag)))

