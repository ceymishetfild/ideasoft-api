(ns idea-soft-api.api.shipping-rate
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn shipping-rates-get-with-http-info
  "Kargo Oranı Listesi Alma
  Kargo Oranı listesini verir."
  ([] (shipping-rates-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids shipping-company region ]}]
   (call-api "/shipping_rates" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "shippingCompany" shipping-company "region" region }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn shipping-rates-get
  "Kargo Oranı Listesi Alma
  Kargo Oranı listesini verir."
  ([] (shipping-rates-get nil))
  ([optional-params]
   (:data (shipping-rates-get-with-http-info optional-params))))

(defn shipping-rates-id-delete-with-http-info
  "Kargo Oranı Silme
  Kalıcı olarak ilgili Kargo Oranını siler."
  [id ]
  (check-required-params id)
  (call-api "/shipping_rates/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipping-rates-id-delete
  "Kargo Oranı Silme
  Kalıcı olarak ilgili Kargo Oranını siler."
  [id ]
  (:data (shipping-rates-id-delete-with-http-info id)))

(defn shipping-rates-id-get-with-http-info
  "Kargo Oranı Alma
  İlgili Kargo Oranını getirir."
  [id ]
  (check-required-params id)
  (call-api "/shipping_rates/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipping-rates-id-get
  "Kargo Oranı Alma
  İlgili Kargo Oranını getirir."
  [id ]
  (:data (shipping-rates-id-get-with-http-info id)))

(defn shipping-rates-id-put-with-http-info
  "Kargo Oranı Güncelleme
  İlgili Kargo Oranını günceller."
  [id shipping-rate ]
  (check-required-params id shipping-rate)
  (call-api "/shipping_rates/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    shipping-rate
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipping-rates-id-put
  "Kargo Oranı Güncelleme
  İlgili Kargo Oranını günceller."
  [id shipping-rate ]
  (:data (shipping-rates-id-put-with-http-info id shipping-rate)))

(defn shipping-rates-post-with-http-info
  "Kargo Oranı Oluşturma
  Yeni bir Kargo Oranı oluşturur."
  [shipping-rate ]
  (check-required-params shipping-rate)
  (call-api "/shipping_rates" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    shipping-rate
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipping-rates-post
  "Kargo Oranı Oluşturma
  Yeni bir Kargo Oranı oluşturur."
  [shipping-rate ]
  (:data (shipping-rates-post-with-http-info shipping-rate)))

