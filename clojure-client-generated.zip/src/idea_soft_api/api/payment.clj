(ns idea-soft-api.api.payment
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn payments-get-with-http-info
  "Ödeme Listesi Alma
  Ödeme listesini verir."
  ([] (payments-get-with-http-info nil))
  ([{:keys [sort limit page since-id transaction-id member-email member status payment-type-name start-date end-date ]}]
   (call-api "/payments" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "transactionId" transaction-id "memberEmail" member-email "member" member "status" status "paymentTypeName" payment-type-name "startDate" start-date "endDate" end-date }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn payments-get
  "Ödeme Listesi Alma
  Ödeme listesini verir."
  ([] (payments-get nil))
  ([optional-params]
   (:data (payments-get-with-http-info optional-params))))

(defn payments-id-delete-with-http-info
  "Ödeme Silme
  Kalıcı olarak ilgili Ödemeyi siler."
  [id ]
  (check-required-params id)
  (call-api "/payments/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn payments-id-delete
  "Ödeme Silme
  Kalıcı olarak ilgili Ödemeyi siler."
  [id ]
  (:data (payments-id-delete-with-http-info id)))

(defn payments-id-get-with-http-info
  "Ödeme Alma
  İlgili Ödemeyi getirir."
  [id ]
  (check-required-params id)
  (call-api "/payments/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn payments-id-get
  "Ödeme Alma
  İlgili Ödemeyi getirir."
  [id ]
  (:data (payments-id-get-with-http-info id)))

(defn payments-id-put-with-http-info
  "Ödeme Güncelleme
  İlgili Ödemeyi günceller."
  [id payment ]
  (check-required-params id payment)
  (call-api "/payments/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    payment
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn payments-id-put
  "Ödeme Güncelleme
  İlgili Ödemeyi günceller."
  [id payment ]
  (:data (payments-id-put-with-http-info id payment)))

(defn payments-post-with-http-info
  "Ödeme Oluşturma
  Yeni bir Ödeme oluşturur."
  [payment ]
  (check-required-params payment)
  (call-api "/payments" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    payment
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn payments-post
  "Ödeme Oluşturma
  Yeni bir Ödeme oluşturur."
  [payment ]
  (:data (payments-post-with-http-info payment)))

