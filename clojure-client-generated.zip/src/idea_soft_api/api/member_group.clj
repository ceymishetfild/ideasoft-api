(ns idea-soft-api.api.member-group
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn member-groups-get-with-http-info
  "Üye Grubu Listesi Alma
  Üye Grubu listesini verir."
  ([] (member-groups-get-with-http-info nil))
  ([{:keys [sort limit page since-id name ]}]
   (call-api "/member_groups" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "name" name }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn member-groups-get
  "Üye Grubu Listesi Alma
  Üye Grubu listesini verir."
  ([] (member-groups-get nil))
  ([optional-params]
   (:data (member-groups-get-with-http-info optional-params))))

(defn member-groups-id-delete-with-http-info
  "Üye Grubu Silme
  Kalıcı olarak ilgili Üye Grubunu siler."
  [id ]
  (check-required-params id)
  (call-api "/member_groups/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn member-groups-id-delete
  "Üye Grubu Silme
  Kalıcı olarak ilgili Üye Grubunu siler."
  [id ]
  (:data (member-groups-id-delete-with-http-info id)))

(defn member-groups-id-get-with-http-info
  "Üye Grubu Alma
  İlgili Üye Grubunu getirir."
  [id ]
  (check-required-params id)
  (call-api "/member_groups/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn member-groups-id-get
  "Üye Grubu Alma
  İlgili Üye Grubunu getirir."
  [id ]
  (:data (member-groups-id-get-with-http-info id)))

(defn member-groups-id-put-with-http-info
  "Üye Grubu Güncelleme
  İlgili Üye Grubunu günceller."
  [id member-group ]
  (check-required-params id member-group)
  (call-api "/member_groups/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    member-group
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn member-groups-id-put
  "Üye Grubu Güncelleme
  İlgili Üye Grubunu günceller."
  [id member-group ]
  (:data (member-groups-id-put-with-http-info id member-group)))

(defn member-groups-post-with-http-info
  "Üye Grubu Oluşturma
  Yeni bir Üye Grubu oluşturur."
  [member-group ]
  (check-required-params member-group)
  (call-api "/member_groups" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    member-group
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn member-groups-post
  "Üye Grubu Oluşturma
  Yeni bir Üye Grubu oluşturur."
  [member-group ]
  (:data (member-groups-post-with-http-info member-group)))

