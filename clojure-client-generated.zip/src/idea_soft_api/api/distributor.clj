(ns idea-soft-api.api.distributor
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn distributors-get-with-http-info
  "Distribütör Listesi Alma
  Distribütör listesini verir."
  ([] (distributors-get-with-http-info nil))
  ([{:keys [sort limit page since-id name email phone contact-person ]}]
   (call-api "/distributors" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "name" name "email" email "phone" phone "contactPerson" contact-person }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn distributors-get
  "Distribütör Listesi Alma
  Distribütör listesini verir."
  ([] (distributors-get nil))
  ([optional-params]
   (:data (distributors-get-with-http-info optional-params))))

(defn distributors-id-delete-with-http-info
  "Distribütör Silme
  Kalıcı olarak ilgili Distribütörü siler."
  [id ]
  (check-required-params id)
  (call-api "/distributors/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn distributors-id-delete
  "Distribütör Silme
  Kalıcı olarak ilgili Distribütörü siler."
  [id ]
  (:data (distributors-id-delete-with-http-info id)))

(defn distributors-id-get-with-http-info
  "Distribütör Alma
  İlgili Distribütörü getirir."
  [id ]
  (check-required-params id)
  (call-api "/distributors/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn distributors-id-get
  "Distribütör Alma
  İlgili Distribütörü getirir."
  [id ]
  (:data (distributors-id-get-with-http-info id)))

(defn distributors-id-put-with-http-info
  "Distribütör Güncelleme
  İlgili Distribütörü günceller."
  [id distributor ]
  (check-required-params id distributor)
  (call-api "/distributors/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    distributor
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn distributors-id-put
  "Distribütör Güncelleme
  İlgili Distribütörü günceller."
  [id distributor ]
  (:data (distributors-id-put-with-http-info id distributor)))

(defn distributors-post-with-http-info
  "Distribütör Oluşturma
  Yeni bir Distribütör oluşturur."
  [distributor ]
  (check-required-params distributor)
  (call-api "/distributors" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    distributor
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn distributors-post
  "Distribütör Oluşturma
  Yeni bir Distribütör oluşturur."
  [distributor ]
  (:data (distributors-post-with-http-info distributor)))

