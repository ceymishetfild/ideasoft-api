(ns idea-soft-api.api.installment-rate
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn installment-rates-get-with-http-info
  "Taksit Oranı Listesi Alma
  Taksit Oranı listesini verir."
  ([] (installment-rates-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids payment-gateway ]}]
   (call-api "/installment_rates" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "paymentGateway" payment-gateway }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn installment-rates-get
  "Taksit Oranı Listesi Alma
  Taksit Oranı listesini verir."
  ([] (installment-rates-get nil))
  ([optional-params]
   (:data (installment-rates-get-with-http-info optional-params))))

(defn installment-rates-id-get-with-http-info
  "Taksit Oranı Alma
  İlgili Taksit Oranını getirir."
  [id ]
  (check-required-params id)
  (call-api "/installment_rates/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn installment-rates-id-get
  "Taksit Oranı Alma
  İlgili Taksit Oranını getirir."
  [id ]
  (:data (installment-rates-id-get-with-http-info id)))

