(ns idea-soft-api.api.shipping-provider
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn shipping-providers-get-with-http-info
  "Teslimat Hizmeti Sağlayıcısı Listesi Alma
  Teslimat Hizmeti Sağlayıcısı listesini verir."
  ([] (shipping-providers-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids code name ]}]
   (call-api "/shipping_providers" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "code" code "name" name }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn shipping-providers-get
  "Teslimat Hizmeti Sağlayıcısı Listesi Alma
  Teslimat Hizmeti Sağlayıcısı listesini verir."
  ([] (shipping-providers-get nil))
  ([optional-params]
   (:data (shipping-providers-get-with-http-info optional-params))))

(defn shipping-providers-id-get-with-http-info
  "Teslimat Hizmeti Sağlayıcısı Alma
  İlgili Teslimat Hizmeti Sağlayıcısını getirir."
  [id ]
  (check-required-params id)
  (call-api "/shipping_providers/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipping-providers-id-get
  "Teslimat Hizmeti Sağlayıcısı Alma
  İlgili Teslimat Hizmeti Sağlayıcısını getirir."
  [id ]
  (:data (shipping-providers-id-get-with-http-info id)))

