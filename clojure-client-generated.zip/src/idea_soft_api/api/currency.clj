(ns idea-soft-api.api.currency
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn currencies-get-with-http-info
  "Kur Listesi Alma
  Kur listesini verir."
  ([] (currencies-get-with-http-info nil))
  ([{:keys [sort limit page since-id label abbr status ]}]
   (call-api "/currencies" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "label" label "abbr" abbr "status" status }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn currencies-get
  "Kur Listesi Alma
  Kur listesini verir."
  ([] (currencies-get nil))
  ([optional-params]
   (:data (currencies-get-with-http-info optional-params))))

(defn currencies-id-get-with-http-info
  "Kur Alma
  İlgili Kur getirir."
  [id ]
  (check-required-params id)
  (call-api "/currencies/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn currencies-id-get
  "Kur Alma
  İlgili Kur getirir."
  [id ]
  (:data (currencies-id-get-with-http-info id)))

(defn currencies-id-put-with-http-info
  "Kur Güncelleme
  İlgili Kur günceller."
  [id currency ]
  (check-required-params id currency)
  (call-api "/currencies/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    currency
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn currencies-id-put
  "Kur Güncelleme
  İlgili Kur günceller."
  [id currency ]
  (:data (currencies-id-put-with-http-info id currency)))

