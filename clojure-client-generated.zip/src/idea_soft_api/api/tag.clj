(ns idea-soft-api.api.tag
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn tags-get-with-http-info
  "SEO+ Etiketi Listesi Alma
  SEO+ Etiketi listesini verir."
  ([] (tags-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids name ]}]
   (call-api "/tags" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "name" name }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn tags-get
  "SEO+ Etiketi Listesi Alma
  SEO+ Etiketi listesini verir."
  ([] (tags-get nil))
  ([optional-params]
   (:data (tags-get-with-http-info optional-params))))

(defn tags-id-delete-with-http-info
  "SEO+ Etiketi Silme
  Kalıcı olarak ilgili SEO+ Etiketini siler."
  [id ]
  (check-required-params id)
  (call-api "/tags/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn tags-id-delete
  "SEO+ Etiketi Silme
  Kalıcı olarak ilgili SEO+ Etiketini siler."
  [id ]
  (:data (tags-id-delete-with-http-info id)))

(defn tags-id-get-with-http-info
  "SEO+ Etiketi Alma
  İlgili SEO+ Etiketini getirir."
  [id ]
  (check-required-params id)
  (call-api "/tags/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn tags-id-get
  "SEO+ Etiketi Alma
  İlgili SEO+ Etiketini getirir."
  [id ]
  (:data (tags-id-get-with-http-info id)))

(defn tags-id-put-with-http-info
  "SEO+ Etiketi Güncelleme
  İlgili SEO+ Etiketini günceller."
  [id tag ]
  (check-required-params id tag)
  (call-api "/tags/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    tag
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn tags-id-put
  "SEO+ Etiketi Güncelleme
  İlgili SEO+ Etiketini günceller."
  [id tag ]
  (:data (tags-id-put-with-http-info id tag)))

(defn tags-post-with-http-info
  "SEO+ Etiketi Oluşturma
  Yeni bir SEO+ Etiketi oluşturur."
  [tag ]
  (check-required-params tag)
  (call-api "/tags" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    tag
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn tags-post
  "SEO+ Etiketi Oluşturma
  Yeni bir SEO+ Etiketi oluşturur."
  [tag ]
  (:data (tags-post-with-http-info tag)))

