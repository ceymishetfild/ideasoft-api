(ns idea-soft-api.api.brand
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn brands-get-with-http-info
  "Marka Listesi Alma
  Marka listesini verir."
  ([] (brands-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids name status distributor start-date end-date start-updated-at end-updated-at q ]}]
   (call-api "/brands" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "name" name "status" status "distributor" distributor "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at "q" (with-collection-format q :multi) }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn brands-get
  "Marka Listesi Alma
  Marka listesini verir."
  ([] (brands-get nil))
  ([optional-params]
   (:data (brands-get-with-http-info optional-params))))

(defn brands-id-delete-with-http-info
  "Marka Silme
  Kalıcı olarak ilgili Markayı siler."
  [id ]
  (check-required-params id)
  (call-api "/brands/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn brands-id-delete
  "Marka Silme
  Kalıcı olarak ilgili Markayı siler."
  [id ]
  (:data (brands-id-delete-with-http-info id)))

(defn brands-id-get-with-http-info
  "Marka Alma
  İlgili Markayı getirir."
  [id ]
  (check-required-params id)
  (call-api "/brands/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn brands-id-get
  "Marka Alma
  İlgili Markayı getirir."
  [id ]
  (:data (brands-id-get-with-http-info id)))

(defn brands-id-put-with-http-info
  "Marka Güncelleme
  İlgili Markayı günceller."
  [id brand ]
  (check-required-params id brand)
  (call-api "/brands/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    brand
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn brands-id-put
  "Marka Güncelleme
  İlgili Markayı günceller."
  [id brand ]
  (:data (brands-id-put-with-http-info id brand)))

(defn brands-post-with-http-info
  "Marka Oluşturma
  Yeni bir Marka oluşturur."
  [brand ]
  (check-required-params brand)
  (call-api "/brands" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    brand
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn brands-post
  "Marka Oluşturma
  Yeni bir Marka oluşturur."
  [brand ]
  (:data (brands-post-with-http-info brand)))

