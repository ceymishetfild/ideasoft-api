(ns idea-soft-api.api.product-special-info
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn product-special-infos-get-with-http-info
  "Ürün Özel Bilgi Alanı Listesi Alma
  Ürün Özel Bilgi Alanı listesini verir."
  ([] (product-special-infos-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids title status product ]}]
   (call-api "/product_special_infos" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "title" title "status" status "product" product }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn product-special-infos-get
  "Ürün Özel Bilgi Alanı Listesi Alma
  Ürün Özel Bilgi Alanı listesini verir."
  ([] (product-special-infos-get nil))
  ([optional-params]
   (:data (product-special-infos-get-with-http-info optional-params))))

(defn product-special-infos-id-delete-with-http-info
  "Ürün Özel Bilgi Alanı
  Kalıcı olarak ilgili Ürün Özel Bilgi Alanını siler."
  [id ]
  (check-required-params id)
  (call-api "/product_special_infos/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-special-infos-id-delete
  "Ürün Özel Bilgi Alanı
  Kalıcı olarak ilgili Ürün Özel Bilgi Alanını siler."
  [id ]
  (:data (product-special-infos-id-delete-with-http-info id)))

(defn product-special-infos-id-get-with-http-info
  "Ürün Özel Bilgi Alanı
  İlgili Ürün Özel Bilgi Alanını getirir."
  [id ]
  (check-required-params id)
  (call-api "/product_special_infos/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-special-infos-id-get
  "Ürün Özel Bilgi Alanı
  İlgili Ürün Özel Bilgi Alanını getirir."
  [id ]
  (:data (product-special-infos-id-get-with-http-info id)))

(defn product-special-infos-id-put-with-http-info
  "Ürün Özel Bilgi Alanı Güncelleme
  İlgili Ürün Özel Bilgi Alanını günceller."
  [id product-special-info ]
  (check-required-params id product-special-info)
  (call-api "/product_special_infos/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-special-info
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-special-infos-id-put
  "Ürün Özel Bilgi Alanı Güncelleme
  İlgili Ürün Özel Bilgi Alanını günceller."
  [id product-special-info ]
  (:data (product-special-infos-id-put-with-http-info id product-special-info)))

(defn product-special-infos-post-with-http-info
  "Ürün Özel Bilgi Alanı Oluşturma
  Yeni bir Ürün Özel Bilgi Alanı oluşturur."
  [product-special-info ]
  (check-required-params product-special-info)
  (call-api "/product_special_infos" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-special-info
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-special-infos-post
  "Ürün Özel Bilgi Alanı Oluşturma
  Yeni bir Ürün Özel Bilgi Alanı oluşturur."
  [product-special-info ]
  (:data (product-special-infos-post-with-http-info product-special-info)))

