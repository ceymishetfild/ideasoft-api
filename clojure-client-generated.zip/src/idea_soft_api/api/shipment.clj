(ns idea-soft-api.api.shipment
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn shipments-get-with-http-info
  "Teslimat Listesi Alma
  Teslimat listesini verir."
  ([] (shipments-get-with-http-info nil))
  ([{:keys [sort limit page since-id code invoice-key barcode order start-date end-date start-updated-at end-updated-at ]}]
   (call-api "/shipments" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "code" code "invoiceKey" invoice-key "barcode" barcode "order" order "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn shipments-get
  "Teslimat Listesi Alma
  Teslimat listesini verir."
  ([] (shipments-get nil))
  ([optional-params]
   (:data (shipments-get-with-http-info optional-params))))

(defn shipments-id-delete-with-http-info
  "Teslimat Silme
  Kalıcı olarak ilgili Teslimatı siler."
  [id ]
  (check-required-params id)
  (call-api "/shipments/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipments-id-delete
  "Teslimat Silme
  Kalıcı olarak ilgili Teslimatı siler."
  [id ]
  (:data (shipments-id-delete-with-http-info id)))

(defn shipments-id-get-with-http-info
  "Teslimat Alma
  İlgili Teslimatı getirir."
  [id ]
  (check-required-params id)
  (call-api "/shipments/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipments-id-get
  "Teslimat Alma
  İlgili Teslimatı getirir."
  [id ]
  (:data (shipments-id-get-with-http-info id)))

(defn shipments-id-put-with-http-info
  "Teslimat Güncelleme
  İlgili Teslimatı günceller."
  [id shipment ]
  (check-required-params id shipment)
  (call-api "/shipments/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    shipment
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipments-id-put
  "Teslimat Güncelleme
  İlgili Teslimatı günceller."
  [id shipment ]
  (:data (shipments-id-put-with-http-info id shipment)))

(defn shipments-post-with-http-info
  "Teslimat Oluşturma
  Yeni bir Teslimat oluşturur."
  [shipment ]
  (check-required-params shipment)
  (call-api "/shipments" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    shipment
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipments-post
  "Teslimat Oluşturma
  Yeni bir Teslimat oluşturur."
  [shipment ]
  (:data (shipments-post-with-http-info shipment)))

