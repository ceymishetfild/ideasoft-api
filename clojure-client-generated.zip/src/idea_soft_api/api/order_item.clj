(ns idea-soft-api.api.order-item
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn order-items-get-with-http-info
  "Sipariş Kalemi Listesi Alma
  Sipariş Kalemi listesini verir."
  ([] (order-items-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids order product-name product-sku product-barcode start-date end-date start-updated-at end-updated-at ]}]
   (call-api "/order_items" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "order" order "productName" product-name "productSku" product-sku "productBarcode" product-barcode "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn order-items-get
  "Sipariş Kalemi Listesi Alma
  Sipariş Kalemi listesini verir."
  ([] (order-items-get nil))
  ([optional-params]
   (:data (order-items-get-with-http-info optional-params))))

(defn order-items-id-get-with-http-info
  "Sipariş Kalemi Alma
  İlgili Sipariş Kalemini getirir."
  [id ]
  (check-required-params id)
  (call-api "/order_items/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn order-items-id-get
  "Sipariş Kalemi Alma
  İlgili Sipariş Kalemini getirir."
  [id ]
  (:data (order-items-id-get-with-http-info id)))

