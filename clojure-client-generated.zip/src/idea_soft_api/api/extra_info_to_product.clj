(ns idea-soft-api.api.extra-info-to-product
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn extra-info-to-products-get-with-http-info
  "Ek Bilgi Ürün Bağı Listesi Alma
  Ek Bilgi Ürün Bağı listesini verir."
  ([] (extra-info-to-products-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids extra-info product ]}]
   (call-api "/extra_info_to_products" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "extraInfo" extra-info "product" product }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn extra-info-to-products-get
  "Ek Bilgi Ürün Bağı Listesi Alma
  Ek Bilgi Ürün Bağı listesini verir."
  ([] (extra-info-to-products-get nil))
  ([optional-params]
   (:data (extra-info-to-products-get-with-http-info optional-params))))

(defn extra-info-to-products-id-delete-with-http-info
  "Ek Bilgi Ürün Bağı Silme
  Kalıcı olarak ilgili Ek Bilgi Ürün Bağını siler."
  [id ]
  (check-required-params id)
  (call-api "/extra_info_to_products/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn extra-info-to-products-id-delete
  "Ek Bilgi Ürün Bağı Silme
  Kalıcı olarak ilgili Ek Bilgi Ürün Bağını siler."
  [id ]
  (:data (extra-info-to-products-id-delete-with-http-info id)))

(defn extra-info-to-products-id-get-with-http-info
  "Ek Bilgi Ürün Bağı Alma
  İlgili Ek Bilgi Ürün Bağını getirir."
  [id ]
  (check-required-params id)
  (call-api "/extra_info_to_products/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn extra-info-to-products-id-get
  "Ek Bilgi Ürün Bağı Alma
  İlgili Ek Bilgi Ürün Bağını getirir."
  [id ]
  (:data (extra-info-to-products-id-get-with-http-info id)))

(defn extra-info-to-products-id-put-with-http-info
  "Ek Bilgi Ürün Bağı Güncelleme
  İlgili Ek Bilgi Ürün Bağını günceller."
  [id extra-info-to-product ]
  (check-required-params id extra-info-to-product)
  (call-api "/extra_info_to_products/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    extra-info-to-product
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn extra-info-to-products-id-put
  "Ek Bilgi Ürün Bağı Güncelleme
  İlgili Ek Bilgi Ürün Bağını günceller."
  [id extra-info-to-product ]
  (:data (extra-info-to-products-id-put-with-http-info id extra-info-to-product)))

(defn extra-info-to-products-post-with-http-info
  "Ek Bilgi Ürün Bağı Oluşturma
  Yeni bir Ek Bilgi Ürün Bağı oluşturur."
  [extra-info-to-product ]
  (check-required-params extra-info-to-product)
  (call-api "/extra_info_to_products" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    extra-info-to-product
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn extra-info-to-products-post
  "Ek Bilgi Ürün Bağı Oluşturma
  Yeni bir Ek Bilgi Ürün Bağı oluşturur."
  [extra-info-to-product ]
  (:data (extra-info-to-products-post-with-http-info extra-info-to-product)))

