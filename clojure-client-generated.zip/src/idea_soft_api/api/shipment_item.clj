(ns idea-soft-api.api.shipment-item
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn shipment-items-get-with-http-info
  "Teslimat Kalemi Listesi Alma
  Teslimat Kalemi listesini verir."
  ([] (shipment-items-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids product shipment order-item start-date end-date start-updated-at end-updated-at ]}]
   (call-api "/shipment_items" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "product" product "shipment" shipment "orderItem" order-item "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn shipment-items-get
  "Teslimat Kalemi Listesi Alma
  Teslimat Kalemi listesini verir."
  ([] (shipment-items-get nil))
  ([optional-params]
   (:data (shipment-items-get-with-http-info optional-params))))

(defn shipment-items-id-delete-with-http-info
  "Teslimat Kalemi Silme
  Kalıcı olarak ilgili Teslimat Kalemini siler."
  [id ]
  (check-required-params id)
  (call-api "/shipment_items/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipment-items-id-delete
  "Teslimat Kalemi Silme
  Kalıcı olarak ilgili Teslimat Kalemini siler."
  [id ]
  (:data (shipment-items-id-delete-with-http-info id)))

(defn shipment-items-id-get-with-http-info
  "Teslimat Kalemi Alma
  İlgili Teslimat Kalemini getirir."
  [id ]
  (check-required-params id)
  (call-api "/shipment_items/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipment-items-id-get
  "Teslimat Kalemi Alma
  İlgili Teslimat Kalemini getirir."
  [id ]
  (:data (shipment-items-id-get-with-http-info id)))

(defn shipment-items-id-put-with-http-info
  "Teslimat Kalemi Güncelleme
  İlgili Teslimat Kalemini günceller."
  [id shipment-item ]
  (check-required-params id shipment-item)
  (call-api "/shipment_items/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    shipment-item
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipment-items-id-put
  "Teslimat Kalemi Güncelleme
  İlgili Teslimat Kalemini günceller."
  [id shipment-item ]
  (:data (shipment-items-id-put-with-http-info id shipment-item)))

(defn shipment-items-post-with-http-info
  "Teslimat Kalemi Oluşturma
  Yeni bir Teslimat Kalemi oluşturur."
  [shipment-item ]
  (check-required-params shipment-item)
  (call-api "/shipment_items" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    shipment-item
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn shipment-items-post
  "Teslimat Kalemi Oluşturma
  Yeni bir Teslimat Kalemi oluşturur."
  [shipment-item ]
  (:data (shipment-items-post-with-http-info shipment-item)))

