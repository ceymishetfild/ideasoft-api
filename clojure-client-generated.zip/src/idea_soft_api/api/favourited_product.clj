(ns idea-soft-api.api.favourited-product
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn favourited-products-get-with-http-info
  "Favori Ürün Listesi Alma
  Favori Ürün listesini verir."
  ([] (favourited-products-get-with-http-info nil))
  ([{:keys [sort limit page since-id product ]}]
   (call-api "/favourited_products" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "product" product }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn favourited-products-get
  "Favori Ürün Listesi Alma
  Favori Ürün listesini verir."
  ([] (favourited-products-get nil))
  ([optional-params]
   (:data (favourited-products-get-with-http-info optional-params))))

(defn favourited-products-id-delete-with-http-info
  "Favori Ürün Silme
  Kalıcı olarak ilgili Favori Ürünü siler."
  [id ]
  (check-required-params id)
  (call-api "/favourited_products/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn favourited-products-id-delete
  "Favori Ürün Silme
  Kalıcı olarak ilgili Favori Ürünü siler."
  [id ]
  (:data (favourited-products-id-delete-with-http-info id)))

(defn favourited-products-id-get-with-http-info
  "Favori Ürün Alma
  İlgili Favori Ürünü getirir."
  [id ]
  (check-required-params id)
  (call-api "/favourited_products/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn favourited-products-id-get
  "Favori Ürün Alma
  İlgili Favori Ürünü getirir."
  [id ]
  (:data (favourited-products-id-get-with-http-info id)))

(defn favourited-products-id-put-with-http-info
  "Favori Ürün Güncelleme
  İlgili Favori Ürünü günceller."
  [id favourited-product ]
  (check-required-params id favourited-product)
  (call-api "/favourited_products/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    favourited-product
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn favourited-products-id-put
  "Favori Ürün Güncelleme
  İlgili Favori Ürünü günceller."
  [id favourited-product ]
  (:data (favourited-products-id-put-with-http-info id favourited-product)))

(defn favourited-products-post-with-http-info
  "Favori Ürün Oluşturma
  Yeni bir Favori Ürün oluşturur."
  [favourited-product ]
  (check-required-params favourited-product)
  (call-api "/favourited_products" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    favourited-product
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn favourited-products-post
  "Favori Ürün Oluşturma
  Yeni bir Favori Ürün oluşturur."
  [favourited-product ]
  (:data (favourited-products-post-with-http-info favourited-product)))

