(ns idea-soft-api.api.town-group
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn town-groups-get-with-http-info
  "İlçe Grubu Listesi Alma
  İlçe Grubu listesini verir."
  ([] (town-groups-get-with-http-info nil))
  ([{:keys [sort limit page since-id name ]}]
   (call-api "/town_groups" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "name" name }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn town-groups-get
  "İlçe Grubu Listesi Alma
  İlçe Grubu listesini verir."
  ([] (town-groups-get nil))
  ([optional-params]
   (:data (town-groups-get-with-http-info optional-params))))

(defn town-groups-id-delete-with-http-info
  "İlçe Grubu Silme
  Kalıcı olarak ilgili İlçe Grubunu siler."
  [id ]
  (check-required-params id)
  (call-api "/town_groups/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn town-groups-id-delete
  "İlçe Grubu Silme
  Kalıcı olarak ilgili İlçe Grubunu siler."
  [id ]
  (:data (town-groups-id-delete-with-http-info id)))

(defn town-groups-id-get-with-http-info
  "İlçe Grubu Alma
  İlgili İlçe Grubunu getirir."
  [id ]
  (check-required-params id)
  (call-api "/town_groups/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn town-groups-id-get
  "İlçe Grubu Alma
  İlgili İlçe Grubunu getirir."
  [id ]
  (:data (town-groups-id-get-with-http-info id)))

(defn town-groups-id-put-with-http-info
  "İlçe Grubu Güncelleme
  İlgili İlçe Grubunu günceller."
  [id town-group ]
  (check-required-params id town-group)
  (call-api "/town_groups/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    town-group
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn town-groups-id-put
  "İlçe Grubu Güncelleme
  İlgili İlçe Grubunu günceller."
  [id town-group ]
  (:data (town-groups-id-put-with-http-info id town-group)))

(defn town-groups-post-with-http-info
  "İlçe Grubu Oluşturma
  Yeni bir İlçe Grubu oluşturur."
  [town-group ]
  (check-required-params town-group)
  (call-api "/town_groups" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    town-group
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn town-groups-post
  "İlçe Grubu Oluşturma
  Yeni bir İlçe Grubu oluşturur."
  [town-group ]
  (:data (town-groups-post-with-http-info town-group)))

