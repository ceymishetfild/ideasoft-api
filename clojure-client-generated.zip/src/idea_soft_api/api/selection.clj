(ns idea-soft-api.api.selection
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn selections-get-with-http-info
  "Ek Özellik Listesi Alma
  Ek Özellik listesini verir."
  ([] (selections-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids title selection-group ]}]
   (call-api "/selections" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "title" title "selectionGroup" selection-group }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn selections-get
  "Ek Özellik Listesi Alma
  Ek Özellik listesini verir."
  ([] (selections-get nil))
  ([optional-params]
   (:data (selections-get-with-http-info optional-params))))

(defn selections-id-delete-with-http-info
  "Ek Özellik Silme
  Kalıcı olarak ilgili Ek Özelliği siler."
  [id ]
  (check-required-params id)
  (call-api "/selections/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn selections-id-delete
  "Ek Özellik Silme
  Kalıcı olarak ilgili Ek Özelliği siler."
  [id ]
  (:data (selections-id-delete-with-http-info id)))

(defn selections-id-get-with-http-info
  "Ek Özellik Alma
  İlgili Ek Özelliği getirir."
  [id ]
  (check-required-params id)
  (call-api "/selections/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn selections-id-get
  "Ek Özellik Alma
  İlgili Ek Özelliği getirir."
  [id ]
  (:data (selections-id-get-with-http-info id)))

(defn selections-id-put-with-http-info
  "Ek Özellik Güncelleme
  İlgili Ek Özelliği günceller."
  [id selection ]
  (check-required-params id selection)
  (call-api "/selections/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    selection
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn selections-id-put
  "Ek Özellik Güncelleme
  İlgili Ek Özelliği günceller."
  [id selection ]
  (:data (selections-id-put-with-http-info id selection)))

(defn selections-post-with-http-info
  "Ek Özellik Oluşturma
  Yeni bir Ek Özellik oluşturur."
  [selection ]
  (check-required-params selection)
  (call-api "/selections" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    selection
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn selections-post
  "Ek Özellik Oluşturma
  Yeni bir Ek Özellik oluşturur."
  [selection ]
  (:data (selections-post-with-http-info selection)))

