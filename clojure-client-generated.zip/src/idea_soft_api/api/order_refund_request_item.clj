(ns idea-soft-api.api.order-refund-request-item
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn order-refund-request-items-get-with-http-info
  "Sipariş İptal Talebi Kalemi Listesi Alma
  Sipariş İptal Talebi Kalemi listesini verir."
  ([] (order-refund-request-items-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids order-refund-request order-item start-date end-date start-updated-at end-updated-at ]}]
   (call-api "/order_refund_request_items" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "orderRefundRequest" order-refund-request "orderItem" order-item "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn order-refund-request-items-get
  "Sipariş İptal Talebi Kalemi Listesi Alma
  Sipariş İptal Talebi Kalemi listesini verir."
  ([] (order-refund-request-items-get nil))
  ([optional-params]
   (:data (order-refund-request-items-get-with-http-info optional-params))))

(defn order-refund-request-items-id-delete-with-http-info
  "Sipariş İptal Talebi Kalemi Silme
  Kalıcı olarak ilgili Sipariş İptal Talebi Kalemini siler."
  [id ]
  (check-required-params id)
  (call-api "/order_refund_request_items/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn order-refund-request-items-id-delete
  "Sipariş İptal Talebi Kalemi Silme
  Kalıcı olarak ilgili Sipariş İptal Talebi Kalemini siler."
  [id ]
  (:data (order-refund-request-items-id-delete-with-http-info id)))

(defn order-refund-request-items-id-get-with-http-info
  "Sipariş İptal Talebi Kalemi Alma
  İlgili Sipariş İptal Talebi Kalemini getirir."
  [id ]
  (check-required-params id)
  (call-api "/order_refund_request_items/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn order-refund-request-items-id-get
  "Sipariş İptal Talebi Kalemi Alma
  İlgili Sipariş İptal Talebi Kalemini getirir."
  [id ]
  (:data (order-refund-request-items-id-get-with-http-info id)))

(defn order-refund-request-items-id-put-with-http-info
  "Sipariş İptal Talebi Kalemi Güncelleme
  İlgili Sipariş İptal Talebi Kalemini günceller."
  [id order-refund-request-item ]
  (check-required-params id order-refund-request-item)
  (call-api "/order_refund_request_items/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    order-refund-request-item
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn order-refund-request-items-id-put
  "Sipariş İptal Talebi Kalemi Güncelleme
  İlgili Sipariş İptal Talebi Kalemini günceller."
  [id order-refund-request-item ]
  (:data (order-refund-request-items-id-put-with-http-info id order-refund-request-item)))

(defn order-refund-request-items-post-with-http-info
  "Sipariş İptal Talebi Kalemi Oluşturma
  Yeni bir Sipariş İptal Talebi Kalemi oluşturur."
  [order-refund-request-item ]
  (check-required-params order-refund-request-item)
  (call-api "/order_refund_request_items" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    order-refund-request-item
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn order-refund-request-items-post
  "Sipariş İptal Talebi Kalemi Oluşturma
  Yeni bir Sipariş İptal Talebi Kalemi oluşturur."
  [order-refund-request-item ]
  (:data (order-refund-request-items-post-with-http-info order-refund-request-item)))

