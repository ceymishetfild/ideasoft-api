(ns idea-soft-api.api.maillist
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn maillists-get-with-http-info
  "Mail Listesi Listesi Alma
  Mail Listesi listesini verir."
  ([] (maillists-get-with-http-info nil))
  ([{:keys [sort limit page since-id name email maillist-group start-date end-date start-updated-at end-updated-at ]}]
   (call-api "/maillists" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "name" name "email" email "maillistGroup" maillist-group "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn maillists-get
  "Mail Listesi Listesi Alma
  Mail Listesi listesini verir."
  ([] (maillists-get nil))
  ([optional-params]
   (:data (maillists-get-with-http-info optional-params))))

(defn maillists-id-delete-with-http-info
  "Mail Listesi Silme
  Kalıcı olarak ilgili Mail Listesini siler."
  [id ]
  (check-required-params id)
  (call-api "/maillists/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn maillists-id-delete
  "Mail Listesi Silme
  Kalıcı olarak ilgili Mail Listesini siler."
  [id ]
  (:data (maillists-id-delete-with-http-info id)))

(defn maillists-id-get-with-http-info
  "Mail Listesi Alma
  İlgili Mail Listesini getirir."
  [id ]
  (check-required-params id)
  (call-api "/maillists/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn maillists-id-get
  "Mail Listesi Alma
  İlgili Mail Listesini getirir."
  [id ]
  (:data (maillists-id-get-with-http-info id)))

(defn maillists-id-put-with-http-info
  "Mail Listesi Güncelleme
  İlgili Mail Listesini günceller."
  [id maillist ]
  (check-required-params id maillist)
  (call-api "/maillists/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    maillist
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn maillists-id-put
  "Mail Listesi Güncelleme
  İlgili Mail Listesini günceller."
  [id maillist ]
  (:data (maillists-id-put-with-http-info id maillist)))

(defn maillists-post-with-http-info
  "Mail Listesi Oluşturma
  Yeni bir Mail Listesini oluşturur."
  [maillist ]
  (check-required-params maillist)
  (call-api "/maillists" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    maillist
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn maillists-post
  "Mail Listesi Oluşturma
  Yeni bir Mail Listesini oluşturur."
  [maillist ]
  (:data (maillists-post-with-http-info maillist)))

