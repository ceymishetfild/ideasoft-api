(ns idea-soft-api.api.order-user-note
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn order-user-notes-get-with-http-info
  "Sipariş Yönetici Notu Listesi Alma
  Sipariş Yönetici Notu listesini verir."
  ([] (order-user-notes-get-with-http-info nil))
  ([{:keys [sort limit page since-id order user-email start-date end-date start-updated-at end-updated-at ]}]
   (call-api "/order_user_notes" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "order" order "userEmail" user-email "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn order-user-notes-get
  "Sipariş Yönetici Notu Listesi Alma
  Sipariş Yönetici Notu listesini verir."
  ([] (order-user-notes-get nil))
  ([optional-params]
   (:data (order-user-notes-get-with-http-info optional-params))))

(defn order-user-notes-id-delete-with-http-info
  "Sipariş Yönetici Notu Silme
  Kalıcı olarak ilgili Sipariş Yönetici Notunu siler."
  [id ]
  (check-required-params id)
  (call-api "/order_user_notes/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn order-user-notes-id-delete
  "Sipariş Yönetici Notu Silme
  Kalıcı olarak ilgili Sipariş Yönetici Notunu siler."
  [id ]
  (:data (order-user-notes-id-delete-with-http-info id)))

(defn order-user-notes-id-get-with-http-info
  "Sipariş Yönetici Notu Alma
  İlgili Sipariş Yönetici Notunu getirir."
  [id ]
  (check-required-params id)
  (call-api "/order_user_notes/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn order-user-notes-id-get
  "Sipariş Yönetici Notu Alma
  İlgili Sipariş Yönetici Notunu getirir."
  [id ]
  (:data (order-user-notes-id-get-with-http-info id)))

(defn order-user-notes-id-put-with-http-info
  "Sipariş Yönetici Notu Güncelleme
  İlgili Sipariş Yönetici Notunu günceller."
  [id order-user-note ]
  (check-required-params id order-user-note)
  (call-api "/order_user_notes/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    order-user-note
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn order-user-notes-id-put
  "Sipariş Yönetici Notu Güncelleme
  İlgili Sipariş Yönetici Notunu günceller."
  [id order-user-note ]
  (:data (order-user-notes-id-put-with-http-info id order-user-note)))

(defn order-user-notes-post-with-http-info
  "Sipariş Yönetici Notu Oluşturma
  Yeni bir Sipariş Yönetici Notu oluşturur."
  [order-user-note ]
  (check-required-params order-user-note)
  (call-api "/order_user_notes" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    order-user-note
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn order-user-notes-post
  "Sipariş Yönetici Notu Oluşturma
  Yeni bir Sipariş Yönetici Notu oluşturur."
  [order-user-note ]
  (:data (order-user-notes-post-with-http-info order-user-note)))

