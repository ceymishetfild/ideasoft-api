(ns idea-soft-api.api.category
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn categories-get-with-http-info
  "Kategori Listesi Alma
  Kategori listesini verir."
  ([] (categories-get-with-http-info nil))
  ([{:keys [sort limit page since-id name status distributor parent start-date end-date start-updated-at end-updated-at ]}]
   (call-api "/categories" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "name" name "status" status "distributor" distributor "parent" parent "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn categories-get
  "Kategori Listesi Alma
  Kategori listesini verir."
  ([] (categories-get nil))
  ([optional-params]
   (:data (categories-get-with-http-info optional-params))))

(defn categories-id-delete-with-http-info
  "Kategori Silme
  Kalıcı olarak ilgili Kategoriyi siler."
  [id ]
  (check-required-params id)
  (call-api "/categories/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn categories-id-delete
  "Kategori Silme
  Kalıcı olarak ilgili Kategoriyi siler."
  [id ]
  (:data (categories-id-delete-with-http-info id)))

(defn categories-id-get-with-http-info
  "Kategori Alma
  İlgili Kategoriyi getirir."
  [id ]
  (check-required-params id)
  (call-api "/categories/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn categories-id-get
  "Kategori Alma
  İlgili Kategoriyi getirir."
  [id ]
  (:data (categories-id-get-with-http-info id)))

(defn categories-id-put-with-http-info
  "Kategori Güncelleme
  İlgili Kategoriyi günceller."
  [id category ]
  (check-required-params id category)
  (call-api "/categories/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    category
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn categories-id-put
  "Kategori Güncelleme
  İlgili Kategoriyi günceller."
  [id category ]
  (:data (categories-id-put-with-http-info id category)))

(defn categories-post-with-http-info
  "Kategori Oluşturma
  Yeni bir Kategori oluşturur."
  [category ]
  (check-required-params category)
  (call-api "/categories" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    category
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn categories-post
  "Kategori Oluşturma
  Yeni bir Kategori oluşturur."
  [category ]
  (:data (categories-post-with-http-info category)))

