(ns idea-soft-api.api.member
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn members-charts-get-with-http-info
  "Üye Grafik Aksiyonu
  Zaman bazında üye genel istatistiklerini getirir."
  [time-frame start-date ]
  (check-required-params time-frame start-date)
  (call-api "/members/charts" :get
            {:path-params   {}
             :header-params {}
             :query-params  {"timeFrame" time-frame "startDate" start-date }
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn members-charts-get
  "Üye Grafik Aksiyonu
  Zaman bazında üye genel istatistiklerini getirir."
  [time-frame start-date ]
  (:data (members-charts-get-with-http-info time-frame start-date)))

(defn members-combined-get-with-http-info
  "Üye Birleşik Aksiyonu
  Bugün, aylık, yıllık ve toplam üye oturum açma istatistiklerini totalCount cinsinden getirir."
  []
  (call-api "/members/combined" :get
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    []}))

(defn members-combined-get
  "Üye Birleşik Aksiyonu
  Bugün, aylık, yıllık ve toplam üye oturum açma istatistiklerini totalCount cinsinden getirir."
  []
  (:data (members-combined-get-with-http-info)))

(defn members-get-with-http-info
  "Üye Listesi Alma
  Üye listesini verir."
  ([] (members-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids firstname surname email password gender mobile-phone-number phone-number member-group location country referred-member q start-date end-date start-updated-at end-updated-at ]}]
   (call-api "/members" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "firstname" firstname "surname" surname "email" email "password" password "gender" gender "mobilePhoneNumber" mobile-phone-number "phoneNumber" phone-number "memberGroup" member-group "location" location "country" country "referredMember" referred-member "q" (with-collection-format q :multi) "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn members-get
  "Üye Listesi Alma
  Üye listesini verir."
  ([] (members-get nil))
  ([optional-params]
   (:data (members-get-with-http-info optional-params))))

(defn members-id-delete-with-http-info
  "Üye Silme
  Kalıcı olarak ilgili Üyeyi siler."
  [id ]
  (check-required-params id)
  (call-api "/members/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn members-id-delete
  "Üye Silme
  Kalıcı olarak ilgili Üyeyi siler."
  [id ]
  (:data (members-id-delete-with-http-info id)))

(defn members-id-get-with-http-info
  "Üye Alma
  İlgili Üyeyi getirir."
  [id ]
  (check-required-params id)
  (call-api "/members/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn members-id-get
  "Üye Alma
  İlgili Üyeyi getirir."
  [id ]
  (:data (members-id-get-with-http-info id)))

(defn members-id-put-with-http-info
  "Üye Güncelleme
  İlgili Üyeyi günceller."
  [id member ]
  (check-required-params id member)
  (call-api "/members/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    member
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn members-id-put
  "Üye Güncelleme
  İlgili Üyeyi günceller."
  [id member ]
  (:data (members-id-put-with-http-info id member)))

(defn members-post-with-http-info
  "Üye Oluşturma
  Yeni bir Üye oluşturur."
  [member ]
  (check-required-params member)
  (call-api "/members" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    member
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn members-post
  "Üye Oluşturma
  Yeni bir Üye oluşturur."
  [member ]
  (:data (members-post-with-http-info member)))

