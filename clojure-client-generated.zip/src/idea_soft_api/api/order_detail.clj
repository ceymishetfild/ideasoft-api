(ns idea-soft-api.api.order-detail
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn order-details-get-with-http-info
  "Sipariş Detayı Listesi Alma
  Sipariş Detayı listesini verir."
  ([] (order-details-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids order ]}]
   (call-api "/order_details" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "order" order }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn order-details-get
  "Sipariş Detayı Listesi Alma
  Sipariş Detayı listesini verir."
  ([] (order-details-get nil))
  ([optional-params]
   (:data (order-details-get-with-http-info optional-params))))

(defn order-details-id-delete-with-http-info
  "Sipariş Detayı Silme
  Kalıcı olarak ilgili Sipariş Detayı siler."
  [id ]
  (check-required-params id)
  (call-api "/order_details/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn order-details-id-delete
  "Sipariş Detayı Silme
  Kalıcı olarak ilgili Sipariş Detayı siler."
  [id ]
  (:data (order-details-id-delete-with-http-info id)))

(defn order-details-id-get-with-http-info
  "Sipariş Detayı Alma
  İlgili Sipariş Detayı getirir."
  [id ]
  (check-required-params id)
  (call-api "/order_details/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn order-details-id-get
  "Sipariş Detayı Alma
  İlgili Sipariş Detayı getirir."
  [id ]
  (:data (order-details-id-get-with-http-info id)))

(defn order-details-id-put-with-http-info
  "Sipariş Detayı Güncelleme
  İlgili Sipariş Detayı günceller."
  [id order-detail ]
  (check-required-params id order-detail)
  (call-api "/order_details/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    order-detail
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn order-details-id-put
  "Sipariş Detayı Güncelleme
  İlgili Sipariş Detayı günceller."
  [id order-detail ]
  (:data (order-details-id-put-with-http-info id order-detail)))

(defn order-details-post-with-http-info
  "Sipariş Detayı Oluşturma
  Yeni bir Sipariş Detayı oluşturur."
  [order-detail ]
  (check-required-params order-detail)
  (call-api "/order_details" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    order-detail
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn order-details-post
  "Sipariş Detayı Oluşturma
  Yeni bir Sipariş Detayı oluşturur."
  [order-detail ]
  (:data (order-details-post-with-http-info order-detail)))

