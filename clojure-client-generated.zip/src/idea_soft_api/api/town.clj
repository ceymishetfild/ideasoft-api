(ns idea-soft-api.api.town
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn towns-get-with-http-info
  "İlçe Listesi Alma
  İlçe listesini verir."
  ([] (towns-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids location town-group name status ]}]
   (call-api "/towns" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "location" location "townGroup" town-group "name" name "status" status }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn towns-get
  "İlçe Listesi Alma
  İlçe listesini verir."
  ([] (towns-get nil))
  ([optional-params]
   (:data (towns-get-with-http-info optional-params))))

(defn towns-id-delete-with-http-info
  "İlçe Silme
  Kalıcı olarak ilgili İlçeyi siler."
  [id ]
  (check-required-params id)
  (call-api "/towns/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn towns-id-delete
  "İlçe Silme
  Kalıcı olarak ilgili İlçeyi siler."
  [id ]
  (:data (towns-id-delete-with-http-info id)))

(defn towns-id-get-with-http-info
  "İlçe Alma
  İlgili İlçeyi getirir."
  [id ]
  (check-required-params id)
  (call-api "/towns/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn towns-id-get
  "İlçe Alma
  İlgili İlçeyi getirir."
  [id ]
  (:data (towns-id-get-with-http-info id)))

(defn towns-id-put-with-http-info
  "İlçe Güncelleme
  İlgili İlçeyi günceller."
  [id town ]
  (check-required-params id town)
  (call-api "/towns/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    town
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn towns-id-put
  "İlçe Güncelleme
  İlgili İlçeyi günceller."
  [id town ]
  (:data (towns-id-put-with-http-info id town)))

(defn towns-post-with-http-info
  "İlçe Oluşturma
  Yeni bir İlçe oluşturur."
  [town ]
  (check-required-params town)
  (call-api "/towns" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    town
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn towns-post
  "İlçe Oluşturma
  Yeni bir İlçe oluşturur."
  [town ]
  (:data (towns-post-with-http-info town)))

