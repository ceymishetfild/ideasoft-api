(ns idea-soft-api.api.product-to-count-down
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn product-to-count-downs-get-with-http-info
  "Ürün Geri Sayım Bağı Listesi Alma
  Ürün Geri Sayım Bağı listesini verir."
  ([] (product-to-count-downs-get-with-http-info nil))
  ([{:keys [sort limit page since-id product ]}]
   (call-api "/product_to_count_downs" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "product" product }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn product-to-count-downs-get
  "Ürün Geri Sayım Bağı Listesi Alma
  Ürün Geri Sayım Bağı listesini verir."
  ([] (product-to-count-downs-get nil))
  ([optional-params]
   (:data (product-to-count-downs-get-with-http-info optional-params))))

(defn product-to-count-downs-id-delete-with-http-info
  "Ürün Geri Sayım Bağı Silme
  Kalıcı olarak ilgili Ürün Geri Sayım Bağını siler."
  [id ]
  (check-required-params id)
  (call-api "/product_to_count_downs/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-to-count-downs-id-delete
  "Ürün Geri Sayım Bağı Silme
  Kalıcı olarak ilgili Ürün Geri Sayım Bağını siler."
  [id ]
  (:data (product-to-count-downs-id-delete-with-http-info id)))

(defn product-to-count-downs-id-get-with-http-info
  "Ürün Geri Sayım Bağı Alma
  İlgili Ürün Geri Sayım Bağını getirir."
  [id ]
  (check-required-params id)
  (call-api "/product_to_count_downs/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-to-count-downs-id-get
  "Ürün Geri Sayım Bağı Alma
  İlgili Ürün Geri Sayım Bağını getirir."
  [id ]
  (:data (product-to-count-downs-id-get-with-http-info id)))

(defn product-to-count-downs-id-put-with-http-info
  "Ürün Geri Sayım Bağı Güncelleme
  İlgili Ürün Geri Sayım Bağını günceller."
  [id product-to-count-down ]
  (check-required-params id product-to-count-down)
  (call-api "/product_to_count_downs/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-to-count-down
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-to-count-downs-id-put
  "Ürün Geri Sayım Bağı Güncelleme
  İlgili Ürün Geri Sayım Bağını günceller."
  [id product-to-count-down ]
  (:data (product-to-count-downs-id-put-with-http-info id product-to-count-down)))

(defn product-to-count-downs-post-with-http-info
  "Ürün Geri Sayım Bağı Oluşturma
  Yeni bir Ürün Geri Sayım Bağı oluşturur."
  [product-to-count-down ]
  (check-required-params product-to-count-down)
  (call-api "/product_to_count_downs" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-to-count-down
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-to-count-downs-post
  "Ürün Geri Sayım Bağı Oluşturma
  Yeni bir Ürün Geri Sayım Bağı oluşturur."
  [product-to-count-down ]
  (:data (product-to-count-downs-post-with-http-info product-to-count-down)))

