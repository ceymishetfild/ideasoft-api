(ns idea-soft-api.api.extra-info
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn extra-infos-get-with-http-info
  "Ek Bilgi Listesi Alma
  Ek Bilgi listesini verir."
  ([] (extra-infos-get-with-http-info nil))
  ([{:keys [sort limit page since-id name ]}]
   (call-api "/extra_infos" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "name" name }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn extra-infos-get
  "Ek Bilgi Listesi Alma
  Ek Bilgi listesini verir."
  ([] (extra-infos-get nil))
  ([optional-params]
   (:data (extra-infos-get-with-http-info optional-params))))

(defn extra-infos-id-delete-with-http-info
  "Ek Bilgi Silme
  Kalıcı olarak ilgili Ek Bilgiyi siler."
  [id ]
  (check-required-params id)
  (call-api "/extra_infos/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn extra-infos-id-delete
  "Ek Bilgi Silme
  Kalıcı olarak ilgili Ek Bilgiyi siler."
  [id ]
  (:data (extra-infos-id-delete-with-http-info id)))

(defn extra-infos-id-get-with-http-info
  "Ek Bilgi Alma
  İlgili Ek Bilgiyi getirir."
  [id ]
  (check-required-params id)
  (call-api "/extra_infos/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn extra-infos-id-get
  "Ek Bilgi Alma
  İlgili Ek Bilgiyi getirir."
  [id ]
  (:data (extra-infos-id-get-with-http-info id)))

(defn extra-infos-id-put-with-http-info
  "Ek Bilgi Güncelleme
  İlgili Ek Bilgiyi günceller."
  [id extra-info ]
  (check-required-params id extra-info)
  (call-api "/extra_infos/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    extra-info
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn extra-infos-id-put
  "Ek Bilgi Güncelleme
  İlgili Ek Bilgiyi günceller."
  [id extra-info ]
  (:data (extra-infos-id-put-with-http-info id extra-info)))

(defn extra-infos-post-with-http-info
  "Ek Bilgi Oluşturma
  Yeni bir Ek Bilgi oluşturur."
  [extra-info ]
  (check-required-params extra-info)
  (call-api "/extra_infos" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    extra-info
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn extra-infos-post
  "Ek Bilgi Oluşturma
  Yeni bir Ek Bilgi oluşturur."
  [extra-info ]
  (:data (extra-infos-post-with-http-info extra-info)))

