(ns idea-soft-api.api.billing-address
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn billing-addresses-get-with-http-info
  "Fatura Adresi Listesi Alma
  Fatura Adresi listesini verir."
  ([] (billing-addresses-get-with-http-info nil))
  ([{:keys [sort limit page since-id order start-date end-date start-updated-at end-updated-at ]}]
   (call-api "/billing_addresses" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "order" order "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn billing-addresses-get
  "Fatura Adresi Listesi Alma
  Fatura Adresi listesini verir."
  ([] (billing-addresses-get nil))
  ([optional-params]
   (:data (billing-addresses-get-with-http-info optional-params))))

(defn billing-addresses-id-get-with-http-info
  "Fatura Adresi Alma
  İlgili Fatura Adresini getirir."
  [id ]
  (check-required-params id)
  (call-api "/billing_addresses/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn billing-addresses-id-get
  "Fatura Adresi Alma
  İlgili Fatura Adresini getirir."
  [id ]
  (:data (billing-addresses-id-get-with-http-info id)))

(defn billing-addresses-id-put-with-http-info
  "Fatura Adresi Güncelleme
  İlgili Fatura Adresini günceller."
  [id billing-address ]
  (check-required-params id billing-address)
  (call-api "/billing_addresses/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    billing-address
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn billing-addresses-id-put
  "Fatura Adresi Güncelleme
  İlgili Fatura Adresini günceller."
  [id billing-address ]
  (:data (billing-addresses-id-put-with-http-info id billing-address)))

(defn billing-addresses-post-with-http-info
  "Fatura Adresi Oluşturma
  Yeni bir Fatura Adresi oluşturur. Fatura Adresi oluşturabilmek için geçerli bir önceden tanımlanmış Sipariş id değerine ihtiyaç vardır."
  [billing-address ]
  (check-required-params billing-address)
  (call-api "/billing_addresses" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    billing-address
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn billing-addresses-post
  "Fatura Adresi Oluşturma
  Yeni bir Fatura Adresi oluşturur. Fatura Adresi oluşturabilmek için geçerli bir önceden tanımlanmış Sipariş id değerine ihtiyaç vardır."
  [billing-address ]
  (:data (billing-addresses-post-with-http-info billing-address)))

