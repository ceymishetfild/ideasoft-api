(ns idea-soft-api.api.payment-provider
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn payment-providers-get-with-http-info
  "Ödeme Altyapısı Sağlayıcısı Listesi Alma
  Ödeme Altyapısı Sağlayıcısı listesini verir."
  ([] (payment-providers-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids code name ]}]
   (call-api "/payment_providers" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "code" code "name" name }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn payment-providers-get
  "Ödeme Altyapısı Sağlayıcısı Listesi Alma
  Ödeme Altyapısı Sağlayıcısı listesini verir."
  ([] (payment-providers-get nil))
  ([optional-params]
   (:data (payment-providers-get-with-http-info optional-params))))

(defn payment-providers-id-get-with-http-info
  "Ödeme Altyapısı Sağlayıcısı Alma
  İlgili Ödeme Altyapısı Sağlayıcısını getirir."
  [id ]
  (check-required-params id)
  (call-api "/payment_providers/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn payment-providers-id-get
  "Ödeme Altyapısı Sağlayıcısı Alma
  İlgili Ödeme Altyapısı Sağlayıcısını getirir."
  [id ]
  (:data (payment-providers-id-get-with-http-info id)))

