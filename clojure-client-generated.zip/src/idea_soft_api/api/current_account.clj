(ns idea-soft-api.api.current-account
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn current-accounts-get-with-http-info
  "Cari Hesap Listesi Alma
  Cari Hesap listesini verir."
  ([] (current-accounts-get-with-http-info nil))
  ([{:keys [sort limit page since-id ids code title start-date end-date start-updated-at end-updated-at member ]}]
   (call-api "/current_accounts" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "ids" ids "code" code "title" title "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at "member" member }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn current-accounts-get
  "Cari Hesap Listesi Alma
  Cari Hesap listesini verir."
  ([] (current-accounts-get nil))
  ([optional-params]
   (:data (current-accounts-get-with-http-info optional-params))))

(defn current-accounts-id-delete-with-http-info
  "Cari Hesap Silme
  Kalıcı olarak ilgili Cari Hesabı siler."
  [id ]
  (check-required-params id)
  (call-api "/current_accounts/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn current-accounts-id-delete
  "Cari Hesap Silme
  Kalıcı olarak ilgili Cari Hesabı siler."
  [id ]
  (:data (current-accounts-id-delete-with-http-info id)))

(defn current-accounts-id-get-with-http-info
  "Cari Hesap Alma
  İlgili Cari Hesabı getirir."
  [id ]
  (check-required-params id)
  (call-api "/current_accounts/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn current-accounts-id-get
  "Cari Hesap Alma
  İlgili Cari Hesabı getirir."
  [id ]
  (:data (current-accounts-id-get-with-http-info id)))

(defn current-accounts-id-put-with-http-info
  "Cari Hesap Güncelleme
  İlgili Cari Hesabı günceller."
  [id current-account ]
  (check-required-params id current-account)
  (call-api "/current_accounts/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    current-account
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn current-accounts-id-put
  "Cari Hesap Güncelleme
  İlgili Cari Hesabı günceller."
  [id current-account ]
  (:data (current-accounts-id-put-with-http-info id current-account)))

(defn current-accounts-post-with-http-info
  "Cari Hesap Oluşturma
  Yeni bir Cari Hesap oluşturur."
  [current-account ]
  (check-required-params current-account)
  (call-api "/current_accounts" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    current-account
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn current-accounts-post
  "Cari Hesap Oluşturma
  Yeni bir Cari Hesap oluşturur."
  [current-account ]
  (:data (current-accounts-post-with-http-info current-account)))

