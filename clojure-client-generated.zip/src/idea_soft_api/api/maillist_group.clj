(ns idea-soft-api.api.maillist-group
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn maillist-groups-get-with-http-info
  "Mail Listesi Grubu Listesi Alma
  Mail Listesi Grubu listesini verir."
  ([] (maillist-groups-get-with-http-info nil))
  ([{:keys [sort limit page since-id name ]}]
   (call-api "/maillist_groups" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "name" name }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn maillist-groups-get
  "Mail Listesi Grubu Listesi Alma
  Mail Listesi Grubu listesini verir."
  ([] (maillist-groups-get nil))
  ([optional-params]
   (:data (maillist-groups-get-with-http-info optional-params))))

(defn maillist-groups-id-delete-with-http-info
  "Mail Listesi Grubu Silme
  Kalıcı olarak ilgili Mail Listesi Grubunu siler."
  [id ]
  (check-required-params id)
  (call-api "/maillist_groups/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn maillist-groups-id-delete
  "Mail Listesi Grubu Silme
  Kalıcı olarak ilgili Mail Listesi Grubunu siler."
  [id ]
  (:data (maillist-groups-id-delete-with-http-info id)))

(defn maillist-groups-id-get-with-http-info
  "Mail Listesi Grubu Alma
  İlgili Mail Listesi Grubunu getirir."
  [id ]
  (check-required-params id)
  (call-api "/maillist_groups/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn maillist-groups-id-get
  "Mail Listesi Grubu Alma
  İlgili Mail Listesi Grubunu getirir."
  [id ]
  (:data (maillist-groups-id-get-with-http-info id)))

(defn maillist-groups-id-put-with-http-info
  "Mail Listesi Grubu Güncelleme
  İlgili Mail Listesi Grubunu günceller."
  [id maillist-group ]
  (check-required-params id maillist-group)
  (call-api "/maillist_groups/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    maillist-group
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn maillist-groups-id-put
  "Mail Listesi Grubu Güncelleme
  İlgili Mail Listesi Grubunu günceller."
  [id maillist-group ]
  (:data (maillist-groups-id-put-with-http-info id maillist-group)))

(defn maillist-groups-post-with-http-info
  "Mail Listesi Grubu Oluşturma
  Yeni bir Mail Listesi Grubu oluşturur."
  [maillist-group ]
  (check-required-params maillist-group)
  (call-api "/maillist_groups" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    maillist-group
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn maillist-groups-post
  "Mail Listesi Grubu Oluşturma
  Yeni bir Mail Listesi Grubu oluşturur."
  [maillist-group ]
  (:data (maillist-groups-post-with-http-info maillist-group)))

