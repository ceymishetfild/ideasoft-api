(ns idea-soft-api.api.cart
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn carts-id-delete-with-http-info
  "Sepet Silme
  Kalıcı olarak ilgili Sepeti siler."
  [id ]
  (check-required-params id)
  (call-api "/carts/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn carts-id-delete
  "Sepet Silme
  Kalıcı olarak ilgili Sepeti siler."
  [id ]
  (:data (carts-id-delete-with-http-info id)))

(defn carts-id-get-with-http-info
  "Sepet Alma
  İlgili Sepet getirir."
  [id ]
  (check-required-params id)
  (call-api "/carts/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn carts-id-get
  "Sepet Alma
  İlgili Sepet getirir."
  [id ]
  (:data (carts-id-get-with-http-info id)))

(defn carts-post-with-http-info
  "Sepet Oluşturma
  Yeni bir Sepet oluşturur."
  [cart ]
  (check-required-params cart)
  (call-api "/carts" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    cart
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn carts-post
  "Sepet Oluşturma
  Yeni bir Sepet oluşturur."
  [cart ]
  (:data (carts-post-with-http-info cart)))

