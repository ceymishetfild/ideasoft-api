(ns idea-soft-api.api.product-comment
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn product-comments-get-with-http-info
  "Ürün Yorumları Listesi Alma
  Ürün Yorumları listesini verir."
  ([] (product-comments-get-with-http-info nil))
  ([{:keys [sort limit page since-id status is-anonymous member product start-date end-date start-updated-at end-updated-at ]}]
   (call-api "/product_comments" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "status" status "isAnonymous" is-anonymous "member" member "product" product "startDate" start-date "endDate" end-date "startUpdatedAt" start-updated-at "endUpdatedAt" end-updated-at }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn product-comments-get
  "Ürün Yorumları Listesi Alma
  Ürün Yorumları listesini verir."
  ([] (product-comments-get nil))
  ([optional-params]
   (:data (product-comments-get-with-http-info optional-params))))

(defn product-comments-id-delete-with-http-info
  "Ürün Yorumu Silme
  Kalıcı olarak ilgili Ürün Yorumunu siler."
  [id ]
  (check-required-params id)
  (call-api "/product_comments/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-comments-id-delete
  "Ürün Yorumu Silme
  Kalıcı olarak ilgili Ürün Yorumunu siler."
  [id ]
  (:data (product-comments-id-delete-with-http-info id)))

(defn product-comments-id-get-with-http-info
  "Ürün Yorumu Alma
  İlgili Ürün Yorumunu getirir."
  [id ]
  (check-required-params id)
  (call-api "/product_comments/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-comments-id-get
  "Ürün Yorumu Alma
  İlgili Ürün Yorumunu getirir."
  [id ]
  (:data (product-comments-id-get-with-http-info id)))

(defn product-comments-id-put-with-http-info
  "Ürün Yorumu Güncelleme
  İlgili Ürün Yorumunu günceller."
  [id product-comment ]
  (check-required-params id product-comment)
  (call-api "/product_comments/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-comment
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-comments-id-put
  "Ürün Yorumu Güncelleme
  İlgili Ürün Yorumunu günceller."
  [id product-comment ]
  (:data (product-comments-id-put-with-http-info id product-comment)))

(defn product-comments-post-with-http-info
  "Ürün Yorumu Oluşturma
  Yeni bir Ürün Yorumu oluşturur."
  [product-comment ]
  (check-required-params product-comment)
  (call-api "/product_comments" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    product-comment
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn product-comments-post
  "Ürün Yorumu Oluşturma
  Yeni bir Ürün Yorumu oluşturur."
  [product-comment ]
  (:data (product-comments-post-with-http-info product-comment)))

