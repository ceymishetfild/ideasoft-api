(ns idea-soft-api.api.option-group
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn option-groups-get-with-http-info
  "Varyant Grubu Listesi Alma
  Varyant Grubu listesini verir."
  ([] (option-groups-get-with-http-info nil))
  ([{:keys [sort limit page since-id title ]}]
   (call-api "/option_groups" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "title" title }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn option-groups-get
  "Varyant Grubu Listesi Alma
  Varyant Grubu listesini verir."
  ([] (option-groups-get nil))
  ([optional-params]
   (:data (option-groups-get-with-http-info optional-params))))

(defn option-groups-id-delete-with-http-info
  "Varyant Grubu Silme
  Kalıcı olarak ilgili Varyant Grubunu siler."
  [id ]
  (check-required-params id)
  (call-api "/option_groups/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn option-groups-id-delete
  "Varyant Grubu Silme
  Kalıcı olarak ilgili Varyant Grubunu siler."
  [id ]
  (:data (option-groups-id-delete-with-http-info id)))

(defn option-groups-id-get-with-http-info
  "Varyant Grubu Alma
  İlgili Varyant Grubunu getirir."
  [id ]
  (check-required-params id)
  (call-api "/option_groups/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn option-groups-id-get
  "Varyant Grubu Alma
  İlgili Varyant Grubunu getirir."
  [id ]
  (:data (option-groups-id-get-with-http-info id)))

(defn option-groups-id-put-with-http-info
  "Varyant Grubu Güncelleme
  İlgili Varyant Grubunu günceller."
  [id option-group ]
  (check-required-params id option-group)
  (call-api "/option_groups/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    option-group
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn option-groups-id-put
  "Varyant Grubu Güncelleme
  İlgili Varyant Grubunu günceller."
  [id option-group ]
  (:data (option-groups-id-put-with-http-info id option-group)))

(defn option-groups-post-with-http-info
  "Varyant Grubu Oluşturma
  Yeni bir Varyant Grubu oluşturur."
  [option-group ]
  (check-required-params option-group)
  (call-api "/option_groups" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    option-group
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn option-groups-post
  "Varyant Grubu Oluşturma
  Yeni bir Varyant Grubu oluşturur."
  [option-group ]
  (:data (option-groups-post-with-http-info option-group)))

