(ns idea-soft-api.api.theme
  (:require [idea-soft-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn themes-get-with-http-info
  "Tema Listesi Alma
  Tema listesi verir."
  ([] (themes-get-with-http-info nil))
  ([{:keys [sort limit page since-id status platform type ]}]
   (call-api "/themes" :get
             {:path-params   {}
              :header-params {}
              :query-params  {"sort" sort "limit" limit "page" page "sinceId" since-id "status" status "platform" platform "type" type }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn themes-get
  "Tema Listesi Alma
  Tema listesi verir."
  ([] (themes-get nil))
  ([optional-params]
   (:data (themes-get-with-http-info optional-params))))

(defn themes-id-assets-get-with-http-info
  "Tema Dosyası Listesi Alma
  Tema Dosyası listesi verir."
  ([id ] (themes-id-assets-get-with-http-info id nil))
  ([id {:keys [key ]}]
   (check-required-params id)
   (call-api "/themes/{id}/assets" :get
             {:path-params   {"id" id }
              :header-params {}
              :query-params  {"key" key }
              :form-params   {}
              :content-types ["application/json"]
              :accepts       ["application/json"]
              :auth-names    ["OAuth2"]})))

(defn themes-id-assets-get
  "Tema Dosyası Listesi Alma
  Tema Dosyası listesi verir."
  ([id ] (themes-id-assets-get id nil))
  ([id optional-params]
   (:data (themes-id-assets-get-with-http-info id optional-params))))

(defn themes-id-assetskeykey-delete-with-http-info
  "Tema Dosyası Silme
  Kalıcı olarak ilgili Tema Dosyasını siler."
  [id key ]
  (check-required-params id key)
  (call-api "/themes/{id}/assets?key&#x3D;{key}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {"key" key }
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn themes-id-assetskeykey-delete
  "Tema Dosyası Silme
  Kalıcı olarak ilgili Tema Dosyasını siler."
  [id key ]
  (:data (themes-id-assetskeykey-delete-with-http-info id key)))

(defn themes-id-assetskeykey-get-with-http-info
  "Tema Dosyası Alma
  İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur."
  [id key ]
  (check-required-params id key)
  (call-api "/themes/{id}/assets?key&#x3D;{key}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {"key" key }
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn themes-id-assetskeykey-get
  "Tema Dosyası Alma
  İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur."
  [id key ]
  (:data (themes-id-assetskeykey-get-with-http-info id key)))

(defn themes-id-assetskeykey-put-with-http-info
  "Tema Dosyası Güncelleme
  Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller."
  [id theme asset ]
  (check-required-params id theme asset)
  (call-api "/themes/{id}/assets?key&#x3D;{key}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    asset
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn themes-id-assetskeykey-put
  "Tema Dosyası Güncelleme
  Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller."
  [id theme asset ]
  (:data (themes-id-assetskeykey-put-with-http-info id theme asset)))

(defn themes-id-delete-with-http-info
  "Tema Silme
  Kalıcı olarak ilgili Temayı siler."
  [id ]
  (check-required-params id)
  (call-api "/themes/{id}" :delete
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn themes-id-delete
  "Tema Silme
  Kalıcı olarak ilgili Temayı siler."
  [id ]
  (:data (themes-id-delete-with-http-info id)))

(defn themes-id-get-with-http-info
  "Tema Alma
  İlgili Temayı getirir."
  [id ]
  (check-required-params id)
  (call-api "/themes/{id}" :get
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn themes-id-get
  "Tema Alma
  İlgili Temayı getirir."
  [id ]
  (:data (themes-id-get-with-http-info id)))

(defn themes-id-put-with-http-info
  "Tema Güncelleme
  İlgili Temayı günceller."
  [id theme ]
  (check-required-params id theme)
  (call-api "/themes/{id}" :put
            {:path-params   {"id" id }
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    theme
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn themes-id-put
  "Tema Güncelleme
  İlgili Temayı günceller."
  [id theme ]
  (:data (themes-id-put-with-http-info id theme)))

(defn themes-post-with-http-info
  "Tema Oluşturma
  Yeni bir tema oluşturur."
  [theme ]
  (check-required-params theme)
  (call-api "/themes" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    theme
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["OAuth2"]}))

(defn themes-post
  "Tema Oluşturma
  Yeni bir tema oluşturur."
  [theme ]
  (:data (themes-post-with-http-info theme)))

