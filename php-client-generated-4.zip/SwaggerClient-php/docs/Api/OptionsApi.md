# Swagger\Client\OptionsApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**optionsGet**](OptionsApi.md#optionsGet) | **GET** /options | Varyant Listesi Alma
[**optionsIdDelete**](OptionsApi.md#optionsIdDelete) | **DELETE** /options/{id} | Varyant Silme
[**optionsIdGet**](OptionsApi.md#optionsIdGet) | **GET** /options/{id} | Varyant Alma
[**optionsIdPut**](OptionsApi.md#optionsIdPut) | **PUT** /options/{id} | Varyant Güncelleme
[**optionsPost**](OptionsApi.md#optionsPost) | **POST** /options | Varyant Oluşturma


# **optionsGet**
> \Swagger\Client\Model\Options optionsGet($sort, $limit, $page, $since_id, $ids, $title, $option_group)

Varyant Listesi Alma

Varyant listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OptionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$title = "title_example"; // string | Varyant başlığı
$option_group = 56; // int | Varyant Grubu id

try {
    $result = $apiInstance->optionsGet($sort, $limit, $page, $since_id, $ids, $title, $option_group);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OptionsApi->optionsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **title** | **string**| Varyant başlığı | [optional]
 **option_group** | **int**| Varyant Grubu id | [optional]

### Return type

[**\Swagger\Client\Model\Options**](../Model/Options.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **optionsIdDelete**
> optionsIdDelete($id)

Varyant Silme

Kalıcı olarak ilgili Varyantı siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OptionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Varyant nesnesinin id değeri

try {
    $apiInstance->optionsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling OptionsApi->optionsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **optionsIdGet**
> \Swagger\Client\Model\Options optionsIdGet($id)

Varyant Alma

İlgili Varyantı getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OptionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Varyant nesnesinin id değeri

try {
    $result = $apiInstance->optionsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OptionsApi->optionsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\Options**](../Model/Options.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **optionsIdPut**
> \Swagger\Client\Model\Options optionsIdPut($id, $options)

Varyant Güncelleme

İlgili Varyantı günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OptionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Varyant nesnesinin id değeri
$options = new \Swagger\Client\Model\Options(); // \Swagger\Client\Model\Options | nesnesi

try {
    $result = $apiInstance->optionsIdPut($id, $options);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OptionsApi->optionsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant nesnesinin id değeri |
 **options** | [**\Swagger\Client\Model\Options**](../Model/Options.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\Options**](../Model/Options.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **optionsPost**
> \Swagger\Client\Model\Options optionsPost($options)

Varyant Oluşturma

Yeni bir Varyant oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OptionsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$options = new \Swagger\Client\Model\Options(); // \Swagger\Client\Model\Options | nesnesi

try {
    $result = $apiInstance->optionsPost($options);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OptionsApi->optionsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **options** | [**\Swagger\Client\Model\Options**](../Model/Options.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\Options**](../Model/Options.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

