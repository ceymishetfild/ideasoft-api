# Swagger\Client\FavouritedProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**favouritedProductsGet**](FavouritedProductApi.md#favouritedProductsGet) | **GET** /favourited_products | Favori Ürün Listesi Alma
[**favouritedProductsIdDelete**](FavouritedProductApi.md#favouritedProductsIdDelete) | **DELETE** /favourited_products/{id} | Favori Ürün Silme
[**favouritedProductsIdGet**](FavouritedProductApi.md#favouritedProductsIdGet) | **GET** /favourited_products/{id} | Favori Ürün Alma
[**favouritedProductsIdPut**](FavouritedProductApi.md#favouritedProductsIdPut) | **PUT** /favourited_products/{id} | Favori Ürün Güncelleme
[**favouritedProductsPost**](FavouritedProductApi.md#favouritedProductsPost) | **POST** /favourited_products | Favori Ürün Oluşturma


# **favouritedProductsGet**
> \Swagger\Client\Model\FavouritedProduct favouritedProductsGet($sort, $limit, $page, $since_id, $ids, $product)

Favori Ürün Listesi Alma

Favori Ürün listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\FavouritedProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$product = 56; // int | Ürün id

try {
    $result = $apiInstance->favouritedProductsGet($sort, $limit, $page, $since_id, $ids, $product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling FavouritedProductApi->favouritedProductsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **product** | **int**| Ürün id | [optional]

### Return type

[**\Swagger\Client\Model\FavouritedProduct**](../Model/FavouritedProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **favouritedProductsIdDelete**
> favouritedProductsIdDelete($id)

Favori Ürün Silme

Kalıcı olarak ilgili Favori Ürünü siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\FavouritedProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Favori Ürün nesnesinin id değeri

try {
    $apiInstance->favouritedProductsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling FavouritedProductApi->favouritedProductsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Favori Ürün nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **favouritedProductsIdGet**
> \Swagger\Client\Model\FavouritedProduct favouritedProductsIdGet($id)

Favori Ürün Alma

İlgili Favori Ürünü getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\FavouritedProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Favori Ürün nesnesinin id değeri

try {
    $result = $apiInstance->favouritedProductsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling FavouritedProductApi->favouritedProductsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Favori Ürün nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\FavouritedProduct**](../Model/FavouritedProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **favouritedProductsIdPut**
> \Swagger\Client\Model\FavouritedProduct favouritedProductsIdPut($id, $favourited_product)

Favori Ürün Güncelleme

İlgili Favori Ürünü günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\FavouritedProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Favori Ürün nesnesinin id değeri
$favourited_product = new \Swagger\Client\Model\FavouritedProduct(); // \Swagger\Client\Model\FavouritedProduct | nesnesi

try {
    $result = $apiInstance->favouritedProductsIdPut($id, $favourited_product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling FavouritedProductApi->favouritedProductsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Favori Ürün nesnesinin id değeri |
 **favourited_product** | [**\Swagger\Client\Model\FavouritedProduct**](../Model/FavouritedProduct.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\FavouritedProduct**](../Model/FavouritedProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **favouritedProductsPost**
> \Swagger\Client\Model\FavouritedProduct favouritedProductsPost($favourited_product)

Favori Ürün Oluşturma

Yeni bir Favori Ürün oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\FavouritedProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$favourited_product = new \Swagger\Client\Model\FavouritedProduct(); // \Swagger\Client\Model\FavouritedProduct | nesnesi

try {
    $result = $apiInstance->favouritedProductsPost($favourited_product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling FavouritedProductApi->favouritedProductsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **favourited_product** | [**\Swagger\Client\Model\FavouritedProduct**](../Model/FavouritedProduct.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\FavouritedProduct**](../Model/FavouritedProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

