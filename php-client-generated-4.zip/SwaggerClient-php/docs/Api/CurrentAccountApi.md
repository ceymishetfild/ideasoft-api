# Swagger\Client\CurrentAccountApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**currentAccountsGet**](CurrentAccountApi.md#currentAccountsGet) | **GET** /current_accounts | Cari Hesap Listesi Alma
[**currentAccountsIdDelete**](CurrentAccountApi.md#currentAccountsIdDelete) | **DELETE** /current_accounts/{id} | Cari Hesap Silme
[**currentAccountsIdGet**](CurrentAccountApi.md#currentAccountsIdGet) | **GET** /current_accounts/{id} | Cari Hesap Alma
[**currentAccountsIdPut**](CurrentAccountApi.md#currentAccountsIdPut) | **PUT** /current_accounts/{id} | Cari Hesap Güncelleme
[**currentAccountsPost**](CurrentAccountApi.md#currentAccountsPost) | **POST** /current_accounts | Cari Hesap Oluşturma


# **currentAccountsGet**
> \Swagger\Client\Model\CurrentAccount currentAccountsGet($sort, $limit, $page, $since_id, $ids, $code, $title, $start_date, $end_date, $start_updated_at, $end_updated_at, $member)

Cari Hesap Listesi Alma

Cari Hesap listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CurrentAccountApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$code = "code_example"; // string | Cari Hesap kodu
$title = "title_example"; // string | Cari Hesap başlığı
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi
$start_updated_at = new \DateTime("2013-10-20"); // \DateTime | updatedAt değeri için başlangıç tarihi
$end_updated_at = "end_updated_at_example"; // string | updatedAt değeri için bitiş tarihi
$member = "member_example"; // string | İlgili üye

try {
    $result = $apiInstance->currentAccountsGet($sort, $limit, $page, $since_id, $ids, $code, $title, $start_date, $end_date, $start_updated_at, $end_updated_at, $member);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CurrentAccountApi->currentAccountsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **code** | **string**| Cari Hesap kodu | [optional]
 **title** | **string**| Cari Hesap başlığı | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]
 **start_updated_at** | **\DateTime**| updatedAt değeri için başlangıç tarihi | [optional]
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional]
 **member** | **string**| İlgili üye | [optional]

### Return type

[**\Swagger\Client\Model\CurrentAccount**](../Model/CurrentAccount.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **currentAccountsIdDelete**
> currentAccountsIdDelete($id)

Cari Hesap Silme

Kalıcı olarak ilgili Cari Hesabı siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CurrentAccountApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Cari Hesap nesnesinin id değeri

try {
    $apiInstance->currentAccountsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling CurrentAccountApi->currentAccountsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Cari Hesap nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **currentAccountsIdGet**
> \Swagger\Client\Model\CurrentAccount currentAccountsIdGet($id)

Cari Hesap Alma

İlgili Cari Hesabı getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CurrentAccountApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Cari Hesap nesnesinin id değeri

try {
    $result = $apiInstance->currentAccountsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CurrentAccountApi->currentAccountsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Cari Hesap nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\CurrentAccount**](../Model/CurrentAccount.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **currentAccountsIdPut**
> \Swagger\Client\Model\CurrentAccount currentAccountsIdPut($id, $current_account)

Cari Hesap Güncelleme

İlgili Cari Hesabı günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CurrentAccountApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Cari Hesap nesnesinin id değeri
$current_account = new \Swagger\Client\Model\CurrentAccount(); // \Swagger\Client\Model\CurrentAccount | nesnesi

try {
    $result = $apiInstance->currentAccountsIdPut($id, $current_account);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CurrentAccountApi->currentAccountsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Cari Hesap nesnesinin id değeri |
 **current_account** | [**\Swagger\Client\Model\CurrentAccount**](../Model/CurrentAccount.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\CurrentAccount**](../Model/CurrentAccount.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **currentAccountsPost**
> \Swagger\Client\Model\CurrentAccount currentAccountsPost($current_account)

Cari Hesap Oluşturma

Yeni bir Cari Hesap oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CurrentAccountApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$current_account = new \Swagger\Client\Model\CurrentAccount(); // \Swagger\Client\Model\CurrentAccount | nesnesi

try {
    $result = $apiInstance->currentAccountsPost($current_account);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CurrentAccountApi->currentAccountsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **current_account** | [**\Swagger\Client\Model\CurrentAccount**](../Model/CurrentAccount.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\CurrentAccount**](../Model/CurrentAccount.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

