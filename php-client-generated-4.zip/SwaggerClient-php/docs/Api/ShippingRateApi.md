# Swagger\Client\ShippingRateApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shippingRatesGet**](ShippingRateApi.md#shippingRatesGet) | **GET** /shipping_rates | Kargo Oranı Listesi Alma
[**shippingRatesIdDelete**](ShippingRateApi.md#shippingRatesIdDelete) | **DELETE** /shipping_rates/{id} | Kargo Oranı Silme
[**shippingRatesIdGet**](ShippingRateApi.md#shippingRatesIdGet) | **GET** /shipping_rates/{id} | Kargo Oranı Alma
[**shippingRatesIdPut**](ShippingRateApi.md#shippingRatesIdPut) | **PUT** /shipping_rates/{id} | Kargo Oranı Güncelleme
[**shippingRatesPost**](ShippingRateApi.md#shippingRatesPost) | **POST** /shipping_rates | Kargo Oranı Oluşturma


# **shippingRatesGet**
> \Swagger\Client\Model\ShippingRate shippingRatesGet($sort, $limit, $page, $since_id, $ids, $shipping_company, $region)

Kargo Oranı Listesi Alma

Kargo Oranı listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShippingRateApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$shipping_company = 56; // int | Kargo firması id
$region = 56; // int | Bölge id

try {
    $result = $apiInstance->shippingRatesGet($sort, $limit, $page, $since_id, $ids, $shipping_company, $region);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShippingRateApi->shippingRatesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **shipping_company** | **int**| Kargo firması id | [optional]
 **region** | **int**| Bölge id | [optional]

### Return type

[**\Swagger\Client\Model\ShippingRate**](../Model/ShippingRate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shippingRatesIdDelete**
> shippingRatesIdDelete($id)

Kargo Oranı Silme

Kalıcı olarak ilgili Kargo Oranını siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShippingRateApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Kargo Oranı nesnesinin id değeri

try {
    $apiInstance->shippingRatesIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling ShippingRateApi->shippingRatesIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kargo Oranı nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shippingRatesIdGet**
> \Swagger\Client\Model\ShippingRate shippingRatesIdGet($id)

Kargo Oranı Alma

İlgili Kargo Oranını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShippingRateApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Kargo Oranı nesnesinin id değeri

try {
    $result = $apiInstance->shippingRatesIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShippingRateApi->shippingRatesIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kargo Oranı nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\ShippingRate**](../Model/ShippingRate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shippingRatesIdPut**
> \Swagger\Client\Model\ShippingRate shippingRatesIdPut($id, $shipping_rate)

Kargo Oranı Güncelleme

İlgili Kargo Oranını günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShippingRateApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Kargo Oranı nesnesinin id değeri
$shipping_rate = new \Swagger\Client\Model\ShippingRate(); // \Swagger\Client\Model\ShippingRate | nesnesi

try {
    $result = $apiInstance->shippingRatesIdPut($id, $shipping_rate);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShippingRateApi->shippingRatesIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kargo Oranı nesnesinin id değeri |
 **shipping_rate** | [**\Swagger\Client\Model\ShippingRate**](../Model/ShippingRate.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ShippingRate**](../Model/ShippingRate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shippingRatesPost**
> \Swagger\Client\Model\ShippingRate shippingRatesPost($shipping_rate)

Kargo Oranı Oluşturma

Yeni bir Kargo Oranı oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShippingRateApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$shipping_rate = new \Swagger\Client\Model\ShippingRate(); // \Swagger\Client\Model\ShippingRate | nesnesi

try {
    $result = $apiInstance->shippingRatesPost($shipping_rate);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShippingRateApi->shippingRatesPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipping_rate** | [**\Swagger\Client\Model\ShippingRate**](../Model/ShippingRate.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ShippingRate**](../Model/ShippingRate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

