# Swagger\Client\ProductSpecialInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productSpecialInfosGet**](ProductSpecialInfoApi.md#productSpecialInfosGet) | **GET** /product_special_infos | Ürün Özel Bilgi Alanı Listesi Alma
[**productSpecialInfosIdDelete**](ProductSpecialInfoApi.md#productSpecialInfosIdDelete) | **DELETE** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**productSpecialInfosIdGet**](ProductSpecialInfoApi.md#productSpecialInfosIdGet) | **GET** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**productSpecialInfosIdPut**](ProductSpecialInfoApi.md#productSpecialInfosIdPut) | **PUT** /product_special_infos/{id} | Ürün Özel Bilgi Alanı Güncelleme
[**productSpecialInfosPost**](ProductSpecialInfoApi.md#productSpecialInfosPost) | **POST** /product_special_infos | Ürün Özel Bilgi Alanı Oluşturma


# **productSpecialInfosGet**
> \Swagger\Client\Model\ProductSpecialInfo productSpecialInfosGet($sort, $limit, $page, $since_id, $ids, $title, $status, $product)

Ürün Özel Bilgi Alanı Listesi Alma

Ürün Özel Bilgi Alanı listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductSpecialInfoApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$title = "title_example"; // string | Ürün Özel Bilgi Alanı başlığı
$status = "status_example"; // string | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
$product = 56; // int | Ürün id

try {
    $result = $apiInstance->productSpecialInfosGet($sort, $limit, $page, $since_id, $ids, $title, $status, $product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductSpecialInfoApi->productSpecialInfosGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **title** | **string**| Ürün Özel Bilgi Alanı başlığı | [optional]
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional]
 **product** | **int**| Ürün id | [optional]

### Return type

[**\Swagger\Client\Model\ProductSpecialInfo**](../Model/ProductSpecialInfo.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productSpecialInfosIdDelete**
> productSpecialInfosIdDelete($id)

Ürün Özel Bilgi Alanı

Kalıcı olarak ilgili Ürün Özel Bilgi Alanını siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductSpecialInfoApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Özel Bilgi Alanı nesnesinin id değeri

try {
    $apiInstance->productSpecialInfosIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling ProductSpecialInfoApi->productSpecialInfosIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özel Bilgi Alanı nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productSpecialInfosIdGet**
> \Swagger\Client\Model\ProductSpecialInfo productSpecialInfosIdGet($id)

Ürün Özel Bilgi Alanı

İlgili Ürün Özel Bilgi Alanını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductSpecialInfoApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Özel Bilgi Alanı nesnesinin id değeri

try {
    $result = $apiInstance->productSpecialInfosIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductSpecialInfoApi->productSpecialInfosIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özel Bilgi Alanı nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\ProductSpecialInfo**](../Model/ProductSpecialInfo.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productSpecialInfosIdPut**
> \Swagger\Client\Model\ProductSpecialInfo productSpecialInfosIdPut($id, $product_special_info)

Ürün Özel Bilgi Alanı Güncelleme

İlgili Ürün Özel Bilgi Alanını günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductSpecialInfoApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Özel Bilgi Alanı nesnesinin id değeri
$product_special_info = new \Swagger\Client\Model\ProductSpecialInfo(); // \Swagger\Client\Model\ProductSpecialInfo | nesnesi

try {
    $result = $apiInstance->productSpecialInfosIdPut($id, $product_special_info);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductSpecialInfoApi->productSpecialInfosIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özel Bilgi Alanı nesnesinin id değeri |
 **product_special_info** | [**\Swagger\Client\Model\ProductSpecialInfo**](../Model/ProductSpecialInfo.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ProductSpecialInfo**](../Model/ProductSpecialInfo.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productSpecialInfosPost**
> \Swagger\Client\Model\ProductSpecialInfo productSpecialInfosPost($product_special_info)

Ürün Özel Bilgi Alanı Oluşturma

Yeni bir Ürün Özel Bilgi Alanı oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductSpecialInfoApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$product_special_info = new \Swagger\Client\Model\ProductSpecialInfo(); // \Swagger\Client\Model\ProductSpecialInfo | nesnesi

try {
    $result = $apiInstance->productSpecialInfosPost($product_special_info);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductSpecialInfoApi->productSpecialInfosPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_special_info** | [**\Swagger\Client\Model\ProductSpecialInfo**](../Model/ProductSpecialInfo.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ProductSpecialInfo**](../Model/ProductSpecialInfo.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

