# Swagger\Client\TownGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**townGroupsGet**](TownGroupApi.md#townGroupsGet) | **GET** /town_groups | İlçe Grubu Listesi Alma
[**townGroupsIdDelete**](TownGroupApi.md#townGroupsIdDelete) | **DELETE** /town_groups/{id} | İlçe Grubu Silme
[**townGroupsIdGet**](TownGroupApi.md#townGroupsIdGet) | **GET** /town_groups/{id} | İlçe Grubu Alma
[**townGroupsIdPut**](TownGroupApi.md#townGroupsIdPut) | **PUT** /town_groups/{id} | İlçe Grubu Güncelleme
[**townGroupsPost**](TownGroupApi.md#townGroupsPost) | **POST** /town_groups | İlçe Grubu Oluşturma


# **townGroupsGet**
> \Swagger\Client\Model\TownGroup townGroupsGet($sort, $limit, $page, $since_id, $ids, $name)

İlçe Grubu Listesi Alma

İlçe Grubu listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\TownGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$name = "name_example"; // string | İlçe Grubu adı

try {
    $result = $apiInstance->townGroupsGet($sort, $limit, $page, $since_id, $ids, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TownGroupApi->townGroupsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **name** | **string**| İlçe Grubu adı | [optional]

### Return type

[**\Swagger\Client\Model\TownGroup**](../Model/TownGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **townGroupsIdDelete**
> townGroupsIdDelete($id)

İlçe Grubu Silme

Kalıcı olarak ilgili İlçe Grubunu siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\TownGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | İlçe Grubu nesnesinin id değeri

try {
    $apiInstance->townGroupsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling TownGroupApi->townGroupsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe Grubu nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **townGroupsIdGet**
> \Swagger\Client\Model\TownGroup townGroupsIdGet($id)

İlçe Grubu Alma

İlgili İlçe Grubunu getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\TownGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | İlçe Grubu nesnesinin id değeri

try {
    $result = $apiInstance->townGroupsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TownGroupApi->townGroupsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe Grubu nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\TownGroup**](../Model/TownGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **townGroupsIdPut**
> \Swagger\Client\Model\TownGroup townGroupsIdPut($id, $town_group)

İlçe Grubu Güncelleme

İlgili İlçe Grubunu günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\TownGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | İlçe Grubu nesnesinin id değeri
$town_group = new \Swagger\Client\Model\TownGroup(); // \Swagger\Client\Model\TownGroup | nesnesi

try {
    $result = $apiInstance->townGroupsIdPut($id, $town_group);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TownGroupApi->townGroupsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe Grubu nesnesinin id değeri |
 **town_group** | [**\Swagger\Client\Model\TownGroup**](../Model/TownGroup.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\TownGroup**](../Model/TownGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **townGroupsPost**
> \Swagger\Client\Model\TownGroup townGroupsPost($town_group)

İlçe Grubu Oluşturma

Yeni bir İlçe Grubu oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\TownGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$town_group = new \Swagger\Client\Model\TownGroup(); // \Swagger\Client\Model\TownGroup | nesnesi

try {
    $result = $apiInstance->townGroupsPost($town_group);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TownGroupApi->townGroupsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **town_group** | [**\Swagger\Client\Model\TownGroup**](../Model/TownGroup.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\TownGroup**](../Model/TownGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

