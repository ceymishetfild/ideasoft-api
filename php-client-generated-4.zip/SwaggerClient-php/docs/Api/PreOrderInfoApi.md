# Swagger\Client\PreOrderInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**preOrderInfosGet**](PreOrderInfoApi.md#preOrderInfosGet) | **GET** /pre_order_infos | Sipariş Öncesi Bilgisi Listesi Alma
[**preOrderInfosIdDelete**](PreOrderInfoApi.md#preOrderInfosIdDelete) | **DELETE** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Silme
[**preOrderInfosIdGet**](PreOrderInfoApi.md#preOrderInfosIdGet) | **GET** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Alma
[**preOrderInfosIdPut**](PreOrderInfoApi.md#preOrderInfosIdPut) | **PUT** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Güncelleme
[**preOrderInfosPost**](PreOrderInfoApi.md#preOrderInfosPost) | **POST** /pre_order_infos | Sipariş Öncesi Bilgisi Oluşturma


# **preOrderInfosGet**
> \Swagger\Client\Model\PreOrderInfo preOrderInfosGet($sort, $limit, $page, $since_id, $ids, $session_id, $start_date, $end_date, $start_updated_at, $end_updated_at)

Sipariş Öncesi Bilgisi Listesi Alma

Sipariş Öncesi Bilgisi listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\PreOrderInfoApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$session_id = "session_id_example"; // string | Sipariş Öncesi Bilgisi session id.
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi
$start_updated_at = new \DateTime("2013-10-20"); // \DateTime | updatedAt değeri için başlangıç tarihi
$end_updated_at = "end_updated_at_example"; // string | updatedAt değeri için bitiş tarihi

try {
    $result = $apiInstance->preOrderInfosGet($sort, $limit, $page, $since_id, $ids, $session_id, $start_date, $end_date, $start_updated_at, $end_updated_at);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PreOrderInfoApi->preOrderInfosGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **session_id** | **string**| Sipariş Öncesi Bilgisi session id. | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]
 **start_updated_at** | **\DateTime**| updatedAt değeri için başlangıç tarihi | [optional]
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**\Swagger\Client\Model\PreOrderInfo**](../Model/PreOrderInfo.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **preOrderInfosIdDelete**
> preOrderInfosIdDelete($id)

Sipariş Öncesi Bilgisi Silme

Kalıcı olarak ilgili Sipariş Öncesi Bilgisini siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\PreOrderInfoApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sipariş Öncesi Bilgisi nesnesinin id değeri

try {
    $apiInstance->preOrderInfosIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling PreOrderInfoApi->preOrderInfosIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Öncesi Bilgisi nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **preOrderInfosIdGet**
> \Swagger\Client\Model\PreOrderInfo preOrderInfosIdGet($id)

Sipariş Öncesi Bilgisi Alma

İlgili Sipariş Öncesi Bilgisini getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\PreOrderInfoApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sipariş Öncesi Bilgisi nesnesinin id değeri

try {
    $result = $apiInstance->preOrderInfosIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PreOrderInfoApi->preOrderInfosIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Öncesi Bilgisi nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\PreOrderInfo**](../Model/PreOrderInfo.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **preOrderInfosIdPut**
> \Swagger\Client\Model\PreOrderInfo preOrderInfosIdPut($id, $pre_order_info)

Sipariş Öncesi Bilgisi Güncelleme

İlgili Sipariş Öncesi Bilgisini günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\PreOrderInfoApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sipariş Öncesi Bilgisi nesnesinin id değeri
$pre_order_info = new \Swagger\Client\Model\PreOrderInfo(); // \Swagger\Client\Model\PreOrderInfo | nesnesi

try {
    $result = $apiInstance->preOrderInfosIdPut($id, $pre_order_info);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PreOrderInfoApi->preOrderInfosIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Öncesi Bilgisi nesnesinin id değeri |
 **pre_order_info** | [**\Swagger\Client\Model\PreOrderInfo**](../Model/PreOrderInfo.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\PreOrderInfo**](../Model/PreOrderInfo.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **preOrderInfosPost**
> \Swagger\Client\Model\PreOrderInfo preOrderInfosPost($pre_order_info)

Sipariş Öncesi Bilgisi Oluşturma

Yeni bir Sipariş Öncesi Bilgisi oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\PreOrderInfoApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$pre_order_info = new \Swagger\Client\Model\PreOrderInfo(); // \Swagger\Client\Model\PreOrderInfo | nesnesi

try {
    $result = $apiInstance->preOrderInfosPost($pre_order_info);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PreOrderInfoApi->preOrderInfosPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pre_order_info** | [**\Swagger\Client\Model\PreOrderInfo**](../Model/PreOrderInfo.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\PreOrderInfo**](../Model/PreOrderInfo.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

