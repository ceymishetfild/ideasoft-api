# Swagger\Client\TownApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**townsGet**](TownApi.md#townsGet) | **GET** /towns | İlçe Listesi Alma
[**townsIdDelete**](TownApi.md#townsIdDelete) | **DELETE** /towns/{id} | İlçe Silme
[**townsIdGet**](TownApi.md#townsIdGet) | **GET** /towns/{id} | İlçe Alma
[**townsIdPut**](TownApi.md#townsIdPut) | **PUT** /towns/{id} | İlçe Güncelleme
[**townsPost**](TownApi.md#townsPost) | **POST** /towns | İlçe Oluşturma


# **townsGet**
> \Swagger\Client\Model\Town townsGet($sort, $limit, $page, $since_id, $ids, $location, $town_group, $name, $status)

İlçe Listesi Alma

İlçe listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\TownApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$location = 56; // int | Şehir id
$town_group = 56; // int | İlçe grubu id
$name = "name_example"; // string | İlçe adı.
$status = "status_example"; // string | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif

try {
    $result = $apiInstance->townsGet($sort, $limit, $page, $since_id, $ids, $location, $town_group, $name, $status);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TownApi->townsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **location** | **int**| Şehir id | [optional]
 **town_group** | **int**| İlçe grubu id | [optional]
 **name** | **string**| İlçe adı. | [optional]
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional]

### Return type

[**\Swagger\Client\Model\Town**](../Model/Town.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **townsIdDelete**
> townsIdDelete($id)

İlçe Silme

Kalıcı olarak ilgili İlçeyi siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\TownApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | İlçe nesnesinin id değeri

try {
    $apiInstance->townsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling TownApi->townsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **townsIdGet**
> \Swagger\Client\Model\Town townsIdGet($id)

İlçe Alma

İlgili İlçeyi getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\TownApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | İlçe nesnesinin id değeri

try {
    $result = $apiInstance->townsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TownApi->townsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\Town**](../Model/Town.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **townsIdPut**
> \Swagger\Client\Model\Town townsIdPut($id, $town)

İlçe Güncelleme

İlgili İlçeyi günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\TownApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | İlçe nesnesinin id değeri
$town = new \Swagger\Client\Model\Town(); // \Swagger\Client\Model\Town | nesnesi

try {
    $result = $apiInstance->townsIdPut($id, $town);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TownApi->townsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe nesnesinin id değeri |
 **town** | [**\Swagger\Client\Model\Town**](../Model/Town.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\Town**](../Model/Town.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **townsPost**
> \Swagger\Client\Model\Town townsPost($town)

İlçe Oluşturma

Yeni bir İlçe oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\TownApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$town = new \Swagger\Client\Model\Town(); // \Swagger\Client\Model\Town | nesnesi

try {
    $result = $apiInstance->townsPost($town);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TownApi->townsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **town** | [**\Swagger\Client\Model\Town**](../Model/Town.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\Town**](../Model/Town.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

