# Swagger\Client\ProductToCategoryApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productToCategoriesGet**](ProductToCategoryApi.md#productToCategoriesGet) | **GET** /product_to_categories | Ürün Kategori Bağı Listesi Alma
[**productToCategoriesIdDelete**](ProductToCategoryApi.md#productToCategoriesIdDelete) | **DELETE** /product_to_categories/{id} | Ürün Kategori Bağı Silme
[**productToCategoriesIdGet**](ProductToCategoryApi.md#productToCategoriesIdGet) | **GET** /product_to_categories/{id} | Ürün Kategori Bağı Alma
[**productToCategoriesIdPut**](ProductToCategoryApi.md#productToCategoriesIdPut) | **PUT** /product_to_categories/{id} | Ürün Kategori Bağı Güncelleme
[**productToCategoriesPost**](ProductToCategoryApi.md#productToCategoriesPost) | **POST** /product_to_categories | Ürün Kategori Bağı Oluşturma


# **productToCategoriesGet**
> \Swagger\Client\Model\ProductToCategory productToCategoriesGet($sort, $limit, $page, $since_id, $ids, $product, $category)

Ürün Kategori Bağı Listesi Alma

Ürün Kategori Bağı listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductToCategoryApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$product = 56; // int | Ürün id
$category = 56; // int | Kategori id

try {
    $result = $apiInstance->productToCategoriesGet($sort, $limit, $page, $since_id, $ids, $product, $category);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductToCategoryApi->productToCategoriesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **product** | **int**| Ürün id | [optional]
 **category** | **int**| Kategori id | [optional]

### Return type

[**\Swagger\Client\Model\ProductToCategory**](../Model/ProductToCategory.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productToCategoriesIdDelete**
> productToCategoriesIdDelete($id)

Ürün Kategori Bağı Silme

Kalıcı olarak ilgili Ürün Kategori Bağını siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductToCategoryApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Kategori Bağı nesnesinin id değeri

try {
    $apiInstance->productToCategoriesIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling ProductToCategoryApi->productToCategoriesIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Kategori Bağı nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productToCategoriesIdGet**
> \Swagger\Client\Model\ProductToCategory productToCategoriesIdGet($id)

Ürün Kategori Bağı Alma

İlgili Ürün Kategori Bağını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductToCategoryApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Kategori Bağı nesnesinin id değeri

try {
    $result = $apiInstance->productToCategoriesIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductToCategoryApi->productToCategoriesIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Kategori Bağı nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\ProductToCategory**](../Model/ProductToCategory.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productToCategoriesIdPut**
> \Swagger\Client\Model\ProductToCategory productToCategoriesIdPut($id, $product_to_category)

Ürün Kategori Bağı Güncelleme

İlgili Ürün Kategori Bağını günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductToCategoryApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Kategori Bağı nesnesinin id değeri
$product_to_category = new \Swagger\Client\Model\ProductToCategory(); // \Swagger\Client\Model\ProductToCategory | nesnesi

try {
    $result = $apiInstance->productToCategoriesIdPut($id, $product_to_category);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductToCategoryApi->productToCategoriesIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Kategori Bağı nesnesinin id değeri |
 **product_to_category** | [**\Swagger\Client\Model\ProductToCategory**](../Model/ProductToCategory.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ProductToCategory**](../Model/ProductToCategory.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productToCategoriesPost**
> \Swagger\Client\Model\ProductToCategory productToCategoriesPost($product_to_category)

Ürün Kategori Bağı Oluşturma

Yeni bir Ürün Kategori Bağı oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductToCategoryApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$product_to_category = new \Swagger\Client\Model\ProductToCategory(); // \Swagger\Client\Model\ProductToCategory | nesnesi

try {
    $result = $apiInstance->productToCategoriesPost($product_to_category);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductToCategoryApi->productToCategoriesPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_to_category** | [**\Swagger\Client\Model\ProductToCategory**](../Model/ProductToCategory.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ProductToCategory**](../Model/ProductToCategory.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

