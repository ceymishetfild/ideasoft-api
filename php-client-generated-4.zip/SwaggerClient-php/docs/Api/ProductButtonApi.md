# Swagger\Client\ProductButtonApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productButtonsGet**](ProductButtonApi.md#productButtonsGet) | **GET** /product_buttons | Ürün ve Stok Butonu Listesi Alma
[**productButtonsIdDelete**](ProductButtonApi.md#productButtonsIdDelete) | **DELETE** /product_buttons/{id} | Ürün ve Stok Butonu Silme
[**productButtonsIdGet**](ProductButtonApi.md#productButtonsIdGet) | **GET** /product_buttons/{id} | Ürün ve Stok Butonu Alma
[**productButtonsIdPut**](ProductButtonApi.md#productButtonsIdPut) | **PUT** /product_buttons/{id} | Ürün ve Stok Butonu Güncelleme
[**productButtonsPost**](ProductButtonApi.md#productButtonsPost) | **POST** /product_buttons | Ürün ve Stok Butonu Oluşturma


# **productButtonsGet**
> \Swagger\Client\Model\ProductButton productButtonsGet($sort, $limit, $page, $since_id, $ids, $fast_shipping, $same_day_shipping, $three_days_delivery, $five_days_delivery, $seven_days_delivery, $free_shipping, $delivery_from_stock, $pre_ordered_product, $ask_stock, $campaigned_product, $product)

Ürün ve Stok Butonu Listesi Alma

Ürün ve Stok Butonu listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductButtonApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$fast_shipping = "fast_shipping_example"; // string | Hızlı Gönderi butonuna sahip ürünler<code>0</code><br><code>1</code>
$same_day_shipping = "same_day_shipping_example"; // string | Aynı Gün Kargo butonuna sahip ürünler<code>0</code><br><code>1</code>
$three_days_delivery = "three_days_delivery_example"; // string | 3 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
$five_days_delivery = "five_days_delivery_example"; // string | 5 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
$seven_days_delivery = "seven_days_delivery_example"; // string | 7 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
$free_shipping = "free_shipping_example"; // string | Kargo Bedava butonuna sahip ürünler<code>0</code><br><code>1</code>
$delivery_from_stock = "delivery_from_stock_example"; // string | Stoktan Teslim butonuna sahip ürünler<code>0</code><br><code>1</code>
$pre_ordered_product = "pre_ordered_product_example"; // string | Ön Siparişli Ürün butonuna sahip ürünler<code>0</code><br><code>1</code>
$ask_stock = "ask_stock_example"; // string | Stok Sorunuz butonuna sahip ürünler<code>0</code><br><code>1</code>
$campaigned_product = "campaigned_product_example"; // string | Kampanyalı Ürün butonuna sahip ürünler<code>0</code><br><code>1</code>
$product = 56; // int | Ürün id

try {
    $result = $apiInstance->productButtonsGet($sort, $limit, $page, $since_id, $ids, $fast_shipping, $same_day_shipping, $three_days_delivery, $five_days_delivery, $seven_days_delivery, $free_shipping, $delivery_from_stock, $pre_ordered_product, $ask_stock, $campaigned_product, $product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductButtonApi->productButtonsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **fast_shipping** | **string**| Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional]
 **same_day_shipping** | **string**| Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional]
 **three_days_delivery** | **string**| 3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional]
 **five_days_delivery** | **string**| 5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional]
 **seven_days_delivery** | **string**| 7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional]
 **free_shipping** | **string**| Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional]
 **delivery_from_stock** | **string**| Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional]
 **pre_ordered_product** | **string**| Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional]
 **ask_stock** | **string**| Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional]
 **campaigned_product** | **string**| Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional]
 **product** | **int**| Ürün id | [optional]

### Return type

[**\Swagger\Client\Model\ProductButton**](../Model/ProductButton.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productButtonsIdDelete**
> productButtonsIdDelete($id)

Ürün ve Stok Butonu Silme

Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductButtonApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün ve Stok Butonu nesnesinin id değeri

try {
    $apiInstance->productButtonsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling ProductButtonApi->productButtonsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün ve Stok Butonu nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productButtonsIdGet**
> \Swagger\Client\Model\ProductButton productButtonsIdGet($id)

Ürün ve Stok Butonu Alma

İlgili Ürün ve Stok Butonunu getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductButtonApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün ve Stok Butonu nesnesinin id değeri

try {
    $result = $apiInstance->productButtonsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductButtonApi->productButtonsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün ve Stok Butonu nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\ProductButton**](../Model/ProductButton.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productButtonsIdPut**
> \Swagger\Client\Model\ProductButton productButtonsIdPut($id, $product_button)

Ürün ve Stok Butonu Güncelleme

İlgili Ürün ve Stok Butonunu günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductButtonApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün ve Stok Butonu nesnesinin id değeri
$product_button = new \Swagger\Client\Model\ProductButton(); // \Swagger\Client\Model\ProductButton | nesnesi

try {
    $result = $apiInstance->productButtonsIdPut($id, $product_button);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductButtonApi->productButtonsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün ve Stok Butonu nesnesinin id değeri |
 **product_button** | [**\Swagger\Client\Model\ProductButton**](../Model/ProductButton.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ProductButton**](../Model/ProductButton.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productButtonsPost**
> \Swagger\Client\Model\ProductButton productButtonsPost($product_button)

Ürün ve Stok Butonu Oluşturma

Yeni bir Ürün ve Stok Butonu oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductButtonApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$product_button = new \Swagger\Client\Model\ProductButton(); // \Swagger\Client\Model\ProductButton | nesnesi

try {
    $result = $apiInstance->productButtonsPost($product_button);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductButtonApi->productButtonsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_button** | [**\Swagger\Client\Model\ProductButton**](../Model/ProductButton.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ProductButton**](../Model/ProductButton.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

