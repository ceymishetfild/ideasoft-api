# Swagger\Client\OptionToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**optionToProductsGet**](OptionToProductApi.md#optionToProductsGet) | **GET** /option_to_products | Varyant Ürün Bağı Listesi Alma
[**optionToProductsIdDelete**](OptionToProductApi.md#optionToProductsIdDelete) | **DELETE** /option_to_products/{id} | Varyant Ürün Bağı Silme
[**optionToProductsIdGet**](OptionToProductApi.md#optionToProductsIdGet) | **GET** /option_to_products/{id} | Varyant Ürün Bağı Alma
[**optionToProductsIdPut**](OptionToProductApi.md#optionToProductsIdPut) | **PUT** /option_to_products/{id} | Varyant Ürün Bağı Güncelleme
[**optionToProductsPost**](OptionToProductApi.md#optionToProductsPost) | **POST** /option_to_products | Varyant Ürün Bağı Oluşturma


# **optionToProductsGet**
> \Swagger\Client\Model\OptionToProduct optionToProductsGet($sort, $limit, $page, $since_id, $ids, $product, $option_group, $option, $parent_product_id)

Varyant Ürün Bağı Listesi Alma

Varyant Ürün Bağı listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OptionToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$product = 56; // int | Ürün id
$option_group = 56; // int | Varyant Grubu id
$option = 56; // int | Varyant id
$parent_product_id = 56; // int | Ana Ürün id

try {
    $result = $apiInstance->optionToProductsGet($sort, $limit, $page, $since_id, $ids, $product, $option_group, $option, $parent_product_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OptionToProductApi->optionToProductsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **product** | **int**| Ürün id | [optional]
 **option_group** | **int**| Varyant Grubu id | [optional]
 **option** | **int**| Varyant id | [optional]
 **parent_product_id** | **int**| Ana Ürün id | [optional]

### Return type

[**\Swagger\Client\Model\OptionToProduct**](../Model/OptionToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **optionToProductsIdDelete**
> optionToProductsIdDelete($id)

Varyant Ürün Bağı Silme

Kalıcı olarak ilgili Varyant Ürün Bağını siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OptionToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Varyant Ürün Bağı nesnesinin id değeri

try {
    $apiInstance->optionToProductsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling OptionToProductApi->optionToProductsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant Ürün Bağı nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **optionToProductsIdGet**
> \Swagger\Client\Model\OptionToProduct optionToProductsIdGet($id)

Varyant Ürün Bağı Alma

İlgili Varyant Ürün Bağını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OptionToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Varyant Ürün Bağı nesnesinin id değeri

try {
    $result = $apiInstance->optionToProductsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OptionToProductApi->optionToProductsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant Ürün Bağı nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\OptionToProduct**](../Model/OptionToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **optionToProductsIdPut**
> \Swagger\Client\Model\OptionToProduct optionToProductsIdPut($id, $option_to_product)

Varyant Ürün Bağı Güncelleme

İlgili Varyant Ürün Bağını günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OptionToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Varyant Ürün Bağı nesnesinin id değeri
$option_to_product = new \Swagger\Client\Model\OptionToProduct(); // \Swagger\Client\Model\OptionToProduct | nesnesi

try {
    $result = $apiInstance->optionToProductsIdPut($id, $option_to_product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OptionToProductApi->optionToProductsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant Ürün Bağı nesnesinin id değeri |
 **option_to_product** | [**\Swagger\Client\Model\OptionToProduct**](../Model/OptionToProduct.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\OptionToProduct**](../Model/OptionToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **optionToProductsPost**
> \Swagger\Client\Model\OptionToProduct optionToProductsPost($option_to_product)

Varyant Ürün Bağı Oluşturma

Yeni bir Varyant Ürün Bağı oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OptionToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$option_to_product = new \Swagger\Client\Model\OptionToProduct(); // \Swagger\Client\Model\OptionToProduct | nesnesi

try {
    $result = $apiInstance->optionToProductsPost($option_to_product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OptionToProductApi->optionToProductsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **option_to_product** | [**\Swagger\Client\Model\OptionToProduct**](../Model/OptionToProduct.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\OptionToProduct**](../Model/OptionToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

