# Swagger\Client\PaymentGatewayApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**paymentGatewaysGet**](PaymentGatewayApi.md#paymentGatewaysGet) | **GET** /payment_gateways | Ödeme Kanalı Listesi Alma
[**paymentGatewaysIdGet**](PaymentGatewayApi.md#paymentGatewaysIdGet) | **GET** /payment_gateways/{id} | Ödeme Kanalı Alma


# **paymentGatewaysGet**
> \Swagger\Client\Model\PaymentGateway paymentGatewaysGet($sort, $limit, $page, $since_id, $ids, $code, $name)

Ödeme Kanalı Listesi Alma

Ödeme Kanalı listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\PaymentGatewayApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$code = "code_example"; // string | Ödeme kanalı notu
$name = "name_example"; // string | Ödeme kanalı adı

try {
    $result = $apiInstance->paymentGatewaysGet($sort, $limit, $page, $since_id, $ids, $code, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PaymentGatewayApi->paymentGatewaysGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **code** | **string**| Ödeme kanalı notu | [optional]
 **name** | **string**| Ödeme kanalı adı | [optional]

### Return type

[**\Swagger\Client\Model\PaymentGateway**](../Model/PaymentGateway.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **paymentGatewaysIdGet**
> \Swagger\Client\Model\PaymentGateway paymentGatewaysIdGet($id)

Ödeme Kanalı Alma

İlgili Ödeme Kanalını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\PaymentGatewayApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ödeme Kanalı nesnesinin id değeri

try {
    $result = $apiInstance->paymentGatewaysIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PaymentGatewayApi->paymentGatewaysIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ödeme Kanalı nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\PaymentGateway**](../Model/PaymentGateway.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

