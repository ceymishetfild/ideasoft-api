# Swagger\Client\ShippingCompanyApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shippingCompaniesGet**](ShippingCompanyApi.md#shippingCompaniesGet) | **GET** /shipping_companies | Kargo Firması Listesi Alma
[**shippingCompaniesIdDelete**](ShippingCompanyApi.md#shippingCompaniesIdDelete) | **DELETE** /shipping_companies/{id} | Kargo Firması Silme
[**shippingCompaniesIdGet**](ShippingCompanyApi.md#shippingCompaniesIdGet) | **GET** /shipping_companies/{id} | Kargo Firması Alma
[**shippingCompaniesIdPut**](ShippingCompanyApi.md#shippingCompaniesIdPut) | **PUT** /shipping_companies/{id} | Kargo Firması Güncelleme
[**shippingCompaniesPost**](ShippingCompanyApi.md#shippingCompaniesPost) | **POST** /shipping_companies | Kargo Firması Oluşturma


# **shippingCompaniesGet**
> \Swagger\Client\Model\ShippingCompany shippingCompaniesGet($sort, $limit, $page, $since_id, $ids, $name, $company_code, $payment_type, $shipping_provider)

Kargo Firması Listesi Alma

Kargo Firması listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShippingCompanyApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$name = "name_example"; // string | Kargo firması adı
$company_code = "company_code_example"; // string | Kargo firması kodu
$payment_type = "payment_type_example"; // string | Ödeme Tipi şu değerleri alabilir: <br><code>cash_on_delivery</code> : Alıcı ödemeli<br><code>standart_delivery</code> : Gönderici ödemeli<br><code>not_applicable</code> : Bu alan için uygulanabilir değil
$shipping_provider = 56; // int | Teslimat Hizmeti Sağlayıcısı id

try {
    $result = $apiInstance->shippingCompaniesGet($sort, $limit, $page, $since_id, $ids, $name, $company_code, $payment_type, $shipping_provider);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShippingCompanyApi->shippingCompaniesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **name** | **string**| Kargo firması adı | [optional]
 **company_code** | **string**| Kargo firması kodu | [optional]
 **payment_type** | **string**| Ödeme Tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil | [optional]
 **shipping_provider** | **int**| Teslimat Hizmeti Sağlayıcısı id | [optional]

### Return type

[**\Swagger\Client\Model\ShippingCompany**](../Model/ShippingCompany.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shippingCompaniesIdDelete**
> shippingCompaniesIdDelete($id)

Kargo Firması Silme

Kalıcı olarak ilgili Kargo Firmasını siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShippingCompanyApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Kargo Firması nesnesinin id değeri

try {
    $apiInstance->shippingCompaniesIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling ShippingCompanyApi->shippingCompaniesIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kargo Firması nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shippingCompaniesIdGet**
> \Swagger\Client\Model\ShippingCompany shippingCompaniesIdGet($id)

Kargo Firması Alma

İlgili Kargo Firmasını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShippingCompanyApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Kargo Firması nesnesinin id değeri

try {
    $result = $apiInstance->shippingCompaniesIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShippingCompanyApi->shippingCompaniesIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kargo Firması nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\ShippingCompany**](../Model/ShippingCompany.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shippingCompaniesIdPut**
> \Swagger\Client\Model\ShippingCompany shippingCompaniesIdPut($id, $shipping_company)

Kargo Firması Güncelleme

İlgili Kargo Firmasını günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShippingCompanyApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Kargo Firması nesnesinin id değeri
$shipping_company = new \Swagger\Client\Model\ShippingCompany(); // \Swagger\Client\Model\ShippingCompany | nesnesi

try {
    $result = $apiInstance->shippingCompaniesIdPut($id, $shipping_company);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShippingCompanyApi->shippingCompaniesIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kargo Firması nesnesinin id değeri |
 **shipping_company** | [**\Swagger\Client\Model\ShippingCompany**](../Model/ShippingCompany.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ShippingCompany**](../Model/ShippingCompany.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shippingCompaniesPost**
> \Swagger\Client\Model\ShippingCompany shippingCompaniesPost($shipping_company)

Kargo Firması Oluşturma

Yeni bir Kargo Firması oluşturur relationship.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShippingCompanyApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$shipping_company = new \Swagger\Client\Model\ShippingCompany(); // \Swagger\Client\Model\ShippingCompany | nesnesi

try {
    $result = $apiInstance->shippingCompaniesPost($shipping_company);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShippingCompanyApi->shippingCompaniesPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipping_company** | [**\Swagger\Client\Model\ShippingCompany**](../Model/ShippingCompany.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ShippingCompany**](../Model/ShippingCompany.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

