# Swagger\Client\MemberApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**membersChartsGet**](MemberApi.md#membersChartsGet) | **GET** /members/charts | Üye Grafik Aksiyonu
[**membersCombinedGet**](MemberApi.md#membersCombinedGet) | **GET** /members/combined | Üye Birleşik Aksiyonu
[**membersGet**](MemberApi.md#membersGet) | **GET** /members | Üye Listesi Alma
[**membersIdDelete**](MemberApi.md#membersIdDelete) | **DELETE** /members/{id} | Üye Silme
[**membersIdGet**](MemberApi.md#membersIdGet) | **GET** /members/{id} | Üye Alma
[**membersIdPut**](MemberApi.md#membersIdPut) | **PUT** /members/{id} | Üye Güncelleme
[**membersPost**](MemberApi.md#membersPost) | **POST** /members | Üye Oluşturma


# **membersChartsGet**
> \Swagger\Client\Model\Member membersChartsGet($time_frame, $start_date)

Üye Grafik Aksiyonu

Zaman bazında üye genel istatistiklerini getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$time_frame = "time_frame_example"; // string | Şu değerleri olabilir: full, year, month or week
$start_date = "start_date_example"; // string | Zaman aralığının başlangıcı

try {
    $result = $apiInstance->membersChartsGet($time_frame, $start_date);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MemberApi->membersChartsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **time_frame** | **string**| Şu değerleri olabilir: full, year, month or week |
 **start_date** | **string**| Zaman aralığının başlangıcı |

### Return type

[**\Swagger\Client\Model\Member**](../Model/Member.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **membersCombinedGet**
> \Swagger\Client\Model\Member membersCombinedGet()

Üye Birleşik Aksiyonu

Bugün, aylık, yıllık ve toplam üye oturum açma istatistiklerini totalCount cinsinden getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\MemberApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->membersCombinedGet();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MemberApi->membersCombinedGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\Member**](../Model/Member.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **membersGet**
> \Swagger\Client\Model\Member membersGet($sort, $limit, $page, $since_id, $ids, $firstname, $surname, $email, $password, $gender, $mobile_phone_number, $phone_number, $member_group, $location, $country, $referred_member, $q, $start_date, $end_date, $start_updated_at, $end_updated_at)

Üye Listesi Alma

Üye listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$firstname = "firstname_example"; // string | Adı
$surname = "surname_example"; // string | Soyadı
$email = "email_example"; // string | e-mail adresi
$password = "password_example"; // string | Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri
$gender = "gender_example"; // string | Cinsiyet şu değerleri alabilir: <br><code>male</code> : Erkek<br><code>female</code> : Kadın
$mobile_phone_number = "mobile_phone_number_example"; // string | Üye mobil telefon numarası
$phone_number = "phone_number_example"; // string | Üye telefon numarası
$member_group = 56; // int | Üye Grubu id
$location = 56; // int | Şehir id
$country = 56; // int | Ülke id
$referred_member = 56; // int | Tavsiye Üye id
$q = array("q_example"); // string[] | Üye arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;]
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi
$start_updated_at = new \DateTime("2013-10-20"); // \DateTime | updatedAt değeri için başlangıç tarihi
$end_updated_at = "end_updated_at_example"; // string | updatedAt değeri için bitiş tarihi

try {
    $result = $apiInstance->membersGet($sort, $limit, $page, $since_id, $ids, $firstname, $surname, $email, $password, $gender, $mobile_phone_number, $phone_number, $member_group, $location, $country, $referred_member, $q, $start_date, $end_date, $start_updated_at, $end_updated_at);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MemberApi->membersGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **firstname** | **string**| Adı | [optional]
 **surname** | **string**| Soyadı | [optional]
 **email** | **string**| e-mail adresi | [optional]
 **password** | **string**| Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri | [optional]
 **gender** | **string**| Cinsiyet şu değerleri alabilir: &lt;br&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın | [optional]
 **mobile_phone_number** | **string**| Üye mobil telefon numarası | [optional]
 **phone_number** | **string**| Üye telefon numarası | [optional]
 **member_group** | **int**| Üye Grubu id | [optional]
 **location** | **int**| Şehir id | [optional]
 **country** | **int**| Ülke id | [optional]
 **referred_member** | **int**| Tavsiye Üye id | [optional]
 **q** | [**string[]**](../Model/string.md)| Üye arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]
 **start_updated_at** | **\DateTime**| updatedAt değeri için başlangıç tarihi | [optional]
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**\Swagger\Client\Model\Member**](../Model/Member.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **membersIdDelete**
> membersIdDelete($id)

Üye Silme

Kalıcı olarak ilgili Üyeyi siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Üye nesnesinin id değeri

try {
    $apiInstance->membersIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling MemberApi->membersIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **membersIdGet**
> \Swagger\Client\Model\Member membersIdGet($id)

Üye Alma

İlgili Üyeyi getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Üye nesnesinin id değeri

try {
    $result = $apiInstance->membersIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MemberApi->membersIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\Member**](../Model/Member.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **membersIdPut**
> \Swagger\Client\Model\Member membersIdPut($id, $member)

Üye Güncelleme

İlgili Üyeyi günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Üye nesnesinin id değeri
$member = new \Swagger\Client\Model\Member(); // \Swagger\Client\Model\Member | nesnesi

try {
    $result = $apiInstance->membersIdPut($id, $member);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MemberApi->membersIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye nesnesinin id değeri |
 **member** | [**\Swagger\Client\Model\Member**](../Model/Member.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\Member**](../Model/Member.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **membersPost**
> \Swagger\Client\Model\Member membersPost($member)

Üye Oluşturma

Yeni bir Üye oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MemberApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$member = new \Swagger\Client\Model\Member(); // \Swagger\Client\Model\Member | nesnesi

try {
    $result = $apiInstance->membersPost($member);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MemberApi->membersPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member** | [**\Swagger\Client\Model\Member**](../Model/Member.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\Member**](../Model/Member.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

