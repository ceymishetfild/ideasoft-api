# Swagger\Client\OrderRefundRequestItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**orderRefundRequestItemsGet**](OrderRefundRequestItemApi.md#orderRefundRequestItemsGet) | **GET** /order_refund_request_items | Sipariş İptal Talebi Kalemi Listesi Alma
[**orderRefundRequestItemsIdDelete**](OrderRefundRequestItemApi.md#orderRefundRequestItemsIdDelete) | **DELETE** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Silme
[**orderRefundRequestItemsIdGet**](OrderRefundRequestItemApi.md#orderRefundRequestItemsIdGet) | **GET** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Alma
[**orderRefundRequestItemsIdPut**](OrderRefundRequestItemApi.md#orderRefundRequestItemsIdPut) | **PUT** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Güncelleme
[**orderRefundRequestItemsPost**](OrderRefundRequestItemApi.md#orderRefundRequestItemsPost) | **POST** /order_refund_request_items | Sipariş İptal Talebi Kalemi Oluşturma


# **orderRefundRequestItemsGet**
> \Swagger\Client\Model\OrderRefundRequestItem orderRefundRequestItemsGet($sort, $limit, $page, $since_id, $ids, $order_refund_request, $order_item, $start_date, $end_date, $start_updated_at, $end_updated_at)

Sipariş İptal Talebi Kalemi Listesi Alma

Sipariş İptal Talebi Kalemi listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OrderRefundRequestItemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$order_refund_request = 56; // int | Sipariş iptal talebi id
$order_item = 56; // int | Sipariş ürünü id
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi
$start_updated_at = new \DateTime("2013-10-20"); // \DateTime | updatedAt değeri için başlangıç tarihi
$end_updated_at = "end_updated_at_example"; // string | updatedAt değeri için bitiş tarihi

try {
    $result = $apiInstance->orderRefundRequestItemsGet($sort, $limit, $page, $since_id, $ids, $order_refund_request, $order_item, $start_date, $end_date, $start_updated_at, $end_updated_at);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrderRefundRequestItemApi->orderRefundRequestItemsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **order_refund_request** | **int**| Sipariş iptal talebi id | [optional]
 **order_item** | **int**| Sipariş ürünü id | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]
 **start_updated_at** | **\DateTime**| updatedAt değeri için başlangıç tarihi | [optional]
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**\Swagger\Client\Model\OrderRefundRequestItem**](../Model/OrderRefundRequestItem.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **orderRefundRequestItemsIdDelete**
> orderRefundRequestItemsIdDelete($id)

Sipariş İptal Talebi Kalemi Silme

Kalıcı olarak ilgili Sipariş İptal Talebi Kalemini siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OrderRefundRequestItemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sipariş İptal Talebi Kalemi nesnesinin id değeri

try {
    $apiInstance->orderRefundRequestItemsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling OrderRefundRequestItemApi->orderRefundRequestItemsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş İptal Talebi Kalemi nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **orderRefundRequestItemsIdGet**
> \Swagger\Client\Model\OrderRefundRequestItem orderRefundRequestItemsIdGet($id)

Sipariş İptal Talebi Kalemi Alma

İlgili Sipariş İptal Talebi Kalemini getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OrderRefundRequestItemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sipariş İptal Talebi Kalemi nesnesinin id değeri

try {
    $result = $apiInstance->orderRefundRequestItemsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrderRefundRequestItemApi->orderRefundRequestItemsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş İptal Talebi Kalemi nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\OrderRefundRequestItem**](../Model/OrderRefundRequestItem.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **orderRefundRequestItemsIdPut**
> \Swagger\Client\Model\OrderRefundRequestItem orderRefundRequestItemsIdPut($id, $order_refund_request_item)

Sipariş İptal Talebi Kalemi Güncelleme

İlgili Sipariş İptal Talebi Kalemini günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OrderRefundRequestItemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sipariş İptal Talebi Kalemi nesnesinin id değeri
$order_refund_request_item = new \Swagger\Client\Model\OrderRefundRequestItem(); // \Swagger\Client\Model\OrderRefundRequestItem | nesnesi

try {
    $result = $apiInstance->orderRefundRequestItemsIdPut($id, $order_refund_request_item);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrderRefundRequestItemApi->orderRefundRequestItemsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş İptal Talebi Kalemi nesnesinin id değeri |
 **order_refund_request_item** | [**\Swagger\Client\Model\OrderRefundRequestItem**](../Model/OrderRefundRequestItem.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\OrderRefundRequestItem**](../Model/OrderRefundRequestItem.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **orderRefundRequestItemsPost**
> \Swagger\Client\Model\OrderRefundRequestItem orderRefundRequestItemsPost($order_refund_request_item)

Sipariş İptal Talebi Kalemi Oluşturma

Yeni bir Sipariş İptal Talebi Kalemi oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OrderRefundRequestItemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$order_refund_request_item = new \Swagger\Client\Model\OrderRefundRequestItem(); // \Swagger\Client\Model\OrderRefundRequestItem | nesnesi

try {
    $result = $apiInstance->orderRefundRequestItemsPost($order_refund_request_item);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OrderRefundRequestItemApi->orderRefundRequestItemsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_refund_request_item** | [**\Swagger\Client\Model\OrderRefundRequestItem**](../Model/OrderRefundRequestItem.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\OrderRefundRequestItem**](../Model/OrderRefundRequestItem.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

