# Swagger\Client\SelectionToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selectionToProductsGet**](SelectionToProductApi.md#selectionToProductsGet) | **GET** /selection_to_products | Ek Özellik Ürün Bağı Listesi Alma
[**selectionToProductsIdDelete**](SelectionToProductApi.md#selectionToProductsIdDelete) | **DELETE** /selection_to_products/{id} | Ek Özellik Ürün Bağı Silme
[**selectionToProductsIdGet**](SelectionToProductApi.md#selectionToProductsIdGet) | **GET** /selection_to_products/{id} | Ek Özellik Ürün Bağı Alma
[**selectionToProductsIdPut**](SelectionToProductApi.md#selectionToProductsIdPut) | **PUT** /selection_to_products/{id} | Ek Özellik Ürün Bağı Güncelleme
[**selectionToProductsPost**](SelectionToProductApi.md#selectionToProductsPost) | **POST** /selection_to_products | Ek Özellik Ürün Bağı Oluşturma


# **selectionToProductsGet**
> \Swagger\Client\Model\SelectionToProduct selectionToProductsGet($sort, $limit, $page, $since_id, $ids, $selection, $product)

Ek Özellik Ürün Bağı Listesi Alma

Ek Özellik Ürün Bağı listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SelectionToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$selection = 56; // int | Ek Özellik id
$product = 56; // int | Ürün id

try {
    $result = $apiInstance->selectionToProductsGet($sort, $limit, $page, $since_id, $ids, $selection, $product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SelectionToProductApi->selectionToProductsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **selection** | **int**| Ek Özellik id | [optional]
 **product** | **int**| Ürün id | [optional]

### Return type

[**\Swagger\Client\Model\SelectionToProduct**](../Model/SelectionToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **selectionToProductsIdDelete**
> selectionToProductsIdDelete($id)

Ek Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ek Özellik Ürün Bağını siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SelectionToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ek Özellik Ürün Bağı nesnesinin id değeri

try {
    $apiInstance->selectionToProductsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling SelectionToProductApi->selectionToProductsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik Ürün Bağı nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **selectionToProductsIdGet**
> \Swagger\Client\Model\SelectionToProduct selectionToProductsIdGet($id)

Ek Özellik Ürün Bağı Alma

İlgili Ek Özellik Ürün Bağını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SelectionToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ek Özellik Ürün Bağı nesnesinin id değeri

try {
    $result = $apiInstance->selectionToProductsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SelectionToProductApi->selectionToProductsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik Ürün Bağı nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\SelectionToProduct**](../Model/SelectionToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **selectionToProductsIdPut**
> \Swagger\Client\Model\SelectionToProduct selectionToProductsIdPut($id, $selection_to_product)

Ek Özellik Ürün Bağı Güncelleme

İlgili Ek Özellik Ürün Bağını günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SelectionToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ek Özellik Ürün Bağı nesnesinin id değeri
$selection_to_product = new \Swagger\Client\Model\SelectionToProduct(); // \Swagger\Client\Model\SelectionToProduct | nesnesi

try {
    $result = $apiInstance->selectionToProductsIdPut($id, $selection_to_product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SelectionToProductApi->selectionToProductsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik Ürün Bağı nesnesinin id değeri |
 **selection_to_product** | [**\Swagger\Client\Model\SelectionToProduct**](../Model/SelectionToProduct.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\SelectionToProduct**](../Model/SelectionToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **selectionToProductsPost**
> \Swagger\Client\Model\SelectionToProduct selectionToProductsPost($selection_to_product)

Ek Özellik Ürün Bağı Oluşturma

Yeni bir Ek Özellik Ürün Bağı oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SelectionToProductApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$selection_to_product = new \Swagger\Client\Model\SelectionToProduct(); // \Swagger\Client\Model\SelectionToProduct | nesnesi

try {
    $result = $apiInstance->selectionToProductsPost($selection_to_product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SelectionToProductApi->selectionToProductsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selection_to_product** | [**\Swagger\Client\Model\SelectionToProduct**](../Model/SelectionToProduct.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\SelectionToProduct**](../Model/SelectionToProduct.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

