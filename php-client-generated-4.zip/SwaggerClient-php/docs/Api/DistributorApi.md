# Swagger\Client\DistributorApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**distributorsGet**](DistributorApi.md#distributorsGet) | **GET** /distributors | Distribütör Listesi Alma
[**distributorsIdDelete**](DistributorApi.md#distributorsIdDelete) | **DELETE** /distributors/{id} | Distribütör Silme
[**distributorsIdGet**](DistributorApi.md#distributorsIdGet) | **GET** /distributors/{id} | Distribütör Alma
[**distributorsIdPut**](DistributorApi.md#distributorsIdPut) | **PUT** /distributors/{id} | Distribütör Güncelleme
[**distributorsPost**](DistributorApi.md#distributorsPost) | **POST** /distributors | Distribütör Oluşturma


# **distributorsGet**
> \Swagger\Client\Model\Distributor distributorsGet($sort, $limit, $page, $since_id, $ids, $name, $email, $phone, $contact_person)

Distribütör Listesi Alma

Distribütör listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DistributorApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$name = "name_example"; // string | Distribütör adı.
$email = "email_example"; // string | Distribütör email adresi
$phone = "phone_example"; // string | Distribütör telefonu
$contact_person = "contact_person_example"; // string | Distribütör sorumlu kişi

try {
    $result = $apiInstance->distributorsGet($sort, $limit, $page, $since_id, $ids, $name, $email, $phone, $contact_person);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DistributorApi->distributorsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **name** | **string**| Distribütör adı. | [optional]
 **email** | **string**| Distribütör email adresi | [optional]
 **phone** | **string**| Distribütör telefonu | [optional]
 **contact_person** | **string**| Distribütör sorumlu kişi | [optional]

### Return type

[**\Swagger\Client\Model\Distributor**](../Model/Distributor.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **distributorsIdDelete**
> distributorsIdDelete($id)

Distribütör Silme

Kalıcı olarak ilgili Distribütörü siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DistributorApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Distribütör nesnesinin id değeri

try {
    $apiInstance->distributorsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling DistributorApi->distributorsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Distribütör nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **distributorsIdGet**
> \Swagger\Client\Model\Distributor distributorsIdGet($id)

Distribütör Alma

İlgili Distribütörü getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DistributorApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Distribütör nesnesinin id değeri

try {
    $result = $apiInstance->distributorsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DistributorApi->distributorsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Distribütör nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\Distributor**](../Model/Distributor.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **distributorsIdPut**
> \Swagger\Client\Model\Distributor distributorsIdPut($id, $distributor)

Distribütör Güncelleme

İlgili Distribütörü günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DistributorApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Distribütör nesnesinin id değeri
$distributor = new \Swagger\Client\Model\Distributor(); // \Swagger\Client\Model\Distributor | nesnesi

try {
    $result = $apiInstance->distributorsIdPut($id, $distributor);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DistributorApi->distributorsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Distribütör nesnesinin id değeri |
 **distributor** | [**\Swagger\Client\Model\Distributor**](../Model/Distributor.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\Distributor**](../Model/Distributor.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **distributorsPost**
> \Swagger\Client\Model\Distributor distributorsPost($distributor)

Distribütör Oluşturma

Yeni bir Distribütör oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DistributorApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$distributor = new \Swagger\Client\Model\Distributor(); // \Swagger\Client\Model\Distributor | nesnesi

try {
    $result = $apiInstance->distributorsPost($distributor);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DistributorApi->distributorsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **distributor** | [**\Swagger\Client\Model\Distributor**](../Model/Distributor.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\Distributor**](../Model/Distributor.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

