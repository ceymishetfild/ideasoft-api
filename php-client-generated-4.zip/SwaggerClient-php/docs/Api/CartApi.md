# Swagger\Client\CartApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cartsIdDelete**](CartApi.md#cartsIdDelete) | **DELETE** /carts/{id} | Sepet Silme
[**cartsIdGet**](CartApi.md#cartsIdGet) | **GET** /carts/{id} | Sepet Alma
[**cartsPost**](CartApi.md#cartsPost) | **POST** /carts | Sepet Oluşturma


# **cartsIdDelete**
> cartsIdDelete($id)

Sepet Silme

Kalıcı olarak ilgili Sepeti siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CartApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sepet nesnesinin id değeri

try {
    $apiInstance->cartsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling CartApi->cartsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sepet nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **cartsIdGet**
> \Swagger\Client\Model\Cart cartsIdGet($id)

Sepet Alma

İlgili Sepet getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CartApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sepet nesnesinin id değeri

try {
    $result = $apiInstance->cartsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CartApi->cartsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sepet nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\Cart**](../Model/Cart.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **cartsPost**
> \Swagger\Client\Model\Cart cartsPost($cart)

Sepet Oluşturma

Yeni bir Sepet oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CartApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$cart = new \Swagger\Client\Model\Cart(); // \Swagger\Client\Model\Cart | nesnesi

try {
    $result = $apiInstance->cartsPost($cart);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CartApi->cartsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart** | [**\Swagger\Client\Model\Cart**](../Model/Cart.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\Cart**](../Model/Cart.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

