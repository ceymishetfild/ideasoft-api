# Swagger\Client\OptionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**optionGroupsGet**](OptionGroupApi.md#optionGroupsGet) | **GET** /option_groups | Varyant Grubu Listesi Alma
[**optionGroupsIdDelete**](OptionGroupApi.md#optionGroupsIdDelete) | **DELETE** /option_groups/{id} | Varyant Grubu Silme
[**optionGroupsIdGet**](OptionGroupApi.md#optionGroupsIdGet) | **GET** /option_groups/{id} | Varyant Grubu Alma
[**optionGroupsIdPut**](OptionGroupApi.md#optionGroupsIdPut) | **PUT** /option_groups/{id} | Varyant Grubu Güncelleme
[**optionGroupsPost**](OptionGroupApi.md#optionGroupsPost) | **POST** /option_groups | Varyant Grubu Oluşturma


# **optionGroupsGet**
> \Swagger\Client\Model\OptionGroup optionGroupsGet($sort, $limit, $page, $since_id, $ids, $title)

Varyant Grubu Listesi Alma

Varyant Grubu listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OptionGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$title = "title_example"; // string | Varyant Grubu başlığı.

try {
    $result = $apiInstance->optionGroupsGet($sort, $limit, $page, $since_id, $ids, $title);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OptionGroupApi->optionGroupsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **title** | **string**| Varyant Grubu başlığı. | [optional]

### Return type

[**\Swagger\Client\Model\OptionGroup**](../Model/OptionGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **optionGroupsIdDelete**
> optionGroupsIdDelete($id)

Varyant Grubu Silme

Kalıcı olarak ilgili Varyant Grubunu siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OptionGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Varyant Grubu nesnesinin id değeri

try {
    $apiInstance->optionGroupsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling OptionGroupApi->optionGroupsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant Grubu nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **optionGroupsIdGet**
> \Swagger\Client\Model\OptionGroup optionGroupsIdGet($id)

Varyant Grubu Alma

İlgili Varyant Grubunu getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OptionGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Varyant Grubu nesnesinin id değeri

try {
    $result = $apiInstance->optionGroupsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OptionGroupApi->optionGroupsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant Grubu nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\OptionGroup**](../Model/OptionGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **optionGroupsIdPut**
> \Swagger\Client\Model\OptionGroup optionGroupsIdPut($id, $option_group)

Varyant Grubu Güncelleme

İlgili Varyant Grubunu günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OptionGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Varyant Grubu nesnesinin id değeri
$option_group = new \Swagger\Client\Model\OptionGroup(); // \Swagger\Client\Model\OptionGroup | nesnesi

try {
    $result = $apiInstance->optionGroupsIdPut($id, $option_group);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OptionGroupApi->optionGroupsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant Grubu nesnesinin id değeri |
 **option_group** | [**\Swagger\Client\Model\OptionGroup**](../Model/OptionGroup.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\OptionGroup**](../Model/OptionGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **optionGroupsPost**
> \Swagger\Client\Model\OptionGroup optionGroupsPost($option_group)

Varyant Grubu Oluşturma

Yeni bir Varyant Grubu oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\OptionGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$option_group = new \Swagger\Client\Model\OptionGroup(); // \Swagger\Client\Model\OptionGroup | nesnesi

try {
    $result = $apiInstance->optionGroupsPost($option_group);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OptionGroupApi->optionGroupsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **option_group** | [**\Swagger\Client\Model\OptionGroup**](../Model/OptionGroup.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\OptionGroup**](../Model/OptionGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

