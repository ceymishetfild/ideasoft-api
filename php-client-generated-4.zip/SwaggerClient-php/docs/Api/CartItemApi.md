# Swagger\Client\CartItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cartItemsIdDelete**](CartItemApi.md#cartItemsIdDelete) | **DELETE** /cart_items/{id} | Sepet Kalemi Silme
[**cartItemsIdPut**](CartItemApi.md#cartItemsIdPut) | **PUT** /cart_items/{id} | Sepet Kalemi Güncelleme
[**cartItemsPost**](CartItemApi.md#cartItemsPost) | **POST** /cart_items | Sepet Kalemi Oluşturma


# **cartItemsIdDelete**
> cartItemsIdDelete($id)

Sepet Kalemi Silme

Kalıcı olarak ilgili Sepet Kalemini siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CartItemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sepet Kalemi nesnesinin id değeri

try {
    $apiInstance->cartItemsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling CartItemApi->cartItemsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sepet Kalemi nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **cartItemsIdPut**
> \Swagger\Client\Model\CartItem cartItemsIdPut($id)

Sepet Kalemi Güncelleme

İlgili Sepet Kalemini günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CartItemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Sepet Kalemi nesnesinin id değeri

try {
    $result = $apiInstance->cartItemsIdPut($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CartItemApi->cartItemsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sepet Kalemi nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\CartItem**](../Model/CartItem.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **cartItemsPost**
> \Swagger\Client\Model\CartItem cartItemsPost($cart_item)

Sepet Kalemi Oluşturma

Yeni bir Sepet Kalemi oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CartItemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$cart_item = new \Swagger\Client\Model\CartItem(); // \Swagger\Client\Model\CartItem | nesnesi

try {
    $result = $apiInstance->cartItemsPost($cart_item);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CartItemApi->cartItemsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_item** | [**\Swagger\Client\Model\CartItem**](../Model/CartItem.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\CartItem**](../Model/CartItem.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

