# Swagger\Client\SpecValueApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specValuesGet**](SpecValueApi.md#specValuesGet) | **GET** /spec_values | Ürün Özellik Değeri Listesi Alma
[**specValuesIdDelete**](SpecValueApi.md#specValuesIdDelete) | **DELETE** /spec_values/{id} | Ürün Özellik Değeri Silme
[**specValuesIdGet**](SpecValueApi.md#specValuesIdGet) | **GET** /spec_values/{id} | Ürün Özellik Değeri Alma
[**specValuesIdPut**](SpecValueApi.md#specValuesIdPut) | **PUT** /spec_values/{id} | Ürün Özellik Değeri Güncelleme
[**specValuesPost**](SpecValueApi.md#specValuesPost) | **POST** /spec_values | Ürün Özellik Değeri Oluşturma


# **specValuesGet**
> \Swagger\Client\Model\SpecValue specValuesGet($sort, $limit, $page, $since_id, $ids, $name, $spec_name, $spec_value)

Ürün Özellik Değeri Listesi Alma

Ürün Özellik Değeri listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SpecValueApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$name = "name_example"; // string | Ürün özellik adı
$spec_name = 56; // int | Ürün özellik id
$spec_value = 56; // int | Ürün özellik değeri id

try {
    $result = $apiInstance->specValuesGet($sort, $limit, $page, $since_id, $ids, $name, $spec_name, $spec_value);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SpecValueApi->specValuesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **name** | **string**| Ürün özellik adı | [optional]
 **spec_name** | **int**| Ürün özellik id | [optional]
 **spec_value** | **int**| Ürün özellik değeri id | [optional]

### Return type

[**\Swagger\Client\Model\SpecValue**](../Model/SpecValue.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **specValuesIdDelete**
> specValuesIdDelete($id)

Ürün Özellik Değeri Silme

Kalıcı olarak ilgili Ürün Özellik Değerini siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SpecValueApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Özellik Değeri nesnesinin id değeri

try {
    $apiInstance->specValuesIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling SpecValueApi->specValuesIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Değeri nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **specValuesIdGet**
> \Swagger\Client\Model\SpecValue specValuesIdGet($id)

Ürün Özellik Değeri Alma

İlgili Ürün Özellik Değerini getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SpecValueApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Özellik Değeri nesnesinin id değeri

try {
    $result = $apiInstance->specValuesIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SpecValueApi->specValuesIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Değeri nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\SpecValue**](../Model/SpecValue.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **specValuesIdPut**
> \Swagger\Client\Model\SpecValue specValuesIdPut($id, $spec_value)

Ürün Özellik Değeri Güncelleme

İlgili Ürün Özellik Değerini günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SpecValueApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Özellik Değeri nesnesinin id değeri
$spec_value = new \Swagger\Client\Model\SpecValue(); // \Swagger\Client\Model\SpecValue | nesnesi

try {
    $result = $apiInstance->specValuesIdPut($id, $spec_value);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SpecValueApi->specValuesIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Değeri nesnesinin id değeri |
 **spec_value** | [**\Swagger\Client\Model\SpecValue**](../Model/SpecValue.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\SpecValue**](../Model/SpecValue.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **specValuesPost**
> \Swagger\Client\Model\SpecValue specValuesPost($spec_value)

Ürün Özellik Değeri Oluşturma

Yeni bir Ürün Özellik Değeri oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SpecValueApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$spec_value = new \Swagger\Client\Model\SpecValue(); // \Swagger\Client\Model\SpecValue | nesnesi

try {
    $result = $apiInstance->specValuesPost($spec_value);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SpecValueApi->specValuesPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **spec_value** | [**\Swagger\Client\Model\SpecValue**](../Model/SpecValue.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\SpecValue**](../Model/SpecValue.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

