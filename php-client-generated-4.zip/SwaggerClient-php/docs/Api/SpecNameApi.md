# Swagger\Client\SpecNameApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specNamesGet**](SpecNameApi.md#specNamesGet) | **GET** /spec_names | Ürün Özelliği Listesi Alma
[**specNamesIdDelete**](SpecNameApi.md#specNamesIdDelete) | **DELETE** /spec_names/{id} | Ürün Özelliği Silme
[**specNamesIdGet**](SpecNameApi.md#specNamesIdGet) | **GET** /spec_names/{id} | Ürün Özelliği Alma
[**specNamesIdPut**](SpecNameApi.md#specNamesIdPut) | **PUT** /spec_names/{id} | Ürün Özelliği Güncelleme
[**specNamesPost**](SpecNameApi.md#specNamesPost) | **POST** /spec_names | Ürün Özelliği Oluşturma


# **specNamesGet**
> \Swagger\Client\Model\SpecName specNamesGet($sort, $limit, $page, $since_id, $ids, $name, $spec_group, $choice_type)

Ürün Özelliği Listesi Alma

Ürün Özelliği listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SpecNameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$name = "name_example"; // string | Ürün Özelliği adı
$spec_group = 56; // int | Ürün özellik grubu id
$choice_type = "choice_type_example"; // string | Status şu değerleri alabilir: <br><code>singular</code> : Tekil<br><code>plural</code> : Çoğul

try {
    $result = $apiInstance->specNamesGet($sort, $limit, $page, $since_id, $ids, $name, $spec_group, $choice_type);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SpecNameApi->specNamesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **name** | **string**| Ürün Özelliği adı | [optional]
 **spec_group** | **int**| Ürün özellik grubu id | [optional]
 **choice_type** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul | [optional]

### Return type

[**\Swagger\Client\Model\SpecName**](../Model/SpecName.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **specNamesIdDelete**
> specNamesIdDelete($id)

Ürün Özelliği Silme

Kalıcı olarak ilgili Ürün Özelliğini siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SpecNameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Özellik nesnesinin id değeri

try {
    $apiInstance->specNamesIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling SpecNameApi->specNamesIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **specNamesIdGet**
> \Swagger\Client\Model\SpecName specNamesIdGet($id)

Ürün Özelliği Alma

İlgili Ürün Özelliğini getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SpecNameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Özellik nesnesinin id değeri

try {
    $result = $apiInstance->specNamesIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SpecNameApi->specNamesIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\SpecName**](../Model/SpecName.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **specNamesIdPut**
> \Swagger\Client\Model\SpecName specNamesIdPut($id, $spec_name)

Ürün Özelliği Güncelleme

İlgili Ürün Özelliğini günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SpecNameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Özellik nesnesinin id değeri
$spec_name = new \Swagger\Client\Model\SpecName(); // \Swagger\Client\Model\SpecName | nesnesi

try {
    $result = $apiInstance->specNamesIdPut($id, $spec_name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SpecNameApi->specNamesIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik nesnesinin id değeri |
 **spec_name** | [**\Swagger\Client\Model\SpecName**](../Model/SpecName.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\SpecName**](../Model/SpecName.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **specNamesPost**
> \Swagger\Client\Model\SpecName specNamesPost($spec_name)

Ürün Özelliği Oluşturma

Yeni bir Ürün Özelliği oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\SpecNameApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$spec_name = new \Swagger\Client\Model\SpecName(); // \Swagger\Client\Model\SpecName | nesnesi

try {
    $result = $apiInstance->specNamesPost($spec_name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SpecNameApi->specNamesPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **spec_name** | [**\Swagger\Client\Model\SpecName**](../Model/SpecName.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\SpecName**](../Model/SpecName.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

