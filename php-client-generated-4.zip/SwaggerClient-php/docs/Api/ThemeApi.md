# Swagger\Client\ThemeApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**themesGet**](ThemeApi.md#themesGet) | **GET** /themes | Tema Listesi Alma
[**themesIdAssetsGet**](ThemeApi.md#themesIdAssetsGet) | **GET** /themes/{id}/assets | Tema Dosyası Listesi Alma
[**themesIdAssetskeykeyDelete**](ThemeApi.md#themesIdAssetskeykeyDelete) | **DELETE** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Silme
[**themesIdAssetskeykeyGet**](ThemeApi.md#themesIdAssetskeykeyGet) | **GET** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Alma
[**themesIdAssetskeykeyPut**](ThemeApi.md#themesIdAssetskeykeyPut) | **PUT** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Güncelleme
[**themesIdDelete**](ThemeApi.md#themesIdDelete) | **DELETE** /themes/{id} | Tema Silme
[**themesIdGet**](ThemeApi.md#themesIdGet) | **GET** /themes/{id} | Tema Alma
[**themesIdPut**](ThemeApi.md#themesIdPut) | **PUT** /themes/{id} | Tema Güncelleme
[**themesPost**](ThemeApi.md#themesPost) | **POST** /themes | Tema Oluşturma


# **themesGet**
> \Swagger\Client\Model\Theme themesGet($sort, $limit, $page, $since_id, $ids, $status, $platform, $type)

Tema Listesi Alma

Tema listesi verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ThemeApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$status = 56; // int | Tema durumu
$platform = "platform_example"; // string | Tema platformu
$type = "type_example"; // string | Tema tipi

try {
    $result = $apiInstance->themesGet($sort, $limit, $page, $since_id, $ids, $status, $platform, $type);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ThemeApi->themesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **status** | **int**| Tema durumu | [optional]
 **platform** | **string**| Tema platformu | [optional]
 **type** | **string**| Tema tipi | [optional]

### Return type

[**\Swagger\Client\Model\Theme**](../Model/Theme.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **themesIdAssetsGet**
> \Swagger\Client\Model\Asset themesIdAssetsGet($id, $key)

Tema Dosyası Listesi Alma

Tema Dosyası listesi verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ThemeApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Tema nesnesinin id değeri
$key = "key_example"; // string | Tema Dosyası nesnesi anahtar değeri.

try {
    $result = $apiInstance->themesIdAssetsGet($id, $key);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ThemeApi->themesIdAssetsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri |
 **key** | **string**| Tema Dosyası nesnesi anahtar değeri. | [optional]

### Return type

[**\Swagger\Client\Model\Asset**](../Model/Asset.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **themesIdAssetskeykeyDelete**
> themesIdAssetskeykeyDelete($id, $key)

Tema Dosyası Silme

Kalıcı olarak ilgili Tema Dosyasını siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ThemeApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Tema nesnesinin id değeri
$key = "key_example"; // string | Tema Dosyası nesnesi anahtar değeri.

try {
    $apiInstance->themesIdAssetskeykeyDelete($id, $key);
} catch (Exception $e) {
    echo 'Exception when calling ThemeApi->themesIdAssetskeykeyDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri |
 **key** | **string**| Tema Dosyası nesnesi anahtar değeri. |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **themesIdAssetskeykeyGet**
> \Swagger\Client\Model\Asset themesIdAssetskeykeyGet($id, $key)

Tema Dosyası Alma

İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ThemeApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Tema nesnesinin id değeri
$key = "key_example"; // string | Tema Dosyası nesnesi anahtar değeri.

try {
    $result = $apiInstance->themesIdAssetskeykeyGet($id, $key);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ThemeApi->themesIdAssetskeykeyGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri |
 **key** | **string**| Tema Dosyası nesnesi anahtar değeri. |

### Return type

[**\Swagger\Client\Model\Asset**](../Model/Asset.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **themesIdAssetskeykeyPut**
> \Swagger\Client\Model\Asset themesIdAssetskeykeyPut($id, $theme, $asset)

Tema Dosyası Güncelleme

Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ThemeApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Tema nesnesinin id değeri
$theme = new \Swagger\Client\Model\Theme(); // \Swagger\Client\Model\Theme | nesnesi
$asset = new \Swagger\Client\Model\Asset(); // \Swagger\Client\Model\Asset | nesnesi

try {
    $result = $apiInstance->themesIdAssetskeykeyPut($id, $theme, $asset);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ThemeApi->themesIdAssetskeykeyPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri |
 **theme** | [**\Swagger\Client\Model\Theme**](../Model/Theme.md)| nesnesi |
 **asset** | [**\Swagger\Client\Model\Asset**](../Model/Asset.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\Asset**](../Model/Asset.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **themesIdDelete**
> themesIdDelete($id)

Tema Silme

Kalıcı olarak ilgili Temayı siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ThemeApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Tema nesnesinin id değeri

try {
    $apiInstance->themesIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling ThemeApi->themesIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **themesIdGet**
> \Swagger\Client\Model\Theme themesIdGet($id)

Tema Alma

İlgili Temayı getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ThemeApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Tema nesnesinin id değeri

try {
    $result = $apiInstance->themesIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ThemeApi->themesIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\Theme**](../Model/Theme.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **themesIdPut**
> \Swagger\Client\Model\Theme themesIdPut($id, $theme)

Tema Güncelleme

İlgili Temayı günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ThemeApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Tema nesnesinin id değeri
$theme = new \Swagger\Client\Model\Theme(); // \Swagger\Client\Model\Theme | nesnesi

try {
    $result = $apiInstance->themesIdPut($id, $theme);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ThemeApi->themesIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri |
 **theme** | [**\Swagger\Client\Model\Theme**](../Model/Theme.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\Theme**](../Model/Theme.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **themesPost**
> \Swagger\Client\Model\Theme themesPost($theme)

Tema Oluşturma

Yeni bir tema oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ThemeApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$theme = new \Swagger\Client\Model\Theme(); // \Swagger\Client\Model\Theme | nesnesi

try {
    $result = $apiInstance->themesPost($theme);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ThemeApi->themesPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **theme** | [**\Swagger\Client\Model\Theme**](../Model/Theme.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\Theme**](../Model/Theme.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

