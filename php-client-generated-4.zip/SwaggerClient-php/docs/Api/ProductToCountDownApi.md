# Swagger\Client\ProductToCountDownApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productToCountDownsGet**](ProductToCountDownApi.md#productToCountDownsGet) | **GET** /product_to_count_downs | Ürün Geri Sayım Bağı Listesi Alma
[**productToCountDownsIdDelete**](ProductToCountDownApi.md#productToCountDownsIdDelete) | **DELETE** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Silme
[**productToCountDownsIdGet**](ProductToCountDownApi.md#productToCountDownsIdGet) | **GET** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Alma
[**productToCountDownsIdPut**](ProductToCountDownApi.md#productToCountDownsIdPut) | **PUT** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Güncelleme
[**productToCountDownsPost**](ProductToCountDownApi.md#productToCountDownsPost) | **POST** /product_to_count_downs | Ürün Geri Sayım Bağı Oluşturma


# **productToCountDownsGet**
> \Swagger\Client\Model\ProductToCountDown productToCountDownsGet($sort, $limit, $page, $since_id, $ids, $product)

Ürün Geri Sayım Bağı Listesi Alma

Ürün Geri Sayım Bağı listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductToCountDownApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$product = 56; // int | Ürün id

try {
    $result = $apiInstance->productToCountDownsGet($sort, $limit, $page, $since_id, $ids, $product);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductToCountDownApi->productToCountDownsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **product** | **int**| Ürün id | [optional]

### Return type

[**\Swagger\Client\Model\ProductToCountDown**](../Model/ProductToCountDown.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productToCountDownsIdDelete**
> productToCountDownsIdDelete($id)

Ürün Geri Sayım Bağı Silme

Kalıcı olarak ilgili Ürün Geri Sayım Bağını siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductToCountDownApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Geri Sayım Bağı nesnesinin id değeri

try {
    $apiInstance->productToCountDownsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling ProductToCountDownApi->productToCountDownsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Geri Sayım Bağı nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productToCountDownsIdGet**
> \Swagger\Client\Model\ProductToCountDown productToCountDownsIdGet($id)

Ürün Geri Sayım Bağı Alma

İlgili Ürün Geri Sayım Bağını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductToCountDownApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Geri Sayım Bağı nesnesinin id değeri

try {
    $result = $apiInstance->productToCountDownsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductToCountDownApi->productToCountDownsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Geri Sayım Bağı nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\ProductToCountDown**](../Model/ProductToCountDown.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productToCountDownsIdPut**
> \Swagger\Client\Model\ProductToCountDown productToCountDownsIdPut($id, $product_to_count_down)

Ürün Geri Sayım Bağı Güncelleme

İlgili Ürün Geri Sayım Bağını günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductToCountDownApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Geri Sayım Bağı nesnesinin id değeri
$product_to_count_down = new \Swagger\Client\Model\ProductToCountDown(); // \Swagger\Client\Model\ProductToCountDown | nesnesi

try {
    $result = $apiInstance->productToCountDownsIdPut($id, $product_to_count_down);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductToCountDownApi->productToCountDownsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Geri Sayım Bağı nesnesinin id değeri |
 **product_to_count_down** | [**\Swagger\Client\Model\ProductToCountDown**](../Model/ProductToCountDown.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ProductToCountDown**](../Model/ProductToCountDown.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productToCountDownsPost**
> \Swagger\Client\Model\ProductToCountDown productToCountDownsPost($product_to_count_down)

Ürün Geri Sayım Bağı Oluşturma

Yeni bir Ürün Geri Sayım Bağı oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductToCountDownApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$product_to_count_down = new \Swagger\Client\Model\ProductToCountDown(); // \Swagger\Client\Model\ProductToCountDown | nesnesi

try {
    $result = $apiInstance->productToCountDownsPost($product_to_count_down);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductToCountDownApi->productToCountDownsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_to_count_down** | [**\Swagger\Client\Model\ProductToCountDown**](../Model/ProductToCountDown.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ProductToCountDown**](../Model/ProductToCountDown.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

