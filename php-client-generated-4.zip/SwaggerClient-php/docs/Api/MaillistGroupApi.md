# Swagger\Client\MaillistGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**maillistGroupsGet**](MaillistGroupApi.md#maillistGroupsGet) | **GET** /maillist_groups | Mail Listesi Grubu Listesi Alma
[**maillistGroupsIdDelete**](MaillistGroupApi.md#maillistGroupsIdDelete) | **DELETE** /maillist_groups/{id} | Mail Listesi Grubu Silme
[**maillistGroupsIdGet**](MaillistGroupApi.md#maillistGroupsIdGet) | **GET** /maillist_groups/{id} | Mail Listesi Grubu Alma
[**maillistGroupsIdPut**](MaillistGroupApi.md#maillistGroupsIdPut) | **PUT** /maillist_groups/{id} | Mail Listesi Grubu Güncelleme
[**maillistGroupsPost**](MaillistGroupApi.md#maillistGroupsPost) | **POST** /maillist_groups | Mail Listesi Grubu Oluşturma


# **maillistGroupsGet**
> \Swagger\Client\Model\MaillistGroup maillistGroupsGet($sort, $limit, $page, $since_id, $ids, $name)

Mail Listesi Grubu Listesi Alma

Mail Listesi Grubu listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MaillistGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$name = "name_example"; // string | Mail Listesi Grubu adı

try {
    $result = $apiInstance->maillistGroupsGet($sort, $limit, $page, $since_id, $ids, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MaillistGroupApi->maillistGroupsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **name** | **string**| Mail Listesi Grubu adı | [optional]

### Return type

[**\Swagger\Client\Model\MaillistGroup**](../Model/MaillistGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **maillistGroupsIdDelete**
> maillistGroupsIdDelete($id)

Mail Listesi Grubu Silme

Kalıcı olarak ilgili Mail Listesi Grubunu siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MaillistGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Mail Listesi Grubu nesnesinin id değeri

try {
    $apiInstance->maillistGroupsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling MaillistGroupApi->maillistGroupsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi Grubu nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **maillistGroupsIdGet**
> \Swagger\Client\Model\MaillistGroup maillistGroupsIdGet($id)

Mail Listesi Grubu Alma

İlgili Mail Listesi Grubunu getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MaillistGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Mail Listesi Grubu nesnesinin id değeri

try {
    $result = $apiInstance->maillistGroupsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MaillistGroupApi->maillistGroupsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi Grubu nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\MaillistGroup**](../Model/MaillistGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **maillistGroupsIdPut**
> \Swagger\Client\Model\MaillistGroup maillistGroupsIdPut($id, $maillist_group)

Mail Listesi Grubu Güncelleme

İlgili Mail Listesi Grubunu günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MaillistGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Mail Listesi Grubu nesnesinin id değeri
$maillist_group = new \Swagger\Client\Model\MaillistGroup(); // \Swagger\Client\Model\MaillistGroup | nesnesi

try {
    $result = $apiInstance->maillistGroupsIdPut($id, $maillist_group);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MaillistGroupApi->maillistGroupsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi Grubu nesnesinin id değeri |
 **maillist_group** | [**\Swagger\Client\Model\MaillistGroup**](../Model/MaillistGroup.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\MaillistGroup**](../Model/MaillistGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **maillistGroupsPost**
> \Swagger\Client\Model\MaillistGroup maillistGroupsPost($maillist_group)

Mail Listesi Grubu Oluşturma

Yeni bir Mail Listesi Grubu oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\MaillistGroupApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$maillist_group = new \Swagger\Client\Model\MaillistGroup(); // \Swagger\Client\Model\MaillistGroup | nesnesi

try {
    $result = $apiInstance->maillistGroupsPost($maillist_group);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling MaillistGroupApi->maillistGroupsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **maillist_group** | [**\Swagger\Client\Model\MaillistGroup**](../Model/MaillistGroup.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\MaillistGroup**](../Model/MaillistGroup.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

