# Swagger\Client\ProductCommentApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productCommentsGet**](ProductCommentApi.md#productCommentsGet) | **GET** /product_comments | Ürün Yorumları Listesi Alma
[**productCommentsIdDelete**](ProductCommentApi.md#productCommentsIdDelete) | **DELETE** /product_comments/{id} | Ürün Yorumu Silme
[**productCommentsIdGet**](ProductCommentApi.md#productCommentsIdGet) | **GET** /product_comments/{id} | Ürün Yorumu Alma
[**productCommentsIdPut**](ProductCommentApi.md#productCommentsIdPut) | **PUT** /product_comments/{id} | Ürün Yorumu Güncelleme
[**productCommentsPost**](ProductCommentApi.md#productCommentsPost) | **POST** /product_comments | Ürün Yorumu Oluşturma


# **productCommentsGet**
> \Swagger\Client\Model\ProductComment productCommentsGet($sort, $limit, $page, $since_id, $status, $is_anonymous, $member, $product, $start_date, $end_date, $start_updated_at, $end_updated_at)

Ürün Yorumları Listesi Alma

Ürün Yorumları listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductCommentApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$status = "status_example"; // string | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
$is_anonymous = "is_anonymous_example"; // string | IsAnonymous şu değerleri alabilir: <br><code>0</code> : Anonim değil<br><code>1</code> : Anonim
$member = 56; // int | Üye id
$product = 56; // int | Ürün id
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi
$start_updated_at = new \DateTime("2013-10-20"); // \DateTime | updatedAt değeri için başlangıç tarihi
$end_updated_at = "end_updated_at_example"; // string | updatedAt değeri için bitiş tarihi

try {
    $result = $apiInstance->productCommentsGet($sort, $limit, $page, $since_id, $status, $is_anonymous, $member, $product, $start_date, $end_date, $start_updated_at, $end_updated_at);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductCommentApi->productCommentsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional]
 **is_anonymous** | **string**| IsAnonymous şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Anonim değil&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Anonim | [optional]
 **member** | **int**| Üye id | [optional]
 **product** | **int**| Ürün id | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]
 **start_updated_at** | **\DateTime**| updatedAt değeri için başlangıç tarihi | [optional]
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**\Swagger\Client\Model\ProductComment**](../Model/ProductComment.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productCommentsIdDelete**
> productCommentsIdDelete($id)

Ürün Yorumu Silme

Kalıcı olarak ilgili Ürün Yorumunu siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductCommentApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Yorumu nesnesinin id değeri

try {
    $apiInstance->productCommentsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling ProductCommentApi->productCommentsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Yorumu nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productCommentsIdGet**
> \Swagger\Client\Model\ProductComment productCommentsIdGet($id)

Ürün Yorumu Alma

İlgili Ürün Yorumunu getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductCommentApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Yorumu nesnesinin id değeri

try {
    $result = $apiInstance->productCommentsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductCommentApi->productCommentsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Yorumu nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\ProductComment**](../Model/ProductComment.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productCommentsIdPut**
> \Swagger\Client\Model\ProductComment productCommentsIdPut($id, $product_comment)

Ürün Yorumu Güncelleme

İlgili Ürün Yorumunu günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductCommentApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Ürün Yorumu nesnesinin id değeri
$product_comment = new \Swagger\Client\Model\ProductComment(); // \Swagger\Client\Model\ProductComment | nesnesi

try {
    $result = $apiInstance->productCommentsIdPut($id, $product_comment);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductCommentApi->productCommentsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Yorumu nesnesinin id değeri |
 **product_comment** | [**\Swagger\Client\Model\ProductComment**](../Model/ProductComment.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ProductComment**](../Model/ProductComment.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **productCommentsPost**
> \Swagger\Client\Model\ProductComment productCommentsPost($product_comment)

Ürün Yorumu Oluşturma

Yeni bir Ürün Yorumu oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ProductCommentApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$product_comment = new \Swagger\Client\Model\ProductComment(); // \Swagger\Client\Model\ProductComment | nesnesi

try {
    $result = $apiInstance->productCommentsPost($product_comment);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductCommentApi->productCommentsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_comment** | [**\Swagger\Client\Model\ProductComment**](../Model/ProductComment.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ProductComment**](../Model/ProductComment.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

