# Swagger\Client\ShipmentItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipmentItemsGet**](ShipmentItemApi.md#shipmentItemsGet) | **GET** /shipment_items | Teslimat Kalemi Listesi Alma
[**shipmentItemsIdDelete**](ShipmentItemApi.md#shipmentItemsIdDelete) | **DELETE** /shipment_items/{id} | Teslimat Kalemi Silme
[**shipmentItemsIdGet**](ShipmentItemApi.md#shipmentItemsIdGet) | **GET** /shipment_items/{id} | Teslimat Kalemi Alma
[**shipmentItemsIdPut**](ShipmentItemApi.md#shipmentItemsIdPut) | **PUT** /shipment_items/{id} | Teslimat Kalemi Güncelleme
[**shipmentItemsPost**](ShipmentItemApi.md#shipmentItemsPost) | **POST** /shipment_items | Teslimat Kalemi Oluşturma


# **shipmentItemsGet**
> \Swagger\Client\Model\ShipmentItem shipmentItemsGet($sort, $limit, $page, $since_id, $ids, $product, $shipment, $order_item, $start_date, $end_date, $start_updated_at, $end_updated_at)

Teslimat Kalemi Listesi Alma

Teslimat Kalemi listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShipmentItemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$product = 56; // int | Ürün id
$shipment = 56; // int | Teslimat id
$order_item = 56; // int | Sipariş kalemi id
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi
$start_updated_at = new \DateTime("2013-10-20"); // \DateTime | updatedAt değeri için başlangıç tarihi
$end_updated_at = "end_updated_at_example"; // string | updatedAt değeri için bitiş tarihi

try {
    $result = $apiInstance->shipmentItemsGet($sort, $limit, $page, $since_id, $ids, $product, $shipment, $order_item, $start_date, $end_date, $start_updated_at, $end_updated_at);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentItemApi->shipmentItemsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **product** | **int**| Ürün id | [optional]
 **shipment** | **int**| Teslimat id | [optional]
 **order_item** | **int**| Sipariş kalemi id | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]
 **start_updated_at** | **\DateTime**| updatedAt değeri için başlangıç tarihi | [optional]
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**\Swagger\Client\Model\ShipmentItem**](../Model/ShipmentItem.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shipmentItemsIdDelete**
> shipmentItemsIdDelete($id)

Teslimat Kalemi Silme

Kalıcı olarak ilgili Teslimat Kalemini siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShipmentItemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Teslimat Kalemi nesnesinin id değeri

try {
    $apiInstance->shipmentItemsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentItemApi->shipmentItemsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Teslimat Kalemi nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shipmentItemsIdGet**
> \Swagger\Client\Model\ShipmentItem shipmentItemsIdGet($id)

Teslimat Kalemi Alma

İlgili Teslimat Kalemini getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShipmentItemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Teslimat Kalemi nesnesinin id değeri

try {
    $result = $apiInstance->shipmentItemsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentItemApi->shipmentItemsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Teslimat Kalemi nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\ShipmentItem**](../Model/ShipmentItem.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shipmentItemsIdPut**
> \Swagger\Client\Model\ShipmentItem shipmentItemsIdPut($id, $shipment_item)

Teslimat Kalemi Güncelleme

İlgili Teslimat Kalemini günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShipmentItemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Teslimat Kalemi nesnesinin id değeri
$shipment_item = new \Swagger\Client\Model\ShipmentItem(); // \Swagger\Client\Model\ShipmentItem | nesnesi

try {
    $result = $apiInstance->shipmentItemsIdPut($id, $shipment_item);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentItemApi->shipmentItemsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Teslimat Kalemi nesnesinin id değeri |
 **shipment_item** | [**\Swagger\Client\Model\ShipmentItem**](../Model/ShipmentItem.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ShipmentItem**](../Model/ShipmentItem.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shipmentItemsPost**
> \Swagger\Client\Model\ShipmentItem shipmentItemsPost($shipment_item)

Teslimat Kalemi Oluşturma

Yeni bir Teslimat Kalemi oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShipmentItemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$shipment_item = new \Swagger\Client\Model\ShipmentItem(); // \Swagger\Client\Model\ShipmentItem | nesnesi

try {
    $result = $apiInstance->shipmentItemsPost($shipment_item);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentItemApi->shipmentItemsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipment_item** | [**\Swagger\Client\Model\ShipmentItem**](../Model/ShipmentItem.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ShipmentItem**](../Model/ShipmentItem.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

