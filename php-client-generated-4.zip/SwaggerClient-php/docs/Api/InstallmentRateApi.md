# Swagger\Client\InstallmentRateApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**installmentRatesGet**](InstallmentRateApi.md#installmentRatesGet) | **GET** /installment_rates | Taksit Oranı Listesi Alma
[**installmentRatesIdGet**](InstallmentRateApi.md#installmentRatesIdGet) | **GET** /installment_rates/{id} | Taksit Oranı Alma


# **installmentRatesGet**
> \Swagger\Client\Model\InstallmentRate installmentRatesGet($sort, $limit, $page, $since_id, $ids, $payment_gateway)

Taksit Oranı Listesi Alma

Taksit Oranı listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\InstallmentRateApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$payment_gateway = 56; // int | Ödeme Kanalı id

try {
    $result = $apiInstance->installmentRatesGet($sort, $limit, $page, $since_id, $ids, $payment_gateway);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstallmentRateApi->installmentRatesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **payment_gateway** | **int**| Ödeme Kanalı id | [optional]

### Return type

[**\Swagger\Client\Model\InstallmentRate**](../Model/InstallmentRate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **installmentRatesIdGet**
> \Swagger\Client\Model\InstallmentRate installmentRatesIdGet($id)

Taksit Oranı Alma

İlgili Taksit Oranını getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\InstallmentRateApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Taksit Oranı nesnesinin id değeri

try {
    $result = $apiInstance->installmentRatesIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling InstallmentRateApi->installmentRatesIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Taksit Oranı nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\InstallmentRate**](../Model/InstallmentRate.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

