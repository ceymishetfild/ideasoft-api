# Swagger\Client\ShipmentApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipmentsGet**](ShipmentApi.md#shipmentsGet) | **GET** /shipments | Teslimat Listesi Alma
[**shipmentsIdDelete**](ShipmentApi.md#shipmentsIdDelete) | **DELETE** /shipments/{id} | Teslimat Silme
[**shipmentsIdGet**](ShipmentApi.md#shipmentsIdGet) | **GET** /shipments/{id} | Teslimat Alma
[**shipmentsIdPut**](ShipmentApi.md#shipmentsIdPut) | **PUT** /shipments/{id} | Teslimat Güncelleme
[**shipmentsPost**](ShipmentApi.md#shipmentsPost) | **POST** /shipments | Teslimat Oluşturma


# **shipmentsGet**
> \Swagger\Client\Model\Shipment shipmentsGet($sort, $limit, $page, $since_id, $ids, $code, $invoice_key, $barcode, $order, $start_date, $end_date, $start_updated_at, $end_updated_at)

Teslimat Listesi Alma

Teslimat listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShipmentApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$code = "code_example"; // string | Teslimat kodu
$invoice_key = "invoice_key_example"; // string | Teslimat fatura anahtarı
$barcode = "barcode_example"; // string | Teslimat barkodu
$order = 56; // int | Sipariş id
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi
$start_updated_at = new \DateTime("2013-10-20"); // \DateTime | updatedAt değeri için başlangıç tarihi
$end_updated_at = "end_updated_at_example"; // string | updatedAt değeri için bitiş tarihi

try {
    $result = $apiInstance->shipmentsGet($sort, $limit, $page, $since_id, $ids, $code, $invoice_key, $barcode, $order, $start_date, $end_date, $start_updated_at, $end_updated_at);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentApi->shipmentsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **code** | **string**| Teslimat kodu | [optional]
 **invoice_key** | **string**| Teslimat fatura anahtarı | [optional]
 **barcode** | **string**| Teslimat barkodu | [optional]
 **order** | **int**| Sipariş id | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]
 **start_updated_at** | **\DateTime**| updatedAt değeri için başlangıç tarihi | [optional]
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**\Swagger\Client\Model\Shipment**](../Model/Shipment.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shipmentsIdDelete**
> shipmentsIdDelete($id)

Teslimat Silme

Kalıcı olarak ilgili Teslimatı siler.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShipmentApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Teslimat nesnesinin id değeri

try {
    $apiInstance->shipmentsIdDelete($id);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentApi->shipmentsIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Teslimat nesnesinin id değeri |

### Return type

void (empty response body)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shipmentsIdGet**
> \Swagger\Client\Model\Shipment shipmentsIdGet($id)

Teslimat Alma

İlgili Teslimatı getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShipmentApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Teslimat nesnesinin id değeri

try {
    $result = $apiInstance->shipmentsIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentApi->shipmentsIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Teslimat nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\Shipment**](../Model/Shipment.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shipmentsIdPut**
> \Swagger\Client\Model\Shipment shipmentsIdPut($id, $shipment)

Teslimat Güncelleme

İlgili Teslimatı günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShipmentApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Teslimat nesnesinin id değeri
$shipment = new \Swagger\Client\Model\Shipment(); // \Swagger\Client\Model\Shipment | nesnesi

try {
    $result = $apiInstance->shipmentsIdPut($id, $shipment);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentApi->shipmentsIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Teslimat nesnesinin id değeri |
 **shipment** | [**\Swagger\Client\Model\Shipment**](../Model/Shipment.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\Shipment**](../Model/Shipment.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shipmentsPost**
> \Swagger\Client\Model\Shipment shipmentsPost($shipment)

Teslimat Oluşturma

Yeni bir Teslimat oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShipmentApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$shipment = new \Swagger\Client\Model\Shipment(); // \Swagger\Client\Model\Shipment | nesnesi

try {
    $result = $apiInstance->shipmentsPost($shipment);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShipmentApi->shipmentsPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipment** | [**\Swagger\Client\Model\Shipment**](../Model/Shipment.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\Shipment**](../Model/Shipment.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

