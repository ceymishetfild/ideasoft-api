# Swagger\Client\ShippingAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shippingAddressesGet**](ShippingAddressApi.md#shippingAddressesGet) | **GET** /shipping_addresses | Teslimat Adresi Listesi Alma
[**shippingAddressesIdGet**](ShippingAddressApi.md#shippingAddressesIdGet) | **GET** /shipping_addresses/{id} | Teslimat Adresi Alma
[**shippingAddressesIdPut**](ShippingAddressApi.md#shippingAddressesIdPut) | **PUT** /shipping_addresses/{id} | Teslimat Adresi Güncelleme
[**shippingAddressesPost**](ShippingAddressApi.md#shippingAddressesPost) | **POST** /shipping_addresses | Teslimat Adresi Oluşturma


# **shippingAddressesGet**
> \Swagger\Client\Model\ShippingAddress shippingAddressesGet($sort, $limit, $page, $since_id, $ids, $order, $start_date, $end_date, $start_updated_at, $end_updated_at)

Teslimat Adresi Listesi Alma

Teslimat Adresi listesini verir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShippingAddressApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$sort = "sort_example"; // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
$limit = 20; // int | Bir sayfada gelecek sonuç adedi
$page = 1; // int | Hangi sayfadan başlanacağı
$since_id = 56; // int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
$ids = "ids_example"; // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>
$order = 56; // int | Sipariş id
$start_date = new \DateTime("2013-10-20"); // \DateTime | createdAt değeri için başlangıç tarihi
$end_date = "end_date_example"; // string | createdAt değeri için bitiş tarihi
$start_updated_at = new \DateTime("2013-10-20"); // \DateTime | updatedAt değeri için başlangıç tarihi
$end_updated_at = "end_updated_at_example"; // string | updatedAt değeri için bitiş tarihi

try {
    $result = $apiInstance->shippingAddressesGet($sort, $limit, $page, $since_id, $ids, $order, $start_date, $end_date, $start_updated_at, $end_updated_at);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShippingAddressApi->shippingAddressesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional]
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; | [optional]
 **order** | **int**| Sipariş id | [optional]
 **start_date** | **\DateTime**| createdAt değeri için başlangıç tarihi | [optional]
 **end_date** | **string**| createdAt değeri için bitiş tarihi | [optional]
 **start_updated_at** | **\DateTime**| updatedAt değeri için başlangıç tarihi | [optional]
 **end_updated_at** | **string**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**\Swagger\Client\Model\ShippingAddress**](../Model/ShippingAddress.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shippingAddressesIdGet**
> \Swagger\Client\Model\ShippingAddress shippingAddressesIdGet($id)

Teslimat Adresi Alma

İlgili Teslimat Adresi getirir.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShippingAddressApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Teslimat Adresi nesnesinin id değeri

try {
    $result = $apiInstance->shippingAddressesIdGet($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShippingAddressApi->shippingAddressesIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Teslimat Adresi nesnesinin id değeri |

### Return type

[**\Swagger\Client\Model\ShippingAddress**](../Model/ShippingAddress.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shippingAddressesIdPut**
> \Swagger\Client\Model\ShippingAddress shippingAddressesIdPut($id, $shipping_address)

Teslimat Adresi Güncelleme

İlgili Teslimat Adresi günceller.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShippingAddressApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$id = 56; // int | Teslimat Adresi nesnesinin id değeri
$shipping_address = new \Swagger\Client\Model\ShippingAddress(); // \Swagger\Client\Model\ShippingAddress | nesnesi

try {
    $result = $apiInstance->shippingAddressesIdPut($id, $shipping_address);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShippingAddressApi->shippingAddressesIdPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Teslimat Adresi nesnesinin id değeri |
 **shipping_address** | [**\Swagger\Client\Model\ShippingAddress**](../Model/ShippingAddress.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ShippingAddress**](../Model/ShippingAddress.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **shippingAddressesPost**
> \Swagger\Client\Model\ShippingAddress shippingAddressesPost($shipping_address)

Teslimat Adresi Oluşturma

Yeni bir Teslimat Adresi oluşturur.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure OAuth2 access token for authorization: OAuth2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\ShippingAddressApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$shipping_address = new \Swagger\Client\Model\ShippingAddress(); // \Swagger\Client\Model\ShippingAddress | nesnesi

try {
    $result = $apiInstance->shippingAddressesPost($shipping_address);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ShippingAddressApi->shippingAddressesPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipping_address** | [**\Swagger\Client\Model\ShippingAddress**](../Model/ShippingAddress.md)| nesnesi |

### Return type

[**\Swagger\Client\Model\ShippingAddress**](../Model/ShippingAddress.md)

### Authorization

[OAuth2](../../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

