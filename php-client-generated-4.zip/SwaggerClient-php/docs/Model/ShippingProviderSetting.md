# ShippingProviderSetting

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Teslimat hizmeti sağlayıcısı ayarı nesnesi kimlik değeri. | [optional] 
**var_key** | **string** | Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken anahtarı. | 
**var_value** | **string** | Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken değeri. | 
**shipping_provider** | [**\Swagger\Client\Model\ShippingProvider**](ShippingProvider.md) | Teslimat hizmeti sağlayıcısı nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


