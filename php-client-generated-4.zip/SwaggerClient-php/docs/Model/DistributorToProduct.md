# DistributorToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Distribütor ürün bağı nesnesi kimlik değeri. | [optional] 
**distributor** | [**\Swagger\Client\Model\Distributor**](Distributor.md) | The description of the Distributor. | 
**product** | [**\Swagger\Client\Model\Product**](Product.md) | The description of the Product. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


