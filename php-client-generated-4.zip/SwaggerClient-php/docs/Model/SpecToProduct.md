# SpecToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ürün özellik ürün bağı nesnesi kimlik değeri. | [optional] 
**product** | [**\Swagger\Client\Model\Product**](Product.md) | Ürün nesnesi. | [optional] 
**spec_group** | [**\Swagger\Client\Model\SpecGroup**](SpecGroup.md) | Ürün özelliği grubu nesnesi. | 
**spec_name** | [**\Swagger\Client\Model\SpecName**](SpecName.md) | Ürün özelliği nesnesi. | 
**spec_value** | [**\Swagger\Client\Model\SpecValue**](SpecValue.md) | Ürün özellik grubu nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


