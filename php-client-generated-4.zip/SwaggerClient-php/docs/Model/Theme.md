# Theme

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Tema nesnesi kimlik değeri. | [optional] 
**platform** | **string** | Temanın kullanılacağı platform.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü.&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil.&lt;br&gt;&lt;/div&gt; | 
**type** | **string** | Tema tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;self&lt;/code&gt; : Kişisel Tema.&lt;br&gt;&lt;code&gt;standard&lt;/code&gt; : Standart Tema.&lt;br&gt;&lt;/div&gt; | [optional] 
**name** | **string** | Tema adı. | 
**preset** | **string** | Temanın rengi. | [optional] 
**directory_name** | **string** | Temanın dizini. | [optional] 
**status** | **string** | Temanın durumu. | 
**revision** | **int** | Temanın revisionı. | [optional] 
**created_at** | [**\DateTime**](\DateTime.md) | Tema nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | [**\DateTime**](\DateTime.md) | Tema nesnesinin güncellenme zamanı. | [optional] 
**attachment** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


