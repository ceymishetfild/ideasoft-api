# MemberAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Üye adresi nesnesinin benzersiz rakamsal kimlik değeri. | [optional] 
**name** | **string** | Üye Adresi adı. | [optional] 
**type** | **string** | Üye Adresi tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;shipping&lt;/code&gt; : Teslimat adresi.&lt;br&gt;&lt;code&gt;billing&lt;/code&gt; : Fatura adresi.&lt;br&gt;&lt;/div&gt; | [optional] 
**firstname** | **string** | Üyenin ismi. | [optional] 
**surname** | **string** | Üyenin soy ismi. | [optional] 
**address** | **string** | Üyenin adres bilgileri. | [optional] 
**sub_location_name** | **string** | İlçe adı. | [optional] 
**phone_number** | **string** | Üyenin telefon numarası. | [optional] 
**mobile_phone_number** | **string** | Üyenin mobil telefon numarası. | [optional] 
**tc_id** | **string** | Üyenin TC kimlik numarası. | [optional] 
**tax_number** | **string** | Üyenin vergi numarası. | [optional] 
**tax_office** | **string** | Üyenin vergi dairesi. | [optional] 
**invoice_type** | **string** | Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt; | [optional] 
**is_einvoice_user** | **bool** | Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] 
**created_at** | [**\DateTime**](\DateTime.md) | Tema nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | [**\DateTime**](\DateTime.md) | Tema nesnesinin güncellenme zamanı. | [optional] 
**member** | [**\Swagger\Client\Model\Member**](Member.md) | Üye nesnesi | [optional] 
**country** | [**\Swagger\Client\Model\Country**](Country.md) | Ülke nesnesi. | [optional] 
**location** | [**\Swagger\Client\Model\Location**](Location.md) | Şehir nesnesi. | [optional] 
**sub_location** | [**\Swagger\Client\Model\Town**](Town.md) | İlçe nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


