# Currency

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Kur nesnesi kimlik değeri. | [optional] 
**label** | **string** | Kur etiketi. | [optional] 
**buying_price** | **float** | Kurun alış fiyatı. | [optional] 
**selling_price** | **float** | Kurun satış fiyatı. | [optional] 
**abbr** | **string** | Kurun kısaltması. | [optional] 
**updated_at** | [**\DateTime**](\DateTime.md) | Kur nesnesinin güncellenme zamanı. | [optional] 
**status** | **string** | Kur nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**is_primary** | **string** | Kurun birincil kur olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Birincil kur.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Birincil kur değil.&lt;br&gt;&lt;/div&gt; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


