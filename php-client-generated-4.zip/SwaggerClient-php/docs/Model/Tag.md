# Tag

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | SEO+ etiketi nesnesi kimlik değeri. | [optional] 
**name** | **string** | SEO+ etiketi nesnesi için isim değeri. | 
**count** | **int** | SEO+ etiketinin kaç kez kullanıldığı bilgisi. | [optional] 
**page_title** | **string** | SEO+ etiketi nesnesinin etiket başlığı. | [optional] 
**meta_description** | **string** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] 
**meta_keywords** | **string** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


