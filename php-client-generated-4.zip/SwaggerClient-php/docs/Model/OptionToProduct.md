# OptionToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Varyant ürün bağı nesnesi kimlik değeri. | [optional] 
**parent_product_id** | **int** | Ana ürünün benzersiz kimlik değeri. | 
**option_group** | [**\Swagger\Client\Model\OptionGroup**](OptionGroup.md) | Varyant grubu nesnesi. | 
**option** | [**\Swagger\Client\Model\Options**](Options.md) | Varyant nesnesi. | 
**product** | [**\Swagger\Client\Model\Product**](Product.md) | Ürün nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


