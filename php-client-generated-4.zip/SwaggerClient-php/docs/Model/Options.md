# Options

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Varyant nesnesi kimlik değeri. | [optional] 
**title** | **string** | Varyant başlığı. Varyant Grubu renk is bu değer kırmızı olabilir. | 
**sort_order** | **int** | Varyant nesnesi için sıralama değeri. | [optional] 
**logo** | **string** | Logo görselinin adı.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;jpg&lt;/code&gt; : jpg dosyası için geçerli uzantı.&lt;br&gt;&lt;code&gt;png&lt;/code&gt; : png dosyası için geçerli uzantı.&lt;br&gt;&lt;code&gt;gif&lt;/code&gt; : gif dosyası için geçerli uzantı.&lt;br&gt;&lt;code&gt;jpeg&lt;/code&gt; : jpeg dosyası için geçerli uzantı.&lt;br&gt;&lt;/div&gt; | [optional] 
**option_group** | [**\Swagger\Client\Model\OptionGroup**](OptionGroup.md) | Varyant grubu nesnesi. | 
**attachment** | **string** | Varyant nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


