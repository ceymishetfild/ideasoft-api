# Payment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ödeme nesnesi kimlik değeri. | [optional] 
**member_firstname** | **string** | Üyenin ismi. | 
**member_surname** | **string** | Üyenin soy ismi. | 
**member_email** | **string** | Üyenin e-mail adresi. | 
**member_phone** | **string** | Üyenin telefon numarası. | [optional] 
**payment_type_name** | **string** | Ödeme tipi | 
**payment_provider_code** | **string** | Ödeme hizmeti sağlayıcısı kodu. Bu değer ön tanımlıdır. | 
**payment_provider_name** | **string** | Ödeme hizmeti sağlayıcısı adı. Bu değer ön tanımlıdır. | 
**payment_gateway_name** | **string** | Ödeme kanalı adı. Bu değer ön tanımlıdır. | 
**payment_gateway_code** | **string** | Ödeme kanalı kodu. Bu değer ön tanımlıdır. | 
**bank_name** | **string** | Ödeme yapılan banka. Bu değer ön tanımlıdır. | [optional] 
**device_type** | **string** | Ödemenin gerçekleştiği cihaz bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil&lt;br&gt;&lt;code&gt;tablet&lt;/code&gt; : Tablet&lt;br&gt;&lt;/div&gt; | 
**client_ip** | **string** | Müşterinin IP adresi. | 
**currency_rates** | **string** | Kur oranları. | 
**amount** | **float** | Ödemenin saf fiyatı. | 
**final_amount** | **float** | Ödemenin son fiyatı. | 
**sum_of_gained_points** | **float** | Ödemeden kazanılan toplam puan. | [optional] 
**installment** | **int** | Ödemenin standart taksit sayısı. | 
**installment_rate** | **float** | Ödemenin taksit oranı. | 
**extra_installment** | **int** | Ödemenin ekstra taksit sayısı. | [optional] 
**currency** | **string** | Kur bilgisi. | 
**transaction_id** | **string** | Siparişin numarası. | [optional] 
**member_note** | **string** | Müşterinin ödeme notu. | [optional] 
**user_note** | **string** | Yönetici(admin) ödeme notu. | [optional] 
**status** | **string** | Ödeme durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;/div&gt; | 
**error_message** | **string** | Ödemenin hata mesajı. | [optional] 
**card_saving_system** | **string** | Kart saklama sistemi. | [optional] 
**created_at** | [**\DateTime**](\DateTime.md) | Ödeme nesnesinin oluşturulma zamanı. | [optional] 
**member** | [**\Swagger\Client\Model\Member**](Member.md) | Üye nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


