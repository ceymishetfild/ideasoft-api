# CartItemAttribute

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sepet kalemi özelliği nesnesi kimlik değeri. | [optional] 
**name** | **string** | Sepet kalemi özelliği nesnesinin isim değeri. Örneğin, sepet kalemi kalem ise bu değer renk olabilir. | [optional] 
**value** | **string** | Sepet kalemi özelliği nesnesinin değeri. Örneğin, sepet kalemi kalem, isim değeri renk ise bu değer kırmızı olabilir. | [optional] 
**created_at** | [**\DateTime**](\DateTime.md) | Sepet kalemi özelliği nesnesinin oluşturulma zamanı. | [optional] 
**cart_item** | [**\Swagger\Client\Model\CartItem**](CartItem.md) | Sepet kalemi nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


