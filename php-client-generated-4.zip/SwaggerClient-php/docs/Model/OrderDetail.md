# OrderDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sipariş detayı nesnesi kimlik değeri. | [optional] 
**var_key** | **string** | Sipariş detayı nesnesi için değişken anahtarı. | 
**var_value** | **string** | Sipariş detayı nesnesi için değişken değeri. | 
**order** | [**\Swagger\Client\Model\Order**](Order.md) | Sipariş nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


