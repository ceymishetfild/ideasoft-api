# \SelectionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SelectionGroupsGet**](SelectionGroupApi.md#SelectionGroupsGet) | **Get** /selection_groups | Ek Özellik Grubu Listesi Alma
[**SelectionGroupsIdDelete**](SelectionGroupApi.md#SelectionGroupsIdDelete) | **Delete** /selection_groups/{id} | Ek Özellik Grubu Silme
[**SelectionGroupsIdGet**](SelectionGroupApi.md#SelectionGroupsIdGet) | **Get** /selection_groups/{id} | Ek Özellik Grubu Alma
[**SelectionGroupsIdPut**](SelectionGroupApi.md#SelectionGroupsIdPut) | **Put** /selection_groups/{id} | Ek Özellik Grubu Güncelleme
[**SelectionGroupsPost**](SelectionGroupApi.md#SelectionGroupsPost) | **Post** /selection_groups | Ek Özellik Grubu Oluşturma


# **SelectionGroupsGet**
> SelectionGroup SelectionGroupsGet(ctx, optional)
Ek Özellik Grubu Listesi Alma

Ek Özellik Grubu listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **title** | **string**| Ek Özellik Grubu başlığı | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SelectionGroupsIdDelete**
> SelectionGroupsIdDelete(ctx, id)
Ek Özellik Grubu Silme

Kalıcı olarak ilgili Ek Özellik Grubunu siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ek Özellik Grubu nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SelectionGroupsIdGet**
> SelectionGroup SelectionGroupsIdGet(ctx, id)
Ek Özellik Grubu Alma

İlgili Ek Özellik Grubunu getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ek Özellik Grubu nesnesinin id değeri | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SelectionGroupsIdPut**
> SelectionGroup SelectionGroupsIdPut(ctx, id, selectionGroup)
Ek Özellik Grubu Güncelleme

İlgili Ek Özellik Grubunu günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ek Özellik Grubu nesnesinin id değeri | 
  **selectionGroup** | [**SelectionGroup**](SelectionGroup.md)| SelectionGroup nesnesi | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SelectionGroupsPost**
> SelectionGroup SelectionGroupsPost(ctx, selectionGroup)
Ek Özellik Grubu Oluşturma

Yeni bir Ek Özellik Grubu oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **selectionGroup** | [**SelectionGroup**](SelectionGroup.md)| SelectionGroup nesnesi | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

