# \OptionsApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**OptionsGet**](OptionsApi.md#OptionsGet) | **Get** /options | Varyant Listesi Alma
[**OptionsIdDelete**](OptionsApi.md#OptionsIdDelete) | **Delete** /options/{id} | Varyant Silme
[**OptionsIdGet**](OptionsApi.md#OptionsIdGet) | **Get** /options/{id} | Varyant Alma
[**OptionsIdPut**](OptionsApi.md#OptionsIdPut) | **Put** /options/{id} | Varyant Güncelleme
[**OptionsPost**](OptionsApi.md#OptionsPost) | **Post** /options | Varyant Oluşturma


# **OptionsGet**
> Options OptionsGet(ctx, optional)
Varyant Listesi Alma

Varyant listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **title** | **string**| Varyant başlığı | 
 **optionGroup** | **int32**| Varyant Grubu id | 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OptionsIdDelete**
> OptionsIdDelete(ctx, id)
Varyant Silme

Kalıcı olarak ilgili Varyantı siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Varyant nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OptionsIdGet**
> Options OptionsIdGet(ctx, id)
Varyant Alma

İlgili Varyantı getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Varyant nesnesinin id değeri | 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OptionsIdPut**
> Options OptionsIdPut(ctx, id, options)
Varyant Güncelleme

İlgili Varyantı günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Varyant nesnesinin id değeri | 
  **options** | [**Options**](Options.md)| Options nesnesi | 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OptionsPost**
> Options OptionsPost(ctx, options)
Varyant Oluşturma

Yeni bir Varyant oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **options** | [**Options**](Options.md)| Options nesnesi | 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

