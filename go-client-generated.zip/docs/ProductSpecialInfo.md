# ProductSpecialInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Özel bilgi alanı nesnesi kimlik değeri. | [optional] [default to null]
**Title** | **string** | Özel bilgi alanı başlığı. | [default to null]
**Content** | **string** | Özel bilgi alanı içeriği. | [default to null]
**Status** | **int32** | Özel bilgi alanı aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | [default to null]
**Product** | [***Product**](Product.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


