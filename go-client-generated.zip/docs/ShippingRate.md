# ShippingRate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Kargo oranı nesnesi kimlik değeri. | [optional] [default to null]
**VolumetricWeightStart** | **int32** | İlgili kargo firması, ilgili bölge ve ilgili orana ait minimum desi değeri. | [default to null]
**VolumetricWeightEnd** | **int32** | İlgili kargo firması, ilgili bölge ve ilgili orana ait maximum desi değeri. | [default to null]
**Rate** | **float32** | Seçili bölge ve kargo firması için kargo oranı. | [default to null]
**Region** | [***Region**](Region.md) | Bölge nesnesi. | [optional] [default to null]
**ShippingCompany** | [***ShippingCompany**](ShippingCompany.md) | Kargo firması nesnesi. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


