# Maillist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Mail listesi nesnesi kimlik değeri. | [optional] [default to null]
**Name** | **string** | Mail listesi nesnesi için isim değeri. | [default to null]
**Email** | **string** | Ziyaretçi veya üyenin mail adresi. | [default to null]
**LastMailSentDate** | [**time.Time**](time.Time.md) | En son e-mail gönderilen zaman. | [optional] [default to null]
**CreatorIpAddress** | **string** | Mail listesi nesnesini oluşturan kişinin IP adresi. | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Mail listesi nesnesinin oluşturulma zamanı. | [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Mail listesi nesnesinin güncellenme zamanı. | [default to null]
**MaillistGroup** | [***MaillistGroup**](MaillistGroup.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


