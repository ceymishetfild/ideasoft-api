# ShippingProviderSetting

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Teslimat hizmeti sağlayıcısı ayarı nesnesi kimlik değeri. | [optional] [default to null]
**VarKey** | **string** | Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken anahtarı. | [default to null]
**VarValue** | **string** | Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken değeri. | [default to null]
**ShippingProvider** | [***ShippingProvider**](ShippingProvider.md) | Teslimat hizmeti sağlayıcısı nesnesi. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


