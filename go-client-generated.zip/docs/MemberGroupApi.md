# \MemberGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**MemberGroupsGet**](MemberGroupApi.md#MemberGroupsGet) | **Get** /member_groups | Üye Grubu Listesi Alma
[**MemberGroupsIdDelete**](MemberGroupApi.md#MemberGroupsIdDelete) | **Delete** /member_groups/{id} | Üye Grubu Silme
[**MemberGroupsIdGet**](MemberGroupApi.md#MemberGroupsIdGet) | **Get** /member_groups/{id} | Üye Grubu Alma
[**MemberGroupsIdPut**](MemberGroupApi.md#MemberGroupsIdPut) | **Put** /member_groups/{id} | Üye Grubu Güncelleme
[**MemberGroupsPost**](MemberGroupApi.md#MemberGroupsPost) | **Post** /member_groups | Üye Grubu Oluşturma


# **MemberGroupsGet**
> MemberGroup MemberGroupsGet(ctx, optional)
Üye Grubu Listesi Alma

Üye Grubu listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | 
 **name** | **string**| Üye Grubu adı | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MemberGroupsIdDelete**
> MemberGroupsIdDelete(ctx, id)
Üye Grubu Silme

Kalıcı olarak ilgili Üye Grubunu siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Üye Grubu nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MemberGroupsIdGet**
> MemberGroup MemberGroupsIdGet(ctx, id)
Üye Grubu Alma

İlgili Üye Grubunu getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Üye Grubu nesnesinin id değeri | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MemberGroupsIdPut**
> MemberGroup MemberGroupsIdPut(ctx, id, memberGroup)
Üye Grubu Güncelleme

İlgili Üye Grubunu günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Üye Grubu nesnesinin id değeri | 
  **memberGroup** | [**MemberGroup**](MemberGroup.md)|  nesnesi | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MemberGroupsPost**
> MemberGroup MemberGroupsPost(ctx, memberGroup)
Üye Grubu Oluşturma

Yeni bir Üye Grubu oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **memberGroup** | [**MemberGroup**](MemberGroup.md)|  nesnesi | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

