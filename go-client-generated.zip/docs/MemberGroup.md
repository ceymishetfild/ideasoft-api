# MemberGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Üye Grubu nesnesi kimlik değeri. | [optional] [default to null]
**Name** | **string** | Üye Grubu nesnesi için isim değeri. | [default to null]
**PriceIndex** | **int32** | Üye Grubunun fiyat indisi. Örnek Fiyat 2. | [default to null]
**AllowedPaymentGateways** | **string** | Üye Grubunun izin verilmiş ödeme kanalları. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


