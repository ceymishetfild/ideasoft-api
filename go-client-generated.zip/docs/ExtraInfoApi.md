# \ExtraInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ExtraInfosGet**](ExtraInfoApi.md#ExtraInfosGet) | **Get** /extra_infos | Ek Bilgi Listesi Alma
[**ExtraInfosIdDelete**](ExtraInfoApi.md#ExtraInfosIdDelete) | **Delete** /extra_infos/{id} | Ek Bilgi Silme
[**ExtraInfosIdGet**](ExtraInfoApi.md#ExtraInfosIdGet) | **Get** /extra_infos/{id} | Ek Bilgi Alma
[**ExtraInfosIdPut**](ExtraInfoApi.md#ExtraInfosIdPut) | **Put** /extra_infos/{id} | Ek Bilgi Güncelleme
[**ExtraInfosPost**](ExtraInfoApi.md#ExtraInfosPost) | **Post** /extra_infos | Ek Bilgi Oluşturma


# **ExtraInfosGet**
> ExtraInfo ExtraInfosGet(ctx, optional)
Ek Bilgi Listesi Alma

Ek Bilgi listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | 
 **name** | **string**| Ek Bilgi adı | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ExtraInfosIdDelete**
> ExtraInfosIdDelete(ctx, id)
Ek Bilgi Silme

Kalıcı olarak ilgili Ek Bilgiyi siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ek Bilgi nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ExtraInfosIdGet**
> ExtraInfo ExtraInfosIdGet(ctx, id)
Ek Bilgi Alma

İlgili Ek Bilgiyi getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ek Bilgi nesnesinin id değeri | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ExtraInfosIdPut**
> ExtraInfo ExtraInfosIdPut(ctx, id, extraInfo)
Ek Bilgi Güncelleme

İlgili Ek Bilgiyi günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ek Bilgi nesnesinin id değeri | 
  **extraInfo** | [**ExtraInfo**](ExtraInfo.md)|  nesnesi | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ExtraInfosPost**
> ExtraInfo ExtraInfosPost(ctx, extraInfo)
Ek Bilgi Oluşturma

Yeni bir Ek Bilgi oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **extraInfo** | [**ExtraInfo**](ExtraInfo.md)|  nesnesi | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

