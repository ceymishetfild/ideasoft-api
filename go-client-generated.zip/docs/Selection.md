# Selection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ek özellik nesnesi kimlik değeri. | [optional] [default to null]
**Title** | **string** | Ek özellik nesnesinin başlığı. | [optional] [default to null]
**SortOrder** | **int32** | Ek özellik nesnesi için sıralama değeri. | [default to null]
**SelectionGroup** | [***SelectionGroup**](SelectionGroup.md) | Ek özellik grubu nesnesi. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


