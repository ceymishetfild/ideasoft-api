# ProductToTag

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ürün SEO+ etiketi bağı nesnesi kimlik değeri. | [optional] [default to null]
**Product** | [***Product**](Product.md) | Ürün nesnesi. | [default to null]
**Tag** | [***Tag**](Tag.md) | SEO+ etiketi nesnesi. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


