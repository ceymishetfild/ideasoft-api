# Distributor

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Distributor nesnesi kimlik değeri. | [optional] [default to null]
**Name** | **string** | Distributor nesnesi için isim değeri. | [default to null]
**Email** | **string** | E-mail adresi. | [optional] [default to null]
**Phone** | **string** | Telefon numarası. | [optional] [default to null]
**ContactPerson** | **string** | İletişim kişisi. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


