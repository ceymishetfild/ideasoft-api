# \CartItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CartItemsIdDelete**](CartItemApi.md#CartItemsIdDelete) | **Delete** /cart_items/{id} | Sepet Kalemi Silme
[**CartItemsIdPut**](CartItemApi.md#CartItemsIdPut) | **Put** /cart_items/{id} | Sepet Kalemi Güncelleme
[**CartItemsPost**](CartItemApi.md#CartItemsPost) | **Post** /cart_items | Sepet Kalemi Oluşturma


# **CartItemsIdDelete**
> CartItemsIdDelete(ctx, id)
Sepet Kalemi Silme

Kalıcı olarak ilgili Sepet Kalemini siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Sepet Kalemi nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **CartItemsIdPut**
> CartItem CartItemsIdPut(ctx, id)
Sepet Kalemi Güncelleme

İlgili Sepet Kalemini günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Sepet Kalemi nesnesinin id değeri | 

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **CartItemsPost**
> CartItem CartItemsPost(ctx, cartItem)
Sepet Kalemi Oluşturma

Yeni bir Sepet Kalemi oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **cartItem** | [**CartItem**](CartItem.md)| CartItem nesnesi | 

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

