# OrderRefundRequestItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Sipariş iptal talebi kalemi nesnesi kimlik değeri. | [optional] [default to null]
**Amount** | **float32** | Sipariş iptal talebi istenen ürün miktarı. | [default to null]
**Reason** | **string** | Sipariş iptal talebi sebebi. Tanımlı dört seçenekten biri seçilmelidir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Ürünü iade etmek istiyorum.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Ürünü değiştirmek istiyorum.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Faturadaki ürünler ile bana gelen ürünler farklı.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Diğer&lt;/code&gt; : &lt;br&gt;&lt;/div&gt; | [default to null]
**Details** | **string** | Sipariş iptal talebinin detaylı açıklaması. | [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Sipariş iptal talebi kalemi nesnesinin oluşturulma zamanı. | [optional] [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Sipariş iptal talebi kalemi nesnesinin güncellenme zamanı. | [optional] [default to null]
**OrderItem** | [***OrderItem**](OrderItem.md) |  | [optional] [default to null]
**OrderRefundRequest** | [***OrderRefundRequest**](OrderRefundRequest.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


