# Shipment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Teslimat nesnesi kimlik değeri. | [optional] [default to null]
**Barcode** | **string** | Teslimat barkodu. | [optional] [default to null]
**WaybillNo** | **string** | Teslimat fatura numarası. | [optional] [default to null]
**InvoiceKey** | **string** | Teslimat irsaliye makbuzu numarası. | [optional] [default to null]
**CargoOffice** | **string** | Teslimatın kargo şubesi | [optional] [default to null]
**Code** | **string** | Teslimat kodu. Kargo takip kodu. | [optional] [default to null]
**DeliveryType** | **string** | Teslimat tipi | [optional] [default to null]
**InvoiceIncluded** | **string** | Faturanın pakete dahillik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Dahil.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Dahil değil.&lt;br&gt;&lt;/div&gt; | [optional] [default to null]
**PayAtDoorAmount** | **float32** | Kapıda ödeme hizmeti bedeli. | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Teslimat nesnesinin oluşturulma zamanı. | [optional] [default to null]
**Status** | **int32** | Teslimat nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | [default to null]
**Order** | [***Order**](Order.md) | Sipariş nesnesi. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


