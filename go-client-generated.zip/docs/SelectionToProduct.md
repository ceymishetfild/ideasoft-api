# SelectionToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ek özellik ürün bağı nesnesi kimlik değeri. | [optional] [default to null]
**Selection** | [***Selection**](Selection.md) | Ek özellik nesnesi. | [default to null]
**Product** | [***Product**](Product.md) | Ürün nesnesi. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


