# Theme

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Tema nesnesi kimlik değeri. | [optional] [default to null]
**Platform** | **string** | Temanın kullanılacağı platform.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü.&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil.&lt;br&gt;&lt;/div&gt; | [default to null]
**Type_** | **string** | Tema tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;self&lt;/code&gt; : Kişisel Tema.&lt;br&gt;&lt;code&gt;standard&lt;/code&gt; : Standart Tema.&lt;br&gt;&lt;/div&gt; | [optional] [default to null]
**Name** | **string** | Tema adı. | [default to null]
**Preset** | **string** | Temanın rengi. | [optional] [default to null]
**DirectoryName** | **string** | Temanın dizini. | [optional] [default to null]
**Status** | **string** | Temanın durumu. | [default to null]
**Revision** | **int32** | Temanın revisionı. | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Tema nesnesinin oluşturulma zamanı. | [optional] [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Tema nesnesinin güncellenme zamanı. | [optional] [default to null]
**Attachment** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


