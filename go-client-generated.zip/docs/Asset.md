# Asset

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Key** | **string** | Tema Dosyası nesnesi anahtar değeri. | [optional] [default to null]
**ContentType** | **string** | Tema Dosyası içerik tipi. Geçerli bir MIME Content-Type verilmelidir. | [optional] [default to null]
**Attachment** | **string** | Tema Dosyası içeriği. | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Tema Dosyası nesnesinin oluşturulma zamanı. | [optional] [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Tema Dosyası nesnesinin güncellenme zamanı. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


