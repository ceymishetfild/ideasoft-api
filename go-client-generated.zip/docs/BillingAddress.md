# BillingAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Sipariş adresi nesnesi kimlik değeri. | [optional] [default to null]
**Firstname** | **string** | Müşterinin ismi. | [default to null]
**Surname** | **string** | Müşterinin soy ismi. | [default to null]
**Country** | **string** | Müşterinin ülke bilgisi. | [default to null]
**Location** | **string** | Müşterinin şehir bilgisi. | [default to null]
**SubLocation** | **string** | Müşterinin ilçe bilgisi. | [optional] [default to null]
**Address** | **string** | Müşterinin adres bilgisi. | [default to null]
**PhoneNumber** | **string** | Müşterinin telefon numarası. | [default to null]
**MobilePhoneNumber** | **string** | Müşterinin mobil telefon numarası. | [optional] [default to null]
**Order** | [***Order**](Order.md) | Sipariş nesnesi. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


