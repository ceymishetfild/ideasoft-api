# \OrderDetailApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**OrderDetailsGet**](OrderDetailApi.md#OrderDetailsGet) | **Get** /order_details | Sipariş Detayı Listesi Alma
[**OrderDetailsIdDelete**](OrderDetailApi.md#OrderDetailsIdDelete) | **Delete** /order_details/{id} | Sipariş Detayı Silme
[**OrderDetailsIdGet**](OrderDetailApi.md#OrderDetailsIdGet) | **Get** /order_details/{id} | Sipariş Detayı Alma
[**OrderDetailsIdPut**](OrderDetailApi.md#OrderDetailsIdPut) | **Put** /order_details/{id} | Sipariş Detayı Güncelleme
[**OrderDetailsPost**](OrderDetailApi.md#OrderDetailsPost) | **Post** /order_details | Sipariş Detayı Oluşturma


# **OrderDetailsGet**
> OrderDetail OrderDetailsGet(ctx, optional)
Sipariş Detayı Listesi Alma

Sipariş Detayı listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **order** | **int32**| Sipariş id | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OrderDetailsIdDelete**
> OrderDetailsIdDelete(ctx, id)
Sipariş Detayı Silme

Kalıcı olarak ilgili Sipariş Detayı siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Sipariş Detayı nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OrderDetailsIdGet**
> OrderDetail OrderDetailsIdGet(ctx, id)
Sipariş Detayı Alma

İlgili Sipariş Detayı getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Sipariş Detayı nesnesinin id değeri | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OrderDetailsIdPut**
> OrderDetail OrderDetailsIdPut(ctx, id, orderDetail)
Sipariş Detayı Güncelleme

İlgili Sipariş Detayı günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Sipariş Detayı nesnesinin id değeri | 
  **orderDetail** | [**OrderDetail**](OrderDetail.md)| OrderDetail nesnesi | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OrderDetailsPost**
> OrderDetail OrderDetailsPost(ctx, orderDetail)
Sipariş Detayı Oluşturma

Yeni bir Sipariş Detayı oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **orderDetail** | [**OrderDetail**](OrderDetail.md)| OrderDetail nesnesi | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

