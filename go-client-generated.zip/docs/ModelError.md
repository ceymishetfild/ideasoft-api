# ModelError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Code** | **int32** | HTTP Hata kodu. | [optional] [default to null]
**ErrorMessage** | **string** | Hata mesajı. Hata mesajları İngilizce dilindedir. | [optional] [default to null]
**ErrorCode** | **int32** | Hata kodu. Eğer ek bir hata kodu varsa bu alanda belirtilir. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


