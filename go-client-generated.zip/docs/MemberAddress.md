# MemberAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Üye adresi nesnesinin benzersiz rakamsal kimlik değeri. | [optional] [default to null]
**Name** | **string** | Üye Adresi adı. | [optional] [default to null]
**Type_** | **string** | Üye Adresi tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;shipping&lt;/code&gt; : Teslimat adresi.&lt;br&gt;&lt;code&gt;billing&lt;/code&gt; : Fatura adresi.&lt;br&gt;&lt;/div&gt; | [optional] [default to null]
**Firstname** | **string** | Üyenin ismi. | [optional] [default to null]
**Surname** | **string** | Üyenin soy ismi. | [optional] [default to null]
**Address** | **string** | Üyenin adres bilgileri. | [optional] [default to null]
**SubLocationName** | **string** | İlçe adı. | [optional] [default to null]
**PhoneNumber** | **string** | Üyenin telefon numarası. | [optional] [default to null]
**MobilePhoneNumber** | **string** | Üyenin mobil telefon numarası. | [optional] [default to null]
**TcId** | **string** | Üyenin TC kimlik numarası. | [optional] [default to null]
**TaxNumber** | **string** | Üyenin vergi numarası. | [optional] [default to null]
**TaxOffice** | **string** | Üyenin vergi dairesi. | [optional] [default to null]
**InvoiceType** | **string** | Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt; | [optional] [default to null]
**IsEinvoiceUser** | **bool** | Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Tema nesnesinin oluşturulma zamanı. | [optional] [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Tema nesnesinin güncellenme zamanı. | [optional] [default to null]
**Member** | [***Member**](Member.md) |  | [optional] [default to null]
**Country** | [***Country**](Country.md) |  | [optional] [default to null]
**Location** | [***Location**](Location.md) |  | [optional] [default to null]
**SubLocation** | [***Town**](Town.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


