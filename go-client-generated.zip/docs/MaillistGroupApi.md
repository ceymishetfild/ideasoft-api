# \MaillistGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**MaillistGroupsGet**](MaillistGroupApi.md#MaillistGroupsGet) | **Get** /maillist_groups | Mail Listesi Grubu Listesi Alma
[**MaillistGroupsIdDelete**](MaillistGroupApi.md#MaillistGroupsIdDelete) | **Delete** /maillist_groups/{id} | Mail Listesi Grubu Silme
[**MaillistGroupsIdGet**](MaillistGroupApi.md#MaillistGroupsIdGet) | **Get** /maillist_groups/{id} | Mail Listesi Grubu Alma
[**MaillistGroupsIdPut**](MaillistGroupApi.md#MaillistGroupsIdPut) | **Put** /maillist_groups/{id} | Mail Listesi Grubu Güncelleme
[**MaillistGroupsPost**](MaillistGroupApi.md#MaillistGroupsPost) | **Post** /maillist_groups | Mail Listesi Grubu Oluşturma


# **MaillistGroupsGet**
> MaillistGroup MaillistGroupsGet(ctx, optional)
Mail Listesi Grubu Listesi Alma

Mail Listesi Grubu listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **name** | **string**| Mail Listesi Grubu adı | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MaillistGroupsIdDelete**
> MaillistGroupsIdDelete(ctx, id)
Mail Listesi Grubu Silme

Kalıcı olarak ilgili Mail Listesi Grubunu siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Mail Listesi Grubu nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MaillistGroupsIdGet**
> MaillistGroup MaillistGroupsIdGet(ctx, id)
Mail Listesi Grubu Alma

İlgili Mail Listesi Grubunu getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Mail Listesi Grubu nesnesinin id değeri | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MaillistGroupsIdPut**
> MaillistGroup MaillistGroupsIdPut(ctx, id, maillistGroup)
Mail Listesi Grubu Güncelleme

İlgili Mail Listesi Grubunu günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Mail Listesi Grubu nesnesinin id değeri | 
  **maillistGroup** | [**MaillistGroup**](MaillistGroup.md)| MaillistGroup nesnesi | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MaillistGroupsPost**
> MaillistGroup MaillistGroupsPost(ctx, maillistGroup)
Mail Listesi Grubu Oluşturma

Yeni bir Mail Listesi Grubu oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **maillistGroup** | [**MaillistGroup**](MaillistGroup.md)| MaillistGroup nesnesi | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

