# OptionToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Varyant ürün bağı nesnesi kimlik değeri. | [optional] [default to null]
**ParentProductId** | **int32** | Ana ürünün benzersiz kimlik değeri. | [default to null]
**OptionGroup** | [***OptionGroup**](OptionGroup.md) |  | [optional] [default to null]
**Option** | [***Options**](Options.md) |  | [optional] [default to null]
**Product** | [***Product**](Product.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


