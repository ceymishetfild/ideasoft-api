# OptionToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Varyant ürün bağı nesnesi kimlik değeri. | [optional] [default to null]
**ParentProductId** | **int32** | Ana ürünün benzersiz kimlik değeri. | [default to null]
**OptionGroup** | [***OptionGroup**](OptionGroup.md) | Varyant grubu nesnesi. | [default to null]
**Option** | [***Options**](Options.md) | Varyant nesnesi. | [default to null]
**Product** | [***Product**](Product.md) | Ürün nesnesi. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


