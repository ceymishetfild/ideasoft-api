# OptionGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Varyant grubu nesnesi kimlik değeri. | [optional] [default to null]
**Title** | **string** | Varyant grubunun başlığı. Varyant değeri kırmızı ise bu değer renk olabilir. | [default to null]
**SortOrder** | **int32** | Varyant grubunun sıralama değeri. | [optional] [default to null]
**FilterStatus** | **string** | Varyant grubunun filtre menüsündeki gösterim durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Gösterilsin.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Gösterilmesin.&lt;br&gt;&lt;/div&gt; | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


