# \ProductToCategoryApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductToCategoriesGet**](ProductToCategoryApi.md#ProductToCategoriesGet) | **Get** /product_to_categories | Ürün Kategori Bağı Listesi Alma
[**ProductToCategoriesIdDelete**](ProductToCategoryApi.md#ProductToCategoriesIdDelete) | **Delete** /product_to_categories/{id} | Ürün Kategori Bağı Silme
[**ProductToCategoriesIdGet**](ProductToCategoryApi.md#ProductToCategoriesIdGet) | **Get** /product_to_categories/{id} | Ürün Kategori Bağı Alma
[**ProductToCategoriesIdPut**](ProductToCategoryApi.md#ProductToCategoriesIdPut) | **Put** /product_to_categories/{id} | Ürün Kategori Bağı Güncelleme
[**ProductToCategoriesPost**](ProductToCategoryApi.md#ProductToCategoriesPost) | **Post** /product_to_categories | Ürün Kategori Bağı Oluşturma


# **ProductToCategoriesGet**
> ProductToCategory ProductToCategoriesGet(ctx, optional)
Ürün Kategori Bağı Listesi Alma

Ürün Kategori Bağı listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **product** | **int32**| Ürün id | 
 **category** | **int32**| Kategori id | 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductToCategoriesIdDelete**
> ProductToCategoriesIdDelete(ctx, id)
Ürün Kategori Bağı Silme

Kalıcı olarak ilgili Ürün Kategori Bağını siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün Kategori Bağı nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductToCategoriesIdGet**
> ProductToCategory ProductToCategoriesIdGet(ctx, id)
Ürün Kategori Bağı Alma

İlgili Ürün Kategori Bağını getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün Kategori Bağı nesnesinin id değeri | 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductToCategoriesIdPut**
> ProductToCategory ProductToCategoriesIdPut(ctx, id, productToCategory)
Ürün Kategori Bağı Güncelleme

İlgili Ürün Kategori Bağını günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün Kategori Bağı nesnesinin id değeri | 
  **productToCategory** | [**ProductToCategory**](ProductToCategory.md)| ProductToCategory nesnesi | 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductToCategoriesPost**
> ProductToCategory ProductToCategoriesPost(ctx, productToCategory)
Ürün Kategori Bağı Oluşturma

Yeni bir Ürün Kategori Bağı oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **productToCategory** | [**ProductToCategory**](ProductToCategory.md)| ProductToCategory nesnesi | 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

