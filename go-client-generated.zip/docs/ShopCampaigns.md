# ShopCampaigns

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Promosyon nesnesi kimlik değeri. | [optional] [default to null]
**Label** | **string** | Promosyon adı. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


