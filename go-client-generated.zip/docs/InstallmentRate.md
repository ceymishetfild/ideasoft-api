# InstallmentRate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Taksit oranı nesnesi kimlik değeri. | [optional] [default to null]
**Installment** | **int32** | Taksit adeti. | [default to null]
**Rate** | **float32** | Taksit adeti için oran bilgisi. | [default to null]
**PaymentGateway** | [***PaymentGateway**](PaymentGateway.md) | Ödeme kanalı nesnesi. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


