# ExtraInfoToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ek bilgi ürün bağı nesnesi kimlik değeri. | [optional] [default to null]
**Value** | **string** | Ek bilgi ürün bağı değeridir. Ek bilgi renk ise bu değer kırmızı olabilir. | [default to null]
**ExtraInfo** | [***ExtraInfo**](ExtraInfo.md) |  | [optional] [default to null]
**Product** | [***Product**](Product.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


