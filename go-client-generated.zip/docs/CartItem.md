# CartItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Sepet kalemi nesnesi kimlik değeri. | [optional] [default to null]
**ParentProductId** | **int32** | Ana ürünün benzersiz rakamsal kimlik değeri. | [optional] [default to null]
**Quantity** | **float32** | Sepetteki kalem adedi. | [default to null]
**CategoryId** | **int32** | Sepetteki kaleme ait kategorinin benzersiz kimlik değeri. | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Sepet kalemi nesnesinin oluşturulma zamanı. | [optional] [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Sepet kalemi nesnesinin güncellenme zamanı. | [optional] [default to null]
**Cart** | [***Cart**](Cart.md) | Sepet nesnesi. | [default to null]
**Product** | [***Product**](Product.md) | Ürün nesnesi. | [default to null]
**Attributes** | [**[]CartItemAttribute**](CartItemAttribute.md) | Sepet kalemi özelliği barındıran liste. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


