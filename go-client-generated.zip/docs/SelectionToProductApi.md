# \SelectionToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SelectionToProductsGet**](SelectionToProductApi.md#SelectionToProductsGet) | **Get** /selection_to_products | Ek Özellik Ürün Bağı Listesi Alma
[**SelectionToProductsIdDelete**](SelectionToProductApi.md#SelectionToProductsIdDelete) | **Delete** /selection_to_products/{id} | Ek Özellik Ürün Bağı Silme
[**SelectionToProductsIdGet**](SelectionToProductApi.md#SelectionToProductsIdGet) | **Get** /selection_to_products/{id} | Ek Özellik Ürün Bağı Alma
[**SelectionToProductsIdPut**](SelectionToProductApi.md#SelectionToProductsIdPut) | **Put** /selection_to_products/{id} | Ek Özellik Ürün Bağı Güncelleme
[**SelectionToProductsPost**](SelectionToProductApi.md#SelectionToProductsPost) | **Post** /selection_to_products | Ek Özellik Ürün Bağı Oluşturma


# **SelectionToProductsGet**
> SelectionToProduct SelectionToProductsGet(ctx, optional)
Ek Özellik Ürün Bağı Listesi Alma

Ek Özellik Ürün Bağı listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | 
 **selection** | **int32**| Ek Özellik id | 
 **product** | **int32**| Ürün id | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SelectionToProductsIdDelete**
> SelectionToProductsIdDelete(ctx, id)
Ek Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ek Özellik Ürün Bağını siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ek Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SelectionToProductsIdGet**
> SelectionToProduct SelectionToProductsIdGet(ctx, id)
Ek Özellik Ürün Bağı Alma

İlgili Ek Özellik Ürün Bağını getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ek Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SelectionToProductsIdPut**
> SelectionToProduct SelectionToProductsIdPut(ctx, id, selectionToProduct)
Ek Özellik Ürün Bağı Güncelleme

İlgili Ek Özellik Ürün Bağını günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ek Özellik Ürün Bağı nesnesinin id değeri | 
  **selectionToProduct** | [**SelectionToProduct**](SelectionToProduct.md)|  nesnesi | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SelectionToProductsPost**
> SelectionToProduct SelectionToProductsPost(ctx, selectionToProduct)
Ek Özellik Ürün Bağı Oluşturma

Yeni bir Ek Özellik Ürün Bağı oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **selectionToProduct** | [**SelectionToProduct**](SelectionToProduct.md)|  nesnesi | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

