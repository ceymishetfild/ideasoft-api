# ShipmentItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Teslimat Kalemi nesnesi kimlik değeri. | [optional] [default to null]
**RootProductId** | **int32** | Ana ürünün id değeri. | [optional] [default to null]
**Amount** | **int32** | Ürünün stok tipi cinsinden miktarı. | [default to null]
**Price** | **float32** | Ürünün fiyatı. | [default to null]
**ProductLabel** | **string** | Ürün başlığı. | [optional] [default to null]
**Currency** | **string** | Ürünün kur bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;USD&lt;/code&gt; : Amerikan Doları&lt;br&gt;&lt;code&gt;EUR&lt;/code&gt; : Euro&lt;br&gt;&lt;code&gt;TL&lt;/code&gt; : Türk Lirası&lt;br&gt;&lt;code&gt;GBP&lt;/code&gt; : İngiliz Sterlini&lt;br&gt;&lt;code&gt;JPY&lt;/code&gt; : Japon Yeni&lt;br&gt;&lt;code&gt;CNY&lt;/code&gt; : Çin Yuanı&lt;br&gt;&lt;code&gt;GR&lt;/code&gt; : Gram Altın&lt;br&gt;&lt;code&gt;CHF&lt;/code&gt; : İsviçre Frangı&lt;br&gt;&lt;/div&gt; | [default to null]
**Tax** | **int32** | Ürünün vergi değeri. | [optional] [default to null]
**Dm3** | **float32** | Ürünün desi bilgisi. | [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Teslimat Kalemi nesnesinin oluşturulma zamanı. | [optional] [default to null]
**Status** | **int32** | Teslimat Kalemi nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Teslimat Kalemi nesnesinin güncellenme zamanı. | [optional] [default to null]
**OrderItem** | [***OrderItem**](OrderItem.md) |  | [optional] [default to null]
**Product** | [***Product**](Product.md) |  | [optional] [default to null]
**Shipment** | [***Shipment**](Shipment.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


