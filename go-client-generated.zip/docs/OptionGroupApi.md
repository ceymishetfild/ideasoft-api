# \OptionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**OptionGroupsGet**](OptionGroupApi.md#OptionGroupsGet) | **Get** /option_groups | Varyant Grubu Listesi Alma
[**OptionGroupsIdDelete**](OptionGroupApi.md#OptionGroupsIdDelete) | **Delete** /option_groups/{id} | Varyant Grubu Silme
[**OptionGroupsIdGet**](OptionGroupApi.md#OptionGroupsIdGet) | **Get** /option_groups/{id} | Varyant Grubu Alma
[**OptionGroupsIdPut**](OptionGroupApi.md#OptionGroupsIdPut) | **Put** /option_groups/{id} | Varyant Grubu Güncelleme
[**OptionGroupsPost**](OptionGroupApi.md#OptionGroupsPost) | **Post** /option_groups | Varyant Grubu Oluşturma


# **OptionGroupsGet**
> OptionGroup OptionGroupsGet(ctx, optional)
Varyant Grubu Listesi Alma

Varyant Grubu listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | 
 **title** | **string**| Varyant Grubu başlığı. | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OptionGroupsIdDelete**
> OptionGroupsIdDelete(ctx, id)
Varyant Grubu Silme

Kalıcı olarak ilgili Varyant Grubunu siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Varyant Grubu nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OptionGroupsIdGet**
> OptionGroup OptionGroupsIdGet(ctx, id)
Varyant Grubu Alma

İlgili Varyant Grubunu getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Varyant Grubu nesnesinin id değeri | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OptionGroupsIdPut**
> OptionGroup OptionGroupsIdPut(ctx, id, optionGroup)
Varyant Grubu Güncelleme

İlgili Varyant Grubunu günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Varyant Grubu nesnesinin id değeri | 
  **optionGroup** | [**OptionGroup**](OptionGroup.md)|  nesnesi | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OptionGroupsPost**
> OptionGroup OptionGroupsPost(ctx, optionGroup)
Varyant Grubu Oluşturma

Yeni bir Varyant Grubu oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **optionGroup** | [**OptionGroup**](OptionGroup.md)|  nesnesi | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

