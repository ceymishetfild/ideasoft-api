# \OrderRefundRequestItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**OrderRefundRequestItemsGet**](OrderRefundRequestItemApi.md#OrderRefundRequestItemsGet) | **Get** /order_refund_request_items | Sipariş İptal Talebi Kalemi Listesi Alma
[**OrderRefundRequestItemsIdDelete**](OrderRefundRequestItemApi.md#OrderRefundRequestItemsIdDelete) | **Delete** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Silme
[**OrderRefundRequestItemsIdGet**](OrderRefundRequestItemApi.md#OrderRefundRequestItemsIdGet) | **Get** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Alma
[**OrderRefundRequestItemsIdPut**](OrderRefundRequestItemApi.md#OrderRefundRequestItemsIdPut) | **Put** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Güncelleme
[**OrderRefundRequestItemsPost**](OrderRefundRequestItemApi.md#OrderRefundRequestItemsPost) | **Post** /order_refund_request_items | Sipariş İptal Talebi Kalemi Oluşturma


# **OrderRefundRequestItemsGet**
> OrderRefundRequestItem OrderRefundRequestItemsGet(ctx, optional)
Sipariş İptal Talebi Kalemi Listesi Alma

Sipariş İptal Talebi Kalemi listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **orderRefundRequest** | **int32**| Sipariş iptal talebi id | 
 **orderItem** | **int32**| Sipariş ürünü id | 
 **startDate** | **string**| createdAt değeri için başlangıç tarihi | 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | 
 **startUpdatedAt** | **string**| updatedAt değeri için başlangıç tarihi | 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | 

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OrderRefundRequestItemsIdDelete**
> OrderRefundRequestItemsIdDelete(ctx, id)
Sipariş İptal Talebi Kalemi Silme

Kalıcı olarak ilgili Sipariş İptal Talebi Kalemini siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Sipariş İptal Talebi Kalemi nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OrderRefundRequestItemsIdGet**
> OrderRefundRequestItem OrderRefundRequestItemsIdGet(ctx, id)
Sipariş İptal Talebi Kalemi Alma

İlgili Sipariş İptal Talebi Kalemini getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Sipariş İptal Talebi Kalemi nesnesinin id değeri | 

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OrderRefundRequestItemsIdPut**
> OrderRefundRequestItem OrderRefundRequestItemsIdPut(ctx, id, orderRefundRequestItem)
Sipariş İptal Talebi Kalemi Güncelleme

İlgili Sipariş İptal Talebi Kalemini günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Sipariş İptal Talebi Kalemi nesnesinin id değeri | 
  **orderRefundRequestItem** | [**OrderRefundRequestItem**](OrderRefundRequestItem.md)| OrderRefundRequestItem nesnesi | 

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OrderRefundRequestItemsPost**
> OrderRefundRequestItem OrderRefundRequestItemsPost(ctx, orderRefundRequestItem)
Sipariş İptal Talebi Kalemi Oluşturma

Yeni bir Sipariş İptal Talebi Kalemi oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **orderRefundRequestItem** | [**OrderRefundRequestItem**](OrderRefundRequestItem.md)| OrderRefundRequestItem nesnesi | 

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

