# PaymentProvider

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ödeme altyapısı sağlayıcısı nesnesi kimlik değeri. | [optional] [default to null]
**Code** | **string** | Ödeme altyapısı sağlayıcısı için ön tanımlanmış kod değeri. | [default to null]
**Name** | **string** | Ödeme altyapısı sağlayıcısı için isim değeri. | [default to null]
**Status** | **string** | Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer. | [default to null]
**PaymentType** | [***PaymentType**](PaymentType.md) |  | [optional] [default to null]
**Settings** | [**[]PaymentProviderSetting**](PaymentProviderSetting.md) | Ödeme altyapısı sağlayıcısı ayarları | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


