# \SpecGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SpecGroupsGet**](SpecGroupApi.md#SpecGroupsGet) | **Get** /spec_groups | Ürün Özellik Grubu Listesi Alma
[**SpecGroupsIdDelete**](SpecGroupApi.md#SpecGroupsIdDelete) | **Delete** /spec_groups/{id} | Ürün Özellik Grubu Silme
[**SpecGroupsIdGet**](SpecGroupApi.md#SpecGroupsIdGet) | **Get** /spec_groups/{id} | Ürün Özellik Grubu Alma
[**SpecGroupsIdPut**](SpecGroupApi.md#SpecGroupsIdPut) | **Put** /spec_groups/{id} | Ürün Özellik Grubu Güncelleme
[**SpecGroupsPost**](SpecGroupApi.md#SpecGroupsPost) | **Post** /spec_groups | Ürün Özellik Grubu Oluşturma


# **SpecGroupsGet**
> SpecGroup SpecGroupsGet(ctx, optional)
Ürün Özellik Grubu Listesi Alma

Ürün Özellik Grubu listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | 
 **name** | **string**| Ürün Özellik Grubu adı | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SpecGroupsIdDelete**
> SpecGroupsIdDelete(ctx, id)
Ürün Özellik Grubu Silme

Kalıcı olarak ilgili Ürün Özellik Grubunu siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ürün Özellik Grubu nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SpecGroupsIdGet**
> SpecGroup SpecGroupsIdGet(ctx, id)
Ürün Özellik Grubu Alma

İlgili Ürün Özellik Grubunu getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ürün Özellik Grubu nesnesinin id değeri | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SpecGroupsIdPut**
> SpecGroup SpecGroupsIdPut(ctx, id, specGroup)
Ürün Özellik Grubu Güncelleme

İlgili Ürün Özellik Grubunu günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ürün Özellik Grubu nesnesinin id değeri | 
  **specGroup** | [**SpecGroup**](SpecGroup.md)|  nesnesi | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SpecGroupsPost**
> SpecGroup SpecGroupsPost(ctx, specGroup)
Ürün Özellik Grubu Oluşturma

Yeni bir Ürün Özellik Grubu oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **specGroup** | [**SpecGroup**](SpecGroup.md)|  nesnesi | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

