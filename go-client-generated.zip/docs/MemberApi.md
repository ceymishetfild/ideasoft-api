# \MemberApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**MembersChartsGet**](MemberApi.md#MembersChartsGet) | **Get** /members/charts | Üye Grafik Aksiyonu
[**MembersCombinedGet**](MemberApi.md#MembersCombinedGet) | **Get** /members/combined | Üye Birleşik Aksiyonu
[**MembersGet**](MemberApi.md#MembersGet) | **Get** /members | Üye Listesi Alma
[**MembersIdDelete**](MemberApi.md#MembersIdDelete) | **Delete** /members/{id} | Üye Silme
[**MembersIdGet**](MemberApi.md#MembersIdGet) | **Get** /members/{id} | Üye Alma
[**MembersIdPut**](MemberApi.md#MembersIdPut) | **Put** /members/{id} | Üye Güncelleme
[**MembersPost**](MemberApi.md#MembersPost) | **Post** /members | Üye Oluşturma


# **MembersChartsGet**
> Member MembersChartsGet(ctx, timeFrame, startDate)
Üye Grafik Aksiyonu

Zaman bazında üye genel istatistiklerini getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **timeFrame** | **string**| Şu değerleri olabilir: full, year, month or week | 
  **startDate** | **string**| Zaman aralığının başlangıcı | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MembersCombinedGet**
> Member MembersCombinedGet(ctx, )
Üye Birleşik Aksiyonu

Bugün, aylık, yıllık ve toplam üye oturum açma istatistiklerini totalCount cinsinden getirir.

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MembersGet**
> Member MembersGet(ctx, optional)
Üye Listesi Alma

Üye listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **firstname** | **string**| Adı | 
 **surname** | **string**| Soyadı | 
 **email** | **string**| e-mail adresi | 
 **password** | **string**| Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri | 
 **gender** | **string**| Cinsiyet şu değerleri alabilir: &lt;br&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın | 
 **mobilePhoneNumber** | **string**| Üye mobil telefon numarası | 
 **phoneNumber** | **string**| Üye telefon numarası | 
 **memberGroup** | **int32**| Üye Grubu id | 
 **location** | **int32**| Şehir id | 
 **country** | **int32**| Ülke id | 
 **referredMember** | **int32**| Tavsiye Üye id | 
 **q** | [**[]string**](string.md)| Üye arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | 
 **startDate** | **string**| createdAt değeri için başlangıç tarihi | 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | 
 **startUpdatedAt** | **string**| updatedAt değeri için başlangıç tarihi | 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MembersIdDelete**
> MembersIdDelete(ctx, id)
Üye Silme

Kalıcı olarak ilgili Üyeyi siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Üye nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MembersIdGet**
> Member MembersIdGet(ctx, id)
Üye Alma

İlgili Üyeyi getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Üye nesnesinin id değeri | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MembersIdPut**
> Member MembersIdPut(ctx, id, member)
Üye Güncelleme

İlgili Üyeyi günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Üye nesnesinin id değeri | 
  **member** | [**Member**](Member.md)| Member nesnesi | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MembersPost**
> Member MembersPost(ctx, member)
Üye Oluşturma

Yeni bir Üye oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **member** | [**Member**](Member.md)| Member nesnesi | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

