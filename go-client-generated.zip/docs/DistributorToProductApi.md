# \DistributorToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DistributorToProductsGet**](DistributorToProductApi.md#DistributorToProductsGet) | **Get** /distributor_to_products | Distribütör Ürün Bağı Listesi Alma
[**DistributorToProductsIdDelete**](DistributorToProductApi.md#DistributorToProductsIdDelete) | **Delete** /distributor_to_products/{id} | Distribütör Ürün Bağı Silme
[**DistributorToProductsIdGet**](DistributorToProductApi.md#DistributorToProductsIdGet) | **Get** /distributor_to_products/{id} | Distribütör Ürün Bağı Alma
[**DistributorToProductsIdPut**](DistributorToProductApi.md#DistributorToProductsIdPut) | **Put** /distributor_to_products/{id} | Distribütör Ürün Bağı Güncelleme
[**DistributorToProductsPost**](DistributorToProductApi.md#DistributorToProductsPost) | **Post** /distributor_to_products | Distribütör Ürün Bağı Oluşturma


# **DistributorToProductsGet**
> DistributorToProduct DistributorToProductsGet(ctx, optional)
Distribütör Ürün Bağı Listesi Alma

Distribütör Ürün Bağı listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | 
 **distributor** | **int32**| Distribütör id | 
 **product** | **int32**| Ürün id | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **DistributorToProductsIdDelete**
> DistributorToProductsIdDelete(ctx, id)
Distribütör Ürün Bağı Silme

Kalıcı olarak ilgili Distribütör Ürün Bağını siler

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Distribütör Ürün Bağı nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **DistributorToProductsIdGet**
> DistributorToProduct DistributorToProductsIdGet(ctx, id)
Distribütör Ürün Bağı Alma

İlgili Distribütör Ürün Bağını getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Distribütör Ürün Bağı nesnesinin id değeri | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **DistributorToProductsIdPut**
> DistributorToProduct DistributorToProductsIdPut(ctx, id, distributorToProduct)
Distribütör Ürün Bağı Güncelleme

İlgili Distribütör Ürün Bağını günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Distribütör Ürün Bağı nesnesinin id değeri | 
  **distributorToProduct** | [**DistributorToProduct**](DistributorToProduct.md)|  nesnesi | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **DistributorToProductsPost**
> DistributorToProduct DistributorToProductsPost(ctx, distributorToProduct)
Distribütör Ürün Bağı Oluşturma

Yeni bir Distribütör Ürün Bağı oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **distributorToProduct** | [**DistributorToProduct**](DistributorToProduct.md)|  nesnesi | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

