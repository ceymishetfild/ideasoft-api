# \ShipmentItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ShipmentItemsGet**](ShipmentItemApi.md#ShipmentItemsGet) | **Get** /shipment_items | Teslimat Kalemi Listesi Alma
[**ShipmentItemsIdDelete**](ShipmentItemApi.md#ShipmentItemsIdDelete) | **Delete** /shipment_items/{id} | Teslimat Kalemi Silme
[**ShipmentItemsIdGet**](ShipmentItemApi.md#ShipmentItemsIdGet) | **Get** /shipment_items/{id} | Teslimat Kalemi Alma
[**ShipmentItemsIdPut**](ShipmentItemApi.md#ShipmentItemsIdPut) | **Put** /shipment_items/{id} | Teslimat Kalemi Güncelleme
[**ShipmentItemsPost**](ShipmentItemApi.md#ShipmentItemsPost) | **Post** /shipment_items | Teslimat Kalemi Oluşturma


# **ShipmentItemsGet**
> ShipmentItem ShipmentItemsGet(ctx, optional)
Teslimat Kalemi Listesi Alma

Teslimat Kalemi listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **product** | **int32**| Ürün id | 
 **shipment** | **int32**| Teslimat id | 
 **orderItem** | **int32**| Sipariş kalemi id | 
 **startDate** | **string**| createdAt değeri için başlangıç tarihi | 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | 
 **startUpdatedAt** | **string**| updatedAt değeri için başlangıç tarihi | 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShipmentItemsIdDelete**
> ShipmentItemsIdDelete(ctx, id)
Teslimat Kalemi Silme

Kalıcı olarak ilgili Teslimat Kalemini siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Teslimat Kalemi nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShipmentItemsIdGet**
> ShipmentItem ShipmentItemsIdGet(ctx, id)
Teslimat Kalemi Alma

İlgili Teslimat Kalemini getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Teslimat Kalemi nesnesinin id değeri | 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShipmentItemsIdPut**
> ShipmentItem ShipmentItemsIdPut(ctx, id, shipmentItem)
Teslimat Kalemi Güncelleme

İlgili Teslimat Kalemini günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Teslimat Kalemi nesnesinin id değeri | 
  **shipmentItem** | [**ShipmentItem**](ShipmentItem.md)| ShipmentItem nesnesi | 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShipmentItemsPost**
> ShipmentItem ShipmentItemsPost(ctx, shipmentItem)
Teslimat Kalemi Oluşturma

Yeni bir Teslimat Kalemi oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **shipmentItem** | [**ShipmentItem**](ShipmentItem.md)| ShipmentItem nesnesi | 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

