# \ShippingAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ShippingAddressesGet**](ShippingAddressApi.md#ShippingAddressesGet) | **Get** /shipping_addresses | Teslimat Adresi Listesi Alma
[**ShippingAddressesIdGet**](ShippingAddressApi.md#ShippingAddressesIdGet) | **Get** /shipping_addresses/{id} | Teslimat Adresi Alma
[**ShippingAddressesIdPut**](ShippingAddressApi.md#ShippingAddressesIdPut) | **Put** /shipping_addresses/{id} | Teslimat Adresi Güncelleme
[**ShippingAddressesPost**](ShippingAddressApi.md#ShippingAddressesPost) | **Post** /shipping_addresses | Teslimat Adresi Oluşturma


# **ShippingAddressesGet**
> ShippingAddress ShippingAddressesGet(ctx, optional)
Teslimat Adresi Listesi Alma

Teslimat Adresi listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **order** | **int32**| Sipariş id | 
 **startDate** | **string**| createdAt değeri için başlangıç tarihi | 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | 
 **startUpdatedAt** | **string**| updatedAt değeri için başlangıç tarihi | 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | 

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShippingAddressesIdGet**
> ShippingAddress ShippingAddressesIdGet(ctx, id)
Teslimat Adresi Alma

İlgili Teslimat Adresi getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Teslimat Adresi nesnesinin id değeri | 

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShippingAddressesIdPut**
> ShippingAddress ShippingAddressesIdPut(ctx, id, shippingAddress)
Teslimat Adresi Güncelleme

İlgili Teslimat Adresi günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Teslimat Adresi nesnesinin id değeri | 
  **shippingAddress** | [**ShippingAddress**](ShippingAddress.md)| ShippingAddress nesnesi | 

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShippingAddressesPost**
> ShippingAddress ShippingAddressesPost(ctx, shippingAddress)
Teslimat Adresi Oluşturma

Yeni bir Teslimat Adresi oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **shippingAddress** | [**ShippingAddress**](ShippingAddress.md)| ShippingAddress nesnesi | 

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

