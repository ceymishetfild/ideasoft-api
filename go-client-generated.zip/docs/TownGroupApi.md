# \TownGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**TownGroupsGet**](TownGroupApi.md#TownGroupsGet) | **Get** /town_groups | İlçe Grubu Listesi Alma
[**TownGroupsIdDelete**](TownGroupApi.md#TownGroupsIdDelete) | **Delete** /town_groups/{id} | İlçe Grubu Silme
[**TownGroupsIdGet**](TownGroupApi.md#TownGroupsIdGet) | **Get** /town_groups/{id} | İlçe Grubu Alma
[**TownGroupsIdPut**](TownGroupApi.md#TownGroupsIdPut) | **Put** /town_groups/{id} | İlçe Grubu Güncelleme
[**TownGroupsPost**](TownGroupApi.md#TownGroupsPost) | **Post** /town_groups | İlçe Grubu Oluşturma


# **TownGroupsGet**
> TownGroup TownGroupsGet(ctx, optional)
İlçe Grubu Listesi Alma

İlçe Grubu listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **name** | **string**| İlçe Grubu adı | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **TownGroupsIdDelete**
> TownGroupsIdDelete(ctx, id)
İlçe Grubu Silme

Kalıcı olarak ilgili İlçe Grubunu siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| İlçe Grubu nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **TownGroupsIdGet**
> TownGroup TownGroupsIdGet(ctx, id)
İlçe Grubu Alma

İlgili İlçe Grubunu getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| İlçe Grubu nesnesinin id değeri | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **TownGroupsIdPut**
> TownGroup TownGroupsIdPut(ctx, id, townGroup)
İlçe Grubu Güncelleme

İlgili İlçe Grubunu günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| İlçe Grubu nesnesinin id değeri | 
  **townGroup** | [**TownGroup**](TownGroup.md)| TownGroup nesnesi | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **TownGroupsPost**
> TownGroup TownGroupsPost(ctx, townGroup)
İlçe Grubu Oluşturma

Yeni bir İlçe Grubu oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **townGroup** | [**TownGroup**](TownGroup.md)| TownGroup nesnesi | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

