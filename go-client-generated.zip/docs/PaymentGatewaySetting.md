# PaymentGatewaySetting

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ödeme kanalı ayarı nesnesi kimlik değeri. | [optional] [default to null]
**VarKey** | **string** | Ödeme kanalı ayarı nesnesi için değişken anahtarı. | [default to null]
**VarValue** | **string** | Ödeme kanalı ayarı nesnesi için değişken değeri. | [default to null]
**PaymentGateway** | [***PaymentGateway**](PaymentGateway.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


