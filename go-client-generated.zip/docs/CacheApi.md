# \CacheApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CacheDelete**](CacheApi.md#CacheDelete) | **Delete** /cache | Önbellek Silme


# **CacheDelete**
> CacheDelete(ctx, )
Önbellek Silme

Kalıcı olarak Önbelleği siler.

### Required Parameters
This endpoint does not need any parameter.

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

