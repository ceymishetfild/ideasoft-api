# QuickCart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Hızlı satın al bağlantısı nesnesi kimlik değeri. | [optional] [default to null]
**Name** | **string** | Hızlı satın al bağlantısı nesnesi için isim değeri. | [default to null]
**Url** | **string** | Hızlı satın al bağlantısı url&#39;si. | [default to null]
**ShortUrl** | **string** | Hızlı satın al bağlantısı için kısaltılmış url. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


