# ExtraInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ek bilgi nesnesi kimlik değeri. | [optional] [default to null]
**Name** | **string** | Ek bilgi nesnesi için isim değeri. | [default to null]
**SortOrder** | **int32** | Ek bilgi nesnesi için sıralama değeri. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


