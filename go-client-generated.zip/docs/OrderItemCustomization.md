# OrderItemCustomization

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Sipariş kalemi özelleştirme kimlik değeri. | [optional] [default to null]
**ProductCustomizationGroupId** | **int32** | Ürün özelleştirme grubu nesnesi kimlik değeri. | [optional] [default to null]
**ProductCustomizationGroupName** | **string** | Ürün özelleştirme grubu nesnesinin grup adı. | [optional] [default to null]
**ProductCustomizationGroupSortOrder** | **int32** | Ürün özelleştirme grubu nesnesinin sıralaması. | [optional] [default to null]
**ProductCustomizationFieldId** | **int32** | Ürün özelleştirme nesnesi kimlik değeri.. | [optional] [default to null]
**ProductCustomizationFieldType** | **string** | Ürün özelleştirme nesnesinin alan tipi. | [optional] [default to null]
**ProductCustomizationFieldName** | **string** | Ürün özelleştirme nesnesinin alan adı. | [optional] [default to null]
**ProductCustomizationFieldValue** | **string** | Ürün özelleştirme nesnesinin değeri. | [optional] [default to null]
**CartItemAttributeId** | **int32** | Sepet kalemi özelliği nesnesi kimlik değeri. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


