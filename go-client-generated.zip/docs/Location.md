# Location

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Şehir nesnesi kimlik değeri. | [optional] [default to null]
**Name** | **string** | Şehir nesnesi için isim değeri. | [default to null]
**Status** | **string** | Şehir nesnesinin aktiflik durumunu belirten değer. | [default to null]
**Predefined** | **string** | Şehir nesnesinin öntanımlı olup olmadığını belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Öntanımlı şehir.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yeni eklenmiş şehir.&lt;br&gt;&lt;/div&gt; | [optional] [default to null]
**Country** | [***Country**](Country.md) |  | [optional] [default to null]
**Region** | [***Region**](Region.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


