# \ProductToTagApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductToTagsGet**](ProductToTagApi.md#ProductToTagsGet) | **Get** /product_to_tags | Ürün SEO+ Bağı Listesi Alma
[**ProductToTagsIdDelete**](ProductToTagApi.md#ProductToTagsIdDelete) | **Delete** /product_to_tags/{id} | Ürün SEO+ Bağı Silme
[**ProductToTagsIdGet**](ProductToTagApi.md#ProductToTagsIdGet) | **Get** /product_to_tags/{id} | Ürün SEO+ Bağı Alma
[**ProductToTagsIdPut**](ProductToTagApi.md#ProductToTagsIdPut) | **Put** /product_to_tags/{id} | Ürün SEO+ Bağı Güncelleme
[**ProductToTagsPost**](ProductToTagApi.md#ProductToTagsPost) | **Post** /product_to_tags | Ürün SEO+ Bağı Oluşturma


# **ProductToTagsGet**
> ProductToTag ProductToTagsGet(ctx, optional)
Ürün SEO+ Bağı Listesi Alma

Ürün SEO+ Bağı listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **product** | **int32**| Ürün id | 
 **tag** | **int32**| Etiket id | 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductToTagsIdDelete**
> ProductToTagsIdDelete(ctx, id)
Ürün SEO+ Bağı Silme

Kalıcı olarak ilgili Ürün SEO+ Bağını siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün SEO+ nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductToTagsIdGet**
> ProductToTag ProductToTagsIdGet(ctx, id)
Ürün SEO+ Bağı Alma

İlgili Ürün SEO+ Bağını getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün SEO+ nesnesinin id değeri | 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductToTagsIdPut**
> ProductToTag ProductToTagsIdPut(ctx, id, productToTag)
Ürün SEO+ Bağı Güncelleme

İlgili Ürün SEO+ Bağını günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün SEO+ nesnesinin id değeri | 
  **productToTag** | [**ProductToTag**](ProductToTag.md)| ProductToTag nesnesi | 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductToTagsPost**
> ProductToTag ProductToTagsPost(ctx, productToTag)
Ürün SEO+ Bağı Oluşturma

Yeni bir Ürün SEO+ Bağı oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **productToTag** | [**ProductToTag**](ProductToTag.md)| ProductToTag nesnesi | 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

