# \ProductSpecialInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductSpecialInfosGet**](ProductSpecialInfoApi.md#ProductSpecialInfosGet) | **Get** /product_special_infos | Ürün Özel Bilgi Alanı Listesi Alma
[**ProductSpecialInfosIdDelete**](ProductSpecialInfoApi.md#ProductSpecialInfosIdDelete) | **Delete** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**ProductSpecialInfosIdGet**](ProductSpecialInfoApi.md#ProductSpecialInfosIdGet) | **Get** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**ProductSpecialInfosIdPut**](ProductSpecialInfoApi.md#ProductSpecialInfosIdPut) | **Put** /product_special_infos/{id} | Ürün Özel Bilgi Alanı Güncelleme
[**ProductSpecialInfosPost**](ProductSpecialInfoApi.md#ProductSpecialInfosPost) | **Post** /product_special_infos | Ürün Özel Bilgi Alanı Oluşturma


# **ProductSpecialInfosGet**
> ProductSpecialInfo ProductSpecialInfosGet(ctx, optional)
Ürün Özel Bilgi Alanı Listesi Alma

Ürün Özel Bilgi Alanı listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | 
 **title** | **string**| Ürün Özel Bilgi Alanı başlığı | 
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | 
 **product** | **int32**| Ürün id | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductSpecialInfosIdDelete**
> ProductSpecialInfosIdDelete(ctx, id)
Ürün Özel Bilgi Alanı

Kalıcı olarak ilgili Ürün Özel Bilgi Alanını siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductSpecialInfosIdGet**
> ProductSpecialInfo ProductSpecialInfosIdGet(ctx, id)
Ürün Özel Bilgi Alanı

İlgili Ürün Özel Bilgi Alanını getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductSpecialInfosIdPut**
> ProductSpecialInfo ProductSpecialInfosIdPut(ctx, id, productSpecialInfo)
Ürün Özel Bilgi Alanı Güncelleme

İlgili Ürün Özel Bilgi Alanını günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 
  **productSpecialInfo** | [**ProductSpecialInfo**](ProductSpecialInfo.md)|  nesnesi | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductSpecialInfosPost**
> ProductSpecialInfo ProductSpecialInfosPost(ctx, productSpecialInfo)
Ürün Özel Bilgi Alanı Oluşturma

Yeni bir Ürün Özel Bilgi Alanı oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **productSpecialInfo** | [**ProductSpecialInfo**](ProductSpecialInfo.md)|  nesnesi | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

