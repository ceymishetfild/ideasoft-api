# CartItemAttribute

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Sepet kalemi özelliği nesnesi kimlik değeri. | [optional] [default to null]
**Name** | **string** | Sepet kalemi özelliği nesnesinin isim değeri. Örneğin, sepet kalemi kalem ise bu değer renk olabilir. | [optional] [default to null]
**Value** | **string** | Sepet kalemi özelliği nesnesinin değeri. Örneğin, sepet kalemi kalem, isim değeri renk ise bu değer kırmızı olabilir. | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Sepet kalemi özelliği nesnesinin oluşturulma zamanı. | [optional] [default to null]
**CartItem** | [***CartItem**](CartItem.md) | Sepet kalemi nesnesi. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


