# OrderRefundRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Sipariş iptal talebi nesnesi kimlik değeri. | [optional] [default to null]
**Code** | **string** | Sipariş iptal talebi için oluşturulan benzersiz kod değeri. | [default to null]
**Status** | **string** | Sipariş iptal talebi için durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı.&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor.&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi.&lt;br&gt;&lt;/div&gt; | [default to null]
**Fee** | **float32** | Müşteriye ödenecek miktar bilgisi. | [default to null]
**CancellationReason** | **string** | Sipariş iptal talebinin oluşturulması sebebinin detaylı açıklaması. | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Sipariş iptal talebi nesnesinin oluşturulma zamanı. | [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Sipariş iptal talebi nesnesinin güncellenme zamanı. | [default to null]
**Member** | [***Member**](Member.md) |  | [optional] [default to null]
**Order** | [***Order**](Order.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


