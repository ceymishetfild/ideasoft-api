# CurrentAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Cari hesap nesnesi kimlik değeri. | [optional] [default to null]
**Code** | **string** | Cari hesap için düzenlenebilir bir kod değeri. | [optional] [default to null]
**Title** | **string** | Cari hesap nesnesinin başlığı. | [default to null]
**Balance** | **float32** | Cari hesabın bakiyesi. | [optional] [default to null]
**RiskLimit** | **float32** | Cari hesap için belirlenmiş risk limiti. | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Cari hesap nesnesinin oluşturulma zamanı. | [optional] [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Cari hesap nesnesinin güncellenme zamanı. | [optional] [default to null]
**Member** | [***Member**](Member.md) | Üye nesnesi. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


