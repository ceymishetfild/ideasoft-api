# \FavouritedProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**FavouritedProductsGet**](FavouritedProductApi.md#FavouritedProductsGet) | **Get** /favourited_products | Favori Ürün Listesi Alma
[**FavouritedProductsIdDelete**](FavouritedProductApi.md#FavouritedProductsIdDelete) | **Delete** /favourited_products/{id} | Favori Ürün Silme
[**FavouritedProductsIdGet**](FavouritedProductApi.md#FavouritedProductsIdGet) | **Get** /favourited_products/{id} | Favori Ürün Alma
[**FavouritedProductsIdPut**](FavouritedProductApi.md#FavouritedProductsIdPut) | **Put** /favourited_products/{id} | Favori Ürün Güncelleme
[**FavouritedProductsPost**](FavouritedProductApi.md#FavouritedProductsPost) | **Post** /favourited_products | Favori Ürün Oluşturma


# **FavouritedProductsGet**
> FavouritedProduct FavouritedProductsGet(ctx, optional)
Favori Ürün Listesi Alma

Favori Ürün listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **product** | **int32**| Ürün id | 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **FavouritedProductsIdDelete**
> FavouritedProductsIdDelete(ctx, id)
Favori Ürün Silme

Kalıcı olarak ilgili Favori Ürünü siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Favori Ürün nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **FavouritedProductsIdGet**
> FavouritedProduct FavouritedProductsIdGet(ctx, id)
Favori Ürün Alma

İlgili Favori Ürünü getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Favori Ürün nesnesinin id değeri | 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **FavouritedProductsIdPut**
> FavouritedProduct FavouritedProductsIdPut(ctx, id, favouritedProduct)
Favori Ürün Güncelleme

İlgili Favori Ürünü günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Favori Ürün nesnesinin id değeri | 
  **favouritedProduct** | [**FavouritedProduct**](FavouritedProduct.md)| FavouritedProduct nesnesi | 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **FavouritedProductsPost**
> FavouritedProduct FavouritedProductsPost(ctx, favouritedProduct)
Favori Ürün Oluşturma

Yeni bir Favori Ürün oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **favouritedProduct** | [**FavouritedProduct**](FavouritedProduct.md)| FavouritedProduct nesnesi | 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

