# \ShippingRateApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ShippingRatesGet**](ShippingRateApi.md#ShippingRatesGet) | **Get** /shipping_rates | Kargo Oranı Listesi Alma
[**ShippingRatesIdDelete**](ShippingRateApi.md#ShippingRatesIdDelete) | **Delete** /shipping_rates/{id} | Kargo Oranı Silme
[**ShippingRatesIdGet**](ShippingRateApi.md#ShippingRatesIdGet) | **Get** /shipping_rates/{id} | Kargo Oranı Alma
[**ShippingRatesIdPut**](ShippingRateApi.md#ShippingRatesIdPut) | **Put** /shipping_rates/{id} | Kargo Oranı Güncelleme
[**ShippingRatesPost**](ShippingRateApi.md#ShippingRatesPost) | **Post** /shipping_rates | Kargo Oranı Oluşturma


# **ShippingRatesGet**
> ShippingRate ShippingRatesGet(ctx, optional)
Kargo Oranı Listesi Alma

Kargo Oranı listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | 
 **shippingCompany** | **int32**| Kargo firması id | 
 **region** | **int32**| Bölge id | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShippingRatesIdDelete**
> ShippingRatesIdDelete(ctx, id)
Kargo Oranı Silme

Kalıcı olarak ilgili Kargo Oranını siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Kargo Oranı nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShippingRatesIdGet**
> ShippingRate ShippingRatesIdGet(ctx, id)
Kargo Oranı Alma

İlgili Kargo Oranını getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Kargo Oranı nesnesinin id değeri | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShippingRatesIdPut**
> ShippingRate ShippingRatesIdPut(ctx, id, shippingRate)
Kargo Oranı Güncelleme

İlgili Kargo Oranını günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Kargo Oranı nesnesinin id değeri | 
  **shippingRate** | [**ShippingRate**](ShippingRate.md)|  nesnesi | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShippingRatesPost**
> ShippingRate ShippingRatesPost(ctx, shippingRate)
Kargo Oranı Oluşturma

Yeni bir Kargo Oranı oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **shippingRate** | [**ShippingRate**](ShippingRate.md)|  nesnesi | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

