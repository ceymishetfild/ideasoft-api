# ShippingCompany

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Kargo firması nesnesi kimlik değeri. | [optional] [default to null]
**Name** | **string** | Kargo firması nesnesi için isim değeri. | [default to null]
**Status** | **string** | Kargo firması nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;active&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | [default to null]
**ExtraPrice** | **float32** | Kargo firması için sabit ücret. Sabit bir kargo ücreti uygulayacaksanız her sipariş için sabit kargo ücreti girebilirsiniz. Desi bilgilerini kaydetmeniz durumunda desi toplamlarının üzerine sabit ücret eklenecektir. | [optional] [default to null]
**ExtraVolumetricWeightPrice** | **float32** | Kargo firması için girmiş olduğunuz desi bilgileri 50 Desiye kadar girilebilmektedir. 50&#39;nin üzeri veya girmiş olduğunuz desi miktarının üzerine her +1 desi için eklenecek olan kargo ücreti. | [optional] [default to null]
**FreeShipmentOrderPrice** | **float32** | Alışveriş sepeti toplamı belirlediğiniz Ücretsiz kargo limitini geçtiğinde müşterileriniz ücretsiz kargo hizmetinden faydalanabilirler.(Örn: X Lira üzeri ücretsiz Kargo!) | [optional] [default to null]
**FreeShipmentVolumetricWeightLimit** | **float32** | Ücretsiz kargo miktarı için maksimum ücretsiz desi miktarıdır. Alışveriş sırasındaki desi miktarı ücretsiz desi miktarından fazlaysa, + Desi miktarını sipariş sırasında sistem müşteriden tahsil eder.(Örn: X TL üzeri ücretsiz kargo! Fakat X desiye kadar)Üzeri müşteriden tahsil edilir. | [optional] [default to null]
**SortOrder** | **int32** | Kargo firması nesnesi için sıralama değeri. | [optional] [default to null]
**CompanyCode** | **string** | API tarafından otomatik oluşturulan kargo firması kodu. | [optional] [default to null]
**PaymentType** | **string** | Kargo firması için ödeme tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli.&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli.&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil.&lt;br&gt;&lt;/div&gt; | [optional] [default to null]
**ShippingProvider** | [***ShippingProvider**](ShippingProvider.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


