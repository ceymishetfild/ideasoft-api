# \SelectionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SelectionsGet**](SelectionApi.md#SelectionsGet) | **Get** /selections | Ek Özellik Listesi Alma
[**SelectionsIdDelete**](SelectionApi.md#SelectionsIdDelete) | **Delete** /selections/{id} | Ek Özellik Silme
[**SelectionsIdGet**](SelectionApi.md#SelectionsIdGet) | **Get** /selections/{id} | Ek Özellik Alma
[**SelectionsIdPut**](SelectionApi.md#SelectionsIdPut) | **Put** /selections/{id} | Ek Özellik Güncelleme
[**SelectionsPost**](SelectionApi.md#SelectionsPost) | **Post** /selections | Ek Özellik Oluşturma


# **SelectionsGet**
> Selection SelectionsGet(ctx, optional)
Ek Özellik Listesi Alma

Ek Özellik listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **title** | **string**| Ek Özellik başlığı | 
 **selectionGroup** | **int32**| Ek Özellik Grubu id | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SelectionsIdDelete**
> SelectionsIdDelete(ctx, id)
Ek Özellik Silme

Kalıcı olarak ilgili Ek Özelliği siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ek Özellik nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SelectionsIdGet**
> Selection SelectionsIdGet(ctx, id)
Ek Özellik Alma

İlgili Ek Özelliği getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ek Özellik nesnesinin id değeri | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SelectionsIdPut**
> Selection SelectionsIdPut(ctx, id, selection)
Ek Özellik Güncelleme

İlgili Ek Özelliği günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ek Özellik nesnesinin id değeri | 
  **selection** | [**Selection**](Selection.md)| Selection nesnesi | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SelectionsPost**
> Selection SelectionsPost(ctx, selection)
Ek Özellik Oluşturma

Yeni bir Ek Özellik oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **selection** | [**Selection**](Selection.md)| Selection nesnesi | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

