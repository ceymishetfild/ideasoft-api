# \ProductDetailApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductDetailsGet**](ProductDetailApi.md#ProductDetailsGet) | **Get** /product_details | Ürün Detay Listesi Alma
[**ProductDetailsIdDelete**](ProductDetailApi.md#ProductDetailsIdDelete) | **Delete** /product_details/{id} | Ürün Detay Silme
[**ProductDetailsIdGet**](ProductDetailApi.md#ProductDetailsIdGet) | **Get** /product_details/{id} | Ürün Detay Alma
[**ProductDetailsIdPut**](ProductDetailApi.md#ProductDetailsIdPut) | **Put** /product_details/{id} | Ürün Detay Güncelleme
[**ProductDetailsPost**](ProductDetailApi.md#ProductDetailsPost) | **Post** /product_details | Ürün Detay Oluşturma


# **ProductDetailsGet**
> ProductDetail ProductDetailsGet(ctx, optional)
Ürün Detay Listesi Alma

Ürün Detay listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **sku** | **string**| Ürün stok kodu | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductDetailsIdDelete**
> ProductDetailsIdDelete(ctx, id)
Ürün Detay Silme

Kalıcı olarak ilgili Ürün Detayını siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün Detay nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductDetailsIdGet**
> ProductDetail ProductDetailsIdGet(ctx, id)
Ürün Detay Alma

İlgili Ürün Detayını getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün Detay nesnesinin id değeri | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductDetailsIdPut**
> ProductDetail ProductDetailsIdPut(ctx, id, productDetail)
Ürün Detay Güncelleme

İlgili Ürün Detayını günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün Detay nesnesinin id değeri | 
  **productDetail** | [**ProductDetail**](ProductDetail.md)| ProductDetail nesnesi | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductDetailsPost**
> ProductDetail ProductDetailsPost(ctx, productDetail)
Ürün Detay Oluşturma

Yeni bir Ürün Detay oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **productDetail** | [**ProductDetail**](ProductDetail.md)| ProductDetail nesnesi | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

