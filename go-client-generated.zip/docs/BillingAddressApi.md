# \BillingAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**BillingAddressesGet**](BillingAddressApi.md#BillingAddressesGet) | **Get** /billing_addresses | Fatura Adresi Listesi Alma
[**BillingAddressesIdGet**](BillingAddressApi.md#BillingAddressesIdGet) | **Get** /billing_addresses/{id} | Fatura Adresi Alma
[**BillingAddressesIdPut**](BillingAddressApi.md#BillingAddressesIdPut) | **Put** /billing_addresses/{id} | Fatura Adresi Güncelleme
[**BillingAddressesPost**](BillingAddressApi.md#BillingAddressesPost) | **Post** /billing_addresses | Fatura Adresi Oluşturma


# **BillingAddressesGet**
> BillingAddress BillingAddressesGet(ctx, optional)
Fatura Adresi Listesi Alma

Fatura Adresi listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **order** | **int32**| Sipariş id | 
 **startDate** | **string**| createdAt değeri için başlangıç tarihi | 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | 
 **startUpdatedAt** | **string**| updatedAt değeri için başlangıç tarihi | 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **BillingAddressesIdGet**
> BillingAddress BillingAddressesIdGet(ctx, id)
Fatura Adresi Alma

İlgili Fatura Adresini getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Fatura Adresi nesnesinin id değeri | 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **BillingAddressesIdPut**
> BillingAddress BillingAddressesIdPut(ctx, id, billingAddress)
Fatura Adresi Güncelleme

İlgili Fatura Adresini günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Fatura Adresi nesnesinin id değeri | 
  **billingAddress** | [**BillingAddress**](BillingAddress.md)| BillingAddress nesnesi | 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **BillingAddressesPost**
> BillingAddress BillingAddressesPost(ctx, billingAddress)
Fatura Adresi Oluşturma

Yeni bir Fatura Adresi oluşturur. Fatura Adresi oluşturabilmek için geçerli bir önceden tanımlanmış Sipariş id değerine ihtiyaç vardır.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **billingAddress** | [**BillingAddress**](BillingAddress.md)| BillingAddress nesnesi | 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

