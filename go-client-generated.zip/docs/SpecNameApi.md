# \SpecNameApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SpecNamesGet**](SpecNameApi.md#SpecNamesGet) | **Get** /spec_names | Ürün Özelliği Listesi Alma
[**SpecNamesIdDelete**](SpecNameApi.md#SpecNamesIdDelete) | **Delete** /spec_names/{id} | Ürün Özelliği Silme
[**SpecNamesIdGet**](SpecNameApi.md#SpecNamesIdGet) | **Get** /spec_names/{id} | Ürün Özelliği Alma
[**SpecNamesIdPut**](SpecNameApi.md#SpecNamesIdPut) | **Put** /spec_names/{id} | Ürün Özelliği Güncelleme
[**SpecNamesPost**](SpecNameApi.md#SpecNamesPost) | **Post** /spec_names | Ürün Özelliği Oluşturma


# **SpecNamesGet**
> SpecName SpecNamesGet(ctx, optional)
Ürün Özelliği Listesi Alma

Ürün Özelliği listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **name** | **string**| Ürün Özelliği adı | 
 **specGroup** | **int32**| Ürün özellik grubu id | 
 **choiceType** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SpecNamesIdDelete**
> SpecNamesIdDelete(ctx, id)
Ürün Özelliği Silme

Kalıcı olarak ilgili Ürün Özelliğini siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün Özellik nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SpecNamesIdGet**
> SpecName SpecNamesIdGet(ctx, id)
Ürün Özelliği Alma

İlgili Ürün Özelliğini getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün Özellik nesnesinin id değeri | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SpecNamesIdPut**
> SpecName SpecNamesIdPut(ctx, id, specName)
Ürün Özelliği Güncelleme

İlgili Ürün Özelliğini günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün Özellik nesnesinin id değeri | 
  **specName** | [**SpecName**](SpecName.md)| SpecName nesnesi | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SpecNamesPost**
> SpecName SpecNamesPost(ctx, specName)
Ürün Özelliği Oluşturma

Yeni bir Ürün Özelliği oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **specName** | [**SpecName**](SpecName.md)| SpecName nesnesi | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

