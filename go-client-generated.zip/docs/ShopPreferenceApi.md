# \ShopPreferenceApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**PreferencesGet**](ShopPreferenceApi.md#PreferencesGet) | **Get** /preferences | Tanımlamalar Listesi Alma
[**PreferencesIdGet**](ShopPreferenceApi.md#PreferencesIdGet) | **Get** /preferences/{id} | Tanımlamalar Alma
[**PreferencesIdPut**](ShopPreferenceApi.md#PreferencesIdPut) | **Put** /preferences/{id} | Tanımlamalar Güncelleme


# **PreferencesGet**
> ShopPreference PreferencesGet(ctx, optional)
Tanımlamalar Listesi Alma

Tanımlamalar listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 100]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | 
 **varKey** | **string**| Tanımlama varKey değeri | 

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PreferencesIdGet**
> ShopPreference PreferencesIdGet(ctx, id)
Tanımlamalar Alma

İlgili Tanımlamayı getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Tanımlama nesnesinin id değeri | 

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PreferencesIdPut**
> ShopPreference PreferencesIdPut(ctx, id, shopPreference)
Tanımlamalar Güncelleme

İlgili Tanımlamayı günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Tanımlama nesnesinin id değeri | 
  **shopPreference** | [**ShopPreference**](ShopPreference.md)|  nesnesi | 

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

