# Brand

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Marka nesnesi kimlik değeri. | [optional] [default to null]
**Name** | **string** | Marka nesnesi için isim değeri. | [default to null]
**Slug** | **string** | Slug değeri ilgili nesnenin Url değeridir. | [optional] [default to null]
**SortOrder** | **int32** | Marka nesnesi için sıralama değeri. | [optional] [default to null]
**Status** | **string** | Marka nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | [default to null]
**Distributor** | **string** | Markanın tedarikçisi. | [optional] [default to null]
**ImageFile** | **string** | Marka nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF | [optional] [default to null]
**ShowcaseContent** | **string** | Marka nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir. | [optional] [default to null]
**DisplayShowcaseContent** | **string** | Marka nesnesi üst içerik metninin gösterim durumu. | [optional] [default to null]
**MetaKeywords** | **string** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] [default to null]
**MetaDescription** | **string** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] [default to null]
**PageTitle** | **string** | Marka nesnesinin etiket başlığı. | [optional] [default to null]
**Attachment** | **string** | Marka nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Marka nesnesinin oluşturulma zamanı. | [optional] [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Marka nesnesinin güncellenme zamanı. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


