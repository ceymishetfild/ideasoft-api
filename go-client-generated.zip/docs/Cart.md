# Cart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Sepet nesnesi kimlik değeri. | [optional] [default to null]
**SessionId** | **string** | Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri. | [default to null]
**Locked** | **string** | Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz. | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Sepet nesnesinin oluşturulma zamanı. | [optional] [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Sepet nesnesinin güncellenme zamanı. | [optional] [default to null]
**ChosenPromotion** | [***ShopCampaigns**](ShopCampaigns.md) | Promosyon nesnesi. | [optional] [default to null]
**Member** | [***Member**](Member.md) | Üye nesnesi. | [optional] [default to null]
**ChosenToken** | [***ShopTokens**](ShopTokens.md) | Hediye çeki nesnesi. | [optional] [default to null]
**Items** | [**[]CartItem**](CartItem.md) | Sepet kalemi nesnelerini barındıran liste. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


