# \ProductPriceApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductPricesGet**](ProductPriceApi.md#ProductPricesGet) | **Get** /product_prices | Ürün Fiyat Listesi Alma
[**ProductPricesIdDelete**](ProductPriceApi.md#ProductPricesIdDelete) | **Delete** /product_prices/{id} | Ürün Fiyat Silme
[**ProductPricesIdGet**](ProductPriceApi.md#ProductPricesIdGet) | **Get** /product_prices/{id} | Ürün Fiyat Alma
[**ProductPricesIdPut**](ProductPriceApi.md#ProductPricesIdPut) | **Put** /product_prices/{id} | Ürün Fiyat Güncelleme
[**ProductPricesPost**](ProductPriceApi.md#ProductPricesPost) | **Post** /product_prices | Ürün Fiyat Oluşturma


# **ProductPricesGet**
> ProductPrice ProductPricesGet(ctx, optional)
Ürün Fiyat Listesi Alma

Ürün Fiyat listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **type_** | **int32**| Ürün fiyat tipi | 
 **product** | **int32**| Ürün id | 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductPricesIdDelete**
> ProductPricesIdDelete(ctx, id)
Ürün Fiyat Silme

Kalıcı olarak ilgili Ürün Fiyatını siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün Fiyat nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductPricesIdGet**
> ProductPrice ProductPricesIdGet(ctx, id)
Ürün Fiyat Alma

İlgili Ürün Fiyatını getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün Fiyat nesnesinin id değeri | 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductPricesIdPut**
> ProductPrice ProductPricesIdPut(ctx, id, productPrice)
Ürün Fiyat Güncelleme

İlgili Ürün Fiyatını günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün Fiyat nesnesinin id değeri | 
  **productPrice** | [**ProductPrice**](ProductPrice.md)| ProductPrice nesnesi | 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductPricesPost**
> ProductPrice ProductPricesPost(ctx, productPrice)
Ürün Fiyat Oluşturma

Yeni bir Ürün Fiyat oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **productPrice** | [**ProductPrice**](ProductPrice.md)| ProductPrice nesnesi | 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

