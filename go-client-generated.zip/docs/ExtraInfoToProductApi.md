# \ExtraInfoToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ExtraInfoToProductsGet**](ExtraInfoToProductApi.md#ExtraInfoToProductsGet) | **Get** /extra_info_to_products | Ek Bilgi Ürün Bağı Listesi Alma
[**ExtraInfoToProductsIdDelete**](ExtraInfoToProductApi.md#ExtraInfoToProductsIdDelete) | **Delete** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Silme
[**ExtraInfoToProductsIdGet**](ExtraInfoToProductApi.md#ExtraInfoToProductsIdGet) | **Get** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Alma
[**ExtraInfoToProductsIdPut**](ExtraInfoToProductApi.md#ExtraInfoToProductsIdPut) | **Put** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Güncelleme
[**ExtraInfoToProductsPost**](ExtraInfoToProductApi.md#ExtraInfoToProductsPost) | **Post** /extra_info_to_products | Ek Bilgi Ürün Bağı Oluşturma


# **ExtraInfoToProductsGet**
> ExtraInfoToProduct ExtraInfoToProductsGet(ctx, optional)
Ek Bilgi Ürün Bağı Listesi Alma

Ek Bilgi Ürün Bağı listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | 
 **extraInfo** | **int32**| Ek bilgi id | 
 **product** | **int32**| Ürün id | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ExtraInfoToProductsIdDelete**
> ExtraInfoToProductsIdDelete(ctx, id)
Ek Bilgi Ürün Bağı Silme

Kalıcı olarak ilgili Ek Bilgi Ürün Bağını siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ExtraInfoToProductsIdGet**
> ExtraInfoToProduct ExtraInfoToProductsIdGet(ctx, id)
Ek Bilgi Ürün Bağı Alma

İlgili Ek Bilgi Ürün Bağını getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ExtraInfoToProductsIdPut**
> ExtraInfoToProduct ExtraInfoToProductsIdPut(ctx, id, extraInfoToProduct)
Ek Bilgi Ürün Bağı Güncelleme

İlgili Ek Bilgi Ürün Bağını günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 
  **extraInfoToProduct** | [**ExtraInfoToProduct**](ExtraInfoToProduct.md)|  nesnesi | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ExtraInfoToProductsPost**
> ExtraInfoToProduct ExtraInfoToProductsPost(ctx, extraInfoToProduct)
Ek Bilgi Ürün Bağı Oluşturma

Yeni bir Ek Bilgi Ürün Bağı oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **extraInfoToProduct** | [**ExtraInfoToProduct**](ExtraInfoToProduct.md)|  nesnesi | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

