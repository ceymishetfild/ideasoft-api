# \ProductButtonApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductButtonsGet**](ProductButtonApi.md#ProductButtonsGet) | **Get** /product_buttons | Ürün ve Stok Butonu Listesi Alma
[**ProductButtonsIdDelete**](ProductButtonApi.md#ProductButtonsIdDelete) | **Delete** /product_buttons/{id} | Ürün ve Stok Butonu Silme
[**ProductButtonsIdGet**](ProductButtonApi.md#ProductButtonsIdGet) | **Get** /product_buttons/{id} | Ürün ve Stok Butonu Alma
[**ProductButtonsIdPut**](ProductButtonApi.md#ProductButtonsIdPut) | **Put** /product_buttons/{id} | Ürün ve Stok Butonu Güncelleme
[**ProductButtonsPost**](ProductButtonApi.md#ProductButtonsPost) | **Post** /product_buttons | Ürün ve Stok Butonu Oluşturma


# **ProductButtonsGet**
> ProductButton ProductButtonsGet(ctx, optional)
Ürün ve Stok Butonu Listesi Alma

Ürün ve Stok Butonu listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **fastShipping** | **int32**| Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | 
 **sameDayShipping** | **int32**| Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | 
 **threeDaysDelivery** | **int32**| 3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | 
 **fiveDaysDelivery** | **int32**| 5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | 
 **sevenDaysDelivery** | **int32**| 7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | 
 **freeShipping** | **int32**| Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | 
 **deliveryFromStock** | **int32**| Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | 
 **preOrderedProduct** | **int32**| Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | 
 **askStock** | **int32**| Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | 
 **campaignedProduct** | **int32**| Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | 
 **product** | **int32**| Ürün id | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductButtonsIdDelete**
> ProductButtonsIdDelete(ctx, id)
Ürün ve Stok Butonu Silme

Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductButtonsIdGet**
> ProductButton ProductButtonsIdGet(ctx, id)
Ürün ve Stok Butonu Alma

İlgili Ürün ve Stok Butonunu getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductButtonsIdPut**
> ProductButton ProductButtonsIdPut(ctx, id, productButton)
Ürün ve Stok Butonu Güncelleme

İlgili Ürün ve Stok Butonunu günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün ve Stok Butonu nesnesinin id değeri | 
  **productButton** | [**ProductButton**](ProductButton.md)| ProductButton nesnesi | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductButtonsPost**
> ProductButton ProductButtonsPost(ctx, productButton)
Ürün ve Stok Butonu Oluşturma

Yeni bir Ürün ve Stok Butonu oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **productButton** | [**ProductButton**](ProductButton.md)| ProductButton nesnesi | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

