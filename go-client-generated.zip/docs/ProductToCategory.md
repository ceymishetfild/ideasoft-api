# ProductToCategory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ürün kategori bağı nesnesi kimlik değeri. | [optional] [default to null]
**SortOrder** | **int32** | Ürün kategori bağının sıralama değeri. Özel sıra belirtmek istemiyorsanız 9999 olarak iletebilirsiniz. | [optional] [default to null]
**Product** | [***Product**](Product.md) |  | [optional] [default to null]
**Category** | [***Category**](Category.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


