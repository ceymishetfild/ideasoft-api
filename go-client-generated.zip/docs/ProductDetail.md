# ProductDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ürün detayı nesnesi kimlik değeri. | [optional] [default to null]
**Sku** | **string** | Ürünün stok kodu. | [optional] [default to null]
**Details** | **string** | Detay bilgisi. | [optional] [default to null]
**ExtraDetails** | **string** | Ürün ekstra detaylı bilgi. | [optional] [default to null]
**Product** | [***Product**](Product.md) | Ürün nesnesi. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


