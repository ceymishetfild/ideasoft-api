# OrderUserNote

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Sipariş yönetici notu nesnesi kimlik değeri. | [optional] [default to null]
**UserEmail** | **string** | Yöneticinin(admin) e-mail adresi. | [default to null]
**UserFirstname** | **string** | Yöneticinin(admin) ismi. | [optional] [default to null]
**UserSurname** | **string** | Yöneticinin(admin) soy ismi. | [optional] [default to null]
**Note** | **string** | Yöneticinin(admin) sipariş için girdiği not. | [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Sipariş yönetici notu nesnesinin oluşturulma zamanı. | [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Sipariş yönetici notu nesnesinin güncellenme zamanı. | [default to null]
**Order** | [***Order**](Order.md) | Sipariş nesnesi. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


