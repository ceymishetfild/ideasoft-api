# SelectionGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ek özellik grubu nesnesi kimlik değeri. | [optional] [default to null]
**Title** | **string** | Ek özellik grubu nesnesinin başlığı. | [default to null]
**SortOrder** | **int32** | Ek özellik grubu nesnesi için sıralama değeri. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


