# \CurrentAccountApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CurrentAccountsGet**](CurrentAccountApi.md#CurrentAccountsGet) | **Get** /current_accounts | Cari Hesap Listesi Alma
[**CurrentAccountsIdDelete**](CurrentAccountApi.md#CurrentAccountsIdDelete) | **Delete** /current_accounts/{id} | Cari Hesap Silme
[**CurrentAccountsIdGet**](CurrentAccountApi.md#CurrentAccountsIdGet) | **Get** /current_accounts/{id} | Cari Hesap Alma
[**CurrentAccountsIdPut**](CurrentAccountApi.md#CurrentAccountsIdPut) | **Put** /current_accounts/{id} | Cari Hesap Güncelleme
[**CurrentAccountsPost**](CurrentAccountApi.md#CurrentAccountsPost) | **Post** /current_accounts | Cari Hesap Oluşturma


# **CurrentAccountsGet**
> CurrentAccount CurrentAccountsGet(ctx, optional)
Cari Hesap Listesi Alma

Cari Hesap listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | 
 **code** | **string**| Cari Hesap kodu | 
 **title** | **string**| Cari Hesap başlığı | 
 **startDate** | **string**| createdAt değeri için başlangıç tarihi | 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | 
 **startUpdatedAt** | **string**| updatedAt değeri için başlangıç tarihi | 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | 
 **member** | **string**| İlgili üye | 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **CurrentAccountsIdDelete**
> CurrentAccountsIdDelete(ctx, id)
Cari Hesap Silme

Kalıcı olarak ilgili Cari Hesabı siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Cari Hesap nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **CurrentAccountsIdGet**
> CurrentAccount CurrentAccountsIdGet(ctx, id)
Cari Hesap Alma

İlgili Cari Hesabı getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Cari Hesap nesnesinin id değeri | 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **CurrentAccountsIdPut**
> CurrentAccount CurrentAccountsIdPut(ctx, id, currentAccount)
Cari Hesap Güncelleme

İlgili Cari Hesabı günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Cari Hesap nesnesinin id değeri | 
  **currentAccount** | [**CurrentAccount**](CurrentAccount.md)|  nesnesi | 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **CurrentAccountsPost**
> CurrentAccount CurrentAccountsPost(ctx, currentAccount)
Cari Hesap Oluşturma

Yeni bir Cari Hesap oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **currentAccount** | [**CurrentAccount**](CurrentAccount.md)|  nesnesi | 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

