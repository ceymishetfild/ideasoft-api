# \MaillistApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**MaillistsGet**](MaillistApi.md#MaillistsGet) | **Get** /maillists | Mail Listesi Listesi Alma
[**MaillistsIdDelete**](MaillistApi.md#MaillistsIdDelete) | **Delete** /maillists/{id} | Mail Listesi Silme
[**MaillistsIdGet**](MaillistApi.md#MaillistsIdGet) | **Get** /maillists/{id} | Mail Listesi Alma
[**MaillistsIdPut**](MaillistApi.md#MaillistsIdPut) | **Put** /maillists/{id} | Mail Listesi Güncelleme
[**MaillistsPost**](MaillistApi.md#MaillistsPost) | **Post** /maillists | Mail Listesi Oluşturma


# **MaillistsGet**
> Maillist MaillistsGet(ctx, optional)
Mail Listesi Listesi Alma

Mail Listesi listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **name** | **string**| Mail Listesi adı. | 
 **email** | **string**| Mail Listesi e-mail. | 
 **maillistGroup** | **int32**| Mail Listesi Grubu id | 
 **startDate** | **string**| createdAt değeri için başlangıç tarihi | 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | 
 **startUpdatedAt** | **string**| updatedAt değeri için başlangıç tarihi | 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MaillistsIdDelete**
> MaillistsIdDelete(ctx, id)
Mail Listesi Silme

Kalıcı olarak ilgili Mail Listesini siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Mail Listesi nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MaillistsIdGet**
> Maillist MaillistsIdGet(ctx, id)
Mail Listesi Alma

İlgili Mail Listesini getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Mail Listesi nesnesinin id değeri | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MaillistsIdPut**
> Maillist MaillistsIdPut(ctx, id, maillist)
Mail Listesi Güncelleme

İlgili Mail Listesini günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Mail Listesi nesnesinin id değeri | 
  **maillist** | [**Maillist**](Maillist.md)| Maillist nesnesi | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MaillistsPost**
> Maillist MaillistsPost(ctx, maillist)
Mail Listesi Oluşturma

Yeni bir Mail Listesini oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **maillist** | [**Maillist**](Maillist.md)| Maillist nesnesi | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

