# \ShipmentApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ShipmentsGet**](ShipmentApi.md#ShipmentsGet) | **Get** /shipments | Teslimat Listesi Alma
[**ShipmentsIdDelete**](ShipmentApi.md#ShipmentsIdDelete) | **Delete** /shipments/{id} | Teslimat Silme
[**ShipmentsIdGet**](ShipmentApi.md#ShipmentsIdGet) | **Get** /shipments/{id} | Teslimat Alma
[**ShipmentsIdPut**](ShipmentApi.md#ShipmentsIdPut) | **Put** /shipments/{id} | Teslimat Güncelleme
[**ShipmentsPost**](ShipmentApi.md#ShipmentsPost) | **Post** /shipments | Teslimat Oluşturma


# **ShipmentsGet**
> Shipment ShipmentsGet(ctx, optional)
Teslimat Listesi Alma

Teslimat listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **code** | **string**| Teslimat kodu | 
 **invoiceKey** | **string**| Teslimat fatura anahtarı | 
 **barcode** | **string**| Teslimat barkodu | 
 **order** | **int32**| Sipariş id | 
 **startDate** | **string**| createdAt değeri için başlangıç tarihi | 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | 
 **startUpdatedAt** | **string**| updatedAt değeri için başlangıç tarihi | 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | 

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShipmentsIdDelete**
> ShipmentsIdDelete(ctx, id)
Teslimat Silme

Kalıcı olarak ilgili Teslimatı siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Teslimat nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShipmentsIdGet**
> Shipment ShipmentsIdGet(ctx, id)
Teslimat Alma

İlgili Teslimatı getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Teslimat nesnesinin id değeri | 

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShipmentsIdPut**
> Shipment ShipmentsIdPut(ctx, id, shipment)
Teslimat Güncelleme

İlgili Teslimatı günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Teslimat nesnesinin id değeri | 
  **shipment** | [**Shipment**](Shipment.md)| Shipment nesnesi | 

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShipmentsPost**
> Shipment ShipmentsPost(ctx, shipment)
Teslimat Oluşturma

Yeni bir Teslimat oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **shipment** | [**Shipment**](Shipment.md)| Shipment nesnesi | 

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

