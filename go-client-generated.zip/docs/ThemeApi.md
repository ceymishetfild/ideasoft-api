# \ThemeApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ThemesGet**](ThemeApi.md#ThemesGet) | **Get** /themes | Tema Listesi Alma
[**ThemesIdAssetsGet**](ThemeApi.md#ThemesIdAssetsGet) | **Get** /themes/{id}/assets | Tema Dosyası Listesi Alma
[**ThemesIdAssetskeykeyDelete**](ThemeApi.md#ThemesIdAssetskeykeyDelete) | **Delete** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Silme
[**ThemesIdAssetskeykeyGet**](ThemeApi.md#ThemesIdAssetskeykeyGet) | **Get** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Alma
[**ThemesIdAssetskeykeyPut**](ThemeApi.md#ThemesIdAssetskeykeyPut) | **Put** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Güncelleme
[**ThemesIdDelete**](ThemeApi.md#ThemesIdDelete) | **Delete** /themes/{id} | Tema Silme
[**ThemesIdGet**](ThemeApi.md#ThemesIdGet) | **Get** /themes/{id} | Tema Alma
[**ThemesIdPut**](ThemeApi.md#ThemesIdPut) | **Put** /themes/{id} | Tema Güncelleme
[**ThemesPost**](ThemeApi.md#ThemesPost) | **Post** /themes | Tema Oluşturma


# **ThemesGet**
> Theme ThemesGet(ctx, optional)
Tema Listesi Alma

Tema listesi verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | 
 **status** | **int32**| Tema durumu | 
 **platform** | **string**| Tema platformu | 
 **type_** | **string**| Tema tipi | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ThemesIdAssetsGet**
> Asset ThemesIdAssetsGet(ctx, id, optional)
Tema Dosyası Listesi Alma

Tema Dosyası listesi verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Tema nesnesinin id değeri | 
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int32**| Tema nesnesinin id değeri | 
 **key** | **string**| Tema Dosyası nesnesi anahtar değeri. | 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ThemesIdAssetskeykeyDelete**
> ThemesIdAssetskeykeyDelete(ctx, id, key)
Tema Dosyası Silme

Kalıcı olarak ilgili Tema Dosyasını siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Tema nesnesinin id değeri | 
  **key** | **string**| Tema Dosyası nesnesi anahtar değeri. | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ThemesIdAssetskeykeyGet**
> Asset ThemesIdAssetskeykeyGet(ctx, id, key)
Tema Dosyası Alma

İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Tema nesnesinin id değeri | 
  **key** | **string**| Tema Dosyası nesnesi anahtar değeri. | 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ThemesIdAssetskeykeyPut**
> Asset ThemesIdAssetskeykeyPut(ctx, id, theme, asset)
Tema Dosyası Güncelleme

Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Tema nesnesinin id değeri | 
  **theme** | [**Theme**](Theme.md)| Theme nesnesi | 
  **asset** | [**Asset**](Asset.md)| Asset nesnesi | 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ThemesIdDelete**
> ThemesIdDelete(ctx, id)
Tema Silme

Kalıcı olarak ilgili Temayı siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Tema nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ThemesIdGet**
> Theme ThemesIdGet(ctx, id)
Tema Alma

İlgili Temayı getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Tema nesnesinin id değeri | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ThemesIdPut**
> Theme ThemesIdPut(ctx, id, theme)
Tema Güncelleme

İlgili Temayı günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Tema nesnesinin id değeri | 
  **theme** | [**Theme**](Theme.md)| Theme nesnesi | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ThemesPost**
> Theme ThemesPost(ctx, theme)
Tema Oluşturma

Yeni bir tema oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **theme** | [**Theme**](Theme.md)| Theme nesnesi | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

