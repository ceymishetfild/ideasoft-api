# OrderItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Sipariş kalemi nesnesi kimlik değeri. | [optional] [default to null]
**ProductName** | **string** | Ürünün adı. | [default to null]
**ProductSku** | **string** | Ürünün stok kodu. | [default to null]
**ProductBarcode** | **string** | Ürünün barkodu. | [optional] [default to null]
**ProductPrice** | **float32** | Ürünün fiyatı. | [default to null]
**ProductCurrency** | **string** | Ürünün kuru. | [default to null]
**ProductQuantity** | **float32** | Ürünün stok tipi cinsinden miktarı. | [default to null]
**ProductTax** | **int32** | Ürünün vergisi | [default to null]
**ProductDiscount** | **float32** | Ürünün standart indirim değeri. | [default to null]
**ProductMoneyOrderDiscount** | **float32** | Ürünün havale indirim değeri. | [default to null]
**ProductWeight** | **float32** | Ürünün ağırlığı. | [default to null]
**ProductStockTypeLabel** | **string** | Ürünün stok tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Adet&lt;/code&gt; : Stok tipi birimi Adet&lt;br&gt;&lt;code&gt;cm&lt;/code&gt; : Stok tipi birimi Santimetre&lt;br&gt;&lt;code&gt;Düzine&lt;/code&gt; : Stok tipi birimi Düzine&lt;br&gt;&lt;code&gt;gram&lt;/code&gt; : Stok tipi birimi Gram&lt;br&gt;&lt;code&gt;kg&lt;/code&gt; : Stok tipi birimi Kilogram&lt;br&gt;&lt;code&gt;Kişi&lt;/code&gt; : Stok tipi birimi Kişi&lt;br&gt;&lt;code&gt;Paket&lt;/code&gt; : Stok tipi birimi Paket&lt;br&gt;&lt;code&gt;metre&lt;/code&gt; : Stok tipi birimi Metre&lt;br&gt;&lt;code&gt;m2&lt;/code&gt; : Stok tipi birimi Metre kare&lt;br&gt;&lt;code&gt;Çift&lt;/code&gt; : Stok tipi birimi Çift&lt;br&gt;&lt;/div&gt; | [default to null]
**IsProductPromotioned** | **string** | Ürünün promosyon olup olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;0&lt;/code&gt; : Ürün promosyon değil.&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Ürün promosyon.&lt;br&gt;&lt;/div&gt; | [optional] [default to null]
**Discount** | **float32** | Ürünün hediye çeki indirim değeri. | [default to null]
**Order** | [***Order**](Order.md) |  | [optional] [default to null]
**Product** | [***Product**](Product.md) |  | [optional] [default to null]
**OrderItemSubscription** | [***OrderItemSubscription**](OrderItemSubscription.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


