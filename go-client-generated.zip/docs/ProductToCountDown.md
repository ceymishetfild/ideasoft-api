# ProductToCountDown

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ürün geri sayım bağı nesnesi kimlik değeri. | [optional] [default to null]
**StartDate** | [**time.Time**](time.Time.md) | Geri sayımın başlangıç tarihi. | [optional] [default to null]
**EndDate** | [**time.Time**](time.Time.md) | Geri sayımın bitiş tarihi. | [optional] [default to null]
**ExpireDate** | [**time.Time**](time.Time.md) | Geri sayımın ürün için geçersiz olma tarihi. | [optional] [default to null]
**UseCountDown** | **string** | Geri sayımın aktiflik durumu bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | [default to null]
**Product** | [***Product**](Product.md) | Ürün nesnesi. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


