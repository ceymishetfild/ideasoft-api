# ShopUserlevels

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Yönetici grubu nesnesinin benzersiz rakamsal kimlik değeri. | [optional] [default to null]
**Label** | **string** | Yönetici grubu ismi. | [optional] [default to null]
**Roles** | **string** | Yönetici grubunun sahip olduğu roller. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


