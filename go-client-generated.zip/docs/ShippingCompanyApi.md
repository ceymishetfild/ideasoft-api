# \ShippingCompanyApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ShippingCompaniesGet**](ShippingCompanyApi.md#ShippingCompaniesGet) | **Get** /shipping_companies | Kargo Firması Listesi Alma
[**ShippingCompaniesIdDelete**](ShippingCompanyApi.md#ShippingCompaniesIdDelete) | **Delete** /shipping_companies/{id} | Kargo Firması Silme
[**ShippingCompaniesIdGet**](ShippingCompanyApi.md#ShippingCompaniesIdGet) | **Get** /shipping_companies/{id} | Kargo Firması Alma
[**ShippingCompaniesIdPut**](ShippingCompanyApi.md#ShippingCompaniesIdPut) | **Put** /shipping_companies/{id} | Kargo Firması Güncelleme
[**ShippingCompaniesPost**](ShippingCompanyApi.md#ShippingCompaniesPost) | **Post** /shipping_companies | Kargo Firması Oluşturma


# **ShippingCompaniesGet**
> ShippingCompany ShippingCompaniesGet(ctx, optional)
Kargo Firması Listesi Alma

Kargo Firması listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **name** | **string**| Kargo firması adı | 
 **companyCode** | **string**| Kargo firması kodu | 
 **paymentType** | **string**| Ödeme Tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil | 
 **shippingProvider** | **int32**| Teslimat Hizmeti Sağlayıcısı id | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShippingCompaniesIdDelete**
> ShippingCompaniesIdDelete(ctx, id)
Kargo Firması Silme

Kalıcı olarak ilgili Kargo Firmasını siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Kargo Firması nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShippingCompaniesIdGet**
> ShippingCompany ShippingCompaniesIdGet(ctx, id)
Kargo Firması Alma

İlgili Kargo Firmasını getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Kargo Firması nesnesinin id değeri | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShippingCompaniesIdPut**
> ShippingCompany ShippingCompaniesIdPut(ctx, id, shippingCompany)
Kargo Firması Güncelleme

İlgili Kargo Firmasını günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Kargo Firması nesnesinin id değeri | 
  **shippingCompany** | [**ShippingCompany**](ShippingCompany.md)| ShippingCompany nesnesi | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ShippingCompaniesPost**
> ShippingCompany ShippingCompaniesPost(ctx, shippingCompany)
Kargo Firması Oluşturma

Yeni bir Kargo Firması oluşturur relationship.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **shippingCompany** | [**ShippingCompany**](ShippingCompany.md)| ShippingCompany nesnesi | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

