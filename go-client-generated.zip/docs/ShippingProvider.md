# ShippingProvider

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Teslimat hizmeti sağlayıcısı nesnesi kimlik değeri. | [optional] [default to null]
**Code** | **string** | Teslimat hizmeti sağlayıcısı kodu. Benzersiz olmalıdır. | [default to null]
**Name** | **string** | Teslimat hizmeti sağlayıcısı nesnesi için isim değeri. | [default to null]
**TrackingUrl** | **string** | Kargo takip url. | [default to null]
**TrackingFormMethod** | **string** | Kargo takip formu almak için kullanılacak method.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;get&lt;/code&gt; : GET methodu.&lt;br&gt;&lt;code&gt;post&lt;/code&gt; : POST methodu.&lt;br&gt;&lt;/div&gt; | [optional] [default to null]
**Payload** | **string** | İlgili kargo takip formu almak için kullanılacak yük. | [optional] [default to null]
**Settings** | [**[]ShippingProviderSetting**](ShippingProviderSetting.md) | Teslimat hizmeti sağlayıcısı için ayarlar. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


