# ShopPreference

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Tanımlama nesnesi kimlik değeri. | [optional] [default to null]
**VarKey** | **string** | Tanımlama nesnesi için değişken anahtarı. | [optional] [default to null]
**VarValue** | **string** | Tanımlama nesnesi için değişken değeri. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


