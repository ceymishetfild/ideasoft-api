# \SpecValueApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SpecValuesGet**](SpecValueApi.md#SpecValuesGet) | **Get** /spec_values | Ürün Özellik Değeri Listesi Alma
[**SpecValuesIdDelete**](SpecValueApi.md#SpecValuesIdDelete) | **Delete** /spec_values/{id} | Ürün Özellik Değeri Silme
[**SpecValuesIdGet**](SpecValueApi.md#SpecValuesIdGet) | **Get** /spec_values/{id} | Ürün Özellik Değeri Alma
[**SpecValuesIdPut**](SpecValueApi.md#SpecValuesIdPut) | **Put** /spec_values/{id} | Ürün Özellik Değeri Güncelleme
[**SpecValuesPost**](SpecValueApi.md#SpecValuesPost) | **Post** /spec_values | Ürün Özellik Değeri Oluşturma


# **SpecValuesGet**
> SpecValue SpecValuesGet(ctx, optional)
Ürün Özellik Değeri Listesi Alma

Ürün Özellik Değeri listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **name** | **string**| Ürün özellik adı | 
 **specName** | **int32**| Ürün özellik id | 
 **specValue** | **int32**| Ürün özellik değeri id | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SpecValuesIdDelete**
> SpecValuesIdDelete(ctx, id)
Ürün Özellik Değeri Silme

Kalıcı olarak ilgili Ürün Özellik Değerini siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün Özellik Değeri nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SpecValuesIdGet**
> SpecValue SpecValuesIdGet(ctx, id)
Ürün Özellik Değeri Alma

İlgili Ürün Özellik Değerini getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün Özellik Değeri nesnesinin id değeri | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SpecValuesIdPut**
> SpecValue SpecValuesIdPut(ctx, id, specValue)
Ürün Özellik Değeri Güncelleme

İlgili Ürün Özellik Değerini günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Ürün Özellik Değeri nesnesinin id değeri | 
  **specValue** | [**SpecValue**](SpecValue.md)| SpecValue nesnesi | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SpecValuesPost**
> SpecValue SpecValuesPost(ctx, specValue)
Ürün Özellik Değeri Oluşturma

Yeni bir Ürün Özellik Değeri oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **specValue** | [**SpecValue**](SpecValue.md)| SpecValue nesnesi | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

