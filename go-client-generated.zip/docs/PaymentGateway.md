# PaymentGateway

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ödeme kanalı nesnesi kimlik değeri. | [optional] [default to null]
**Code** | **string** | Ödeme kanalı için ön tanımlanmış kod değeri. | [default to null]
**Name** | **string** | Ödeme kanalı nesnesi için isim değeri. | [default to null]
**Status** | **string** | Ödeme kanalının aktiflik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;/div&gt; | [default to null]
**SortOrder** | **int32** | Ödeme kanalı nesnesi için sıralama değeri. | [optional] [default to null]
**PaymentProvider** | [***PaymentProvider**](PaymentProvider.md) |  | [optional] [default to null]
**Settings** | [**[]PaymentGatewaySetting**](PaymentGatewaySetting.md) | Ödeme kanalı ayarları. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


