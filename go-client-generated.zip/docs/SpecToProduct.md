# SpecToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ürün özellik ürün bağı nesnesi kimlik değeri. | [optional] [default to null]
**Product** | [***Product**](Product.md) |  | [optional] [default to null]
**SpecGroup** | [***SpecGroup**](SpecGroup.md) |  | [optional] [default to null]
**SpecName** | [***SpecName**](SpecName.md) |  | [optional] [default to null]
**SpecValue** | [***SpecValue**](SpecValue.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


