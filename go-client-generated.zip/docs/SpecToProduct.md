# SpecToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ürün özellik ürün bağı nesnesi kimlik değeri. | [optional] [default to null]
**Product** | [***Product**](Product.md) | Ürün nesnesi. | [optional] [default to null]
**SpecGroup** | [***SpecGroup**](SpecGroup.md) | Ürün özelliği grubu nesnesi. | [default to null]
**SpecName** | [***SpecName**](SpecName.md) | Ürün özelliği nesnesi. | [default to null]
**SpecValue** | [***SpecValue**](SpecValue.md) | Ürün özellik grubu nesnesi. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


