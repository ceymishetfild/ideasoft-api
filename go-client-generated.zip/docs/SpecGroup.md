# SpecGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ürün özelliği grubu nesnesi kimlik değeri. | [optional] [default to null]
**Name** | **string** | Ürün özelliği grubu nesnesi için isim değeri. | [default to null]
**SortOrder** | **int32** | Ürün özelliği grubu nesnesi için sıralama değeri. | [optional] [default to null]
**Status** | **string** | Ürün özelliği grubu nesnesi için aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


