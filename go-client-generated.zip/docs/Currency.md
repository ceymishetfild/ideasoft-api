# Currency

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Kur nesnesi kimlik değeri. | [optional] [default to null]
**Label** | **string** | Kur etiketi. | [optional] [default to null]
**BuyingPrice** | **float32** | Kurun alış fiyatı. | [optional] [default to null]
**SellingPrice** | **float32** | Kurun satış fiyatı. | [optional] [default to null]
**Abbr** | **string** | Kurun kısaltması. | [optional] [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Kur nesnesinin güncellenme zamanı. | [optional] [default to null]
**Status** | **string** | Kur nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | [optional] [default to null]
**IsPrimary** | **string** | Kurun birincil kur olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Birincil kur.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Birincil kur değil.&lt;br&gt;&lt;/div&gt; | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


