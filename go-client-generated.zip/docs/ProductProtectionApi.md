# \ProductProtectionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductProtectionsGet**](ProductProtectionApi.md#ProductProtectionsGet) | **Get** /product_protections | Entegrasyon Seçeneği Listesi Alma
[**ProductProtectionsIdDelete**](ProductProtectionApi.md#ProductProtectionsIdDelete) | **Delete** /product_protections/{id} | Entegrasyon Seçeneği Silme
[**ProductProtectionsIdGet**](ProductProtectionApi.md#ProductProtectionsIdGet) | **Get** /product_protections/{id} | Entegrasyon Seçeneği Alma
[**ProductProtectionsIdPut**](ProductProtectionApi.md#ProductProtectionsIdPut) | **Put** /product_protections/{id} | Entegrasyon Seçeneği Güncelleme
[**ProductProtectionsPost**](ProductProtectionApi.md#ProductProtectionsPost) | **Post** /product_protections | Entegrasyon Seçeneği Oluşturma


# **ProductProtectionsGet**
> ProductProtection ProductProtectionsGet(ctx, optional)
Entegrasyon Seçeneği Listesi Alma

Entegrasyon Seçeneği listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **isPriceProtected** | **int32**| Fiyat korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | 
 **isStockProtected** | **int32**| Stok korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | 
 **product** | **int32**| Ürün id | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductProtectionsIdDelete**
> ProductProtectionsIdDelete(ctx, id)
Entegrasyon Seçeneği Silme

Kalıcı olarak ilgili Entegrasyon Seçeneğini siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Entegrasyon Seçeneği nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductProtectionsIdGet**
> ProductProtection ProductProtectionsIdGet(ctx, id)
Entegrasyon Seçeneği Alma

İlgili Entegrasyon Seçeneğini getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Entegrasyon Seçeneği nesnesinin id değeri | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductProtectionsIdPut**
> ProductProtection ProductProtectionsIdPut(ctx, id, productProtection)
Entegrasyon Seçeneği Güncelleme

İlgili Entegrasyon Seçeneğini günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Entegrasyon Seçeneği nesnesinin id değeri | 
  **productProtection** | [**ProductProtection**](ProductProtection.md)| ProductProtection nesnesi | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ProductProtectionsPost**
> ProductProtection ProductProtectionsPost(ctx, productProtection)
Entegrasyon Seçeneği Oluşturma

Yeni bir Entegrasyon Seçeneği oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **productProtection** | [**ProductProtection**](ProductProtection.md)| ProductProtection nesnesi | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

