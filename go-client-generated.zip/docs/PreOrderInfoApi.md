# \PreOrderInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**PreOrderInfosGet**](PreOrderInfoApi.md#PreOrderInfosGet) | **Get** /pre_order_infos | Sipariş Öncesi Bilgisi Listesi Alma
[**PreOrderInfosIdDelete**](PreOrderInfoApi.md#PreOrderInfosIdDelete) | **Delete** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Silme
[**PreOrderInfosIdGet**](PreOrderInfoApi.md#PreOrderInfosIdGet) | **Get** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Alma
[**PreOrderInfosIdPut**](PreOrderInfoApi.md#PreOrderInfosIdPut) | **Put** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Güncelleme
[**PreOrderInfosPost**](PreOrderInfoApi.md#PreOrderInfosPost) | **Post** /pre_order_infos | Sipariş Öncesi Bilgisi Oluşturma


# **PreOrderInfosGet**
> PreOrderInfo PreOrderInfosGet(ctx, optional)
Sipariş Öncesi Bilgisi Listesi Alma

Sipariş Öncesi Bilgisi listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **sessionId** | **string**| Sipariş Öncesi Bilgisi session id. | 
 **startDate** | **string**| createdAt değeri için başlangıç tarihi | 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | 
 **startUpdatedAt** | **string**| updatedAt değeri için başlangıç tarihi | 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PreOrderInfosIdDelete**
> PreOrderInfosIdDelete(ctx, id)
Sipariş Öncesi Bilgisi Silme

Kalıcı olarak ilgili Sipariş Öncesi Bilgisini siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PreOrderInfosIdGet**
> PreOrderInfo PreOrderInfosIdGet(ctx, id)
Sipariş Öncesi Bilgisi Alma

İlgili Sipariş Öncesi Bilgisini getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PreOrderInfosIdPut**
> PreOrderInfo PreOrderInfosIdPut(ctx, id, preOrderInfo)
Sipariş Öncesi Bilgisi Güncelleme

İlgili Sipariş Öncesi Bilgisini günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 
  **preOrderInfo** | [**PreOrderInfo**](PreOrderInfo.md)| PreOrderInfo nesnesi | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PreOrderInfosPost**
> PreOrderInfo PreOrderInfosPost(ctx, preOrderInfo)
Sipariş Öncesi Bilgisi Oluşturma

Yeni bir Sipariş Öncesi Bilgisi oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **preOrderInfo** | [**PreOrderInfo**](PreOrderInfo.md)| PreOrderInfo nesnesi | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

