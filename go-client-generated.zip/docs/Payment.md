# Payment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ödeme nesnesi kimlik değeri. | [optional] [default to null]
**MemberFirstname** | **string** | Üyenin ismi. | [default to null]
**MemberSurname** | **string** | Üyenin soy ismi. | [default to null]
**MemberEmail** | **string** | Üyenin e-mail adresi. | [default to null]
**MemberPhone** | **string** | Üyenin telefon numarası. | [optional] [default to null]
**PaymentTypeName** | **string** | Ödeme tipi | [default to null]
**PaymentProviderCode** | **string** | Ödeme hizmeti sağlayıcısı kodu. Bu değer ön tanımlıdır. | [default to null]
**PaymentProviderName** | **string** | Ödeme hizmeti sağlayıcısı adı. Bu değer ön tanımlıdır. | [default to null]
**PaymentGatewayName** | **string** | Ödeme kanalı adı. Bu değer ön tanımlıdır. | [default to null]
**PaymentGatewayCode** | **string** | Ödeme kanalı kodu. Bu değer ön tanımlıdır. | [default to null]
**BankName** | **string** | Ödeme yapılan banka. Bu değer ön tanımlıdır. | [optional] [default to null]
**DeviceType** | **string** | Ödemenin gerçekleştiği cihaz bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil&lt;br&gt;&lt;code&gt;tablet&lt;/code&gt; : Tablet&lt;br&gt;&lt;/div&gt; | [default to null]
**ClientIp** | **string** | Müşterinin IP adresi. | [default to null]
**CurrencyRates** | **string** | Kur oranları. | [default to null]
**Amount** | **float32** | Ödemenin saf fiyatı. | [default to null]
**FinalAmount** | **float32** | Ödemenin son fiyatı. | [default to null]
**SumOfGainedPoints** | **float32** | Ödemeden kazanılan toplam puan. | [optional] [default to null]
**Installment** | **int32** | Ödemenin standart taksit sayısı. | [default to null]
**InstallmentRate** | **float32** | Ödemenin taksit oranı. | [default to null]
**ExtraInstallment** | **int32** | Ödemenin ekstra taksit sayısı. | [optional] [default to null]
**Currency** | **string** | Kur bilgisi. | [default to null]
**TransactionId** | **string** | Siparişin numarası. | [optional] [default to null]
**MemberNote** | **string** | Müşterinin ödeme notu. | [optional] [default to null]
**UserNote** | **string** | Yönetici(admin) ödeme notu. | [optional] [default to null]
**Status** | **string** | Ödeme durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;/div&gt; | [default to null]
**ErrorMessage** | **string** | Ödemenin hata mesajı. | [optional] [default to null]
**CardSavingSystem** | **string** | Kart saklama sistemi. | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Ödeme nesnesinin oluşturulma zamanı. | [optional] [default to null]
**Member** | [***Member**](Member.md) | Üye nesnesi. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


