# Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Kategori nesnesi kimlik değeri. | [optional] [default to null]
**Name** | **string** | Kategori nesnesi için isim değeri. | [default to null]
**Slug** | **string** | Slug değeri ilgili nesnenin Url değeridir. | [optional] [default to null]
**SortOrder** | **int32** | Kategori nesnesi için sıralama değeri. | [optional] [default to null]
**Status** | **string** | Kategori nesnesinin aktiflik durumunu belirten değer. | [default to null]
**Percent** | **float32** | Kategori nesnesinin fiyat katsayısı. | [optional] [default to null]
**ImageFile** | **string** | Kategori nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF | [optional] [default to null]
**Distributor** | **string** | Her zaman null değer alır. Pratikte kullanımı yoktur. | [optional] [default to null]
**DisplayShowcaseContent** | **int32** | Kategori nesnesinin üst içerik metninin gösterim durumu. | [optional] [default to null]
**ShowcaseContent** | **string** | Kategori nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir. | [optional] [default to null]
**ShowcaseContentDisplayType** | **int32** | Kategori nesnesinin üst içerik metninin gösterim tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kategori içeriği.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Kategori ve üst kategori içeriği.&lt;br&gt;&lt;code&gt;3&lt;/code&gt; : Kategori ve tüm üst kategoriler.&lt;br&gt;&lt;/div&gt; | [default to null]
**HasChildren** | **string** | Kategori nesnesinin alt kategori barındırma durumu. Bu değer otomatik oluşturulur. | [optional] [default to null]
**MetaKeywords** | **string** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] [default to null]
**MetaDescription** | **string** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] [default to null]
**PageTitle** | **string** | Kategori nesnesinin etiket başlığı. | [optional] [default to null]
**Parent** | [***Category**](Category.md) | Üst kategori olan kategori nesnesi. | [optional] [default to null]
**Attachment** | **string** | Kategori nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Kategori nesnesinin oluşturulma zamanı. | [optional] [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Kategori nesnesinin güncellenme zamanı. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


