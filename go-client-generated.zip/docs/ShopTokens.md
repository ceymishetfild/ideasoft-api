# ShopTokens

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Hediye çeki nesnesi kimlik değeri. | [optional] [default to null]
**Code** | **string** | Hediye çekinin benzersiz kodu. Admin panelinden düzenlenebilir. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


