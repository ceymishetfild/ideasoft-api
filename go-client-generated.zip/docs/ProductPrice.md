# ProductPrice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Ürün fiyatı nesnesi kimlik değeri. | [optional] [default to null]
**Value** | **float32** | Ürün fiyatı değeri. | [default to null]
**Type_** | **int32** | Ürün fiyatı indexi. Fiyat 2, Fiyat 3 gibi. | [default to null]
**Product** | [***Product**](Product.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


