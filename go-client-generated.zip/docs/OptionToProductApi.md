# \OptionToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**OptionToProductsGet**](OptionToProductApi.md#OptionToProductsGet) | **Get** /option_to_products | Varyant Ürün Bağı Listesi Alma
[**OptionToProductsIdDelete**](OptionToProductApi.md#OptionToProductsIdDelete) | **Delete** /option_to_products/{id} | Varyant Ürün Bağı Silme
[**OptionToProductsIdGet**](OptionToProductApi.md#OptionToProductsIdGet) | **Get** /option_to_products/{id} | Varyant Ürün Bağı Alma
[**OptionToProductsIdPut**](OptionToProductApi.md#OptionToProductsIdPut) | **Put** /option_to_products/{id} | Varyant Ürün Bağı Güncelleme
[**OptionToProductsPost**](OptionToProductApi.md#OptionToProductsPost) | **Post** /option_to_products | Varyant Ürün Bağı Oluşturma


# **OptionToProductsGet**
> OptionToProduct OptionToProductsGet(ctx, optional)
Varyant Ürün Bağı Listesi Alma

Varyant Ürün Bağı listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **product** | **int32**| Ürün id | 
 **optionGroup** | **int32**| Varyant Grubu id | 
 **option** | **int32**| Varyant id | 
 **parentProductId** | **int32**| Ana Ürün id | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OptionToProductsIdDelete**
> OptionToProductsIdDelete(ctx, id)
Varyant Ürün Bağı Silme

Kalıcı olarak ilgili Varyant Ürün Bağını siler.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Varyant Ürün Bağı nesnesinin id değeri | 

### Return type

 (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OptionToProductsIdGet**
> OptionToProduct OptionToProductsIdGet(ctx, id)
Varyant Ürün Bağı Alma

İlgili Varyant Ürün Bağını getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Varyant Ürün Bağı nesnesinin id değeri | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OptionToProductsIdPut**
> OptionToProduct OptionToProductsIdPut(ctx, id, optionToProduct)
Varyant Ürün Bağı Güncelleme

İlgili Varyant Ürün Bağını günceller.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **id** | **int32**| Varyant Ürün Bağı nesnesinin id değeri | 
  **optionToProduct** | [**OptionToProduct**](OptionToProduct.md)| OptionToProduct nesnesi | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OptionToProductsPost**
> OptionToProduct OptionToProductsPost(ctx, optionToProduct)
Varyant Ürün Bağı Oluşturma

Yeni bir Varyant Ürün Bağı oluşturur.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context containing the authentication | nil if no authentication
  **optionToProduct** | [**OptionToProduct**](OptionToProduct.md)| OptionToProduct nesnesi | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

