# Tag

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | SEO+ etiketi nesnesi kimlik değeri. | [optional] [default to null]
**Name** | **string** | SEO+ etiketi nesnesi için isim değeri. | [default to null]
**Count** | **int32** | SEO+ etiketinin kaç kez kullanıldığı bilgisi. | [optional] [default to null]
**PageTitle** | **string** | SEO+ etiketi nesnesinin etiket başlığı. | [optional] [default to null]
**MetaDescription** | **string** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] [default to null]
**MetaKeywords** | **string** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


