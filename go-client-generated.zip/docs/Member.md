# Member

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Üye nesnesi kimlik değeri. | [optional] [default to null]
**Firstname** | **string** | Üyenin ismi. | [default to null]
**Surname** | **string** | Üyenin soy ismi. | [default to null]
**Email** | **string** | Üyenin e-mail adresi. | [default to null]
**Gender** | **string** | Üyenin cinsiyet bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın&lt;br&gt;&lt;/div&gt; | [optional] [default to null]
**BirthDate** | [**time.Time**](time.Time.md) | Üyenin doğum tarihi. | [optional] [default to null]
**PhoneNumber** | **string** | Üyenin telefon numarası. | [optional] [default to null]
**MobilePhoneNumber** | **string** | Üyenin mobil telefon numarası. | [optional] [default to null]
**OtherLocation** | **string** | Üyenin diğer şehir bilgileri. | [optional] [default to null]
**Address** | **string** | Üyenin adres bilgileri. | [optional] [default to null]
**TaxNumber** | **string** | Üyenin vergi numarası. | [optional] [default to null]
**TcId** | **string** | Üyenin TC kimlik numarası. | [optional] [default to null]
**Status** | **string** | Üyenin durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;queue&lt;/code&gt; : Sırada&lt;br&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;suspended&lt;/code&gt; : Askıda&lt;br&gt;&lt;/div&gt; | [default to null]
**LastLoginDate** | [**time.Time**](time.Time.md) | Üyenin son giriş yaptığı tarih. | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Üye nesnesinin oluşturulma zamanı. | [optional] [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Üye nesnesinin güncellenme zamanı. | [optional] [default to null]
**ZipCode** | **string** | Üyenin posta kodu. | [optional] [default to null]
**CommercialName** | **string** | Üyenin kurumsal adı. | [optional] [default to null]
**TaxOffice** | **string** | Üyenin vergi dairesi. | [optional] [default to null]
**LastMailSentDate** | [**time.Time**](time.Time.md) | Üyeye gönderilen son e-mail tarihi. | [optional] [default to null]
**LastIp** | **string** | Üyenin en son giriş yaptığı IP adresi. | [optional] [default to null]
**GainedPointAmount** | **float32** | Üyenin kazandığı puan tutarı. | [optional] [default to null]
**SpentPointAmount** | **float32** | Üyenin harcadığı puan tutarı. | [optional] [default to null]
**AllowedToCampaigns** | **string** | Üyenin kampanyalara katılım için izin durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalar için izinli.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalar için izinsiz.&lt;br&gt;&lt;/div&gt; | [optional] [default to null]
**ReferredMemberGainedPointAmount** | **float32** | Üyenin tavsiye ettiği kişilerden dolayı kazandığı puan. | [optional] [default to null]
**District** | **string** | Üyenin ilçesi. | [optional] [default to null]
**DeviceType** | **string** | Üyenin kullandığı cihaz tipi. | [default to null]
**DeviceInfo** | **string** | Üyenin kullandığı cihaz bilgisi. | [optional] [default to null]
**Country** | [***Country**](Country.md) |  | [optional] [default to null]
**Location** | [***Location**](Location.md) |  | [optional] [default to null]
**MemberGroup** | [***MemberGroup**](MemberGroup.md) |  | [optional] [default to null]
**ReferredMember** | [***Member**](Member.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


