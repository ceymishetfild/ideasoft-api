# PreOrderInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Sipariş öncesi bilgisi nesnesi kimlik değeri. | [optional] [default to null]
**SessionId** | **string** | Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri. | [default to null]
**CustomerFirstname** | **string** | Müşterinin ismi. | [optional] [default to null]
**CustomerSurname** | **string** | Müşterinin soy ismi. | [optional] [default to null]
**CustomerEmail** | **string** | Müşterinin e-mail adresi. | [optional] [default to null]
**ShippingFirstname** | **string** | Teslimat yapılacak kişinin ismi. | [default to null]
**ShippingSurname** | **string** | Teslimat yapılacak kişinin soy ismi. | [default to null]
**ShippingAddress** | **string** | Teslimat adresi bilgileri. | [default to null]
**ShippingPhoneNumber** | **string** | Teslimat yapılacak kişinin telefon numarası. | [default to null]
**ShippingMobilePhoneNumber** | **string** | Teslimat yapılacak kişinin mobil telefon numarası. | [default to null]
**ShippingLocationName** | **string** | Teslimat şehri. | [default to null]
**ShippingTown** | **string** | Teslimat ilçesi. | [default to null]
**DifferentBillingAddress** | **string** | Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yok&lt;br&gt;&lt;/div&gt; | [optional] [default to null]
**BillingFirstname** | **string** | Fatura kesilen kişinin ismi. | [default to null]
**BillingSurname** | **string** | Fatura kesilen kişinin soy ismi. | [default to null]
**BillingAddress** | **string** | Fatura adresi bilgileri. | [default to null]
**BillingPhoneNumber** | **string** | Fatura kesilen kişinin telefon numarası. | [default to null]
**BillingMobilePhoneNumber** | **string** | Fatura kesilen kişinin mobil telefon numarası. | [default to null]
**BillingLocationName** | **string** | Fatura adresi şehri | [default to null]
**BillingTown** | **string** | Fatura adresi ilçesi. | [default to null]
**BillingInvoiceType** | **string** | Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt; | [default to null]
**BillingIdentityRegistrationNumber** | **string** | Fatura kesilen kişinin TC kimlik numarası. | [optional] [default to null]
**BillingTaxOffice** | **string** | Fatura kesilen kişi/kurumun vergi dairesi. | [optional] [default to null]
**BillingTaxNo** | **string** | Fatura kesilen kişi/kurum vergi numarası. | [optional] [default to null]
**IsEinvoiceUser** | **string** | Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] [default to null]
**UseGiftPackage** | **string** | Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] [default to null]
**GiftNote** | **string** | Hediye notu bilgisi. | [optional] [default to null]
**ImageFile** | **string** | Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif | [optional] [default to null]
**DeliveryDate** | **string** | Müşterinin teslimatın gerçekleşmisini istediği tarih. | [optional] [default to null]
**DeliveryTime** | **string** | API bu değeri otomatik oluşturur. | [optional] [default to null]
**CreatedAt** | [**time.Time**](time.Time.md) | Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı. | [optional] [default to null]
**UpdatedAt** | [**time.Time**](time.Time.md) | Sipariş öncesi bilgisi nesnesinin güncellenme zamanı. | [optional] [default to null]
**BillingCountry** | [***Country**](Country.md) | Ülke nesnesi. | [default to null]
**BillingLocation** | [***Location**](Location.md) | Şehir nesnesi. | [default to null]
**ShippingCompany** | [***ShippingCompany**](ShippingCompany.md) | Kargo firması nesnesi. | [default to null]
**ShippingCountry** | [***Country**](Country.md) | Ülke nesnesi. | [default to null]
**ShippingLocation** | [***Location**](Location.md) | Şehir nesnesi. | [default to null]
**MemberShippingAddress** | [***MemberAddress**](MemberAddress.md) | Üye adresi nesnesi. | [optional] [default to null]
**MemberBillingAddress** | [***MemberAddress**](MemberAddress.md) | Üye adresi nesnesi. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


