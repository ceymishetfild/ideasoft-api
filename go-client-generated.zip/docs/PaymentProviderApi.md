# \PaymentProviderApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**PaymentProvidersGet**](PaymentProviderApi.md#PaymentProvidersGet) | **Get** /payment_providers | Ödeme Altyapısı Sağlayıcısı Listesi Alma
[**PaymentProvidersIdGet**](PaymentProviderApi.md#PaymentProvidersIdGet) | **Get** /payment_providers/{id} | Ödeme Altyapısı Sağlayıcısı Alma


# **PaymentProvidersGet**
> PaymentProvider PaymentProvidersGet(ctx, optional)
Ödeme Altyapısı Sağlayıcısı Listesi Alma

Ödeme Altyapısı Sağlayıcısı listesini verir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | 
 **limit** | **int32**| Bir sayfada gelecek sonuç adedi | [default to 20]
 **page** | **int32**| Hangi sayfadan başlanacağı | [default to 1]
 **sinceId** | **int32**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | 
 **code** | **string**| Ödeme Altyapısı kodu | 
 **name** | **string**| Ödeme Altyapısı adı | 

### Return type

[**PaymentProvider**](PaymentProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PaymentProvidersIdGet**
> PaymentProvider PaymentProvidersIdGet(ctx, id)
Ödeme Altyapısı Sağlayıcısı Alma

İlgili Ödeme Altyapısı Sağlayıcısını getirir.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **id** | **int32**| Ödeme Altyapııs Sağlayıcısı nesnesinin id değeri | 

### Return type

[**PaymentProvider**](PaymentProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

