
# ProductToCountDown

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ürün geri sayım bağı nesnesi kimlik değeri. |  [optional]
**startDate** | [**Date**](Date.md) | Geri sayımın başlangıç tarihi. |  [optional]
**endDate** | [**Date**](Date.md) | Geri sayımın bitiş tarihi. |  [optional]
**expireDate** | [**Date**](Date.md) | Geri sayımın ürün için geçersiz olma tarihi. |  [optional]
**useCountDown** | [**UseCountDownEnum**](#UseCountDownEnum) | Geri sayımın aktiflik durumu bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 


<a name="UseCountDownEnum"></a>
## Enum: UseCountDownEnum
Name | Value
---- | -----



