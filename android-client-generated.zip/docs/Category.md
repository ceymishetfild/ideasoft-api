
# Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Kategori nesnesi kimlik değeri. |  [optional]
**name** | **String** | Kategori nesnesi için isim değeri. | 
**slug** | **String** | Slug değeri ilgili nesnenin Url değeridir. |  [optional]
**sortOrder** | **Integer** | Kategori nesnesi için sıralama değeri. |  [optional]
**status** | [**StatusEnum**](#StatusEnum) | Kategori nesnesinin aktiflik durumunu belirten değer. | 
**percent** | **Float** | Kategori nesnesinin fiyat katsayısı. |  [optional]
**imageFile** | **String** | Kategori nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF |  [optional]
**distributor** | **String** | Her zaman null değer alır. Pratikte kullanımı yoktur. |  [optional]
**displayShowcaseContent** | **Integer** | Kategori nesnesinin üst içerik metninin gösterim durumu. |  [optional]
**showcaseContent** | **String** | Kategori nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir. |  [optional]
**showcaseContentDisplayType** | **Integer** | Kategori nesnesinin üst içerik metninin gösterim tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kategori içeriği.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Kategori ve üst kategori içeriği.&lt;br&gt;&lt;code&gt;3&lt;/code&gt; : Kategori ve tüm üst kategoriler.&lt;br&gt;&lt;/div&gt; | 
**hasChildren** | [**HasChildrenEnum**](#HasChildrenEnum) | Kategori nesnesinin alt kategori barındırma durumu. Bu değer otomatik oluşturulur. |  [optional]
**metaKeywords** | **String** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. |  [optional]
**metaDescription** | **String** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. |  [optional]
**pageTitle** | **String** | Kategori nesnesinin etiket başlığı. |  [optional]
**parent** | [**Category**](Category.md) | Üst kategori olan kategori nesnesi. |  [optional]
**attachment** | **String** | Kategori nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. |  [optional]
**createdAt** | [**Date**](Date.md) | Kategori nesnesinin oluşturulma zamanı. |  [optional]
**updatedAt** | [**Date**](Date.md) | Kategori nesnesinin güncellenme zamanı. |  [optional]


<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----


<a name="HasChildrenEnum"></a>
## Enum: HasChildrenEnum
Name | Value
---- | -----



