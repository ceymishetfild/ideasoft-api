# SpecValueApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specValuesGet**](SpecValueApi.md#specValuesGet) | **GET** /spec_values | Ürün Özellik Değeri Listesi Alma
[**specValuesIdDelete**](SpecValueApi.md#specValuesIdDelete) | **DELETE** /spec_values/{id} | Ürün Özellik Değeri Silme
[**specValuesIdGet**](SpecValueApi.md#specValuesIdGet) | **GET** /spec_values/{id} | Ürün Özellik Değeri Alma
[**specValuesIdPut**](SpecValueApi.md#specValuesIdPut) | **PUT** /spec_values/{id} | Ürün Özellik Değeri Güncelleme
[**specValuesPost**](SpecValueApi.md#specValuesPost) | **POST** /spec_values | Ürün Özellik Değeri Oluşturma


<a name="specValuesGet"></a>
# **specValuesGet**
> SpecValue specValuesGet(sort, limit, page, sinceId, ids, name, specName, specValue)

Ürün Özellik Değeri Listesi Alma

Ürün Özellik Değeri listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.SpecValueApi;

SpecValueApi apiInstance = new SpecValueApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String name = "name_example"; // String | Ürün özellik adı
Integer specName = 56; // Integer | Ürün özellik id
Integer specValue = 56; // Integer | Ürün özellik değeri id
try {
    SpecValue result = apiInstance.specValuesGet(sort, limit, page, sinceId, ids, name, specName, specValue);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecValueApi#specValuesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **name** | **String**| Ürün özellik adı | [optional]
 **specName** | **Integer**| Ürün özellik id | [optional]
 **specValue** | **Integer**| Ürün özellik değeri id | [optional]

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specValuesIdDelete"></a>
# **specValuesIdDelete**
> specValuesIdDelete(id)

Ürün Özellik Değeri Silme

Kalıcı olarak ilgili Ürün Özellik Değerini siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.SpecValueApi;

SpecValueApi apiInstance = new SpecValueApi();
Integer id = 56; // Integer | Ürün Özellik Değeri nesnesinin id değeri
try {
    apiInstance.specValuesIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecValueApi#specValuesIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Değeri nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specValuesIdGet"></a>
# **specValuesIdGet**
> SpecValue specValuesIdGet(id)

Ürün Özellik Değeri Alma

İlgili Ürün Özellik Değerini getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.SpecValueApi;

SpecValueApi apiInstance = new SpecValueApi();
Integer id = 56; // Integer | Ürün Özellik Değeri nesnesinin id değeri
try {
    SpecValue result = apiInstance.specValuesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecValueApi#specValuesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Değeri nesnesinin id değeri |

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specValuesIdPut"></a>
# **specValuesIdPut**
> SpecValue specValuesIdPut(id, specValue)

Ürün Özellik Değeri Güncelleme

İlgili Ürün Özellik Değerini günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.SpecValueApi;

SpecValueApi apiInstance = new SpecValueApi();
Integer id = 56; // Integer | Ürün Özellik Değeri nesnesinin id değeri
SpecValue specValue = new SpecValue(); // SpecValue |  nesnesi
try {
    SpecValue result = apiInstance.specValuesIdPut(id, specValue);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecValueApi#specValuesIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Değeri nesnesinin id değeri |
 **specValue** | [**SpecValue**](SpecValue.md)|  nesnesi |

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specValuesPost"></a>
# **specValuesPost**
> SpecValue specValuesPost(specValue)

Ürün Özellik Değeri Oluşturma

Yeni bir Ürün Özellik Değeri oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.SpecValueApi;

SpecValueApi apiInstance = new SpecValueApi();
SpecValue specValue = new SpecValue(); // SpecValue |  nesnesi
try {
    SpecValue result = apiInstance.specValuesPost(specValue);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecValueApi#specValuesPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specValue** | [**SpecValue**](SpecValue.md)|  nesnesi |

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

