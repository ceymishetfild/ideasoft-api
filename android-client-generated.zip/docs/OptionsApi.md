# OptionsApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**optionsGet**](OptionsApi.md#optionsGet) | **GET** /options | Varyant Listesi Alma
[**optionsIdDelete**](OptionsApi.md#optionsIdDelete) | **DELETE** /options/{id} | Varyant Silme
[**optionsIdGet**](OptionsApi.md#optionsIdGet) | **GET** /options/{id} | Varyant Alma
[**optionsIdPut**](OptionsApi.md#optionsIdPut) | **PUT** /options/{id} | Varyant Güncelleme
[**optionsPost**](OptionsApi.md#optionsPost) | **POST** /options | Varyant Oluşturma


<a name="optionsGet"></a>
# **optionsGet**
> Options optionsGet(sort, limit, page, sinceId, ids, title, optionGroup)

Varyant Listesi Alma

Varyant listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.OptionsApi;

OptionsApi apiInstance = new OptionsApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String title = "title_example"; // String | Varyant başlığı
Integer optionGroup = 56; // Integer | Varyant Grubu id
try {
    Options result = apiInstance.optionsGet(sort, limit, page, sinceId, ids, title, optionGroup);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OptionsApi#optionsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **title** | **String**| Varyant başlığı | [optional]
 **optionGroup** | **Integer**| Varyant Grubu id | [optional]

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionsIdDelete"></a>
# **optionsIdDelete**
> optionsIdDelete(id)

Varyant Silme

Kalıcı olarak ilgili Varyantı siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.OptionsApi;

OptionsApi apiInstance = new OptionsApi();
Integer id = 56; // Integer | Varyant nesnesinin id değeri
try {
    apiInstance.optionsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling OptionsApi#optionsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionsIdGet"></a>
# **optionsIdGet**
> Options optionsIdGet(id)

Varyant Alma

İlgili Varyantı getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.OptionsApi;

OptionsApi apiInstance = new OptionsApi();
Integer id = 56; // Integer | Varyant nesnesinin id değeri
try {
    Options result = apiInstance.optionsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OptionsApi#optionsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant nesnesinin id değeri |

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionsIdPut"></a>
# **optionsIdPut**
> Options optionsIdPut(id, options)

Varyant Güncelleme

İlgili Varyantı günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.OptionsApi;

OptionsApi apiInstance = new OptionsApi();
Integer id = 56; // Integer | Varyant nesnesinin id değeri
Options options = new Options(); // Options |  nesnesi
try {
    Options result = apiInstance.optionsIdPut(id, options);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OptionsApi#optionsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant nesnesinin id değeri |
 **options** | [**Options**](Options.md)|  nesnesi |

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionsPost"></a>
# **optionsPost**
> Options optionsPost(options)

Varyant Oluşturma

Yeni bir Varyant oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.OptionsApi;

OptionsApi apiInstance = new OptionsApi();
Options options = new Options(); // Options |  nesnesi
try {
    Options result = apiInstance.optionsPost(options);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OptionsApi#optionsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **options** | [**Options**](Options.md)|  nesnesi |

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

