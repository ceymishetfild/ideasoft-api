# ProductSpecialInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productSpecialInfosGet**](ProductSpecialInfoApi.md#productSpecialInfosGet) | **GET** /product_special_infos | Ürün Özel Bilgi Alanı Listesi Alma
[**productSpecialInfosIdDelete**](ProductSpecialInfoApi.md#productSpecialInfosIdDelete) | **DELETE** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**productSpecialInfosIdGet**](ProductSpecialInfoApi.md#productSpecialInfosIdGet) | **GET** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**productSpecialInfosIdPut**](ProductSpecialInfoApi.md#productSpecialInfosIdPut) | **PUT** /product_special_infos/{id} | Ürün Özel Bilgi Alanı Güncelleme
[**productSpecialInfosPost**](ProductSpecialInfoApi.md#productSpecialInfosPost) | **POST** /product_special_infos | Ürün Özel Bilgi Alanı Oluşturma


<a name="productSpecialInfosGet"></a>
# **productSpecialInfosGet**
> ProductSpecialInfo productSpecialInfosGet(sort, limit, page, sinceId, title, status, product)

Ürün Özel Bilgi Alanı Listesi Alma

Ürün Özel Bilgi Alanı listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductSpecialInfoApi;

ProductSpecialInfoApi apiInstance = new ProductSpecialInfoApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String title = "title_example"; // String | Ürün Özel Bilgi Alanı başlığı
Integer status = 56; // Integer | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
Integer product = 56; // Integer | Ürün id
try {
    ProductSpecialInfo result = apiInstance.productSpecialInfosGet(sort, limit, page, sinceId, title, status, product);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductSpecialInfoApi#productSpecialInfosGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **title** | **String**| Ürün Özel Bilgi Alanı başlığı | [optional]
 **status** | **Integer**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] [enum: 0, 1]
 **product** | **Integer**| Ürün id | [optional]

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productSpecialInfosIdDelete"></a>
# **productSpecialInfosIdDelete**
> productSpecialInfosIdDelete(id)

Ürün Özel Bilgi Alanı

Kalıcı olarak ilgili Ürün Özel Bilgi Alanını siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductSpecialInfoApi;

ProductSpecialInfoApi apiInstance = new ProductSpecialInfoApi();
Integer id = 56; // Integer | Ürün Özel Bilgi Alanı nesnesinin id değeri
try {
    apiInstance.productSpecialInfosIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductSpecialInfoApi#productSpecialInfosIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özel Bilgi Alanı nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productSpecialInfosIdGet"></a>
# **productSpecialInfosIdGet**
> ProductSpecialInfo productSpecialInfosIdGet(id)

Ürün Özel Bilgi Alanı

İlgili Ürün Özel Bilgi Alanını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductSpecialInfoApi;

ProductSpecialInfoApi apiInstance = new ProductSpecialInfoApi();
Integer id = 56; // Integer | Ürün Özel Bilgi Alanı nesnesinin id değeri
try {
    ProductSpecialInfo result = apiInstance.productSpecialInfosIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductSpecialInfoApi#productSpecialInfosIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özel Bilgi Alanı nesnesinin id değeri |

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productSpecialInfosIdPut"></a>
# **productSpecialInfosIdPut**
> ProductSpecialInfo productSpecialInfosIdPut(id, productSpecialInfo)

Ürün Özel Bilgi Alanı Güncelleme

İlgili Ürün Özel Bilgi Alanını günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductSpecialInfoApi;

ProductSpecialInfoApi apiInstance = new ProductSpecialInfoApi();
Integer id = 56; // Integer | Ürün Özel Bilgi Alanı nesnesinin id değeri
ProductSpecialInfo productSpecialInfo = new ProductSpecialInfo(); // ProductSpecialInfo | ProductSpecialInfo nesnesi
try {
    ProductSpecialInfo result = apiInstance.productSpecialInfosIdPut(id, productSpecialInfo);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductSpecialInfoApi#productSpecialInfosIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özel Bilgi Alanı nesnesinin id değeri |
 **productSpecialInfo** | [**ProductSpecialInfo**](ProductSpecialInfo.md)| ProductSpecialInfo nesnesi |

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productSpecialInfosPost"></a>
# **productSpecialInfosPost**
> ProductSpecialInfo productSpecialInfosPost(productSpecialInfo)

Ürün Özel Bilgi Alanı Oluşturma

Yeni bir Ürün Özel Bilgi Alanı oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductSpecialInfoApi;

ProductSpecialInfoApi apiInstance = new ProductSpecialInfoApi();
ProductSpecialInfo productSpecialInfo = new ProductSpecialInfo(); // ProductSpecialInfo | ProductSpecialInfo nesnesi
try {
    ProductSpecialInfo result = apiInstance.productSpecialInfosPost(productSpecialInfo);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductSpecialInfoApi#productSpecialInfosPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productSpecialInfo** | [**ProductSpecialInfo**](ProductSpecialInfo.md)| ProductSpecialInfo nesnesi |

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

