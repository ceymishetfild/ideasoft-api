
# Town

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | İlçe nesnesi kimlik değeri. |  [optional]
**name** | **String** | İlçe nesnesi için isim değeri. | 
**status** | [**StatusEnum**](#StatusEnum) | İlçenin aktiflik bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**location** | [**Location**](Location.md) |  |  [optional]
**townGroup** | [**TownGroup**](TownGroup.md) |  |  [optional]


<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----



