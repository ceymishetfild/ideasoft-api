
# Currency

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Kur nesnesi kimlik değeri. |  [optional]
**label** | **String** | Kur etiketi. |  [optional]
**buyingPrice** | **Float** | Kurun alış fiyatı. |  [optional]
**sellingPrice** | **Float** | Kurun satış fiyatı. |  [optional]
**abbr** | **String** | Kurun kısaltması. |  [optional]
**updatedAt** | [**Date**](Date.md) | Kur nesnesinin güncellenme zamanı. |  [optional]
**status** | [**StatusEnum**](#StatusEnum) | Kur nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; |  [optional]
**isPrimary** | [**IsPrimaryEnum**](#IsPrimaryEnum) | Kurun birincil kur olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Birincil kur.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Birincil kur değil.&lt;br&gt;&lt;/div&gt; |  [optional]


<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----


<a name="IsPrimaryEnum"></a>
## Enum: IsPrimaryEnum
Name | Value
---- | -----



