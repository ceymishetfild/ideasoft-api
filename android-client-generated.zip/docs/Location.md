
# Location

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Şehir nesnesi kimlik değeri. |  [optional]
**name** | **String** | Şehir nesnesi için isim değeri. | 
**status** | [**StatusEnum**](#StatusEnum) | Şehir nesnesinin aktiflik durumunu belirten değer. | 
**predefined** | [**PredefinedEnum**](#PredefinedEnum) | Şehir nesnesinin öntanımlı olup olmadığını belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Öntanımlı şehir.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yeni eklenmiş şehir.&lt;br&gt;&lt;/div&gt; |  [optional]
**country** | [**Country**](Country.md) | Ülke nesnesi. |  [optional]
**region** | [**Region**](Region.md) | Bölge nesnesi. |  [optional]


<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----


<a name="PredefinedEnum"></a>
## Enum: PredefinedEnum
Name | Value
---- | -----



