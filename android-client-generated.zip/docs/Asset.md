
# Asset

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** | Tema Dosyası nesnesi anahtar değeri. |  [optional]
**contentType** | **String** | Tema Dosyası içerik tipi. Geçerli bir MIME Content-Type verilmelidir. |  [optional]
**attachment** | **String** | Tema Dosyası içeriği. |  [optional]
**createdAt** | [**Date**](Date.md) | Tema Dosyası nesnesinin oluşturulma zamanı. |  [optional]
**updatedAt** | [**Date**](Date.md) | Tema Dosyası nesnesinin güncellenme zamanı. |  [optional]



