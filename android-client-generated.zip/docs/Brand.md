
# Brand

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Marka nesnesi kimlik değeri. |  [optional]
**name** | **String** | Marka nesnesi için isim değeri. | 
**slug** | **String** | Slug değeri ilgili nesnenin Url değeridir. |  [optional]
**sortOrder** | **Integer** | Marka nesnesi için sıralama değeri. |  [optional]
**status** | [**StatusEnum**](#StatusEnum) | Marka nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**distributor** | **String** | Markanın tedarikçisi. |  [optional]
**imageFile** | **String** | Marka nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF |  [optional]
**showcaseContent** | **String** | Marka nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir. |  [optional]
**displayShowcaseContent** | [**DisplayShowcaseContentEnum**](#DisplayShowcaseContentEnum) | Marka nesnesi üst içerik metninin gösterim durumu. |  [optional]
**metaKeywords** | **String** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. |  [optional]
**metaDescription** | **String** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. |  [optional]
**pageTitle** | **String** | Marka nesnesinin etiket başlığı. |  [optional]
**attachment** | **String** | Marka nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. |  [optional]
**createdAt** | [**Date**](Date.md) | Marka nesnesinin oluşturulma zamanı. |  [optional]
**updatedAt** | [**Date**](Date.md) | Marka nesnesinin güncellenme zamanı. |  [optional]


<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----


<a name="DisplayShowcaseContentEnum"></a>
## Enum: DisplayShowcaseContentEnum
Name | Value
---- | -----



