# ProductPriceApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productPricesGet**](ProductPriceApi.md#productPricesGet) | **GET** /product_prices | Ürün Fiyat Listesi Alma
[**productPricesIdDelete**](ProductPriceApi.md#productPricesIdDelete) | **DELETE** /product_prices/{id} | Ürün Fiyat Silme
[**productPricesIdGet**](ProductPriceApi.md#productPricesIdGet) | **GET** /product_prices/{id} | Ürün Fiyat Alma
[**productPricesIdPut**](ProductPriceApi.md#productPricesIdPut) | **PUT** /product_prices/{id} | Ürün Fiyat Güncelleme
[**productPricesPost**](ProductPriceApi.md#productPricesPost) | **POST** /product_prices | Ürün Fiyat Oluşturma


<a name="productPricesGet"></a>
# **productPricesGet**
> ProductPrice productPricesGet(sort, limit, page, sinceId, type, product)

Ürün Fiyat Listesi Alma

Ürün Fiyat listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductPriceApi;

ProductPriceApi apiInstance = new ProductPriceApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
Integer type = 56; // Integer | Ürün fiyat tipi
Integer product = 56; // Integer | Ürün id
try {
    ProductPrice result = apiInstance.productPricesGet(sort, limit, page, sinceId, type, product);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductPriceApi#productPricesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **type** | **Integer**| Ürün fiyat tipi | [optional]
 **product** | **Integer**| Ürün id | [optional]

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productPricesIdDelete"></a>
# **productPricesIdDelete**
> productPricesIdDelete(id)

Ürün Fiyat Silme

Kalıcı olarak ilgili Ürün Fiyatını siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductPriceApi;

ProductPriceApi apiInstance = new ProductPriceApi();
Integer id = 56; // Integer | Ürün Fiyat nesnesinin id değeri
try {
    apiInstance.productPricesIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductPriceApi#productPricesIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Fiyat nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productPricesIdGet"></a>
# **productPricesIdGet**
> ProductPrice productPricesIdGet(id)

Ürün Fiyat Alma

İlgili Ürün Fiyatını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductPriceApi;

ProductPriceApi apiInstance = new ProductPriceApi();
Integer id = 56; // Integer | Ürün Fiyat nesnesinin id değeri
try {
    ProductPrice result = apiInstance.productPricesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductPriceApi#productPricesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Fiyat nesnesinin id değeri |

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productPricesIdPut"></a>
# **productPricesIdPut**
> ProductPrice productPricesIdPut(id, productPrice)

Ürün Fiyat Güncelleme

İlgili Ürün Fiyatını günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductPriceApi;

ProductPriceApi apiInstance = new ProductPriceApi();
Integer id = 56; // Integer | Ürün Fiyat nesnesinin id değeri
ProductPrice productPrice = new ProductPrice(); // ProductPrice | ProductPrice nesnesi
try {
    ProductPrice result = apiInstance.productPricesIdPut(id, productPrice);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductPriceApi#productPricesIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Fiyat nesnesinin id değeri |
 **productPrice** | [**ProductPrice**](ProductPrice.md)| ProductPrice nesnesi |

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productPricesPost"></a>
# **productPricesPost**
> ProductPrice productPricesPost(productPrice)

Ürün Fiyat Oluşturma

Yeni bir Ürün Fiyat oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductPriceApi;

ProductPriceApi apiInstance = new ProductPriceApi();
ProductPrice productPrice = new ProductPrice(); // ProductPrice | ProductPrice nesnesi
try {
    ProductPrice result = apiInstance.productPricesPost(productPrice);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductPriceApi#productPricesPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productPrice** | [**ProductPrice**](ProductPrice.md)| ProductPrice nesnesi |

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

