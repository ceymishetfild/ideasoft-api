# SpecGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specGroupsGet**](SpecGroupApi.md#specGroupsGet) | **GET** /spec_groups | Ürün Özellik Grubu Listesi Alma
[**specGroupsIdDelete**](SpecGroupApi.md#specGroupsIdDelete) | **DELETE** /spec_groups/{id} | Ürün Özellik Grubu Silme
[**specGroupsIdGet**](SpecGroupApi.md#specGroupsIdGet) | **GET** /spec_groups/{id} | Ürün Özellik Grubu Alma
[**specGroupsIdPut**](SpecGroupApi.md#specGroupsIdPut) | **PUT** /spec_groups/{id} | Ürün Özellik Grubu Güncelleme
[**specGroupsPost**](SpecGroupApi.md#specGroupsPost) | **POST** /spec_groups | Ürün Özellik Grubu Oluşturma


<a name="specGroupsGet"></a>
# **specGroupsGet**
> SpecGroup specGroupsGet(sort, limit, page, sinceId, ids, name)

Ürün Özellik Grubu Listesi Alma

Ürün Özellik Grubu listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.SpecGroupApi;

SpecGroupApi apiInstance = new SpecGroupApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String name = "name_example"; // String | Ürün Özellik Grubu adı
try {
    SpecGroup result = apiInstance.specGroupsGet(sort, limit, page, sinceId, ids, name);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecGroupApi#specGroupsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **name** | **String**| Ürün Özellik Grubu adı | [optional]

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specGroupsIdDelete"></a>
# **specGroupsIdDelete**
> specGroupsIdDelete(id)

Ürün Özellik Grubu Silme

Kalıcı olarak ilgili Ürün Özellik Grubunu siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.SpecGroupApi;

SpecGroupApi apiInstance = new SpecGroupApi();
Integer id = 56; // Integer | Ürün Özellik Grubu nesnesinin id değeri
try {
    apiInstance.specGroupsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecGroupApi#specGroupsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Grubu nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specGroupsIdGet"></a>
# **specGroupsIdGet**
> SpecGroup specGroupsIdGet(id)

Ürün Özellik Grubu Alma

İlgili Ürün Özellik Grubunu getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.SpecGroupApi;

SpecGroupApi apiInstance = new SpecGroupApi();
Integer id = 56; // Integer | Ürün Özellik Grubu nesnesinin id değeri
try {
    SpecGroup result = apiInstance.specGroupsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecGroupApi#specGroupsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Grubu nesnesinin id değeri |

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specGroupsIdPut"></a>
# **specGroupsIdPut**
> SpecGroup specGroupsIdPut(id, specGroup)

Ürün Özellik Grubu Güncelleme

İlgili Ürün Özellik Grubunu günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.SpecGroupApi;

SpecGroupApi apiInstance = new SpecGroupApi();
Integer id = 56; // Integer | Ürün Özellik Grubu nesnesinin id değeri
SpecGroup specGroup = new SpecGroup(); // SpecGroup |  nesnesi
try {
    SpecGroup result = apiInstance.specGroupsIdPut(id, specGroup);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecGroupApi#specGroupsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Grubu nesnesinin id değeri |
 **specGroup** | [**SpecGroup**](SpecGroup.md)|  nesnesi |

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specGroupsPost"></a>
# **specGroupsPost**
> SpecGroup specGroupsPost(specGroup)

Ürün Özellik Grubu Oluşturma

Yeni bir Ürün Özellik Grubu oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.SpecGroupApi;

SpecGroupApi apiInstance = new SpecGroupApi();
SpecGroup specGroup = new SpecGroup(); // SpecGroup |  nesnesi
try {
    SpecGroup result = apiInstance.specGroupsPost(specGroup);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecGroupApi#specGroupsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specGroup** | [**SpecGroup**](SpecGroup.md)|  nesnesi |

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

