
# PaymentGatewaySetting

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ödeme kanalı ayarı nesnesi kimlik değeri. |  [optional]
**varKey** | **String** | Ödeme kanalı ayarı nesnesi için değişken anahtarı. | 
**varValue** | **String** | Ödeme kanalı ayarı nesnesi için değişken değeri. | 
**paymentGateway** | [**PaymentGateway**](PaymentGateway.md) |  |  [optional]



