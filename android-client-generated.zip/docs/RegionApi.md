# RegionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**regionsGet**](RegionApi.md#regionsGet) | **GET** /regions | Bölge Listesi Alma
[**regionsIdGet**](RegionApi.md#regionsIdGet) | **GET** /regions/{id} | Bölge Alma


<a name="regionsGet"></a>
# **regionsGet**
> Region regionsGet(sort, limit, page, sinceId, ids, name)

Bölge Listesi Alma

Bölge listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.RegionApi;

RegionApi apiInstance = new RegionApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String name = "name_example"; // String | Bölge adı
try {
    Region result = apiInstance.regionsGet(sort, limit, page, sinceId, ids, name);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RegionApi#regionsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **name** | **String**| Bölge adı | [optional]

### Return type

[**Region**](Region.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="regionsIdGet"></a>
# **regionsIdGet**
> Region regionsIdGet(id)

Bölge Alma

İlgili Bölgeyi getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.RegionApi;

RegionApi apiInstance = new RegionApi();
Integer id = 56; // Integer | Bölge nesnesinin id değeri
try {
    Region result = apiInstance.regionsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling RegionApi#regionsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Bölge nesnesinin id değeri |

### Return type

[**Region**](Region.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

