# ShippingAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shippingAddressesGet**](ShippingAddressApi.md#shippingAddressesGet) | **GET** /shipping_addresses | Teslimat Adresi Listesi Alma
[**shippingAddressesIdGet**](ShippingAddressApi.md#shippingAddressesIdGet) | **GET** /shipping_addresses/{id} | Teslimat Adresi Alma
[**shippingAddressesIdPut**](ShippingAddressApi.md#shippingAddressesIdPut) | **PUT** /shipping_addresses/{id} | Teslimat Adresi Güncelleme
[**shippingAddressesPost**](ShippingAddressApi.md#shippingAddressesPost) | **POST** /shipping_addresses | Teslimat Adresi Oluşturma


<a name="shippingAddressesGet"></a>
# **shippingAddressesGet**
> ShippingAddress shippingAddressesGet(sort, limit, page, sinceId, order, startDate, endDate, startUpdatedAt, endUpdatedAt)

Teslimat Adresi Listesi Alma

Teslimat Adresi listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.ShippingAddressApi;

ShippingAddressApi apiInstance = new ShippingAddressApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
Integer order = 56; // Integer | Sipariş id
Date startDate = new Date(); // Date | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
Date startUpdatedAt = new Date(); // Date | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
try {
    ShippingAddress result = apiInstance.shippingAddressesGet(sort, limit, page, sinceId, order, startDate, endDate, startUpdatedAt, endUpdatedAt);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingAddressApi#shippingAddressesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **order** | **Integer**| Sipariş id | [optional]
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingAddressesIdGet"></a>
# **shippingAddressesIdGet**
> ShippingAddress shippingAddressesIdGet(id)

Teslimat Adresi Alma

İlgili Teslimat Adresi getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.ShippingAddressApi;

ShippingAddressApi apiInstance = new ShippingAddressApi();
Integer id = 56; // Integer | Teslimat Adresi nesnesinin id değeri
try {
    ShippingAddress result = apiInstance.shippingAddressesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingAddressApi#shippingAddressesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Teslimat Adresi nesnesinin id değeri |

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingAddressesIdPut"></a>
# **shippingAddressesIdPut**
> ShippingAddress shippingAddressesIdPut(id, shippingAddress)

Teslimat Adresi Güncelleme

İlgili Teslimat Adresi günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.ShippingAddressApi;

ShippingAddressApi apiInstance = new ShippingAddressApi();
Integer id = 56; // Integer | Teslimat Adresi nesnesinin id değeri
ShippingAddress shippingAddress = new ShippingAddress(); // ShippingAddress | ShippingAddress nesnesi
try {
    ShippingAddress result = apiInstance.shippingAddressesIdPut(id, shippingAddress);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingAddressApi#shippingAddressesIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Teslimat Adresi nesnesinin id değeri |
 **shippingAddress** | [**ShippingAddress**](ShippingAddress.md)| ShippingAddress nesnesi |

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingAddressesPost"></a>
# **shippingAddressesPost**
> ShippingAddress shippingAddressesPost(shippingAddress)

Teslimat Adresi Oluşturma

Yeni bir Teslimat Adresi oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.ShippingAddressApi;

ShippingAddressApi apiInstance = new ShippingAddressApi();
ShippingAddress shippingAddress = new ShippingAddress(); // ShippingAddress | ShippingAddress nesnesi
try {
    ShippingAddress result = apiInstance.shippingAddressesPost(shippingAddress);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingAddressApi#shippingAddressesPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shippingAddress** | [**ShippingAddress**](ShippingAddress.md)| ShippingAddress nesnesi |

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

