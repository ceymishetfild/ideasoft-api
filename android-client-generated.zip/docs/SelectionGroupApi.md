# SelectionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selectionGroupsGet**](SelectionGroupApi.md#selectionGroupsGet) | **GET** /selection_groups | Ek Özellik Grubu Listesi Alma
[**selectionGroupsIdDelete**](SelectionGroupApi.md#selectionGroupsIdDelete) | **DELETE** /selection_groups/{id} | Ek Özellik Grubu Silme
[**selectionGroupsIdGet**](SelectionGroupApi.md#selectionGroupsIdGet) | **GET** /selection_groups/{id} | Ek Özellik Grubu Alma
[**selectionGroupsIdPut**](SelectionGroupApi.md#selectionGroupsIdPut) | **PUT** /selection_groups/{id} | Ek Özellik Grubu Güncelleme
[**selectionGroupsPost**](SelectionGroupApi.md#selectionGroupsPost) | **POST** /selection_groups | Ek Özellik Grubu Oluşturma


<a name="selectionGroupsGet"></a>
# **selectionGroupsGet**
> SelectionGroup selectionGroupsGet(sort, limit, page, sinceId, ids, title)

Ek Özellik Grubu Listesi Alma

Ek Özellik Grubu listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.SelectionGroupApi;

SelectionGroupApi apiInstance = new SelectionGroupApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String title = "title_example"; // String | Ek Özellik Grubu başlığı
try {
    SelectionGroup result = apiInstance.selectionGroupsGet(sort, limit, page, sinceId, ids, title);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SelectionGroupApi#selectionGroupsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **title** | **String**| Ek Özellik Grubu başlığı | [optional]

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionGroupsIdDelete"></a>
# **selectionGroupsIdDelete**
> selectionGroupsIdDelete(id)

Ek Özellik Grubu Silme

Kalıcı olarak ilgili Ek Özellik Grubunu siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.SelectionGroupApi;

SelectionGroupApi apiInstance = new SelectionGroupApi();
Integer id = 56; // Integer | Ek Özellik Grubu nesnesinin id değeri
try {
    apiInstance.selectionGroupsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling SelectionGroupApi#selectionGroupsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Özellik Grubu nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionGroupsIdGet"></a>
# **selectionGroupsIdGet**
> SelectionGroup selectionGroupsIdGet(id)

Ek Özellik Grubu Alma

İlgili Ek Özellik Grubunu getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.SelectionGroupApi;

SelectionGroupApi apiInstance = new SelectionGroupApi();
Integer id = 56; // Integer | Ek Özellik Grubu nesnesinin id değeri
try {
    SelectionGroup result = apiInstance.selectionGroupsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SelectionGroupApi#selectionGroupsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Özellik Grubu nesnesinin id değeri |

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionGroupsIdPut"></a>
# **selectionGroupsIdPut**
> SelectionGroup selectionGroupsIdPut(id, selectionGroup)

Ek Özellik Grubu Güncelleme

İlgili Ek Özellik Grubunu günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.SelectionGroupApi;

SelectionGroupApi apiInstance = new SelectionGroupApi();
Integer id = 56; // Integer | Ek Özellik Grubu nesnesinin id değeri
SelectionGroup selectionGroup = new SelectionGroup(); // SelectionGroup |  nesnesi
try {
    SelectionGroup result = apiInstance.selectionGroupsIdPut(id, selectionGroup);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SelectionGroupApi#selectionGroupsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Özellik Grubu nesnesinin id değeri |
 **selectionGroup** | [**SelectionGroup**](SelectionGroup.md)|  nesnesi |

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionGroupsPost"></a>
# **selectionGroupsPost**
> SelectionGroup selectionGroupsPost(selectionGroup)

Ek Özellik Grubu Oluşturma

Yeni bir Ek Özellik Grubu oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.SelectionGroupApi;

SelectionGroupApi apiInstance = new SelectionGroupApi();
SelectionGroup selectionGroup = new SelectionGroup(); // SelectionGroup |  nesnesi
try {
    SelectionGroup result = apiInstance.selectionGroupsPost(selectionGroup);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SelectionGroupApi#selectionGroupsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selectionGroup** | [**SelectionGroup**](SelectionGroup.md)|  nesnesi |

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

