# FavouritedProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**favouritedProductsGet**](FavouritedProductApi.md#favouritedProductsGet) | **GET** /favourited_products | Favori Ürün Listesi Alma
[**favouritedProductsIdDelete**](FavouritedProductApi.md#favouritedProductsIdDelete) | **DELETE** /favourited_products/{id} | Favori Ürün Silme
[**favouritedProductsIdGet**](FavouritedProductApi.md#favouritedProductsIdGet) | **GET** /favourited_products/{id} | Favori Ürün Alma
[**favouritedProductsIdPut**](FavouritedProductApi.md#favouritedProductsIdPut) | **PUT** /favourited_products/{id} | Favori Ürün Güncelleme
[**favouritedProductsPost**](FavouritedProductApi.md#favouritedProductsPost) | **POST** /favourited_products | Favori Ürün Oluşturma


<a name="favouritedProductsGet"></a>
# **favouritedProductsGet**
> FavouritedProduct favouritedProductsGet(sort, limit, page, sinceId, ids, product)

Favori Ürün Listesi Alma

Favori Ürün listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.FavouritedProductApi;

FavouritedProductApi apiInstance = new FavouritedProductApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
Integer product = 56; // Integer | Ürün id
try {
    FavouritedProduct result = apiInstance.favouritedProductsGet(sort, limit, page, sinceId, ids, product);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling FavouritedProductApi#favouritedProductsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **product** | **Integer**| Ürün id | [optional]

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="favouritedProductsIdDelete"></a>
# **favouritedProductsIdDelete**
> favouritedProductsIdDelete(id)

Favori Ürün Silme

Kalıcı olarak ilgili Favori Ürünü siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.FavouritedProductApi;

FavouritedProductApi apiInstance = new FavouritedProductApi();
Integer id = 56; // Integer | Favori Ürün nesnesinin id değeri
try {
    apiInstance.favouritedProductsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling FavouritedProductApi#favouritedProductsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Favori Ürün nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="favouritedProductsIdGet"></a>
# **favouritedProductsIdGet**
> FavouritedProduct favouritedProductsIdGet(id)

Favori Ürün Alma

İlgili Favori Ürünü getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.FavouritedProductApi;

FavouritedProductApi apiInstance = new FavouritedProductApi();
Integer id = 56; // Integer | Favori Ürün nesnesinin id değeri
try {
    FavouritedProduct result = apiInstance.favouritedProductsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling FavouritedProductApi#favouritedProductsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Favori Ürün nesnesinin id değeri |

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="favouritedProductsIdPut"></a>
# **favouritedProductsIdPut**
> FavouritedProduct favouritedProductsIdPut(id, favouritedProduct)

Favori Ürün Güncelleme

İlgili Favori Ürünü günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.FavouritedProductApi;

FavouritedProductApi apiInstance = new FavouritedProductApi();
Integer id = 56; // Integer | Favori Ürün nesnesinin id değeri
FavouritedProduct favouritedProduct = new FavouritedProduct(); // FavouritedProduct |  nesnesi
try {
    FavouritedProduct result = apiInstance.favouritedProductsIdPut(id, favouritedProduct);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling FavouritedProductApi#favouritedProductsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Favori Ürün nesnesinin id değeri |
 **favouritedProduct** | [**FavouritedProduct**](FavouritedProduct.md)|  nesnesi |

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="favouritedProductsPost"></a>
# **favouritedProductsPost**
> FavouritedProduct favouritedProductsPost(favouritedProduct)

Favori Ürün Oluşturma

Yeni bir Favori Ürün oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.FavouritedProductApi;

FavouritedProductApi apiInstance = new FavouritedProductApi();
FavouritedProduct favouritedProduct = new FavouritedProduct(); // FavouritedProduct |  nesnesi
try {
    FavouritedProduct result = apiInstance.favouritedProductsPost(favouritedProduct);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling FavouritedProductApi#favouritedProductsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **favouritedProduct** | [**FavouritedProduct**](FavouritedProduct.md)|  nesnesi |

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

