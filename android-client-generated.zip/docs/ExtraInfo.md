
# ExtraInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ek bilgi nesnesi kimlik değeri. |  [optional]
**name** | **String** | Ek bilgi nesnesi için isim değeri. | 
**sortOrder** | **Integer** | Ek bilgi nesnesi için sıralama değeri. |  [optional]



