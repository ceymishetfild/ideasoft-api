# TownApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**townsGet**](TownApi.md#townsGet) | **GET** /towns | İlçe Listesi Alma
[**townsIdDelete**](TownApi.md#townsIdDelete) | **DELETE** /towns/{id} | İlçe Silme
[**townsIdGet**](TownApi.md#townsIdGet) | **GET** /towns/{id} | İlçe Alma
[**townsIdPut**](TownApi.md#townsIdPut) | **PUT** /towns/{id} | İlçe Güncelleme
[**townsPost**](TownApi.md#townsPost) | **POST** /towns | İlçe Oluşturma


<a name="townsGet"></a>
# **townsGet**
> Town townsGet(sort, limit, page, sinceId, location, townGroup, name, status)

İlçe Listesi Alma

İlçe listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.TownApi;

TownApi apiInstance = new TownApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
Integer location = 56; // Integer | Şehir id
Integer townGroup = 56; // Integer | İlçe grubu id
String name = "name_example"; // String | İlçe adı.
String status = "status_example"; // String | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
try {
    Town result = apiInstance.townsGet(sort, limit, page, sinceId, location, townGroup, name, status);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TownApi#townsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **location** | **Integer**| Şehir id | [optional]
 **townGroup** | **Integer**| İlçe grubu id | [optional]
 **name** | **String**| İlçe adı. | [optional]
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] [enum: 0, 1]

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townsIdDelete"></a>
# **townsIdDelete**
> townsIdDelete(id)

İlçe Silme

Kalıcı olarak ilgili İlçeyi siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.TownApi;

TownApi apiInstance = new TownApi();
Integer id = 56; // Integer | İlçe nesnesinin id değeri
try {
    apiInstance.townsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling TownApi#townsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| İlçe nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townsIdGet"></a>
# **townsIdGet**
> Town townsIdGet(id)

İlçe Alma

İlgili İlçeyi getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.TownApi;

TownApi apiInstance = new TownApi();
Integer id = 56; // Integer | İlçe nesnesinin id değeri
try {
    Town result = apiInstance.townsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TownApi#townsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| İlçe nesnesinin id değeri |

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townsIdPut"></a>
# **townsIdPut**
> Town townsIdPut(id, town)

İlçe Güncelleme

İlgili İlçeyi günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.TownApi;

TownApi apiInstance = new TownApi();
Integer id = 56; // Integer | İlçe nesnesinin id değeri
Town town = new Town(); // Town | Town nesnesi
try {
    Town result = apiInstance.townsIdPut(id, town);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TownApi#townsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| İlçe nesnesinin id değeri |
 **town** | [**Town**](Town.md)| Town nesnesi |

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townsPost"></a>
# **townsPost**
> Town townsPost(town)

İlçe Oluşturma

Yeni bir İlçe oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.TownApi;

TownApi apiInstance = new TownApi();
Town town = new Town(); // Town | Town nesnesi
try {
    Town result = apiInstance.townsPost(town);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TownApi#townsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **town** | [**Town**](Town.md)| Town nesnesi |

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

