# SpecNameApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specNamesGet**](SpecNameApi.md#specNamesGet) | **GET** /spec_names | Ürün Özelliği Listesi Alma
[**specNamesIdDelete**](SpecNameApi.md#specNamesIdDelete) | **DELETE** /spec_names/{id} | Ürün Özelliği Silme
[**specNamesIdGet**](SpecNameApi.md#specNamesIdGet) | **GET** /spec_names/{id} | Ürün Özelliği Alma
[**specNamesIdPut**](SpecNameApi.md#specNamesIdPut) | **PUT** /spec_names/{id} | Ürün Özelliği Güncelleme
[**specNamesPost**](SpecNameApi.md#specNamesPost) | **POST** /spec_names | Ürün Özelliği Oluşturma


<a name="specNamesGet"></a>
# **specNamesGet**
> SpecName specNamesGet(sort, limit, page, sinceId, name, specGroup, choiceType)

Ürün Özelliği Listesi Alma

Ürün Özelliği listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.SpecNameApi;

SpecNameApi apiInstance = new SpecNameApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String name = "name_example"; // String | Ürün Özelliği adı
Integer specGroup = 56; // Integer | Ürün özellik grubu id
String choiceType = "choiceType_example"; // String | Status şu değerleri alabilir: <br><code>singular</code> : Tekil<br><code>plural</code> : Çoğul
try {
    SpecName result = apiInstance.specNamesGet(sort, limit, page, sinceId, name, specGroup, choiceType);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecNameApi#specNamesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **name** | **String**| Ürün Özelliği adı | [optional]
 **specGroup** | **Integer**| Ürün özellik grubu id | [optional]
 **choiceType** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul | [optional] [enum: singular, plural]

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specNamesIdDelete"></a>
# **specNamesIdDelete**
> specNamesIdDelete(id)

Ürün Özelliği Silme

Kalıcı olarak ilgili Ürün Özelliğini siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.SpecNameApi;

SpecNameApi apiInstance = new SpecNameApi();
Integer id = 56; // Integer | Ürün Özellik nesnesinin id değeri
try {
    apiInstance.specNamesIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecNameApi#specNamesIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specNamesIdGet"></a>
# **specNamesIdGet**
> SpecName specNamesIdGet(id)

Ürün Özelliği Alma

İlgili Ürün Özelliğini getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.SpecNameApi;

SpecNameApi apiInstance = new SpecNameApi();
Integer id = 56; // Integer | Ürün Özellik nesnesinin id değeri
try {
    SpecName result = apiInstance.specNamesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecNameApi#specNamesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik nesnesinin id değeri |

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specNamesIdPut"></a>
# **specNamesIdPut**
> SpecName specNamesIdPut(id, specName)

Ürün Özelliği Güncelleme

İlgili Ürün Özelliğini günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.SpecNameApi;

SpecNameApi apiInstance = new SpecNameApi();
Integer id = 56; // Integer | Ürün Özellik nesnesinin id değeri
SpecName specName = new SpecName(); // SpecName | SpecName nesnesi
try {
    SpecName result = apiInstance.specNamesIdPut(id, specName);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecNameApi#specNamesIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik nesnesinin id değeri |
 **specName** | [**SpecName**](SpecName.md)| SpecName nesnesi |

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specNamesPost"></a>
# **specNamesPost**
> SpecName specNamesPost(specName)

Ürün Özelliği Oluşturma

Yeni bir Ürün Özelliği oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.SpecNameApi;

SpecNameApi apiInstance = new SpecNameApi();
SpecName specName = new SpecName(); // SpecName | SpecName nesnesi
try {
    SpecName result = apiInstance.specNamesPost(specName);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecNameApi#specNamesPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specName** | [**SpecName**](SpecName.md)| SpecName nesnesi |

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

