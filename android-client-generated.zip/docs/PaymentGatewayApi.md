# PaymentGatewayApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**paymentGatewaysGet**](PaymentGatewayApi.md#paymentGatewaysGet) | **GET** /payment_gateways | Ödeme Kanalı Listesi Alma
[**paymentGatewaysIdGet**](PaymentGatewayApi.md#paymentGatewaysIdGet) | **GET** /payment_gateways/{id} | Ödeme Kanalı Alma


<a name="paymentGatewaysGet"></a>
# **paymentGatewaysGet**
> PaymentGateway paymentGatewaysGet(sort, limit, page, sinceId, code, name)

Ödeme Kanalı Listesi Alma

Ödeme Kanalı listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.PaymentGatewayApi;

PaymentGatewayApi apiInstance = new PaymentGatewayApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String code = "code_example"; // String | Ödeme kanalı notu
String name = "name_example"; // String | Ödeme kanalı adı
try {
    PaymentGateway result = apiInstance.paymentGatewaysGet(sort, limit, page, sinceId, code, name);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PaymentGatewayApi#paymentGatewaysGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **code** | **String**| Ödeme kanalı notu | [optional]
 **name** | **String**| Ödeme kanalı adı | [optional]

### Return type

[**PaymentGateway**](PaymentGateway.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="paymentGatewaysIdGet"></a>
# **paymentGatewaysIdGet**
> PaymentGateway paymentGatewaysIdGet(id)

Ödeme Kanalı Alma

İlgili Ödeme Kanalını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.PaymentGatewayApi;

PaymentGatewayApi apiInstance = new PaymentGatewayApi();
Integer id = 56; // Integer | Ödeme Kanalı nesnesinin id değeri
try {
    PaymentGateway result = apiInstance.paymentGatewaysIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PaymentGatewayApi#paymentGatewaysIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ödeme Kanalı nesnesinin id değeri |

### Return type

[**PaymentGateway**](PaymentGateway.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

