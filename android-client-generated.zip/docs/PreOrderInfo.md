
# PreOrderInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sipariş öncesi bilgisi nesnesi kimlik değeri. |  [optional]
**sessionId** | **String** | Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri. | 
**customerFirstname** | **String** | Müşterinin ismi. |  [optional]
**customerSurname** | **String** | Müşterinin soy ismi. |  [optional]
**customerEmail** | **String** | Müşterinin e-mail adresi. |  [optional]
**shippingFirstname** | **String** | Teslimat yapılacak kişinin ismi. | 
**shippingSurname** | **String** | Teslimat yapılacak kişinin soy ismi. | 
**shippingAddress** | **String** | Teslimat adresi bilgileri. | 
**shippingPhoneNumber** | **String** | Teslimat yapılacak kişinin telefon numarası. | 
**shippingMobilePhoneNumber** | **String** | Teslimat yapılacak kişinin mobil telefon numarası. | 
**shippingLocationName** | **String** | Teslimat şehri. | 
**shippingTown** | **String** | Teslimat ilçesi. | 
**differentBillingAddress** | [**DifferentBillingAddressEnum**](#DifferentBillingAddressEnum) | Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yok&lt;br&gt;&lt;/div&gt; |  [optional]
**billingFirstname** | **String** | Fatura kesilen kişinin ismi. | 
**billingSurname** | **String** | Fatura kesilen kişinin soy ismi. | 
**billingAddress** | **String** | Fatura adresi bilgileri. | 
**billingPhoneNumber** | **String** | Fatura kesilen kişinin telefon numarası. | 
**billingMobilePhoneNumber** | **String** | Fatura kesilen kişinin mobil telefon numarası. | 
**billingLocationName** | **String** | Fatura adresi şehri | 
**billingTown** | **String** | Fatura adresi ilçesi. | 
**billingInvoiceType** | [**BillingInvoiceTypeEnum**](#BillingInvoiceTypeEnum) | Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt; | 
**billingIdentityRegistrationNumber** | **String** | Fatura kesilen kişinin TC kimlik numarası. |  [optional]
**billingTaxOffice** | **String** | Fatura kesilen kişi/kurumun vergi dairesi. |  [optional]
**billingTaxNo** | **String** | Fatura kesilen kişi/kurum vergi numarası. |  [optional]
**isEinvoiceUser** | [**IsEinvoiceUserEnum**](#IsEinvoiceUserEnum) | Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; |  [optional]
**useGiftPackage** | [**UseGiftPackageEnum**](#UseGiftPackageEnum) | Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; |  [optional]
**giftNote** | **String** | Hediye notu bilgisi. |  [optional]
**imageFile** | **String** | Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif |  [optional]
**deliveryDate** | [**Date**](Date.md) | Müşterinin teslimatın gerçekleşmisini istediği tarih. |  [optional]
**deliveryTime** | **String** | API bu değeri otomatik oluşturur. |  [optional]
**createdAt** | [**Date**](Date.md) | Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı. |  [optional]
**updatedAt** | [**Date**](Date.md) | Sipariş öncesi bilgisi nesnesinin güncellenme zamanı. |  [optional]
**billingCountry** | [**Country**](Country.md) |  |  [optional]
**billingLocation** | [**Location**](Location.md) |  |  [optional]
**shippingCompany** | [**ShippingCompany**](ShippingCompany.md) |  |  [optional]
**shippingCountry** | [**Country**](Country.md) |  |  [optional]
**shippingLocation** | [**Location**](Location.md) |  |  [optional]
**memberShippingAddress** | [**MemberAddress**](MemberAddress.md) |  |  [optional]
**memberBillingAddress** | [**MemberAddress**](MemberAddress.md) |  |  [optional]


<a name="DifferentBillingAddressEnum"></a>
## Enum: DifferentBillingAddressEnum
Name | Value
---- | -----


<a name="BillingInvoiceTypeEnum"></a>
## Enum: BillingInvoiceTypeEnum
Name | Value
---- | -----


<a name="IsEinvoiceUserEnum"></a>
## Enum: IsEinvoiceUserEnum
Name | Value
---- | -----


<a name="UseGiftPackageEnum"></a>
## Enum: UseGiftPackageEnum
Name | Value
---- | -----



