# CategoryApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**categoriesGet**](CategoryApi.md#categoriesGet) | **GET** /categories | Kategori Listesi Alma
[**categoriesIdDelete**](CategoryApi.md#categoriesIdDelete) | **DELETE** /categories/{id} | Kategori Silme
[**categoriesIdGet**](CategoryApi.md#categoriesIdGet) | **GET** /categories/{id} | Kategori Alma
[**categoriesIdPut**](CategoryApi.md#categoriesIdPut) | **PUT** /categories/{id} | Kategori Güncelleme
[**categoriesPost**](CategoryApi.md#categoriesPost) | **POST** /categories | Kategori Oluşturma


<a name="categoriesGet"></a>
# **categoriesGet**
> Category categoriesGet(sort, limit, page, sinceId, name, status, distributor, parent, startDate, endDate, startUpdatedAt, endUpdatedAt)

Kategori Listesi Alma

Kategori listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.CategoryApi;

CategoryApi apiInstance = new CategoryApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String name = "name_example"; // String | Kategori adı
Integer status = 56; // Integer | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
String distributor = "distributor_example"; // String | Kategori Distribütör
Integer parent = 56; // Integer | Üst kategori id
Date startDate = new Date(); // Date | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
Date startUpdatedAt = new Date(); // Date | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
try {
    Category result = apiInstance.categoriesGet(sort, limit, page, sinceId, name, status, distributor, parent, startDate, endDate, startUpdatedAt, endUpdatedAt);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CategoryApi#categoriesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **name** | **String**| Kategori adı | [optional]
 **status** | **Integer**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] [enum: 0, 1]
 **distributor** | **String**| Kategori Distribütör | [optional]
 **parent** | **Integer**| Üst kategori id | [optional]
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**Category**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="categoriesIdDelete"></a>
# **categoriesIdDelete**
> categoriesIdDelete(id)

Kategori Silme

Kalıcı olarak ilgili Kategoriyi siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.CategoryApi;

CategoryApi apiInstance = new CategoryApi();
Integer id = 56; // Integer | Kategori nesnesinin id değeri
try {
    apiInstance.categoriesIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling CategoryApi#categoriesIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kategori nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="categoriesIdGet"></a>
# **categoriesIdGet**
> Category categoriesIdGet(id)

Kategori Alma

İlgili Kategoriyi getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.CategoryApi;

CategoryApi apiInstance = new CategoryApi();
Integer id = 56; // Integer | Kategori nesnesinin id değeri
try {
    Category result = apiInstance.categoriesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CategoryApi#categoriesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kategori nesnesinin id değeri |

### Return type

[**Category**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="categoriesIdPut"></a>
# **categoriesIdPut**
> Category categoriesIdPut(id, category)

Kategori Güncelleme

İlgili Kategoriyi günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.CategoryApi;

CategoryApi apiInstance = new CategoryApi();
Integer id = 56; // Integer | Kategori nesnesinin id değeri
Category category = new Category(); // Category | Category nesnesi
try {
    Category result = apiInstance.categoriesIdPut(id, category);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CategoryApi#categoriesIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kategori nesnesinin id değeri |
 **category** | [**Category**](Category.md)| Category nesnesi |

### Return type

[**Category**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="categoriesPost"></a>
# **categoriesPost**
> Category categoriesPost(category)

Kategori Oluşturma

Yeni bir Kategori oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.CategoryApi;

CategoryApi apiInstance = new CategoryApi();
Category category = new Category(); // Category | Category nesnesi
try {
    Category result = apiInstance.categoriesPost(category);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CategoryApi#categoriesPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **category** | [**Category**](Category.md)| Category nesnesi |

### Return type

[**Category**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

