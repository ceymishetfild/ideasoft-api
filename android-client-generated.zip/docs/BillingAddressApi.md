# BillingAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**billingAddressesGet**](BillingAddressApi.md#billingAddressesGet) | **GET** /billing_addresses | Fatura Adresi Listesi Alma
[**billingAddressesIdGet**](BillingAddressApi.md#billingAddressesIdGet) | **GET** /billing_addresses/{id} | Fatura Adresi Alma
[**billingAddressesIdPut**](BillingAddressApi.md#billingAddressesIdPut) | **PUT** /billing_addresses/{id} | Fatura Adresi Güncelleme
[**billingAddressesPost**](BillingAddressApi.md#billingAddressesPost) | **POST** /billing_addresses | Fatura Adresi Oluşturma


<a name="billingAddressesGet"></a>
# **billingAddressesGet**
> BillingAddress billingAddressesGet(sort, limit, page, sinceId, order, startDate, endDate, startUpdatedAt, endUpdatedAt)

Fatura Adresi Listesi Alma

Fatura Adresi listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.BillingAddressApi;

BillingAddressApi apiInstance = new BillingAddressApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
Integer order = 56; // Integer | Sipariş id
Date startDate = new Date(); // Date | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
Date startUpdatedAt = new Date(); // Date | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
try {
    BillingAddress result = apiInstance.billingAddressesGet(sort, limit, page, sinceId, order, startDate, endDate, startUpdatedAt, endUpdatedAt);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BillingAddressApi#billingAddressesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **order** | **Integer**| Sipariş id | [optional]
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="billingAddressesIdGet"></a>
# **billingAddressesIdGet**
> BillingAddress billingAddressesIdGet(id)

Fatura Adresi Alma

İlgili Fatura Adresini getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.BillingAddressApi;

BillingAddressApi apiInstance = new BillingAddressApi();
Integer id = 56; // Integer | Fatura Adresi nesnesinin id değeri
try {
    BillingAddress result = apiInstance.billingAddressesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BillingAddressApi#billingAddressesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Fatura Adresi nesnesinin id değeri |

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="billingAddressesIdPut"></a>
# **billingAddressesIdPut**
> BillingAddress billingAddressesIdPut(id, billingAddress)

Fatura Adresi Güncelleme

İlgili Fatura Adresini günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.BillingAddressApi;

BillingAddressApi apiInstance = new BillingAddressApi();
Integer id = 56; // Integer | Fatura Adresi nesnesinin id değeri
BillingAddress billingAddress = new BillingAddress(); // BillingAddress | BillingAddress nesnesi
try {
    BillingAddress result = apiInstance.billingAddressesIdPut(id, billingAddress);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BillingAddressApi#billingAddressesIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Fatura Adresi nesnesinin id değeri |
 **billingAddress** | [**BillingAddress**](BillingAddress.md)| BillingAddress nesnesi |

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="billingAddressesPost"></a>
# **billingAddressesPost**
> BillingAddress billingAddressesPost(billingAddress)

Fatura Adresi Oluşturma

Yeni bir Fatura Adresi oluşturur. Fatura Adresi oluşturabilmek için geçerli bir önceden tanımlanmış Sipariş id değerine ihtiyaç vardır.

### Example
```java
// Import classes:
//import io.swagger.client.api.BillingAddressApi;

BillingAddressApi apiInstance = new BillingAddressApi();
BillingAddress billingAddress = new BillingAddress(); // BillingAddress | BillingAddress nesnesi
try {
    BillingAddress result = apiInstance.billingAddressesPost(billingAddress);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BillingAddressApi#billingAddressesPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **billingAddress** | [**BillingAddress**](BillingAddress.md)| BillingAddress nesnesi |

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

