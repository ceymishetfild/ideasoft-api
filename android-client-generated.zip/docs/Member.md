
# Member

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Üye nesnesi kimlik değeri. |  [optional]
**firstname** | **String** | Üyenin ismi. | 
**surname** | **String** | Üyenin soy ismi. | 
**email** | **String** | Üyenin e-mail adresi. | 
**gender** | [**GenderEnum**](#GenderEnum) | Üyenin cinsiyet bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın&lt;br&gt;&lt;/div&gt; |  [optional]
**birthDate** | [**Date**](Date.md) | Üyenin doğum tarihi. |  [optional]
**phoneNumber** | **String** | Üyenin telefon numarası. |  [optional]
**mobilePhoneNumber** | **String** | Üyenin mobil telefon numarası. |  [optional]
**otherLocation** | **String** | Üyenin diğer şehir bilgileri. |  [optional]
**address** | **String** | Üyenin adres bilgileri. |  [optional]
**taxNumber** | **String** | Üyenin vergi numarası. |  [optional]
**tcId** | **String** | Üyenin TC kimlik numarası. |  [optional]
**status** | [**StatusEnum**](#StatusEnum) | Üyenin durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;queue&lt;/code&gt; : Sırada&lt;br&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;suspended&lt;/code&gt; : Askıda&lt;br&gt;&lt;/div&gt; | 
**lastLoginDate** | [**Date**](Date.md) | Üyenin son giriş yaptığı tarih. |  [optional]
**createdAt** | [**Date**](Date.md) | Üye nesnesinin oluşturulma zamanı. |  [optional]
**updatedAt** | [**Date**](Date.md) | Üye nesnesinin güncellenme zamanı. |  [optional]
**zipCode** | **String** | Üyenin posta kodu. |  [optional]
**commercialName** | **String** | Üyenin kurumsal adı. |  [optional]
**taxOffice** | **String** | Üyenin vergi dairesi. |  [optional]
**lastMailSentDate** | [**Date**](Date.md) | Üyeye gönderilen son e-mail tarihi. |  [optional]
**lastIp** | **String** | Üyenin en son giriş yaptığı IP adresi. |  [optional]
**gainedPointAmount** | **Float** | Üyenin kazandığı puan tutarı. |  [optional]
**spentPointAmount** | **Float** | Üyenin harcadığı puan tutarı. |  [optional]
**allowedToCampaigns** | [**AllowedToCampaignsEnum**](#AllowedToCampaignsEnum) | Üyenin kampanyalara katılım için izin durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalar için izinli.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalar için izinsiz.&lt;br&gt;&lt;/div&gt; |  [optional]
**referredMemberGainedPointAmount** | **Float** | Üyenin tavsiye ettiği kişilerden dolayı kazandığı puan. |  [optional]
**district** | **String** | Üyenin ilçesi. |  [optional]
**deviceType** | **String** | Üyenin kullandığı cihaz tipi. | 
**deviceInfo** | **String** | Üyenin kullandığı cihaz bilgisi. |  [optional]
**country** | [**Country**](Country.md) |  |  [optional]
**location** | [**Location**](Location.md) |  |  [optional]
**memberGroup** | [**MemberGroup**](MemberGroup.md) |  |  [optional]
**referredMember** | [**Member**](Member.md) |  |  [optional]


<a name="GenderEnum"></a>
## Enum: GenderEnum
Name | Value
---- | -----


<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----


<a name="AllowedToCampaignsEnum"></a>
## Enum: AllowedToCampaignsEnum
Name | Value
---- | -----



