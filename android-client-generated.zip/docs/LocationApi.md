# LocationApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**locationsGet**](LocationApi.md#locationsGet) | **GET** /locations | Şehir Listesi Alma
[**locationsIdGet**](LocationApi.md#locationsIdGet) | **GET** /locations/{id} | Şehir Alma


<a name="locationsGet"></a>
# **locationsGet**
> Location locationsGet(sort, limit, page, sinceId, name, country, region)

Şehir Listesi Alma

Şehir listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.LocationApi;

LocationApi apiInstance = new LocationApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String name = "name_example"; // String | Şehir adı
Integer country = 56; // Integer | Ülke id
Integer region = 56; // Integer | Bölge id
try {
    Location result = apiInstance.locationsGet(sort, limit, page, sinceId, name, country, region);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling LocationApi#locationsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **name** | **String**| Şehir adı | [optional]
 **country** | **Integer**| Ülke id | [optional]
 **region** | **Integer**| Bölge id | [optional]

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="locationsIdGet"></a>
# **locationsIdGet**
> Location locationsIdGet(id)

Şehir Alma

İlgili Şehir getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.LocationApi;

LocationApi apiInstance = new LocationApi();
Integer id = 56; // Integer | Şehir nesnesinin id değeri
try {
    Location result = apiInstance.locationsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling LocationApi#locationsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Şehir nesnesinin id değeri |

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

