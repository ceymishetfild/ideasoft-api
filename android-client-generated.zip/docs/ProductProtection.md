
# ProductProtection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Entegrasyon seçeneği nesnesi kimlik değeri. |  [optional]
**isPriceProtected** | [**IsPriceProtectedEnum**](#IsPriceProtectedEnum) | Ürün fiyatının korumalı olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Korumalı.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Korumasız.&lt;br&gt;&lt;/div&gt; |  [optional]
**isStockProtected** | [**IsStockProtectedEnum**](#IsStockProtectedEnum) | Ürün stoğunun korumalı olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Korumalı.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Korumasız.&lt;br&gt;&lt;/div&gt; |  [optional]
**product** | [**Product**](Product.md) |  |  [optional]


<a name="IsPriceProtectedEnum"></a>
## Enum: IsPriceProtectedEnum
Name | Value
---- | -----


<a name="IsStockProtectedEnum"></a>
## Enum: IsStockProtectedEnum
Name | Value
---- | -----



