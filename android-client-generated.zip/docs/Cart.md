
# Cart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sepet nesnesi kimlik değeri. |  [optional]
**sessionId** | **String** | Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri. | 
**locked** | [**LockedEnum**](#LockedEnum) | Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz. |  [optional]
**createdAt** | [**Date**](Date.md) | Sepet nesnesinin oluşturulma zamanı. |  [optional]
**updatedAt** | [**Date**](Date.md) | Sepet nesnesinin güncellenme zamanı. |  [optional]
**chosenPromotion** | [**ShopCampaigns**](ShopCampaigns.md) |  |  [optional]
**member** | [**Member**](Member.md) |  |  [optional]
**chosenToken** | [**ShopTokens**](ShopTokens.md) |  |  [optional]
**items** | [**List&lt;CartItem&gt;**](CartItem.md) | Sepet kalemi nesnelerini barındıran liste. |  [optional]


<a name="LockedEnum"></a>
## Enum: LockedEnum
Name | Value
---- | -----



