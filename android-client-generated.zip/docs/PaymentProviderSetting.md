
# PaymentProviderSetting

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ödeme altyapısı sağlayıcısı ayarı nesnesi kimlik değeri. |  [optional]
**varKey** | **String** | Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken anahtarı. | 
**varValue** | **String** | Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken değeri. | 



