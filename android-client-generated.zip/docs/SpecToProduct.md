
# SpecToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ürün özellik ürün bağı nesnesi kimlik değeri. |  [optional]
**product** | [**Product**](Product.md) | Ürün nesnesi. |  [optional]
**specGroup** | [**SpecGroup**](SpecGroup.md) | Ürün özelliği grubu nesnesi. | 
**specName** | [**SpecName**](SpecName.md) | Ürün özelliği nesnesi. | 
**specValue** | [**SpecValue**](SpecValue.md) | Ürün özellik grubu nesnesi. | 



