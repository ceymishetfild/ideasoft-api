
# CurrentAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Cari hesap nesnesi kimlik değeri. |  [optional]
**code** | **String** | Cari hesap için düzenlenebilir bir kod değeri. |  [optional]
**title** | **String** | Cari hesap nesnesinin başlığı. | 
**balance** | **Float** | Cari hesabın bakiyesi. |  [optional]
**riskLimit** | **Float** | Cari hesap için belirlenmiş risk limiti. |  [optional]
**createdAt** | [**Date**](Date.md) | Cari hesap nesnesinin oluşturulma zamanı. |  [optional]
**updatedAt** | [**Date**](Date.md) | Cari hesap nesnesinin güncellenme zamanı. |  [optional]
**member** | [**Member**](Member.md) |  |  [optional]



