# ShippingCompanyApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shippingCompaniesGet**](ShippingCompanyApi.md#shippingCompaniesGet) | **GET** /shipping_companies | Kargo Firması Listesi Alma
[**shippingCompaniesIdDelete**](ShippingCompanyApi.md#shippingCompaniesIdDelete) | **DELETE** /shipping_companies/{id} | Kargo Firması Silme
[**shippingCompaniesIdGet**](ShippingCompanyApi.md#shippingCompaniesIdGet) | **GET** /shipping_companies/{id} | Kargo Firması Alma
[**shippingCompaniesIdPut**](ShippingCompanyApi.md#shippingCompaniesIdPut) | **PUT** /shipping_companies/{id} | Kargo Firması Güncelleme
[**shippingCompaniesPost**](ShippingCompanyApi.md#shippingCompaniesPost) | **POST** /shipping_companies | Kargo Firması Oluşturma


<a name="shippingCompaniesGet"></a>
# **shippingCompaniesGet**
> ShippingCompany shippingCompaniesGet(sort, limit, page, sinceId, ids, name, companyCode, paymentType, shippingProvider)

Kargo Firması Listesi Alma

Kargo Firması listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.ShippingCompanyApi;

ShippingCompanyApi apiInstance = new ShippingCompanyApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String name = "name_example"; // String | Kargo firması adı
String companyCode = "companyCode_example"; // String | Kargo firması kodu
String paymentType = "paymentType_example"; // String | Ödeme Tipi şu değerleri alabilir: <br><code>cash_on_delivery</code> : Alıcı ödemeli<br><code>standart_delivery</code> : Gönderici ödemeli<br><code>not_applicable</code> : Bu alan için uygulanabilir değil
Integer shippingProvider = 56; // Integer | Teslimat Hizmeti Sağlayıcısı id
try {
    ShippingCompany result = apiInstance.shippingCompaniesGet(sort, limit, page, sinceId, ids, name, companyCode, paymentType, shippingProvider);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingCompanyApi#shippingCompaniesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **name** | **String**| Kargo firması adı | [optional]
 **companyCode** | **String**| Kargo firması kodu | [optional]
 **paymentType** | **String**| Ödeme Tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil | [optional] [enum: cash_on_delivery, standart_delivery, not_applicable]
 **shippingProvider** | **Integer**| Teslimat Hizmeti Sağlayıcısı id | [optional]

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingCompaniesIdDelete"></a>
# **shippingCompaniesIdDelete**
> shippingCompaniesIdDelete(id)

Kargo Firması Silme

Kalıcı olarak ilgili Kargo Firmasını siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.ShippingCompanyApi;

ShippingCompanyApi apiInstance = new ShippingCompanyApi();
Integer id = 56; // Integer | Kargo Firması nesnesinin id değeri
try {
    apiInstance.shippingCompaniesIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingCompanyApi#shippingCompaniesIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kargo Firması nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingCompaniesIdGet"></a>
# **shippingCompaniesIdGet**
> ShippingCompany shippingCompaniesIdGet(id)

Kargo Firması Alma

İlgili Kargo Firmasını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.ShippingCompanyApi;

ShippingCompanyApi apiInstance = new ShippingCompanyApi();
Integer id = 56; // Integer | Kargo Firması nesnesinin id değeri
try {
    ShippingCompany result = apiInstance.shippingCompaniesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingCompanyApi#shippingCompaniesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kargo Firması nesnesinin id değeri |

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingCompaniesIdPut"></a>
# **shippingCompaniesIdPut**
> ShippingCompany shippingCompaniesIdPut(id, shippingCompany)

Kargo Firması Güncelleme

İlgili Kargo Firmasını günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.ShippingCompanyApi;

ShippingCompanyApi apiInstance = new ShippingCompanyApi();
Integer id = 56; // Integer | Kargo Firması nesnesinin id değeri
ShippingCompany shippingCompany = new ShippingCompany(); // ShippingCompany |  nesnesi
try {
    ShippingCompany result = apiInstance.shippingCompaniesIdPut(id, shippingCompany);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingCompanyApi#shippingCompaniesIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kargo Firması nesnesinin id değeri |
 **shippingCompany** | [**ShippingCompany**](ShippingCompany.md)|  nesnesi |

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingCompaniesPost"></a>
# **shippingCompaniesPost**
> ShippingCompany shippingCompaniesPost(shippingCompany)

Kargo Firması Oluşturma

Yeni bir Kargo Firması oluşturur relationship.

### Example
```java
// Import classes:
//import io.swagger.client.api.ShippingCompanyApi;

ShippingCompanyApi apiInstance = new ShippingCompanyApi();
ShippingCompany shippingCompany = new ShippingCompany(); // ShippingCompany |  nesnesi
try {
    ShippingCompany result = apiInstance.shippingCompaniesPost(shippingCompany);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingCompanyApi#shippingCompaniesPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shippingCompany** | [**ShippingCompany**](ShippingCompany.md)|  nesnesi |

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

