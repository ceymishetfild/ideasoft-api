# CurrentAccountApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**currentAccountsGet**](CurrentAccountApi.md#currentAccountsGet) | **GET** /current_accounts | Cari Hesap Listesi Alma
[**currentAccountsIdDelete**](CurrentAccountApi.md#currentAccountsIdDelete) | **DELETE** /current_accounts/{id} | Cari Hesap Silme
[**currentAccountsIdGet**](CurrentAccountApi.md#currentAccountsIdGet) | **GET** /current_accounts/{id} | Cari Hesap Alma
[**currentAccountsIdPut**](CurrentAccountApi.md#currentAccountsIdPut) | **PUT** /current_accounts/{id} | Cari Hesap Güncelleme
[**currentAccountsPost**](CurrentAccountApi.md#currentAccountsPost) | **POST** /current_accounts | Cari Hesap Oluşturma


<a name="currentAccountsGet"></a>
# **currentAccountsGet**
> CurrentAccount currentAccountsGet(sort, limit, page, sinceId, code, title, startDate, endDate, startUpdatedAt, endUpdatedAt, member)

Cari Hesap Listesi Alma

Cari Hesap listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.CurrentAccountApi;

CurrentAccountApi apiInstance = new CurrentAccountApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String code = "code_example"; // String | Cari Hesap kodu
String title = "title_example"; // String | Cari Hesap başlığı
Date startDate = new Date(); // Date | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
Date startUpdatedAt = new Date(); // Date | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
String member = "member_example"; // String | İlgili üye
try {
    CurrentAccount result = apiInstance.currentAccountsGet(sort, limit, page, sinceId, code, title, startDate, endDate, startUpdatedAt, endUpdatedAt, member);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CurrentAccountApi#currentAccountsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **code** | **String**| Cari Hesap kodu | [optional]
 **title** | **String**| Cari Hesap başlığı | [optional]
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]
 **member** | **String**| İlgili üye | [optional]

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="currentAccountsIdDelete"></a>
# **currentAccountsIdDelete**
> currentAccountsIdDelete(id)

Cari Hesap Silme

Kalıcı olarak ilgili Cari Hesabı siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.CurrentAccountApi;

CurrentAccountApi apiInstance = new CurrentAccountApi();
Integer id = 56; // Integer | Cari Hesap nesnesinin id değeri
try {
    apiInstance.currentAccountsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling CurrentAccountApi#currentAccountsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Cari Hesap nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="currentAccountsIdGet"></a>
# **currentAccountsIdGet**
> CurrentAccount currentAccountsIdGet(id)

Cari Hesap Alma

İlgili Cari Hesabı getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.CurrentAccountApi;

CurrentAccountApi apiInstance = new CurrentAccountApi();
Integer id = 56; // Integer | Cari Hesap nesnesinin id değeri
try {
    CurrentAccount result = apiInstance.currentAccountsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CurrentAccountApi#currentAccountsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Cari Hesap nesnesinin id değeri |

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="currentAccountsIdPut"></a>
# **currentAccountsIdPut**
> CurrentAccount currentAccountsIdPut(id, currentAccount)

Cari Hesap Güncelleme

İlgili Cari Hesabı günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.CurrentAccountApi;

CurrentAccountApi apiInstance = new CurrentAccountApi();
Integer id = 56; // Integer | Cari Hesap nesnesinin id değeri
CurrentAccount currentAccount = new CurrentAccount(); // CurrentAccount | CurrentAccount nesnesi
try {
    CurrentAccount result = apiInstance.currentAccountsIdPut(id, currentAccount);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CurrentAccountApi#currentAccountsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Cari Hesap nesnesinin id değeri |
 **currentAccount** | [**CurrentAccount**](CurrentAccount.md)| CurrentAccount nesnesi |

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="currentAccountsPost"></a>
# **currentAccountsPost**
> CurrentAccount currentAccountsPost(currentAccount)

Cari Hesap Oluşturma

Yeni bir Cari Hesap oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.CurrentAccountApi;

CurrentAccountApi apiInstance = new CurrentAccountApi();
CurrentAccount currentAccount = new CurrentAccount(); // CurrentAccount | CurrentAccount nesnesi
try {
    CurrentAccount result = apiInstance.currentAccountsPost(currentAccount);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CurrentAccountApi#currentAccountsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **currentAccount** | [**CurrentAccount**](CurrentAccount.md)| CurrentAccount nesnesi |

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

