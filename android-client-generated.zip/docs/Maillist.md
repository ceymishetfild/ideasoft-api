
# Maillist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Mail listesi nesnesi kimlik değeri. |  [optional]
**name** | **String** | Mail listesi nesnesi için isim değeri. | 
**email** | **String** | Ziyaretçi veya üyenin mail adresi. | 
**lastMailSentDate** | [**Date**](Date.md) | En son e-mail gönderilen zaman. |  [optional]
**creatorIpAddress** | **String** | Mail listesi nesnesini oluşturan kişinin IP adresi. |  [optional]
**createdAt** | [**Date**](Date.md) | Mail listesi nesnesinin oluşturulma zamanı. | 
**updatedAt** | [**Date**](Date.md) | Mail listesi nesnesinin güncellenme zamanı. | 
**maillistGroup** | [**MaillistGroup**](MaillistGroup.md) | Mail listesi grubu nesnesi. | 



