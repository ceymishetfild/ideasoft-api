
# OptionToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Varyant ürün bağı nesnesi kimlik değeri. |  [optional]
**parentProductId** | **Integer** | Ana ürünün benzersiz kimlik değeri. | 
**optionGroup** | [**OptionGroup**](OptionGroup.md) |  |  [optional]
**option** | [**Options**](Options.md) |  |  [optional]
**product** | [**Product**](Product.md) |  |  [optional]



