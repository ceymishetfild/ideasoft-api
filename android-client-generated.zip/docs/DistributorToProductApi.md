# DistributorToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**distributorToProductsGet**](DistributorToProductApi.md#distributorToProductsGet) | **GET** /distributor_to_products | Distribütör Ürün Bağı Listesi Alma
[**distributorToProductsIdDelete**](DistributorToProductApi.md#distributorToProductsIdDelete) | **DELETE** /distributor_to_products/{id} | Distribütör Ürün Bağı Silme
[**distributorToProductsIdGet**](DistributorToProductApi.md#distributorToProductsIdGet) | **GET** /distributor_to_products/{id} | Distribütör Ürün Bağı Alma
[**distributorToProductsIdPut**](DistributorToProductApi.md#distributorToProductsIdPut) | **PUT** /distributor_to_products/{id} | Distribütör Ürün Bağı Güncelleme
[**distributorToProductsPost**](DistributorToProductApi.md#distributorToProductsPost) | **POST** /distributor_to_products | Distribütör Ürün Bağı Oluşturma


<a name="distributorToProductsGet"></a>
# **distributorToProductsGet**
> DistributorToProduct distributorToProductsGet(sort, limit, page, sinceId, ids, distributor, product)

Distribütör Ürün Bağı Listesi Alma

Distribütör Ürün Bağı listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.DistributorToProductApi;

DistributorToProductApi apiInstance = new DistributorToProductApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
Integer distributor = 56; // Integer | Distribütör id
Integer product = 56; // Integer | Ürün id
try {
    DistributorToProduct result = apiInstance.distributorToProductsGet(sort, limit, page, sinceId, ids, distributor, product);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DistributorToProductApi#distributorToProductsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **distributor** | **Integer**| Distribütör id | [optional]
 **product** | **Integer**| Ürün id | [optional]

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorToProductsIdDelete"></a>
# **distributorToProductsIdDelete**
> distributorToProductsIdDelete(id)

Distribütör Ürün Bağı Silme

Kalıcı olarak ilgili Distribütör Ürün Bağını siler

### Example
```java
// Import classes:
//import io.swagger.client.api.DistributorToProductApi;

DistributorToProductApi apiInstance = new DistributorToProductApi();
Integer id = 56; // Integer | Distribütör Ürün Bağı nesnesinin id değeri
try {
    apiInstance.distributorToProductsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling DistributorToProductApi#distributorToProductsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Distribütör Ürün Bağı nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorToProductsIdGet"></a>
# **distributorToProductsIdGet**
> DistributorToProduct distributorToProductsIdGet(id)

Distribütör Ürün Bağı Alma

İlgili Distribütör Ürün Bağını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.DistributorToProductApi;

DistributorToProductApi apiInstance = new DistributorToProductApi();
Integer id = 56; // Integer | Distribütör Ürün Bağı nesnesinin id değeri
try {
    DistributorToProduct result = apiInstance.distributorToProductsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DistributorToProductApi#distributorToProductsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Distribütör Ürün Bağı nesnesinin id değeri |

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorToProductsIdPut"></a>
# **distributorToProductsIdPut**
> DistributorToProduct distributorToProductsIdPut(id, distributorToProduct)

Distribütör Ürün Bağı Güncelleme

İlgili Distribütör Ürün Bağını günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.DistributorToProductApi;

DistributorToProductApi apiInstance = new DistributorToProductApi();
Integer id = 56; // Integer | Distribütör Ürün Bağı nesnesinin id değeri
DistributorToProduct distributorToProduct = new DistributorToProduct(); // DistributorToProduct |  nesnesi
try {
    DistributorToProduct result = apiInstance.distributorToProductsIdPut(id, distributorToProduct);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DistributorToProductApi#distributorToProductsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Distribütör Ürün Bağı nesnesinin id değeri |
 **distributorToProduct** | [**DistributorToProduct**](DistributorToProduct.md)|  nesnesi |

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorToProductsPost"></a>
# **distributorToProductsPost**
> DistributorToProduct distributorToProductsPost(distributorToProduct)

Distribütör Ürün Bağı Oluşturma

Yeni bir Distribütör Ürün Bağı oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.DistributorToProductApi;

DistributorToProductApi apiInstance = new DistributorToProductApi();
DistributorToProduct distributorToProduct = new DistributorToProduct(); // DistributorToProduct |  nesnesi
try {
    DistributorToProduct result = apiInstance.distributorToProductsPost(distributorToProduct);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DistributorToProductApi#distributorToProductsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **distributorToProduct** | [**DistributorToProduct**](DistributorToProduct.md)|  nesnesi |

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

