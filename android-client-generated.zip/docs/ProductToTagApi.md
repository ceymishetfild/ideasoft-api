# ProductToTagApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productToTagsGet**](ProductToTagApi.md#productToTagsGet) | **GET** /product_to_tags | Ürün SEO+ Bağı Listesi Alma
[**productToTagsIdDelete**](ProductToTagApi.md#productToTagsIdDelete) | **DELETE** /product_to_tags/{id} | Ürün SEO+ Bağı Silme
[**productToTagsIdGet**](ProductToTagApi.md#productToTagsIdGet) | **GET** /product_to_tags/{id} | Ürün SEO+ Bağı Alma
[**productToTagsIdPut**](ProductToTagApi.md#productToTagsIdPut) | **PUT** /product_to_tags/{id} | Ürün SEO+ Bağı Güncelleme
[**productToTagsPost**](ProductToTagApi.md#productToTagsPost) | **POST** /product_to_tags | Ürün SEO+ Bağı Oluşturma


<a name="productToTagsGet"></a>
# **productToTagsGet**
> ProductToTag productToTagsGet(sort, limit, page, sinceId, product, tag)

Ürün SEO+ Bağı Listesi Alma

Ürün SEO+ Bağı listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductToTagApi;

ProductToTagApi apiInstance = new ProductToTagApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
Integer product = 56; // Integer | Ürün id
Integer tag = 56; // Integer | Etiket id
try {
    ProductToTag result = apiInstance.productToTagsGet(sort, limit, page, sinceId, product, tag);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductToTagApi#productToTagsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **product** | **Integer**| Ürün id | [optional]
 **tag** | **Integer**| Etiket id | [optional]

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToTagsIdDelete"></a>
# **productToTagsIdDelete**
> productToTagsIdDelete(id)

Ürün SEO+ Bağı Silme

Kalıcı olarak ilgili Ürün SEO+ Bağını siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductToTagApi;

ProductToTagApi apiInstance = new ProductToTagApi();
Integer id = 56; // Integer | Ürün SEO+ nesnesinin id değeri
try {
    apiInstance.productToTagsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductToTagApi#productToTagsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün SEO+ nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToTagsIdGet"></a>
# **productToTagsIdGet**
> ProductToTag productToTagsIdGet(id)

Ürün SEO+ Bağı Alma

İlgili Ürün SEO+ Bağını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductToTagApi;

ProductToTagApi apiInstance = new ProductToTagApi();
Integer id = 56; // Integer | Ürün SEO+ nesnesinin id değeri
try {
    ProductToTag result = apiInstance.productToTagsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductToTagApi#productToTagsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün SEO+ nesnesinin id değeri |

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToTagsIdPut"></a>
# **productToTagsIdPut**
> ProductToTag productToTagsIdPut(id, productToTag)

Ürün SEO+ Bağı Güncelleme

İlgili Ürün SEO+ Bağını günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductToTagApi;

ProductToTagApi apiInstance = new ProductToTagApi();
Integer id = 56; // Integer | Ürün SEO+ nesnesinin id değeri
ProductToTag productToTag = new ProductToTag(); // ProductToTag | ProductToTag nesnesi
try {
    ProductToTag result = apiInstance.productToTagsIdPut(id, productToTag);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductToTagApi#productToTagsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün SEO+ nesnesinin id değeri |
 **productToTag** | [**ProductToTag**](ProductToTag.md)| ProductToTag nesnesi |

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToTagsPost"></a>
# **productToTagsPost**
> ProductToTag productToTagsPost(productToTag)

Ürün SEO+ Bağı Oluşturma

Yeni bir Ürün SEO+ Bağı oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductToTagApi;

ProductToTagApi apiInstance = new ProductToTagApi();
ProductToTag productToTag = new ProductToTag(); // ProductToTag | ProductToTag nesnesi
try {
    ProductToTag result = apiInstance.productToTagsPost(productToTag);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductToTagApi#productToTagsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productToTag** | [**ProductToTag**](ProductToTag.md)| ProductToTag nesnesi |

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

