
# SelectionGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ek özellik grubu nesnesi kimlik değeri. |  [optional]
**title** | **String** | Ek özellik grubu nesnesinin başlığı. | 
**sortOrder** | **Integer** | Ek özellik grubu nesnesi için sıralama değeri. | 



