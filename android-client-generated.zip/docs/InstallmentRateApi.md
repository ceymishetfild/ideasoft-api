# InstallmentRateApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**installmentRatesGet**](InstallmentRateApi.md#installmentRatesGet) | **GET** /installment_rates | Taksit Oranı Listesi Alma
[**installmentRatesIdGet**](InstallmentRateApi.md#installmentRatesIdGet) | **GET** /installment_rates/{id} | Taksit Oranı Alma


<a name="installmentRatesGet"></a>
# **installmentRatesGet**
> InstallmentRate installmentRatesGet(sort, limit, page, sinceId, ids, paymentGateway)

Taksit Oranı Listesi Alma

Taksit Oranı listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.InstallmentRateApi;

InstallmentRateApi apiInstance = new InstallmentRateApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
Integer paymentGateway = 56; // Integer | Ödeme Kanalı id
try {
    InstallmentRate result = apiInstance.installmentRatesGet(sort, limit, page, sinceId, ids, paymentGateway);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling InstallmentRateApi#installmentRatesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **paymentGateway** | **Integer**| Ödeme Kanalı id | [optional]

### Return type

[**InstallmentRate**](InstallmentRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="installmentRatesIdGet"></a>
# **installmentRatesIdGet**
> InstallmentRate installmentRatesIdGet(id)

Taksit Oranı Alma

İlgili Taksit Oranını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.InstallmentRateApi;

InstallmentRateApi apiInstance = new InstallmentRateApi();
Integer id = 56; // Integer | Taksit Oranı nesnesinin id değeri
try {
    InstallmentRate result = apiInstance.installmentRatesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling InstallmentRateApi#installmentRatesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Taksit Oranı nesnesinin id değeri |

### Return type

[**InstallmentRate**](InstallmentRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

