# PreOrderInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**preOrderInfosGet**](PreOrderInfoApi.md#preOrderInfosGet) | **GET** /pre_order_infos | Sipariş Öncesi Bilgisi Listesi Alma
[**preOrderInfosIdDelete**](PreOrderInfoApi.md#preOrderInfosIdDelete) | **DELETE** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Silme
[**preOrderInfosIdGet**](PreOrderInfoApi.md#preOrderInfosIdGet) | **GET** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Alma
[**preOrderInfosIdPut**](PreOrderInfoApi.md#preOrderInfosIdPut) | **PUT** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Güncelleme
[**preOrderInfosPost**](PreOrderInfoApi.md#preOrderInfosPost) | **POST** /pre_order_infos | Sipariş Öncesi Bilgisi Oluşturma


<a name="preOrderInfosGet"></a>
# **preOrderInfosGet**
> PreOrderInfo preOrderInfosGet(sort, limit, page, sinceId, ids, sessionId, startDate, endDate, startUpdatedAt, endUpdatedAt)

Sipariş Öncesi Bilgisi Listesi Alma

Sipariş Öncesi Bilgisi listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.PreOrderInfoApi;

PreOrderInfoApi apiInstance = new PreOrderInfoApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String sessionId = "sessionId_example"; // String | Sipariş Öncesi Bilgisi session id.
Date startDate = new Date(); // Date | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
Date startUpdatedAt = new Date(); // Date | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
try {
    PreOrderInfo result = apiInstance.preOrderInfosGet(sort, limit, page, sinceId, ids, sessionId, startDate, endDate, startUpdatedAt, endUpdatedAt);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PreOrderInfoApi#preOrderInfosGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **sessionId** | **String**| Sipariş Öncesi Bilgisi session id. | [optional]
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="preOrderInfosIdDelete"></a>
# **preOrderInfosIdDelete**
> preOrderInfosIdDelete(id)

Sipariş Öncesi Bilgisi Silme

Kalıcı olarak ilgili Sipariş Öncesi Bilgisini siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.PreOrderInfoApi;

PreOrderInfoApi apiInstance = new PreOrderInfoApi();
Integer id = 56; // Integer | Sipariş Öncesi Bilgisi nesnesinin id değeri
try {
    apiInstance.preOrderInfosIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling PreOrderInfoApi#preOrderInfosIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Öncesi Bilgisi nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="preOrderInfosIdGet"></a>
# **preOrderInfosIdGet**
> PreOrderInfo preOrderInfosIdGet(id)

Sipariş Öncesi Bilgisi Alma

İlgili Sipariş Öncesi Bilgisini getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.PreOrderInfoApi;

PreOrderInfoApi apiInstance = new PreOrderInfoApi();
Integer id = 56; // Integer | Sipariş Öncesi Bilgisi nesnesinin id değeri
try {
    PreOrderInfo result = apiInstance.preOrderInfosIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PreOrderInfoApi#preOrderInfosIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Öncesi Bilgisi nesnesinin id değeri |

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="preOrderInfosIdPut"></a>
# **preOrderInfosIdPut**
> PreOrderInfo preOrderInfosIdPut(id, preOrderInfo)

Sipariş Öncesi Bilgisi Güncelleme

İlgili Sipariş Öncesi Bilgisini günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.PreOrderInfoApi;

PreOrderInfoApi apiInstance = new PreOrderInfoApi();
Integer id = 56; // Integer | Sipariş Öncesi Bilgisi nesnesinin id değeri
PreOrderInfo preOrderInfo = new PreOrderInfo(); // PreOrderInfo |  nesnesi
try {
    PreOrderInfo result = apiInstance.preOrderInfosIdPut(id, preOrderInfo);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PreOrderInfoApi#preOrderInfosIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Öncesi Bilgisi nesnesinin id değeri |
 **preOrderInfo** | [**PreOrderInfo**](PreOrderInfo.md)|  nesnesi |

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="preOrderInfosPost"></a>
# **preOrderInfosPost**
> PreOrderInfo preOrderInfosPost(preOrderInfo)

Sipariş Öncesi Bilgisi Oluşturma

Yeni bir Sipariş Öncesi Bilgisi oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.PreOrderInfoApi;

PreOrderInfoApi apiInstance = new PreOrderInfoApi();
PreOrderInfo preOrderInfo = new PreOrderInfo(); // PreOrderInfo |  nesnesi
try {
    PreOrderInfo result = apiInstance.preOrderInfosPost(preOrderInfo);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PreOrderInfoApi#preOrderInfosPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **preOrderInfo** | [**PreOrderInfo**](PreOrderInfo.md)|  nesnesi |

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

