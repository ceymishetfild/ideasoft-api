# ProductToCountDownApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productToCountDownsGet**](ProductToCountDownApi.md#productToCountDownsGet) | **GET** /product_to_count_downs | Ürün Geri Sayım Bağı Listesi Alma
[**productToCountDownsIdDelete**](ProductToCountDownApi.md#productToCountDownsIdDelete) | **DELETE** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Silme
[**productToCountDownsIdGet**](ProductToCountDownApi.md#productToCountDownsIdGet) | **GET** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Alma
[**productToCountDownsIdPut**](ProductToCountDownApi.md#productToCountDownsIdPut) | **PUT** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Güncelleme
[**productToCountDownsPost**](ProductToCountDownApi.md#productToCountDownsPost) | **POST** /product_to_count_downs | Ürün Geri Sayım Bağı Oluşturma


<a name="productToCountDownsGet"></a>
# **productToCountDownsGet**
> ProductToCountDown productToCountDownsGet(sort, limit, page, sinceId, product)

Ürün Geri Sayım Bağı Listesi Alma

Ürün Geri Sayım Bağı listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductToCountDownApi;

ProductToCountDownApi apiInstance = new ProductToCountDownApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
Integer product = 56; // Integer | Ürün id
try {
    ProductToCountDown result = apiInstance.productToCountDownsGet(sort, limit, page, sinceId, product);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductToCountDownApi#productToCountDownsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **product** | **Integer**| Ürün id | [optional]

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCountDownsIdDelete"></a>
# **productToCountDownsIdDelete**
> productToCountDownsIdDelete(id)

Ürün Geri Sayım Bağı Silme

Kalıcı olarak ilgili Ürün Geri Sayım Bağını siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductToCountDownApi;

ProductToCountDownApi apiInstance = new ProductToCountDownApi();
Integer id = 56; // Integer | Ürün Geri Sayım Bağı nesnesinin id değeri
try {
    apiInstance.productToCountDownsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductToCountDownApi#productToCountDownsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Geri Sayım Bağı nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCountDownsIdGet"></a>
# **productToCountDownsIdGet**
> ProductToCountDown productToCountDownsIdGet(id)

Ürün Geri Sayım Bağı Alma

İlgili Ürün Geri Sayım Bağını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductToCountDownApi;

ProductToCountDownApi apiInstance = new ProductToCountDownApi();
Integer id = 56; // Integer | Ürün Geri Sayım Bağı nesnesinin id değeri
try {
    ProductToCountDown result = apiInstance.productToCountDownsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductToCountDownApi#productToCountDownsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Geri Sayım Bağı nesnesinin id değeri |

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCountDownsIdPut"></a>
# **productToCountDownsIdPut**
> ProductToCountDown productToCountDownsIdPut(id, productToCountDown)

Ürün Geri Sayım Bağı Güncelleme

İlgili Ürün Geri Sayım Bağını günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductToCountDownApi;

ProductToCountDownApi apiInstance = new ProductToCountDownApi();
Integer id = 56; // Integer | Ürün Geri Sayım Bağı nesnesinin id değeri
ProductToCountDown productToCountDown = new ProductToCountDown(); // ProductToCountDown | ProductToCountDown nesnesi
try {
    ProductToCountDown result = apiInstance.productToCountDownsIdPut(id, productToCountDown);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductToCountDownApi#productToCountDownsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Geri Sayım Bağı nesnesinin id değeri |
 **productToCountDown** | [**ProductToCountDown**](ProductToCountDown.md)| ProductToCountDown nesnesi |

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCountDownsPost"></a>
# **productToCountDownsPost**
> ProductToCountDown productToCountDownsPost(productToCountDown)

Ürün Geri Sayım Bağı Oluşturma

Yeni bir Ürün Geri Sayım Bağı oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.ProductToCountDownApi;

ProductToCountDownApi apiInstance = new ProductToCountDownApi();
ProductToCountDown productToCountDown = new ProductToCountDown(); // ProductToCountDown | ProductToCountDown nesnesi
try {
    ProductToCountDown result = apiInstance.productToCountDownsPost(productToCountDown);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductToCountDownApi#productToCountDownsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productToCountDown** | [**ProductToCountDown**](ProductToCountDown.md)| ProductToCountDown nesnesi |

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

