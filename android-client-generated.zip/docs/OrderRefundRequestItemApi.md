# OrderRefundRequestItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**orderRefundRequestItemsGet**](OrderRefundRequestItemApi.md#orderRefundRequestItemsGet) | **GET** /order_refund_request_items | Sipariş İptal Talebi Kalemi Listesi Alma
[**orderRefundRequestItemsIdDelete**](OrderRefundRequestItemApi.md#orderRefundRequestItemsIdDelete) | **DELETE** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Silme
[**orderRefundRequestItemsIdGet**](OrderRefundRequestItemApi.md#orderRefundRequestItemsIdGet) | **GET** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Alma
[**orderRefundRequestItemsIdPut**](OrderRefundRequestItemApi.md#orderRefundRequestItemsIdPut) | **PUT** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Güncelleme
[**orderRefundRequestItemsPost**](OrderRefundRequestItemApi.md#orderRefundRequestItemsPost) | **POST** /order_refund_request_items | Sipariş İptal Talebi Kalemi Oluşturma


<a name="orderRefundRequestItemsGet"></a>
# **orderRefundRequestItemsGet**
> OrderRefundRequestItem orderRefundRequestItemsGet(sort, limit, page, sinceId, orderRefundRequest, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt)

Sipariş İptal Talebi Kalemi Listesi Alma

Sipariş İptal Talebi Kalemi listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.OrderRefundRequestItemApi;

OrderRefundRequestItemApi apiInstance = new OrderRefundRequestItemApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
Integer orderRefundRequest = 56; // Integer | Sipariş iptal talebi id
Integer orderItem = 56; // Integer | Sipariş ürünü id
Date startDate = new Date(); // Date | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
Date startUpdatedAt = new Date(); // Date | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
try {
    OrderRefundRequestItem result = apiInstance.orderRefundRequestItemsGet(sort, limit, page, sinceId, orderRefundRequest, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderRefundRequestItemApi#orderRefundRequestItemsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **orderRefundRequest** | **Integer**| Sipariş iptal talebi id | [optional]
 **orderItem** | **Integer**| Sipariş ürünü id | [optional]
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderRefundRequestItemsIdDelete"></a>
# **orderRefundRequestItemsIdDelete**
> orderRefundRequestItemsIdDelete(id)

Sipariş İptal Talebi Kalemi Silme

Kalıcı olarak ilgili Sipariş İptal Talebi Kalemini siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.OrderRefundRequestItemApi;

OrderRefundRequestItemApi apiInstance = new OrderRefundRequestItemApi();
Integer id = 56; // Integer | Sipariş İptal Talebi Kalemi nesnesinin id değeri
try {
    apiInstance.orderRefundRequestItemsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderRefundRequestItemApi#orderRefundRequestItemsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş İptal Talebi Kalemi nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderRefundRequestItemsIdGet"></a>
# **orderRefundRequestItemsIdGet**
> OrderRefundRequestItem orderRefundRequestItemsIdGet(id)

Sipariş İptal Talebi Kalemi Alma

İlgili Sipariş İptal Talebi Kalemini getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.OrderRefundRequestItemApi;

OrderRefundRequestItemApi apiInstance = new OrderRefundRequestItemApi();
Integer id = 56; // Integer | Sipariş İptal Talebi Kalemi nesnesinin id değeri
try {
    OrderRefundRequestItem result = apiInstance.orderRefundRequestItemsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderRefundRequestItemApi#orderRefundRequestItemsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş İptal Talebi Kalemi nesnesinin id değeri |

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderRefundRequestItemsIdPut"></a>
# **orderRefundRequestItemsIdPut**
> OrderRefundRequestItem orderRefundRequestItemsIdPut(id, orderRefundRequestItem)

Sipariş İptal Talebi Kalemi Güncelleme

İlgili Sipariş İptal Talebi Kalemini günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.OrderRefundRequestItemApi;

OrderRefundRequestItemApi apiInstance = new OrderRefundRequestItemApi();
Integer id = 56; // Integer | Sipariş İptal Talebi Kalemi nesnesinin id değeri
OrderRefundRequestItem orderRefundRequestItem = new OrderRefundRequestItem(); // OrderRefundRequestItem | OrderRefundRequestItem nesnesi
try {
    OrderRefundRequestItem result = apiInstance.orderRefundRequestItemsIdPut(id, orderRefundRequestItem);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderRefundRequestItemApi#orderRefundRequestItemsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş İptal Talebi Kalemi nesnesinin id değeri |
 **orderRefundRequestItem** | [**OrderRefundRequestItem**](OrderRefundRequestItem.md)| OrderRefundRequestItem nesnesi |

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderRefundRequestItemsPost"></a>
# **orderRefundRequestItemsPost**
> OrderRefundRequestItem orderRefundRequestItemsPost(orderRefundRequestItem)

Sipariş İptal Talebi Kalemi Oluşturma

Yeni bir Sipariş İptal Talebi Kalemi oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.OrderRefundRequestItemApi;

OrderRefundRequestItemApi apiInstance = new OrderRefundRequestItemApi();
OrderRefundRequestItem orderRefundRequestItem = new OrderRefundRequestItem(); // OrderRefundRequestItem | OrderRefundRequestItem nesnesi
try {
    OrderRefundRequestItem result = apiInstance.orderRefundRequestItemsPost(orderRefundRequestItem);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderRefundRequestItemApi#orderRefundRequestItemsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orderRefundRequestItem** | [**OrderRefundRequestItem**](OrderRefundRequestItem.md)| OrderRefundRequestItem nesnesi |

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

