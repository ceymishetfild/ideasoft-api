# ShippingRateApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shippingRatesGet**](ShippingRateApi.md#shippingRatesGet) | **GET** /shipping_rates | Kargo Oranı Listesi Alma
[**shippingRatesIdDelete**](ShippingRateApi.md#shippingRatesIdDelete) | **DELETE** /shipping_rates/{id} | Kargo Oranı Silme
[**shippingRatesIdGet**](ShippingRateApi.md#shippingRatesIdGet) | **GET** /shipping_rates/{id} | Kargo Oranı Alma
[**shippingRatesIdPut**](ShippingRateApi.md#shippingRatesIdPut) | **PUT** /shipping_rates/{id} | Kargo Oranı Güncelleme
[**shippingRatesPost**](ShippingRateApi.md#shippingRatesPost) | **POST** /shipping_rates | Kargo Oranı Oluşturma


<a name="shippingRatesGet"></a>
# **shippingRatesGet**
> ShippingRate shippingRatesGet(sort, limit, page, sinceId, shippingCompany, region)

Kargo Oranı Listesi Alma

Kargo Oranı listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.ShippingRateApi;

ShippingRateApi apiInstance = new ShippingRateApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
Integer shippingCompany = 56; // Integer | Kargo firması id
Integer region = 56; // Integer | Bölge id
try {
    ShippingRate result = apiInstance.shippingRatesGet(sort, limit, page, sinceId, shippingCompany, region);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingRateApi#shippingRatesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **shippingCompany** | **Integer**| Kargo firması id | [optional]
 **region** | **Integer**| Bölge id | [optional]

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingRatesIdDelete"></a>
# **shippingRatesIdDelete**
> shippingRatesIdDelete(id)

Kargo Oranı Silme

Kalıcı olarak ilgili Kargo Oranını siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.ShippingRateApi;

ShippingRateApi apiInstance = new ShippingRateApi();
Integer id = 56; // Integer | Kargo Oranı nesnesinin id değeri
try {
    apiInstance.shippingRatesIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingRateApi#shippingRatesIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kargo Oranı nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingRatesIdGet"></a>
# **shippingRatesIdGet**
> ShippingRate shippingRatesIdGet(id)

Kargo Oranı Alma

İlgili Kargo Oranını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.ShippingRateApi;

ShippingRateApi apiInstance = new ShippingRateApi();
Integer id = 56; // Integer | Kargo Oranı nesnesinin id değeri
try {
    ShippingRate result = apiInstance.shippingRatesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingRateApi#shippingRatesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kargo Oranı nesnesinin id değeri |

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingRatesIdPut"></a>
# **shippingRatesIdPut**
> ShippingRate shippingRatesIdPut(id, shippingRate)

Kargo Oranı Güncelleme

İlgili Kargo Oranını günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.ShippingRateApi;

ShippingRateApi apiInstance = new ShippingRateApi();
Integer id = 56; // Integer | Kargo Oranı nesnesinin id değeri
ShippingRate shippingRate = new ShippingRate(); // ShippingRate | ShippingRate nesnesi
try {
    ShippingRate result = apiInstance.shippingRatesIdPut(id, shippingRate);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingRateApi#shippingRatesIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kargo Oranı nesnesinin id değeri |
 **shippingRate** | [**ShippingRate**](ShippingRate.md)| ShippingRate nesnesi |

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingRatesPost"></a>
# **shippingRatesPost**
> ShippingRate shippingRatesPost(shippingRate)

Kargo Oranı Oluşturma

Yeni bir Kargo Oranı oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.ShippingRateApi;

ShippingRateApi apiInstance = new ShippingRateApi();
ShippingRate shippingRate = new ShippingRate(); // ShippingRate | ShippingRate nesnesi
try {
    ShippingRate result = apiInstance.shippingRatesPost(shippingRate);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingRateApi#shippingRatesPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shippingRate** | [**ShippingRate**](ShippingRate.md)| ShippingRate nesnesi |

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

