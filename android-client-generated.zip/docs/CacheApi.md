# CacheApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cacheDelete**](CacheApi.md#cacheDelete) | **DELETE** /cache | Önbellek Silme


<a name="cacheDelete"></a>
# **cacheDelete**
> cacheDelete()

Önbellek Silme

Kalıcı olarak Önbelleği siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.CacheApi;

CacheApi apiInstance = new CacheApi();
try {
    apiInstance.cacheDelete();
} catch (ApiException e) {
    System.err.println("Exception when calling CacheApi#cacheDelete");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

