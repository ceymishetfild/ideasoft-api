# MemberGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**memberGroupsGet**](MemberGroupApi.md#memberGroupsGet) | **GET** /member_groups | Üye Grubu Listesi Alma
[**memberGroupsIdDelete**](MemberGroupApi.md#memberGroupsIdDelete) | **DELETE** /member_groups/{id} | Üye Grubu Silme
[**memberGroupsIdGet**](MemberGroupApi.md#memberGroupsIdGet) | **GET** /member_groups/{id} | Üye Grubu Alma
[**memberGroupsIdPut**](MemberGroupApi.md#memberGroupsIdPut) | **PUT** /member_groups/{id} | Üye Grubu Güncelleme
[**memberGroupsPost**](MemberGroupApi.md#memberGroupsPost) | **POST** /member_groups | Üye Grubu Oluşturma


<a name="memberGroupsGet"></a>
# **memberGroupsGet**
> MemberGroup memberGroupsGet(sort, limit, page, sinceId, ids, name)

Üye Grubu Listesi Alma

Üye Grubu listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.MemberGroupApi;

MemberGroupApi apiInstance = new MemberGroupApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String name = "name_example"; // String | Üye Grubu adı
try {
    MemberGroup result = apiInstance.memberGroupsGet(sort, limit, page, sinceId, ids, name);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberGroupApi#memberGroupsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **name** | **String**| Üye Grubu adı | [optional]

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberGroupsIdDelete"></a>
# **memberGroupsIdDelete**
> memberGroupsIdDelete(id)

Üye Grubu Silme

Kalıcı olarak ilgili Üye Grubunu siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.MemberGroupApi;

MemberGroupApi apiInstance = new MemberGroupApi();
Integer id = 56; // Integer | Üye Grubu nesnesinin id değeri
try {
    apiInstance.memberGroupsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberGroupApi#memberGroupsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye Grubu nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberGroupsIdGet"></a>
# **memberGroupsIdGet**
> MemberGroup memberGroupsIdGet(id)

Üye Grubu Alma

İlgili Üye Grubunu getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.MemberGroupApi;

MemberGroupApi apiInstance = new MemberGroupApi();
Integer id = 56; // Integer | Üye Grubu nesnesinin id değeri
try {
    MemberGroup result = apiInstance.memberGroupsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberGroupApi#memberGroupsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye Grubu nesnesinin id değeri |

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberGroupsIdPut"></a>
# **memberGroupsIdPut**
> MemberGroup memberGroupsIdPut(id, memberGroup)

Üye Grubu Güncelleme

İlgili Üye Grubunu günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.MemberGroupApi;

MemberGroupApi apiInstance = new MemberGroupApi();
Integer id = 56; // Integer | Üye Grubu nesnesinin id değeri
MemberGroup memberGroup = new MemberGroup(); // MemberGroup |  nesnesi
try {
    MemberGroup result = apiInstance.memberGroupsIdPut(id, memberGroup);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberGroupApi#memberGroupsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye Grubu nesnesinin id değeri |
 **memberGroup** | [**MemberGroup**](MemberGroup.md)|  nesnesi |

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberGroupsPost"></a>
# **memberGroupsPost**
> MemberGroup memberGroupsPost(memberGroup)

Üye Grubu Oluşturma

Yeni bir Üye Grubu oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.MemberGroupApi;

MemberGroupApi apiInstance = new MemberGroupApi();
MemberGroup memberGroup = new MemberGroup(); // MemberGroup |  nesnesi
try {
    MemberGroup result = apiInstance.memberGroupsPost(memberGroup);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberGroupApi#memberGroupsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **memberGroup** | [**MemberGroup**](MemberGroup.md)|  nesnesi |

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

