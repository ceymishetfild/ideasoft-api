# TagApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**tagsGet**](TagApi.md#tagsGet) | **GET** /tags | SEO+ Etiketi Listesi Alma
[**tagsIdDelete**](TagApi.md#tagsIdDelete) | **DELETE** /tags/{id} | SEO+ Etiketi Silme
[**tagsIdGet**](TagApi.md#tagsIdGet) | **GET** /tags/{id} | SEO+ Etiketi Alma
[**tagsIdPut**](TagApi.md#tagsIdPut) | **PUT** /tags/{id} | SEO+ Etiketi Güncelleme
[**tagsPost**](TagApi.md#tagsPost) | **POST** /tags | SEO+ Etiketi Oluşturma


<a name="tagsGet"></a>
# **tagsGet**
> Tag tagsGet(sort, limit, page, sinceId, name)

SEO+ Etiketi Listesi Alma

SEO+ Etiketi listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.TagApi;

TagApi apiInstance = new TagApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
String name = "name_example"; // String | SEO+ Etiketi adı
try {
    Tag result = apiInstance.tagsGet(sort, limit, page, sinceId, name);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TagApi#tagsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **name** | **String**| SEO+ Etiketi adı | [optional]

### Return type

[**Tag**](Tag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="tagsIdDelete"></a>
# **tagsIdDelete**
> tagsIdDelete(id)

SEO+ Etiketi Silme

Kalıcı olarak ilgili SEO+ Etiketini siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.TagApi;

TagApi apiInstance = new TagApi();
Integer id = 56; // Integer | SEO+ Etiketi nesnesinin id değeri
try {
    apiInstance.tagsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling TagApi#tagsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| SEO+ Etiketi nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="tagsIdGet"></a>
# **tagsIdGet**
> Tag tagsIdGet(id)

SEO+ Etiketi Alma

İlgili SEO+ Etiketini getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.TagApi;

TagApi apiInstance = new TagApi();
Integer id = 56; // Integer | SEO+ Etiketi nesnesinin id değeri
try {
    Tag result = apiInstance.tagsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TagApi#tagsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| SEO+ Etiketi nesnesinin id değeri |

### Return type

[**Tag**](Tag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="tagsIdPut"></a>
# **tagsIdPut**
> Tag tagsIdPut(id, tag)

SEO+ Etiketi Güncelleme

İlgili SEO+ Etiketini günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.TagApi;

TagApi apiInstance = new TagApi();
Integer id = 56; // Integer | SEO+ Etiketi nesnesinin id değeri
Tag tag = new Tag(); // Tag | Tag nesnesi
try {
    Tag result = apiInstance.tagsIdPut(id, tag);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TagApi#tagsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| SEO+ Etiketi nesnesinin id değeri |
 **tag** | [**Tag**](Tag.md)| Tag nesnesi |

### Return type

[**Tag**](Tag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="tagsPost"></a>
# **tagsPost**
> Tag tagsPost(tag)

SEO+ Etiketi Oluşturma

Yeni bir SEO+ Etiketi oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.TagApi;

TagApi apiInstance = new TagApi();
Tag tag = new Tag(); // Tag | Tag nesnesi
try {
    Tag result = apiInstance.tagsPost(tag);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TagApi#tagsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tag** | [**Tag**](Tag.md)| Tag nesnesi |

### Return type

[**Tag**](Tag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

