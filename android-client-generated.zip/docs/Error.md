
# Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** | HTTP Hata kodu. |  [optional]
**errorMessage** | **String** | Hata mesajı. Hata mesajları İngilizce dilindedir. |  [optional]
**errorCode** | **Integer** | Hata kodu. Eğer ek bir hata kodu varsa bu alanda belirtilir. |  [optional]



