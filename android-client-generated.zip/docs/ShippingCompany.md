
# ShippingCompany

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Kargo firması nesnesi kimlik değeri. |  [optional]
**name** | **String** | Kargo firması nesnesi için isim değeri. | 
**status** | [**StatusEnum**](#StatusEnum) | Kargo firması nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;active&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**extraPrice** | **Float** | Kargo firması için sabit ücret. Sabit bir kargo ücreti uygulayacaksanız her sipariş için sabit kargo ücreti girebilirsiniz. Desi bilgilerini kaydetmeniz durumunda desi toplamlarının üzerine sabit ücret eklenecektir. |  [optional]
**extraVolumetricWeightPrice** | **Float** | Kargo firması için girmiş olduğunuz desi bilgileri 50 Desiye kadar girilebilmektedir. 50&#39;nin üzeri veya girmiş olduğunuz desi miktarının üzerine her +1 desi için eklenecek olan kargo ücreti. |  [optional]
**freeShipmentOrderPrice** | **Float** | Alışveriş sepeti toplamı belirlediğiniz Ücretsiz kargo limitini geçtiğinde müşterileriniz ücretsiz kargo hizmetinden faydalanabilirler.(Örn: X Lira üzeri ücretsiz Kargo!) |  [optional]
**freeShipmentVolumetricWeightLimit** | **Float** | Ücretsiz kargo miktarı için maksimum ücretsiz desi miktarıdır. Alışveriş sırasındaki desi miktarı ücretsiz desi miktarından fazlaysa, + Desi miktarını sipariş sırasında sistem müşteriden tahsil eder.(Örn: X TL üzeri ücretsiz kargo! Fakat X desiye kadar)Üzeri müşteriden tahsil edilir. |  [optional]
**sortOrder** | **Integer** | Kargo firması nesnesi için sıralama değeri. |  [optional]
**companyCode** | **String** | API tarafından otomatik oluşturulan kargo firması kodu. |  [optional]
**paymentType** | [**PaymentTypeEnum**](#PaymentTypeEnum) | Kargo firması için ödeme tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli.&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli.&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil.&lt;br&gt;&lt;/div&gt; |  [optional]
**shippingProvider** | [**ShippingProvider**](ShippingProvider.md) |  |  [optional]


<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----


<a name="PaymentTypeEnum"></a>
## Enum: PaymentTypeEnum
Name | Value
---- | -----



