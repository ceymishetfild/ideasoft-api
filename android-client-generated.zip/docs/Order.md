
# Order

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sipariş nesnesi kimlik değeri. |  [optional]
**customerFirstname** | **String** | Müşterinin ismi. | 
**customerSurname** | **String** | Müşterinin soy ismi. | 
**customerEmail** | **String** | Müşterinin e-mail adresi. | 
**customerPhone** | **String** | Müşterinin telefon numarası. | 
**paymentTypeName** | **String** | Siparişin ödeme tipi. | 
**paymentProviderCode** | **String** | Siparişin ödeme altyapısı sağlayıcısının kodu. Ön tanımlıdır. API otomatik oluşturur. | 
**paymentProviderName** | **String** | Siparişin ödeme altyapısı sağlayıcısının adı. Ön tanımlıdır. API otomatik oluşturur. | 
**paymentGatewayCode** | **String** | Siparişin ödeme kanalının kodu. Ön tanımlıdır. API otomatik oluşturur. | 
**paymentGatewayName** | **String** | Siparişin ödeme kanalının adı. Ön tanımlıdır. API otomatik oluşturur. | 
**bankName** | **String** | Siparişin banka adı. Ön tanımlıdır. API otomatik oluşturur. |  [optional]
**clientIp** | **String** | Müşterinin IP adresi. | 
**userAgent** | **String** | Siparişin gerçekleştiği tarayıcı bilgisi. |  [optional]
**currency** | **String** | Kur bilgisi. | 
**currencyRates** | **String** | Kur oranları. | 
**amount** | **Float** | Siparişin vergi hariç fiyatı. | 
**couponDiscount** | **Float** | Siparişte kullanılan hediye çeki indirimi tutarı. | 
**taxAmount** | **Float** | Siparişin vergi tutarı. | 
**promotionDiscount** | **Float** | Siparişte kullanılan promosyon indirimi tutarı. | 
**generalAmount** | **Float** | Siparişin genel fiyat tutarı. orderAmount, couponDiscount, taxAmount, promotionDiscount, shippingAmount, additionalServiceAmount tutarlarının toplamı. | 
**shippingAmount** | **Float** | Siparişin teslimat ücreti. | 
**additionalServiceAmount** | **Float** | Siparişin ek hizmet bedeli ücreti. | 
**finalAmount** | **Float** | Siparişin son ödeme tutarı. generalAmount değerinin üzerine taksitten kaynaklı vade farkı bedeli eklenmiş hali. | 
**sumOfGainedPoints** | **Float** | Siparişten kazanılan puan tutarı. |  [optional]
**installment** | **Integer** | Siparişin taksit adeti. |  [optional]
**installmentRate** | **Float** | Siparişin taksit oranı. |  [optional]
**extraInstallment** | **Integer** | Siparişin ek taksit adeti. |  [optional]
**transactionId** | **String** | Siparişin numarası. |  [optional]
**hasUserNote** | [**HasUserNoteEnum**](#HasUserNoteEnum) | Siparişin müşteri notuna sahiplik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sipariş müşteri notuna sahip.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sipariş müşteri notuna sahip değil.&lt;br&gt;&lt;/div&gt; |  [optional]
**status** | [**StatusEnum**](#StatusEnum) | Sipariş durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;/div&gt; | 
**paymentStatus** | [**PaymentStatusEnum**](#PaymentStatusEnum) | Ödeme durumu bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;success&lt;/code&gt; : Başarılı&lt;br&gt;&lt;/div&gt; | 
**errorMessage** | **String** | Siparişin hata mesajı. |  [optional]
**deviceType** | [**DeviceTypeEnum**](#DeviceTypeEnum) | Siparişin gerçekleştiği cihaz bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil&lt;br&gt;&lt;code&gt;tablet&lt;/code&gt; : Tablet&lt;br&gt;&lt;/div&gt; | 
**referrer** | **String** | Siparişe yönlendiren web-sitesi adresi. Yönlendirmeyi yapan web-sitesinin tam URL bilgisini de içerir. API otomatik oluşturur. |  [optional]
**invoicePrintCount** | **Integer** | Sipariş için alınan fatura çıktısı adedi. |  [optional]
**useGiftPackage** | [**UseGiftPackageEnum**](#UseGiftPackageEnum) | Hediye paketi istenilmesi durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hediye paketi istiyorum&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hediye paketi istemiyorum&lt;br&gt;&lt;/div&gt; |  [optional]
**giftNote** | **String** | Hediye notu. |  [optional]
**memberGroupName** | **String** | Üye grubu adı. |  [optional]
**usePromotion** | [**UsePromotionEnum**](#UsePromotionEnum) | Promosyon kullanılma durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Promosyon kullan&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Promosyon kullanma&lt;br&gt;&lt;/div&gt; |  [optional]
**shippingProviderCode** | **String** | Siparişin teslimat hizmeti sağlayıcısı kodu. Ön tanımlıdır. API otomatik oluşturur. |  [optional]
**shippingProviderName** | **String** | Siparişin teslimat hizmeti sağlayıcısı adı. Ön tanımlıdır. |  [optional]
**shippingCompanyName** | **String** | Siparişin kargo firması adı. Ön tanımlıdır. |  [optional]
**shippingPaymentType** | [**ShippingPaymentTypeEnum**](#ShippingPaymentTypeEnum) | Siparişin kargo ödeme tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı Ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici Ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için geçerli değil.&lt;br&gt;&lt;/div&gt; |  [optional]
**shippingTrackingCode** | **String** | Siparişin kargo takip kodu. |  [optional]
**source** | **String** | Siparişin kaynak bilgisi. Siparişin kaynak yazılımını belirtir. | 
**createdAt** | [**Date**](Date.md) | Sipariş nesnesinin oluşturulma zamanı. |  [optional]
**updatedAt** | [**Date**](Date.md) | Sipariş nesnesinin güncellenme zamanı. |  [optional]
**maillist** | [**Maillist**](Maillist.md) |  |  [optional]
**member** | [**Member**](Member.md) |  |  [optional]
**orderDetails** | [**List&lt;OrderDetail&gt;**](OrderDetail.md) | Sipariş detayları. |  [optional]
**orderItems** | [**List&lt;OrderItem&gt;**](OrderItem.md) | Sipariş kalemleri. |  [optional]
**shippingAddress** | [**ShippingAddress**](ShippingAddress.md) |  |  [optional]
**billingAddress** | [**BillingAddress**](BillingAddress.md) |  |  [optional]


<a name="HasUserNoteEnum"></a>
## Enum: HasUserNoteEnum
Name | Value
---- | -----


<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----


<a name="PaymentStatusEnum"></a>
## Enum: PaymentStatusEnum
Name | Value
---- | -----


<a name="DeviceTypeEnum"></a>
## Enum: DeviceTypeEnum
Name | Value
---- | -----


<a name="UseGiftPackageEnum"></a>
## Enum: UseGiftPackageEnum
Name | Value
---- | -----


<a name="UsePromotionEnum"></a>
## Enum: UsePromotionEnum
Name | Value
---- | -----


<a name="ShippingPaymentTypeEnum"></a>
## Enum: ShippingPaymentTypeEnum
Name | Value
---- | -----



