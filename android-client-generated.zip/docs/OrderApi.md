# OrderApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ordersGet**](OrderApi.md#ordersGet) | **GET** /orders | Sipariş Listesi Alma
[**ordersIdDelete**](OrderApi.md#ordersIdDelete) | **DELETE** /orders/{id} | Sipariş Silme
[**ordersIdGet**](OrderApi.md#ordersIdGet) | **GET** /orders/{id} | Sipariş Alma
[**ordersIdPut**](OrderApi.md#ordersIdPut) | **PUT** /orders/{id} | Sipariş Güncelleme
[**ordersPost**](OrderApi.md#ordersPost) | **POST** /orders | Sipariş Oluşturma


<a name="ordersGet"></a>
# **ordersGet**
> Order ordersGet(sort, limit, page, sinceId, transactionId, customerEmail, member, status, paymentStatus, paymentTypeName, shippingProviderCode, q, startDate, endDate, startUpdatedAt, endUpdatedAt)

Sipariş Listesi Alma

Sipariş listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.OrderApi;

OrderApi apiInstance = new OrderApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String transactionId = "transactionId_example"; // String | İşlem id.
String customerEmail = "customerEmail_example"; // String | Müşteri e-mail.
Integer member = 56; // Integer | Üye id
String status = "status_example"; // String | Status şu değerleri alabilir: <br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br><code>deleted</code> : Silindi
String paymentStatus = "paymentStatus_example"; // String | Ödeme durumu şu değerleri alabilir: <br><code>success</code> : Başarılı<br><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br><code>failed</code> : Hatalı Ödemeler
String paymentTypeName = "paymentTypeName_example"; // String | Ödeme tipi şu değerleri alabilir: <br><code>Havale</code><br><code>Özel Ödeme Sistemi</code><br><code>Kredi Kartı</code><br><code>Paypal</code><br><code>GarantiPay</code><br><code>Mail Order</code><br><code>BKM Express</code><br><code>Kapıda Ödeme Nakit</code><br><code>Kapıda Ödeme Kredi Kartı</code>
String shippingProviderCode = "shippingProviderCode_example"; // String | Teslimat hizmeti sağlayıcıları kodu şu değerleri alabilir: <br><code>yurtici</code> : Yurtiçi Kargo<br><code>yurtici_self_service</code> : Yurtiçi Kargo (Self Service)<br><code>yurtici_api</code> : Yurtiçi Kargo (API)<br><code>ptt</code> : PTT Kargo<br><code>mng</code> : MNG Kargo<br><code>surat</code> : Sürat Kargo<br><code>ups</code> : UPS<br><code>aras</code> : Aras Kargo<br><code>other</code> : Diğer
List<String> q = Arrays.asList("q_example"); // List<String> | Sipariş arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;]
Date startDate = new Date(); // Date | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
Date startUpdatedAt = new Date(); // Date | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
try {
    Order result = apiInstance.ordersGet(sort, limit, page, sinceId, transactionId, customerEmail, member, status, paymentStatus, paymentTypeName, shippingProviderCode, q, startDate, endDate, startUpdatedAt, endUpdatedAt);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderApi#ordersGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **transactionId** | **String**| İşlem id. | [optional]
 **customerEmail** | **String**| Müşteri e-mail. | [optional]
 **member** | **Integer**| Üye id | [optional]
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi | [optional] [enum: waiting_for_approval, approved, fulfilled, cancelled, delivered, on_accumulation, waiting_for_payment, being_prepared, refunded, personal_status_1, personal_status_2, personal_status_3, deleted]
 **paymentStatus** | **String**| Ödeme durumu şu değerleri alabilir: &lt;br&gt;&lt;code&gt;success&lt;/code&gt; : Başarılı&lt;br&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler | [optional] [enum: success, in_transaction, failed]
 **paymentTypeName** | **String**| Ödeme tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;Havale&lt;/code&gt;&lt;br&gt;&lt;code&gt;Özel Ödeme Sistemi&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kredi Kartı&lt;/code&gt;&lt;br&gt;&lt;code&gt;Paypal&lt;/code&gt;&lt;br&gt;&lt;code&gt;GarantiPay&lt;/code&gt;&lt;br&gt;&lt;code&gt;Mail Order&lt;/code&gt;&lt;br&gt;&lt;code&gt;BKM Express&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kapıda Ödeme Nakit&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kapıda Ödeme Kredi Kartı&lt;/code&gt; | [optional] [enum: Havale, Özel Ödeme Sistemi, Kredi Kartı, Paypal, GarantiPay, Mail Order, BKM Express, Kapıda Ödeme Nakit, Kapıda Ödeme Kredi Kartı]
 **shippingProviderCode** | **String**| Teslimat hizmeti sağlayıcıları kodu şu değerleri alabilir: &lt;br&gt;&lt;code&gt;yurtici&lt;/code&gt; : Yurtiçi Kargo&lt;br&gt;&lt;code&gt;yurtici_self_service&lt;/code&gt; : Yurtiçi Kargo (Self Service)&lt;br&gt;&lt;code&gt;yurtici_api&lt;/code&gt; : Yurtiçi Kargo (API)&lt;br&gt;&lt;code&gt;ptt&lt;/code&gt; : PTT Kargo&lt;br&gt;&lt;code&gt;mng&lt;/code&gt; : MNG Kargo&lt;br&gt;&lt;code&gt;surat&lt;/code&gt; : Sürat Kargo&lt;br&gt;&lt;code&gt;ups&lt;/code&gt; : UPS&lt;br&gt;&lt;code&gt;aras&lt;/code&gt; : Aras Kargo&lt;br&gt;&lt;code&gt;other&lt;/code&gt; : Diğer | [optional] [enum: yurtici, yurtici_self_service, yurtici_api, ptt, mng, surat, ups, aras, other]
 **q** | [**List&lt;String&gt;**](String.md)| Sipariş arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional]
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="ordersIdDelete"></a>
# **ordersIdDelete**
> ordersIdDelete(id)

Sipariş Silme

Kalıcı olarak ilgili Siparişi siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.OrderApi;

OrderApi apiInstance = new OrderApi();
Integer id = 56; // Integer | Sipariş nesnesinin id değeri
try {
    apiInstance.ordersIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderApi#ordersIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="ordersIdGet"></a>
# **ordersIdGet**
> Order ordersIdGet(id)

Sipariş Alma

İlgili Siparişi getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.OrderApi;

OrderApi apiInstance = new OrderApi();
Integer id = 56; // Integer | Sipariş nesnesinin id değeri
try {
    Order result = apiInstance.ordersIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderApi#ordersIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş nesnesinin id değeri |

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="ordersIdPut"></a>
# **ordersIdPut**
> Order ordersIdPut(id, order)

Sipariş Güncelleme

İlgili Siparişi günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.OrderApi;

OrderApi apiInstance = new OrderApi();
Integer id = 56; // Integer | Sipariş nesnesinin id değeri
Order order = new Order(); // Order | Order nesnesi
try {
    Order result = apiInstance.ordersIdPut(id, order);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderApi#ordersIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş nesnesinin id değeri |
 **order** | [**Order**](Order.md)| Order nesnesi |

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="ordersPost"></a>
# **ordersPost**
> Order ordersPost(order)

Sipariş Oluşturma

Yeni bir Sipariş oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.OrderApi;

OrderApi apiInstance = new OrderApi();
Order order = new Order(); // Order | Order nesnesi
try {
    Order result = apiInstance.ordersPost(order);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderApi#ordersPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order** | [**Order**](Order.md)| Order nesnesi |

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

