
# MemberGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Üye Grubu nesnesi kimlik değeri. |  [optional]
**name** | **String** | Üye Grubu nesnesi için isim değeri. | 
**priceIndex** | **Integer** | Üye Grubunun fiyat indisi. Örnek Fiyat 2. | 
**allowedPaymentGateways** | **String** | Üye Grubunun izin verilmiş ödeme kanalları. | 



