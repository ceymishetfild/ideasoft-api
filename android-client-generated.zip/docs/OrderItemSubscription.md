
# OrderItemSubscription

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sipariş kalemi aboneliği kimlik değeri. |  [optional]



