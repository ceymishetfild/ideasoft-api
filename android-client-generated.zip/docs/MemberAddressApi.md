# MemberAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**memberAddressesGet**](MemberAddressApi.md#memberAddressesGet) | **GET** /member_addresses | Üye Adresi Listeleme
[**memberAddressesIdDelete**](MemberAddressApi.md#memberAddressesIdDelete) | **DELETE** /member_addresses/{id} | Üye Adresi Silme
[**memberAddressesIdGet**](MemberAddressApi.md#memberAddressesIdGet) | **GET** /member_addresses/{id} | Üye Adresi Alma
[**memberAddressesIdPut**](MemberAddressApi.md#memberAddressesIdPut) | **PUT** /member_addresses/{id} | Üye Adresi Güncelleme
[**memberAddressesPost**](MemberAddressApi.md#memberAddressesPost) | **POST** /member_addresses | Üye Adresi Oluşturma


<a name="memberAddressesGet"></a>
# **memberAddressesGet**
> MemberAddress memberAddressesGet(sort, limit, page, sinceId, member, startDate, endDate)

Üye Adresi Listeleme

Üye Adresi listesi verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.MemberAddressApi;

MemberAddressApi apiInstance = new MemberAddressApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
Integer member = 56; // Integer | Üye id
Date startDate = new Date(); // Date | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
try {
    MemberAddress result = apiInstance.memberAddressesGet(sort, limit, page, sinceId, member, startDate, endDate);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberAddressApi#memberAddressesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **member** | **Integer**| Üye id | [optional]
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberAddressesIdDelete"></a>
# **memberAddressesIdDelete**
> memberAddressesIdDelete(id)

Üye Adresi Silme

Kalıcı olarak ilgili Üye Adresini siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.MemberAddressApi;

MemberAddressApi apiInstance = new MemberAddressApi();
Integer id = 56; // Integer | Üye Adresi nesnesinin id değeri
try {
    apiInstance.memberAddressesIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberAddressApi#memberAddressesIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye Adresi nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberAddressesIdGet"></a>
# **memberAddressesIdGet**
> MemberAddress memberAddressesIdGet(id)

Üye Adresi Alma

İlgili Üye Adresini getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.MemberAddressApi;

MemberAddressApi apiInstance = new MemberAddressApi();
Integer id = 56; // Integer | Üye Adresi nesnesinin id değeri
try {
    MemberAddress result = apiInstance.memberAddressesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberAddressApi#memberAddressesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye Adresi nesnesinin id değeri |

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberAddressesIdPut"></a>
# **memberAddressesIdPut**
> MemberAddress memberAddressesIdPut(id, memberAddress)

Üye Adresi Güncelleme

İlgili Üye Adresini günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.MemberAddressApi;

MemberAddressApi apiInstance = new MemberAddressApi();
Integer id = 56; // Integer | Üye Adresi nesnesinin id değeri
MemberAddress memberAddress = new MemberAddress(); // MemberAddress | MemberAddress nesnesi
try {
    MemberAddress result = apiInstance.memberAddressesIdPut(id, memberAddress);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberAddressApi#memberAddressesIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye Adresi nesnesinin id değeri |
 **memberAddress** | [**MemberAddress**](MemberAddress.md)| MemberAddress nesnesi |

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberAddressesPost"></a>
# **memberAddressesPost**
> MemberAddress memberAddressesPost(memberAddress)

Üye Adresi Oluşturma

Yeni bir Üye Adresi oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.MemberAddressApi;

MemberAddressApi apiInstance = new MemberAddressApi();
MemberAddress memberAddress = new MemberAddress(); // MemberAddress | MemberAddress nesnesi
try {
    MemberAddress result = apiInstance.memberAddressesPost(memberAddress);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberAddressApi#memberAddressesPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **memberAddress** | [**MemberAddress**](MemberAddress.md)| MemberAddress nesnesi |

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

