# BrandApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**brandsGet**](BrandApi.md#brandsGet) | **GET** /brands | Marka Listesi Alma
[**brandsIdDelete**](BrandApi.md#brandsIdDelete) | **DELETE** /brands/{id} | Marka Silme
[**brandsIdGet**](BrandApi.md#brandsIdGet) | **GET** /brands/{id} | Marka Alma
[**brandsIdPut**](BrandApi.md#brandsIdPut) | **PUT** /brands/{id} | Marka Güncelleme
[**brandsPost**](BrandApi.md#brandsPost) | **POST** /brands | Marka Oluşturma


<a name="brandsGet"></a>
# **brandsGet**
> Brand brandsGet(sort, limit, page, sinceId, ids, name, status, distributor, startDate, endDate, startUpdatedAt, endUpdatedAt, q)

Marka Listesi Alma

Marka listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.BrandApi;

BrandApi apiInstance = new BrandApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String name = "name_example"; // String | Marka adı.
String status = "status_example"; // String | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
String distributor = "distributor_example"; // String | Marka distribörü
Date startDate = new Date(); // Date | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
Date startUpdatedAt = new Date(); // Date | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
List<String> q = Arrays.asList("q_example"); // List<String> | Marka arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;]
try {
    Brand result = apiInstance.brandsGet(sort, limit, page, sinceId, ids, name, status, distributor, startDate, endDate, startUpdatedAt, endUpdatedAt, q);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BrandApi#brandsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **name** | **String**| Marka adı. | [optional]
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] [enum: 0, 1]
 **distributor** | **String**| Marka distribörü | [optional]
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]
 **q** | [**List&lt;String&gt;**](String.md)| Marka arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional]

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="brandsIdDelete"></a>
# **brandsIdDelete**
> brandsIdDelete(id)

Marka Silme

Kalıcı olarak ilgili Markayı siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.BrandApi;

BrandApi apiInstance = new BrandApi();
Integer id = 56; // Integer | Marka nesnesinin id değeri
try {
    apiInstance.brandsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling BrandApi#brandsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Marka nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="brandsIdGet"></a>
# **brandsIdGet**
> Brand brandsIdGet(id)

Marka Alma

İlgili Markayı getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.BrandApi;

BrandApi apiInstance = new BrandApi();
Integer id = 56; // Integer | Marka nesnesinin id değeri
try {
    Brand result = apiInstance.brandsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BrandApi#brandsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Marka nesnesinin id değeri |

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="brandsIdPut"></a>
# **brandsIdPut**
> Brand brandsIdPut(id, brand)

Marka Güncelleme

İlgili Markayı günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.BrandApi;

BrandApi apiInstance = new BrandApi();
Integer id = 56; // Integer | Marka nesnesinin id değeri
Brand brand = new Brand(); // Brand |  nesnesi
try {
    Brand result = apiInstance.brandsIdPut(id, brand);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BrandApi#brandsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Marka nesnesinin id değeri |
 **brand** | [**Brand**](Brand.md)|  nesnesi |

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="brandsPost"></a>
# **brandsPost**
> Brand brandsPost(brand)

Marka Oluşturma

Yeni bir Marka oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.BrandApi;

BrandApi apiInstance = new BrandApi();
Brand brand = new Brand(); // Brand |  nesnesi
try {
    Brand result = apiInstance.brandsPost(brand);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BrandApi#brandsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **brand** | [**Brand**](Brand.md)|  nesnesi |

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

