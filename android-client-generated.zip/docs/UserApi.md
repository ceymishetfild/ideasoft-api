# UserApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**usersGet**](UserApi.md#usersGet) | **GET** /users | Yönetici Listesi Alma
[**usersIdGet**](UserApi.md#usersIdGet) | **GET** /users/{id} | Yönetici Alma


<a name="usersGet"></a>
# **usersGet**
> User usersGet(sort, limit, page, sinceId, ids, firstname, surname, email, username, phoneNumber, isOwner, status, startDate, endDate, startUpdatedAt, endUpdatedAt)

Yönetici Listesi Alma

Yönetici listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.UserApi;

UserApi apiInstance = new UserApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String firstname = "firstname_example"; // String | Adı
String surname = "surname_example"; // String | Soyadı
String email = "email_example"; // String | e-mail
String username = "username_example"; // String | Yönetici adı
String phoneNumber = "phoneNumber_example"; // String | Telefon numarası
String isOwner = "isOwner_example"; // String | Mağaza sahibi mi?<code>0</code><br><code>1</code>
String status = "status_example"; // String | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif<br><code>2</code> : Askıya alınmış
Date startDate = new Date(); // Date | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
Date startUpdatedAt = new Date(); // Date | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
try {
    User result = apiInstance.usersGet(sort, limit, page, sinceId, ids, firstname, surname, email, username, phoneNumber, isOwner, status, startDate, endDate, startUpdatedAt, endUpdatedAt);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling UserApi#usersGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **firstname** | **String**| Adı | [optional]
 **surname** | **String**| Soyadı | [optional]
 **email** | **String**| e-mail | [optional]
 **username** | **String**| Yönetici adı | [optional]
 **phoneNumber** | **String**| Telefon numarası | [optional]
 **isOwner** | **String**| Mağaza sahibi mi?&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] [enum: 0, 1]
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Askıya alınmış | [optional] [enum: 0, 1, 2]
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**User**](User.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="usersIdGet"></a>
# **usersIdGet**
> User usersIdGet(id)

Yönetici Alma

İlgili Yöneticiyi  getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.UserApi;

UserApi apiInstance = new UserApi();
Integer id = 56; // Integer | Yönetici nesnesinin id değeri
try {
    User result = apiInstance.usersIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling UserApi#usersIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Yönetici nesnesinin id değeri |

### Return type

[**User**](User.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

