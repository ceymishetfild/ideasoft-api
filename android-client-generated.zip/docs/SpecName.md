
# SpecName

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ürün özelliği nesnesi kimlik değeri. |  [optional]
**name** | **String** | Ürün özelliği nesnesi için isim değeri. | 
**choiceType** | [**ChoiceTypeEnum**](#ChoiceTypeEnum) | Özellik tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul&lt;br&gt;&lt;/div&gt; | 
**sortOrder** | **Integer** | Ürün özelliği sıralama değeri. |  [optional]
**status** | [**StatusEnum**](#StatusEnum) | Ürün özelliği aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**specGroup** | [**SpecGroup**](SpecGroup.md) |  |  [optional]


<a name="ChoiceTypeEnum"></a>
## Enum: ChoiceTypeEnum
Name | Value
---- | -----


<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----



