# SelectionToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selectionToProductsGet**](SelectionToProductApi.md#selectionToProductsGet) | **GET** /selection_to_products | Ek Özellik Ürün Bağı Listesi Alma
[**selectionToProductsIdDelete**](SelectionToProductApi.md#selectionToProductsIdDelete) | **DELETE** /selection_to_products/{id} | Ek Özellik Ürün Bağı Silme
[**selectionToProductsIdGet**](SelectionToProductApi.md#selectionToProductsIdGet) | **GET** /selection_to_products/{id} | Ek Özellik Ürün Bağı Alma
[**selectionToProductsIdPut**](SelectionToProductApi.md#selectionToProductsIdPut) | **PUT** /selection_to_products/{id} | Ek Özellik Ürün Bağı Güncelleme
[**selectionToProductsPost**](SelectionToProductApi.md#selectionToProductsPost) | **POST** /selection_to_products | Ek Özellik Ürün Bağı Oluşturma


<a name="selectionToProductsGet"></a>
# **selectionToProductsGet**
> SelectionToProduct selectionToProductsGet(sort, limit, page, sinceId, selection, product)

Ek Özellik Ürün Bağı Listesi Alma

Ek Özellik Ürün Bağı listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.SelectionToProductApi;

SelectionToProductApi apiInstance = new SelectionToProductApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
Integer selection = 56; // Integer | Ek Özellik id
Integer product = 56; // Integer | Ürün id
try {
    SelectionToProduct result = apiInstance.selectionToProductsGet(sort, limit, page, sinceId, selection, product);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SelectionToProductApi#selectionToProductsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **selection** | **Integer**| Ek Özellik id | [optional]
 **product** | **Integer**| Ürün id | [optional]

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionToProductsIdDelete"></a>
# **selectionToProductsIdDelete**
> selectionToProductsIdDelete(id)

Ek Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ek Özellik Ürün Bağını siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.SelectionToProductApi;

SelectionToProductApi apiInstance = new SelectionToProductApi();
Integer id = 56; // Integer | Ek Özellik Ürün Bağı nesnesinin id değeri
try {
    apiInstance.selectionToProductsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling SelectionToProductApi#selectionToProductsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Özellik Ürün Bağı nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionToProductsIdGet"></a>
# **selectionToProductsIdGet**
> SelectionToProduct selectionToProductsIdGet(id)

Ek Özellik Ürün Bağı Alma

İlgili Ek Özellik Ürün Bağını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.SelectionToProductApi;

SelectionToProductApi apiInstance = new SelectionToProductApi();
Integer id = 56; // Integer | Ek Özellik Ürün Bağı nesnesinin id değeri
try {
    SelectionToProduct result = apiInstance.selectionToProductsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SelectionToProductApi#selectionToProductsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Özellik Ürün Bağı nesnesinin id değeri |

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionToProductsIdPut"></a>
# **selectionToProductsIdPut**
> SelectionToProduct selectionToProductsIdPut(id, selectionToProduct)

Ek Özellik Ürün Bağı Güncelleme

İlgili Ek Özellik Ürün Bağını günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.SelectionToProductApi;

SelectionToProductApi apiInstance = new SelectionToProductApi();
Integer id = 56; // Integer | Ek Özellik Ürün Bağı nesnesinin id değeri
SelectionToProduct selectionToProduct = new SelectionToProduct(); // SelectionToProduct | SelectionToProduct nesnesi
try {
    SelectionToProduct result = apiInstance.selectionToProductsIdPut(id, selectionToProduct);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SelectionToProductApi#selectionToProductsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Özellik Ürün Bağı nesnesinin id değeri |
 **selectionToProduct** | [**SelectionToProduct**](SelectionToProduct.md)| SelectionToProduct nesnesi |

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionToProductsPost"></a>
# **selectionToProductsPost**
> SelectionToProduct selectionToProductsPost(selectionToProduct)

Ek Özellik Ürün Bağı Oluşturma

Yeni bir Ek Özellik Ürün Bağı oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.SelectionToProductApi;

SelectionToProductApi apiInstance = new SelectionToProductApi();
SelectionToProduct selectionToProduct = new SelectionToProduct(); // SelectionToProduct | SelectionToProduct nesnesi
try {
    SelectionToProduct result = apiInstance.selectionToProductsPost(selectionToProduct);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SelectionToProductApi#selectionToProductsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selectionToProduct** | [**SelectionToProduct**](SelectionToProduct.md)| SelectionToProduct nesnesi |

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

