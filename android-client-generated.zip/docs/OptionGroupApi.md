# OptionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**optionGroupsGet**](OptionGroupApi.md#optionGroupsGet) | **GET** /option_groups | Varyant Grubu Listesi Alma
[**optionGroupsIdDelete**](OptionGroupApi.md#optionGroupsIdDelete) | **DELETE** /option_groups/{id} | Varyant Grubu Silme
[**optionGroupsIdGet**](OptionGroupApi.md#optionGroupsIdGet) | **GET** /option_groups/{id} | Varyant Grubu Alma
[**optionGroupsIdPut**](OptionGroupApi.md#optionGroupsIdPut) | **PUT** /option_groups/{id} | Varyant Grubu Güncelleme
[**optionGroupsPost**](OptionGroupApi.md#optionGroupsPost) | **POST** /option_groups | Varyant Grubu Oluşturma


<a name="optionGroupsGet"></a>
# **optionGroupsGet**
> OptionGroup optionGroupsGet(sort, limit, page, sinceId, ids, title)

Varyant Grubu Listesi Alma

Varyant Grubu listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.api.OptionGroupApi;

OptionGroupApi apiInstance = new OptionGroupApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String title = "title_example"; // String | Varyant Grubu başlığı.
try {
    OptionGroup result = apiInstance.optionGroupsGet(sort, limit, page, sinceId, ids, title);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OptionGroupApi#optionGroupsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **title** | **String**| Varyant Grubu başlığı. | [optional]

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionGroupsIdDelete"></a>
# **optionGroupsIdDelete**
> optionGroupsIdDelete(id)

Varyant Grubu Silme

Kalıcı olarak ilgili Varyant Grubunu siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.OptionGroupApi;

OptionGroupApi apiInstance = new OptionGroupApi();
Integer id = 56; // Integer | Varyant Grubu nesnesinin id değeri
try {
    apiInstance.optionGroupsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling OptionGroupApi#optionGroupsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant Grubu nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionGroupsIdGet"></a>
# **optionGroupsIdGet**
> OptionGroup optionGroupsIdGet(id)

Varyant Grubu Alma

İlgili Varyant Grubunu getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.OptionGroupApi;

OptionGroupApi apiInstance = new OptionGroupApi();
Integer id = 56; // Integer | Varyant Grubu nesnesinin id değeri
try {
    OptionGroup result = apiInstance.optionGroupsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OptionGroupApi#optionGroupsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant Grubu nesnesinin id değeri |

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionGroupsIdPut"></a>
# **optionGroupsIdPut**
> OptionGroup optionGroupsIdPut(id, optionGroup)

Varyant Grubu Güncelleme

İlgili Varyant Grubunu günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.OptionGroupApi;

OptionGroupApi apiInstance = new OptionGroupApi();
Integer id = 56; // Integer | Varyant Grubu nesnesinin id değeri
OptionGroup optionGroup = new OptionGroup(); // OptionGroup |  nesnesi
try {
    OptionGroup result = apiInstance.optionGroupsIdPut(id, optionGroup);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OptionGroupApi#optionGroupsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant Grubu nesnesinin id değeri |
 **optionGroup** | [**OptionGroup**](OptionGroup.md)|  nesnesi |

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionGroupsPost"></a>
# **optionGroupsPost**
> OptionGroup optionGroupsPost(optionGroup)

Varyant Grubu Oluşturma

Yeni bir Varyant Grubu oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.OptionGroupApi;

OptionGroupApi apiInstance = new OptionGroupApi();
OptionGroup optionGroup = new OptionGroup(); // OptionGroup |  nesnesi
try {
    OptionGroup result = apiInstance.optionGroupsPost(optionGroup);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OptionGroupApi#optionGroupsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **optionGroup** | [**OptionGroup**](OptionGroup.md)|  nesnesi |

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

