
# Tag

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | SEO+ etiketi nesnesi kimlik değeri. |  [optional]
**name** | **String** | SEO+ etiketi nesnesi için isim değeri. | 
**count** | **Integer** | SEO+ etiketinin kaç kez kullanıldığı bilgisi. |  [optional]
**pageTitle** | **String** | SEO+ etiketi nesnesinin etiket başlığı. |  [optional]
**metaDescription** | **String** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. |  [optional]
**metaKeywords** | **String** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. |  [optional]



