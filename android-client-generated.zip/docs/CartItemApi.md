# CartItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cartItemsIdDelete**](CartItemApi.md#cartItemsIdDelete) | **DELETE** /cart_items/{id} | Sepet Kalemi Silme
[**cartItemsIdPut**](CartItemApi.md#cartItemsIdPut) | **PUT** /cart_items/{id} | Sepet Kalemi Güncelleme
[**cartItemsPost**](CartItemApi.md#cartItemsPost) | **POST** /cart_items | Sepet Kalemi Oluşturma


<a name="cartItemsIdDelete"></a>
# **cartItemsIdDelete**
> cartItemsIdDelete(id)

Sepet Kalemi Silme

Kalıcı olarak ilgili Sepet Kalemini siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.CartItemApi;

CartItemApi apiInstance = new CartItemApi();
Integer id = 56; // Integer | Sepet Kalemi nesnesinin id değeri
try {
    apiInstance.cartItemsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling CartItemApi#cartItemsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sepet Kalemi nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="cartItemsIdPut"></a>
# **cartItemsIdPut**
> CartItem cartItemsIdPut(id)

Sepet Kalemi Güncelleme

İlgili Sepet Kalemini günceller.

### Example
```java
// Import classes:
//import io.swagger.client.api.CartItemApi;

CartItemApi apiInstance = new CartItemApi();
Integer id = 56; // Integer | Sepet Kalemi nesnesinin id değeri
try {
    CartItem result = apiInstance.cartItemsIdPut(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CartItemApi#cartItemsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sepet Kalemi nesnesinin id değeri |

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="cartItemsPost"></a>
# **cartItemsPost**
> CartItem cartItemsPost(cartItem)

Sepet Kalemi Oluşturma

Yeni bir Sepet Kalemi oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.CartItemApi;

CartItemApi apiInstance = new CartItemApi();
CartItem cartItem = new CartItem(); // CartItem | CartItem nesnesi
try {
    CartItem result = apiInstance.cartItemsPost(cartItem);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CartItemApi#cartItemsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartItem** | [**CartItem**](CartItem.md)| CartItem nesnesi |

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

