# CartApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cartsIdDelete**](CartApi.md#cartsIdDelete) | **DELETE** /carts/{id} | Sepet Silme
[**cartsIdGet**](CartApi.md#cartsIdGet) | **GET** /carts/{id} | Sepet Alma
[**cartsPost**](CartApi.md#cartsPost) | **POST** /carts | Sepet Oluşturma


<a name="cartsIdDelete"></a>
# **cartsIdDelete**
> cartsIdDelete(id)

Sepet Silme

Kalıcı olarak ilgili Sepeti siler.

### Example
```java
// Import classes:
//import io.swagger.client.api.CartApi;

CartApi apiInstance = new CartApi();
Integer id = 56; // Integer | Sepet nesnesinin id değeri
try {
    apiInstance.cartsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling CartApi#cartsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sepet nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="cartsIdGet"></a>
# **cartsIdGet**
> Cart cartsIdGet(id)

Sepet Alma

İlgili Sepet getirir.

### Example
```java
// Import classes:
//import io.swagger.client.api.CartApi;

CartApi apiInstance = new CartApi();
Integer id = 56; // Integer | Sepet nesnesinin id değeri
try {
    Cart result = apiInstance.cartsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CartApi#cartsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sepet nesnesinin id değeri |

### Return type

[**Cart**](Cart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="cartsPost"></a>
# **cartsPost**
> Cart cartsPost(cart)

Sepet Oluşturma

Yeni bir Sepet oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.api.CartApi;

CartApi apiInstance = new CartApi();
Cart cart = new Cart(); // Cart | Cart nesnesi
try {
    Cart result = apiInstance.cartsPost(cart);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CartApi#cartsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart** | [**Cart**](Cart.md)| Cart nesnesi |

### Return type

[**Cart**](Cart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

