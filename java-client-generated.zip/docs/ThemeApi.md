# ThemeApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**themesGet**](ThemeApi.md#themesGet) | **GET** /themes | Tema Listesi Alma
[**themesIdAssetsGet**](ThemeApi.md#themesIdAssetsGet) | **GET** /themes/{id}/assets | Tema Dosyası Listesi Alma
[**themesIdAssetskeykeyDelete**](ThemeApi.md#themesIdAssetskeykeyDelete) | **DELETE** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Silme
[**themesIdAssetskeykeyGet**](ThemeApi.md#themesIdAssetskeykeyGet) | **GET** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Alma
[**themesIdAssetskeykeyPut**](ThemeApi.md#themesIdAssetskeykeyPut) | **PUT** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Güncelleme
[**themesIdDelete**](ThemeApi.md#themesIdDelete) | **DELETE** /themes/{id} | Tema Silme
[**themesIdGet**](ThemeApi.md#themesIdGet) | **GET** /themes/{id} | Tema Alma
[**themesIdPut**](ThemeApi.md#themesIdPut) | **PUT** /themes/{id} | Tema Güncelleme
[**themesPost**](ThemeApi.md#themesPost) | **POST** /themes | Tema Oluşturma


<a name="themesGet"></a>
# **themesGet**
> Theme themesGet(sort, limit, page, sinceId, status, platform, type)

Tema Listesi Alma

Tema listesi verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ThemeApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ThemeApi apiInstance = new ThemeApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
Integer status = 56; // Integer | Tema durumu
String platform = "platform_example"; // String | Tema platformu
String type = "type_example"; // String | Tema tipi
try {
    Theme result = apiInstance.themesGet(sort, limit, page, sinceId, status, platform, type);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ThemeApi#themesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] [enum: id, type, status]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **status** | **Integer**| Tema durumu | [optional]
 **platform** | **String**| Tema platformu | [optional]
 **type** | **String**| Tema tipi | [optional]

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesIdAssetsGet"></a>
# **themesIdAssetsGet**
> Asset themesIdAssetsGet(id, key)

Tema Dosyası Listesi Alma

Tema Dosyası listesi verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ThemeApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ThemeApi apiInstance = new ThemeApi();
Integer id = 56; // Integer | Tema nesnesinin id değeri
String key = "key_example"; // String | Tema Dosyası nesnesi anahtar değeri.
try {
    Asset result = apiInstance.themesIdAssetsGet(id, key);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ThemeApi#themesIdAssetsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tema nesnesinin id değeri |
 **key** | **String**| Tema Dosyası nesnesi anahtar değeri. | [optional]

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesIdAssetskeykeyDelete"></a>
# **themesIdAssetskeykeyDelete**
> themesIdAssetskeykeyDelete(id, key)

Tema Dosyası Silme

Kalıcı olarak ilgili Tema Dosyasını siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ThemeApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ThemeApi apiInstance = new ThemeApi();
Integer id = 56; // Integer | Tema nesnesinin id değeri
String key = "key_example"; // String | Tema Dosyası nesnesi anahtar değeri.
try {
    apiInstance.themesIdAssetskeykeyDelete(id, key);
} catch (ApiException e) {
    System.err.println("Exception when calling ThemeApi#themesIdAssetskeykeyDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tema nesnesinin id değeri |
 **key** | **String**| Tema Dosyası nesnesi anahtar değeri. |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesIdAssetskeykeyGet"></a>
# **themesIdAssetskeykeyGet**
> Asset themesIdAssetskeykeyGet(id, key)

Tema Dosyası Alma

İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ThemeApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ThemeApi apiInstance = new ThemeApi();
Integer id = 56; // Integer | Tema nesnesinin id değeri
String key = "key_example"; // String | Tema Dosyası nesnesi anahtar değeri.
try {
    Asset result = apiInstance.themesIdAssetskeykeyGet(id, key);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ThemeApi#themesIdAssetskeykeyGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tema nesnesinin id değeri |
 **key** | **String**| Tema Dosyası nesnesi anahtar değeri. |

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesIdAssetskeykeyPut"></a>
# **themesIdAssetskeykeyPut**
> Asset themesIdAssetskeykeyPut(id, theme, asset)

Tema Dosyası Güncelleme

Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ThemeApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ThemeApi apiInstance = new ThemeApi();
Integer id = 56; // Integer | Tema nesnesinin id değeri
Theme theme = new Theme(); // Theme | Theme nesnesi
Asset asset = new Asset(); // Asset | Asset nesnesi
try {
    Asset result = apiInstance.themesIdAssetskeykeyPut(id, theme, asset);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ThemeApi#themesIdAssetskeykeyPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tema nesnesinin id değeri |
 **theme** | [**Theme**](Theme.md)| Theme nesnesi |
 **asset** | [**Asset**](Asset.md)| Asset nesnesi |

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesIdDelete"></a>
# **themesIdDelete**
> themesIdDelete(id)

Tema Silme

Kalıcı olarak ilgili Temayı siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ThemeApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ThemeApi apiInstance = new ThemeApi();
Integer id = 56; // Integer | Tema nesnesinin id değeri
try {
    apiInstance.themesIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ThemeApi#themesIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tema nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesIdGet"></a>
# **themesIdGet**
> Theme themesIdGet(id)

Tema Alma

İlgili Temayı getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ThemeApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ThemeApi apiInstance = new ThemeApi();
Integer id = 56; // Integer | Tema nesnesinin id değeri
try {
    Theme result = apiInstance.themesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ThemeApi#themesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tema nesnesinin id değeri |

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesIdPut"></a>
# **themesIdPut**
> Theme themesIdPut(id, theme)

Tema Güncelleme

İlgili Temayı günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ThemeApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ThemeApi apiInstance = new ThemeApi();
Integer id = 56; // Integer | Tema nesnesinin id değeri
Theme theme = new Theme(); // Theme | Theme nesnesi
try {
    Theme result = apiInstance.themesIdPut(id, theme);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ThemeApi#themesIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tema nesnesinin id değeri |
 **theme** | [**Theme**](Theme.md)| Theme nesnesi |

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesPost"></a>
# **themesPost**
> Theme themesPost(theme)

Tema Oluşturma

Yeni bir tema oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ThemeApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ThemeApi apiInstance = new ThemeApi();
Theme theme = new Theme(); // Theme | Theme nesnesi
try {
    Theme result = apiInstance.themesPost(theme);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ThemeApi#themesPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **theme** | [**Theme**](Theme.md)| Theme nesnesi |

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

