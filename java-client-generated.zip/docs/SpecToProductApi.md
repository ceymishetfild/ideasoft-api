# SpecToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specToProductsGet**](SpecToProductApi.md#specToProductsGet) | **GET** /spec_to_products | Ürün Özellik Ürün Bağı Listesi Alma
[**specToProductsIdDelete**](SpecToProductApi.md#specToProductsIdDelete) | **DELETE** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Silme
[**specToProductsIdGet**](SpecToProductApi.md#specToProductsIdGet) | **GET** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Alma
[**specToProductsIdPut**](SpecToProductApi.md#specToProductsIdPut) | **PUT** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Güncelleme
[**specToProductsPost**](SpecToProductApi.md#specToProductsPost) | **POST** /spec_to_products | Ürün Özellik Ürün Bağı Oluşturma


<a name="specToProductsGet"></a>
# **specToProductsGet**
> SpecToProduct specToProductsGet(sort, limit, page, sinceId, ids, product, specGroup, specName, specValue)

Ürün Özellik Ürün Bağı Listesi Alma

Ürün Özellik Ürün Bağı listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SpecToProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

SpecToProductApi apiInstance = new SpecToProductApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
Integer product = 56; // Integer | Ürün id
Integer specGroup = 56; // Integer | Ürün özellik grubu id
Integer specName = 56; // Integer | Ürün özellik id
Integer specValue = 56; // Integer | Ürün özellik değeri id
try {
    SpecToProduct result = apiInstance.specToProductsGet(sort, limit, page, sinceId, ids, product, specGroup, specName, specValue);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecToProductApi#specToProductsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **product** | **Integer**| Ürün id | [optional]
 **specGroup** | **Integer**| Ürün özellik grubu id | [optional]
 **specName** | **Integer**| Ürün özellik id | [optional]
 **specValue** | **Integer**| Ürün özellik değeri id | [optional]

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specToProductsIdDelete"></a>
# **specToProductsIdDelete**
> specToProductsIdDelete(id)

Ürün Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SpecToProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

SpecToProductApi apiInstance = new SpecToProductApi();
Integer id = 56; // Integer | Ürün Özellik Ürün Bağı nesnesinin id değeri
try {
    apiInstance.specToProductsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecToProductApi#specToProductsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Ürün Bağı nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specToProductsIdGet"></a>
# **specToProductsIdGet**
> SpecToProduct specToProductsIdGet(id)

Ürün Özellik Ürün Bağı Alma

İlgili Ürün Özellik Ürün Bağını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SpecToProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

SpecToProductApi apiInstance = new SpecToProductApi();
Integer id = 56; // Integer | Ürün Özellik Ürün Bağı nesnesinin id değeri
try {
    SpecToProduct result = apiInstance.specToProductsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecToProductApi#specToProductsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Ürün Bağı nesnesinin id değeri |

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specToProductsIdPut"></a>
# **specToProductsIdPut**
> SpecToProduct specToProductsIdPut(id, specToProduct)

Ürün Özellik Ürün Bağı Güncelleme

İlgili Ürün Özellik Ürün Bağını günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SpecToProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

SpecToProductApi apiInstance = new SpecToProductApi();
Integer id = 56; // Integer | Ürün Özellik Ürün Bağı nesnesinin id değeri
SpecToProduct specToProduct = new SpecToProduct(); // SpecToProduct |  nesnesi
try {
    SpecToProduct result = apiInstance.specToProductsIdPut(id, specToProduct);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecToProductApi#specToProductsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Ürün Bağı nesnesinin id değeri |
 **specToProduct** | [**SpecToProduct**](SpecToProduct.md)|  nesnesi |

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specToProductsPost"></a>
# **specToProductsPost**
> SpecToProduct specToProductsPost(specToProduct)

Ürün Özellik Ürün Bağı Oluşturma

Yeni bir Ürün Özellik Ürün Bağı oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SpecToProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

SpecToProductApi apiInstance = new SpecToProductApi();
SpecToProduct specToProduct = new SpecToProduct(); // SpecToProduct |  nesnesi
try {
    SpecToProduct result = apiInstance.specToProductsPost(specToProduct);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SpecToProductApi#specToProductsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specToProduct** | [**SpecToProduct**](SpecToProduct.md)|  nesnesi |

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

