# OrderUserNoteApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**orderUserNotesGet**](OrderUserNoteApi.md#orderUserNotesGet) | **GET** /order_user_notes | Sipariş Yönetici Notu Listesi Alma
[**orderUserNotesIdDelete**](OrderUserNoteApi.md#orderUserNotesIdDelete) | **DELETE** /order_user_notes/{id} | Sipariş Yönetici Notu Silme
[**orderUserNotesIdGet**](OrderUserNoteApi.md#orderUserNotesIdGet) | **GET** /order_user_notes/{id} | Sipariş Yönetici Notu Alma
[**orderUserNotesIdPut**](OrderUserNoteApi.md#orderUserNotesIdPut) | **PUT** /order_user_notes/{id} | Sipariş Yönetici Notu Güncelleme
[**orderUserNotesPost**](OrderUserNoteApi.md#orderUserNotesPost) | **POST** /order_user_notes | Sipariş Yönetici Notu Oluşturma


<a name="orderUserNotesGet"></a>
# **orderUserNotesGet**
> OrderUserNote orderUserNotesGet(sort, limit, page, sinceId, ids, order, userEmail, startDate, endDate, startUpdatedAt, endUpdatedAt)

Sipariş Yönetici Notu Listesi Alma

Sipariş Yönetici Notu listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrderUserNoteApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OrderUserNoteApi apiInstance = new OrderUserNoteApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
Integer order = 56; // Integer | Sipariş id
String userEmail = "userEmail_example"; // String | Yönetici e-mail
LocalDate startDate = new LocalDate(); // LocalDate | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
LocalDate startUpdatedAt = new LocalDate(); // LocalDate | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
try {
    OrderUserNote result = apiInstance.orderUserNotesGet(sort, limit, page, sinceId, ids, order, userEmail, startDate, endDate, startUpdatedAt, endUpdatedAt);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderUserNoteApi#orderUserNotesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **order** | **Integer**| Sipariş id | [optional]
 **userEmail** | **String**| Yönetici e-mail | [optional]
 **startDate** | **LocalDate**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **LocalDate**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderUserNotesIdDelete"></a>
# **orderUserNotesIdDelete**
> orderUserNotesIdDelete(id)

Sipariş Yönetici Notu Silme

Kalıcı olarak ilgili Sipariş Yönetici Notunu siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrderUserNoteApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OrderUserNoteApi apiInstance = new OrderUserNoteApi();
Integer id = 56; // Integer | Sipariş Yönetici Notu nesnesinin id değeri
try {
    apiInstance.orderUserNotesIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderUserNoteApi#orderUserNotesIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Yönetici Notu nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderUserNotesIdGet"></a>
# **orderUserNotesIdGet**
> OrderUserNote orderUserNotesIdGet(id)

Sipariş Yönetici Notu Alma

İlgili Sipariş Yönetici Notunu getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrderUserNoteApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OrderUserNoteApi apiInstance = new OrderUserNoteApi();
Integer id = 56; // Integer | Sipariş Yönetici Notu nesnesinin id değeri
try {
    OrderUserNote result = apiInstance.orderUserNotesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderUserNoteApi#orderUserNotesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Yönetici Notu nesnesinin id değeri |

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderUserNotesIdPut"></a>
# **orderUserNotesIdPut**
> OrderUserNote orderUserNotesIdPut(id, orderUserNote)

Sipariş Yönetici Notu Güncelleme

İlgili Sipariş Yönetici Notunu günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrderUserNoteApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OrderUserNoteApi apiInstance = new OrderUserNoteApi();
Integer id = 56; // Integer | Sipariş Yönetici Notu nesnesinin id değeri
OrderUserNote orderUserNote = new OrderUserNote(); // OrderUserNote |  nesnesi
try {
    OrderUserNote result = apiInstance.orderUserNotesIdPut(id, orderUserNote);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderUserNoteApi#orderUserNotesIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Yönetici Notu nesnesinin id değeri |
 **orderUserNote** | [**OrderUserNote**](OrderUserNote.md)|  nesnesi |

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderUserNotesPost"></a>
# **orderUserNotesPost**
> OrderUserNote orderUserNotesPost(orderUserNote)

Sipariş Yönetici Notu Oluşturma

Yeni bir Sipariş Yönetici Notu oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrderUserNoteApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OrderUserNoteApi apiInstance = new OrderUserNoteApi();
OrderUserNote orderUserNote = new OrderUserNote(); // OrderUserNote |  nesnesi
try {
    OrderUserNote result = apiInstance.orderUserNotesPost(orderUserNote);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderUserNoteApi#orderUserNotesPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orderUserNote** | [**OrderUserNote**](OrderUserNote.md)|  nesnesi |

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

