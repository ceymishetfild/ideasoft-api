# ShippingProviderApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shippingProvidersGet**](ShippingProviderApi.md#shippingProvidersGet) | **GET** /shipping_providers | Teslimat Hizmeti Sağlayıcısı Listesi Alma
[**shippingProvidersIdGet**](ShippingProviderApi.md#shippingProvidersIdGet) | **GET** /shipping_providers/{id} | Teslimat Hizmeti Sağlayıcısı Alma


<a name="shippingProvidersGet"></a>
# **shippingProvidersGet**
> ShippingProvider shippingProvidersGet(sort, limit, page, sinceId, code, name)

Teslimat Hizmeti Sağlayıcısı Listesi Alma

Teslimat Hizmeti Sağlayıcısı listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShippingProviderApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ShippingProviderApi apiInstance = new ShippingProviderApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String code = "code_example"; // String | Kargo firması kodu
String name = "name_example"; // String | Kargo firması adı
try {
    ShippingProvider result = apiInstance.shippingProvidersGet(sort, limit, page, sinceId, code, name);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingProviderApi#shippingProvidersGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **code** | **String**| Kargo firması kodu | [optional]
 **name** | **String**| Kargo firması adı | [optional]

### Return type

[**ShippingProvider**](ShippingProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingProvidersIdGet"></a>
# **shippingProvidersIdGet**
> ShippingProvider shippingProvidersIdGet(id)

Teslimat Hizmeti Sağlayıcısı Alma

İlgili Teslimat Hizmeti Sağlayıcısını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShippingProviderApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ShippingProviderApi apiInstance = new ShippingProviderApi();
Integer id = 56; // Integer | Teslimat Hizmeti Sağlayıcısı nesnesinin id değeri
try {
    ShippingProvider result = apiInstance.shippingProvidersIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShippingProviderApi#shippingProvidersIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Teslimat Hizmeti Sağlayıcısı nesnesinin id değeri |

### Return type

[**ShippingProvider**](ShippingProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

