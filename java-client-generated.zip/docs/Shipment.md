
# Shipment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Teslimat nesnesi kimlik değeri. |  [optional]
**barcode** | **String** | Teslimat barkodu. |  [optional]
**waybillNo** | **String** | Teslimat fatura numarası. |  [optional]
**invoiceKey** | **String** | Teslimat irsaliye makbuzu numarası. |  [optional]
**cargoOffice** | **String** | Teslimatın kargo şubesi |  [optional]
**code** | **String** | Teslimat kodu. Kargo takip kodu. |  [optional]
**deliveryType** | **String** | Teslimat tipi |  [optional]
**invoiceIncluded** | [**InvoiceIncludedEnum**](#InvoiceIncludedEnum) | Faturanın pakete dahillik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Dahil.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Dahil değil.&lt;br&gt;&lt;/div&gt; |  [optional]
**payAtDoorAmount** | **Float** | Kapıda ödeme hizmeti bedeli. |  [optional]
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) | Teslimat nesnesinin oluşturulma zamanı. |  [optional]
**status** | [**StatusEnum**](#StatusEnum) | Teslimat nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**order** | [**Order**](Order.md) |  |  [optional]


<a name="InvoiceIncludedEnum"></a>
## Enum: InvoiceIncludedEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;


<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----
NUMBER_0 | 0
NUMBER_1 | 1



