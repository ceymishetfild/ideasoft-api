# CacheApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cacheDelete**](CacheApi.md#cacheDelete) | **DELETE** /cache | Önbellek Silme


<a name="cacheDelete"></a>
# **cacheDelete**
> cacheDelete()

Önbellek Silme

Kalıcı olarak Önbelleği siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.CacheApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

CacheApi apiInstance = new CacheApi();
try {
    apiInstance.cacheDelete();
} catch (ApiException e) {
    System.err.println("Exception when calling CacheApi#cacheDelete");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

