
# CartItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sepet kalemi nesnesi kimlik değeri. |  [optional]
**parentProductId** | **Integer** | Ana ürünün benzersiz rakamsal kimlik değeri. |  [optional]
**quantity** | **Float** | Sepetteki kalem adedi. | 
**categoryId** | **Integer** | Sepetteki kaleme ait kategorinin benzersiz kimlik değeri. |  [optional]
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) | Sepet kalemi nesnesinin oluşturulma zamanı. |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) | Sepet kalemi nesnesinin güncellenme zamanı. |  [optional]
**cart** | [**Cart**](Cart.md) | Sepet nesnesi. | 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 
**attributes** | [**List&lt;CartItemAttribute&gt;**](CartItemAttribute.md) | Sepet kalemi özelliği barındıran liste. |  [optional]



