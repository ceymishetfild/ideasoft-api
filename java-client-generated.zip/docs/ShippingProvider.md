
# ShippingProvider

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Teslimat hizmeti sağlayıcısı nesnesi kimlik değeri. |  [optional]
**code** | **String** | Teslimat hizmeti sağlayıcısı kodu. Benzersiz olmalıdır. | 
**name** | **String** | Teslimat hizmeti sağlayıcısı nesnesi için isim değeri. | 
**trackingUrl** | **String** | Kargo takip url. | 
**trackingFormMethod** | [**TrackingFormMethodEnum**](#TrackingFormMethodEnum) | Kargo takip formu almak için kullanılacak method.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;get&lt;/code&gt; : GET methodu.&lt;br&gt;&lt;code&gt;post&lt;/code&gt; : POST methodu.&lt;br&gt;&lt;/div&gt; |  [optional]
**payload** | **String** | İlgili kargo takip formu almak için kullanılacak yük. |  [optional]
**settings** | [**List&lt;ShippingProviderSetting&gt;**](ShippingProviderSetting.md) | Teslimat hizmeti sağlayıcısı için ayarlar. |  [optional]


<a name="TrackingFormMethodEnum"></a>
## Enum: TrackingFormMethodEnum
Name | Value
---- | -----
GET | &quot;get&quot;
POST | &quot;post&quot;



