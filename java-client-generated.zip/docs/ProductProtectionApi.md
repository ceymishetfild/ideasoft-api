# ProductProtectionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productProtectionsGet**](ProductProtectionApi.md#productProtectionsGet) | **GET** /product_protections | Entegrasyon Seçeneği Listesi Alma
[**productProtectionsIdDelete**](ProductProtectionApi.md#productProtectionsIdDelete) | **DELETE** /product_protections/{id} | Entegrasyon Seçeneği Silme
[**productProtectionsIdGet**](ProductProtectionApi.md#productProtectionsIdGet) | **GET** /product_protections/{id} | Entegrasyon Seçeneği Alma
[**productProtectionsIdPut**](ProductProtectionApi.md#productProtectionsIdPut) | **PUT** /product_protections/{id} | Entegrasyon Seçeneği Güncelleme
[**productProtectionsPost**](ProductProtectionApi.md#productProtectionsPost) | **POST** /product_protections | Entegrasyon Seçeneği Oluşturma


<a name="productProtectionsGet"></a>
# **productProtectionsGet**
> ProductProtection productProtectionsGet(sort, limit, page, sinceId, isPriceProtected, isStockProtected, product)

Entegrasyon Seçeneği Listesi Alma

Entegrasyon Seçeneği listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductProtectionApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductProtectionApi apiInstance = new ProductProtectionApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
Integer isPriceProtected = 56; // Integer | Fiyat korumalı ürünleri listeler<code>0</code><br><code>1</code>
Integer isStockProtected = 56; // Integer | Stok korumalı ürünleri listeler<code>0</code><br><code>1</code>
Integer product = 56; // Integer | Ürün id
try {
    ProductProtection result = apiInstance.productProtectionsGet(sort, limit, page, sinceId, isPriceProtected, isStockProtected, product);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductProtectionApi#productProtectionsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **isPriceProtected** | **Integer**| Fiyat korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] [enum: 0, 1]
 **isStockProtected** | **Integer**| Stok korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] [enum: 0, 1]
 **product** | **Integer**| Ürün id | [optional]

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productProtectionsIdDelete"></a>
# **productProtectionsIdDelete**
> productProtectionsIdDelete(id)

Entegrasyon Seçeneği Silme

Kalıcı olarak ilgili Entegrasyon Seçeneğini siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductProtectionApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductProtectionApi apiInstance = new ProductProtectionApi();
Integer id = 56; // Integer | Entegrasyon Seçeneği nesnesinin id değeri
try {
    apiInstance.productProtectionsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductProtectionApi#productProtectionsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Entegrasyon Seçeneği nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productProtectionsIdGet"></a>
# **productProtectionsIdGet**
> ProductProtection productProtectionsIdGet(id)

Entegrasyon Seçeneği Alma

İlgili Entegrasyon Seçeneğini getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductProtectionApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductProtectionApi apiInstance = new ProductProtectionApi();
Integer id = 56; // Integer | Entegrasyon Seçeneği nesnesinin id değeri
try {
    ProductProtection result = apiInstance.productProtectionsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductProtectionApi#productProtectionsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Entegrasyon Seçeneği nesnesinin id değeri |

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productProtectionsIdPut"></a>
# **productProtectionsIdPut**
> ProductProtection productProtectionsIdPut(id, productProtection)

Entegrasyon Seçeneği Güncelleme

İlgili Entegrasyon Seçeneğini günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductProtectionApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductProtectionApi apiInstance = new ProductProtectionApi();
Integer id = 56; // Integer | Entegrasyon Seçeneği nesnesinin id değeri
ProductProtection productProtection = new ProductProtection(); // ProductProtection | ProductProtection nesnesi
try {
    ProductProtection result = apiInstance.productProtectionsIdPut(id, productProtection);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductProtectionApi#productProtectionsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Entegrasyon Seçeneği nesnesinin id değeri |
 **productProtection** | [**ProductProtection**](ProductProtection.md)| ProductProtection nesnesi |

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productProtectionsPost"></a>
# **productProtectionsPost**
> ProductProtection productProtectionsPost(productProtection)

Entegrasyon Seçeneği Oluşturma

Yeni bir Entegrasyon Seçeneği oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductProtectionApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductProtectionApi apiInstance = new ProductProtectionApi();
ProductProtection productProtection = new ProductProtection(); // ProductProtection | ProductProtection nesnesi
try {
    ProductProtection result = apiInstance.productProtectionsPost(productProtection);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductProtectionApi#productProtectionsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productProtection** | [**ProductProtection**](ProductProtection.md)| ProductProtection nesnesi |

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

