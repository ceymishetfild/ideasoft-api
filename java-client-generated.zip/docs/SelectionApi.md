# SelectionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selectionsGet**](SelectionApi.md#selectionsGet) | **GET** /selections | Ek Özellik Listesi Alma
[**selectionsIdDelete**](SelectionApi.md#selectionsIdDelete) | **DELETE** /selections/{id} | Ek Özellik Silme
[**selectionsIdGet**](SelectionApi.md#selectionsIdGet) | **GET** /selections/{id} | Ek Özellik Alma
[**selectionsIdPut**](SelectionApi.md#selectionsIdPut) | **PUT** /selections/{id} | Ek Özellik Güncelleme
[**selectionsPost**](SelectionApi.md#selectionsPost) | **POST** /selections | Ek Özellik Oluşturma


<a name="selectionsGet"></a>
# **selectionsGet**
> Selection selectionsGet(sort, limit, page, sinceId, ids, title, selectionGroup)

Ek Özellik Listesi Alma

Ek Özellik listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SelectionApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

SelectionApi apiInstance = new SelectionApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String title = "title_example"; // String | Ek Özellik başlığı
Integer selectionGroup = 56; // Integer | Ek Özellik Grubu id
try {
    Selection result = apiInstance.selectionsGet(sort, limit, page, sinceId, ids, title, selectionGroup);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SelectionApi#selectionsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **title** | **String**| Ek Özellik başlığı | [optional]
 **selectionGroup** | **Integer**| Ek Özellik Grubu id | [optional]

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionsIdDelete"></a>
# **selectionsIdDelete**
> selectionsIdDelete(id)

Ek Özellik Silme

Kalıcı olarak ilgili Ek Özelliği siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SelectionApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

SelectionApi apiInstance = new SelectionApi();
Integer id = 56; // Integer | Ek Özellik nesnesinin id değeri
try {
    apiInstance.selectionsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling SelectionApi#selectionsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Özellik nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionsIdGet"></a>
# **selectionsIdGet**
> Selection selectionsIdGet(id)

Ek Özellik Alma

İlgili Ek Özelliği getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SelectionApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

SelectionApi apiInstance = new SelectionApi();
Integer id = 56; // Integer | Ek Özellik nesnesinin id değeri
try {
    Selection result = apiInstance.selectionsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SelectionApi#selectionsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Özellik nesnesinin id değeri |

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionsIdPut"></a>
# **selectionsIdPut**
> Selection selectionsIdPut(id, selection)

Ek Özellik Güncelleme

İlgili Ek Özelliği günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SelectionApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

SelectionApi apiInstance = new SelectionApi();
Integer id = 56; // Integer | Ek Özellik nesnesinin id değeri
Selection selection = new Selection(); // Selection |  nesnesi
try {
    Selection result = apiInstance.selectionsIdPut(id, selection);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SelectionApi#selectionsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Özellik nesnesinin id değeri |
 **selection** | [**Selection**](Selection.md)|  nesnesi |

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionsPost"></a>
# **selectionsPost**
> Selection selectionsPost(selection)

Ek Özellik Oluşturma

Yeni bir Ek Özellik oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SelectionApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

SelectionApi apiInstance = new SelectionApi();
Selection selection = new Selection(); // Selection |  nesnesi
try {
    Selection result = apiInstance.selectionsPost(selection);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SelectionApi#selectionsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selection** | [**Selection**](Selection.md)|  nesnesi |

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

