# ProductCommentApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productCommentsGet**](ProductCommentApi.md#productCommentsGet) | **GET** /product_comments | Ürün Yorumları Listesi Alma
[**productCommentsIdDelete**](ProductCommentApi.md#productCommentsIdDelete) | **DELETE** /product_comments/{id} | Ürün Yorumu Silme
[**productCommentsIdGet**](ProductCommentApi.md#productCommentsIdGet) | **GET** /product_comments/{id} | Ürün Yorumu Alma
[**productCommentsIdPut**](ProductCommentApi.md#productCommentsIdPut) | **PUT** /product_comments/{id} | Ürün Yorumu Güncelleme
[**productCommentsPost**](ProductCommentApi.md#productCommentsPost) | **POST** /product_comments | Ürün Yorumu Oluşturma


<a name="productCommentsGet"></a>
# **productCommentsGet**
> ProductComment productCommentsGet(sort, limit, page, sinceId, status, isAnonymous, member, product, startDate, endDate, startUpdatedAt, endUpdatedAt)

Ürün Yorumları Listesi Alma

Ürün Yorumları listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductCommentApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductCommentApi apiInstance = new ProductCommentApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
String status = "status_example"; // String | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
String isAnonymous = "isAnonymous_example"; // String | IsAnonymous şu değerleri alabilir: <br><code>0</code> : Anonim değil<br><code>1</code> : Anonim
Integer member = 56; // Integer | Üye id
Integer product = 56; // Integer | Ürün id
LocalDate startDate = new LocalDate(); // LocalDate | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
LocalDate startUpdatedAt = new LocalDate(); // LocalDate | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
try {
    ProductComment result = apiInstance.productCommentsGet(sort, limit, page, sinceId, status, isAnonymous, member, product, startDate, endDate, startUpdatedAt, endUpdatedAt);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductCommentApi#productCommentsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional]
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] [enum: 0, 1]
 **isAnonymous** | **String**| IsAnonymous şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Anonim değil&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Anonim | [optional] [enum: 0, 1]
 **member** | **Integer**| Üye id | [optional]
 **product** | **Integer**| Ürün id | [optional]
 **startDate** | **LocalDate**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **LocalDate**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productCommentsIdDelete"></a>
# **productCommentsIdDelete**
> productCommentsIdDelete(id)

Ürün Yorumu Silme

Kalıcı olarak ilgili Ürün Yorumunu siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductCommentApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductCommentApi apiInstance = new ProductCommentApi();
Integer id = 56; // Integer | Ürün Yorumu nesnesinin id değeri
try {
    apiInstance.productCommentsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductCommentApi#productCommentsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Yorumu nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productCommentsIdGet"></a>
# **productCommentsIdGet**
> ProductComment productCommentsIdGet(id)

Ürün Yorumu Alma

İlgili Ürün Yorumunu getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductCommentApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductCommentApi apiInstance = new ProductCommentApi();
Integer id = 56; // Integer | Ürün Yorumu nesnesinin id değeri
try {
    ProductComment result = apiInstance.productCommentsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductCommentApi#productCommentsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Yorumu nesnesinin id değeri |

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productCommentsIdPut"></a>
# **productCommentsIdPut**
> ProductComment productCommentsIdPut(id, productComment)

Ürün Yorumu Güncelleme

İlgili Ürün Yorumunu günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductCommentApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductCommentApi apiInstance = new ProductCommentApi();
Integer id = 56; // Integer | Ürün Yorumu nesnesinin id değeri
ProductComment productComment = new ProductComment(); // ProductComment |  nesnesi
try {
    ProductComment result = apiInstance.productCommentsIdPut(id, productComment);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductCommentApi#productCommentsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Yorumu nesnesinin id değeri |
 **productComment** | [**ProductComment**](ProductComment.md)|  nesnesi |

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productCommentsPost"></a>
# **productCommentsPost**
> ProductComment productCommentsPost(productComment)

Ürün Yorumu Oluşturma

Yeni bir Ürün Yorumu oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductCommentApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductCommentApi apiInstance = new ProductCommentApi();
ProductComment productComment = new ProductComment(); // ProductComment |  nesnesi
try {
    ProductComment result = apiInstance.productCommentsPost(productComment);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductCommentApi#productCommentsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productComment** | [**ProductComment**](ProductComment.md)|  nesnesi |

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

