# ExtraInfoToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extraInfoToProductsGet**](ExtraInfoToProductApi.md#extraInfoToProductsGet) | **GET** /extra_info_to_products | Ek Bilgi Ürün Bağı Listesi Alma
[**extraInfoToProductsIdDelete**](ExtraInfoToProductApi.md#extraInfoToProductsIdDelete) | **DELETE** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Silme
[**extraInfoToProductsIdGet**](ExtraInfoToProductApi.md#extraInfoToProductsIdGet) | **GET** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Alma
[**extraInfoToProductsIdPut**](ExtraInfoToProductApi.md#extraInfoToProductsIdPut) | **PUT** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Güncelleme
[**extraInfoToProductsPost**](ExtraInfoToProductApi.md#extraInfoToProductsPost) | **POST** /extra_info_to_products | Ek Bilgi Ürün Bağı Oluşturma


<a name="extraInfoToProductsGet"></a>
# **extraInfoToProductsGet**
> ExtraInfoToProduct extraInfoToProductsGet(sort, limit, page, sinceId, ids, extraInfo, product)

Ek Bilgi Ürün Bağı Listesi Alma

Ek Bilgi Ürün Bağı listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ExtraInfoToProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ExtraInfoToProductApi apiInstance = new ExtraInfoToProductApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
Integer extraInfo = 56; // Integer | Ek bilgi id
Integer product = 56; // Integer | Ürün id
try {
    ExtraInfoToProduct result = apiInstance.extraInfoToProductsGet(sort, limit, page, sinceId, ids, extraInfo, product);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ExtraInfoToProductApi#extraInfoToProductsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **extraInfo** | **Integer**| Ek bilgi id | [optional]
 **product** | **Integer**| Ürün id | [optional]

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfoToProductsIdDelete"></a>
# **extraInfoToProductsIdDelete**
> extraInfoToProductsIdDelete(id)

Ek Bilgi Ürün Bağı Silme

Kalıcı olarak ilgili Ek Bilgi Ürün Bağını siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ExtraInfoToProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ExtraInfoToProductApi apiInstance = new ExtraInfoToProductApi();
Integer id = 56; // Integer | Ek Bilgi Ürün Bağı nesnesinin id değeri
try {
    apiInstance.extraInfoToProductsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ExtraInfoToProductApi#extraInfoToProductsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Bilgi Ürün Bağı nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfoToProductsIdGet"></a>
# **extraInfoToProductsIdGet**
> ExtraInfoToProduct extraInfoToProductsIdGet(id)

Ek Bilgi Ürün Bağı Alma

İlgili Ek Bilgi Ürün Bağını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ExtraInfoToProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ExtraInfoToProductApi apiInstance = new ExtraInfoToProductApi();
Integer id = 56; // Integer | Ek Bilgi Ürün Bağı nesnesinin id değeri
try {
    ExtraInfoToProduct result = apiInstance.extraInfoToProductsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ExtraInfoToProductApi#extraInfoToProductsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Bilgi Ürün Bağı nesnesinin id değeri |

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfoToProductsIdPut"></a>
# **extraInfoToProductsIdPut**
> ExtraInfoToProduct extraInfoToProductsIdPut(id, extraInfoToProduct)

Ek Bilgi Ürün Bağı Güncelleme

İlgili Ek Bilgi Ürün Bağını günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ExtraInfoToProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ExtraInfoToProductApi apiInstance = new ExtraInfoToProductApi();
Integer id = 56; // Integer | Ek Bilgi Ürün Bağı nesnesinin id değeri
ExtraInfoToProduct extraInfoToProduct = new ExtraInfoToProduct(); // ExtraInfoToProduct |  nesnesi
try {
    ExtraInfoToProduct result = apiInstance.extraInfoToProductsIdPut(id, extraInfoToProduct);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ExtraInfoToProductApi#extraInfoToProductsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Bilgi Ürün Bağı nesnesinin id değeri |
 **extraInfoToProduct** | [**ExtraInfoToProduct**](ExtraInfoToProduct.md)|  nesnesi |

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfoToProductsPost"></a>
# **extraInfoToProductsPost**
> ExtraInfoToProduct extraInfoToProductsPost(extraInfoToProduct)

Ek Bilgi Ürün Bağı Oluşturma

Yeni bir Ek Bilgi Ürün Bağı oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ExtraInfoToProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ExtraInfoToProductApi apiInstance = new ExtraInfoToProductApi();
ExtraInfoToProduct extraInfoToProduct = new ExtraInfoToProduct(); // ExtraInfoToProduct |  nesnesi
try {
    ExtraInfoToProduct result = apiInstance.extraInfoToProductsPost(extraInfoToProduct);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ExtraInfoToProductApi#extraInfoToProductsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extraInfoToProduct** | [**ExtraInfoToProduct**](ExtraInfoToProduct.md)|  nesnesi |

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

