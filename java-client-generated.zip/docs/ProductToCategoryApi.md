# ProductToCategoryApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productToCategoriesGet**](ProductToCategoryApi.md#productToCategoriesGet) | **GET** /product_to_categories | Ürün Kategori Bağı Listesi Alma
[**productToCategoriesIdDelete**](ProductToCategoryApi.md#productToCategoriesIdDelete) | **DELETE** /product_to_categories/{id} | Ürün Kategori Bağı Silme
[**productToCategoriesIdGet**](ProductToCategoryApi.md#productToCategoriesIdGet) | **GET** /product_to_categories/{id} | Ürün Kategori Bağı Alma
[**productToCategoriesIdPut**](ProductToCategoryApi.md#productToCategoriesIdPut) | **PUT** /product_to_categories/{id} | Ürün Kategori Bağı Güncelleme
[**productToCategoriesPost**](ProductToCategoryApi.md#productToCategoriesPost) | **POST** /product_to_categories | Ürün Kategori Bağı Oluşturma


<a name="productToCategoriesGet"></a>
# **productToCategoriesGet**
> ProductToCategory productToCategoriesGet(sort, limit, page, sinceId, product, category)

Ürün Kategori Bağı Listesi Alma

Ürün Kategori Bağı listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductToCategoryApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductToCategoryApi apiInstance = new ProductToCategoryApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
Integer product = 56; // Integer | Ürün id
Integer category = 56; // Integer | Kategori id
try {
    ProductToCategory result = apiInstance.productToCategoriesGet(sort, limit, page, sinceId, product, category);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductToCategoryApi#productToCategoriesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **product** | **Integer**| Ürün id | [optional]
 **category** | **Integer**| Kategori id | [optional]

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCategoriesIdDelete"></a>
# **productToCategoriesIdDelete**
> productToCategoriesIdDelete(id)

Ürün Kategori Bağı Silme

Kalıcı olarak ilgili Ürün Kategori Bağını siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductToCategoryApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductToCategoryApi apiInstance = new ProductToCategoryApi();
Integer id = 56; // Integer | Ürün Kategori Bağı nesnesinin id değeri
try {
    apiInstance.productToCategoriesIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductToCategoryApi#productToCategoriesIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Kategori Bağı nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCategoriesIdGet"></a>
# **productToCategoriesIdGet**
> ProductToCategory productToCategoriesIdGet(id)

Ürün Kategori Bağı Alma

İlgili Ürün Kategori Bağını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductToCategoryApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductToCategoryApi apiInstance = new ProductToCategoryApi();
Integer id = 56; // Integer | Ürün Kategori Bağı nesnesinin id değeri
try {
    ProductToCategory result = apiInstance.productToCategoriesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductToCategoryApi#productToCategoriesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Kategori Bağı nesnesinin id değeri |

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCategoriesIdPut"></a>
# **productToCategoriesIdPut**
> ProductToCategory productToCategoriesIdPut(id, productToCategory)

Ürün Kategori Bağı Güncelleme

İlgili Ürün Kategori Bağını günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductToCategoryApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductToCategoryApi apiInstance = new ProductToCategoryApi();
Integer id = 56; // Integer | Ürün Kategori Bağı nesnesinin id değeri
ProductToCategory productToCategory = new ProductToCategory(); // ProductToCategory | ProductToCategory nesnesi
try {
    ProductToCategory result = apiInstance.productToCategoriesIdPut(id, productToCategory);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductToCategoryApi#productToCategoriesIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Kategori Bağı nesnesinin id değeri |
 **productToCategory** | [**ProductToCategory**](ProductToCategory.md)| ProductToCategory nesnesi |

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCategoriesPost"></a>
# **productToCategoriesPost**
> ProductToCategory productToCategoriesPost(productToCategory)

Ürün Kategori Bağı Oluşturma

Yeni bir Ürün Kategori Bağı oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductToCategoryApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductToCategoryApi apiInstance = new ProductToCategoryApi();
ProductToCategory productToCategory = new ProductToCategory(); // ProductToCategory | ProductToCategory nesnesi
try {
    ProductToCategory result = apiInstance.productToCategoriesPost(productToCategory);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductToCategoryApi#productToCategoriesPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productToCategory** | [**ProductToCategory**](ProductToCategory.md)| ProductToCategory nesnesi |

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

