
# OrderItemCustomization

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sipariş kalemi özelleştirme kimlik değeri. |  [optional]
**productCustomizationGroupId** | **Integer** | Ürün özelleştirme grubu nesnesi kimlik değeri. |  [optional]
**productCustomizationGroupName** | **String** | Ürün özelleştirme grubu nesnesinin grup adı. |  [optional]
**productCustomizationGroupSortOrder** | **Integer** | Ürün özelleştirme grubu nesnesinin sıralaması. |  [optional]
**productCustomizationFieldId** | **Integer** | Ürün özelleştirme nesnesi kimlik değeri.. |  [optional]
**productCustomizationFieldType** | **String** | Ürün özelleştirme nesnesinin alan tipi. |  [optional]
**productCustomizationFieldName** | **String** | Ürün özelleştirme nesnesinin alan adı. |  [optional]
**productCustomizationFieldValue** | **String** | Ürün özelleştirme nesnesinin değeri. |  [optional]
**cartItemAttributeId** | **Integer** | Sepet kalemi özelliği nesnesi kimlik değeri. |  [optional]



