
# FavouritedProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Favori ürün nesnesi kimlik değeri. |  [optional]
**member** | [**Member**](Member.md) |  |  [optional]
**product** | [**Product**](Product.md) |  |  [optional]



