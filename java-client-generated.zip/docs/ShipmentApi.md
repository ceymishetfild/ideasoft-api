# ShipmentApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipmentsGet**](ShipmentApi.md#shipmentsGet) | **GET** /shipments | Teslimat Listesi Alma
[**shipmentsIdDelete**](ShipmentApi.md#shipmentsIdDelete) | **DELETE** /shipments/{id} | Teslimat Silme
[**shipmentsIdGet**](ShipmentApi.md#shipmentsIdGet) | **GET** /shipments/{id} | Teslimat Alma
[**shipmentsIdPut**](ShipmentApi.md#shipmentsIdPut) | **PUT** /shipments/{id} | Teslimat Güncelleme
[**shipmentsPost**](ShipmentApi.md#shipmentsPost) | **POST** /shipments | Teslimat Oluşturma


<a name="shipmentsGet"></a>
# **shipmentsGet**
> Shipment shipmentsGet(sort, limit, page, sinceId, ids, code, invoiceKey, barcode, order, startDate, endDate, startUpdatedAt, endUpdatedAt)

Teslimat Listesi Alma

Teslimat listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShipmentApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ShipmentApi apiInstance = new ShipmentApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String code = "code_example"; // String | Teslimat kodu
String invoiceKey = "invoiceKey_example"; // String | Teslimat fatura anahtarı
String barcode = "barcode_example"; // String | Teslimat barkodu
Integer order = 56; // Integer | Sipariş id
LocalDate startDate = new LocalDate(); // LocalDate | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
LocalDate startUpdatedAt = new LocalDate(); // LocalDate | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
try {
    Shipment result = apiInstance.shipmentsGet(sort, limit, page, sinceId, ids, code, invoiceKey, barcode, order, startDate, endDate, startUpdatedAt, endUpdatedAt);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShipmentApi#shipmentsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **code** | **String**| Teslimat kodu | [optional]
 **invoiceKey** | **String**| Teslimat fatura anahtarı | [optional]
 **barcode** | **String**| Teslimat barkodu | [optional]
 **order** | **Integer**| Sipariş id | [optional]
 **startDate** | **LocalDate**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **LocalDate**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shipmentsIdDelete"></a>
# **shipmentsIdDelete**
> shipmentsIdDelete(id)

Teslimat Silme

Kalıcı olarak ilgili Teslimatı siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShipmentApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ShipmentApi apiInstance = new ShipmentApi();
Integer id = 56; // Integer | Teslimat nesnesinin id değeri
try {
    apiInstance.shipmentsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ShipmentApi#shipmentsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Teslimat nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shipmentsIdGet"></a>
# **shipmentsIdGet**
> Shipment shipmentsIdGet(id)

Teslimat Alma

İlgili Teslimatı getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShipmentApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ShipmentApi apiInstance = new ShipmentApi();
Integer id = 56; // Integer | Teslimat nesnesinin id değeri
try {
    Shipment result = apiInstance.shipmentsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShipmentApi#shipmentsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Teslimat nesnesinin id değeri |

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shipmentsIdPut"></a>
# **shipmentsIdPut**
> Shipment shipmentsIdPut(id, shipment)

Teslimat Güncelleme

İlgili Teslimatı günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShipmentApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ShipmentApi apiInstance = new ShipmentApi();
Integer id = 56; // Integer | Teslimat nesnesinin id değeri
Shipment shipment = new Shipment(); // Shipment |  nesnesi
try {
    Shipment result = apiInstance.shipmentsIdPut(id, shipment);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShipmentApi#shipmentsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Teslimat nesnesinin id değeri |
 **shipment** | [**Shipment**](Shipment.md)|  nesnesi |

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shipmentsPost"></a>
# **shipmentsPost**
> Shipment shipmentsPost(shipment)

Teslimat Oluşturma

Yeni bir Teslimat oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShipmentApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ShipmentApi apiInstance = new ShipmentApi();
Shipment shipment = new Shipment(); // Shipment |  nesnesi
try {
    Shipment result = apiInstance.shipmentsPost(shipment);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShipmentApi#shipmentsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipment** | [**Shipment**](Shipment.md)|  nesnesi |

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

