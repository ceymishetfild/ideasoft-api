# ExtraInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extraInfosGet**](ExtraInfoApi.md#extraInfosGet) | **GET** /extra_infos | Ek Bilgi Listesi Alma
[**extraInfosIdDelete**](ExtraInfoApi.md#extraInfosIdDelete) | **DELETE** /extra_infos/{id} | Ek Bilgi Silme
[**extraInfosIdGet**](ExtraInfoApi.md#extraInfosIdGet) | **GET** /extra_infos/{id} | Ek Bilgi Alma
[**extraInfosIdPut**](ExtraInfoApi.md#extraInfosIdPut) | **PUT** /extra_infos/{id} | Ek Bilgi Güncelleme
[**extraInfosPost**](ExtraInfoApi.md#extraInfosPost) | **POST** /extra_infos | Ek Bilgi Oluşturma


<a name="extraInfosGet"></a>
# **extraInfosGet**
> ExtraInfo extraInfosGet(sort, limit, page, sinceId, ids, name)

Ek Bilgi Listesi Alma

Ek Bilgi listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ExtraInfoApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ExtraInfoApi apiInstance = new ExtraInfoApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String name = "name_example"; // String | Ek Bilgi adı
try {
    ExtraInfo result = apiInstance.extraInfosGet(sort, limit, page, sinceId, ids, name);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ExtraInfoApi#extraInfosGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **name** | **String**| Ek Bilgi adı | [optional]

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfosIdDelete"></a>
# **extraInfosIdDelete**
> extraInfosIdDelete(id)

Ek Bilgi Silme

Kalıcı olarak ilgili Ek Bilgiyi siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ExtraInfoApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ExtraInfoApi apiInstance = new ExtraInfoApi();
Integer id = 56; // Integer | Ek Bilgi nesnesinin id değeri
try {
    apiInstance.extraInfosIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ExtraInfoApi#extraInfosIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Bilgi nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfosIdGet"></a>
# **extraInfosIdGet**
> ExtraInfo extraInfosIdGet(id)

Ek Bilgi Alma

İlgili Ek Bilgiyi getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ExtraInfoApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ExtraInfoApi apiInstance = new ExtraInfoApi();
Integer id = 56; // Integer | Ek Bilgi nesnesinin id değeri
try {
    ExtraInfo result = apiInstance.extraInfosIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ExtraInfoApi#extraInfosIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Bilgi nesnesinin id değeri |

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfosIdPut"></a>
# **extraInfosIdPut**
> ExtraInfo extraInfosIdPut(id, extraInfo)

Ek Bilgi Güncelleme

İlgili Ek Bilgiyi günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ExtraInfoApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ExtraInfoApi apiInstance = new ExtraInfoApi();
Integer id = 56; // Integer | Ek Bilgi nesnesinin id değeri
ExtraInfo extraInfo = new ExtraInfo(); // ExtraInfo |  nesnesi
try {
    ExtraInfo result = apiInstance.extraInfosIdPut(id, extraInfo);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ExtraInfoApi#extraInfosIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Bilgi nesnesinin id değeri |
 **extraInfo** | [**ExtraInfo**](ExtraInfo.md)|  nesnesi |

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfosPost"></a>
# **extraInfosPost**
> ExtraInfo extraInfosPost(extraInfo)

Ek Bilgi Oluşturma

Yeni bir Ek Bilgi oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ExtraInfoApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ExtraInfoApi apiInstance = new ExtraInfoApi();
ExtraInfo extraInfo = new ExtraInfo(); // ExtraInfo |  nesnesi
try {
    ExtraInfo result = apiInstance.extraInfosPost(extraInfo);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ExtraInfoApi#extraInfosPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extraInfo** | [**ExtraInfo**](ExtraInfo.md)|  nesnesi |

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

