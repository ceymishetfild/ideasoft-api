# TownGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**townGroupsGet**](TownGroupApi.md#townGroupsGet) | **GET** /town_groups | İlçe Grubu Listesi Alma
[**townGroupsIdDelete**](TownGroupApi.md#townGroupsIdDelete) | **DELETE** /town_groups/{id} | İlçe Grubu Silme
[**townGroupsIdGet**](TownGroupApi.md#townGroupsIdGet) | **GET** /town_groups/{id} | İlçe Grubu Alma
[**townGroupsIdPut**](TownGroupApi.md#townGroupsIdPut) | **PUT** /town_groups/{id} | İlçe Grubu Güncelleme
[**townGroupsPost**](TownGroupApi.md#townGroupsPost) | **POST** /town_groups | İlçe Grubu Oluşturma


<a name="townGroupsGet"></a>
# **townGroupsGet**
> TownGroup townGroupsGet(sort, limit, page, sinceId, ids, name)

İlçe Grubu Listesi Alma

İlçe Grubu listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.TownGroupApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

TownGroupApi apiInstance = new TownGroupApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String name = "name_example"; // String | İlçe Grubu adı
try {
    TownGroup result = apiInstance.townGroupsGet(sort, limit, page, sinceId, ids, name);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TownGroupApi#townGroupsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **name** | **String**| İlçe Grubu adı | [optional]

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townGroupsIdDelete"></a>
# **townGroupsIdDelete**
> townGroupsIdDelete(id)

İlçe Grubu Silme

Kalıcı olarak ilgili İlçe Grubunu siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.TownGroupApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

TownGroupApi apiInstance = new TownGroupApi();
Integer id = 56; // Integer | İlçe Grubu nesnesinin id değeri
try {
    apiInstance.townGroupsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling TownGroupApi#townGroupsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| İlçe Grubu nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townGroupsIdGet"></a>
# **townGroupsIdGet**
> TownGroup townGroupsIdGet(id)

İlçe Grubu Alma

İlgili İlçe Grubunu getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.TownGroupApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

TownGroupApi apiInstance = new TownGroupApi();
Integer id = 56; // Integer | İlçe Grubu nesnesinin id değeri
try {
    TownGroup result = apiInstance.townGroupsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TownGroupApi#townGroupsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| İlçe Grubu nesnesinin id değeri |

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townGroupsIdPut"></a>
# **townGroupsIdPut**
> TownGroup townGroupsIdPut(id, townGroup)

İlçe Grubu Güncelleme

İlgili İlçe Grubunu günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.TownGroupApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

TownGroupApi apiInstance = new TownGroupApi();
Integer id = 56; // Integer | İlçe Grubu nesnesinin id değeri
TownGroup townGroup = new TownGroup(); // TownGroup |  nesnesi
try {
    TownGroup result = apiInstance.townGroupsIdPut(id, townGroup);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TownGroupApi#townGroupsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| İlçe Grubu nesnesinin id değeri |
 **townGroup** | [**TownGroup**](TownGroup.md)|  nesnesi |

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townGroupsPost"></a>
# **townGroupsPost**
> TownGroup townGroupsPost(townGroup)

İlçe Grubu Oluşturma

Yeni bir İlçe Grubu oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.TownGroupApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

TownGroupApi apiInstance = new TownGroupApi();
TownGroup townGroup = new TownGroup(); // TownGroup |  nesnesi
try {
    TownGroup result = apiInstance.townGroupsPost(townGroup);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TownGroupApi#townGroupsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **townGroup** | [**TownGroup**](TownGroup.md)|  nesnesi |

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

