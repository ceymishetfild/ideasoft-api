
# OrderItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sipariş kalemi nesnesi kimlik değeri. |  [optional]
**productName** | **String** | Ürünün adı. | 
**productSku** | **String** | Ürünün stok kodu. | 
**productBarcode** | **String** | Ürünün barkodu. |  [optional]
**productPrice** | **Float** | Ürünün fiyatı. | 
**productCurrency** | **String** | Ürünün kuru. | 
**productQuantity** | **Float** | Ürünün stok tipi cinsinden miktarı. | 
**productTax** | **Integer** | Ürünün vergisi | 
**productDiscount** | **Float** | Ürünün standart indirim değeri. | 
**productMoneyOrderDiscount** | **Float** | Ürünün havale indirim değeri. | 
**productWeight** | **Float** | Ürünün ağırlığı. | 
**productStockTypeLabel** | **String** | Ürünün stok tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Adet&lt;/code&gt; : Stok tipi birimi Adet&lt;br&gt;&lt;code&gt;cm&lt;/code&gt; : Stok tipi birimi Santimetre&lt;br&gt;&lt;code&gt;Düzine&lt;/code&gt; : Stok tipi birimi Düzine&lt;br&gt;&lt;code&gt;gram&lt;/code&gt; : Stok tipi birimi Gram&lt;br&gt;&lt;code&gt;kg&lt;/code&gt; : Stok tipi birimi Kilogram&lt;br&gt;&lt;code&gt;Kişi&lt;/code&gt; : Stok tipi birimi Kişi&lt;br&gt;&lt;code&gt;Paket&lt;/code&gt; : Stok tipi birimi Paket&lt;br&gt;&lt;code&gt;metre&lt;/code&gt; : Stok tipi birimi Metre&lt;br&gt;&lt;code&gt;m2&lt;/code&gt; : Stok tipi birimi Metre kare&lt;br&gt;&lt;code&gt;Çift&lt;/code&gt; : Stok tipi birimi Çift&lt;br&gt;&lt;/div&gt; | 
**isProductPromotioned** | [**IsProductPromotionedEnum**](#IsProductPromotionedEnum) | Ürünün promosyon olup olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;0&lt;/code&gt; : Ürün promosyon değil.&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Ürün promosyon.&lt;br&gt;&lt;/div&gt; |  [optional]
**discount** | **Float** | Ürünün hediye çeki indirim değeri. | 
**order** | [**Order**](Order.md) |  |  [optional]
**product** | [**Product**](Product.md) |  |  [optional]
**orderItemSubscription** | [**OrderItemSubscription**](OrderItemSubscription.md) |  |  [optional]


<a name="IsProductPromotionedEnum"></a>
## Enum: IsProductPromotionedEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;



