# ShopPreferenceApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**preferencesGet**](ShopPreferenceApi.md#preferencesGet) | **GET** /preferences | Tanımlamalar Listesi Alma
[**preferencesIdGet**](ShopPreferenceApi.md#preferencesIdGet) | **GET** /preferences/{id} | Tanımlamalar Alma
[**preferencesIdPut**](ShopPreferenceApi.md#preferencesIdPut) | **PUT** /preferences/{id} | Tanımlamalar Güncelleme


<a name="preferencesGet"></a>
# **preferencesGet**
> ShopPreference preferencesGet(sort, limit, page, sinceId, ids, varKey)

Tanımlamalar Listesi Alma

Tanımlamalar listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShopPreferenceApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ShopPreferenceApi apiInstance = new ShopPreferenceApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 100; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String varKey = "varKey_example"; // String | Tanımlama varKey değeri
try {
    ShopPreference result = apiInstance.preferencesGet(sort, limit, page, sinceId, ids, varKey);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShopPreferenceApi#preferencesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 100]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **varKey** | **String**| Tanımlama varKey değeri | [optional]

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="preferencesIdGet"></a>
# **preferencesIdGet**
> ShopPreference preferencesIdGet(id)

Tanımlamalar Alma

İlgili Tanımlamayı getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShopPreferenceApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ShopPreferenceApi apiInstance = new ShopPreferenceApi();
Integer id = 56; // Integer | Tanımlama nesnesinin id değeri
try {
    ShopPreference result = apiInstance.preferencesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShopPreferenceApi#preferencesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tanımlama nesnesinin id değeri |

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="preferencesIdPut"></a>
# **preferencesIdPut**
> ShopPreference preferencesIdPut(id, shopPreference)

Tanımlamalar Güncelleme

İlgili Tanımlamayı günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShopPreferenceApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ShopPreferenceApi apiInstance = new ShopPreferenceApi();
Integer id = 56; // Integer | Tanımlama nesnesinin id değeri
ShopPreference shopPreference = new ShopPreference(); // ShopPreference |  nesnesi
try {
    ShopPreference result = apiInstance.preferencesIdPut(id, shopPreference);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShopPreferenceApi#preferencesIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tanımlama nesnesinin id değeri |
 **shopPreference** | [**ShopPreference**](ShopPreference.md)|  nesnesi |

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

