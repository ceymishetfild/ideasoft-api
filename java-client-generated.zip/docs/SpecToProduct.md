
# SpecToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ürün özellik ürün bağı nesnesi kimlik değeri. |  [optional]
**product** | [**Product**](Product.md) |  |  [optional]
**specGroup** | [**SpecGroup**](SpecGroup.md) |  |  [optional]
**specName** | [**SpecName**](SpecName.md) |  |  [optional]
**specValue** | [**SpecValue**](SpecValue.md) |  |  [optional]



