
# OptionToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Varyant ürün bağı nesnesi kimlik değeri. |  [optional]
**parentProductId** | **Integer** | Ana ürünün benzersiz kimlik değeri. | 
**optionGroup** | [**OptionGroup**](OptionGroup.md) | Varyant grubu nesnesi. | 
**option** | [**Options**](Options.md) | Varyant nesnesi. | 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 



