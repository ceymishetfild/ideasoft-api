
# CartItemAttribute

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sepet kalemi özelliği nesnesi kimlik değeri. |  [optional]
**name** | **String** | Sepet kalemi özelliği nesnesinin isim değeri. Örneğin, sepet kalemi kalem ise bu değer renk olabilir. |  [optional]
**value** | **String** | Sepet kalemi özelliği nesnesinin değeri. Örneğin, sepet kalemi kalem, isim değeri renk ise bu değer kırmızı olabilir. |  [optional]
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) | Sepet kalemi özelliği nesnesinin oluşturulma zamanı. |  [optional]
**cartItem** | [**CartItem**](CartItem.md) | Sepet kalemi nesnesi. |  [optional]



