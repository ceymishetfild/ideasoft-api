
# Maillist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Mail listesi nesnesi kimlik değeri. |  [optional]
**name** | **String** | Mail listesi nesnesi için isim değeri. | 
**email** | **String** | Ziyaretçi veya üyenin mail adresi. | 
**lastMailSentDate** | [**OffsetDateTime**](OffsetDateTime.md) | En son e-mail gönderilen zaman. |  [optional]
**creatorIpAddress** | **String** | Mail listesi nesnesini oluşturan kişinin IP adresi. |  [optional]
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) | Mail listesi nesnesinin oluşturulma zamanı. | 
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) | Mail listesi nesnesinin güncellenme zamanı. | 
**maillistGroup** | [**MaillistGroup**](MaillistGroup.md) |  |  [optional]



