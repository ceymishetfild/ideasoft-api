# CurrencyApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**currenciesGet**](CurrencyApi.md#currenciesGet) | **GET** /currencies | Kur Listesi Alma
[**currenciesIdGet**](CurrencyApi.md#currenciesIdGet) | **GET** /currencies/{id} | Kur Alma
[**currenciesIdPut**](CurrencyApi.md#currenciesIdPut) | **PUT** /currencies/{id} | Kur Güncelleme


<a name="currenciesGet"></a>
# **currenciesGet**
> Currency currenciesGet(sort, limit, page, sinceId, label, abbr, status)

Kur Listesi Alma

Kur listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.CurrencyApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

CurrencyApi apiInstance = new CurrencyApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String label = "label_example"; // String | Kur etiketi
String abbr = "abbr_example"; // String | Kur kısaltması
Integer status = 56; // Integer | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
try {
    Currency result = apiInstance.currenciesGet(sort, limit, page, sinceId, label, abbr, status);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CurrencyApi#currenciesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **label** | **String**| Kur etiketi | [optional]
 **abbr** | **String**| Kur kısaltması | [optional]
 **status** | **Integer**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] [enum: 0, 1]

### Return type

[**Currency**](Currency.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="currenciesIdGet"></a>
# **currenciesIdGet**
> Currency currenciesIdGet(id)

Kur Alma

İlgili Kur getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.CurrencyApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

CurrencyApi apiInstance = new CurrencyApi();
Integer id = 56; // Integer | Kur nesnesinin id değeri
try {
    Currency result = apiInstance.currenciesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CurrencyApi#currenciesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kur nesnesinin id değeri |

### Return type

[**Currency**](Currency.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="currenciesIdPut"></a>
# **currenciesIdPut**
> Currency currenciesIdPut(id, currency)

Kur Güncelleme

İlgili Kur günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.CurrencyApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

CurrencyApi apiInstance = new CurrencyApi();
Integer id = 56; // Integer | Kur nesnesinin id değeri
Currency currency = new Currency(); // Currency | Currency nesnesi
try {
    Currency result = apiInstance.currenciesIdPut(id, currency);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CurrencyApi#currenciesIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kur nesnesinin id değeri |
 **currency** | [**Currency**](Currency.md)| Currency nesnesi |

### Return type

[**Currency**](Currency.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

