
# ProductToTag

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ürün SEO+ etiketi bağı nesnesi kimlik değeri. |  [optional]
**product** | [**Product**](Product.md) |  |  [optional]
**tag** | [**Tag**](Tag.md) |  |  [optional]



