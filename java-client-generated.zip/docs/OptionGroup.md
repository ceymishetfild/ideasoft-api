
# OptionGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Varyant grubu nesnesi kimlik değeri. |  [optional]
**title** | **String** | Varyant grubunun başlığı. Varyant değeri kırmızı ise bu değer renk olabilir. | 
**sortOrder** | **Integer** | Varyant grubunun sıralama değeri. |  [optional]
**filterStatus** | [**FilterStatusEnum**](#FilterStatusEnum) | Varyant grubunun filtre menüsündeki gösterim durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Gösterilsin.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Gösterilmesin.&lt;br&gt;&lt;/div&gt; |  [optional]


<a name="FilterStatusEnum"></a>
## Enum: FilterStatusEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;



