# ProductImageApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productImagesGet**](ProductImageApi.md#productImagesGet) | **GET** /product_images | Ürün Resim Listesi Alma
[**productImagesIdDelete**](ProductImageApi.md#productImagesIdDelete) | **DELETE** /product_images/{id} | Ürün Resim Silme
[**productImagesIdGet**](ProductImageApi.md#productImagesIdGet) | **GET** /product_images/{id} | Ürün Resim Alma
[**productImagesPost**](ProductImageApi.md#productImagesPost) | **POST** /product_images | Ürün Resim Oluşturma


<a name="productImagesGet"></a>
# **productImagesGet**
> ProductImage productImagesGet(sort, limit, page, sinceId, fileName, product)

Ürün Resim Listesi Alma

Ürün Resim listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductImageApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductImageApi apiInstance = new ProductImageApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String fileName = "fileName_example"; // String | Ürün Resim dosya adı
Integer product = 56; // Integer | Ürün id
try {
    ProductImage result = apiInstance.productImagesGet(sort, limit, page, sinceId, fileName, product);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductImageApi#productImagesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **fileName** | **String**| Ürün Resim dosya adı | [optional]
 **product** | **Integer**| Ürün id | [optional]

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productImagesIdDelete"></a>
# **productImagesIdDelete**
> productImagesIdDelete(id)

Ürün Resim Silme

Kalıcı olarak ilgili Ürün Resmini siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductImageApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductImageApi apiInstance = new ProductImageApi();
Integer id = 56; // Integer | Ürün Resmi nesnesinin id değeri
try {
    apiInstance.productImagesIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductImageApi#productImagesIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Resmi nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productImagesIdGet"></a>
# **productImagesIdGet**
> ProductImage productImagesIdGet(id)

Ürün Resim Alma

İlgili Ürün Resmini getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductImageApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductImageApi apiInstance = new ProductImageApi();
Integer id = 56; // Integer | Ürün Resmi nesnesinin id değeri
try {
    ProductImage result = apiInstance.productImagesIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductImageApi#productImagesIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Resmi nesnesinin id değeri |

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productImagesPost"></a>
# **productImagesPost**
> ProductImage productImagesPost(productImage)

Ürün Resim Oluşturma

Yeni bir Ürün Resim oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductImageApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductImageApi apiInstance = new ProductImageApi();
ProductImage productImage = new ProductImage(); // ProductImage | ProductImage nesnesi
try {
    ProductImage result = apiInstance.productImagesPost(productImage);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductImageApi#productImagesPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productImage** | [**ProductImage**](ProductImage.md)| ProductImage nesnesi |

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

