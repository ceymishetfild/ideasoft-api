
# ShippingProviderSetting

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Teslimat hizmeti sağlayıcısı ayarı nesnesi kimlik değeri. |  [optional]
**varKey** | **String** | Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken anahtarı. | 
**varValue** | **String** | Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken değeri. | 
**shippingProvider** | [**ShippingProvider**](ShippingProvider.md) |  |  [optional]



