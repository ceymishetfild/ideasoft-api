# OrderRefundRequestApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**orderRefundRequestsGet**](OrderRefundRequestApi.md#orderRefundRequestsGet) | **GET** /order_refund_requests | Sipariş İptal Talebi Listesi Alma
[**orderRefundRequestsIdDelete**](OrderRefundRequestApi.md#orderRefundRequestsIdDelete) | **DELETE** /order_refund_requests/{id} | Sipariş İptal Talebi Silme
[**orderRefundRequestsIdGet**](OrderRefundRequestApi.md#orderRefundRequestsIdGet) | **GET** /order_refund_requests/{id} | Sipariş İptal Talebi Alma
[**orderRefundRequestsIdPut**](OrderRefundRequestApi.md#orderRefundRequestsIdPut) | **PUT** /order_refund_requests/{id} | Sipariş İptal Talebi Güncelleme
[**orderRefundRequestsPost**](OrderRefundRequestApi.md#orderRefundRequestsPost) | **POST** /order_refund_requests | Sipariş İptal Talebi Oluşturma


<a name="orderRefundRequestsGet"></a>
# **orderRefundRequestsGet**
> OrderRefundRequest orderRefundRequestsGet(sort, limit, page, sinceId, ids, order, member, code, status, startDate, endDate, startUpdatedAt, endUpdatedAt)

Sipariş İptal Talebi Listesi Alma

Sipariş İptal Talebi listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrderRefundRequestApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OrderRefundRequestApi apiInstance = new OrderRefundRequestApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
Integer order = 56; // Integer | Sipariş id
Integer member = 56; // Integer | Üye id
String code = "code_example"; // String | Sipariş İptal Talebi kodu
String status = "status_example"; // String | Status şu değerleri alabilir: <br><code>waiting_for_approval</code> : Onay bekliyor<br><code>approved</code> : Onaylandı<br><code>cancelled</code> : İptal edildi
LocalDate startDate = new LocalDate(); // LocalDate | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
LocalDate startUpdatedAt = new LocalDate(); // LocalDate | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
try {
    OrderRefundRequest result = apiInstance.orderRefundRequestsGet(sort, limit, page, sinceId, ids, order, member, code, status, startDate, endDate, startUpdatedAt, endUpdatedAt);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderRefundRequestApi#orderRefundRequestsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **order** | **Integer**| Sipariş id | [optional]
 **member** | **Integer**| Üye id | [optional]
 **code** | **String**| Sipariş İptal Talebi kodu | [optional]
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi | [optional] [enum: waiting_for_approval, approved, cancelled]
 **startDate** | **LocalDate**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **LocalDate**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderRefundRequestsIdDelete"></a>
# **orderRefundRequestsIdDelete**
> orderRefundRequestsIdDelete(id)

Sipariş İptal Talebi Silme

Kalıcı olarak ilgili Sipariş İptal Talebini siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrderRefundRequestApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OrderRefundRequestApi apiInstance = new OrderRefundRequestApi();
Integer id = 56; // Integer | Sipariş İptal Talebi nesnesinin id değeri
try {
    apiInstance.orderRefundRequestsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderRefundRequestApi#orderRefundRequestsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş İptal Talebi nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderRefundRequestsIdGet"></a>
# **orderRefundRequestsIdGet**
> OrderRefundRequest orderRefundRequestsIdGet(id)

Sipariş İptal Talebi Alma

İlgili Sipariş İptal Talebini getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrderRefundRequestApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OrderRefundRequestApi apiInstance = new OrderRefundRequestApi();
Integer id = 56; // Integer | Sipariş İptal Talebi nesnesinin id değeri
try {
    OrderRefundRequest result = apiInstance.orderRefundRequestsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderRefundRequestApi#orderRefundRequestsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş İptal Talebi nesnesinin id değeri |

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderRefundRequestsIdPut"></a>
# **orderRefundRequestsIdPut**
> OrderRefundRequest orderRefundRequestsIdPut(id, orderRefundRequest)

Sipariş İptal Talebi Güncelleme

İlgili Sipariş İptal Talebini günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrderRefundRequestApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OrderRefundRequestApi apiInstance = new OrderRefundRequestApi();
Integer id = 56; // Integer | Sipariş İptal Talebi nesnesinin id değeri
OrderRefundRequest orderRefundRequest = new OrderRefundRequest(); // OrderRefundRequest |  nesnesi
try {
    OrderRefundRequest result = apiInstance.orderRefundRequestsIdPut(id, orderRefundRequest);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderRefundRequestApi#orderRefundRequestsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş İptal Talebi nesnesinin id değeri |
 **orderRefundRequest** | [**OrderRefundRequest**](OrderRefundRequest.md)|  nesnesi |

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderRefundRequestsPost"></a>
# **orderRefundRequestsPost**
> OrderRefundRequest orderRefundRequestsPost(orderRefundRequest)

Sipariş İptal Talebi Oluşturma

Yeni bir Sipariş İptal Talebi oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrderRefundRequestApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OrderRefundRequestApi apiInstance = new OrderRefundRequestApi();
OrderRefundRequest orderRefundRequest = new OrderRefundRequest(); // OrderRefundRequest |  nesnesi
try {
    OrderRefundRequest result = apiInstance.orderRefundRequestsPost(orderRefundRequest);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderRefundRequestApi#orderRefundRequestsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orderRefundRequest** | [**OrderRefundRequest**](OrderRefundRequest.md)|  nesnesi |

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

