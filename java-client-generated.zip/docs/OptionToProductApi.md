# OptionToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**optionToProductsGet**](OptionToProductApi.md#optionToProductsGet) | **GET** /option_to_products | Varyant Ürün Bağı Listesi Alma
[**optionToProductsIdDelete**](OptionToProductApi.md#optionToProductsIdDelete) | **DELETE** /option_to_products/{id} | Varyant Ürün Bağı Silme
[**optionToProductsIdGet**](OptionToProductApi.md#optionToProductsIdGet) | **GET** /option_to_products/{id} | Varyant Ürün Bağı Alma
[**optionToProductsIdPut**](OptionToProductApi.md#optionToProductsIdPut) | **PUT** /option_to_products/{id} | Varyant Ürün Bağı Güncelleme
[**optionToProductsPost**](OptionToProductApi.md#optionToProductsPost) | **POST** /option_to_products | Varyant Ürün Bağı Oluşturma


<a name="optionToProductsGet"></a>
# **optionToProductsGet**
> OptionToProduct optionToProductsGet(sort, limit, page, sinceId, product, optionGroup, option, parentProductId)

Varyant Ürün Bağı Listesi Alma

Varyant Ürün Bağı listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OptionToProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OptionToProductApi apiInstance = new OptionToProductApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
Integer product = 56; // Integer | Ürün id
Integer optionGroup = 56; // Integer | Varyant Grubu id
Integer option = 56; // Integer | Varyant id
Integer parentProductId = 56; // Integer | Ana Ürün id
try {
    OptionToProduct result = apiInstance.optionToProductsGet(sort, limit, page, sinceId, product, optionGroup, option, parentProductId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OptionToProductApi#optionToProductsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **product** | **Integer**| Ürün id | [optional]
 **optionGroup** | **Integer**| Varyant Grubu id | [optional]
 **option** | **Integer**| Varyant id | [optional]
 **parentProductId** | **Integer**| Ana Ürün id | [optional]

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionToProductsIdDelete"></a>
# **optionToProductsIdDelete**
> optionToProductsIdDelete(id)

Varyant Ürün Bağı Silme

Kalıcı olarak ilgili Varyant Ürün Bağını siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OptionToProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OptionToProductApi apiInstance = new OptionToProductApi();
Integer id = 56; // Integer | Varyant Ürün Bağı nesnesinin id değeri
try {
    apiInstance.optionToProductsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling OptionToProductApi#optionToProductsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant Ürün Bağı nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionToProductsIdGet"></a>
# **optionToProductsIdGet**
> OptionToProduct optionToProductsIdGet(id)

Varyant Ürün Bağı Alma

İlgili Varyant Ürün Bağını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OptionToProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OptionToProductApi apiInstance = new OptionToProductApi();
Integer id = 56; // Integer | Varyant Ürün Bağı nesnesinin id değeri
try {
    OptionToProduct result = apiInstance.optionToProductsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OptionToProductApi#optionToProductsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant Ürün Bağı nesnesinin id değeri |

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionToProductsIdPut"></a>
# **optionToProductsIdPut**
> OptionToProduct optionToProductsIdPut(id, optionToProduct)

Varyant Ürün Bağı Güncelleme

İlgili Varyant Ürün Bağını günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OptionToProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OptionToProductApi apiInstance = new OptionToProductApi();
Integer id = 56; // Integer | Varyant Ürün Bağı nesnesinin id değeri
OptionToProduct optionToProduct = new OptionToProduct(); // OptionToProduct | OptionToProduct nesnesi
try {
    OptionToProduct result = apiInstance.optionToProductsIdPut(id, optionToProduct);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OptionToProductApi#optionToProductsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant Ürün Bağı nesnesinin id değeri |
 **optionToProduct** | [**OptionToProduct**](OptionToProduct.md)| OptionToProduct nesnesi |

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionToProductsPost"></a>
# **optionToProductsPost**
> OptionToProduct optionToProductsPost(optionToProduct)

Varyant Ürün Bağı Oluşturma

Yeni bir Varyant Ürün Bağı oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OptionToProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OptionToProductApi apiInstance = new OptionToProductApi();
OptionToProduct optionToProduct = new OptionToProduct(); // OptionToProduct | OptionToProduct nesnesi
try {
    OptionToProduct result = apiInstance.optionToProductsPost(optionToProduct);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OptionToProductApi#optionToProductsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **optionToProduct** | [**OptionToProduct**](OptionToProduct.md)| OptionToProduct nesnesi |

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

