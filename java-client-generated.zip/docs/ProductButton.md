
# ProductButton

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ürün ve stok butonu nesnesi kimlik değeri. |  [optional]
**fastShipping** | [**FastShippingEnum**](#FastShippingEnum) | Hızlı gönderi butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hızlı kargo butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hızlı kargo butonu pasif.&lt;br&gt;&lt;/div&gt; |  [optional]
**sameDayShipping** | [**SameDayShippingEnum**](#SameDayShippingEnum) | Aynı gün kargo butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aynı gün kargo butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Aynı gün kargo butonu pasif.&lt;br&gt;&lt;/div&gt; |  [optional]
**threeDaysDelivery** | [**ThreeDaysDeliveryEnum**](#ThreeDaysDeliveryEnum) | 3 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 3 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 3 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt; |  [optional]
**fiveDaysDelivery** | [**FiveDaysDeliveryEnum**](#FiveDaysDeliveryEnum) | 5 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 5 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 5 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt; |  [optional]
**sevenDaysDelivery** | [**SevenDaysDeliveryEnum**](#SevenDaysDeliveryEnum) | 7 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 7 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 7 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt; |  [optional]
**freeShipping** | [**FreeShippingEnum**](#FreeShippingEnum) | Kargo bedava butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kargo bedava butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kargo bedava butonu pasif.&lt;br&gt;&lt;/div&gt; |  [optional]
**deliveryFromStock** | [**DeliveryFromStockEnum**](#DeliveryFromStockEnum) | Stoktan teslim butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Stoktan teslim butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Stoktan teslim butonu pasif.&lt;br&gt;&lt;/div&gt; |  [optional]
**preOrderedProduct** | [**PreOrderedProductEnum**](#PreOrderedProductEnum) | Ön siparişli stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Ön siparişli ürün butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Ön siparişli ürün butonu pasif.&lt;br&gt;&lt;/div&gt; |  [optional]
**limitedStock** | [**LimitedStockEnum**](#LimitedStockEnum) | Sınırlı stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sınırlı stok butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sınırlı stok butonu pasif.&lt;br&gt;&lt;/div&gt; |  [optional]
**askStock** | [**AskStockEnum**](#AskStockEnum) | Stok sorunuz butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Stok sorunuz butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Stok sorunuz butonu pasif.&lt;br&gt;&lt;/div&gt; |  [optional]
**campaignedProduct** | [**CampaignedProductEnum**](#CampaignedProductEnum) | Kampanyalı stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalı ürün butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalı ürün butonu pasif.&lt;br&gt;&lt;/div&gt; |  [optional]
**product** | [**Product**](Product.md) |  |  [optional]


<a name="FastShippingEnum"></a>
## Enum: FastShippingEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;


<a name="SameDayShippingEnum"></a>
## Enum: SameDayShippingEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;


<a name="ThreeDaysDeliveryEnum"></a>
## Enum: ThreeDaysDeliveryEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;


<a name="FiveDaysDeliveryEnum"></a>
## Enum: FiveDaysDeliveryEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;


<a name="SevenDaysDeliveryEnum"></a>
## Enum: SevenDaysDeliveryEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;


<a name="FreeShippingEnum"></a>
## Enum: FreeShippingEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;


<a name="DeliveryFromStockEnum"></a>
## Enum: DeliveryFromStockEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;


<a name="PreOrderedProductEnum"></a>
## Enum: PreOrderedProductEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;


<a name="LimitedStockEnum"></a>
## Enum: LimitedStockEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;


<a name="AskStockEnum"></a>
## Enum: AskStockEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;


<a name="CampaignedProductEnum"></a>
## Enum: CampaignedProductEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;



