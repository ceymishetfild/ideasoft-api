# ShipmentItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipmentItemsGet**](ShipmentItemApi.md#shipmentItemsGet) | **GET** /shipment_items | Teslimat Kalemi Listesi Alma
[**shipmentItemsIdDelete**](ShipmentItemApi.md#shipmentItemsIdDelete) | **DELETE** /shipment_items/{id} | Teslimat Kalemi Silme
[**shipmentItemsIdGet**](ShipmentItemApi.md#shipmentItemsIdGet) | **GET** /shipment_items/{id} | Teslimat Kalemi Alma
[**shipmentItemsIdPut**](ShipmentItemApi.md#shipmentItemsIdPut) | **PUT** /shipment_items/{id} | Teslimat Kalemi Güncelleme
[**shipmentItemsPost**](ShipmentItemApi.md#shipmentItemsPost) | **POST** /shipment_items | Teslimat Kalemi Oluşturma


<a name="shipmentItemsGet"></a>
# **shipmentItemsGet**
> ShipmentItem shipmentItemsGet(sort, limit, page, sinceId, product, shipment, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt)

Teslimat Kalemi Listesi Alma

Teslimat Kalemi listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShipmentItemApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ShipmentItemApi apiInstance = new ShipmentItemApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
Integer product = 56; // Integer | Ürün id
Integer shipment = 56; // Integer | Teslimat id
Integer orderItem = 56; // Integer | Sipariş kalemi id
LocalDate startDate = new LocalDate(); // LocalDate | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
LocalDate startUpdatedAt = new LocalDate(); // LocalDate | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
try {
    ShipmentItem result = apiInstance.shipmentItemsGet(sort, limit, page, sinceId, product, shipment, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShipmentItemApi#shipmentItemsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **product** | **Integer**| Ürün id | [optional]
 **shipment** | **Integer**| Teslimat id | [optional]
 **orderItem** | **Integer**| Sipariş kalemi id | [optional]
 **startDate** | **LocalDate**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **LocalDate**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shipmentItemsIdDelete"></a>
# **shipmentItemsIdDelete**
> shipmentItemsIdDelete(id)

Teslimat Kalemi Silme

Kalıcı olarak ilgili Teslimat Kalemini siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShipmentItemApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ShipmentItemApi apiInstance = new ShipmentItemApi();
Integer id = 56; // Integer | Teslimat Kalemi nesnesinin id değeri
try {
    apiInstance.shipmentItemsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ShipmentItemApi#shipmentItemsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Teslimat Kalemi nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shipmentItemsIdGet"></a>
# **shipmentItemsIdGet**
> ShipmentItem shipmentItemsIdGet(id)

Teslimat Kalemi Alma

İlgili Teslimat Kalemini getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShipmentItemApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ShipmentItemApi apiInstance = new ShipmentItemApi();
Integer id = 56; // Integer | Teslimat Kalemi nesnesinin id değeri
try {
    ShipmentItem result = apiInstance.shipmentItemsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShipmentItemApi#shipmentItemsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Teslimat Kalemi nesnesinin id değeri |

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shipmentItemsIdPut"></a>
# **shipmentItemsIdPut**
> ShipmentItem shipmentItemsIdPut(id, shipmentItem)

Teslimat Kalemi Güncelleme

İlgili Teslimat Kalemini günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShipmentItemApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ShipmentItemApi apiInstance = new ShipmentItemApi();
Integer id = 56; // Integer | Teslimat Kalemi nesnesinin id değeri
ShipmentItem shipmentItem = new ShipmentItem(); // ShipmentItem | ShipmentItem nesnesi
try {
    ShipmentItem result = apiInstance.shipmentItemsIdPut(id, shipmentItem);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShipmentItemApi#shipmentItemsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Teslimat Kalemi nesnesinin id değeri |
 **shipmentItem** | [**ShipmentItem**](ShipmentItem.md)| ShipmentItem nesnesi |

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shipmentItemsPost"></a>
# **shipmentItemsPost**
> ShipmentItem shipmentItemsPost(shipmentItem)

Teslimat Kalemi Oluşturma

Yeni bir Teslimat Kalemi oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ShipmentItemApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ShipmentItemApi apiInstance = new ShipmentItemApi();
ShipmentItem shipmentItem = new ShipmentItem(); // ShipmentItem | ShipmentItem nesnesi
try {
    ShipmentItem result = apiInstance.shipmentItemsPost(shipmentItem);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ShipmentItemApi#shipmentItemsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipmentItem** | [**ShipmentItem**](ShipmentItem.md)| ShipmentItem nesnesi |

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

