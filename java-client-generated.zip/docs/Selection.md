
# Selection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ek özellik nesnesi kimlik değeri. |  [optional]
**title** | **String** | Ek özellik nesnesinin başlığı. |  [optional]
**sortOrder** | **Integer** | Ek özellik nesnesi için sıralama değeri. | 
**selectionGroup** | [**SelectionGroup**](SelectionGroup.md) |  |  [optional]



