# OrderDetailApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**orderDetailsGet**](OrderDetailApi.md#orderDetailsGet) | **GET** /order_details | Sipariş Detayı Listesi Alma
[**orderDetailsIdDelete**](OrderDetailApi.md#orderDetailsIdDelete) | **DELETE** /order_details/{id} | Sipariş Detayı Silme
[**orderDetailsIdGet**](OrderDetailApi.md#orderDetailsIdGet) | **GET** /order_details/{id} | Sipariş Detayı Alma
[**orderDetailsIdPut**](OrderDetailApi.md#orderDetailsIdPut) | **PUT** /order_details/{id} | Sipariş Detayı Güncelleme
[**orderDetailsPost**](OrderDetailApi.md#orderDetailsPost) | **POST** /order_details | Sipariş Detayı Oluşturma


<a name="orderDetailsGet"></a>
# **orderDetailsGet**
> OrderDetail orderDetailsGet(sort, limit, page, sinceId, ids, order)

Sipariş Detayı Listesi Alma

Sipariş Detayı listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrderDetailApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OrderDetailApi apiInstance = new OrderDetailApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
Integer order = 56; // Integer | Sipariş id
try {
    OrderDetail result = apiInstance.orderDetailsGet(sort, limit, page, sinceId, ids, order);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderDetailApi#orderDetailsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **order** | **Integer**| Sipariş id | [optional]

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderDetailsIdDelete"></a>
# **orderDetailsIdDelete**
> orderDetailsIdDelete(id)

Sipariş Detayı Silme

Kalıcı olarak ilgili Sipariş Detayı siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrderDetailApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OrderDetailApi apiInstance = new OrderDetailApi();
Integer id = 56; // Integer | Sipariş Detayı nesnesinin id değeri
try {
    apiInstance.orderDetailsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderDetailApi#orderDetailsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Detayı nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderDetailsIdGet"></a>
# **orderDetailsIdGet**
> OrderDetail orderDetailsIdGet(id)

Sipariş Detayı Alma

İlgili Sipariş Detayı getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrderDetailApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OrderDetailApi apiInstance = new OrderDetailApi();
Integer id = 56; // Integer | Sipariş Detayı nesnesinin id değeri
try {
    OrderDetail result = apiInstance.orderDetailsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderDetailApi#orderDetailsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Detayı nesnesinin id değeri |

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderDetailsIdPut"></a>
# **orderDetailsIdPut**
> OrderDetail orderDetailsIdPut(id, orderDetail)

Sipariş Detayı Güncelleme

İlgili Sipariş Detayı günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrderDetailApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OrderDetailApi apiInstance = new OrderDetailApi();
Integer id = 56; // Integer | Sipariş Detayı nesnesinin id değeri
OrderDetail orderDetail = new OrderDetail(); // OrderDetail |  nesnesi
try {
    OrderDetail result = apiInstance.orderDetailsIdPut(id, orderDetail);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderDetailApi#orderDetailsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Detayı nesnesinin id değeri |
 **orderDetail** | [**OrderDetail**](OrderDetail.md)|  nesnesi |

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderDetailsPost"></a>
# **orderDetailsPost**
> OrderDetail orderDetailsPost(orderDetail)

Sipariş Detayı Oluşturma

Yeni bir Sipariş Detayı oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.OrderDetailApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

OrderDetailApi apiInstance = new OrderDetailApi();
OrderDetail orderDetail = new OrderDetail(); // OrderDetail |  nesnesi
try {
    OrderDetail result = apiInstance.orderDetailsPost(orderDetail);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OrderDetailApi#orderDetailsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orderDetail** | [**OrderDetail**](OrderDetail.md)|  nesnesi |

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

