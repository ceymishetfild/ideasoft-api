
# ProductDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ürün detayı nesnesi kimlik değeri. |  [optional]
**sku** | **String** | Ürünün stok kodu. |  [optional]
**details** | **String** | Detay bilgisi. |  [optional]
**extraDetails** | **String** | Ürün ekstra detaylı bilgi. |  [optional]
**product** | [**Product**](Product.md) | Ürün nesnesi. | 



