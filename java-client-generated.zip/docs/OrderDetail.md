
# OrderDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sipariş detayı nesnesi kimlik değeri. |  [optional]
**varKey** | **String** | Sipariş detayı nesnesi için değişken anahtarı. | 
**varValue** | **String** | Sipariş detayı nesnesi için değişken değeri. | 
**order** | [**Order**](Order.md) |  |  [optional]



