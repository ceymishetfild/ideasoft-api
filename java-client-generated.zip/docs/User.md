
# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Yönetici nesnesi kimlik değeri. |  [optional]
**firstname** | **String** | Yöneticinin ismi. |  [optional]
**surname** | **String** | Yöneticinin soy ismi. |  [optional]
**email** | **String** | Yöneticinin e-mail adresi. | 
**username** | **String** | Yöneticinin kullanıcı adı. | 
**phoneNumber** | **String** | Yöneticinin telefon numarası. |  [optional]
**status** | [**StatusEnum**](#StatusEnum) | Yöneticinin aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Askıya alınmış.&lt;br&gt;&lt;/div&gt; | 
**isOwner** | [**IsOwnerEnum**](#IsOwnerEnum) | Yöneticinin site sahibi olma durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Site sahibi.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Site sahibi değil.&lt;br&gt;&lt;/div&gt; |  [optional]
**membergroups** | [**List&lt;MemberGroup&gt;**](MemberGroup.md) | İlgili üye grubu. |  [optional]
**smsApproved** | [**SmsApprovedEnum**](#SmsApprovedEnum) | Yöneticinin SMS verifikasyonu yapılma bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : SMS verifikasyon yapılmış.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : SMS verifikasyon yapılmamış.&lt;br&gt;&lt;/div&gt; |  [optional]
**userlevel** | [**ShopUserlevels**](ShopUserlevels.md) | Yönetici grubu nesnesi. |  [optional]


<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----
NUMBER_0 | 0
NUMBER_1 | 1
NUMBER_2 | 2


<a name="IsOwnerEnum"></a>
## Enum: IsOwnerEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;


<a name="SmsApprovedEnum"></a>
## Enum: SmsApprovedEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;



