# MemberApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**membersChartsGet**](MemberApi.md#membersChartsGet) | **GET** /members/charts | Üye Grafik Aksiyonu
[**membersCombinedGet**](MemberApi.md#membersCombinedGet) | **GET** /members/combined | Üye Birleşik Aksiyonu
[**membersGet**](MemberApi.md#membersGet) | **GET** /members | Üye Listesi Alma
[**membersIdDelete**](MemberApi.md#membersIdDelete) | **DELETE** /members/{id} | Üye Silme
[**membersIdGet**](MemberApi.md#membersIdGet) | **GET** /members/{id} | Üye Alma
[**membersIdPut**](MemberApi.md#membersIdPut) | **PUT** /members/{id} | Üye Güncelleme
[**membersPost**](MemberApi.md#membersPost) | **POST** /members | Üye Oluşturma


<a name="membersChartsGet"></a>
# **membersChartsGet**
> Member membersChartsGet(timeFrame, startDate)

Üye Grafik Aksiyonu

Zaman bazında üye genel istatistiklerini getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.MemberApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

MemberApi apiInstance = new MemberApi();
String timeFrame = "timeFrame_example"; // String | Şu değerleri olabilir: full, year, month or week
String startDate = "startDate_example"; // String | Zaman aralığının başlangıcı
try {
    Member result = apiInstance.membersChartsGet(timeFrame, startDate);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberApi#membersChartsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timeFrame** | **String**| Şu değerleri olabilir: full, year, month or week |
 **startDate** | **String**| Zaman aralığının başlangıcı |

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="membersCombinedGet"></a>
# **membersCombinedGet**
> Member membersCombinedGet()

Üye Birleşik Aksiyonu

Bugün, aylık, yıllık ve toplam üye oturum açma istatistiklerini totalCount cinsinden getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.MemberApi;


MemberApi apiInstance = new MemberApi();
try {
    Member result = apiInstance.membersCombinedGet();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberApi#membersCombinedGet");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Member**](Member.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="membersGet"></a>
# **membersGet**
> Member membersGet(sort, limit, page, sinceId, ids, firstname, surname, email, password, gender, mobilePhoneNumber, phoneNumber, memberGroup, location, country, referredMember, q, startDate, endDate, startUpdatedAt, endUpdatedAt)

Üye Listesi Alma

Üye listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.MemberApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

MemberApi apiInstance = new MemberApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String firstname = "firstname_example"; // String | Adı
String surname = "surname_example"; // String | Soyadı
String email = "email_example"; // String | e-mail adresi
String password = "password_example"; // String | Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri
String gender = "gender_example"; // String | Cinsiyet şu değerleri alabilir: <br><code>male</code> : Erkek<br><code>female</code> : Kadın
String mobilePhoneNumber = "mobilePhoneNumber_example"; // String | Üye mobil telefon numarası
String phoneNumber = "phoneNumber_example"; // String | Üye telefon numarası
Integer memberGroup = 56; // Integer | Üye Grubu id
Integer location = 56; // Integer | Şehir id
Integer country = 56; // Integer | Ülke id
Integer referredMember = 56; // Integer | Tavsiye Üye id
List<String> q = Arrays.asList("q_example"); // List<String> | Üye arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;]
LocalDate startDate = new LocalDate(); // LocalDate | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
LocalDate startUpdatedAt = new LocalDate(); // LocalDate | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
try {
    Member result = apiInstance.membersGet(sort, limit, page, sinceId, ids, firstname, surname, email, password, gender, mobilePhoneNumber, phoneNumber, memberGroup, location, country, referredMember, q, startDate, endDate, startUpdatedAt, endUpdatedAt);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberApi#membersGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **firstname** | **String**| Adı | [optional]
 **surname** | **String**| Soyadı | [optional]
 **email** | **String**| e-mail adresi | [optional]
 **password** | **String**| Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri | [optional]
 **gender** | **String**| Cinsiyet şu değerleri alabilir: &lt;br&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın | [optional] [enum: male, female]
 **mobilePhoneNumber** | **String**| Üye mobil telefon numarası | [optional]
 **phoneNumber** | **String**| Üye telefon numarası | [optional]
 **memberGroup** | **Integer**| Üye Grubu id | [optional]
 **location** | **Integer**| Şehir id | [optional]
 **country** | **Integer**| Ülke id | [optional]
 **referredMember** | **Integer**| Tavsiye Üye id | [optional]
 **q** | [**List&lt;String&gt;**](String.md)| Üye arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional]
 **startDate** | **LocalDate**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **LocalDate**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="membersIdDelete"></a>
# **membersIdDelete**
> membersIdDelete(id)

Üye Silme

Kalıcı olarak ilgili Üyeyi siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.MemberApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

MemberApi apiInstance = new MemberApi();
Integer id = 56; // Integer | Üye nesnesinin id değeri
try {
    apiInstance.membersIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberApi#membersIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="membersIdGet"></a>
# **membersIdGet**
> Member membersIdGet(id)

Üye Alma

İlgili Üyeyi getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.MemberApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

MemberApi apiInstance = new MemberApi();
Integer id = 56; // Integer | Üye nesnesinin id değeri
try {
    Member result = apiInstance.membersIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberApi#membersIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye nesnesinin id değeri |

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="membersIdPut"></a>
# **membersIdPut**
> Member membersIdPut(id, member)

Üye Güncelleme

İlgili Üyeyi günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.MemberApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

MemberApi apiInstance = new MemberApi();
Integer id = 56; // Integer | Üye nesnesinin id değeri
Member member = new Member(); // Member |  nesnesi
try {
    Member result = apiInstance.membersIdPut(id, member);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberApi#membersIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye nesnesinin id değeri |
 **member** | [**Member**](Member.md)|  nesnesi |

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="membersPost"></a>
# **membersPost**
> Member membersPost(member)

Üye Oluşturma

Yeni bir Üye oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.MemberApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

MemberApi apiInstance = new MemberApi();
Member member = new Member(); // Member |  nesnesi
try {
    Member result = apiInstance.membersPost(member);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling MemberApi#membersPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member** | [**Member**](Member.md)|  nesnesi |

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

