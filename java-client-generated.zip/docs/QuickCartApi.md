# QuickCartApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**quickCartsGet**](QuickCartApi.md#quickCartsGet) | **GET** /quick_carts | Hızlı Satın Al Bağlantısı Alma
[**quickCartsIdDelete**](QuickCartApi.md#quickCartsIdDelete) | **DELETE** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Silme
[**quickCartsIdGet**](QuickCartApi.md#quickCartsIdGet) | **GET** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Alma
[**quickCartsIdPut**](QuickCartApi.md#quickCartsIdPut) | **PUT** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Güncelleme
[**quickCartsPost**](QuickCartApi.md#quickCartsPost) | **POST** /quick_carts | Hızlı Satın Al Bağlantısı Oluşturma


<a name="quickCartsGet"></a>
# **quickCartsGet**
> QuickCart quickCartsGet(sort, limit, page, sinceId, name)

Hızlı Satın Al Bağlantısı Alma

Hızlı Satın Al Bağlantısı döndürür.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.QuickCartApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

QuickCartApi apiInstance = new QuickCartApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String name = "name_example"; // String | Hızlı Satın Al Bağlantısı adı
try {
    QuickCart result = apiInstance.quickCartsGet(sort, limit, page, sinceId, name);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling QuickCartApi#quickCartsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **name** | **String**| Hızlı Satın Al Bağlantısı adı | [optional]

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="quickCartsIdDelete"></a>
# **quickCartsIdDelete**
> quickCartsIdDelete(id)

Hızlı Satın Al Bağlantısı Silme

Kalıcı olarak ilgili Hızlı Satın Al Bağlantısını siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.QuickCartApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

QuickCartApi apiInstance = new QuickCartApi();
Integer id = 56; // Integer | Hızlı Satın Al nesnesinin id değeri
try {
    apiInstance.quickCartsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling QuickCartApi#quickCartsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Hızlı Satın Al nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="quickCartsIdGet"></a>
# **quickCartsIdGet**
> QuickCart quickCartsIdGet(id)

Hızlı Satın Al Bağlantısı Alma

İlgili Hızlı Satın Al Bağlantısını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.QuickCartApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

QuickCartApi apiInstance = new QuickCartApi();
Integer id = 56; // Integer | Hızlı Satın Al nesnesinin id değeri
try {
    QuickCart result = apiInstance.quickCartsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling QuickCartApi#quickCartsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Hızlı Satın Al nesnesinin id değeri |

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="quickCartsIdPut"></a>
# **quickCartsIdPut**
> QuickCart quickCartsIdPut(id, quickCart)

Hızlı Satın Al Bağlantısı Güncelleme

İlgili Hızlı Satın Al Bağlantısını günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.QuickCartApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

QuickCartApi apiInstance = new QuickCartApi();
Integer id = 56; // Integer | Hızlı Satın Al nesnesinin id değeri
QuickCart quickCart = new QuickCart(); // QuickCart | QuickCart nesnesi
try {
    QuickCart result = apiInstance.quickCartsIdPut(id, quickCart);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling QuickCartApi#quickCartsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Hızlı Satın Al nesnesinin id değeri |
 **quickCart** | [**QuickCart**](QuickCart.md)| QuickCart nesnesi |

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="quickCartsPost"></a>
# **quickCartsPost**
> QuickCart quickCartsPost(quickCart)

Hızlı Satın Al Bağlantısı Oluşturma

Yeni bir Hızlı Satın Al Bağlantısı oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.QuickCartApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

QuickCartApi apiInstance = new QuickCartApi();
QuickCart quickCart = new QuickCart(); // QuickCart | QuickCart nesnesi
try {
    QuickCart result = apiInstance.quickCartsPost(quickCart);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling QuickCartApi#quickCartsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **quickCart** | [**QuickCart**](QuickCart.md)| QuickCart nesnesi |

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

