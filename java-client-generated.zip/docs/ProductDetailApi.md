# ProductDetailApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productDetailsGet**](ProductDetailApi.md#productDetailsGet) | **GET** /product_details | Ürün Detay Listesi Alma
[**productDetailsIdDelete**](ProductDetailApi.md#productDetailsIdDelete) | **DELETE** /product_details/{id} | Ürün Detay Silme
[**productDetailsIdGet**](ProductDetailApi.md#productDetailsIdGet) | **GET** /product_details/{id} | Ürün Detay Alma
[**productDetailsIdPut**](ProductDetailApi.md#productDetailsIdPut) | **PUT** /product_details/{id} | Ürün Detay Güncelleme
[**productDetailsPost**](ProductDetailApi.md#productDetailsPost) | **POST** /product_details | Ürün Detay Oluşturma


<a name="productDetailsGet"></a>
# **productDetailsGet**
> ProductDetail productDetailsGet(sort, limit, page, sinceId, ids, sku)

Ürün Detay Listesi Alma

Ürün Detay listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductDetailApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductDetailApi apiInstance = new ProductDetailApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String sku = "sku_example"; // String | Ürün stok kodu
try {
    ProductDetail result = apiInstance.productDetailsGet(sort, limit, page, sinceId, ids, sku);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductDetailApi#productDetailsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **sku** | **String**| Ürün stok kodu | [optional]

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productDetailsIdDelete"></a>
# **productDetailsIdDelete**
> productDetailsIdDelete(id)

Ürün Detay Silme

Kalıcı olarak ilgili Ürün Detayını siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductDetailApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductDetailApi apiInstance = new ProductDetailApi();
Integer id = 56; // Integer | Ürün Detay nesnesinin id değeri
try {
    apiInstance.productDetailsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductDetailApi#productDetailsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Detay nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productDetailsIdGet"></a>
# **productDetailsIdGet**
> ProductDetail productDetailsIdGet(id)

Ürün Detay Alma

İlgili Ürün Detayını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductDetailApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductDetailApi apiInstance = new ProductDetailApi();
Integer id = 56; // Integer | Ürün Detay nesnesinin id değeri
try {
    ProductDetail result = apiInstance.productDetailsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductDetailApi#productDetailsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Detay nesnesinin id değeri |

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productDetailsIdPut"></a>
# **productDetailsIdPut**
> ProductDetail productDetailsIdPut(id, productDetail)

Ürün Detay Güncelleme

İlgili Ürün Detayını günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductDetailApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductDetailApi apiInstance = new ProductDetailApi();
Integer id = 56; // Integer | Ürün Detay nesnesinin id değeri
ProductDetail productDetail = new ProductDetail(); // ProductDetail |  nesnesi
try {
    ProductDetail result = apiInstance.productDetailsIdPut(id, productDetail);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductDetailApi#productDetailsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Detay nesnesinin id değeri |
 **productDetail** | [**ProductDetail**](ProductDetail.md)|  nesnesi |

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productDetailsPost"></a>
# **productDetailsPost**
> ProductDetail productDetailsPost(productDetail)

Ürün Detay Oluşturma

Yeni bir Ürün Detay oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductDetailApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductDetailApi apiInstance = new ProductDetailApi();
ProductDetail productDetail = new ProductDetail(); // ProductDetail |  nesnesi
try {
    ProductDetail result = apiInstance.productDetailsPost(productDetail);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductDetailApi#productDetailsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productDetail** | [**ProductDetail**](ProductDetail.md)|  nesnesi |

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

