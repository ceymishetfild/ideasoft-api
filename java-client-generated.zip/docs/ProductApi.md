# ProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productsGet**](ProductApi.md#productsGet) | **GET** /products | Ürün Listesi Alma
[**productsIdDelete**](ProductApi.md#productsIdDelete) | **DELETE** /products/{id} | Ürün Silme
[**productsIdGet**](ProductApi.md#productsIdGet) | **GET** /products/{id} | Ürün Alma
[**productsIdPut**](ProductApi.md#productsIdPut) | **PUT** /products/{id} | Ürün Güncelleme
[**productsPost**](ProductApi.md#productsPost) | **POST** /products | Ürün Oluşturma


<a name="productsGet"></a>
# **productsGet**
> Product productsGet(sort, limit, page, sinceId, parent, brand, sku, name, distributor, q, startDate, endDate, startUpdatedAt, endUpdatedAt)

Ürün Listesi Alma

Ürün listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductApi apiInstance = new ProductApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String parent = "parent_example"; // String | Ürün id
Integer brand = 56; // Integer | Marka id
String sku = "sku_example"; // String | Ürün stok kodu.
String name = "name_example"; // String | Ürün adı.
String distributor = "distributor_example"; // String | Ürün distribütör.
List<String> q = Arrays.asList("q_example"); // List<String> | Ürün arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;]
LocalDate startDate = new LocalDate(); // LocalDate | createdAt değeri için başlangıç tarihi
String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
LocalDate startUpdatedAt = new LocalDate(); // LocalDate | updatedAt değeri için başlangıç tarihi
String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
try {
    Product result = apiInstance.productsGet(sort, limit, page, sinceId, parent, brand, sku, name, distributor, q, startDate, endDate, startUpdatedAt, endUpdatedAt);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductApi#productsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **parent** | **String**| Ürün id | [optional]
 **brand** | **Integer**| Marka id | [optional]
 **sku** | **String**| Ürün stok kodu. | [optional]
 **name** | **String**| Ürün adı. | [optional]
 **distributor** | **String**| Ürün distribütör. | [optional]
 **q** | [**List&lt;String&gt;**](String.md)| Ürün arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional]
 **startDate** | **LocalDate**| createdAt değeri için başlangıç tarihi | [optional]
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional]
 **startUpdatedAt** | **LocalDate**| updatedAt değeri için başlangıç tarihi | [optional]
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional]

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productsIdDelete"></a>
# **productsIdDelete**
> productsIdDelete(id)

Ürün Silme

Kalıcı olarak ilgili Ürünü siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductApi apiInstance = new ProductApi();
Integer id = 56; // Integer | Ürün nesnesinin id değeri
try {
    apiInstance.productsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductApi#productsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productsIdGet"></a>
# **productsIdGet**
> Product productsIdGet(id)

Ürün Alma

İlgili Ürünü getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductApi apiInstance = new ProductApi();
Integer id = 56; // Integer | Ürün nesnesinin id değeri
try {
    Product result = apiInstance.productsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductApi#productsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün nesnesinin id değeri |

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productsIdPut"></a>
# **productsIdPut**
> Product productsIdPut(id, product)

Ürün Güncelleme

İlgili Ürünü günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductApi apiInstance = new ProductApi();
Integer id = 56; // Integer | Ürün nesnesinin id değeri
Product product = new Product(); // Product | Product nesnesi
try {
    Product result = apiInstance.productsIdPut(id, product);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductApi#productsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün nesnesinin id değeri |
 **product** | [**Product**](Product.md)| Product nesnesi |

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productsPost"></a>
# **productsPost**
> Product productsPost(product)

Ürün Oluşturma

Yeni bir Ürün oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductApi apiInstance = new ProductApi();
Product product = new Product(); // Product | Product nesnesi
try {
    Product result = apiInstance.productsPost(product);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductApi#productsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product** | [**Product**](Product.md)| Product nesnesi |

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

