
# OrderUserNote

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sipariş yönetici notu nesnesi kimlik değeri. |  [optional]
**userEmail** | **String** | Yöneticinin(admin) e-mail adresi. | 
**userFirstname** | **String** | Yöneticinin(admin) ismi. |  [optional]
**userSurname** | **String** | Yöneticinin(admin) soy ismi. |  [optional]
**note** | **String** | Yöneticinin(admin) sipariş için girdiği not. | 
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) | Sipariş yönetici notu nesnesinin oluşturulma zamanı. | 
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) | Sipariş yönetici notu nesnesinin güncellenme zamanı. | 
**order** | [**Order**](Order.md) |  |  [optional]



