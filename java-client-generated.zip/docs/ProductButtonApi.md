# ProductButtonApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productButtonsGet**](ProductButtonApi.md#productButtonsGet) | **GET** /product_buttons | Ürün ve Stok Butonu Listesi Alma
[**productButtonsIdDelete**](ProductButtonApi.md#productButtonsIdDelete) | **DELETE** /product_buttons/{id} | Ürün ve Stok Butonu Silme
[**productButtonsIdGet**](ProductButtonApi.md#productButtonsIdGet) | **GET** /product_buttons/{id} | Ürün ve Stok Butonu Alma
[**productButtonsIdPut**](ProductButtonApi.md#productButtonsIdPut) | **PUT** /product_buttons/{id} | Ürün ve Stok Butonu Güncelleme
[**productButtonsPost**](ProductButtonApi.md#productButtonsPost) | **POST** /product_buttons | Ürün ve Stok Butonu Oluşturma


<a name="productButtonsGet"></a>
# **productButtonsGet**
> ProductButton productButtonsGet(sort, limit, page, sinceId, ids, fastShipping, sameDayShipping, threeDaysDelivery, fiveDaysDelivery, sevenDaysDelivery, freeShipping, deliveryFromStock, preOrderedProduct, askStock, campaignedProduct, product)

Ürün ve Stok Butonu Listesi Alma

Ürün ve Stok Butonu listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductButtonApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductButtonApi apiInstance = new ProductButtonApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String fastShipping = "fastShipping_example"; // String | Hızlı Gönderi butonuna sahip ürünler<code>0</code><br><code>1</code>
String sameDayShipping = "sameDayShipping_example"; // String | Aynı Gün Kargo butonuna sahip ürünler<code>0</code><br><code>1</code>
String threeDaysDelivery = "threeDaysDelivery_example"; // String | 3 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
String fiveDaysDelivery = "fiveDaysDelivery_example"; // String | 5 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
String sevenDaysDelivery = "sevenDaysDelivery_example"; // String | 7 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
String freeShipping = "freeShipping_example"; // String | Kargo Bedava butonuna sahip ürünler<code>0</code><br><code>1</code>
String deliveryFromStock = "deliveryFromStock_example"; // String | Stoktan Teslim butonuna sahip ürünler<code>0</code><br><code>1</code>
String preOrderedProduct = "preOrderedProduct_example"; // String | Ön Siparişli Ürün butonuna sahip ürünler<code>0</code><br><code>1</code>
String askStock = "askStock_example"; // String | Stok Sorunuz butonuna sahip ürünler<code>0</code><br><code>1</code>
String campaignedProduct = "campaignedProduct_example"; // String | Kampanyalı Ürün butonuna sahip ürünler<code>0</code><br><code>1</code>
Integer product = 56; // Integer | Ürün id
try {
    ProductButton result = apiInstance.productButtonsGet(sort, limit, page, sinceId, ids, fastShipping, sameDayShipping, threeDaysDelivery, fiveDaysDelivery, sevenDaysDelivery, freeShipping, deliveryFromStock, preOrderedProduct, askStock, campaignedProduct, product);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductButtonApi#productButtonsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **fastShipping** | **String**| Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] [enum: 0, 1]
 **sameDayShipping** | **String**| Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] [enum: 0, 1]
 **threeDaysDelivery** | **String**| 3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] [enum: 0, 1]
 **fiveDaysDelivery** | **String**| 5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] [enum: 0, 1]
 **sevenDaysDelivery** | **String**| 7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] [enum: 0, 1]
 **freeShipping** | **String**| Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] [enum: 0, 1]
 **deliveryFromStock** | **String**| Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] [enum: 0, 1]
 **preOrderedProduct** | **String**| Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] [enum: 0, 1]
 **askStock** | **String**| Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] [enum: 0, 1]
 **campaignedProduct** | **String**| Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] [enum: 0, 1]
 **product** | **Integer**| Ürün id | [optional]

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productButtonsIdDelete"></a>
# **productButtonsIdDelete**
> productButtonsIdDelete(id)

Ürün ve Stok Butonu Silme

Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductButtonApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductButtonApi apiInstance = new ProductButtonApi();
Integer id = 56; // Integer | Ürün ve Stok Butonu nesnesinin id değeri
try {
    apiInstance.productButtonsIdDelete(id);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductButtonApi#productButtonsIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün ve Stok Butonu nesnesinin id değeri |

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productButtonsIdGet"></a>
# **productButtonsIdGet**
> ProductButton productButtonsIdGet(id)

Ürün ve Stok Butonu Alma

İlgili Ürün ve Stok Butonunu getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductButtonApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductButtonApi apiInstance = new ProductButtonApi();
Integer id = 56; // Integer | Ürün ve Stok Butonu nesnesinin id değeri
try {
    ProductButton result = apiInstance.productButtonsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductButtonApi#productButtonsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün ve Stok Butonu nesnesinin id değeri |

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productButtonsIdPut"></a>
# **productButtonsIdPut**
> ProductButton productButtonsIdPut(id, productButton)

Ürün ve Stok Butonu Güncelleme

İlgili Ürün ve Stok Butonunu günceller.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductButtonApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductButtonApi apiInstance = new ProductButtonApi();
Integer id = 56; // Integer | Ürün ve Stok Butonu nesnesinin id değeri
ProductButton productButton = new ProductButton(); // ProductButton |  nesnesi
try {
    ProductButton result = apiInstance.productButtonsIdPut(id, productButton);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductButtonApi#productButtonsIdPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün ve Stok Butonu nesnesinin id değeri |
 **productButton** | [**ProductButton**](ProductButton.md)|  nesnesi |

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productButtonsPost"></a>
# **productButtonsPost**
> ProductButton productButtonsPost(productButton)

Ürün ve Stok Butonu Oluşturma

Yeni bir Ürün ve Stok Butonu oluşturur.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ProductButtonApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

ProductButtonApi apiInstance = new ProductButtonApi();
ProductButton productButton = new ProductButton(); // ProductButton |  nesnesi
try {
    ProductButton result = apiInstance.productButtonsPost(productButton);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductButtonApi#productButtonsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productButton** | [**ProductButton**](ProductButton.md)|  nesnesi |

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

