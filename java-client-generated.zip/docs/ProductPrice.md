
# ProductPrice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ürün fiyatı nesnesi kimlik değeri. |  [optional]
**value** | **Float** | Ürün fiyatı değeri. | 
**type** | **Integer** | Ürün fiyatı indexi. Fiyat 2, Fiyat 3 gibi. | 
**product** | [**Product**](Product.md) |  |  [optional]



