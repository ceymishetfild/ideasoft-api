
# Theme

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Tema nesnesi kimlik değeri. |  [optional]
**platform** | [**PlatformEnum**](#PlatformEnum) | Temanın kullanılacağı platform.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü.&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil.&lt;br&gt;&lt;/div&gt; | 
**type** | [**TypeEnum**](#TypeEnum) | Tema tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;self&lt;/code&gt; : Kişisel Tema.&lt;br&gt;&lt;code&gt;standard&lt;/code&gt; : Standart Tema.&lt;br&gt;&lt;/div&gt; |  [optional]
**name** | **String** | Tema adı. | 
**preset** | **String** | Temanın rengi. |  [optional]
**directoryName** | **String** | Temanın dizini. |  [optional]
**status** | [**StatusEnum**](#StatusEnum) | Temanın durumu. | 
**revision** | **Integer** | Temanın revisionı. |  [optional]
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) | Tema nesnesinin oluşturulma zamanı. |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) | Tema nesnesinin güncellenme zamanı. |  [optional]
**attachment** | **String** |  |  [optional]


<a name="PlatformEnum"></a>
## Enum: PlatformEnum
Name | Value
---- | -----
DESKTOP | &quot;desktop&quot;
MOBILE | &quot;mobile&quot;


<a name="TypeEnum"></a>
## Enum: TypeEnum
Name | Value
---- | -----
SELF | &quot;self&quot;
STANDARD | &quot;standard&quot;


<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;



