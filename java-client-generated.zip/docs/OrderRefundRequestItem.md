
# OrderRefundRequestItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sipariş iptal talebi kalemi nesnesi kimlik değeri. |  [optional]
**amount** | **Float** | Sipariş iptal talebi istenen ürün miktarı. | 
**reason** | **String** | Sipariş iptal talebi sebebi. Tanımlı dört seçenekten biri seçilmelidir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Ürünü iade etmek istiyorum.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Ürünü değiştirmek istiyorum.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Faturadaki ürünler ile bana gelen ürünler farklı.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Diğer&lt;/code&gt; : &lt;br&gt;&lt;/div&gt; | 
**details** | **String** | Sipariş iptal talebinin detaylı açıklaması. | 
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) | Sipariş iptal talebi kalemi nesnesinin oluşturulma zamanı. |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) | Sipariş iptal talebi kalemi nesnesinin güncellenme zamanı. |  [optional]
**orderItem** | [**OrderItem**](OrderItem.md) | Sipariş kalemi nesnesi. | 
**orderRefundRequest** | [**OrderRefundRequest**](OrderRefundRequest.md) | Sipariş iptal talebi nesnesi. | 



