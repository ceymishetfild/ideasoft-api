# PaymentProviderApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**paymentProvidersGet**](PaymentProviderApi.md#paymentProvidersGet) | **GET** /payment_providers | Ödeme Altyapısı Sağlayıcısı Listesi Alma
[**paymentProvidersIdGet**](PaymentProviderApi.md#paymentProvidersIdGet) | **GET** /payment_providers/{id} | Ödeme Altyapısı Sağlayıcısı Alma


<a name="paymentProvidersGet"></a>
# **paymentProvidersGet**
> PaymentProvider paymentProvidersGet(sort, limit, page, sinceId, ids, code, name)

Ödeme Altyapısı Sağlayıcısı Listesi Alma

Ödeme Altyapısı Sağlayıcısı listesini verir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.PaymentProviderApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

PaymentProviderApi apiInstance = new PaymentProviderApi();
String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
Integer page = 1; // Integer | Hangi sayfadan başlanacağı
Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
String ids = "ids_example"; // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
String code = "code_example"; // String | Ödeme Altyapısı kodu
String name = "name_example"; // String | Ödeme Altyapısı adı
try {
    PaymentProvider result = apiInstance.paymentProvidersGet(sort, limit, page, sinceId, ids, code, name);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PaymentProviderApi#paymentProvidersGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] [enum: id]
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional]
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional]
 **code** | **String**| Ödeme Altyapısı kodu | [optional]
 **name** | **String**| Ödeme Altyapısı adı | [optional]

### Return type

[**PaymentProvider**](PaymentProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="paymentProvidersIdGet"></a>
# **paymentProvidersIdGet**
> PaymentProvider paymentProvidersIdGet(id)

Ödeme Altyapısı Sağlayıcısı Alma

İlgili Ödeme Altyapısı Sağlayıcısını getirir.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.PaymentProviderApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: OAuth2
OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
OAuth2.setAccessToken("YOUR ACCESS TOKEN");

PaymentProviderApi apiInstance = new PaymentProviderApi();
Integer id = 56; // Integer | Ödeme Altyapııs Sağlayıcısı nesnesinin id değeri
try {
    PaymentProvider result = apiInstance.paymentProvidersIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PaymentProviderApi#paymentProvidersIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ödeme Altyapııs Sağlayıcısı nesnesinin id değeri |

### Return type

[**PaymentProvider**](PaymentProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

