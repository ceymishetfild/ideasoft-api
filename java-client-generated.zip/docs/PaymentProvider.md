
# PaymentProvider

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ödeme altyapısı sağlayıcısı nesnesi kimlik değeri. |  [optional]
**code** | **String** | Ödeme altyapısı sağlayıcısı için ön tanımlanmış kod değeri. | 
**name** | **String** | Ödeme altyapısı sağlayıcısı için isim değeri. | 
**status** | [**StatusEnum**](#StatusEnum) | Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer. | 
**paymentType** | [**PaymentType**](PaymentType.md) |  |  [optional]
**settings** | [**List&lt;PaymentProviderSetting&gt;**](PaymentProviderSetting.md) | Ödeme altyapısı sağlayıcısı ayarları |  [optional]


<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;



