
# Asset

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** | Tema Dosyası nesnesi anahtar değeri. |  [optional]
**contentType** | **String** | Tema Dosyası içerik tipi. Geçerli bir MIME Content-Type verilmelidir. |  [optional]
**attachment** | **String** | Tema Dosyası içeriği. |  [optional]
**createdAt** | [**OffsetDateTime**](OffsetDateTime.md) | Tema Dosyası nesnesinin oluşturulma zamanı. |  [optional]
**updatedAt** | [**OffsetDateTime**](OffsetDateTime.md) | Tema Dosyası nesnesinin güncellenme zamanı. |  [optional]



