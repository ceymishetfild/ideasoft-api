

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import io.swagger.client.model.SpecValue;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SpecValueApi {
    private ApiClient apiClient;

    public SpecValueApi() {
        this(Configuration.getDefaultApiClient());
    }

    public SpecValueApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for specValuesGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Ürün özellik adı (optional)
     * @param specName Ürün özellik id (optional)
     * @param specValue Ürün özellik değeri id (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call specValuesGetCall(String sort, Integer limit, Integer page, Integer sinceId, String name, Integer specName, Integer specValue, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/spec_values";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (name != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("name", name));
        if (specName != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("specName", specName));
        if (specValue != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("specValue", specValue));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call specValuesGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, String name, Integer specName, Integer specValue, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = specValuesGetCall(sort, limit, page, sinceId, name, specName, specValue, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün Özellik Değeri Listesi Alma
     * Ürün Özellik Değeri listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Ürün özellik adı (optional)
     * @param specName Ürün özellik id (optional)
     * @param specValue Ürün özellik değeri id (optional)
     * @return SpecValue
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SpecValue specValuesGet(String sort, Integer limit, Integer page, Integer sinceId, String name, Integer specName, Integer specValue) throws ApiException {
        ApiResponse<SpecValue> resp = specValuesGetWithHttpInfo(sort, limit, page, sinceId, name, specName, specValue);
        return resp.getData();
    }

    /**
     * Ürün Özellik Değeri Listesi Alma
     * Ürün Özellik Değeri listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Ürün özellik adı (optional)
     * @param specName Ürün özellik id (optional)
     * @param specValue Ürün özellik değeri id (optional)
     * @return ApiResponse&lt;SpecValue&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SpecValue> specValuesGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, String name, Integer specName, Integer specValue) throws ApiException {
        com.squareup.okhttp.Call call = specValuesGetValidateBeforeCall(sort, limit, page, sinceId, name, specName, specValue, null, null);
        Type localVarReturnType = new TypeToken<SpecValue>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün Özellik Değeri Listesi Alma (asynchronously)
     * Ürün Özellik Değeri listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Ürün özellik adı (optional)
     * @param specName Ürün özellik id (optional)
     * @param specValue Ürün özellik değeri id (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call specValuesGetAsync(String sort, Integer limit, Integer page, Integer sinceId, String name, Integer specName, Integer specValue, final ApiCallback<SpecValue> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = specValuesGetValidateBeforeCall(sort, limit, page, sinceId, name, specName, specValue, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SpecValue>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for specValuesIdDelete
     * @param id Ürün Özellik Değeri nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call specValuesIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/spec_values/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call specValuesIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling specValuesIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = specValuesIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün Özellik Değeri Silme
     * Kalıcı olarak ilgili Ürün Özellik Değerini siler.
     * @param id Ürün Özellik Değeri nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void specValuesIdDelete(Integer id) throws ApiException {
        specValuesIdDeleteWithHttpInfo(id);
    }

    /**
     * Ürün Özellik Değeri Silme
     * Kalıcı olarak ilgili Ürün Özellik Değerini siler.
     * @param id Ürün Özellik Değeri nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> specValuesIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = specValuesIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Ürün Özellik Değeri Silme (asynchronously)
     * Kalıcı olarak ilgili Ürün Özellik Değerini siler.
     * @param id Ürün Özellik Değeri nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call specValuesIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = specValuesIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for specValuesIdGet
     * @param id Ürün Özellik Değeri nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call specValuesIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/spec_values/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call specValuesIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling specValuesIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = specValuesIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün Özellik Değeri Alma
     * İlgili Ürün Özellik Değerini getirir.
     * @param id Ürün Özellik Değeri nesnesinin id değeri (required)
     * @return SpecValue
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SpecValue specValuesIdGet(Integer id) throws ApiException {
        ApiResponse<SpecValue> resp = specValuesIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Ürün Özellik Değeri Alma
     * İlgili Ürün Özellik Değerini getirir.
     * @param id Ürün Özellik Değeri nesnesinin id değeri (required)
     * @return ApiResponse&lt;SpecValue&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SpecValue> specValuesIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = specValuesIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<SpecValue>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün Özellik Değeri Alma (asynchronously)
     * İlgili Ürün Özellik Değerini getirir.
     * @param id Ürün Özellik Değeri nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call specValuesIdGetAsync(Integer id, final ApiCallback<SpecValue> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = specValuesIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SpecValue>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for specValuesIdPut
     * @param id Ürün Özellik Değeri nesnesinin id değeri (required)
     * @param specValue SpecValue nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call specValuesIdPutCall(Integer id, SpecValue specValue, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = specValue;

        // create path and map variables
        String localVarPath = "/spec_values/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call specValuesIdPutValidateBeforeCall(Integer id, SpecValue specValue, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling specValuesIdPut(Async)");
        }
        
        // verify the required parameter 'specValue' is set
        if (specValue == null) {
            throw new ApiException("Missing the required parameter 'specValue' when calling specValuesIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = specValuesIdPutCall(id, specValue, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün Özellik Değeri Güncelleme
     * İlgili Ürün Özellik Değerini günceller.
     * @param id Ürün Özellik Değeri nesnesinin id değeri (required)
     * @param specValue SpecValue nesnesi (required)
     * @return SpecValue
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SpecValue specValuesIdPut(Integer id, SpecValue specValue) throws ApiException {
        ApiResponse<SpecValue> resp = specValuesIdPutWithHttpInfo(id, specValue);
        return resp.getData();
    }

    /**
     * Ürün Özellik Değeri Güncelleme
     * İlgili Ürün Özellik Değerini günceller.
     * @param id Ürün Özellik Değeri nesnesinin id değeri (required)
     * @param specValue SpecValue nesnesi (required)
     * @return ApiResponse&lt;SpecValue&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SpecValue> specValuesIdPutWithHttpInfo(Integer id, SpecValue specValue) throws ApiException {
        com.squareup.okhttp.Call call = specValuesIdPutValidateBeforeCall(id, specValue, null, null);
        Type localVarReturnType = new TypeToken<SpecValue>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün Özellik Değeri Güncelleme (asynchronously)
     * İlgili Ürün Özellik Değerini günceller.
     * @param id Ürün Özellik Değeri nesnesinin id değeri (required)
     * @param specValue SpecValue nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call specValuesIdPutAsync(Integer id, SpecValue specValue, final ApiCallback<SpecValue> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = specValuesIdPutValidateBeforeCall(id, specValue, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SpecValue>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for specValuesPost
     * @param specValue SpecValue nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call specValuesPostCall(SpecValue specValue, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = specValue;

        // create path and map variables
        String localVarPath = "/spec_values";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call specValuesPostValidateBeforeCall(SpecValue specValue, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'specValue' is set
        if (specValue == null) {
            throw new ApiException("Missing the required parameter 'specValue' when calling specValuesPost(Async)");
        }
        

        com.squareup.okhttp.Call call = specValuesPostCall(specValue, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün Özellik Değeri Oluşturma
     * Yeni bir Ürün Özellik Değeri oluşturur.
     * @param specValue SpecValue nesnesi (required)
     * @return SpecValue
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SpecValue specValuesPost(SpecValue specValue) throws ApiException {
        ApiResponse<SpecValue> resp = specValuesPostWithHttpInfo(specValue);
        return resp.getData();
    }

    /**
     * Ürün Özellik Değeri Oluşturma
     * Yeni bir Ürün Özellik Değeri oluşturur.
     * @param specValue SpecValue nesnesi (required)
     * @return ApiResponse&lt;SpecValue&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SpecValue> specValuesPostWithHttpInfo(SpecValue specValue) throws ApiException {
        com.squareup.okhttp.Call call = specValuesPostValidateBeforeCall(specValue, null, null);
        Type localVarReturnType = new TypeToken<SpecValue>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün Özellik Değeri Oluşturma (asynchronously)
     * Yeni bir Ürün Özellik Değeri oluşturur.
     * @param specValue SpecValue nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call specValuesPostAsync(SpecValue specValue, final ApiCallback<SpecValue> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = specValuesPostValidateBeforeCall(specValue, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SpecValue>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
