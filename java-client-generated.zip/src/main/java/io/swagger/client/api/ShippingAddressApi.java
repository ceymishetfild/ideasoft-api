

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.ShippingAddress;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShippingAddressApi {
    private ApiClient apiClient;

    public ShippingAddressApi() {
        this(Configuration.getDefaultApiClient());
    }

    public ShippingAddressApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for shippingAddressesGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param order Sipariş id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call shippingAddressesGetCall(String sort, Integer limit, Integer page, Integer sinceId, Integer order, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/shipping_addresses";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (order != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("order", order));
        if (startDate != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("startDate", startDate));
        if (endDate != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("endDate", endDate));
        if (startUpdatedAt != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("startUpdatedAt", startUpdatedAt));
        if (endUpdatedAt != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("endUpdatedAt", endUpdatedAt));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call shippingAddressesGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, Integer order, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = shippingAddressesGetCall(sort, limit, page, sinceId, order, startDate, endDate, startUpdatedAt, endUpdatedAt, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Teslimat Adresi Listesi Alma
     * Teslimat Adresi listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param order Sipariş id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @return ShippingAddress
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ShippingAddress shippingAddressesGet(String sort, Integer limit, Integer page, Integer sinceId, Integer order, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt) throws ApiException {
        ApiResponse<ShippingAddress> resp = shippingAddressesGetWithHttpInfo(sort, limit, page, sinceId, order, startDate, endDate, startUpdatedAt, endUpdatedAt);
        return resp.getData();
    }

    /**
     * Teslimat Adresi Listesi Alma
     * Teslimat Adresi listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param order Sipariş id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @return ApiResponse&lt;ShippingAddress&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ShippingAddress> shippingAddressesGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, Integer order, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt) throws ApiException {
        com.squareup.okhttp.Call call = shippingAddressesGetValidateBeforeCall(sort, limit, page, sinceId, order, startDate, endDate, startUpdatedAt, endUpdatedAt, null, null);
        Type localVarReturnType = new TypeToken<ShippingAddress>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Teslimat Adresi Listesi Alma (asynchronously)
     * Teslimat Adresi listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param order Sipariş id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call shippingAddressesGetAsync(String sort, Integer limit, Integer page, Integer sinceId, Integer order, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, final ApiCallback<ShippingAddress> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = shippingAddressesGetValidateBeforeCall(sort, limit, page, sinceId, order, startDate, endDate, startUpdatedAt, endUpdatedAt, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ShippingAddress>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for shippingAddressesIdGet
     * @param id Teslimat Adresi nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call shippingAddressesIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/shipping_addresses/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call shippingAddressesIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling shippingAddressesIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = shippingAddressesIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Teslimat Adresi Alma
     * İlgili Teslimat Adresi getirir.
     * @param id Teslimat Adresi nesnesinin id değeri (required)
     * @return ShippingAddress
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ShippingAddress shippingAddressesIdGet(Integer id) throws ApiException {
        ApiResponse<ShippingAddress> resp = shippingAddressesIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Teslimat Adresi Alma
     * İlgili Teslimat Adresi getirir.
     * @param id Teslimat Adresi nesnesinin id değeri (required)
     * @return ApiResponse&lt;ShippingAddress&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ShippingAddress> shippingAddressesIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = shippingAddressesIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<ShippingAddress>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Teslimat Adresi Alma (asynchronously)
     * İlgili Teslimat Adresi getirir.
     * @param id Teslimat Adresi nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call shippingAddressesIdGetAsync(Integer id, final ApiCallback<ShippingAddress> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = shippingAddressesIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ShippingAddress>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for shippingAddressesIdPut
     * @param id Teslimat Adresi nesnesinin id değeri (required)
     * @param shippingAddress ShippingAddress nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call shippingAddressesIdPutCall(Integer id, ShippingAddress shippingAddress, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = shippingAddress;

        // create path and map variables
        String localVarPath = "/shipping_addresses/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call shippingAddressesIdPutValidateBeforeCall(Integer id, ShippingAddress shippingAddress, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling shippingAddressesIdPut(Async)");
        }
        
        // verify the required parameter 'shippingAddress' is set
        if (shippingAddress == null) {
            throw new ApiException("Missing the required parameter 'shippingAddress' when calling shippingAddressesIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = shippingAddressesIdPutCall(id, shippingAddress, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Teslimat Adresi Güncelleme
     * İlgili Teslimat Adresi günceller.
     * @param id Teslimat Adresi nesnesinin id değeri (required)
     * @param shippingAddress ShippingAddress nesnesi (required)
     * @return ShippingAddress
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ShippingAddress shippingAddressesIdPut(Integer id, ShippingAddress shippingAddress) throws ApiException {
        ApiResponse<ShippingAddress> resp = shippingAddressesIdPutWithHttpInfo(id, shippingAddress);
        return resp.getData();
    }

    /**
     * Teslimat Adresi Güncelleme
     * İlgili Teslimat Adresi günceller.
     * @param id Teslimat Adresi nesnesinin id değeri (required)
     * @param shippingAddress ShippingAddress nesnesi (required)
     * @return ApiResponse&lt;ShippingAddress&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ShippingAddress> shippingAddressesIdPutWithHttpInfo(Integer id, ShippingAddress shippingAddress) throws ApiException {
        com.squareup.okhttp.Call call = shippingAddressesIdPutValidateBeforeCall(id, shippingAddress, null, null);
        Type localVarReturnType = new TypeToken<ShippingAddress>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Teslimat Adresi Güncelleme (asynchronously)
     * İlgili Teslimat Adresi günceller.
     * @param id Teslimat Adresi nesnesinin id değeri (required)
     * @param shippingAddress ShippingAddress nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call shippingAddressesIdPutAsync(Integer id, ShippingAddress shippingAddress, final ApiCallback<ShippingAddress> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = shippingAddressesIdPutValidateBeforeCall(id, shippingAddress, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ShippingAddress>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for shippingAddressesPost
     * @param shippingAddress ShippingAddress nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call shippingAddressesPostCall(ShippingAddress shippingAddress, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = shippingAddress;

        // create path and map variables
        String localVarPath = "/shipping_addresses";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call shippingAddressesPostValidateBeforeCall(ShippingAddress shippingAddress, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'shippingAddress' is set
        if (shippingAddress == null) {
            throw new ApiException("Missing the required parameter 'shippingAddress' when calling shippingAddressesPost(Async)");
        }
        

        com.squareup.okhttp.Call call = shippingAddressesPostCall(shippingAddress, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Teslimat Adresi Oluşturma
     * Yeni bir Teslimat Adresi oluşturur.
     * @param shippingAddress ShippingAddress nesnesi (required)
     * @return ShippingAddress
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ShippingAddress shippingAddressesPost(ShippingAddress shippingAddress) throws ApiException {
        ApiResponse<ShippingAddress> resp = shippingAddressesPostWithHttpInfo(shippingAddress);
        return resp.getData();
    }

    /**
     * Teslimat Adresi Oluşturma
     * Yeni bir Teslimat Adresi oluşturur.
     * @param shippingAddress ShippingAddress nesnesi (required)
     * @return ApiResponse&lt;ShippingAddress&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ShippingAddress> shippingAddressesPostWithHttpInfo(ShippingAddress shippingAddress) throws ApiException {
        com.squareup.okhttp.Call call = shippingAddressesPostValidateBeforeCall(shippingAddress, null, null);
        Type localVarReturnType = new TypeToken<ShippingAddress>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Teslimat Adresi Oluşturma (asynchronously)
     * Yeni bir Teslimat Adresi oluşturur.
     * @param shippingAddress ShippingAddress nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call shippingAddressesPostAsync(ShippingAddress shippingAddress, final ApiCallback<ShippingAddress> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = shippingAddressesPostValidateBeforeCall(shippingAddress, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ShippingAddress>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
