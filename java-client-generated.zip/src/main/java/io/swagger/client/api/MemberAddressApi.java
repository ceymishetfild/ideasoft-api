

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.MemberAddress;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MemberAddressApi {
    private ApiClient apiClient;

    public MemberAddressApi() {
        this(Configuration.getDefaultApiClient());
    }

    public MemberAddressApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for memberAddressesGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir (optional)
     * @param member Üye id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call memberAddressesGetCall(String sort, Integer limit, Integer page, Integer sinceId, Integer member, LocalDate startDate, String endDate, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/member_addresses";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (member != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("member", member));
        if (startDate != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("startDate", startDate));
        if (endDate != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("endDate", endDate));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call memberAddressesGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, Integer member, LocalDate startDate, String endDate, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = memberAddressesGetCall(sort, limit, page, sinceId, member, startDate, endDate, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Üye Adresi Listeleme
     * Üye Adresi listesi verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir (optional)
     * @param member Üye id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @return MemberAddress
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public MemberAddress memberAddressesGet(String sort, Integer limit, Integer page, Integer sinceId, Integer member, LocalDate startDate, String endDate) throws ApiException {
        ApiResponse<MemberAddress> resp = memberAddressesGetWithHttpInfo(sort, limit, page, sinceId, member, startDate, endDate);
        return resp.getData();
    }

    /**
     * Üye Adresi Listeleme
     * Üye Adresi listesi verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir (optional)
     * @param member Üye id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @return ApiResponse&lt;MemberAddress&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<MemberAddress> memberAddressesGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, Integer member, LocalDate startDate, String endDate) throws ApiException {
        com.squareup.okhttp.Call call = memberAddressesGetValidateBeforeCall(sort, limit, page, sinceId, member, startDate, endDate, null, null);
        Type localVarReturnType = new TypeToken<MemberAddress>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Üye Adresi Listeleme (asynchronously)
     * Üye Adresi listesi verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir (optional)
     * @param member Üye id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call memberAddressesGetAsync(String sort, Integer limit, Integer page, Integer sinceId, Integer member, LocalDate startDate, String endDate, final ApiCallback<MemberAddress> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = memberAddressesGetValidateBeforeCall(sort, limit, page, sinceId, member, startDate, endDate, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<MemberAddress>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for memberAddressesIdDelete
     * @param id Üye Adresi nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call memberAddressesIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/member_addresses/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call memberAddressesIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling memberAddressesIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = memberAddressesIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Üye Adresi Silme
     * Kalıcı olarak ilgili Üye Adresini siler.
     * @param id Üye Adresi nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void memberAddressesIdDelete(Integer id) throws ApiException {
        memberAddressesIdDeleteWithHttpInfo(id);
    }

    /**
     * Üye Adresi Silme
     * Kalıcı olarak ilgili Üye Adresini siler.
     * @param id Üye Adresi nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> memberAddressesIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = memberAddressesIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Üye Adresi Silme (asynchronously)
     * Kalıcı olarak ilgili Üye Adresini siler.
     * @param id Üye Adresi nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call memberAddressesIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = memberAddressesIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for memberAddressesIdGet
     * @param id Üye Adresi nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call memberAddressesIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/member_addresses/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call memberAddressesIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling memberAddressesIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = memberAddressesIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Üye Adresi Alma
     * İlgili Üye Adresini getirir.
     * @param id Üye Adresi nesnesinin id değeri (required)
     * @return MemberAddress
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public MemberAddress memberAddressesIdGet(Integer id) throws ApiException {
        ApiResponse<MemberAddress> resp = memberAddressesIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Üye Adresi Alma
     * İlgili Üye Adresini getirir.
     * @param id Üye Adresi nesnesinin id değeri (required)
     * @return ApiResponse&lt;MemberAddress&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<MemberAddress> memberAddressesIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = memberAddressesIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<MemberAddress>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Üye Adresi Alma (asynchronously)
     * İlgili Üye Adresini getirir.
     * @param id Üye Adresi nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call memberAddressesIdGetAsync(Integer id, final ApiCallback<MemberAddress> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = memberAddressesIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<MemberAddress>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for memberAddressesIdPut
     * @param id Üye Adresi nesnesinin id değeri (required)
     * @param memberAddress MemberAddress nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call memberAddressesIdPutCall(Integer id, MemberAddress memberAddress, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = memberAddress;

        // create path and map variables
        String localVarPath = "/member_addresses/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call memberAddressesIdPutValidateBeforeCall(Integer id, MemberAddress memberAddress, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling memberAddressesIdPut(Async)");
        }
        
        // verify the required parameter 'memberAddress' is set
        if (memberAddress == null) {
            throw new ApiException("Missing the required parameter 'memberAddress' when calling memberAddressesIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = memberAddressesIdPutCall(id, memberAddress, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Üye Adresi Güncelleme
     * İlgili Üye Adresini günceller.
     * @param id Üye Adresi nesnesinin id değeri (required)
     * @param memberAddress MemberAddress nesnesi (required)
     * @return MemberAddress
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public MemberAddress memberAddressesIdPut(Integer id, MemberAddress memberAddress) throws ApiException {
        ApiResponse<MemberAddress> resp = memberAddressesIdPutWithHttpInfo(id, memberAddress);
        return resp.getData();
    }

    /**
     * Üye Adresi Güncelleme
     * İlgili Üye Adresini günceller.
     * @param id Üye Adresi nesnesinin id değeri (required)
     * @param memberAddress MemberAddress nesnesi (required)
     * @return ApiResponse&lt;MemberAddress&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<MemberAddress> memberAddressesIdPutWithHttpInfo(Integer id, MemberAddress memberAddress) throws ApiException {
        com.squareup.okhttp.Call call = memberAddressesIdPutValidateBeforeCall(id, memberAddress, null, null);
        Type localVarReturnType = new TypeToken<MemberAddress>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Üye Adresi Güncelleme (asynchronously)
     * İlgili Üye Adresini günceller.
     * @param id Üye Adresi nesnesinin id değeri (required)
     * @param memberAddress MemberAddress nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call memberAddressesIdPutAsync(Integer id, MemberAddress memberAddress, final ApiCallback<MemberAddress> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = memberAddressesIdPutValidateBeforeCall(id, memberAddress, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<MemberAddress>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for memberAddressesPost
     * @param memberAddress MemberAddress nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call memberAddressesPostCall(MemberAddress memberAddress, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = memberAddress;

        // create path and map variables
        String localVarPath = "/member_addresses";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call memberAddressesPostValidateBeforeCall(MemberAddress memberAddress, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'memberAddress' is set
        if (memberAddress == null) {
            throw new ApiException("Missing the required parameter 'memberAddress' when calling memberAddressesPost(Async)");
        }
        

        com.squareup.okhttp.Call call = memberAddressesPostCall(memberAddress, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Üye Adresi Oluşturma
     * Yeni bir Üye Adresi oluşturur.
     * @param memberAddress MemberAddress nesnesi (required)
     * @return MemberAddress
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public MemberAddress memberAddressesPost(MemberAddress memberAddress) throws ApiException {
        ApiResponse<MemberAddress> resp = memberAddressesPostWithHttpInfo(memberAddress);
        return resp.getData();
    }

    /**
     * Üye Adresi Oluşturma
     * Yeni bir Üye Adresi oluşturur.
     * @param memberAddress MemberAddress nesnesi (required)
     * @return ApiResponse&lt;MemberAddress&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<MemberAddress> memberAddressesPostWithHttpInfo(MemberAddress memberAddress) throws ApiException {
        com.squareup.okhttp.Call call = memberAddressesPostValidateBeforeCall(memberAddress, null, null);
        Type localVarReturnType = new TypeToken<MemberAddress>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Üye Adresi Oluşturma (asynchronously)
     * Yeni bir Üye Adresi oluşturur.
     * @param memberAddress MemberAddress nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call memberAddressesPostAsync(MemberAddress memberAddress, final ApiCallback<MemberAddress> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = memberAddressesPostValidateBeforeCall(memberAddress, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<MemberAddress>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
