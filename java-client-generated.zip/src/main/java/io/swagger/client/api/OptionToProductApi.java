

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import io.swagger.client.model.OptionToProduct;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OptionToProductApi {
    private ApiClient apiClient;

    public OptionToProductApi() {
        this(Configuration.getDefaultApiClient());
    }

    public OptionToProductApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for optionToProductsGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param optionGroup Varyant Grubu id (optional)
     * @param option Varyant id (optional)
     * @param parentProductId Ana Ürün id (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call optionToProductsGetCall(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer optionGroup, Integer option, Integer parentProductId, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/option_to_products";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (product != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("product", product));
        if (optionGroup != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("optionGroup", optionGroup));
        if (option != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("option", option));
        if (parentProductId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("parentProductId", parentProductId));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call optionToProductsGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer optionGroup, Integer option, Integer parentProductId, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = optionToProductsGetCall(sort, limit, page, sinceId, product, optionGroup, option, parentProductId, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Varyant Ürün Bağı Listesi Alma
     * Varyant Ürün Bağı listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param optionGroup Varyant Grubu id (optional)
     * @param option Varyant id (optional)
     * @param parentProductId Ana Ürün id (optional)
     * @return OptionToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public OptionToProduct optionToProductsGet(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer optionGroup, Integer option, Integer parentProductId) throws ApiException {
        ApiResponse<OptionToProduct> resp = optionToProductsGetWithHttpInfo(sort, limit, page, sinceId, product, optionGroup, option, parentProductId);
        return resp.getData();
    }

    /**
     * Varyant Ürün Bağı Listesi Alma
     * Varyant Ürün Bağı listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param optionGroup Varyant Grubu id (optional)
     * @param option Varyant id (optional)
     * @param parentProductId Ana Ürün id (optional)
     * @return ApiResponse&lt;OptionToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<OptionToProduct> optionToProductsGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer optionGroup, Integer option, Integer parentProductId) throws ApiException {
        com.squareup.okhttp.Call call = optionToProductsGetValidateBeforeCall(sort, limit, page, sinceId, product, optionGroup, option, parentProductId, null, null);
        Type localVarReturnType = new TypeToken<OptionToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Varyant Ürün Bağı Listesi Alma (asynchronously)
     * Varyant Ürün Bağı listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param optionGroup Varyant Grubu id (optional)
     * @param option Varyant id (optional)
     * @param parentProductId Ana Ürün id (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call optionToProductsGetAsync(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer optionGroup, Integer option, Integer parentProductId, final ApiCallback<OptionToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = optionToProductsGetValidateBeforeCall(sort, limit, page, sinceId, product, optionGroup, option, parentProductId, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<OptionToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for optionToProductsIdDelete
     * @param id Varyant Ürün Bağı nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call optionToProductsIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/option_to_products/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call optionToProductsIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling optionToProductsIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = optionToProductsIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Varyant Ürün Bağı Silme
     * Kalıcı olarak ilgili Varyant Ürün Bağını siler.
     * @param id Varyant Ürün Bağı nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void optionToProductsIdDelete(Integer id) throws ApiException {
        optionToProductsIdDeleteWithHttpInfo(id);
    }

    /**
     * Varyant Ürün Bağı Silme
     * Kalıcı olarak ilgili Varyant Ürün Bağını siler.
     * @param id Varyant Ürün Bağı nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> optionToProductsIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = optionToProductsIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Varyant Ürün Bağı Silme (asynchronously)
     * Kalıcı olarak ilgili Varyant Ürün Bağını siler.
     * @param id Varyant Ürün Bağı nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call optionToProductsIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = optionToProductsIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for optionToProductsIdGet
     * @param id Varyant Ürün Bağı nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call optionToProductsIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/option_to_products/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call optionToProductsIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling optionToProductsIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = optionToProductsIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Varyant Ürün Bağı Alma
     * İlgili Varyant Ürün Bağını getirir.
     * @param id Varyant Ürün Bağı nesnesinin id değeri (required)
     * @return OptionToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public OptionToProduct optionToProductsIdGet(Integer id) throws ApiException {
        ApiResponse<OptionToProduct> resp = optionToProductsIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Varyant Ürün Bağı Alma
     * İlgili Varyant Ürün Bağını getirir.
     * @param id Varyant Ürün Bağı nesnesinin id değeri (required)
     * @return ApiResponse&lt;OptionToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<OptionToProduct> optionToProductsIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = optionToProductsIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<OptionToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Varyant Ürün Bağı Alma (asynchronously)
     * İlgili Varyant Ürün Bağını getirir.
     * @param id Varyant Ürün Bağı nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call optionToProductsIdGetAsync(Integer id, final ApiCallback<OptionToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = optionToProductsIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<OptionToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for optionToProductsIdPut
     * @param id Varyant Ürün Bağı nesnesinin id değeri (required)
     * @param optionToProduct OptionToProduct nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call optionToProductsIdPutCall(Integer id, OptionToProduct optionToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = optionToProduct;

        // create path and map variables
        String localVarPath = "/option_to_products/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call optionToProductsIdPutValidateBeforeCall(Integer id, OptionToProduct optionToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling optionToProductsIdPut(Async)");
        }
        
        // verify the required parameter 'optionToProduct' is set
        if (optionToProduct == null) {
            throw new ApiException("Missing the required parameter 'optionToProduct' when calling optionToProductsIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = optionToProductsIdPutCall(id, optionToProduct, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Varyant Ürün Bağı Güncelleme
     * İlgili Varyant Ürün Bağını günceller.
     * @param id Varyant Ürün Bağı nesnesinin id değeri (required)
     * @param optionToProduct OptionToProduct nesnesi (required)
     * @return OptionToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public OptionToProduct optionToProductsIdPut(Integer id, OptionToProduct optionToProduct) throws ApiException {
        ApiResponse<OptionToProduct> resp = optionToProductsIdPutWithHttpInfo(id, optionToProduct);
        return resp.getData();
    }

    /**
     * Varyant Ürün Bağı Güncelleme
     * İlgili Varyant Ürün Bağını günceller.
     * @param id Varyant Ürün Bağı nesnesinin id değeri (required)
     * @param optionToProduct OptionToProduct nesnesi (required)
     * @return ApiResponse&lt;OptionToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<OptionToProduct> optionToProductsIdPutWithHttpInfo(Integer id, OptionToProduct optionToProduct) throws ApiException {
        com.squareup.okhttp.Call call = optionToProductsIdPutValidateBeforeCall(id, optionToProduct, null, null);
        Type localVarReturnType = new TypeToken<OptionToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Varyant Ürün Bağı Güncelleme (asynchronously)
     * İlgili Varyant Ürün Bağını günceller.
     * @param id Varyant Ürün Bağı nesnesinin id değeri (required)
     * @param optionToProduct OptionToProduct nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call optionToProductsIdPutAsync(Integer id, OptionToProduct optionToProduct, final ApiCallback<OptionToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = optionToProductsIdPutValidateBeforeCall(id, optionToProduct, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<OptionToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for optionToProductsPost
     * @param optionToProduct OptionToProduct nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call optionToProductsPostCall(OptionToProduct optionToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = optionToProduct;

        // create path and map variables
        String localVarPath = "/option_to_products";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call optionToProductsPostValidateBeforeCall(OptionToProduct optionToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'optionToProduct' is set
        if (optionToProduct == null) {
            throw new ApiException("Missing the required parameter 'optionToProduct' when calling optionToProductsPost(Async)");
        }
        

        com.squareup.okhttp.Call call = optionToProductsPostCall(optionToProduct, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Varyant Ürün Bağı Oluşturma
     * Yeni bir Varyant Ürün Bağı oluşturur.
     * @param optionToProduct OptionToProduct nesnesi (required)
     * @return OptionToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public OptionToProduct optionToProductsPost(OptionToProduct optionToProduct) throws ApiException {
        ApiResponse<OptionToProduct> resp = optionToProductsPostWithHttpInfo(optionToProduct);
        return resp.getData();
    }

    /**
     * Varyant Ürün Bağı Oluşturma
     * Yeni bir Varyant Ürün Bağı oluşturur.
     * @param optionToProduct OptionToProduct nesnesi (required)
     * @return ApiResponse&lt;OptionToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<OptionToProduct> optionToProductsPostWithHttpInfo(OptionToProduct optionToProduct) throws ApiException {
        com.squareup.okhttp.Call call = optionToProductsPostValidateBeforeCall(optionToProduct, null, null);
        Type localVarReturnType = new TypeToken<OptionToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Varyant Ürün Bağı Oluşturma (asynchronously)
     * Yeni bir Varyant Ürün Bağı oluşturur.
     * @param optionToProduct OptionToProduct nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call optionToProductsPostAsync(OptionToProduct optionToProduct, final ApiCallback<OptionToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = optionToProductsPostValidateBeforeCall(optionToProduct, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<OptionToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
