

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import io.swagger.client.model.ProductToCategory;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductToCategoryApi {
    private ApiClient apiClient;

    public ProductToCategoryApi() {
        this(Configuration.getDefaultApiClient());
    }

    public ProductToCategoryApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for productToCategoriesGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param category Kategori id (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call productToCategoriesGetCall(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer category, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/product_to_categories";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (product != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("product", product));
        if (category != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("category", category));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call productToCategoriesGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer category, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = productToCategoriesGetCall(sort, limit, page, sinceId, product, category, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün Kategori Bağı Listesi Alma
     * Ürün Kategori Bağı listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param category Kategori id (optional)
     * @return ProductToCategory
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ProductToCategory productToCategoriesGet(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer category) throws ApiException {
        ApiResponse<ProductToCategory> resp = productToCategoriesGetWithHttpInfo(sort, limit, page, sinceId, product, category);
        return resp.getData();
    }

    /**
     * Ürün Kategori Bağı Listesi Alma
     * Ürün Kategori Bağı listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param category Kategori id (optional)
     * @return ApiResponse&lt;ProductToCategory&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ProductToCategory> productToCategoriesGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer category) throws ApiException {
        com.squareup.okhttp.Call call = productToCategoriesGetValidateBeforeCall(sort, limit, page, sinceId, product, category, null, null);
        Type localVarReturnType = new TypeToken<ProductToCategory>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün Kategori Bağı Listesi Alma (asynchronously)
     * Ürün Kategori Bağı listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param category Kategori id (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call productToCategoriesGetAsync(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer category, final ApiCallback<ProductToCategory> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = productToCategoriesGetValidateBeforeCall(sort, limit, page, sinceId, product, category, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ProductToCategory>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for productToCategoriesIdDelete
     * @param id Ürün Kategori Bağı nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call productToCategoriesIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/product_to_categories/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call productToCategoriesIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling productToCategoriesIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = productToCategoriesIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün Kategori Bağı Silme
     * Kalıcı olarak ilgili Ürün Kategori Bağını siler.
     * @param id Ürün Kategori Bağı nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void productToCategoriesIdDelete(Integer id) throws ApiException {
        productToCategoriesIdDeleteWithHttpInfo(id);
    }

    /**
     * Ürün Kategori Bağı Silme
     * Kalıcı olarak ilgili Ürün Kategori Bağını siler.
     * @param id Ürün Kategori Bağı nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> productToCategoriesIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = productToCategoriesIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Ürün Kategori Bağı Silme (asynchronously)
     * Kalıcı olarak ilgili Ürün Kategori Bağını siler.
     * @param id Ürün Kategori Bağı nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call productToCategoriesIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = productToCategoriesIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for productToCategoriesIdGet
     * @param id Ürün Kategori Bağı nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call productToCategoriesIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/product_to_categories/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call productToCategoriesIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling productToCategoriesIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = productToCategoriesIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün Kategori Bağı Alma
     * İlgili Ürün Kategori Bağını getirir.
     * @param id Ürün Kategori Bağı nesnesinin id değeri (required)
     * @return ProductToCategory
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ProductToCategory productToCategoriesIdGet(Integer id) throws ApiException {
        ApiResponse<ProductToCategory> resp = productToCategoriesIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Ürün Kategori Bağı Alma
     * İlgili Ürün Kategori Bağını getirir.
     * @param id Ürün Kategori Bağı nesnesinin id değeri (required)
     * @return ApiResponse&lt;ProductToCategory&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ProductToCategory> productToCategoriesIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = productToCategoriesIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<ProductToCategory>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün Kategori Bağı Alma (asynchronously)
     * İlgili Ürün Kategori Bağını getirir.
     * @param id Ürün Kategori Bağı nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call productToCategoriesIdGetAsync(Integer id, final ApiCallback<ProductToCategory> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = productToCategoriesIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ProductToCategory>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for productToCategoriesIdPut
     * @param id Ürün Kategori Bağı nesnesinin id değeri (required)
     * @param productToCategory ProductToCategory nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call productToCategoriesIdPutCall(Integer id, ProductToCategory productToCategory, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = productToCategory;

        // create path and map variables
        String localVarPath = "/product_to_categories/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call productToCategoriesIdPutValidateBeforeCall(Integer id, ProductToCategory productToCategory, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling productToCategoriesIdPut(Async)");
        }
        
        // verify the required parameter 'productToCategory' is set
        if (productToCategory == null) {
            throw new ApiException("Missing the required parameter 'productToCategory' when calling productToCategoriesIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = productToCategoriesIdPutCall(id, productToCategory, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün Kategori Bağı Güncelleme
     * İlgili Ürün Kategori Bağını günceller.
     * @param id Ürün Kategori Bağı nesnesinin id değeri (required)
     * @param productToCategory ProductToCategory nesnesi (required)
     * @return ProductToCategory
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ProductToCategory productToCategoriesIdPut(Integer id, ProductToCategory productToCategory) throws ApiException {
        ApiResponse<ProductToCategory> resp = productToCategoriesIdPutWithHttpInfo(id, productToCategory);
        return resp.getData();
    }

    /**
     * Ürün Kategori Bağı Güncelleme
     * İlgili Ürün Kategori Bağını günceller.
     * @param id Ürün Kategori Bağı nesnesinin id değeri (required)
     * @param productToCategory ProductToCategory nesnesi (required)
     * @return ApiResponse&lt;ProductToCategory&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ProductToCategory> productToCategoriesIdPutWithHttpInfo(Integer id, ProductToCategory productToCategory) throws ApiException {
        com.squareup.okhttp.Call call = productToCategoriesIdPutValidateBeforeCall(id, productToCategory, null, null);
        Type localVarReturnType = new TypeToken<ProductToCategory>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün Kategori Bağı Güncelleme (asynchronously)
     * İlgili Ürün Kategori Bağını günceller.
     * @param id Ürün Kategori Bağı nesnesinin id değeri (required)
     * @param productToCategory ProductToCategory nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call productToCategoriesIdPutAsync(Integer id, ProductToCategory productToCategory, final ApiCallback<ProductToCategory> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = productToCategoriesIdPutValidateBeforeCall(id, productToCategory, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ProductToCategory>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for productToCategoriesPost
     * @param productToCategory ProductToCategory nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call productToCategoriesPostCall(ProductToCategory productToCategory, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = productToCategory;

        // create path and map variables
        String localVarPath = "/product_to_categories";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call productToCategoriesPostValidateBeforeCall(ProductToCategory productToCategory, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'productToCategory' is set
        if (productToCategory == null) {
            throw new ApiException("Missing the required parameter 'productToCategory' when calling productToCategoriesPost(Async)");
        }
        

        com.squareup.okhttp.Call call = productToCategoriesPostCall(productToCategory, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün Kategori Bağı Oluşturma
     * Yeni bir Ürün Kategori Bağı oluşturur.
     * @param productToCategory ProductToCategory nesnesi (required)
     * @return ProductToCategory
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ProductToCategory productToCategoriesPost(ProductToCategory productToCategory) throws ApiException {
        ApiResponse<ProductToCategory> resp = productToCategoriesPostWithHttpInfo(productToCategory);
        return resp.getData();
    }

    /**
     * Ürün Kategori Bağı Oluşturma
     * Yeni bir Ürün Kategori Bağı oluşturur.
     * @param productToCategory ProductToCategory nesnesi (required)
     * @return ApiResponse&lt;ProductToCategory&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ProductToCategory> productToCategoriesPostWithHttpInfo(ProductToCategory productToCategory) throws ApiException {
        com.squareup.okhttp.Call call = productToCategoriesPostValidateBeforeCall(productToCategory, null, null);
        Type localVarReturnType = new TypeToken<ProductToCategory>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün Kategori Bağı Oluşturma (asynchronously)
     * Yeni bir Ürün Kategori Bağı oluşturur.
     * @param productToCategory ProductToCategory nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call productToCategoriesPostAsync(ProductToCategory productToCategory, final ApiCallback<ProductToCategory> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = productToCategoriesPostValidateBeforeCall(productToCategory, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ProductToCategory>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
