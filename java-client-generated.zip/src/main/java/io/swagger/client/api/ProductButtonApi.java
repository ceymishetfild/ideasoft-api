

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import io.swagger.client.model.ProductButton;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductButtonApi {
    private ApiClient apiClient;

    public ProductButtonApi() {
        this(Configuration.getDefaultApiClient());
    }

    public ProductButtonApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for productButtonsGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param fastShipping Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param sameDayShipping Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param threeDaysDelivery 3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param fiveDaysDelivery 5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param sevenDaysDelivery 7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param freeShipping Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param deliveryFromStock Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param preOrderedProduct Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param askStock Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param campaignedProduct Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param product Ürün id (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call productButtonsGetCall(String sort, Integer limit, Integer page, Integer sinceId, Integer fastShipping, Integer sameDayShipping, Integer threeDaysDelivery, Integer fiveDaysDelivery, Integer sevenDaysDelivery, Integer freeShipping, Integer deliveryFromStock, Integer preOrderedProduct, Integer askStock, Integer campaignedProduct, Integer product, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/product_buttons";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (fastShipping != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("fastShipping", fastShipping));
        if (sameDayShipping != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sameDayShipping", sameDayShipping));
        if (threeDaysDelivery != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("threeDaysDelivery", threeDaysDelivery));
        if (fiveDaysDelivery != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("fiveDaysDelivery", fiveDaysDelivery));
        if (sevenDaysDelivery != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sevenDaysDelivery", sevenDaysDelivery));
        if (freeShipping != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("freeShipping", freeShipping));
        if (deliveryFromStock != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("deliveryFromStock", deliveryFromStock));
        if (preOrderedProduct != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("preOrderedProduct", preOrderedProduct));
        if (askStock != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("askStock", askStock));
        if (campaignedProduct != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("campaignedProduct", campaignedProduct));
        if (product != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("product", product));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call productButtonsGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, Integer fastShipping, Integer sameDayShipping, Integer threeDaysDelivery, Integer fiveDaysDelivery, Integer sevenDaysDelivery, Integer freeShipping, Integer deliveryFromStock, Integer preOrderedProduct, Integer askStock, Integer campaignedProduct, Integer product, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = productButtonsGetCall(sort, limit, page, sinceId, fastShipping, sameDayShipping, threeDaysDelivery, fiveDaysDelivery, sevenDaysDelivery, freeShipping, deliveryFromStock, preOrderedProduct, askStock, campaignedProduct, product, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün ve Stok Butonu Listesi Alma
     * Ürün ve Stok Butonu listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param fastShipping Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param sameDayShipping Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param threeDaysDelivery 3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param fiveDaysDelivery 5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param sevenDaysDelivery 7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param freeShipping Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param deliveryFromStock Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param preOrderedProduct Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param askStock Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param campaignedProduct Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param product Ürün id (optional)
     * @return ProductButton
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ProductButton productButtonsGet(String sort, Integer limit, Integer page, Integer sinceId, Integer fastShipping, Integer sameDayShipping, Integer threeDaysDelivery, Integer fiveDaysDelivery, Integer sevenDaysDelivery, Integer freeShipping, Integer deliveryFromStock, Integer preOrderedProduct, Integer askStock, Integer campaignedProduct, Integer product) throws ApiException {
        ApiResponse<ProductButton> resp = productButtonsGetWithHttpInfo(sort, limit, page, sinceId, fastShipping, sameDayShipping, threeDaysDelivery, fiveDaysDelivery, sevenDaysDelivery, freeShipping, deliveryFromStock, preOrderedProduct, askStock, campaignedProduct, product);
        return resp.getData();
    }

    /**
     * Ürün ve Stok Butonu Listesi Alma
     * Ürün ve Stok Butonu listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param fastShipping Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param sameDayShipping Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param threeDaysDelivery 3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param fiveDaysDelivery 5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param sevenDaysDelivery 7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param freeShipping Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param deliveryFromStock Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param preOrderedProduct Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param askStock Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param campaignedProduct Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param product Ürün id (optional)
     * @return ApiResponse&lt;ProductButton&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ProductButton> productButtonsGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, Integer fastShipping, Integer sameDayShipping, Integer threeDaysDelivery, Integer fiveDaysDelivery, Integer sevenDaysDelivery, Integer freeShipping, Integer deliveryFromStock, Integer preOrderedProduct, Integer askStock, Integer campaignedProduct, Integer product) throws ApiException {
        com.squareup.okhttp.Call call = productButtonsGetValidateBeforeCall(sort, limit, page, sinceId, fastShipping, sameDayShipping, threeDaysDelivery, fiveDaysDelivery, sevenDaysDelivery, freeShipping, deliveryFromStock, preOrderedProduct, askStock, campaignedProduct, product, null, null);
        Type localVarReturnType = new TypeToken<ProductButton>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün ve Stok Butonu Listesi Alma (asynchronously)
     * Ürün ve Stok Butonu listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param fastShipping Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param sameDayShipping Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param threeDaysDelivery 3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param fiveDaysDelivery 5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param sevenDaysDelivery 7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param freeShipping Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param deliveryFromStock Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param preOrderedProduct Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param askStock Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param campaignedProduct Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param product Ürün id (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call productButtonsGetAsync(String sort, Integer limit, Integer page, Integer sinceId, Integer fastShipping, Integer sameDayShipping, Integer threeDaysDelivery, Integer fiveDaysDelivery, Integer sevenDaysDelivery, Integer freeShipping, Integer deliveryFromStock, Integer preOrderedProduct, Integer askStock, Integer campaignedProduct, Integer product, final ApiCallback<ProductButton> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = productButtonsGetValidateBeforeCall(sort, limit, page, sinceId, fastShipping, sameDayShipping, threeDaysDelivery, fiveDaysDelivery, sevenDaysDelivery, freeShipping, deliveryFromStock, preOrderedProduct, askStock, campaignedProduct, product, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ProductButton>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for productButtonsIdDelete
     * @param id Ürün ve Stok Butonu nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call productButtonsIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/product_buttons/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call productButtonsIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling productButtonsIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = productButtonsIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün ve Stok Butonu Silme
     * Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.
     * @param id Ürün ve Stok Butonu nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void productButtonsIdDelete(Integer id) throws ApiException {
        productButtonsIdDeleteWithHttpInfo(id);
    }

    /**
     * Ürün ve Stok Butonu Silme
     * Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.
     * @param id Ürün ve Stok Butonu nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> productButtonsIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = productButtonsIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Ürün ve Stok Butonu Silme (asynchronously)
     * Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.
     * @param id Ürün ve Stok Butonu nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call productButtonsIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = productButtonsIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for productButtonsIdGet
     * @param id Ürün ve Stok Butonu nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call productButtonsIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/product_buttons/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call productButtonsIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling productButtonsIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = productButtonsIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün ve Stok Butonu Alma
     * İlgili Ürün ve Stok Butonunu getirir.
     * @param id Ürün ve Stok Butonu nesnesinin id değeri (required)
     * @return ProductButton
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ProductButton productButtonsIdGet(Integer id) throws ApiException {
        ApiResponse<ProductButton> resp = productButtonsIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Ürün ve Stok Butonu Alma
     * İlgili Ürün ve Stok Butonunu getirir.
     * @param id Ürün ve Stok Butonu nesnesinin id değeri (required)
     * @return ApiResponse&lt;ProductButton&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ProductButton> productButtonsIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = productButtonsIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<ProductButton>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün ve Stok Butonu Alma (asynchronously)
     * İlgili Ürün ve Stok Butonunu getirir.
     * @param id Ürün ve Stok Butonu nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call productButtonsIdGetAsync(Integer id, final ApiCallback<ProductButton> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = productButtonsIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ProductButton>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for productButtonsIdPut
     * @param id Ürün ve Stok Butonu nesnesinin id değeri (required)
     * @param productButton ProductButton nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call productButtonsIdPutCall(Integer id, ProductButton productButton, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = productButton;

        // create path and map variables
        String localVarPath = "/product_buttons/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call productButtonsIdPutValidateBeforeCall(Integer id, ProductButton productButton, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling productButtonsIdPut(Async)");
        }
        
        // verify the required parameter 'productButton' is set
        if (productButton == null) {
            throw new ApiException("Missing the required parameter 'productButton' when calling productButtonsIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = productButtonsIdPutCall(id, productButton, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün ve Stok Butonu Güncelleme
     * İlgili Ürün ve Stok Butonunu günceller.
     * @param id Ürün ve Stok Butonu nesnesinin id değeri (required)
     * @param productButton ProductButton nesnesi (required)
     * @return ProductButton
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ProductButton productButtonsIdPut(Integer id, ProductButton productButton) throws ApiException {
        ApiResponse<ProductButton> resp = productButtonsIdPutWithHttpInfo(id, productButton);
        return resp.getData();
    }

    /**
     * Ürün ve Stok Butonu Güncelleme
     * İlgili Ürün ve Stok Butonunu günceller.
     * @param id Ürün ve Stok Butonu nesnesinin id değeri (required)
     * @param productButton ProductButton nesnesi (required)
     * @return ApiResponse&lt;ProductButton&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ProductButton> productButtonsIdPutWithHttpInfo(Integer id, ProductButton productButton) throws ApiException {
        com.squareup.okhttp.Call call = productButtonsIdPutValidateBeforeCall(id, productButton, null, null);
        Type localVarReturnType = new TypeToken<ProductButton>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün ve Stok Butonu Güncelleme (asynchronously)
     * İlgili Ürün ve Stok Butonunu günceller.
     * @param id Ürün ve Stok Butonu nesnesinin id değeri (required)
     * @param productButton ProductButton nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call productButtonsIdPutAsync(Integer id, ProductButton productButton, final ApiCallback<ProductButton> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = productButtonsIdPutValidateBeforeCall(id, productButton, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ProductButton>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for productButtonsPost
     * @param productButton ProductButton nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call productButtonsPostCall(ProductButton productButton, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = productButton;

        // create path and map variables
        String localVarPath = "/product_buttons";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call productButtonsPostValidateBeforeCall(ProductButton productButton, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'productButton' is set
        if (productButton == null) {
            throw new ApiException("Missing the required parameter 'productButton' when calling productButtonsPost(Async)");
        }
        

        com.squareup.okhttp.Call call = productButtonsPostCall(productButton, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün ve Stok Butonu Oluşturma
     * Yeni bir Ürün ve Stok Butonu oluşturur.
     * @param productButton ProductButton nesnesi (required)
     * @return ProductButton
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ProductButton productButtonsPost(ProductButton productButton) throws ApiException {
        ApiResponse<ProductButton> resp = productButtonsPostWithHttpInfo(productButton);
        return resp.getData();
    }

    /**
     * Ürün ve Stok Butonu Oluşturma
     * Yeni bir Ürün ve Stok Butonu oluşturur.
     * @param productButton ProductButton nesnesi (required)
     * @return ApiResponse&lt;ProductButton&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ProductButton> productButtonsPostWithHttpInfo(ProductButton productButton) throws ApiException {
        com.squareup.okhttp.Call call = productButtonsPostValidateBeforeCall(productButton, null, null);
        Type localVarReturnType = new TypeToken<ProductButton>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün ve Stok Butonu Oluşturma (asynchronously)
     * Yeni bir Ürün ve Stok Butonu oluşturur.
     * @param productButton ProductButton nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call productButtonsPostAsync(ProductButton productButton, final ApiCallback<ProductButton> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = productButtonsPostValidateBeforeCall(productButton, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ProductButton>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
