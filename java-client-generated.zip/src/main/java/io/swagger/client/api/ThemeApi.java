

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Asset;
import io.swagger.client.model.Error;
import io.swagger.client.model.Theme;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ThemeApi {
    private ApiClient apiClient;

    public ThemeApi() {
        this(Configuration.getDefaultApiClient());
    }

    public ThemeApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for themesGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir (optional)
     * @param status Tema durumu (optional)
     * @param platform Tema platformu (optional)
     * @param type Tema tipi (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call themesGetCall(String sort, Integer limit, Integer page, Integer sinceId, Integer status, String platform, String type, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/themes";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (status != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("status", status));
        if (platform != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("platform", platform));
        if (type != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("type", type));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call themesGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, Integer status, String platform, String type, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = themesGetCall(sort, limit, page, sinceId, status, platform, type, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Tema Listesi Alma
     * Tema listesi verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir (optional)
     * @param status Tema durumu (optional)
     * @param platform Tema platformu (optional)
     * @param type Tema tipi (optional)
     * @return Theme
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public Theme themesGet(String sort, Integer limit, Integer page, Integer sinceId, Integer status, String platform, String type) throws ApiException {
        ApiResponse<Theme> resp = themesGetWithHttpInfo(sort, limit, page, sinceId, status, platform, type);
        return resp.getData();
    }

    /**
     * Tema Listesi Alma
     * Tema listesi verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir (optional)
     * @param status Tema durumu (optional)
     * @param platform Tema platformu (optional)
     * @param type Tema tipi (optional)
     * @return ApiResponse&lt;Theme&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Theme> themesGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, Integer status, String platform, String type) throws ApiException {
        com.squareup.okhttp.Call call = themesGetValidateBeforeCall(sort, limit, page, sinceId, status, platform, type, null, null);
        Type localVarReturnType = new TypeToken<Theme>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Tema Listesi Alma (asynchronously)
     * Tema listesi verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir (optional)
     * @param status Tema durumu (optional)
     * @param platform Tema platformu (optional)
     * @param type Tema tipi (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call themesGetAsync(String sort, Integer limit, Integer page, Integer sinceId, Integer status, String platform, String type, final ApiCallback<Theme> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = themesGetValidateBeforeCall(sort, limit, page, sinceId, status, platform, type, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<Theme>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for themesIdAssetsGet
     * @param id Tema nesnesinin id değeri (required)
     * @param key Tema Dosyası nesnesi anahtar değeri. (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call themesIdAssetsGetCall(Integer id, String key, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/themes/{id}/assets"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (key != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("key", key));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call themesIdAssetsGetValidateBeforeCall(Integer id, String key, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling themesIdAssetsGet(Async)");
        }
        

        com.squareup.okhttp.Call call = themesIdAssetsGetCall(id, key, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Tema Dosyası Listesi Alma
     * Tema Dosyası listesi verir.
     * @param id Tema nesnesinin id değeri (required)
     * @param key Tema Dosyası nesnesi anahtar değeri. (optional)
     * @return Asset
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public Asset themesIdAssetsGet(Integer id, String key) throws ApiException {
        ApiResponse<Asset> resp = themesIdAssetsGetWithHttpInfo(id, key);
        return resp.getData();
    }

    /**
     * Tema Dosyası Listesi Alma
     * Tema Dosyası listesi verir.
     * @param id Tema nesnesinin id değeri (required)
     * @param key Tema Dosyası nesnesi anahtar değeri. (optional)
     * @return ApiResponse&lt;Asset&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Asset> themesIdAssetsGetWithHttpInfo(Integer id, String key) throws ApiException {
        com.squareup.okhttp.Call call = themesIdAssetsGetValidateBeforeCall(id, key, null, null);
        Type localVarReturnType = new TypeToken<Asset>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Tema Dosyası Listesi Alma (asynchronously)
     * Tema Dosyası listesi verir.
     * @param id Tema nesnesinin id değeri (required)
     * @param key Tema Dosyası nesnesi anahtar değeri. (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call themesIdAssetsGetAsync(Integer id, String key, final ApiCallback<Asset> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = themesIdAssetsGetValidateBeforeCall(id, key, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<Asset>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for themesIdAssetskeykeyDelete
     * @param id Tema nesnesinin id değeri (required)
     * @param key Tema Dosyası nesnesi anahtar değeri. (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call themesIdAssetskeykeyDeleteCall(Integer id, String key, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/themes/{id}/assets?key={key}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (key != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("key", key));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call themesIdAssetskeykeyDeleteValidateBeforeCall(Integer id, String key, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling themesIdAssetskeykeyDelete(Async)");
        }
        
        // verify the required parameter 'key' is set
        if (key == null) {
            throw new ApiException("Missing the required parameter 'key' when calling themesIdAssetskeykeyDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = themesIdAssetskeykeyDeleteCall(id, key, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Tema Dosyası Silme
     * Kalıcı olarak ilgili Tema Dosyasını siler.
     * @param id Tema nesnesinin id değeri (required)
     * @param key Tema Dosyası nesnesi anahtar değeri. (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void themesIdAssetskeykeyDelete(Integer id, String key) throws ApiException {
        themesIdAssetskeykeyDeleteWithHttpInfo(id, key);
    }

    /**
     * Tema Dosyası Silme
     * Kalıcı olarak ilgili Tema Dosyasını siler.
     * @param id Tema nesnesinin id değeri (required)
     * @param key Tema Dosyası nesnesi anahtar değeri. (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> themesIdAssetskeykeyDeleteWithHttpInfo(Integer id, String key) throws ApiException {
        com.squareup.okhttp.Call call = themesIdAssetskeykeyDeleteValidateBeforeCall(id, key, null, null);
        return apiClient.execute(call);
    }

    /**
     * Tema Dosyası Silme (asynchronously)
     * Kalıcı olarak ilgili Tema Dosyasını siler.
     * @param id Tema nesnesinin id değeri (required)
     * @param key Tema Dosyası nesnesi anahtar değeri. (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call themesIdAssetskeykeyDeleteAsync(Integer id, String key, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = themesIdAssetskeykeyDeleteValidateBeforeCall(id, key, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for themesIdAssetskeykeyGet
     * @param id Tema nesnesinin id değeri (required)
     * @param key Tema Dosyası nesnesi anahtar değeri. (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call themesIdAssetskeykeyGetCall(Integer id, String key, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/themes/{id}/assets?key={key}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (key != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("key", key));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call themesIdAssetskeykeyGetValidateBeforeCall(Integer id, String key, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling themesIdAssetskeykeyGet(Async)");
        }
        
        // verify the required parameter 'key' is set
        if (key == null) {
            throw new ApiException("Missing the required parameter 'key' when calling themesIdAssetskeykeyGet(Async)");
        }
        

        com.squareup.okhttp.Call call = themesIdAssetskeykeyGetCall(id, key, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Tema Dosyası Alma
     * İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur.
     * @param id Tema nesnesinin id değeri (required)
     * @param key Tema Dosyası nesnesi anahtar değeri. (required)
     * @return Asset
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public Asset themesIdAssetskeykeyGet(Integer id, String key) throws ApiException {
        ApiResponse<Asset> resp = themesIdAssetskeykeyGetWithHttpInfo(id, key);
        return resp.getData();
    }

    /**
     * Tema Dosyası Alma
     * İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur.
     * @param id Tema nesnesinin id değeri (required)
     * @param key Tema Dosyası nesnesi anahtar değeri. (required)
     * @return ApiResponse&lt;Asset&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Asset> themesIdAssetskeykeyGetWithHttpInfo(Integer id, String key) throws ApiException {
        com.squareup.okhttp.Call call = themesIdAssetskeykeyGetValidateBeforeCall(id, key, null, null);
        Type localVarReturnType = new TypeToken<Asset>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Tema Dosyası Alma (asynchronously)
     * İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur.
     * @param id Tema nesnesinin id değeri (required)
     * @param key Tema Dosyası nesnesi anahtar değeri. (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call themesIdAssetskeykeyGetAsync(Integer id, String key, final ApiCallback<Asset> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = themesIdAssetskeykeyGetValidateBeforeCall(id, key, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<Asset>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for themesIdAssetskeykeyPut
     * @param id Tema nesnesinin id değeri (required)
     * @param theme Theme nesnesi (required)
     * @param asset Asset nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call themesIdAssetskeykeyPutCall(Integer id, Theme theme, Asset asset, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = asset;

        // create path and map variables
        String localVarPath = "/themes/{id}/assets?key={key}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call themesIdAssetskeykeyPutValidateBeforeCall(Integer id, Theme theme, Asset asset, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling themesIdAssetskeykeyPut(Async)");
        }
        
        // verify the required parameter 'theme' is set
        if (theme == null) {
            throw new ApiException("Missing the required parameter 'theme' when calling themesIdAssetskeykeyPut(Async)");
        }
        
        // verify the required parameter 'asset' is set
        if (asset == null) {
            throw new ApiException("Missing the required parameter 'asset' when calling themesIdAssetskeykeyPut(Async)");
        }
        

        com.squareup.okhttp.Call call = themesIdAssetskeykeyPutCall(id, theme, asset, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Tema Dosyası Güncelleme
     * Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller.
     * @param id Tema nesnesinin id değeri (required)
     * @param theme Theme nesnesi (required)
     * @param asset Asset nesnesi (required)
     * @return Asset
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public Asset themesIdAssetskeykeyPut(Integer id, Theme theme, Asset asset) throws ApiException {
        ApiResponse<Asset> resp = themesIdAssetskeykeyPutWithHttpInfo(id, theme, asset);
        return resp.getData();
    }

    /**
     * Tema Dosyası Güncelleme
     * Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller.
     * @param id Tema nesnesinin id değeri (required)
     * @param theme Theme nesnesi (required)
     * @param asset Asset nesnesi (required)
     * @return ApiResponse&lt;Asset&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Asset> themesIdAssetskeykeyPutWithHttpInfo(Integer id, Theme theme, Asset asset) throws ApiException {
        com.squareup.okhttp.Call call = themesIdAssetskeykeyPutValidateBeforeCall(id, theme, asset, null, null);
        Type localVarReturnType = new TypeToken<Asset>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Tema Dosyası Güncelleme (asynchronously)
     * Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller.
     * @param id Tema nesnesinin id değeri (required)
     * @param theme Theme nesnesi (required)
     * @param asset Asset nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call themesIdAssetskeykeyPutAsync(Integer id, Theme theme, Asset asset, final ApiCallback<Asset> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = themesIdAssetskeykeyPutValidateBeforeCall(id, theme, asset, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<Asset>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for themesIdDelete
     * @param id Tema nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call themesIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/themes/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call themesIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling themesIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = themesIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Tema Silme
     * Kalıcı olarak ilgili Temayı siler.
     * @param id Tema nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void themesIdDelete(Integer id) throws ApiException {
        themesIdDeleteWithHttpInfo(id);
    }

    /**
     * Tema Silme
     * Kalıcı olarak ilgili Temayı siler.
     * @param id Tema nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> themesIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = themesIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Tema Silme (asynchronously)
     * Kalıcı olarak ilgili Temayı siler.
     * @param id Tema nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call themesIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = themesIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for themesIdGet
     * @param id Tema nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call themesIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/themes/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call themesIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling themesIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = themesIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Tema Alma
     * İlgili Temayı getirir.
     * @param id Tema nesnesinin id değeri (required)
     * @return Theme
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public Theme themesIdGet(Integer id) throws ApiException {
        ApiResponse<Theme> resp = themesIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Tema Alma
     * İlgili Temayı getirir.
     * @param id Tema nesnesinin id değeri (required)
     * @return ApiResponse&lt;Theme&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Theme> themesIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = themesIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<Theme>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Tema Alma (asynchronously)
     * İlgili Temayı getirir.
     * @param id Tema nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call themesIdGetAsync(Integer id, final ApiCallback<Theme> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = themesIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<Theme>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for themesIdPut
     * @param id Tema nesnesinin id değeri (required)
     * @param theme Theme nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call themesIdPutCall(Integer id, Theme theme, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = theme;

        // create path and map variables
        String localVarPath = "/themes/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call themesIdPutValidateBeforeCall(Integer id, Theme theme, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling themesIdPut(Async)");
        }
        
        // verify the required parameter 'theme' is set
        if (theme == null) {
            throw new ApiException("Missing the required parameter 'theme' when calling themesIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = themesIdPutCall(id, theme, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Tema Güncelleme
     * İlgili Temayı günceller.
     * @param id Tema nesnesinin id değeri (required)
     * @param theme Theme nesnesi (required)
     * @return Theme
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public Theme themesIdPut(Integer id, Theme theme) throws ApiException {
        ApiResponse<Theme> resp = themesIdPutWithHttpInfo(id, theme);
        return resp.getData();
    }

    /**
     * Tema Güncelleme
     * İlgili Temayı günceller.
     * @param id Tema nesnesinin id değeri (required)
     * @param theme Theme nesnesi (required)
     * @return ApiResponse&lt;Theme&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Theme> themesIdPutWithHttpInfo(Integer id, Theme theme) throws ApiException {
        com.squareup.okhttp.Call call = themesIdPutValidateBeforeCall(id, theme, null, null);
        Type localVarReturnType = new TypeToken<Theme>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Tema Güncelleme (asynchronously)
     * İlgili Temayı günceller.
     * @param id Tema nesnesinin id değeri (required)
     * @param theme Theme nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call themesIdPutAsync(Integer id, Theme theme, final ApiCallback<Theme> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = themesIdPutValidateBeforeCall(id, theme, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<Theme>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for themesPost
     * @param theme Theme nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call themesPostCall(Theme theme, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = theme;

        // create path and map variables
        String localVarPath = "/themes";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call themesPostValidateBeforeCall(Theme theme, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'theme' is set
        if (theme == null) {
            throw new ApiException("Missing the required parameter 'theme' when calling themesPost(Async)");
        }
        

        com.squareup.okhttp.Call call = themesPostCall(theme, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Tema Oluşturma
     * Yeni bir tema oluşturur.
     * @param theme Theme nesnesi (required)
     * @return Theme
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public Theme themesPost(Theme theme) throws ApiException {
        ApiResponse<Theme> resp = themesPostWithHttpInfo(theme);
        return resp.getData();
    }

    /**
     * Tema Oluşturma
     * Yeni bir tema oluşturur.
     * @param theme Theme nesnesi (required)
     * @return ApiResponse&lt;Theme&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Theme> themesPostWithHttpInfo(Theme theme) throws ApiException {
        com.squareup.okhttp.Call call = themesPostValidateBeforeCall(theme, null, null);
        Type localVarReturnType = new TypeToken<Theme>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Tema Oluşturma (asynchronously)
     * Yeni bir tema oluşturur.
     * @param theme Theme nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call themesPostAsync(Theme theme, final ApiCallback<Theme> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = themesPostValidateBeforeCall(theme, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<Theme>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
