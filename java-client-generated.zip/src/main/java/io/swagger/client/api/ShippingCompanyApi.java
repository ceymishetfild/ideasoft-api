

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import io.swagger.client.model.ShippingCompany;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShippingCompanyApi {
    private ApiClient apiClient;

    public ShippingCompanyApi() {
        this(Configuration.getDefaultApiClient());
    }

    public ShippingCompanyApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for shippingCompaniesGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Kargo firması adı (optional)
     * @param companyCode Kargo firması kodu (optional)
     * @param paymentType Ödeme Tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil (optional)
     * @param shippingProvider Teslimat Hizmeti Sağlayıcısı id (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call shippingCompaniesGetCall(String sort, Integer limit, Integer page, Integer sinceId, String name, String companyCode, String paymentType, Integer shippingProvider, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/shipping_companies";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (name != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("name", name));
        if (companyCode != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("companyCode", companyCode));
        if (paymentType != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("paymentType", paymentType));
        if (shippingProvider != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("shippingProvider", shippingProvider));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call shippingCompaniesGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, String name, String companyCode, String paymentType, Integer shippingProvider, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = shippingCompaniesGetCall(sort, limit, page, sinceId, name, companyCode, paymentType, shippingProvider, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Kargo Firması Listesi Alma
     * Kargo Firması listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Kargo firması adı (optional)
     * @param companyCode Kargo firması kodu (optional)
     * @param paymentType Ödeme Tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil (optional)
     * @param shippingProvider Teslimat Hizmeti Sağlayıcısı id (optional)
     * @return ShippingCompany
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ShippingCompany shippingCompaniesGet(String sort, Integer limit, Integer page, Integer sinceId, String name, String companyCode, String paymentType, Integer shippingProvider) throws ApiException {
        ApiResponse<ShippingCompany> resp = shippingCompaniesGetWithHttpInfo(sort, limit, page, sinceId, name, companyCode, paymentType, shippingProvider);
        return resp.getData();
    }

    /**
     * Kargo Firması Listesi Alma
     * Kargo Firması listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Kargo firması adı (optional)
     * @param companyCode Kargo firması kodu (optional)
     * @param paymentType Ödeme Tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil (optional)
     * @param shippingProvider Teslimat Hizmeti Sağlayıcısı id (optional)
     * @return ApiResponse&lt;ShippingCompany&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ShippingCompany> shippingCompaniesGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, String name, String companyCode, String paymentType, Integer shippingProvider) throws ApiException {
        com.squareup.okhttp.Call call = shippingCompaniesGetValidateBeforeCall(sort, limit, page, sinceId, name, companyCode, paymentType, shippingProvider, null, null);
        Type localVarReturnType = new TypeToken<ShippingCompany>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Kargo Firması Listesi Alma (asynchronously)
     * Kargo Firması listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Kargo firması adı (optional)
     * @param companyCode Kargo firması kodu (optional)
     * @param paymentType Ödeme Tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil (optional)
     * @param shippingProvider Teslimat Hizmeti Sağlayıcısı id (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call shippingCompaniesGetAsync(String sort, Integer limit, Integer page, Integer sinceId, String name, String companyCode, String paymentType, Integer shippingProvider, final ApiCallback<ShippingCompany> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = shippingCompaniesGetValidateBeforeCall(sort, limit, page, sinceId, name, companyCode, paymentType, shippingProvider, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ShippingCompany>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for shippingCompaniesIdDelete
     * @param id Kargo Firması nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call shippingCompaniesIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/shipping_companies/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call shippingCompaniesIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling shippingCompaniesIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = shippingCompaniesIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Kargo Firması Silme
     * Kalıcı olarak ilgili Kargo Firmasını siler.
     * @param id Kargo Firması nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void shippingCompaniesIdDelete(Integer id) throws ApiException {
        shippingCompaniesIdDeleteWithHttpInfo(id);
    }

    /**
     * Kargo Firması Silme
     * Kalıcı olarak ilgili Kargo Firmasını siler.
     * @param id Kargo Firması nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> shippingCompaniesIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = shippingCompaniesIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Kargo Firması Silme (asynchronously)
     * Kalıcı olarak ilgili Kargo Firmasını siler.
     * @param id Kargo Firması nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call shippingCompaniesIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = shippingCompaniesIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for shippingCompaniesIdGet
     * @param id Kargo Firması nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call shippingCompaniesIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/shipping_companies/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call shippingCompaniesIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling shippingCompaniesIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = shippingCompaniesIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Kargo Firması Alma
     * İlgili Kargo Firmasını getirir.
     * @param id Kargo Firması nesnesinin id değeri (required)
     * @return ShippingCompany
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ShippingCompany shippingCompaniesIdGet(Integer id) throws ApiException {
        ApiResponse<ShippingCompany> resp = shippingCompaniesIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Kargo Firması Alma
     * İlgili Kargo Firmasını getirir.
     * @param id Kargo Firması nesnesinin id değeri (required)
     * @return ApiResponse&lt;ShippingCompany&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ShippingCompany> shippingCompaniesIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = shippingCompaniesIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<ShippingCompany>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Kargo Firması Alma (asynchronously)
     * İlgili Kargo Firmasını getirir.
     * @param id Kargo Firması nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call shippingCompaniesIdGetAsync(Integer id, final ApiCallback<ShippingCompany> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = shippingCompaniesIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ShippingCompany>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for shippingCompaniesIdPut
     * @param id Kargo Firması nesnesinin id değeri (required)
     * @param shippingCompany ShippingCompany nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call shippingCompaniesIdPutCall(Integer id, ShippingCompany shippingCompany, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = shippingCompany;

        // create path and map variables
        String localVarPath = "/shipping_companies/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call shippingCompaniesIdPutValidateBeforeCall(Integer id, ShippingCompany shippingCompany, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling shippingCompaniesIdPut(Async)");
        }
        
        // verify the required parameter 'shippingCompany' is set
        if (shippingCompany == null) {
            throw new ApiException("Missing the required parameter 'shippingCompany' when calling shippingCompaniesIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = shippingCompaniesIdPutCall(id, shippingCompany, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Kargo Firması Güncelleme
     * İlgili Kargo Firmasını günceller.
     * @param id Kargo Firması nesnesinin id değeri (required)
     * @param shippingCompany ShippingCompany nesnesi (required)
     * @return ShippingCompany
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ShippingCompany shippingCompaniesIdPut(Integer id, ShippingCompany shippingCompany) throws ApiException {
        ApiResponse<ShippingCompany> resp = shippingCompaniesIdPutWithHttpInfo(id, shippingCompany);
        return resp.getData();
    }

    /**
     * Kargo Firması Güncelleme
     * İlgili Kargo Firmasını günceller.
     * @param id Kargo Firması nesnesinin id değeri (required)
     * @param shippingCompany ShippingCompany nesnesi (required)
     * @return ApiResponse&lt;ShippingCompany&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ShippingCompany> shippingCompaniesIdPutWithHttpInfo(Integer id, ShippingCompany shippingCompany) throws ApiException {
        com.squareup.okhttp.Call call = shippingCompaniesIdPutValidateBeforeCall(id, shippingCompany, null, null);
        Type localVarReturnType = new TypeToken<ShippingCompany>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Kargo Firması Güncelleme (asynchronously)
     * İlgili Kargo Firmasını günceller.
     * @param id Kargo Firması nesnesinin id değeri (required)
     * @param shippingCompany ShippingCompany nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call shippingCompaniesIdPutAsync(Integer id, ShippingCompany shippingCompany, final ApiCallback<ShippingCompany> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = shippingCompaniesIdPutValidateBeforeCall(id, shippingCompany, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ShippingCompany>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for shippingCompaniesPost
     * @param shippingCompany ShippingCompany nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call shippingCompaniesPostCall(ShippingCompany shippingCompany, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = shippingCompany;

        // create path and map variables
        String localVarPath = "/shipping_companies";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call shippingCompaniesPostValidateBeforeCall(ShippingCompany shippingCompany, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'shippingCompany' is set
        if (shippingCompany == null) {
            throw new ApiException("Missing the required parameter 'shippingCompany' when calling shippingCompaniesPost(Async)");
        }
        

        com.squareup.okhttp.Call call = shippingCompaniesPostCall(shippingCompany, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Kargo Firması Oluşturma
     * Yeni bir Kargo Firması oluşturur relationship.
     * @param shippingCompany ShippingCompany nesnesi (required)
     * @return ShippingCompany
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ShippingCompany shippingCompaniesPost(ShippingCompany shippingCompany) throws ApiException {
        ApiResponse<ShippingCompany> resp = shippingCompaniesPostWithHttpInfo(shippingCompany);
        return resp.getData();
    }

    /**
     * Kargo Firması Oluşturma
     * Yeni bir Kargo Firması oluşturur relationship.
     * @param shippingCompany ShippingCompany nesnesi (required)
     * @return ApiResponse&lt;ShippingCompany&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ShippingCompany> shippingCompaniesPostWithHttpInfo(ShippingCompany shippingCompany) throws ApiException {
        com.squareup.okhttp.Call call = shippingCompaniesPostValidateBeforeCall(shippingCompany, null, null);
        Type localVarReturnType = new TypeToken<ShippingCompany>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Kargo Firması Oluşturma (asynchronously)
     * Yeni bir Kargo Firması oluşturur relationship.
     * @param shippingCompany ShippingCompany nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call shippingCompaniesPostAsync(ShippingCompany shippingCompany, final ApiCallback<ShippingCompany> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = shippingCompaniesPostValidateBeforeCall(shippingCompany, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ShippingCompany>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
