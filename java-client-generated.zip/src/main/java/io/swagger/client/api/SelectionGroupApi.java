

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import io.swagger.client.model.SelectionGroup;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SelectionGroupApi {
    private ApiClient apiClient;

    public SelectionGroupApi() {
        this(Configuration.getDefaultApiClient());
    }

    public SelectionGroupApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for selectionGroupsGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param title Ek Özellik Grubu başlığı (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call selectionGroupsGetCall(String sort, Integer limit, Integer page, Integer sinceId, String title, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/selection_groups";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (title != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("title", title));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call selectionGroupsGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, String title, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = selectionGroupsGetCall(sort, limit, page, sinceId, title, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ek Özellik Grubu Listesi Alma
     * Ek Özellik Grubu listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param title Ek Özellik Grubu başlığı (optional)
     * @return SelectionGroup
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SelectionGroup selectionGroupsGet(String sort, Integer limit, Integer page, Integer sinceId, String title) throws ApiException {
        ApiResponse<SelectionGroup> resp = selectionGroupsGetWithHttpInfo(sort, limit, page, sinceId, title);
        return resp.getData();
    }

    /**
     * Ek Özellik Grubu Listesi Alma
     * Ek Özellik Grubu listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param title Ek Özellik Grubu başlığı (optional)
     * @return ApiResponse&lt;SelectionGroup&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SelectionGroup> selectionGroupsGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, String title) throws ApiException {
        com.squareup.okhttp.Call call = selectionGroupsGetValidateBeforeCall(sort, limit, page, sinceId, title, null, null);
        Type localVarReturnType = new TypeToken<SelectionGroup>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ek Özellik Grubu Listesi Alma (asynchronously)
     * Ek Özellik Grubu listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param title Ek Özellik Grubu başlığı (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call selectionGroupsGetAsync(String sort, Integer limit, Integer page, Integer sinceId, String title, final ApiCallback<SelectionGroup> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = selectionGroupsGetValidateBeforeCall(sort, limit, page, sinceId, title, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SelectionGroup>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for selectionGroupsIdDelete
     * @param id Ek Özellik Grubu nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call selectionGroupsIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/selection_groups/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call selectionGroupsIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling selectionGroupsIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = selectionGroupsIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ek Özellik Grubu Silme
     * Kalıcı olarak ilgili Ek Özellik Grubunu siler.
     * @param id Ek Özellik Grubu nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void selectionGroupsIdDelete(Integer id) throws ApiException {
        selectionGroupsIdDeleteWithHttpInfo(id);
    }

    /**
     * Ek Özellik Grubu Silme
     * Kalıcı olarak ilgili Ek Özellik Grubunu siler.
     * @param id Ek Özellik Grubu nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> selectionGroupsIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = selectionGroupsIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Ek Özellik Grubu Silme (asynchronously)
     * Kalıcı olarak ilgili Ek Özellik Grubunu siler.
     * @param id Ek Özellik Grubu nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call selectionGroupsIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = selectionGroupsIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for selectionGroupsIdGet
     * @param id Ek Özellik Grubu nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call selectionGroupsIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/selection_groups/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call selectionGroupsIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling selectionGroupsIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = selectionGroupsIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ek Özellik Grubu Alma
     * İlgili Ek Özellik Grubunu getirir.
     * @param id Ek Özellik Grubu nesnesinin id değeri (required)
     * @return SelectionGroup
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SelectionGroup selectionGroupsIdGet(Integer id) throws ApiException {
        ApiResponse<SelectionGroup> resp = selectionGroupsIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Ek Özellik Grubu Alma
     * İlgili Ek Özellik Grubunu getirir.
     * @param id Ek Özellik Grubu nesnesinin id değeri (required)
     * @return ApiResponse&lt;SelectionGroup&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SelectionGroup> selectionGroupsIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = selectionGroupsIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<SelectionGroup>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ek Özellik Grubu Alma (asynchronously)
     * İlgili Ek Özellik Grubunu getirir.
     * @param id Ek Özellik Grubu nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call selectionGroupsIdGetAsync(Integer id, final ApiCallback<SelectionGroup> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = selectionGroupsIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SelectionGroup>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for selectionGroupsIdPut
     * @param id Ek Özellik Grubu nesnesinin id değeri (required)
     * @param selectionGroup SelectionGroup nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call selectionGroupsIdPutCall(Integer id, SelectionGroup selectionGroup, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = selectionGroup;

        // create path and map variables
        String localVarPath = "/selection_groups/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call selectionGroupsIdPutValidateBeforeCall(Integer id, SelectionGroup selectionGroup, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling selectionGroupsIdPut(Async)");
        }
        
        // verify the required parameter 'selectionGroup' is set
        if (selectionGroup == null) {
            throw new ApiException("Missing the required parameter 'selectionGroup' when calling selectionGroupsIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = selectionGroupsIdPutCall(id, selectionGroup, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ek Özellik Grubu Güncelleme
     * İlgili Ek Özellik Grubunu günceller.
     * @param id Ek Özellik Grubu nesnesinin id değeri (required)
     * @param selectionGroup SelectionGroup nesnesi (required)
     * @return SelectionGroup
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SelectionGroup selectionGroupsIdPut(Integer id, SelectionGroup selectionGroup) throws ApiException {
        ApiResponse<SelectionGroup> resp = selectionGroupsIdPutWithHttpInfo(id, selectionGroup);
        return resp.getData();
    }

    /**
     * Ek Özellik Grubu Güncelleme
     * İlgili Ek Özellik Grubunu günceller.
     * @param id Ek Özellik Grubu nesnesinin id değeri (required)
     * @param selectionGroup SelectionGroup nesnesi (required)
     * @return ApiResponse&lt;SelectionGroup&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SelectionGroup> selectionGroupsIdPutWithHttpInfo(Integer id, SelectionGroup selectionGroup) throws ApiException {
        com.squareup.okhttp.Call call = selectionGroupsIdPutValidateBeforeCall(id, selectionGroup, null, null);
        Type localVarReturnType = new TypeToken<SelectionGroup>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ek Özellik Grubu Güncelleme (asynchronously)
     * İlgili Ek Özellik Grubunu günceller.
     * @param id Ek Özellik Grubu nesnesinin id değeri (required)
     * @param selectionGroup SelectionGroup nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call selectionGroupsIdPutAsync(Integer id, SelectionGroup selectionGroup, final ApiCallback<SelectionGroup> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = selectionGroupsIdPutValidateBeforeCall(id, selectionGroup, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SelectionGroup>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for selectionGroupsPost
     * @param selectionGroup SelectionGroup nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call selectionGroupsPostCall(SelectionGroup selectionGroup, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = selectionGroup;

        // create path and map variables
        String localVarPath = "/selection_groups";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call selectionGroupsPostValidateBeforeCall(SelectionGroup selectionGroup, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'selectionGroup' is set
        if (selectionGroup == null) {
            throw new ApiException("Missing the required parameter 'selectionGroup' when calling selectionGroupsPost(Async)");
        }
        

        com.squareup.okhttp.Call call = selectionGroupsPostCall(selectionGroup, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ek Özellik Grubu Oluşturma
     * Yeni bir Ek Özellik Grubu oluşturur.
     * @param selectionGroup SelectionGroup nesnesi (required)
     * @return SelectionGroup
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SelectionGroup selectionGroupsPost(SelectionGroup selectionGroup) throws ApiException {
        ApiResponse<SelectionGroup> resp = selectionGroupsPostWithHttpInfo(selectionGroup);
        return resp.getData();
    }

    /**
     * Ek Özellik Grubu Oluşturma
     * Yeni bir Ek Özellik Grubu oluşturur.
     * @param selectionGroup SelectionGroup nesnesi (required)
     * @return ApiResponse&lt;SelectionGroup&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SelectionGroup> selectionGroupsPostWithHttpInfo(SelectionGroup selectionGroup) throws ApiException {
        com.squareup.okhttp.Call call = selectionGroupsPostValidateBeforeCall(selectionGroup, null, null);
        Type localVarReturnType = new TypeToken<SelectionGroup>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ek Özellik Grubu Oluşturma (asynchronously)
     * Yeni bir Ek Özellik Grubu oluşturur.
     * @param selectionGroup SelectionGroup nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call selectionGroupsPostAsync(SelectionGroup selectionGroup, final ApiCallback<SelectionGroup> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = selectionGroupsPostValidateBeforeCall(selectionGroup, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SelectionGroup>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
