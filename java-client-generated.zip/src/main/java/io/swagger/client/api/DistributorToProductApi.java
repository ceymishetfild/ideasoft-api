

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.DistributorToProduct;
import io.swagger.client.model.Error;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DistributorToProductApi {
    private ApiClient apiClient;

    public DistributorToProductApi() {
        this(Configuration.getDefaultApiClient());
    }

    public DistributorToProductApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for distributorToProductsGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param distributor Distribütör id (optional)
     * @param product Ürün id (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call distributorToProductsGetCall(String sort, Integer limit, Integer page, Integer sinceId, Integer distributor, Integer product, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/distributor_to_products";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (distributor != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("distributor", distributor));
        if (product != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("product", product));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call distributorToProductsGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, Integer distributor, Integer product, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = distributorToProductsGetCall(sort, limit, page, sinceId, distributor, product, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Distribütör Ürün Bağı Listesi Alma
     * Distribütör Ürün Bağı listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param distributor Distribütör id (optional)
     * @param product Ürün id (optional)
     * @return DistributorToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public DistributorToProduct distributorToProductsGet(String sort, Integer limit, Integer page, Integer sinceId, Integer distributor, Integer product) throws ApiException {
        ApiResponse<DistributorToProduct> resp = distributorToProductsGetWithHttpInfo(sort, limit, page, sinceId, distributor, product);
        return resp.getData();
    }

    /**
     * Distribütör Ürün Bağı Listesi Alma
     * Distribütör Ürün Bağı listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param distributor Distribütör id (optional)
     * @param product Ürün id (optional)
     * @return ApiResponse&lt;DistributorToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<DistributorToProduct> distributorToProductsGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, Integer distributor, Integer product) throws ApiException {
        com.squareup.okhttp.Call call = distributorToProductsGetValidateBeforeCall(sort, limit, page, sinceId, distributor, product, null, null);
        Type localVarReturnType = new TypeToken<DistributorToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Distribütör Ürün Bağı Listesi Alma (asynchronously)
     * Distribütör Ürün Bağı listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param distributor Distribütör id (optional)
     * @param product Ürün id (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call distributorToProductsGetAsync(String sort, Integer limit, Integer page, Integer sinceId, Integer distributor, Integer product, final ApiCallback<DistributorToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = distributorToProductsGetValidateBeforeCall(sort, limit, page, sinceId, distributor, product, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<DistributorToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for distributorToProductsIdDelete
     * @param id Distribütör Ürün Bağı nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call distributorToProductsIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/distributor_to_products/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call distributorToProductsIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling distributorToProductsIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = distributorToProductsIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Distribütör Ürün Bağı Silme
     * Kalıcı olarak ilgili Distribütör Ürün Bağını siler
     * @param id Distribütör Ürün Bağı nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void distributorToProductsIdDelete(Integer id) throws ApiException {
        distributorToProductsIdDeleteWithHttpInfo(id);
    }

    /**
     * Distribütör Ürün Bağı Silme
     * Kalıcı olarak ilgili Distribütör Ürün Bağını siler
     * @param id Distribütör Ürün Bağı nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> distributorToProductsIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = distributorToProductsIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Distribütör Ürün Bağı Silme (asynchronously)
     * Kalıcı olarak ilgili Distribütör Ürün Bağını siler
     * @param id Distribütör Ürün Bağı nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call distributorToProductsIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = distributorToProductsIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for distributorToProductsIdGet
     * @param id Distribütör Ürün Bağı nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call distributorToProductsIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/distributor_to_products/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call distributorToProductsIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling distributorToProductsIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = distributorToProductsIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Distribütör Ürün Bağı Alma
     * İlgili Distribütör Ürün Bağını getirir.
     * @param id Distribütör Ürün Bağı nesnesinin id değeri (required)
     * @return DistributorToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public DistributorToProduct distributorToProductsIdGet(Integer id) throws ApiException {
        ApiResponse<DistributorToProduct> resp = distributorToProductsIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Distribütör Ürün Bağı Alma
     * İlgili Distribütör Ürün Bağını getirir.
     * @param id Distribütör Ürün Bağı nesnesinin id değeri (required)
     * @return ApiResponse&lt;DistributorToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<DistributorToProduct> distributorToProductsIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = distributorToProductsIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<DistributorToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Distribütör Ürün Bağı Alma (asynchronously)
     * İlgili Distribütör Ürün Bağını getirir.
     * @param id Distribütör Ürün Bağı nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call distributorToProductsIdGetAsync(Integer id, final ApiCallback<DistributorToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = distributorToProductsIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<DistributorToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for distributorToProductsIdPut
     * @param id Distribütör Ürün Bağı nesnesinin id değeri (required)
     * @param distributorToProduct DistributorToProduct nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call distributorToProductsIdPutCall(Integer id, DistributorToProduct distributorToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = distributorToProduct;

        // create path and map variables
        String localVarPath = "/distributor_to_products/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call distributorToProductsIdPutValidateBeforeCall(Integer id, DistributorToProduct distributorToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling distributorToProductsIdPut(Async)");
        }
        
        // verify the required parameter 'distributorToProduct' is set
        if (distributorToProduct == null) {
            throw new ApiException("Missing the required parameter 'distributorToProduct' when calling distributorToProductsIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = distributorToProductsIdPutCall(id, distributorToProduct, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Distribütör Ürün Bağı Güncelleme
     * İlgili Distribütör Ürün Bağını günceller.
     * @param id Distribütör Ürün Bağı nesnesinin id değeri (required)
     * @param distributorToProduct DistributorToProduct nesnesi (required)
     * @return DistributorToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public DistributorToProduct distributorToProductsIdPut(Integer id, DistributorToProduct distributorToProduct) throws ApiException {
        ApiResponse<DistributorToProduct> resp = distributorToProductsIdPutWithHttpInfo(id, distributorToProduct);
        return resp.getData();
    }

    /**
     * Distribütör Ürün Bağı Güncelleme
     * İlgili Distribütör Ürün Bağını günceller.
     * @param id Distribütör Ürün Bağı nesnesinin id değeri (required)
     * @param distributorToProduct DistributorToProduct nesnesi (required)
     * @return ApiResponse&lt;DistributorToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<DistributorToProduct> distributorToProductsIdPutWithHttpInfo(Integer id, DistributorToProduct distributorToProduct) throws ApiException {
        com.squareup.okhttp.Call call = distributorToProductsIdPutValidateBeforeCall(id, distributorToProduct, null, null);
        Type localVarReturnType = new TypeToken<DistributorToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Distribütör Ürün Bağı Güncelleme (asynchronously)
     * İlgili Distribütör Ürün Bağını günceller.
     * @param id Distribütör Ürün Bağı nesnesinin id değeri (required)
     * @param distributorToProduct DistributorToProduct nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call distributorToProductsIdPutAsync(Integer id, DistributorToProduct distributorToProduct, final ApiCallback<DistributorToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = distributorToProductsIdPutValidateBeforeCall(id, distributorToProduct, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<DistributorToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for distributorToProductsPost
     * @param distributorToProduct DistributorToProduct nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call distributorToProductsPostCall(DistributorToProduct distributorToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = distributorToProduct;

        // create path and map variables
        String localVarPath = "/distributor_to_products";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call distributorToProductsPostValidateBeforeCall(DistributorToProduct distributorToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'distributorToProduct' is set
        if (distributorToProduct == null) {
            throw new ApiException("Missing the required parameter 'distributorToProduct' when calling distributorToProductsPost(Async)");
        }
        

        com.squareup.okhttp.Call call = distributorToProductsPostCall(distributorToProduct, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Distribütör Ürün Bağı Oluşturma
     * Yeni bir Distribütör Ürün Bağı oluşturur.
     * @param distributorToProduct DistributorToProduct nesnesi (required)
     * @return DistributorToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public DistributorToProduct distributorToProductsPost(DistributorToProduct distributorToProduct) throws ApiException {
        ApiResponse<DistributorToProduct> resp = distributorToProductsPostWithHttpInfo(distributorToProduct);
        return resp.getData();
    }

    /**
     * Distribütör Ürün Bağı Oluşturma
     * Yeni bir Distribütör Ürün Bağı oluşturur.
     * @param distributorToProduct DistributorToProduct nesnesi (required)
     * @return ApiResponse&lt;DistributorToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<DistributorToProduct> distributorToProductsPostWithHttpInfo(DistributorToProduct distributorToProduct) throws ApiException {
        com.squareup.okhttp.Call call = distributorToProductsPostValidateBeforeCall(distributorToProduct, null, null);
        Type localVarReturnType = new TypeToken<DistributorToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Distribütör Ürün Bağı Oluşturma (asynchronously)
     * Yeni bir Distribütör Ürün Bağı oluşturur.
     * @param distributorToProduct DistributorToProduct nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call distributorToProductsPostAsync(DistributorToProduct distributorToProduct, final ApiCallback<DistributorToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = distributorToProductsPostValidateBeforeCall(distributorToProduct, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<DistributorToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
