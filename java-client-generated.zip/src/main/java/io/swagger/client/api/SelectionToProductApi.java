

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import io.swagger.client.model.SelectionToProduct;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SelectionToProductApi {
    private ApiClient apiClient;

    public SelectionToProductApi() {
        this(Configuration.getDefaultApiClient());
    }

    public SelectionToProductApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for selectionToProductsGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param selection Ek Özellik id (optional)
     * @param product Ürün id (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call selectionToProductsGetCall(String sort, Integer limit, Integer page, Integer sinceId, Integer selection, Integer product, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/selection_to_products";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (selection != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("selection", selection));
        if (product != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("product", product));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call selectionToProductsGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, Integer selection, Integer product, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = selectionToProductsGetCall(sort, limit, page, sinceId, selection, product, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ek Özellik Ürün Bağı Listesi Alma
     * Ek Özellik Ürün Bağı listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param selection Ek Özellik id (optional)
     * @param product Ürün id (optional)
     * @return SelectionToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SelectionToProduct selectionToProductsGet(String sort, Integer limit, Integer page, Integer sinceId, Integer selection, Integer product) throws ApiException {
        ApiResponse<SelectionToProduct> resp = selectionToProductsGetWithHttpInfo(sort, limit, page, sinceId, selection, product);
        return resp.getData();
    }

    /**
     * Ek Özellik Ürün Bağı Listesi Alma
     * Ek Özellik Ürün Bağı listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param selection Ek Özellik id (optional)
     * @param product Ürün id (optional)
     * @return ApiResponse&lt;SelectionToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SelectionToProduct> selectionToProductsGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, Integer selection, Integer product) throws ApiException {
        com.squareup.okhttp.Call call = selectionToProductsGetValidateBeforeCall(sort, limit, page, sinceId, selection, product, null, null);
        Type localVarReturnType = new TypeToken<SelectionToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ek Özellik Ürün Bağı Listesi Alma (asynchronously)
     * Ek Özellik Ürün Bağı listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param selection Ek Özellik id (optional)
     * @param product Ürün id (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call selectionToProductsGetAsync(String sort, Integer limit, Integer page, Integer sinceId, Integer selection, Integer product, final ApiCallback<SelectionToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = selectionToProductsGetValidateBeforeCall(sort, limit, page, sinceId, selection, product, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SelectionToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for selectionToProductsIdDelete
     * @param id Ek Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call selectionToProductsIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/selection_to_products/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call selectionToProductsIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling selectionToProductsIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = selectionToProductsIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ek Özellik Ürün Bağı Silme
     * Kalıcı olarak ilgili Ek Özellik Ürün Bağını siler.
     * @param id Ek Özellik Ürün Bağı nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void selectionToProductsIdDelete(Integer id) throws ApiException {
        selectionToProductsIdDeleteWithHttpInfo(id);
    }

    /**
     * Ek Özellik Ürün Bağı Silme
     * Kalıcı olarak ilgili Ek Özellik Ürün Bağını siler.
     * @param id Ek Özellik Ürün Bağı nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> selectionToProductsIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = selectionToProductsIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Ek Özellik Ürün Bağı Silme (asynchronously)
     * Kalıcı olarak ilgili Ek Özellik Ürün Bağını siler.
     * @param id Ek Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call selectionToProductsIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = selectionToProductsIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for selectionToProductsIdGet
     * @param id Ek Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call selectionToProductsIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/selection_to_products/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call selectionToProductsIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling selectionToProductsIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = selectionToProductsIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ek Özellik Ürün Bağı Alma
     * İlgili Ek Özellik Ürün Bağını getirir.
     * @param id Ek Özellik Ürün Bağı nesnesinin id değeri (required)
     * @return SelectionToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SelectionToProduct selectionToProductsIdGet(Integer id) throws ApiException {
        ApiResponse<SelectionToProduct> resp = selectionToProductsIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Ek Özellik Ürün Bağı Alma
     * İlgili Ek Özellik Ürün Bağını getirir.
     * @param id Ek Özellik Ürün Bağı nesnesinin id değeri (required)
     * @return ApiResponse&lt;SelectionToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SelectionToProduct> selectionToProductsIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = selectionToProductsIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<SelectionToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ek Özellik Ürün Bağı Alma (asynchronously)
     * İlgili Ek Özellik Ürün Bağını getirir.
     * @param id Ek Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call selectionToProductsIdGetAsync(Integer id, final ApiCallback<SelectionToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = selectionToProductsIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SelectionToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for selectionToProductsIdPut
     * @param id Ek Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param selectionToProduct SelectionToProduct nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call selectionToProductsIdPutCall(Integer id, SelectionToProduct selectionToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = selectionToProduct;

        // create path and map variables
        String localVarPath = "/selection_to_products/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call selectionToProductsIdPutValidateBeforeCall(Integer id, SelectionToProduct selectionToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling selectionToProductsIdPut(Async)");
        }
        
        // verify the required parameter 'selectionToProduct' is set
        if (selectionToProduct == null) {
            throw new ApiException("Missing the required parameter 'selectionToProduct' when calling selectionToProductsIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = selectionToProductsIdPutCall(id, selectionToProduct, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ek Özellik Ürün Bağı Güncelleme
     * İlgili Ek Özellik Ürün Bağını günceller.
     * @param id Ek Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param selectionToProduct SelectionToProduct nesnesi (required)
     * @return SelectionToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SelectionToProduct selectionToProductsIdPut(Integer id, SelectionToProduct selectionToProduct) throws ApiException {
        ApiResponse<SelectionToProduct> resp = selectionToProductsIdPutWithHttpInfo(id, selectionToProduct);
        return resp.getData();
    }

    /**
     * Ek Özellik Ürün Bağı Güncelleme
     * İlgili Ek Özellik Ürün Bağını günceller.
     * @param id Ek Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param selectionToProduct SelectionToProduct nesnesi (required)
     * @return ApiResponse&lt;SelectionToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SelectionToProduct> selectionToProductsIdPutWithHttpInfo(Integer id, SelectionToProduct selectionToProduct) throws ApiException {
        com.squareup.okhttp.Call call = selectionToProductsIdPutValidateBeforeCall(id, selectionToProduct, null, null);
        Type localVarReturnType = new TypeToken<SelectionToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ek Özellik Ürün Bağı Güncelleme (asynchronously)
     * İlgili Ek Özellik Ürün Bağını günceller.
     * @param id Ek Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param selectionToProduct SelectionToProduct nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call selectionToProductsIdPutAsync(Integer id, SelectionToProduct selectionToProduct, final ApiCallback<SelectionToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = selectionToProductsIdPutValidateBeforeCall(id, selectionToProduct, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SelectionToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for selectionToProductsPost
     * @param selectionToProduct SelectionToProduct nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call selectionToProductsPostCall(SelectionToProduct selectionToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = selectionToProduct;

        // create path and map variables
        String localVarPath = "/selection_to_products";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call selectionToProductsPostValidateBeforeCall(SelectionToProduct selectionToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'selectionToProduct' is set
        if (selectionToProduct == null) {
            throw new ApiException("Missing the required parameter 'selectionToProduct' when calling selectionToProductsPost(Async)");
        }
        

        com.squareup.okhttp.Call call = selectionToProductsPostCall(selectionToProduct, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ek Özellik Ürün Bağı Oluşturma
     * Yeni bir Ek Özellik Ürün Bağı oluşturur.
     * @param selectionToProduct SelectionToProduct nesnesi (required)
     * @return SelectionToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SelectionToProduct selectionToProductsPost(SelectionToProduct selectionToProduct) throws ApiException {
        ApiResponse<SelectionToProduct> resp = selectionToProductsPostWithHttpInfo(selectionToProduct);
        return resp.getData();
    }

    /**
     * Ek Özellik Ürün Bağı Oluşturma
     * Yeni bir Ek Özellik Ürün Bağı oluşturur.
     * @param selectionToProduct SelectionToProduct nesnesi (required)
     * @return ApiResponse&lt;SelectionToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SelectionToProduct> selectionToProductsPostWithHttpInfo(SelectionToProduct selectionToProduct) throws ApiException {
        com.squareup.okhttp.Call call = selectionToProductsPostValidateBeforeCall(selectionToProduct, null, null);
        Type localVarReturnType = new TypeToken<SelectionToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ek Özellik Ürün Bağı Oluşturma (asynchronously)
     * Yeni bir Ek Özellik Ürün Bağı oluşturur.
     * @param selectionToProduct SelectionToProduct nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call selectionToProductsPostAsync(SelectionToProduct selectionToProduct, final ApiCallback<SelectionToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = selectionToProductsPostValidateBeforeCall(selectionToProduct, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SelectionToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
