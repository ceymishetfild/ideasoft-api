

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import io.swagger.client.model.MemberGroup;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MemberGroupApi {
    private ApiClient apiClient;

    public MemberGroupApi() {
        this(Configuration.getDefaultApiClient());
    }

    public MemberGroupApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for memberGroupsGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Üye Grubu adı (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call memberGroupsGetCall(String sort, Integer limit, Integer page, Integer sinceId, String name, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/member_groups";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (name != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("name", name));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call memberGroupsGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, String name, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = memberGroupsGetCall(sort, limit, page, sinceId, name, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Üye Grubu Listesi Alma
     * Üye Grubu listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Üye Grubu adı (optional)
     * @return MemberGroup
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public MemberGroup memberGroupsGet(String sort, Integer limit, Integer page, Integer sinceId, String name) throws ApiException {
        ApiResponse<MemberGroup> resp = memberGroupsGetWithHttpInfo(sort, limit, page, sinceId, name);
        return resp.getData();
    }

    /**
     * Üye Grubu Listesi Alma
     * Üye Grubu listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Üye Grubu adı (optional)
     * @return ApiResponse&lt;MemberGroup&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<MemberGroup> memberGroupsGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, String name) throws ApiException {
        com.squareup.okhttp.Call call = memberGroupsGetValidateBeforeCall(sort, limit, page, sinceId, name, null, null);
        Type localVarReturnType = new TypeToken<MemberGroup>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Üye Grubu Listesi Alma (asynchronously)
     * Üye Grubu listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Üye Grubu adı (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call memberGroupsGetAsync(String sort, Integer limit, Integer page, Integer sinceId, String name, final ApiCallback<MemberGroup> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = memberGroupsGetValidateBeforeCall(sort, limit, page, sinceId, name, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<MemberGroup>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for memberGroupsIdDelete
     * @param id Üye Grubu nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call memberGroupsIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/member_groups/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call memberGroupsIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling memberGroupsIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = memberGroupsIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Üye Grubu Silme
     * Kalıcı olarak ilgili Üye Grubunu siler.
     * @param id Üye Grubu nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void memberGroupsIdDelete(Integer id) throws ApiException {
        memberGroupsIdDeleteWithHttpInfo(id);
    }

    /**
     * Üye Grubu Silme
     * Kalıcı olarak ilgili Üye Grubunu siler.
     * @param id Üye Grubu nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> memberGroupsIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = memberGroupsIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Üye Grubu Silme (asynchronously)
     * Kalıcı olarak ilgili Üye Grubunu siler.
     * @param id Üye Grubu nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call memberGroupsIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = memberGroupsIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for memberGroupsIdGet
     * @param id Üye Grubu nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call memberGroupsIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/member_groups/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call memberGroupsIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling memberGroupsIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = memberGroupsIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Üye Grubu Alma
     * İlgili Üye Grubunu getirir.
     * @param id Üye Grubu nesnesinin id değeri (required)
     * @return MemberGroup
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public MemberGroup memberGroupsIdGet(Integer id) throws ApiException {
        ApiResponse<MemberGroup> resp = memberGroupsIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Üye Grubu Alma
     * İlgili Üye Grubunu getirir.
     * @param id Üye Grubu nesnesinin id değeri (required)
     * @return ApiResponse&lt;MemberGroup&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<MemberGroup> memberGroupsIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = memberGroupsIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<MemberGroup>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Üye Grubu Alma (asynchronously)
     * İlgili Üye Grubunu getirir.
     * @param id Üye Grubu nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call memberGroupsIdGetAsync(Integer id, final ApiCallback<MemberGroup> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = memberGroupsIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<MemberGroup>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for memberGroupsIdPut
     * @param id Üye Grubu nesnesinin id değeri (required)
     * @param memberGroup MemberGroup nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call memberGroupsIdPutCall(Integer id, MemberGroup memberGroup, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = memberGroup;

        // create path and map variables
        String localVarPath = "/member_groups/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call memberGroupsIdPutValidateBeforeCall(Integer id, MemberGroup memberGroup, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling memberGroupsIdPut(Async)");
        }
        
        // verify the required parameter 'memberGroup' is set
        if (memberGroup == null) {
            throw new ApiException("Missing the required parameter 'memberGroup' when calling memberGroupsIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = memberGroupsIdPutCall(id, memberGroup, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Üye Grubu Güncelleme
     * İlgili Üye Grubunu günceller.
     * @param id Üye Grubu nesnesinin id değeri (required)
     * @param memberGroup MemberGroup nesnesi (required)
     * @return MemberGroup
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public MemberGroup memberGroupsIdPut(Integer id, MemberGroup memberGroup) throws ApiException {
        ApiResponse<MemberGroup> resp = memberGroupsIdPutWithHttpInfo(id, memberGroup);
        return resp.getData();
    }

    /**
     * Üye Grubu Güncelleme
     * İlgili Üye Grubunu günceller.
     * @param id Üye Grubu nesnesinin id değeri (required)
     * @param memberGroup MemberGroup nesnesi (required)
     * @return ApiResponse&lt;MemberGroup&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<MemberGroup> memberGroupsIdPutWithHttpInfo(Integer id, MemberGroup memberGroup) throws ApiException {
        com.squareup.okhttp.Call call = memberGroupsIdPutValidateBeforeCall(id, memberGroup, null, null);
        Type localVarReturnType = new TypeToken<MemberGroup>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Üye Grubu Güncelleme (asynchronously)
     * İlgili Üye Grubunu günceller.
     * @param id Üye Grubu nesnesinin id değeri (required)
     * @param memberGroup MemberGroup nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call memberGroupsIdPutAsync(Integer id, MemberGroup memberGroup, final ApiCallback<MemberGroup> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = memberGroupsIdPutValidateBeforeCall(id, memberGroup, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<MemberGroup>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for memberGroupsPost
     * @param memberGroup MemberGroup nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call memberGroupsPostCall(MemberGroup memberGroup, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = memberGroup;

        // create path and map variables
        String localVarPath = "/member_groups";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call memberGroupsPostValidateBeforeCall(MemberGroup memberGroup, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'memberGroup' is set
        if (memberGroup == null) {
            throw new ApiException("Missing the required parameter 'memberGroup' when calling memberGroupsPost(Async)");
        }
        

        com.squareup.okhttp.Call call = memberGroupsPostCall(memberGroup, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Üye Grubu Oluşturma
     * Yeni bir Üye Grubu oluşturur.
     * @param memberGroup MemberGroup nesnesi (required)
     * @return MemberGroup
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public MemberGroup memberGroupsPost(MemberGroup memberGroup) throws ApiException {
        ApiResponse<MemberGroup> resp = memberGroupsPostWithHttpInfo(memberGroup);
        return resp.getData();
    }

    /**
     * Üye Grubu Oluşturma
     * Yeni bir Üye Grubu oluşturur.
     * @param memberGroup MemberGroup nesnesi (required)
     * @return ApiResponse&lt;MemberGroup&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<MemberGroup> memberGroupsPostWithHttpInfo(MemberGroup memberGroup) throws ApiException {
        com.squareup.okhttp.Call call = memberGroupsPostValidateBeforeCall(memberGroup, null, null);
        Type localVarReturnType = new TypeToken<MemberGroup>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Üye Grubu Oluşturma (asynchronously)
     * Yeni bir Üye Grubu oluşturur.
     * @param memberGroup MemberGroup nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call memberGroupsPostAsync(MemberGroup memberGroup, final ApiCallback<MemberGroup> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = memberGroupsPostValidateBeforeCall(memberGroup, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<MemberGroup>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
