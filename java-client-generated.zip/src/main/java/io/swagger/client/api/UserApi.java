

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.User;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserApi {
    private ApiClient apiClient;

    public UserApi() {
        this(Configuration.getDefaultApiClient());
    }

    public UserApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for usersGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param firstname Adı (optional)
     * @param surname Soyadı (optional)
     * @param email e-mail (optional)
     * @param username Yönetici adı (optional)
     * @param phoneNumber Telefon numarası (optional)
     * @param isOwner Mağaza sahibi mi?&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param status Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Askıya alınmış (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call usersGetCall(String sort, Integer limit, Integer page, Integer sinceId, String firstname, String surname, String email, String username, String phoneNumber, Integer isOwner, String status, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/users";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (firstname != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("firstname", firstname));
        if (surname != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("surname", surname));
        if (email != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("email", email));
        if (username != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("username", username));
        if (phoneNumber != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("phoneNumber", phoneNumber));
        if (isOwner != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("isOwner", isOwner));
        if (status != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("status", status));
        if (startDate != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("startDate", startDate));
        if (endDate != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("endDate", endDate));
        if (startUpdatedAt != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("startUpdatedAt", startUpdatedAt));
        if (endUpdatedAt != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("endUpdatedAt", endUpdatedAt));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call usersGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, String firstname, String surname, String email, String username, String phoneNumber, Integer isOwner, String status, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = usersGetCall(sort, limit, page, sinceId, firstname, surname, email, username, phoneNumber, isOwner, status, startDate, endDate, startUpdatedAt, endUpdatedAt, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Yönetici Listesi Alma
     * Yönetici listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param firstname Adı (optional)
     * @param surname Soyadı (optional)
     * @param email e-mail (optional)
     * @param username Yönetici adı (optional)
     * @param phoneNumber Telefon numarası (optional)
     * @param isOwner Mağaza sahibi mi?&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param status Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Askıya alınmış (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @return User
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public User usersGet(String sort, Integer limit, Integer page, Integer sinceId, String firstname, String surname, String email, String username, String phoneNumber, Integer isOwner, String status, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt) throws ApiException {
        ApiResponse<User> resp = usersGetWithHttpInfo(sort, limit, page, sinceId, firstname, surname, email, username, phoneNumber, isOwner, status, startDate, endDate, startUpdatedAt, endUpdatedAt);
        return resp.getData();
    }

    /**
     * Yönetici Listesi Alma
     * Yönetici listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param firstname Adı (optional)
     * @param surname Soyadı (optional)
     * @param email e-mail (optional)
     * @param username Yönetici adı (optional)
     * @param phoneNumber Telefon numarası (optional)
     * @param isOwner Mağaza sahibi mi?&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param status Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Askıya alınmış (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @return ApiResponse&lt;User&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<User> usersGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, String firstname, String surname, String email, String username, String phoneNumber, Integer isOwner, String status, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt) throws ApiException {
        com.squareup.okhttp.Call call = usersGetValidateBeforeCall(sort, limit, page, sinceId, firstname, surname, email, username, phoneNumber, isOwner, status, startDate, endDate, startUpdatedAt, endUpdatedAt, null, null);
        Type localVarReturnType = new TypeToken<User>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Yönetici Listesi Alma (asynchronously)
     * Yönetici listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param firstname Adı (optional)
     * @param surname Soyadı (optional)
     * @param email e-mail (optional)
     * @param username Yönetici adı (optional)
     * @param phoneNumber Telefon numarası (optional)
     * @param isOwner Mağaza sahibi mi?&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param status Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Askıya alınmış (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call usersGetAsync(String sort, Integer limit, Integer page, Integer sinceId, String firstname, String surname, String email, String username, String phoneNumber, Integer isOwner, String status, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, final ApiCallback<User> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = usersGetValidateBeforeCall(sort, limit, page, sinceId, firstname, surname, email, username, phoneNumber, isOwner, status, startDate, endDate, startUpdatedAt, endUpdatedAt, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<User>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for usersIdGet
     * @param id Yönetici nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call usersIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/users/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call usersIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling usersIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = usersIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Yönetici Alma
     * İlgili Yöneticiyi  getirir.
     * @param id Yönetici nesnesinin id değeri (required)
     * @return User
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public User usersIdGet(Integer id) throws ApiException {
        ApiResponse<User> resp = usersIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Yönetici Alma
     * İlgili Yöneticiyi  getirir.
     * @param id Yönetici nesnesinin id değeri (required)
     * @return ApiResponse&lt;User&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<User> usersIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = usersIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<User>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Yönetici Alma (asynchronously)
     * İlgili Yöneticiyi  getirir.
     * @param id Yönetici nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call usersIdGetAsync(Integer id, final ApiCallback<User> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = usersIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<User>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
