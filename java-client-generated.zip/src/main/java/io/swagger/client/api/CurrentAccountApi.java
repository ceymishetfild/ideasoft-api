

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.CurrentAccount;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CurrentAccountApi {
    private ApiClient apiClient;

    public CurrentAccountApi() {
        this(Configuration.getDefaultApiClient());
    }

    public CurrentAccountApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for currentAccountsGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param code Cari Hesap kodu (optional)
     * @param title Cari Hesap başlığı (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @param member İlgili üye (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call currentAccountsGetCall(String sort, Integer limit, Integer page, Integer sinceId, String code, String title, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, String member, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/current_accounts";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (code != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("code", code));
        if (title != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("title", title));
        if (startDate != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("startDate", startDate));
        if (endDate != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("endDate", endDate));
        if (startUpdatedAt != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("startUpdatedAt", startUpdatedAt));
        if (endUpdatedAt != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("endUpdatedAt", endUpdatedAt));
        if (member != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("member", member));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call currentAccountsGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, String code, String title, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, String member, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = currentAccountsGetCall(sort, limit, page, sinceId, code, title, startDate, endDate, startUpdatedAt, endUpdatedAt, member, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Cari Hesap Listesi Alma
     * Cari Hesap listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param code Cari Hesap kodu (optional)
     * @param title Cari Hesap başlığı (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @param member İlgili üye (optional)
     * @return CurrentAccount
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public CurrentAccount currentAccountsGet(String sort, Integer limit, Integer page, Integer sinceId, String code, String title, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, String member) throws ApiException {
        ApiResponse<CurrentAccount> resp = currentAccountsGetWithHttpInfo(sort, limit, page, sinceId, code, title, startDate, endDate, startUpdatedAt, endUpdatedAt, member);
        return resp.getData();
    }

    /**
     * Cari Hesap Listesi Alma
     * Cari Hesap listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param code Cari Hesap kodu (optional)
     * @param title Cari Hesap başlığı (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @param member İlgili üye (optional)
     * @return ApiResponse&lt;CurrentAccount&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<CurrentAccount> currentAccountsGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, String code, String title, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, String member) throws ApiException {
        com.squareup.okhttp.Call call = currentAccountsGetValidateBeforeCall(sort, limit, page, sinceId, code, title, startDate, endDate, startUpdatedAt, endUpdatedAt, member, null, null);
        Type localVarReturnType = new TypeToken<CurrentAccount>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Cari Hesap Listesi Alma (asynchronously)
     * Cari Hesap listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param code Cari Hesap kodu (optional)
     * @param title Cari Hesap başlığı (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @param member İlgili üye (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call currentAccountsGetAsync(String sort, Integer limit, Integer page, Integer sinceId, String code, String title, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, String member, final ApiCallback<CurrentAccount> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = currentAccountsGetValidateBeforeCall(sort, limit, page, sinceId, code, title, startDate, endDate, startUpdatedAt, endUpdatedAt, member, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<CurrentAccount>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for currentAccountsIdDelete
     * @param id Cari Hesap nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call currentAccountsIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/current_accounts/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call currentAccountsIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling currentAccountsIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = currentAccountsIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Cari Hesap Silme
     * Kalıcı olarak ilgili Cari Hesabı siler.
     * @param id Cari Hesap nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void currentAccountsIdDelete(Integer id) throws ApiException {
        currentAccountsIdDeleteWithHttpInfo(id);
    }

    /**
     * Cari Hesap Silme
     * Kalıcı olarak ilgili Cari Hesabı siler.
     * @param id Cari Hesap nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> currentAccountsIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = currentAccountsIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Cari Hesap Silme (asynchronously)
     * Kalıcı olarak ilgili Cari Hesabı siler.
     * @param id Cari Hesap nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call currentAccountsIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = currentAccountsIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for currentAccountsIdGet
     * @param id Cari Hesap nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call currentAccountsIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/current_accounts/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call currentAccountsIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling currentAccountsIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = currentAccountsIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Cari Hesap Alma
     * İlgili Cari Hesabı getirir.
     * @param id Cari Hesap nesnesinin id değeri (required)
     * @return CurrentAccount
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public CurrentAccount currentAccountsIdGet(Integer id) throws ApiException {
        ApiResponse<CurrentAccount> resp = currentAccountsIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Cari Hesap Alma
     * İlgili Cari Hesabı getirir.
     * @param id Cari Hesap nesnesinin id değeri (required)
     * @return ApiResponse&lt;CurrentAccount&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<CurrentAccount> currentAccountsIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = currentAccountsIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<CurrentAccount>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Cari Hesap Alma (asynchronously)
     * İlgili Cari Hesabı getirir.
     * @param id Cari Hesap nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call currentAccountsIdGetAsync(Integer id, final ApiCallback<CurrentAccount> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = currentAccountsIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<CurrentAccount>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for currentAccountsIdPut
     * @param id Cari Hesap nesnesinin id değeri (required)
     * @param currentAccount CurrentAccount nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call currentAccountsIdPutCall(Integer id, CurrentAccount currentAccount, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = currentAccount;

        // create path and map variables
        String localVarPath = "/current_accounts/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call currentAccountsIdPutValidateBeforeCall(Integer id, CurrentAccount currentAccount, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling currentAccountsIdPut(Async)");
        }
        
        // verify the required parameter 'currentAccount' is set
        if (currentAccount == null) {
            throw new ApiException("Missing the required parameter 'currentAccount' when calling currentAccountsIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = currentAccountsIdPutCall(id, currentAccount, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Cari Hesap Güncelleme
     * İlgili Cari Hesabı günceller.
     * @param id Cari Hesap nesnesinin id değeri (required)
     * @param currentAccount CurrentAccount nesnesi (required)
     * @return CurrentAccount
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public CurrentAccount currentAccountsIdPut(Integer id, CurrentAccount currentAccount) throws ApiException {
        ApiResponse<CurrentAccount> resp = currentAccountsIdPutWithHttpInfo(id, currentAccount);
        return resp.getData();
    }

    /**
     * Cari Hesap Güncelleme
     * İlgili Cari Hesabı günceller.
     * @param id Cari Hesap nesnesinin id değeri (required)
     * @param currentAccount CurrentAccount nesnesi (required)
     * @return ApiResponse&lt;CurrentAccount&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<CurrentAccount> currentAccountsIdPutWithHttpInfo(Integer id, CurrentAccount currentAccount) throws ApiException {
        com.squareup.okhttp.Call call = currentAccountsIdPutValidateBeforeCall(id, currentAccount, null, null);
        Type localVarReturnType = new TypeToken<CurrentAccount>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Cari Hesap Güncelleme (asynchronously)
     * İlgili Cari Hesabı günceller.
     * @param id Cari Hesap nesnesinin id değeri (required)
     * @param currentAccount CurrentAccount nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call currentAccountsIdPutAsync(Integer id, CurrentAccount currentAccount, final ApiCallback<CurrentAccount> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = currentAccountsIdPutValidateBeforeCall(id, currentAccount, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<CurrentAccount>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for currentAccountsPost
     * @param currentAccount CurrentAccount nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call currentAccountsPostCall(CurrentAccount currentAccount, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = currentAccount;

        // create path and map variables
        String localVarPath = "/current_accounts";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call currentAccountsPostValidateBeforeCall(CurrentAccount currentAccount, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'currentAccount' is set
        if (currentAccount == null) {
            throw new ApiException("Missing the required parameter 'currentAccount' when calling currentAccountsPost(Async)");
        }
        

        com.squareup.okhttp.Call call = currentAccountsPostCall(currentAccount, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Cari Hesap Oluşturma
     * Yeni bir Cari Hesap oluşturur.
     * @param currentAccount CurrentAccount nesnesi (required)
     * @return CurrentAccount
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public CurrentAccount currentAccountsPost(CurrentAccount currentAccount) throws ApiException {
        ApiResponse<CurrentAccount> resp = currentAccountsPostWithHttpInfo(currentAccount);
        return resp.getData();
    }

    /**
     * Cari Hesap Oluşturma
     * Yeni bir Cari Hesap oluşturur.
     * @param currentAccount CurrentAccount nesnesi (required)
     * @return ApiResponse&lt;CurrentAccount&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<CurrentAccount> currentAccountsPostWithHttpInfo(CurrentAccount currentAccount) throws ApiException {
        com.squareup.okhttp.Call call = currentAccountsPostValidateBeforeCall(currentAccount, null, null);
        Type localVarReturnType = new TypeToken<CurrentAccount>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Cari Hesap Oluşturma (asynchronously)
     * Yeni bir Cari Hesap oluşturur.
     * @param currentAccount CurrentAccount nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call currentAccountsPostAsync(CurrentAccount currentAccount, final ApiCallback<CurrentAccount> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = currentAccountsPostValidateBeforeCall(currentAccount, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<CurrentAccount>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
