

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import io.swagger.client.model.MaillistGroup;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MaillistGroupApi {
    private ApiClient apiClient;

    public MaillistGroupApi() {
        this(Configuration.getDefaultApiClient());
    }

    public MaillistGroupApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for maillistGroupsGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Mail Listesi Grubu adı (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call maillistGroupsGetCall(String sort, Integer limit, Integer page, Integer sinceId, String name, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/maillist_groups";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (name != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("name", name));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call maillistGroupsGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, String name, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = maillistGroupsGetCall(sort, limit, page, sinceId, name, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Mail Listesi Grubu Listesi Alma
     * Mail Listesi Grubu listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Mail Listesi Grubu adı (optional)
     * @return MaillistGroup
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public MaillistGroup maillistGroupsGet(String sort, Integer limit, Integer page, Integer sinceId, String name) throws ApiException {
        ApiResponse<MaillistGroup> resp = maillistGroupsGetWithHttpInfo(sort, limit, page, sinceId, name);
        return resp.getData();
    }

    /**
     * Mail Listesi Grubu Listesi Alma
     * Mail Listesi Grubu listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Mail Listesi Grubu adı (optional)
     * @return ApiResponse&lt;MaillistGroup&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<MaillistGroup> maillistGroupsGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, String name) throws ApiException {
        com.squareup.okhttp.Call call = maillistGroupsGetValidateBeforeCall(sort, limit, page, sinceId, name, null, null);
        Type localVarReturnType = new TypeToken<MaillistGroup>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Mail Listesi Grubu Listesi Alma (asynchronously)
     * Mail Listesi Grubu listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param name Mail Listesi Grubu adı (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call maillistGroupsGetAsync(String sort, Integer limit, Integer page, Integer sinceId, String name, final ApiCallback<MaillistGroup> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = maillistGroupsGetValidateBeforeCall(sort, limit, page, sinceId, name, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<MaillistGroup>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for maillistGroupsIdDelete
     * @param id Mail Listesi Grubu nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call maillistGroupsIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/maillist_groups/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call maillistGroupsIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling maillistGroupsIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = maillistGroupsIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Mail Listesi Grubu Silme
     * Kalıcı olarak ilgili Mail Listesi Grubunu siler.
     * @param id Mail Listesi Grubu nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void maillistGroupsIdDelete(Integer id) throws ApiException {
        maillistGroupsIdDeleteWithHttpInfo(id);
    }

    /**
     * Mail Listesi Grubu Silme
     * Kalıcı olarak ilgili Mail Listesi Grubunu siler.
     * @param id Mail Listesi Grubu nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> maillistGroupsIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = maillistGroupsIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Mail Listesi Grubu Silme (asynchronously)
     * Kalıcı olarak ilgili Mail Listesi Grubunu siler.
     * @param id Mail Listesi Grubu nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call maillistGroupsIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = maillistGroupsIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for maillistGroupsIdGet
     * @param id Mail Listesi Grubu nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call maillistGroupsIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/maillist_groups/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call maillistGroupsIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling maillistGroupsIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = maillistGroupsIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Mail Listesi Grubu Alma
     * İlgili Mail Listesi Grubunu getirir.
     * @param id Mail Listesi Grubu nesnesinin id değeri (required)
     * @return MaillistGroup
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public MaillistGroup maillistGroupsIdGet(Integer id) throws ApiException {
        ApiResponse<MaillistGroup> resp = maillistGroupsIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Mail Listesi Grubu Alma
     * İlgili Mail Listesi Grubunu getirir.
     * @param id Mail Listesi Grubu nesnesinin id değeri (required)
     * @return ApiResponse&lt;MaillistGroup&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<MaillistGroup> maillistGroupsIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = maillistGroupsIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<MaillistGroup>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Mail Listesi Grubu Alma (asynchronously)
     * İlgili Mail Listesi Grubunu getirir.
     * @param id Mail Listesi Grubu nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call maillistGroupsIdGetAsync(Integer id, final ApiCallback<MaillistGroup> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = maillistGroupsIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<MaillistGroup>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for maillistGroupsIdPut
     * @param id Mail Listesi Grubu nesnesinin id değeri (required)
     * @param maillistGroup MaillistGroup nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call maillistGroupsIdPutCall(Integer id, MaillistGroup maillistGroup, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = maillistGroup;

        // create path and map variables
        String localVarPath = "/maillist_groups/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call maillistGroupsIdPutValidateBeforeCall(Integer id, MaillistGroup maillistGroup, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling maillistGroupsIdPut(Async)");
        }
        
        // verify the required parameter 'maillistGroup' is set
        if (maillistGroup == null) {
            throw new ApiException("Missing the required parameter 'maillistGroup' when calling maillistGroupsIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = maillistGroupsIdPutCall(id, maillistGroup, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Mail Listesi Grubu Güncelleme
     * İlgili Mail Listesi Grubunu günceller.
     * @param id Mail Listesi Grubu nesnesinin id değeri (required)
     * @param maillistGroup MaillistGroup nesnesi (required)
     * @return MaillistGroup
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public MaillistGroup maillistGroupsIdPut(Integer id, MaillistGroup maillistGroup) throws ApiException {
        ApiResponse<MaillistGroup> resp = maillistGroupsIdPutWithHttpInfo(id, maillistGroup);
        return resp.getData();
    }

    /**
     * Mail Listesi Grubu Güncelleme
     * İlgili Mail Listesi Grubunu günceller.
     * @param id Mail Listesi Grubu nesnesinin id değeri (required)
     * @param maillistGroup MaillistGroup nesnesi (required)
     * @return ApiResponse&lt;MaillistGroup&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<MaillistGroup> maillistGroupsIdPutWithHttpInfo(Integer id, MaillistGroup maillistGroup) throws ApiException {
        com.squareup.okhttp.Call call = maillistGroupsIdPutValidateBeforeCall(id, maillistGroup, null, null);
        Type localVarReturnType = new TypeToken<MaillistGroup>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Mail Listesi Grubu Güncelleme (asynchronously)
     * İlgili Mail Listesi Grubunu günceller.
     * @param id Mail Listesi Grubu nesnesinin id değeri (required)
     * @param maillistGroup MaillistGroup nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call maillistGroupsIdPutAsync(Integer id, MaillistGroup maillistGroup, final ApiCallback<MaillistGroup> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = maillistGroupsIdPutValidateBeforeCall(id, maillistGroup, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<MaillistGroup>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for maillistGroupsPost
     * @param maillistGroup MaillistGroup nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call maillistGroupsPostCall(MaillistGroup maillistGroup, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = maillistGroup;

        // create path and map variables
        String localVarPath = "/maillist_groups";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call maillistGroupsPostValidateBeforeCall(MaillistGroup maillistGroup, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'maillistGroup' is set
        if (maillistGroup == null) {
            throw new ApiException("Missing the required parameter 'maillistGroup' when calling maillistGroupsPost(Async)");
        }
        

        com.squareup.okhttp.Call call = maillistGroupsPostCall(maillistGroup, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Mail Listesi Grubu Oluşturma
     * Yeni bir Mail Listesi Grubu oluşturur.
     * @param maillistGroup MaillistGroup nesnesi (required)
     * @return MaillistGroup
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public MaillistGroup maillistGroupsPost(MaillistGroup maillistGroup) throws ApiException {
        ApiResponse<MaillistGroup> resp = maillistGroupsPostWithHttpInfo(maillistGroup);
        return resp.getData();
    }

    /**
     * Mail Listesi Grubu Oluşturma
     * Yeni bir Mail Listesi Grubu oluşturur.
     * @param maillistGroup MaillistGroup nesnesi (required)
     * @return ApiResponse&lt;MaillistGroup&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<MaillistGroup> maillistGroupsPostWithHttpInfo(MaillistGroup maillistGroup) throws ApiException {
        com.squareup.okhttp.Call call = maillistGroupsPostValidateBeforeCall(maillistGroup, null, null);
        Type localVarReturnType = new TypeToken<MaillistGroup>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Mail Listesi Grubu Oluşturma (asynchronously)
     * Yeni bir Mail Listesi Grubu oluşturur.
     * @param maillistGroup MaillistGroup nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call maillistGroupsPostAsync(MaillistGroup maillistGroup, final ApiCallback<MaillistGroup> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = maillistGroupsPostValidateBeforeCall(maillistGroup, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<MaillistGroup>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
