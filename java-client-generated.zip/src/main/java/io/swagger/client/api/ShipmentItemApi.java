

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.ShipmentItem;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShipmentItemApi {
    private ApiClient apiClient;

    public ShipmentItemApi() {
        this(Configuration.getDefaultApiClient());
    }

    public ShipmentItemApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for shipmentItemsGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param shipment Teslimat id (optional)
     * @param orderItem Sipariş kalemi id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call shipmentItemsGetCall(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer shipment, Integer orderItem, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/shipment_items";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (product != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("product", product));
        if (shipment != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("shipment", shipment));
        if (orderItem != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("orderItem", orderItem));
        if (startDate != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("startDate", startDate));
        if (endDate != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("endDate", endDate));
        if (startUpdatedAt != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("startUpdatedAt", startUpdatedAt));
        if (endUpdatedAt != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("endUpdatedAt", endUpdatedAt));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call shipmentItemsGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer shipment, Integer orderItem, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = shipmentItemsGetCall(sort, limit, page, sinceId, product, shipment, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Teslimat Kalemi Listesi Alma
     * Teslimat Kalemi listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param shipment Teslimat id (optional)
     * @param orderItem Sipariş kalemi id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @return ShipmentItem
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ShipmentItem shipmentItemsGet(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer shipment, Integer orderItem, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt) throws ApiException {
        ApiResponse<ShipmentItem> resp = shipmentItemsGetWithHttpInfo(sort, limit, page, sinceId, product, shipment, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt);
        return resp.getData();
    }

    /**
     * Teslimat Kalemi Listesi Alma
     * Teslimat Kalemi listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param shipment Teslimat id (optional)
     * @param orderItem Sipariş kalemi id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @return ApiResponse&lt;ShipmentItem&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ShipmentItem> shipmentItemsGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer shipment, Integer orderItem, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt) throws ApiException {
        com.squareup.okhttp.Call call = shipmentItemsGetValidateBeforeCall(sort, limit, page, sinceId, product, shipment, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt, null, null);
        Type localVarReturnType = new TypeToken<ShipmentItem>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Teslimat Kalemi Listesi Alma (asynchronously)
     * Teslimat Kalemi listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param shipment Teslimat id (optional)
     * @param orderItem Sipariş kalemi id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call shipmentItemsGetAsync(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer shipment, Integer orderItem, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, final ApiCallback<ShipmentItem> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = shipmentItemsGetValidateBeforeCall(sort, limit, page, sinceId, product, shipment, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ShipmentItem>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for shipmentItemsIdDelete
     * @param id Teslimat Kalemi nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call shipmentItemsIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/shipment_items/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call shipmentItemsIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling shipmentItemsIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = shipmentItemsIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Teslimat Kalemi Silme
     * Kalıcı olarak ilgili Teslimat Kalemini siler.
     * @param id Teslimat Kalemi nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void shipmentItemsIdDelete(Integer id) throws ApiException {
        shipmentItemsIdDeleteWithHttpInfo(id);
    }

    /**
     * Teslimat Kalemi Silme
     * Kalıcı olarak ilgili Teslimat Kalemini siler.
     * @param id Teslimat Kalemi nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> shipmentItemsIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = shipmentItemsIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Teslimat Kalemi Silme (asynchronously)
     * Kalıcı olarak ilgili Teslimat Kalemini siler.
     * @param id Teslimat Kalemi nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call shipmentItemsIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = shipmentItemsIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for shipmentItemsIdGet
     * @param id Teslimat Kalemi nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call shipmentItemsIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/shipment_items/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call shipmentItemsIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling shipmentItemsIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = shipmentItemsIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Teslimat Kalemi Alma
     * İlgili Teslimat Kalemini getirir.
     * @param id Teslimat Kalemi nesnesinin id değeri (required)
     * @return ShipmentItem
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ShipmentItem shipmentItemsIdGet(Integer id) throws ApiException {
        ApiResponse<ShipmentItem> resp = shipmentItemsIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Teslimat Kalemi Alma
     * İlgili Teslimat Kalemini getirir.
     * @param id Teslimat Kalemi nesnesinin id değeri (required)
     * @return ApiResponse&lt;ShipmentItem&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ShipmentItem> shipmentItemsIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = shipmentItemsIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<ShipmentItem>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Teslimat Kalemi Alma (asynchronously)
     * İlgili Teslimat Kalemini getirir.
     * @param id Teslimat Kalemi nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call shipmentItemsIdGetAsync(Integer id, final ApiCallback<ShipmentItem> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = shipmentItemsIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ShipmentItem>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for shipmentItemsIdPut
     * @param id Teslimat Kalemi nesnesinin id değeri (required)
     * @param shipmentItem ShipmentItem nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call shipmentItemsIdPutCall(Integer id, ShipmentItem shipmentItem, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = shipmentItem;

        // create path and map variables
        String localVarPath = "/shipment_items/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call shipmentItemsIdPutValidateBeforeCall(Integer id, ShipmentItem shipmentItem, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling shipmentItemsIdPut(Async)");
        }
        
        // verify the required parameter 'shipmentItem' is set
        if (shipmentItem == null) {
            throw new ApiException("Missing the required parameter 'shipmentItem' when calling shipmentItemsIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = shipmentItemsIdPutCall(id, shipmentItem, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Teslimat Kalemi Güncelleme
     * İlgili Teslimat Kalemini günceller.
     * @param id Teslimat Kalemi nesnesinin id değeri (required)
     * @param shipmentItem ShipmentItem nesnesi (required)
     * @return ShipmentItem
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ShipmentItem shipmentItemsIdPut(Integer id, ShipmentItem shipmentItem) throws ApiException {
        ApiResponse<ShipmentItem> resp = shipmentItemsIdPutWithHttpInfo(id, shipmentItem);
        return resp.getData();
    }

    /**
     * Teslimat Kalemi Güncelleme
     * İlgili Teslimat Kalemini günceller.
     * @param id Teslimat Kalemi nesnesinin id değeri (required)
     * @param shipmentItem ShipmentItem nesnesi (required)
     * @return ApiResponse&lt;ShipmentItem&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ShipmentItem> shipmentItemsIdPutWithHttpInfo(Integer id, ShipmentItem shipmentItem) throws ApiException {
        com.squareup.okhttp.Call call = shipmentItemsIdPutValidateBeforeCall(id, shipmentItem, null, null);
        Type localVarReturnType = new TypeToken<ShipmentItem>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Teslimat Kalemi Güncelleme (asynchronously)
     * İlgili Teslimat Kalemini günceller.
     * @param id Teslimat Kalemi nesnesinin id değeri (required)
     * @param shipmentItem ShipmentItem nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call shipmentItemsIdPutAsync(Integer id, ShipmentItem shipmentItem, final ApiCallback<ShipmentItem> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = shipmentItemsIdPutValidateBeforeCall(id, shipmentItem, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ShipmentItem>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for shipmentItemsPost
     * @param shipmentItem ShipmentItem nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call shipmentItemsPostCall(ShipmentItem shipmentItem, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = shipmentItem;

        // create path and map variables
        String localVarPath = "/shipment_items";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call shipmentItemsPostValidateBeforeCall(ShipmentItem shipmentItem, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'shipmentItem' is set
        if (shipmentItem == null) {
            throw new ApiException("Missing the required parameter 'shipmentItem' when calling shipmentItemsPost(Async)");
        }
        

        com.squareup.okhttp.Call call = shipmentItemsPostCall(shipmentItem, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Teslimat Kalemi Oluşturma
     * Yeni bir Teslimat Kalemi oluşturur.
     * @param shipmentItem ShipmentItem nesnesi (required)
     * @return ShipmentItem
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ShipmentItem shipmentItemsPost(ShipmentItem shipmentItem) throws ApiException {
        ApiResponse<ShipmentItem> resp = shipmentItemsPostWithHttpInfo(shipmentItem);
        return resp.getData();
    }

    /**
     * Teslimat Kalemi Oluşturma
     * Yeni bir Teslimat Kalemi oluşturur.
     * @param shipmentItem ShipmentItem nesnesi (required)
     * @return ApiResponse&lt;ShipmentItem&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ShipmentItem> shipmentItemsPostWithHttpInfo(ShipmentItem shipmentItem) throws ApiException {
        com.squareup.okhttp.Call call = shipmentItemsPostValidateBeforeCall(shipmentItem, null, null);
        Type localVarReturnType = new TypeToken<ShipmentItem>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Teslimat Kalemi Oluşturma (asynchronously)
     * Yeni bir Teslimat Kalemi oluşturur.
     * @param shipmentItem ShipmentItem nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call shipmentItemsPostAsync(ShipmentItem shipmentItem, final ApiCallback<ShipmentItem> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = shipmentItemsPostValidateBeforeCall(shipmentItem, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ShipmentItem>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
