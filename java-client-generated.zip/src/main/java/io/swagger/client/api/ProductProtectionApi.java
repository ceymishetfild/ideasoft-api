

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import io.swagger.client.model.ProductProtection;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductProtectionApi {
    private ApiClient apiClient;

    public ProductProtectionApi() {
        this(Configuration.getDefaultApiClient());
    }

    public ProductProtectionApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for productProtectionsGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param isPriceProtected Fiyat korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param isStockProtected Stok korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param product Ürün id (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call productProtectionsGetCall(String sort, Integer limit, Integer page, Integer sinceId, Integer isPriceProtected, Integer isStockProtected, Integer product, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/product_protections";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (isPriceProtected != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("isPriceProtected", isPriceProtected));
        if (isStockProtected != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("isStockProtected", isStockProtected));
        if (product != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("product", product));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call productProtectionsGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, Integer isPriceProtected, Integer isStockProtected, Integer product, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = productProtectionsGetCall(sort, limit, page, sinceId, isPriceProtected, isStockProtected, product, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Entegrasyon Seçeneği Listesi Alma
     * Entegrasyon Seçeneği listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param isPriceProtected Fiyat korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param isStockProtected Stok korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param product Ürün id (optional)
     * @return ProductProtection
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ProductProtection productProtectionsGet(String sort, Integer limit, Integer page, Integer sinceId, Integer isPriceProtected, Integer isStockProtected, Integer product) throws ApiException {
        ApiResponse<ProductProtection> resp = productProtectionsGetWithHttpInfo(sort, limit, page, sinceId, isPriceProtected, isStockProtected, product);
        return resp.getData();
    }

    /**
     * Entegrasyon Seçeneği Listesi Alma
     * Entegrasyon Seçeneği listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param isPriceProtected Fiyat korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param isStockProtected Stok korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param product Ürün id (optional)
     * @return ApiResponse&lt;ProductProtection&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ProductProtection> productProtectionsGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, Integer isPriceProtected, Integer isStockProtected, Integer product) throws ApiException {
        com.squareup.okhttp.Call call = productProtectionsGetValidateBeforeCall(sort, limit, page, sinceId, isPriceProtected, isStockProtected, product, null, null);
        Type localVarReturnType = new TypeToken<ProductProtection>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Entegrasyon Seçeneği Listesi Alma (asynchronously)
     * Entegrasyon Seçeneği listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param isPriceProtected Fiyat korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param isStockProtected Stok korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; (optional)
     * @param product Ürün id (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call productProtectionsGetAsync(String sort, Integer limit, Integer page, Integer sinceId, Integer isPriceProtected, Integer isStockProtected, Integer product, final ApiCallback<ProductProtection> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = productProtectionsGetValidateBeforeCall(sort, limit, page, sinceId, isPriceProtected, isStockProtected, product, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ProductProtection>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for productProtectionsIdDelete
     * @param id Entegrasyon Seçeneği nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call productProtectionsIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/product_protections/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call productProtectionsIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling productProtectionsIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = productProtectionsIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Entegrasyon Seçeneği Silme
     * Kalıcı olarak ilgili Entegrasyon Seçeneğini siler.
     * @param id Entegrasyon Seçeneği nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void productProtectionsIdDelete(Integer id) throws ApiException {
        productProtectionsIdDeleteWithHttpInfo(id);
    }

    /**
     * Entegrasyon Seçeneği Silme
     * Kalıcı olarak ilgili Entegrasyon Seçeneğini siler.
     * @param id Entegrasyon Seçeneği nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> productProtectionsIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = productProtectionsIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Entegrasyon Seçeneği Silme (asynchronously)
     * Kalıcı olarak ilgili Entegrasyon Seçeneğini siler.
     * @param id Entegrasyon Seçeneği nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call productProtectionsIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = productProtectionsIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for productProtectionsIdGet
     * @param id Entegrasyon Seçeneği nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call productProtectionsIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/product_protections/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call productProtectionsIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling productProtectionsIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = productProtectionsIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Entegrasyon Seçeneği Alma
     * İlgili Entegrasyon Seçeneğini getirir.
     * @param id Entegrasyon Seçeneği nesnesinin id değeri (required)
     * @return ProductProtection
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ProductProtection productProtectionsIdGet(Integer id) throws ApiException {
        ApiResponse<ProductProtection> resp = productProtectionsIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Entegrasyon Seçeneği Alma
     * İlgili Entegrasyon Seçeneğini getirir.
     * @param id Entegrasyon Seçeneği nesnesinin id değeri (required)
     * @return ApiResponse&lt;ProductProtection&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ProductProtection> productProtectionsIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = productProtectionsIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<ProductProtection>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Entegrasyon Seçeneği Alma (asynchronously)
     * İlgili Entegrasyon Seçeneğini getirir.
     * @param id Entegrasyon Seçeneği nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call productProtectionsIdGetAsync(Integer id, final ApiCallback<ProductProtection> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = productProtectionsIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ProductProtection>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for productProtectionsIdPut
     * @param id Entegrasyon Seçeneği nesnesinin id değeri (required)
     * @param productProtection ProductProtection nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call productProtectionsIdPutCall(Integer id, ProductProtection productProtection, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = productProtection;

        // create path and map variables
        String localVarPath = "/product_protections/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call productProtectionsIdPutValidateBeforeCall(Integer id, ProductProtection productProtection, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling productProtectionsIdPut(Async)");
        }
        
        // verify the required parameter 'productProtection' is set
        if (productProtection == null) {
            throw new ApiException("Missing the required parameter 'productProtection' when calling productProtectionsIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = productProtectionsIdPutCall(id, productProtection, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Entegrasyon Seçeneği Güncelleme
     * İlgili Entegrasyon Seçeneğini günceller.
     * @param id Entegrasyon Seçeneği nesnesinin id değeri (required)
     * @param productProtection ProductProtection nesnesi (required)
     * @return ProductProtection
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ProductProtection productProtectionsIdPut(Integer id, ProductProtection productProtection) throws ApiException {
        ApiResponse<ProductProtection> resp = productProtectionsIdPutWithHttpInfo(id, productProtection);
        return resp.getData();
    }

    /**
     * Entegrasyon Seçeneği Güncelleme
     * İlgili Entegrasyon Seçeneğini günceller.
     * @param id Entegrasyon Seçeneği nesnesinin id değeri (required)
     * @param productProtection ProductProtection nesnesi (required)
     * @return ApiResponse&lt;ProductProtection&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ProductProtection> productProtectionsIdPutWithHttpInfo(Integer id, ProductProtection productProtection) throws ApiException {
        com.squareup.okhttp.Call call = productProtectionsIdPutValidateBeforeCall(id, productProtection, null, null);
        Type localVarReturnType = new TypeToken<ProductProtection>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Entegrasyon Seçeneği Güncelleme (asynchronously)
     * İlgili Entegrasyon Seçeneğini günceller.
     * @param id Entegrasyon Seçeneği nesnesinin id değeri (required)
     * @param productProtection ProductProtection nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call productProtectionsIdPutAsync(Integer id, ProductProtection productProtection, final ApiCallback<ProductProtection> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = productProtectionsIdPutValidateBeforeCall(id, productProtection, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ProductProtection>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for productProtectionsPost
     * @param productProtection ProductProtection nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call productProtectionsPostCall(ProductProtection productProtection, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = productProtection;

        // create path and map variables
        String localVarPath = "/product_protections";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call productProtectionsPostValidateBeforeCall(ProductProtection productProtection, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'productProtection' is set
        if (productProtection == null) {
            throw new ApiException("Missing the required parameter 'productProtection' when calling productProtectionsPost(Async)");
        }
        

        com.squareup.okhttp.Call call = productProtectionsPostCall(productProtection, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Entegrasyon Seçeneği Oluşturma
     * Yeni bir Entegrasyon Seçeneği oluşturur.
     * @param productProtection ProductProtection nesnesi (required)
     * @return ProductProtection
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ProductProtection productProtectionsPost(ProductProtection productProtection) throws ApiException {
        ApiResponse<ProductProtection> resp = productProtectionsPostWithHttpInfo(productProtection);
        return resp.getData();
    }

    /**
     * Entegrasyon Seçeneği Oluşturma
     * Yeni bir Entegrasyon Seçeneği oluşturur.
     * @param productProtection ProductProtection nesnesi (required)
     * @return ApiResponse&lt;ProductProtection&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<ProductProtection> productProtectionsPostWithHttpInfo(ProductProtection productProtection) throws ApiException {
        com.squareup.okhttp.Call call = productProtectionsPostValidateBeforeCall(productProtection, null, null);
        Type localVarReturnType = new TypeToken<ProductProtection>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Entegrasyon Seçeneği Oluşturma (asynchronously)
     * Yeni bir Entegrasyon Seçeneği oluşturur.
     * @param productProtection ProductProtection nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call productProtectionsPostAsync(ProductProtection productProtection, final ApiCallback<ProductProtection> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = productProtectionsPostValidateBeforeCall(productProtection, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<ProductProtection>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
