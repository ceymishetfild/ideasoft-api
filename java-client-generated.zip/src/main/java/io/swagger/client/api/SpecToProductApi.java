

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import io.swagger.client.model.SpecToProduct;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SpecToProductApi {
    private ApiClient apiClient;

    public SpecToProductApi() {
        this(Configuration.getDefaultApiClient());
    }

    public SpecToProductApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for specToProductsGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param specGroup Ürün özellik grubu id (optional)
     * @param specName Ürün özellik id (optional)
     * @param specValue Ürün özellik değeri id (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call specToProductsGetCall(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer specGroup, Integer specName, Integer specValue, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/spec_to_products";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (product != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("product", product));
        if (specGroup != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("specGroup", specGroup));
        if (specName != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("specName", specName));
        if (specValue != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("specValue", specValue));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call specToProductsGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer specGroup, Integer specName, Integer specValue, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = specToProductsGetCall(sort, limit, page, sinceId, product, specGroup, specName, specValue, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün Özellik Ürün Bağı Listesi Alma
     * Ürün Özellik Ürün Bağı listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param specGroup Ürün özellik grubu id (optional)
     * @param specName Ürün özellik id (optional)
     * @param specValue Ürün özellik değeri id (optional)
     * @return SpecToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SpecToProduct specToProductsGet(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer specGroup, Integer specName, Integer specValue) throws ApiException {
        ApiResponse<SpecToProduct> resp = specToProductsGetWithHttpInfo(sort, limit, page, sinceId, product, specGroup, specName, specValue);
        return resp.getData();
    }

    /**
     * Ürün Özellik Ürün Bağı Listesi Alma
     * Ürün Özellik Ürün Bağı listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param specGroup Ürün özellik grubu id (optional)
     * @param specName Ürün özellik id (optional)
     * @param specValue Ürün özellik değeri id (optional)
     * @return ApiResponse&lt;SpecToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SpecToProduct> specToProductsGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer specGroup, Integer specName, Integer specValue) throws ApiException {
        com.squareup.okhttp.Call call = specToProductsGetValidateBeforeCall(sort, limit, page, sinceId, product, specGroup, specName, specValue, null, null);
        Type localVarReturnType = new TypeToken<SpecToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün Özellik Ürün Bağı Listesi Alma (asynchronously)
     * Ürün Özellik Ürün Bağı listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param product Ürün id (optional)
     * @param specGroup Ürün özellik grubu id (optional)
     * @param specName Ürün özellik id (optional)
     * @param specValue Ürün özellik değeri id (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call specToProductsGetAsync(String sort, Integer limit, Integer page, Integer sinceId, Integer product, Integer specGroup, Integer specName, Integer specValue, final ApiCallback<SpecToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = specToProductsGetValidateBeforeCall(sort, limit, page, sinceId, product, specGroup, specName, specValue, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SpecToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for specToProductsIdDelete
     * @param id Ürün Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call specToProductsIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/spec_to_products/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call specToProductsIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling specToProductsIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = specToProductsIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün Özellik Ürün Bağı Silme
     * Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler.
     * @param id Ürün Özellik Ürün Bağı nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void specToProductsIdDelete(Integer id) throws ApiException {
        specToProductsIdDeleteWithHttpInfo(id);
    }

    /**
     * Ürün Özellik Ürün Bağı Silme
     * Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler.
     * @param id Ürün Özellik Ürün Bağı nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> specToProductsIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = specToProductsIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Ürün Özellik Ürün Bağı Silme (asynchronously)
     * Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler.
     * @param id Ürün Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call specToProductsIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = specToProductsIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for specToProductsIdGet
     * @param id Ürün Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call specToProductsIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/spec_to_products/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call specToProductsIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling specToProductsIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = specToProductsIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün Özellik Ürün Bağı Alma
     * İlgili Ürün Özellik Ürün Bağını getirir.
     * @param id Ürün Özellik Ürün Bağı nesnesinin id değeri (required)
     * @return SpecToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SpecToProduct specToProductsIdGet(Integer id) throws ApiException {
        ApiResponse<SpecToProduct> resp = specToProductsIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Ürün Özellik Ürün Bağı Alma
     * İlgili Ürün Özellik Ürün Bağını getirir.
     * @param id Ürün Özellik Ürün Bağı nesnesinin id değeri (required)
     * @return ApiResponse&lt;SpecToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SpecToProduct> specToProductsIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = specToProductsIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<SpecToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün Özellik Ürün Bağı Alma (asynchronously)
     * İlgili Ürün Özellik Ürün Bağını getirir.
     * @param id Ürün Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call specToProductsIdGetAsync(Integer id, final ApiCallback<SpecToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = specToProductsIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SpecToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for specToProductsIdPut
     * @param id Ürün Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param specToProduct SpecToProduct nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call specToProductsIdPutCall(Integer id, SpecToProduct specToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = specToProduct;

        // create path and map variables
        String localVarPath = "/spec_to_products/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call specToProductsIdPutValidateBeforeCall(Integer id, SpecToProduct specToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling specToProductsIdPut(Async)");
        }
        
        // verify the required parameter 'specToProduct' is set
        if (specToProduct == null) {
            throw new ApiException("Missing the required parameter 'specToProduct' when calling specToProductsIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = specToProductsIdPutCall(id, specToProduct, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün Özellik Ürün Bağı Güncelleme
     * İlgili Ürün Özellik Ürün Bağını günceller.
     * @param id Ürün Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param specToProduct SpecToProduct nesnesi (required)
     * @return SpecToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SpecToProduct specToProductsIdPut(Integer id, SpecToProduct specToProduct) throws ApiException {
        ApiResponse<SpecToProduct> resp = specToProductsIdPutWithHttpInfo(id, specToProduct);
        return resp.getData();
    }

    /**
     * Ürün Özellik Ürün Bağı Güncelleme
     * İlgili Ürün Özellik Ürün Bağını günceller.
     * @param id Ürün Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param specToProduct SpecToProduct nesnesi (required)
     * @return ApiResponse&lt;SpecToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SpecToProduct> specToProductsIdPutWithHttpInfo(Integer id, SpecToProduct specToProduct) throws ApiException {
        com.squareup.okhttp.Call call = specToProductsIdPutValidateBeforeCall(id, specToProduct, null, null);
        Type localVarReturnType = new TypeToken<SpecToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün Özellik Ürün Bağı Güncelleme (asynchronously)
     * İlgili Ürün Özellik Ürün Bağını günceller.
     * @param id Ürün Özellik Ürün Bağı nesnesinin id değeri (required)
     * @param specToProduct SpecToProduct nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call specToProductsIdPutAsync(Integer id, SpecToProduct specToProduct, final ApiCallback<SpecToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = specToProductsIdPutValidateBeforeCall(id, specToProduct, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SpecToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for specToProductsPost
     * @param specToProduct SpecToProduct nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call specToProductsPostCall(SpecToProduct specToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = specToProduct;

        // create path and map variables
        String localVarPath = "/spec_to_products";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call specToProductsPostValidateBeforeCall(SpecToProduct specToProduct, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'specToProduct' is set
        if (specToProduct == null) {
            throw new ApiException("Missing the required parameter 'specToProduct' when calling specToProductsPost(Async)");
        }
        

        com.squareup.okhttp.Call call = specToProductsPostCall(specToProduct, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Ürün Özellik Ürün Bağı Oluşturma
     * Yeni bir Ürün Özellik Ürün Bağı oluşturur.
     * @param specToProduct SpecToProduct nesnesi (required)
     * @return SpecToProduct
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public SpecToProduct specToProductsPost(SpecToProduct specToProduct) throws ApiException {
        ApiResponse<SpecToProduct> resp = specToProductsPostWithHttpInfo(specToProduct);
        return resp.getData();
    }

    /**
     * Ürün Özellik Ürün Bağı Oluşturma
     * Yeni bir Ürün Özellik Ürün Bağı oluşturur.
     * @param specToProduct SpecToProduct nesnesi (required)
     * @return ApiResponse&lt;SpecToProduct&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<SpecToProduct> specToProductsPostWithHttpInfo(SpecToProduct specToProduct) throws ApiException {
        com.squareup.okhttp.Call call = specToProductsPostValidateBeforeCall(specToProduct, null, null);
        Type localVarReturnType = new TypeToken<SpecToProduct>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Ürün Özellik Ürün Bağı Oluşturma (asynchronously)
     * Yeni bir Ürün Özellik Ürün Bağı oluşturur.
     * @param specToProduct SpecToProduct nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call specToProductsPostAsync(SpecToProduct specToProduct, final ApiCallback<SpecToProduct> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = specToProductsPostValidateBeforeCall(specToProduct, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<SpecToProduct>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
