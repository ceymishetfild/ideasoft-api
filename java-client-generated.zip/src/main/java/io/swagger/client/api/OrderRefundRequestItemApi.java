

package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;


import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.OrderRefundRequestItem;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderRefundRequestItemApi {
    private ApiClient apiClient;

    public OrderRefundRequestItemApi() {
        this(Configuration.getDefaultApiClient());
    }

    public OrderRefundRequestItemApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * Build call for orderRefundRequestItemsGet
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param orderRefundRequest Sipariş iptal talebi id (optional)
     * @param orderItem Sipariş ürünü id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call orderRefundRequestItemsGetCall(String sort, Integer limit, Integer page, Integer sinceId, Integer orderRefundRequest, Integer orderItem, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/order_refund_request_items";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();
        if (sort != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sort", sort));
        if (limit != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("limit", limit));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("page", page));
        if (sinceId != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("sinceId", sinceId));
        if (orderRefundRequest != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("orderRefundRequest", orderRefundRequest));
        if (orderItem != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("orderItem", orderItem));
        if (startDate != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("startDate", startDate));
        if (endDate != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("endDate", endDate));
        if (startUpdatedAt != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("startUpdatedAt", startUpdatedAt));
        if (endUpdatedAt != null)
        localVarQueryParams.addAll(apiClient.parameterToPair("endUpdatedAt", endUpdatedAt));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call orderRefundRequestItemsGetValidateBeforeCall(String sort, Integer limit, Integer page, Integer sinceId, Integer orderRefundRequest, Integer orderItem, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        

        com.squareup.okhttp.Call call = orderRefundRequestItemsGetCall(sort, limit, page, sinceId, orderRefundRequest, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Sipariş İptal Talebi Kalemi Listesi Alma
     * Sipariş İptal Talebi Kalemi listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param orderRefundRequest Sipariş iptal talebi id (optional)
     * @param orderItem Sipariş ürünü id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @return OrderRefundRequestItem
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public OrderRefundRequestItem orderRefundRequestItemsGet(String sort, Integer limit, Integer page, Integer sinceId, Integer orderRefundRequest, Integer orderItem, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt) throws ApiException {
        ApiResponse<OrderRefundRequestItem> resp = orderRefundRequestItemsGetWithHttpInfo(sort, limit, page, sinceId, orderRefundRequest, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt);
        return resp.getData();
    }

    /**
     * Sipariş İptal Talebi Kalemi Listesi Alma
     * Sipariş İptal Talebi Kalemi listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param orderRefundRequest Sipariş iptal talebi id (optional)
     * @param orderItem Sipariş ürünü id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @return ApiResponse&lt;OrderRefundRequestItem&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<OrderRefundRequestItem> orderRefundRequestItemsGetWithHttpInfo(String sort, Integer limit, Integer page, Integer sinceId, Integer orderRefundRequest, Integer orderItem, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt) throws ApiException {
        com.squareup.okhttp.Call call = orderRefundRequestItemsGetValidateBeforeCall(sort, limit, page, sinceId, orderRefundRequest, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt, null, null);
        Type localVarReturnType = new TypeToken<OrderRefundRequestItem>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Sipariş İptal Talebi Kalemi Listesi Alma (asynchronously)
     * Sipariş İptal Talebi Kalemi listesini verir.
     * @param sort Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  (optional)
     * @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
     * @param page Hangi sayfadan başlanacağı (optional, default to 1)
     * @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
     * @param orderRefundRequest Sipariş iptal talebi id (optional)
     * @param orderItem Sipariş ürünü id (optional)
     * @param startDate createdAt değeri için başlangıç tarihi (optional)
     * @param endDate createdAt değeri için bitiş tarihi (optional)
     * @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
     * @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call orderRefundRequestItemsGetAsync(String sort, Integer limit, Integer page, Integer sinceId, Integer orderRefundRequest, Integer orderItem, LocalDate startDate, String endDate, LocalDate startUpdatedAt, String endUpdatedAt, final ApiCallback<OrderRefundRequestItem> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = orderRefundRequestItemsGetValidateBeforeCall(sort, limit, page, sinceId, orderRefundRequest, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<OrderRefundRequestItem>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for orderRefundRequestItemsIdDelete
     * @param id Sipariş İptal Talebi Kalemi nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call orderRefundRequestItemsIdDeleteCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/order_refund_request_items/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "DELETE", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call orderRefundRequestItemsIdDeleteValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling orderRefundRequestItemsIdDelete(Async)");
        }
        

        com.squareup.okhttp.Call call = orderRefundRequestItemsIdDeleteCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Sipariş İptal Talebi Kalemi Silme
     * Kalıcı olarak ilgili Sipariş İptal Talebi Kalemini siler.
     * @param id Sipariş İptal Talebi Kalemi nesnesinin id değeri (required)
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public void orderRefundRequestItemsIdDelete(Integer id) throws ApiException {
        orderRefundRequestItemsIdDeleteWithHttpInfo(id);
    }

    /**
     * Sipariş İptal Talebi Kalemi Silme
     * Kalıcı olarak ilgili Sipariş İptal Talebi Kalemini siler.
     * @param id Sipariş İptal Talebi Kalemi nesnesinin id değeri (required)
     * @return ApiResponse&lt;Void&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<Void> orderRefundRequestItemsIdDeleteWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = orderRefundRequestItemsIdDeleteValidateBeforeCall(id, null, null);
        return apiClient.execute(call);
    }

    /**
     * Sipariş İptal Talebi Kalemi Silme (asynchronously)
     * Kalıcı olarak ilgili Sipariş İptal Talebi Kalemini siler.
     * @param id Sipariş İptal Talebi Kalemi nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call orderRefundRequestItemsIdDeleteAsync(Integer id, final ApiCallback<Void> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = orderRefundRequestItemsIdDeleteValidateBeforeCall(id, progressListener, progressRequestListener);
        apiClient.executeAsync(call, callback);
        return call;
    }
    /**
     * Build call for orderRefundRequestItemsIdGet
     * @param id Sipariş İptal Talebi Kalemi nesnesinin id değeri (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call orderRefundRequestItemsIdGetCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;

        // create path and map variables
        String localVarPath = "/order_refund_request_items/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call orderRefundRequestItemsIdGetValidateBeforeCall(Integer id, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling orderRefundRequestItemsIdGet(Async)");
        }
        

        com.squareup.okhttp.Call call = orderRefundRequestItemsIdGetCall(id, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Sipariş İptal Talebi Kalemi Alma
     * İlgili Sipariş İptal Talebi Kalemini getirir.
     * @param id Sipariş İptal Talebi Kalemi nesnesinin id değeri (required)
     * @return OrderRefundRequestItem
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public OrderRefundRequestItem orderRefundRequestItemsIdGet(Integer id) throws ApiException {
        ApiResponse<OrderRefundRequestItem> resp = orderRefundRequestItemsIdGetWithHttpInfo(id);
        return resp.getData();
    }

    /**
     * Sipariş İptal Talebi Kalemi Alma
     * İlgili Sipariş İptal Talebi Kalemini getirir.
     * @param id Sipariş İptal Talebi Kalemi nesnesinin id değeri (required)
     * @return ApiResponse&lt;OrderRefundRequestItem&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<OrderRefundRequestItem> orderRefundRequestItemsIdGetWithHttpInfo(Integer id) throws ApiException {
        com.squareup.okhttp.Call call = orderRefundRequestItemsIdGetValidateBeforeCall(id, null, null);
        Type localVarReturnType = new TypeToken<OrderRefundRequestItem>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Sipariş İptal Talebi Kalemi Alma (asynchronously)
     * İlgili Sipariş İptal Talebi Kalemini getirir.
     * @param id Sipariş İptal Talebi Kalemi nesnesinin id değeri (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call orderRefundRequestItemsIdGetAsync(Integer id, final ApiCallback<OrderRefundRequestItem> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = orderRefundRequestItemsIdGetValidateBeforeCall(id, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<OrderRefundRequestItem>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for orderRefundRequestItemsIdPut
     * @param id Sipariş İptal Talebi Kalemi nesnesinin id değeri (required)
     * @param orderRefundRequestItem OrderRefundRequestItem nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call orderRefundRequestItemsIdPutCall(Integer id, OrderRefundRequestItem orderRefundRequestItem, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = orderRefundRequestItem;

        // create path and map variables
        String localVarPath = "/order_refund_request_items/{id}"
            .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "PUT", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call orderRefundRequestItemsIdPutValidateBeforeCall(Integer id, OrderRefundRequestItem orderRefundRequestItem, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'id' is set
        if (id == null) {
            throw new ApiException("Missing the required parameter 'id' when calling orderRefundRequestItemsIdPut(Async)");
        }
        
        // verify the required parameter 'orderRefundRequestItem' is set
        if (orderRefundRequestItem == null) {
            throw new ApiException("Missing the required parameter 'orderRefundRequestItem' when calling orderRefundRequestItemsIdPut(Async)");
        }
        

        com.squareup.okhttp.Call call = orderRefundRequestItemsIdPutCall(id, orderRefundRequestItem, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Sipariş İptal Talebi Kalemi Güncelleme
     * İlgili Sipariş İptal Talebi Kalemini günceller.
     * @param id Sipariş İptal Talebi Kalemi nesnesinin id değeri (required)
     * @param orderRefundRequestItem OrderRefundRequestItem nesnesi (required)
     * @return OrderRefundRequestItem
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public OrderRefundRequestItem orderRefundRequestItemsIdPut(Integer id, OrderRefundRequestItem orderRefundRequestItem) throws ApiException {
        ApiResponse<OrderRefundRequestItem> resp = orderRefundRequestItemsIdPutWithHttpInfo(id, orderRefundRequestItem);
        return resp.getData();
    }

    /**
     * Sipariş İptal Talebi Kalemi Güncelleme
     * İlgili Sipariş İptal Talebi Kalemini günceller.
     * @param id Sipariş İptal Talebi Kalemi nesnesinin id değeri (required)
     * @param orderRefundRequestItem OrderRefundRequestItem nesnesi (required)
     * @return ApiResponse&lt;OrderRefundRequestItem&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<OrderRefundRequestItem> orderRefundRequestItemsIdPutWithHttpInfo(Integer id, OrderRefundRequestItem orderRefundRequestItem) throws ApiException {
        com.squareup.okhttp.Call call = orderRefundRequestItemsIdPutValidateBeforeCall(id, orderRefundRequestItem, null, null);
        Type localVarReturnType = new TypeToken<OrderRefundRequestItem>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Sipariş İptal Talebi Kalemi Güncelleme (asynchronously)
     * İlgili Sipariş İptal Talebi Kalemini günceller.
     * @param id Sipariş İptal Talebi Kalemi nesnesinin id değeri (required)
     * @param orderRefundRequestItem OrderRefundRequestItem nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call orderRefundRequestItemsIdPutAsync(Integer id, OrderRefundRequestItem orderRefundRequestItem, final ApiCallback<OrderRefundRequestItem> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = orderRefundRequestItemsIdPutValidateBeforeCall(id, orderRefundRequestItem, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<OrderRefundRequestItem>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /**
     * Build call for orderRefundRequestItemsPost
     * @param orderRefundRequestItem OrderRefundRequestItem nesnesi (required)
     * @param progressListener Progress listener
     * @param progressRequestListener Progress request listener
     * @return Call to execute
     * @throws ApiException If fail to serialize the request body object
     */
    public com.squareup.okhttp.Call orderRefundRequestItemsPostCall(OrderRefundRequestItem orderRefundRequestItem, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = orderRefundRequestItem;

        // create path and map variables
        String localVarPath = "/order_refund_request_items";

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        List<Pair> localVarCollectionQueryParams = new ArrayList<Pair>();

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "OAuth2" };
        return apiClient.buildCall(localVarPath, "POST", localVarQueryParams, localVarCollectionQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    @SuppressWarnings("rawtypes")
    private com.squareup.okhttp.Call orderRefundRequestItemsPostValidateBeforeCall(OrderRefundRequestItem orderRefundRequestItem, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        
        // verify the required parameter 'orderRefundRequestItem' is set
        if (orderRefundRequestItem == null) {
            throw new ApiException("Missing the required parameter 'orderRefundRequestItem' when calling orderRefundRequestItemsPost(Async)");
        }
        

        com.squareup.okhttp.Call call = orderRefundRequestItemsPostCall(orderRefundRequestItem, progressListener, progressRequestListener);
        return call;

    }

    /**
     * Sipariş İptal Talebi Kalemi Oluşturma
     * Yeni bir Sipariş İptal Talebi Kalemi oluşturur.
     * @param orderRefundRequestItem OrderRefundRequestItem nesnesi (required)
     * @return OrderRefundRequestItem
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public OrderRefundRequestItem orderRefundRequestItemsPost(OrderRefundRequestItem orderRefundRequestItem) throws ApiException {
        ApiResponse<OrderRefundRequestItem> resp = orderRefundRequestItemsPostWithHttpInfo(orderRefundRequestItem);
        return resp.getData();
    }

    /**
     * Sipariş İptal Talebi Kalemi Oluşturma
     * Yeni bir Sipariş İptal Talebi Kalemi oluşturur.
     * @param orderRefundRequestItem OrderRefundRequestItem nesnesi (required)
     * @return ApiResponse&lt;OrderRefundRequestItem&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<OrderRefundRequestItem> orderRefundRequestItemsPostWithHttpInfo(OrderRefundRequestItem orderRefundRequestItem) throws ApiException {
        com.squareup.okhttp.Call call = orderRefundRequestItemsPostValidateBeforeCall(orderRefundRequestItem, null, null);
        Type localVarReturnType = new TypeToken<OrderRefundRequestItem>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     * Sipariş İptal Talebi Kalemi Oluşturma (asynchronously)
     * Yeni bir Sipariş İptal Talebi Kalemi oluşturur.
     * @param orderRefundRequestItem OrderRefundRequestItem nesnesi (required)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call orderRefundRequestItemsPostAsync(OrderRefundRequestItem orderRefundRequestItem, final ApiCallback<OrderRefundRequestItem> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = orderRefundRequestItemsPostValidateBeforeCall(orderRefundRequestItem, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<OrderRefundRequestItem>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
