package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.IOException;

/**
 * Tag
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Tag {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("name")
  private String name = null;

  @SerializedName("count")
  private Integer count = null;

  @SerializedName("pageTitle")
  private String pageTitle = null;

  @SerializedName("metaDescription")
  private String metaDescription = null;

  @SerializedName("metaKeywords")
  private String metaKeywords = null;

  public Tag id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * SEO+ etiketi nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "SEO+ etiketi nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Tag name(String name) {
    this.name = name;
    return this;
  }

   /**
   * SEO+ etiketi nesnesi için isim değeri.
   * @return name
  **/
  @ApiModelProperty(example = "ideasoft", required = true, value = "SEO+ etiketi nesnesi için isim değeri.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Tag count(Integer count) {
    this.count = count;
    return this;
  }

   /**
   * SEO+ etiketinin kaç kez kullanıldığı bilgisi.
   * minimum: 0
   * @return count
  **/
  @ApiModelProperty(example = "2", value = "SEO+ etiketinin kaç kez kullanıldığı bilgisi.")
  public Integer getCount() {
    return count;
  }

  public void setCount(Integer count) {
    this.count = count;
  }

  public Tag pageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
    return this;
  }

   /**
   * SEO+ etiketi nesnesinin etiket başlığı.
   * @return pageTitle
  **/
  @ApiModelProperty(example = "Kırmızı Kalem", value = "SEO+ etiketi nesnesinin etiket başlığı.")
  public String getPageTitle() {
    return pageTitle;
  }

  public void setPageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
  }

  public Tag metaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
    return this;
  }

   /**
   * Arama motorları tarafından tespit edilebilecek açıklama yazısı.
   * @return metaDescription
  **/
  @ApiModelProperty(example = "Kaliteli kırtasiye ürünleri.", value = "Arama motorları tarafından tespit edilebilecek açıklama yazısı.")
  public String getMetaDescription() {
    return metaDescription;
  }

  public void setMetaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
  }

  public Tag metaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
    return this;
  }

   /**
   * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.
   * @return metaKeywords
  **/
  @ApiModelProperty(example = "kırmızı, kalem, kırtasiye", value = "Arama motorları tarafından tespit edilebilecek anahtar kelimeler.")
  public String getMetaKeywords() {
    return metaKeywords;
  }

  public void setMetaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Tag tag = (Tag) o;
    return Objects.equals(this.id, tag.id) &&
        Objects.equals(this.name, tag.name) &&
        Objects.equals(this.count, tag.count) &&
        Objects.equals(this.pageTitle, tag.pageTitle) &&
        Objects.equals(this.metaDescription, tag.metaDescription) &&
        Objects.equals(this.metaKeywords, tag.metaKeywords);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, count, pageTitle, metaDescription, metaKeywords);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Tag {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    count: ").append(toIndentedString(count)).append("\n");
    sb.append("    pageTitle: ").append(toIndentedString(pageTitle)).append("\n");
    sb.append("    metaDescription: ").append(toIndentedString(metaDescription)).append("\n");
    sb.append("    metaKeywords: ").append(toIndentedString(metaKeywords)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

