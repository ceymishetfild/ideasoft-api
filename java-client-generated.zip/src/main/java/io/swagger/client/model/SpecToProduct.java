package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Product;
import io.swagger.client.model.SpecGroup;
import io.swagger.client.model.SpecName;
import io.swagger.client.model.SpecValue;
import java.io.IOException;

/**
 * SpecToProduct
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class SpecToProduct {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("product")
  private Product product = null;

  @SerializedName("specGroup")
  private SpecGroup specGroup = null;

  @SerializedName("specName")
  private SpecName specName = null;

  @SerializedName("specValue")
  private SpecValue specValue = null;

  public SpecToProduct id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Ürün özellik ürün bağı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Ürün özellik ürün bağı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public SpecToProduct product(Product product) {
    this.product = product;
    return this;
  }

   /**
   * Get product
   * @return product
  **/
  @ApiModelProperty(value = "")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public SpecToProduct specGroup(SpecGroup specGroup) {
    this.specGroup = specGroup;
    return this;
  }

   /**
   * Get specGroup
   * @return specGroup
  **/
  @ApiModelProperty(value = "")
  public SpecGroup getSpecGroup() {
    return specGroup;
  }

  public void setSpecGroup(SpecGroup specGroup) {
    this.specGroup = specGroup;
  }

  public SpecToProduct specName(SpecName specName) {
    this.specName = specName;
    return this;
  }

   /**
   * Get specName
   * @return specName
  **/
  @ApiModelProperty(value = "")
  public SpecName getSpecName() {
    return specName;
  }

  public void setSpecName(SpecName specName) {
    this.specName = specName;
  }

  public SpecToProduct specValue(SpecValue specValue) {
    this.specValue = specValue;
    return this;
  }

   /**
   * Get specValue
   * @return specValue
  **/
  @ApiModelProperty(value = "")
  public SpecValue getSpecValue() {
    return specValue;
  }

  public void setSpecValue(SpecValue specValue) {
    this.specValue = specValue;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SpecToProduct specToProduct = (SpecToProduct) o;
    return Objects.equals(this.id, specToProduct.id) &&
        Objects.equals(this.product, specToProduct.product) &&
        Objects.equals(this.specGroup, specToProduct.specGroup) &&
        Objects.equals(this.specName, specToProduct.specName) &&
        Objects.equals(this.specValue, specToProduct.specValue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, product, specGroup, specName, specValue);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SpecToProduct {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("    specGroup: ").append(toIndentedString(specGroup)).append("\n");
    sb.append("    specName: ").append(toIndentedString(specName)).append("\n");
    sb.append("    specValue: ").append(toIndentedString(specValue)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

