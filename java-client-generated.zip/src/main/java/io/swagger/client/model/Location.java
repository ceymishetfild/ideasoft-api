package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Country;
import io.swagger.client.model.Region;
import java.io.IOException;

/**
 * Location
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Location {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("name")
  private String name = null;

  /**
   * Şehir nesnesinin aktiflik durumunu belirten değer.
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    _0("0"),
    
    _1("1");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  /**
   * Şehir nesnesinin öntanımlı olup olmadığını belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Öntanımlı şehir.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yeni eklenmiş şehir.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(PredefinedEnum.Adapter.class)
  public enum PredefinedEnum {
    _0("0"),
    
    _1("1");

    private String value;

    PredefinedEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static PredefinedEnum fromValue(String text) {
      for (PredefinedEnum b : PredefinedEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<PredefinedEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final PredefinedEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public PredefinedEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return PredefinedEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("predefined")
  private PredefinedEnum predefined = null;

  @SerializedName("country")
  private Country country = null;

  @SerializedName("region")
  private Region region = null;

  public Location id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Şehir nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Şehir nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Location name(String name) {
    this.name = name;
    return this;
  }

   /**
   * Şehir nesnesi için isim değeri.
   * @return name
  **/
  @ApiModelProperty(example = "İstanbul", required = true, value = "Şehir nesnesi için isim değeri.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Location status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Şehir nesnesinin aktiflik durumunu belirten değer.
   * @return status
  **/
  @ApiModelProperty(example = "1", required = true, value = "Şehir nesnesinin aktiflik durumunu belirten değer.")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

   /**
   * Şehir nesnesinin öntanımlı olup olmadığını belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Öntanımlı şehir.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yeni eklenmiş şehir.&lt;br&gt;&lt;/div&gt;
   * @return predefined
  **/
  @ApiModelProperty(example = "0", value = "Şehir nesnesinin öntanımlı olup olmadığını belirtir.<div class='idea_choice_list'><code>1</code> : Öntanımlı şehir.<br><code>0</code> : Yeni eklenmiş şehir.<br></div>")
  public PredefinedEnum getPredefined() {
    return predefined;
  }

  public Location country(Country country) {
    this.country = country;
    return this;
  }

   /**
   * Get country
   * @return country
  **/
  @ApiModelProperty(value = "")
  public Country getCountry() {
    return country;
  }

  public void setCountry(Country country) {
    this.country = country;
  }

  public Location region(Region region) {
    this.region = region;
    return this;
  }

   /**
   * Get region
   * @return region
  **/
  @ApiModelProperty(value = "")
  public Region getRegion() {
    return region;
  }

  public void setRegion(Region region) {
    this.region = region;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Location location = (Location) o;
    return Objects.equals(this.id, location.id) &&
        Objects.equals(this.name, location.name) &&
        Objects.equals(this.status, location.status) &&
        Objects.equals(this.predefined, location.predefined) &&
        Objects.equals(this.country, location.country) &&
        Objects.equals(this.region, location.region);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, status, predefined, country, region);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Location {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    predefined: ").append(toIndentedString(predefined)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("    region: ").append(toIndentedString(region)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

