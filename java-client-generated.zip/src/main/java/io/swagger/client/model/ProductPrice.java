package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Product;
import java.io.IOException;

/**
 * ProductPrice
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ProductPrice {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("value")
  private Float value = null;

  @SerializedName("type")
  private Integer type = null;

  @SerializedName("product")
  private Product product = null;

  public ProductPrice id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Ürün fiyatı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Ürün fiyatı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductPrice value(Float value) {
    this.value = value;
    return this;
  }

   /**
   * Ürün fiyatı değeri.
   * minimum: 0
   * @return value
  **/
  @ApiModelProperty(example = "10.0", required = true, value = "Ürün fiyatı değeri.")
  public Float getValue() {
    return value;
  }

  public void setValue(Float value) {
    this.value = value;
  }

  public ProductPrice type(Integer type) {
    this.type = type;
    return this;
  }

   /**
   * Ürün fiyatı indexi. Fiyat 2, Fiyat 3 gibi.
   * minimum: 2
   * maximum: 5
   * @return type
  **/
  @ApiModelProperty(example = "2", required = true, value = "Ürün fiyatı indexi. Fiyat 2, Fiyat 3 gibi.")
  public Integer getType() {
    return type;
  }

  public void setType(Integer type) {
    this.type = type;
  }

  public ProductPrice product(Product product) {
    this.product = product;
    return this;
  }

   /**
   * Get product
   * @return product
  **/
  @ApiModelProperty(value = "")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProductPrice productPrice = (ProductPrice) o;
    return Objects.equals(this.id, productPrice.id) &&
        Objects.equals(this.value, productPrice.value) &&
        Objects.equals(this.type, productPrice.type) &&
        Objects.equals(this.product, productPrice.product);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, value, type, product);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductPrice {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    value: ").append(toIndentedString(value)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

