package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Country;
import io.swagger.client.model.Location;
import io.swagger.client.model.Member;
import io.swagger.client.model.MemberGroup;
import java.io.IOException;
import org.threeten.bp.OffsetDateTime;

/**
 * Member
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Member {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("firstname")
  private String firstname = null;

  @SerializedName("surname")
  private String surname = null;

  @SerializedName("email")
  private String email = null;

  /**
   * Üyenin cinsiyet bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(GenderEnum.Adapter.class)
  public enum GenderEnum {
    MALE("male"),
    
    FEMALE("female");

    private String value;

    GenderEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static GenderEnum fromValue(String text) {
      for (GenderEnum b : GenderEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<GenderEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final GenderEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public GenderEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return GenderEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("gender")
  private GenderEnum gender = null;

  @SerializedName("birthDate")
  private OffsetDateTime birthDate = null;

  @SerializedName("phoneNumber")
  private String phoneNumber = null;

  @SerializedName("mobilePhoneNumber")
  private String mobilePhoneNumber = null;

  @SerializedName("otherLocation")
  private String otherLocation = null;

  @SerializedName("address")
  private String address = null;

  @SerializedName("taxNumber")
  private String taxNumber = null;

  @SerializedName("tcId")
  private String tcId = null;

  /**
   * Üyenin durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;queue&lt;/code&gt; : Sırada&lt;br&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;suspended&lt;/code&gt; : Askıda&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    QUEUE("queue"),
    
    ACTIVE("active"),
    
    PASSIVE("passive"),
    
    SUSPENDED("suspended");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  @SerializedName("lastLoginDate")
  private OffsetDateTime lastLoginDate = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  @SerializedName("zipCode")
  private String zipCode = null;

  @SerializedName("commercialName")
  private String commercialName = null;

  @SerializedName("taxOffice")
  private String taxOffice = null;

  @SerializedName("lastMailSentDate")
  private OffsetDateTime lastMailSentDate = null;

  @SerializedName("lastIp")
  private String lastIp = null;

  @SerializedName("gainedPointAmount")
  private Float gainedPointAmount = null;

  @SerializedName("spentPointAmount")
  private Float spentPointAmount = null;

  /**
   * Üyenin kampanyalara katılım için izin durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalar için izinli.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalar için izinsiz.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(AllowedToCampaignsEnum.Adapter.class)
  public enum AllowedToCampaignsEnum {
    _0("0"),
    
    _1("1");

    private String value;

    AllowedToCampaignsEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static AllowedToCampaignsEnum fromValue(String text) {
      for (AllowedToCampaignsEnum b : AllowedToCampaignsEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<AllowedToCampaignsEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final AllowedToCampaignsEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public AllowedToCampaignsEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return AllowedToCampaignsEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("allowedToCampaigns")
  private AllowedToCampaignsEnum allowedToCampaigns = null;

  @SerializedName("referredMemberGainedPointAmount")
  private Float referredMemberGainedPointAmount = null;

  @SerializedName("district")
  private String district = null;

  @SerializedName("deviceType")
  private String deviceType = null;

  @SerializedName("deviceInfo")
  private String deviceInfo = null;

  @SerializedName("country")
  private Country country = null;

  @SerializedName("location")
  private Location location = null;

  @SerializedName("memberGroup")
  private MemberGroup memberGroup = null;

  @SerializedName("referredMember")
  private Member referredMember = null;

  public Member id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Üye nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Üye nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Member firstname(String firstname) {
    this.firstname = firstname;
    return this;
  }

   /**
   * Üyenin ismi.
   * @return firstname
  **/
  @ApiModelProperty(example = "John", required = true, value = "Üyenin ismi.")
  public String getFirstname() {
    return firstname;
  }

  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }

  public Member surname(String surname) {
    this.surname = surname;
    return this;
  }

   /**
   * Üyenin soy ismi.
   * @return surname
  **/
  @ApiModelProperty(example = "Doe", required = true, value = "Üyenin soy ismi.")
  public String getSurname() {
    return surname;
  }

  public void setSurname(String surname) {
    this.surname = surname;
  }

  public Member email(String email) {
    this.email = email;
    return this;
  }

   /**
   * Üyenin e-mail adresi.
   * @return email
  **/
  @ApiModelProperty(example = "johndoe@ideasoft.com.tr", required = true, value = "Üyenin e-mail adresi.")
  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public Member gender(GenderEnum gender) {
    this.gender = gender;
    return this;
  }

   /**
   * Üyenin cinsiyet bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın&lt;br&gt;&lt;/div&gt;
   * @return gender
  **/
  @ApiModelProperty(example = "male", value = "Üyenin cinsiyet bilgisi.<div class='idea_choice_list'><code>male</code> : Erkek<br><code>female</code> : Kadın<br></div>")
  public GenderEnum getGender() {
    return gender;
  }

  public void setGender(GenderEnum gender) {
    this.gender = gender;
  }

  public Member birthDate(OffsetDateTime birthDate) {
    this.birthDate = birthDate;
    return this;
  }

   /**
   * Üyenin doğum tarihi.
   * @return birthDate
  **/
  @ApiModelProperty(example = "1988-02-21T00:00:00+0000", value = "Üyenin doğum tarihi.")
  public OffsetDateTime getBirthDate() {
    return birthDate;
  }

  public void setBirthDate(OffsetDateTime birthDate) {
    this.birthDate = birthDate;
  }

  public Member phoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
    return this;
  }

   /**
   * Üyenin telefon numarası.
   * @return phoneNumber
  **/
  @ApiModelProperty(example = "+90 (216) 326 04 77", value = "Üyenin telefon numarası.")
  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public Member mobilePhoneNumber(String mobilePhoneNumber) {
    this.mobilePhoneNumber = mobilePhoneNumber;
    return this;
  }

   /**
   * Üyenin mobil telefon numarası.
   * @return mobilePhoneNumber
  **/
  @ApiModelProperty(example = "+90 (555) 555 55 55", value = "Üyenin mobil telefon numarası.")
  public String getMobilePhoneNumber() {
    return mobilePhoneNumber;
  }

  public void setMobilePhoneNumber(String mobilePhoneNumber) {
    this.mobilePhoneNumber = mobilePhoneNumber;
  }

  public Member otherLocation(String otherLocation) {
    this.otherLocation = otherLocation;
    return this;
  }

   /**
   * Üyenin diğer şehir bilgileri.
   * @return otherLocation
  **/
  @ApiModelProperty(example = "other-location", value = "Üyenin diğer şehir bilgileri.")
  public String getOtherLocation() {
    return otherLocation;
  }

  public void setOtherLocation(String otherLocation) {
    this.otherLocation = otherLocation;
  }

  public Member address(String address) {
    this.address = address;
    return this;
  }

   /**
   * Üyenin adres bilgileri.
   * @return address
  **/
  @ApiModelProperty(example = "Cumhuriyet Mah. Libadiye Cad. Çimen Sok. No:2", value = "Üyenin adres bilgileri.")
  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public Member taxNumber(String taxNumber) {
    this.taxNumber = taxNumber;
    return this;
  }

   /**
   * Üyenin vergi numarası.
   * @return taxNumber
  **/
  @ApiModelProperty(example = "1966712049", value = "Üyenin vergi numarası.")
  public String getTaxNumber() {
    return taxNumber;
  }

  public void setTaxNumber(String taxNumber) {
    this.taxNumber = taxNumber;
  }

  public Member tcId(String tcId) {
    this.tcId = tcId;
    return this;
  }

   /**
   * Üyenin TC kimlik numarası.
   * @return tcId
  **/
  @ApiModelProperty(example = "11111111111", value = "Üyenin TC kimlik numarası.")
  public String getTcId() {
    return tcId;
  }

  public void setTcId(String tcId) {
    this.tcId = tcId;
  }

  public Member status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Üyenin durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;queue&lt;/code&gt; : Sırada&lt;br&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;suspended&lt;/code&gt; : Askıda&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @ApiModelProperty(example = "active", required = true, value = "Üyenin durum bilgisi.<div class='idea_choice_list'><code>queue</code> : Sırada<br><code>active</code> : Aktif<br><code>passive</code> : Pasif<br><code>suspended</code> : Askıda<br></div>")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Member lastLoginDate(OffsetDateTime lastLoginDate) {
    this.lastLoginDate = lastLoginDate;
    return this;
  }

   /**
   * Üyenin son giriş yaptığı tarih.
   * @return lastLoginDate
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Üyenin son giriş yaptığı tarih.")
  public OffsetDateTime getLastLoginDate() {
    return lastLoginDate;
  }

  public void setLastLoginDate(OffsetDateTime lastLoginDate) {
    this.lastLoginDate = lastLoginDate;
  }

   /**
   * Üye nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Üye nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

   /**
   * Üye nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Üye nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public Member zipCode(String zipCode) {
    this.zipCode = zipCode;
    return this;
  }

   /**
   * Üyenin posta kodu.
   * @return zipCode
  **/
  @ApiModelProperty(example = "34704", value = "Üyenin posta kodu.")
  public String getZipCode() {
    return zipCode;
  }

  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }

  public Member commercialName(String commercialName) {
    this.commercialName = commercialName;
    return this;
  }

   /**
   * Üyenin kurumsal adı.
   * @return commercialName
  **/
  @ApiModelProperty(example = "Ideasoft Yazılım San. ve Tic. A.Ş.", value = "Üyenin kurumsal adı.")
  public String getCommercialName() {
    return commercialName;
  }

  public void setCommercialName(String commercialName) {
    this.commercialName = commercialName;
  }

  public Member taxOffice(String taxOffice) {
    this.taxOffice = taxOffice;
    return this;
  }

   /**
   * Üyenin vergi dairesi.
   * @return taxOffice
  **/
  @ApiModelProperty(example = "Üsküdar", value = "Üyenin vergi dairesi.")
  public String getTaxOffice() {
    return taxOffice;
  }

  public void setTaxOffice(String taxOffice) {
    this.taxOffice = taxOffice;
  }

  public Member lastMailSentDate(OffsetDateTime lastMailSentDate) {
    this.lastMailSentDate = lastMailSentDate;
    return this;
  }

   /**
   * Üyeye gönderilen son e-mail tarihi.
   * @return lastMailSentDate
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Üyeye gönderilen son e-mail tarihi.")
  public OffsetDateTime getLastMailSentDate() {
    return lastMailSentDate;
  }

  public void setLastMailSentDate(OffsetDateTime lastMailSentDate) {
    this.lastMailSentDate = lastMailSentDate;
  }

  public Member lastIp(String lastIp) {
    this.lastIp = lastIp;
    return this;
  }

   /**
   * Üyenin en son giriş yaptığı IP adresi.
   * @return lastIp
  **/
  @ApiModelProperty(example = "192.168.1.1", value = "Üyenin en son giriş yaptığı IP adresi.")
  public String getLastIp() {
    return lastIp;
  }

  public void setLastIp(String lastIp) {
    this.lastIp = lastIp;
  }

  public Member gainedPointAmount(Float gainedPointAmount) {
    this.gainedPointAmount = gainedPointAmount;
    return this;
  }

   /**
   * Üyenin kazandığı puan tutarı.
   * minimum: 0
   * @return gainedPointAmount
  **/
  @ApiModelProperty(example = "10500.0", value = "Üyenin kazandığı puan tutarı.")
  public Float getGainedPointAmount() {
    return gainedPointAmount;
  }

  public void setGainedPointAmount(Float gainedPointAmount) {
    this.gainedPointAmount = gainedPointAmount;
  }

  public Member spentPointAmount(Float spentPointAmount) {
    this.spentPointAmount = spentPointAmount;
    return this;
  }

   /**
   * Üyenin harcadığı puan tutarı.
   * minimum: 0
   * @return spentPointAmount
  **/
  @ApiModelProperty(example = "8500.0", value = "Üyenin harcadığı puan tutarı.")
  public Float getSpentPointAmount() {
    return spentPointAmount;
  }

  public void setSpentPointAmount(Float spentPointAmount) {
    this.spentPointAmount = spentPointAmount;
  }

  public Member allowedToCampaigns(AllowedToCampaignsEnum allowedToCampaigns) {
    this.allowedToCampaigns = allowedToCampaigns;
    return this;
  }

   /**
   * Üyenin kampanyalara katılım için izin durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalar için izinli.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalar için izinsiz.&lt;br&gt;&lt;/div&gt;
   * @return allowedToCampaigns
  **/
  @ApiModelProperty(example = "1", value = "Üyenin kampanyalara katılım için izin durumu.<div class='idea_choice_list'><code>1</code> : Kampanyalar için izinli.<br><code>0</code> : Kampanyalar için izinsiz.<br></div>")
  public AllowedToCampaignsEnum getAllowedToCampaigns() {
    return allowedToCampaigns;
  }

  public void setAllowedToCampaigns(AllowedToCampaignsEnum allowedToCampaigns) {
    this.allowedToCampaigns = allowedToCampaigns;
  }

  public Member referredMemberGainedPointAmount(Float referredMemberGainedPointAmount) {
    this.referredMemberGainedPointAmount = referredMemberGainedPointAmount;
    return this;
  }

   /**
   * Üyenin tavsiye ettiği kişilerden dolayı kazandığı puan.
   * minimum: 0
   * @return referredMemberGainedPointAmount
  **/
  @ApiModelProperty(example = "5000.0", value = "Üyenin tavsiye ettiği kişilerden dolayı kazandığı puan.")
  public Float getReferredMemberGainedPointAmount() {
    return referredMemberGainedPointAmount;
  }

  public void setReferredMemberGainedPointAmount(Float referredMemberGainedPointAmount) {
    this.referredMemberGainedPointAmount = referredMemberGainedPointAmount;
  }

  public Member district(String district) {
    this.district = district;
    return this;
  }

   /**
   * Üyenin ilçesi.
   * @return district
  **/
  @ApiModelProperty(example = "Üsküdar", value = "Üyenin ilçesi.")
  public String getDistrict() {
    return district;
  }

  public void setDistrict(String district) {
    this.district = district;
  }

  public Member deviceType(String deviceType) {
    this.deviceType = deviceType;
    return this;
  }

   /**
   * Üyenin kullandığı cihaz tipi.
   * @return deviceType
  **/
  @ApiModelProperty(example = "bilgisayar", required = true, value = "Üyenin kullandığı cihaz tipi.")
  public String getDeviceType() {
    return deviceType;
  }

  public void setDeviceType(String deviceType) {
    this.deviceType = deviceType;
  }

  public Member deviceInfo(String deviceInfo) {
    this.deviceInfo = deviceInfo;
    return this;
  }

   /**
   * Üyenin kullandığı cihaz bilgisi.
   * @return deviceInfo
  **/
  @ApiModelProperty(example = "deviceInfo", value = "Üyenin kullandığı cihaz bilgisi.")
  public String getDeviceInfo() {
    return deviceInfo;
  }

  public void setDeviceInfo(String deviceInfo) {
    this.deviceInfo = deviceInfo;
  }

  public Member country(Country country) {
    this.country = country;
    return this;
  }

   /**
   * Get country
   * @return country
  **/
  @ApiModelProperty(value = "")
  public Country getCountry() {
    return country;
  }

  public void setCountry(Country country) {
    this.country = country;
  }

  public Member location(Location location) {
    this.location = location;
    return this;
  }

   /**
   * Get location
   * @return location
  **/
  @ApiModelProperty(value = "")
  public Location getLocation() {
    return location;
  }

  public void setLocation(Location location) {
    this.location = location;
  }

  public Member memberGroup(MemberGroup memberGroup) {
    this.memberGroup = memberGroup;
    return this;
  }

   /**
   * Get memberGroup
   * @return memberGroup
  **/
  @ApiModelProperty(value = "")
  public MemberGroup getMemberGroup() {
    return memberGroup;
  }

  public void setMemberGroup(MemberGroup memberGroup) {
    this.memberGroup = memberGroup;
  }

  public Member referredMember(Member referredMember) {
    this.referredMember = referredMember;
    return this;
  }

   /**
   * Get referredMember
   * @return referredMember
  **/
  @ApiModelProperty(value = "")
  public Member getReferredMember() {
    return referredMember;
  }

  public void setReferredMember(Member referredMember) {
    this.referredMember = referredMember;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Member member = (Member) o;
    return Objects.equals(this.id, member.id) &&
        Objects.equals(this.firstname, member.firstname) &&
        Objects.equals(this.surname, member.surname) &&
        Objects.equals(this.email, member.email) &&
        Objects.equals(this.gender, member.gender) &&
        Objects.equals(this.birthDate, member.birthDate) &&
        Objects.equals(this.phoneNumber, member.phoneNumber) &&
        Objects.equals(this.mobilePhoneNumber, member.mobilePhoneNumber) &&
        Objects.equals(this.otherLocation, member.otherLocation) &&
        Objects.equals(this.address, member.address) &&
        Objects.equals(this.taxNumber, member.taxNumber) &&
        Objects.equals(this.tcId, member.tcId) &&
        Objects.equals(this.status, member.status) &&
        Objects.equals(this.lastLoginDate, member.lastLoginDate) &&
        Objects.equals(this.createdAt, member.createdAt) &&
        Objects.equals(this.updatedAt, member.updatedAt) &&
        Objects.equals(this.zipCode, member.zipCode) &&
        Objects.equals(this.commercialName, member.commercialName) &&
        Objects.equals(this.taxOffice, member.taxOffice) &&
        Objects.equals(this.lastMailSentDate, member.lastMailSentDate) &&
        Objects.equals(this.lastIp, member.lastIp) &&
        Objects.equals(this.gainedPointAmount, member.gainedPointAmount) &&
        Objects.equals(this.spentPointAmount, member.spentPointAmount) &&
        Objects.equals(this.allowedToCampaigns, member.allowedToCampaigns) &&
        Objects.equals(this.referredMemberGainedPointAmount, member.referredMemberGainedPointAmount) &&
        Objects.equals(this.district, member.district) &&
        Objects.equals(this.deviceType, member.deviceType) &&
        Objects.equals(this.deviceInfo, member.deviceInfo) &&
        Objects.equals(this.country, member.country) &&
        Objects.equals(this.location, member.location) &&
        Objects.equals(this.memberGroup, member.memberGroup) &&
        Objects.equals(this.referredMember, member.referredMember);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, firstname, surname, email, gender, birthDate, phoneNumber, mobilePhoneNumber, otherLocation, address, taxNumber, tcId, status, lastLoginDate, createdAt, updatedAt, zipCode, commercialName, taxOffice, lastMailSentDate, lastIp, gainedPointAmount, spentPointAmount, allowedToCampaigns, referredMemberGainedPointAmount, district, deviceType, deviceInfo, country, location, memberGroup, referredMember);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Member {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    firstname: ").append(toIndentedString(firstname)).append("\n");
    sb.append("    surname: ").append(toIndentedString(surname)).append("\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    gender: ").append(toIndentedString(gender)).append("\n");
    sb.append("    birthDate: ").append(toIndentedString(birthDate)).append("\n");
    sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
    sb.append("    mobilePhoneNumber: ").append(toIndentedString(mobilePhoneNumber)).append("\n");
    sb.append("    otherLocation: ").append(toIndentedString(otherLocation)).append("\n");
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    taxNumber: ").append(toIndentedString(taxNumber)).append("\n");
    sb.append("    tcId: ").append(toIndentedString(tcId)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    lastLoginDate: ").append(toIndentedString(lastLoginDate)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    zipCode: ").append(toIndentedString(zipCode)).append("\n");
    sb.append("    commercialName: ").append(toIndentedString(commercialName)).append("\n");
    sb.append("    taxOffice: ").append(toIndentedString(taxOffice)).append("\n");
    sb.append("    lastMailSentDate: ").append(toIndentedString(lastMailSentDate)).append("\n");
    sb.append("    lastIp: ").append(toIndentedString(lastIp)).append("\n");
    sb.append("    gainedPointAmount: ").append(toIndentedString(gainedPointAmount)).append("\n");
    sb.append("    spentPointAmount: ").append(toIndentedString(spentPointAmount)).append("\n");
    sb.append("    allowedToCampaigns: ").append(toIndentedString(allowedToCampaigns)).append("\n");
    sb.append("    referredMemberGainedPointAmount: ").append(toIndentedString(referredMemberGainedPointAmount)).append("\n");
    sb.append("    district: ").append(toIndentedString(district)).append("\n");
    sb.append("    deviceType: ").append(toIndentedString(deviceType)).append("\n");
    sb.append("    deviceInfo: ").append(toIndentedString(deviceInfo)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("    location: ").append(toIndentedString(location)).append("\n");
    sb.append("    memberGroup: ").append(toIndentedString(memberGroup)).append("\n");
    sb.append("    referredMember: ").append(toIndentedString(referredMember)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

