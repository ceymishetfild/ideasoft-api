package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Product;
import java.io.IOException;

/**
 * ProductProtection
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ProductProtection {
  @SerializedName("id")
  private Integer id = null;

  /**
   * Ürün fiyatının korumalı olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Korumalı.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Korumasız.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(IsPriceProtectedEnum.Adapter.class)
  public enum IsPriceProtectedEnum {
    _0("0"),
    
    _1("1");

    private String value;

    IsPriceProtectedEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static IsPriceProtectedEnum fromValue(String text) {
      for (IsPriceProtectedEnum b : IsPriceProtectedEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<IsPriceProtectedEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final IsPriceProtectedEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public IsPriceProtectedEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return IsPriceProtectedEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("isPriceProtected")
  private IsPriceProtectedEnum isPriceProtected = null;

  /**
   * Ürün stoğunun korumalı olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Korumalı.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Korumasız.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(IsStockProtectedEnum.Adapter.class)
  public enum IsStockProtectedEnum {
    _0("0"),
    
    _1("1");

    private String value;

    IsStockProtectedEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static IsStockProtectedEnum fromValue(String text) {
      for (IsStockProtectedEnum b : IsStockProtectedEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<IsStockProtectedEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final IsStockProtectedEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public IsStockProtectedEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return IsStockProtectedEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("isStockProtected")
  private IsStockProtectedEnum isStockProtected = null;

  @SerializedName("product")
  private Product product = null;

  public ProductProtection id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Entegrasyon seçeneği nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Entegrasyon seçeneği nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductProtection isPriceProtected(IsPriceProtectedEnum isPriceProtected) {
    this.isPriceProtected = isPriceProtected;
    return this;
  }

   /**
   * Ürün fiyatının korumalı olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Korumalı.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Korumasız.&lt;br&gt;&lt;/div&gt;
   * @return isPriceProtected
  **/
  @ApiModelProperty(example = "0", value = "Ürün fiyatının korumalı olup olmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Korumalı.<br><code>0</code> : Korumasız.<br></div>")
  public IsPriceProtectedEnum getIsPriceProtected() {
    return isPriceProtected;
  }

  public void setIsPriceProtected(IsPriceProtectedEnum isPriceProtected) {
    this.isPriceProtected = isPriceProtected;
  }

  public ProductProtection isStockProtected(IsStockProtectedEnum isStockProtected) {
    this.isStockProtected = isStockProtected;
    return this;
  }

   /**
   * Ürün stoğunun korumalı olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Korumalı.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Korumasız.&lt;br&gt;&lt;/div&gt;
   * @return isStockProtected
  **/
  @ApiModelProperty(example = "0", value = "Ürün stoğunun korumalı olup olmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Korumalı.<br><code>0</code> : Korumasız.<br></div>")
  public IsStockProtectedEnum getIsStockProtected() {
    return isStockProtected;
  }

  public void setIsStockProtected(IsStockProtectedEnum isStockProtected) {
    this.isStockProtected = isStockProtected;
  }

  public ProductProtection product(Product product) {
    this.product = product;
    return this;
  }

   /**
   * Get product
   * @return product
  **/
  @ApiModelProperty(value = "")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProductProtection productProtection = (ProductProtection) o;
    return Objects.equals(this.id, productProtection.id) &&
        Objects.equals(this.isPriceProtected, productProtection.isPriceProtected) &&
        Objects.equals(this.isStockProtected, productProtection.isStockProtected) &&
        Objects.equals(this.product, productProtection.product);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, isPriceProtected, isStockProtected, product);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductProtection {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    isPriceProtected: ").append(toIndentedString(isPriceProtected)).append("\n");
    sb.append("    isStockProtected: ").append(toIndentedString(isStockProtected)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

