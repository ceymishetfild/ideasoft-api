package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.IOException;

/**
 * Distributor
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Distributor {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("name")
  private String name = null;

  @SerializedName("email")
  private String email = null;

  @SerializedName("phone")
  private String phone = null;

  @SerializedName("contactPerson")
  private String contactPerson = null;

  public Distributor id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Distributor nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Distributor nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Distributor name(String name) {
    this.name = name;
    return this;
  }

   /**
   * Distributor nesnesi için isim değeri.
   * @return name
  **/
  @ApiModelProperty(example = "Kırtasiye Tedarik", required = true, value = "Distributor nesnesi için isim değeri.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Distributor email(String email) {
    this.email = email;
    return this;
  }

   /**
   * E-mail adresi.
   * @return email
  **/
  @ApiModelProperty(example = "info@kirtasiyetedarik.com", value = "E-mail adresi.")
  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public Distributor phone(String phone) {
    this.phone = phone;
    return this;
  }

   /**
   * Telefon numarası.
   * @return phone
  **/
  @ApiModelProperty(example = "+90 (544) 444 44 44", value = "Telefon numarası.")
  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public Distributor contactPerson(String contactPerson) {
    this.contactPerson = contactPerson;
    return this;
  }

   /**
   * İletişim kişisi.
   * @return contactPerson
  **/
  @ApiModelProperty(example = "Richard Roe", value = "İletişim kişisi.")
  public String getContactPerson() {
    return contactPerson;
  }

  public void setContactPerson(String contactPerson) {
    this.contactPerson = contactPerson;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Distributor distributor = (Distributor) o;
    return Objects.equals(this.id, distributor.id) &&
        Objects.equals(this.name, distributor.name) &&
        Objects.equals(this.email, distributor.email) &&
        Objects.equals(this.phone, distributor.phone) &&
        Objects.equals(this.contactPerson, distributor.contactPerson);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, email, phone, contactPerson);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Distributor {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    phone: ").append(toIndentedString(phone)).append("\n");
    sb.append("    contactPerson: ").append(toIndentedString(contactPerson)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

