package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Member;
import io.swagger.client.model.Order;
import java.io.IOException;
import org.threeten.bp.OffsetDateTime;

/**
 * OrderRefundRequest
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class OrderRefundRequest {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("code")
  private String code = null;

  /**
   * Sipariş iptal talebi için durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı.&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor.&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    APPROVED("approved"),
    
    WAITING_FOR_APPROVAL("waiting_for_approval"),
    
    CANCELLED("cancelled");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  @SerializedName("fee")
  private Float fee = null;

  @SerializedName("cancellationReason")
  private String cancellationReason = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  @SerializedName("member")
  private Member member = null;

  @SerializedName("order")
  private Order order = null;

  public OrderRefundRequest id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Sipariş iptal talebi nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Sipariş iptal talebi nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OrderRefundRequest code(String code) {
    this.code = code;
    return this;
  }

   /**
   * Sipariş iptal talebi için oluşturulan benzersiz kod değeri.
   * @return code
  **/
  @ApiModelProperty(example = "KOD-1234", required = true, value = "Sipariş iptal talebi için oluşturulan benzersiz kod değeri.")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public OrderRefundRequest status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Sipariş iptal talebi için durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı.&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor.&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @ApiModelProperty(example = "approved", required = true, value = "Sipariş iptal talebi için durum bilgisi.<div class='idea_choice_list'><code>approved</code> : Onaylandı.<br><code>waiting_for_approval</code> : Onay bekliyor.<br><code>cancelled</code> : İptal edildi.<br></div>")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public OrderRefundRequest fee(Float fee) {
    this.fee = fee;
    return this;
  }

   /**
   * Müşteriye ödenecek miktar bilgisi.
   * minimum: 0
   * @return fee
  **/
  @ApiModelProperty(example = "15.0", required = true, value = "Müşteriye ödenecek miktar bilgisi.")
  public Float getFee() {
    return fee;
  }

  public void setFee(Float fee) {
    this.fee = fee;
  }

  public OrderRefundRequest cancellationReason(String cancellationReason) {
    this.cancellationReason = cancellationReason;
    return this;
  }

   /**
   * Sipariş iptal talebinin oluşturulması sebebinin detaylı açıklaması.
   * @return cancellationReason
  **/
  @ApiModelProperty(example = "Ürün kusurlu.", value = "Sipariş iptal talebinin oluşturulması sebebinin detaylı açıklaması.")
  public String getCancellationReason() {
    return cancellationReason;
  }

  public void setCancellationReason(String cancellationReason) {
    this.cancellationReason = cancellationReason;
  }

   /**
   * Sipariş iptal talebi nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", required = true, value = "Sipariş iptal talebi nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

   /**
   * Sipariş iptal talebi nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", required = true, value = "Sipariş iptal talebi nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public OrderRefundRequest member(Member member) {
    this.member = member;
    return this;
  }

   /**
   * Get member
   * @return member
  **/
  @ApiModelProperty(value = "")
  public Member getMember() {
    return member;
  }

  public void setMember(Member member) {
    this.member = member;
  }

  public OrderRefundRequest order(Order order) {
    this.order = order;
    return this;
  }

   /**
   * Get order
   * @return order
  **/
  @ApiModelProperty(value = "")
  public Order getOrder() {
    return order;
  }

  public void setOrder(Order order) {
    this.order = order;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrderRefundRequest orderRefundRequest = (OrderRefundRequest) o;
    return Objects.equals(this.id, orderRefundRequest.id) &&
        Objects.equals(this.code, orderRefundRequest.code) &&
        Objects.equals(this.status, orderRefundRequest.status) &&
        Objects.equals(this.fee, orderRefundRequest.fee) &&
        Objects.equals(this.cancellationReason, orderRefundRequest.cancellationReason) &&
        Objects.equals(this.createdAt, orderRefundRequest.createdAt) &&
        Objects.equals(this.updatedAt, orderRefundRequest.updatedAt) &&
        Objects.equals(this.member, orderRefundRequest.member) &&
        Objects.equals(this.order, orderRefundRequest.order);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, code, status, fee, cancellationReason, createdAt, updatedAt, member, order);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderRefundRequest {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    fee: ").append(toIndentedString(fee)).append("\n");
    sb.append("    cancellationReason: ").append(toIndentedString(cancellationReason)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    member: ").append(toIndentedString(member)).append("\n");
    sb.append("    order: ").append(toIndentedString(order)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

