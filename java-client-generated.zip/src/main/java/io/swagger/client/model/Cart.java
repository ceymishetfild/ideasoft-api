package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.CartItem;
import io.swagger.client.model.Member;
import io.swagger.client.model.ShopCampaigns;
import io.swagger.client.model.ShopTokens;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;

/**
 * Cart
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Cart {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("sessionId")
  private String sessionId = null;

  /**
   * Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz.
   */
  @JsonAdapter(LockedEnum.Adapter.class)
  public enum LockedEnum {
    _0("0"),
    
    _1("1");

    private String value;

    LockedEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static LockedEnum fromValue(String text) {
      for (LockedEnum b : LockedEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<LockedEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final LockedEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public LockedEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return LockedEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("locked")
  private LockedEnum locked = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  @SerializedName("chosenPromotion")
  private ShopCampaigns chosenPromotion = null;

  @SerializedName("member")
  private Member member = null;

  @SerializedName("chosenToken")
  private ShopTokens chosenToken = null;

  @SerializedName("items")
  private List<CartItem> items = null;

  public Cart id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Sepet nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Sepet nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Cart sessionId(String sessionId) {
    this.sessionId = sessionId;
    return this;
  }

   /**
   * Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri.
   * @return sessionId
  **/
  @ApiModelProperty(example = "oibtkn9rspcdbmphf8iceondg1", required = true, value = "Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri.")
  public String getSessionId() {
    return sessionId;
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  public Cart locked(LockedEnum locked) {
    this.locked = locked;
    return this;
  }

   /**
   * Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz.
   * @return locked
  **/
  @ApiModelProperty(example = "0", value = "Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz.")
  public LockedEnum getLocked() {
    return locked;
  }

  public void setLocked(LockedEnum locked) {
    this.locked = locked;
  }

   /**
   * Sepet nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Sepet nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

  public Cart updatedAt(OffsetDateTime updatedAt) {
    this.updatedAt = updatedAt;
    return this;
  }

   /**
   * Sepet nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Sepet nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(OffsetDateTime updatedAt) {
    this.updatedAt = updatedAt;
  }

  public Cart chosenPromotion(ShopCampaigns chosenPromotion) {
    this.chosenPromotion = chosenPromotion;
    return this;
  }

   /**
   * Get chosenPromotion
   * @return chosenPromotion
  **/
  @ApiModelProperty(value = "")
  public ShopCampaigns getChosenPromotion() {
    return chosenPromotion;
  }

  public void setChosenPromotion(ShopCampaigns chosenPromotion) {
    this.chosenPromotion = chosenPromotion;
  }

  public Cart member(Member member) {
    this.member = member;
    return this;
  }

   /**
   * Get member
   * @return member
  **/
  @ApiModelProperty(value = "")
  public Member getMember() {
    return member;
  }

  public void setMember(Member member) {
    this.member = member;
  }

  public Cart chosenToken(ShopTokens chosenToken) {
    this.chosenToken = chosenToken;
    return this;
  }

   /**
   * Get chosenToken
   * @return chosenToken
  **/
  @ApiModelProperty(value = "")
  public ShopTokens getChosenToken() {
    return chosenToken;
  }

  public void setChosenToken(ShopTokens chosenToken) {
    this.chosenToken = chosenToken;
  }

  public Cart items(List<CartItem> items) {
    this.items = items;
    return this;
  }

  public Cart addItemsItem(CartItem itemsItem) {
    if (this.items == null) {
      this.items = new ArrayList<CartItem>();
    }
    this.items.add(itemsItem);
    return this;
  }

   /**
   * Sepet kalemi nesnelerini barındıran liste.
   * @return items
  **/
  @ApiModelProperty(value = "Sepet kalemi nesnelerini barındıran liste.")
  public List<CartItem> getItems() {
    return items;
  }

  public void setItems(List<CartItem> items) {
    this.items = items;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Cart cart = (Cart) o;
    return Objects.equals(this.id, cart.id) &&
        Objects.equals(this.sessionId, cart.sessionId) &&
        Objects.equals(this.locked, cart.locked) &&
        Objects.equals(this.createdAt, cart.createdAt) &&
        Objects.equals(this.updatedAt, cart.updatedAt) &&
        Objects.equals(this.chosenPromotion, cart.chosenPromotion) &&
        Objects.equals(this.member, cart.member) &&
        Objects.equals(this.chosenToken, cart.chosenToken) &&
        Objects.equals(this.items, cart.items);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, sessionId, locked, createdAt, updatedAt, chosenPromotion, member, chosenToken, items);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Cart {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    sessionId: ").append(toIndentedString(sessionId)).append("\n");
    sb.append("    locked: ").append(toIndentedString(locked)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    chosenPromotion: ").append(toIndentedString(chosenPromotion)).append("\n");
    sb.append("    member: ").append(toIndentedString(member)).append("\n");
    sb.append("    chosenToken: ").append(toIndentedString(chosenToken)).append("\n");
    sb.append("    items: ").append(toIndentedString(items)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

