package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Product;
import java.io.IOException;

/**
 * ProductButton
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ProductButton {
  @SerializedName("id")
  private Integer id = null;

  /**
   * Hızlı gönderi butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hızlı kargo butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hızlı kargo butonu pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(FastShippingEnum.Adapter.class)
  public enum FastShippingEnum {
    _0("0"),
    
    _1("1");

    private String value;

    FastShippingEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static FastShippingEnum fromValue(String text) {
      for (FastShippingEnum b : FastShippingEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<FastShippingEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final FastShippingEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public FastShippingEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return FastShippingEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("fastShipping")
  private FastShippingEnum fastShipping = null;

  /**
   * Aynı gün kargo butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aynı gün kargo butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Aynı gün kargo butonu pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(SameDayShippingEnum.Adapter.class)
  public enum SameDayShippingEnum {
    _0("0"),
    
    _1("1");

    private String value;

    SameDayShippingEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static SameDayShippingEnum fromValue(String text) {
      for (SameDayShippingEnum b : SameDayShippingEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<SameDayShippingEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final SameDayShippingEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public SameDayShippingEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return SameDayShippingEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("sameDayShipping")
  private SameDayShippingEnum sameDayShipping = null;

  /**
   * 3 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 3 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 3 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(ThreeDaysDeliveryEnum.Adapter.class)
  public enum ThreeDaysDeliveryEnum {
    _0("0"),
    
    _1("1");

    private String value;

    ThreeDaysDeliveryEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static ThreeDaysDeliveryEnum fromValue(String text) {
      for (ThreeDaysDeliveryEnum b : ThreeDaysDeliveryEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<ThreeDaysDeliveryEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final ThreeDaysDeliveryEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public ThreeDaysDeliveryEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return ThreeDaysDeliveryEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("threeDaysDelivery")
  private ThreeDaysDeliveryEnum threeDaysDelivery = null;

  /**
   * 5 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 5 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 5 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(FiveDaysDeliveryEnum.Adapter.class)
  public enum FiveDaysDeliveryEnum {
    _0("0"),
    
    _1("1");

    private String value;

    FiveDaysDeliveryEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static FiveDaysDeliveryEnum fromValue(String text) {
      for (FiveDaysDeliveryEnum b : FiveDaysDeliveryEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<FiveDaysDeliveryEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final FiveDaysDeliveryEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public FiveDaysDeliveryEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return FiveDaysDeliveryEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("fiveDaysDelivery")
  private FiveDaysDeliveryEnum fiveDaysDelivery = null;

  /**
   * 7 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 7 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 7 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(SevenDaysDeliveryEnum.Adapter.class)
  public enum SevenDaysDeliveryEnum {
    _0("0"),
    
    _1("1");

    private String value;

    SevenDaysDeliveryEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static SevenDaysDeliveryEnum fromValue(String text) {
      for (SevenDaysDeliveryEnum b : SevenDaysDeliveryEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<SevenDaysDeliveryEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final SevenDaysDeliveryEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public SevenDaysDeliveryEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return SevenDaysDeliveryEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("sevenDaysDelivery")
  private SevenDaysDeliveryEnum sevenDaysDelivery = null;

  /**
   * Kargo bedava butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kargo bedava butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kargo bedava butonu pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(FreeShippingEnum.Adapter.class)
  public enum FreeShippingEnum {
    _0("0"),
    
    _1("1");

    private String value;

    FreeShippingEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static FreeShippingEnum fromValue(String text) {
      for (FreeShippingEnum b : FreeShippingEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<FreeShippingEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final FreeShippingEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public FreeShippingEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return FreeShippingEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("freeShipping")
  private FreeShippingEnum freeShipping = null;

  /**
   * Stoktan teslim butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Stoktan teslim butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Stoktan teslim butonu pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(DeliveryFromStockEnum.Adapter.class)
  public enum DeliveryFromStockEnum {
    _0("0"),
    
    _1("1");

    private String value;

    DeliveryFromStockEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static DeliveryFromStockEnum fromValue(String text) {
      for (DeliveryFromStockEnum b : DeliveryFromStockEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<DeliveryFromStockEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final DeliveryFromStockEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public DeliveryFromStockEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return DeliveryFromStockEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("deliveryFromStock")
  private DeliveryFromStockEnum deliveryFromStock = null;

  /**
   * Ön siparişli stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Ön siparişli ürün butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Ön siparişli ürün butonu pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(PreOrderedProductEnum.Adapter.class)
  public enum PreOrderedProductEnum {
    _0("0"),
    
    _1("1");

    private String value;

    PreOrderedProductEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static PreOrderedProductEnum fromValue(String text) {
      for (PreOrderedProductEnum b : PreOrderedProductEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<PreOrderedProductEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final PreOrderedProductEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public PreOrderedProductEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return PreOrderedProductEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("preOrderedProduct")
  private PreOrderedProductEnum preOrderedProduct = null;

  /**
   * Sınırlı stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sınırlı stok butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sınırlı stok butonu pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(LimitedStockEnum.Adapter.class)
  public enum LimitedStockEnum {
    _0("0"),
    
    _1("1");

    private String value;

    LimitedStockEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static LimitedStockEnum fromValue(String text) {
      for (LimitedStockEnum b : LimitedStockEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<LimitedStockEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final LimitedStockEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public LimitedStockEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return LimitedStockEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("limitedStock")
  private LimitedStockEnum limitedStock = null;

  /**
   * Stok sorunuz butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Stok sorunuz butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Stok sorunuz butonu pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(AskStockEnum.Adapter.class)
  public enum AskStockEnum {
    _0("0"),
    
    _1("1");

    private String value;

    AskStockEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static AskStockEnum fromValue(String text) {
      for (AskStockEnum b : AskStockEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<AskStockEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final AskStockEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public AskStockEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return AskStockEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("askStock")
  private AskStockEnum askStock = null;

  /**
   * Kampanyalı stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalı ürün butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalı ürün butonu pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(CampaignedProductEnum.Adapter.class)
  public enum CampaignedProductEnum {
    _0("0"),
    
    _1("1");

    private String value;

    CampaignedProductEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static CampaignedProductEnum fromValue(String text) {
      for (CampaignedProductEnum b : CampaignedProductEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<CampaignedProductEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final CampaignedProductEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public CampaignedProductEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return CampaignedProductEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("campaignedProduct")
  private CampaignedProductEnum campaignedProduct = null;

  @SerializedName("product")
  private Product product = null;

  public ProductButton id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Ürün ve stok butonu nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Ürün ve stok butonu nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductButton fastShipping(FastShippingEnum fastShipping) {
    this.fastShipping = fastShipping;
    return this;
  }

   /**
   * Hızlı gönderi butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hızlı kargo butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hızlı kargo butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return fastShipping
  **/
  @ApiModelProperty(example = "0", value = "Hızlı gönderi butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Hızlı kargo butonu aktif.<br><code>0</code> : Hızlı kargo butonu pasif.<br></div>")
  public FastShippingEnum getFastShipping() {
    return fastShipping;
  }

  public void setFastShipping(FastShippingEnum fastShipping) {
    this.fastShipping = fastShipping;
  }

  public ProductButton sameDayShipping(SameDayShippingEnum sameDayShipping) {
    this.sameDayShipping = sameDayShipping;
    return this;
  }

   /**
   * Aynı gün kargo butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aynı gün kargo butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Aynı gün kargo butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return sameDayShipping
  **/
  @ApiModelProperty(example = "0", value = "Aynı gün kargo butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aynı gün kargo butonu aktif.<br><code>0</code> : Aynı gün kargo butonu pasif.<br></div>")
  public SameDayShippingEnum getSameDayShipping() {
    return sameDayShipping;
  }

  public void setSameDayShipping(SameDayShippingEnum sameDayShipping) {
    this.sameDayShipping = sameDayShipping;
  }

  public ProductButton threeDaysDelivery(ThreeDaysDeliveryEnum threeDaysDelivery) {
    this.threeDaysDelivery = threeDaysDelivery;
    return this;
  }

   /**
   * 3 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 3 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 3 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return threeDaysDelivery
  **/
  @ApiModelProperty(example = "0", value = "3 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 3 günde teslimat butonu aktif.<br><code>0</code> : 3 günde teslimat butonu pasif.<br></div>")
  public ThreeDaysDeliveryEnum getThreeDaysDelivery() {
    return threeDaysDelivery;
  }

  public void setThreeDaysDelivery(ThreeDaysDeliveryEnum threeDaysDelivery) {
    this.threeDaysDelivery = threeDaysDelivery;
  }

  public ProductButton fiveDaysDelivery(FiveDaysDeliveryEnum fiveDaysDelivery) {
    this.fiveDaysDelivery = fiveDaysDelivery;
    return this;
  }

   /**
   * 5 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 5 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 5 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return fiveDaysDelivery
  **/
  @ApiModelProperty(example = "0", value = "5 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 5 günde teslimat butonu aktif.<br><code>0</code> : 5 günde teslimat butonu pasif.<br></div>")
  public FiveDaysDeliveryEnum getFiveDaysDelivery() {
    return fiveDaysDelivery;
  }

  public void setFiveDaysDelivery(FiveDaysDeliveryEnum fiveDaysDelivery) {
    this.fiveDaysDelivery = fiveDaysDelivery;
  }

  public ProductButton sevenDaysDelivery(SevenDaysDeliveryEnum sevenDaysDelivery) {
    this.sevenDaysDelivery = sevenDaysDelivery;
    return this;
  }

   /**
   * 7 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 7 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 7 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return sevenDaysDelivery
  **/
  @ApiModelProperty(example = "0", value = "7 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 7 günde teslimat butonu aktif.<br><code>0</code> : 7 günde teslimat butonu pasif.<br></div>")
  public SevenDaysDeliveryEnum getSevenDaysDelivery() {
    return sevenDaysDelivery;
  }

  public void setSevenDaysDelivery(SevenDaysDeliveryEnum sevenDaysDelivery) {
    this.sevenDaysDelivery = sevenDaysDelivery;
  }

  public ProductButton freeShipping(FreeShippingEnum freeShipping) {
    this.freeShipping = freeShipping;
    return this;
  }

   /**
   * Kargo bedava butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kargo bedava butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kargo bedava butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return freeShipping
  **/
  @ApiModelProperty(example = "0", value = "Kargo bedava butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Kargo bedava butonu aktif.<br><code>0</code> : Kargo bedava butonu pasif.<br></div>")
  public FreeShippingEnum getFreeShipping() {
    return freeShipping;
  }

  public void setFreeShipping(FreeShippingEnum freeShipping) {
    this.freeShipping = freeShipping;
  }

  public ProductButton deliveryFromStock(DeliveryFromStockEnum deliveryFromStock) {
    this.deliveryFromStock = deliveryFromStock;
    return this;
  }

   /**
   * Stoktan teslim butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Stoktan teslim butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Stoktan teslim butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return deliveryFromStock
  **/
  @ApiModelProperty(example = "0", value = "Stoktan teslim butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Stoktan teslim butonu aktif.<br><code>0</code> : Stoktan teslim butonu pasif.<br></div>")
  public DeliveryFromStockEnum getDeliveryFromStock() {
    return deliveryFromStock;
  }

  public void setDeliveryFromStock(DeliveryFromStockEnum deliveryFromStock) {
    this.deliveryFromStock = deliveryFromStock;
  }

  public ProductButton preOrderedProduct(PreOrderedProductEnum preOrderedProduct) {
    this.preOrderedProduct = preOrderedProduct;
    return this;
  }

   /**
   * Ön siparişli stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Ön siparişli ürün butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Ön siparişli ürün butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return preOrderedProduct
  **/
  @ApiModelProperty(example = "0", value = "Ön siparişli stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Ön siparişli ürün butonu aktif.<br><code>0</code> : Ön siparişli ürün butonu pasif.<br></div>")
  public PreOrderedProductEnum getPreOrderedProduct() {
    return preOrderedProduct;
  }

  public void setPreOrderedProduct(PreOrderedProductEnum preOrderedProduct) {
    this.preOrderedProduct = preOrderedProduct;
  }

  public ProductButton limitedStock(LimitedStockEnum limitedStock) {
    this.limitedStock = limitedStock;
    return this;
  }

   /**
   * Sınırlı stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sınırlı stok butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sınırlı stok butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return limitedStock
  **/
  @ApiModelProperty(example = "0", value = "Sınırlı stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Sınırlı stok butonu aktif.<br><code>0</code> : Sınırlı stok butonu pasif.<br></div>")
  public LimitedStockEnum getLimitedStock() {
    return limitedStock;
  }

  public void setLimitedStock(LimitedStockEnum limitedStock) {
    this.limitedStock = limitedStock;
  }

  public ProductButton askStock(AskStockEnum askStock) {
    this.askStock = askStock;
    return this;
  }

   /**
   * Stok sorunuz butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Stok sorunuz butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Stok sorunuz butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return askStock
  **/
  @ApiModelProperty(example = "0", value = "Stok sorunuz butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Stok sorunuz butonu aktif.<br><code>0</code> : Stok sorunuz butonu pasif.<br></div>")
  public AskStockEnum getAskStock() {
    return askStock;
  }

  public void setAskStock(AskStockEnum askStock) {
    this.askStock = askStock;
  }

  public ProductButton campaignedProduct(CampaignedProductEnum campaignedProduct) {
    this.campaignedProduct = campaignedProduct;
    return this;
  }

   /**
   * Kampanyalı stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalı ürün butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalı ürün butonu pasif.&lt;br&gt;&lt;/div&gt;
   * @return campaignedProduct
  **/
  @ApiModelProperty(example = "0", value = "Kampanyalı stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Kampanyalı ürün butonu aktif.<br><code>0</code> : Kampanyalı ürün butonu pasif.<br></div>")
  public CampaignedProductEnum getCampaignedProduct() {
    return campaignedProduct;
  }

  public void setCampaignedProduct(CampaignedProductEnum campaignedProduct) {
    this.campaignedProduct = campaignedProduct;
  }

  public ProductButton product(Product product) {
    this.product = product;
    return this;
  }

   /**
   * Get product
   * @return product
  **/
  @ApiModelProperty(value = "")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProductButton productButton = (ProductButton) o;
    return Objects.equals(this.id, productButton.id) &&
        Objects.equals(this.fastShipping, productButton.fastShipping) &&
        Objects.equals(this.sameDayShipping, productButton.sameDayShipping) &&
        Objects.equals(this.threeDaysDelivery, productButton.threeDaysDelivery) &&
        Objects.equals(this.fiveDaysDelivery, productButton.fiveDaysDelivery) &&
        Objects.equals(this.sevenDaysDelivery, productButton.sevenDaysDelivery) &&
        Objects.equals(this.freeShipping, productButton.freeShipping) &&
        Objects.equals(this.deliveryFromStock, productButton.deliveryFromStock) &&
        Objects.equals(this.preOrderedProduct, productButton.preOrderedProduct) &&
        Objects.equals(this.limitedStock, productButton.limitedStock) &&
        Objects.equals(this.askStock, productButton.askStock) &&
        Objects.equals(this.campaignedProduct, productButton.campaignedProduct) &&
        Objects.equals(this.product, productButton.product);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, fastShipping, sameDayShipping, threeDaysDelivery, fiveDaysDelivery, sevenDaysDelivery, freeShipping, deliveryFromStock, preOrderedProduct, limitedStock, askStock, campaignedProduct, product);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductButton {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    fastShipping: ").append(toIndentedString(fastShipping)).append("\n");
    sb.append("    sameDayShipping: ").append(toIndentedString(sameDayShipping)).append("\n");
    sb.append("    threeDaysDelivery: ").append(toIndentedString(threeDaysDelivery)).append("\n");
    sb.append("    fiveDaysDelivery: ").append(toIndentedString(fiveDaysDelivery)).append("\n");
    sb.append("    sevenDaysDelivery: ").append(toIndentedString(sevenDaysDelivery)).append("\n");
    sb.append("    freeShipping: ").append(toIndentedString(freeShipping)).append("\n");
    sb.append("    deliveryFromStock: ").append(toIndentedString(deliveryFromStock)).append("\n");
    sb.append("    preOrderedProduct: ").append(toIndentedString(preOrderedProduct)).append("\n");
    sb.append("    limitedStock: ").append(toIndentedString(limitedStock)).append("\n");
    sb.append("    askStock: ").append(toIndentedString(askStock)).append("\n");
    sb.append("    campaignedProduct: ").append(toIndentedString(campaignedProduct)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

