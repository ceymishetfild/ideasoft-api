package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.IOException;

/**
 * MemberGroup
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class MemberGroup {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("name")
  private String name = null;

  @SerializedName("priceIndex")
  private Integer priceIndex = null;

  @SerializedName("allowedPaymentGateways")
  private String allowedPaymentGateways = null;

  public MemberGroup id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Üye Grubu nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Üye Grubu nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public MemberGroup name(String name) {
    this.name = name;
    return this;
  }

   /**
   * Üye Grubu nesnesi için isim değeri.
   * @return name
  **/
  @ApiModelProperty(example = "Üyeler", required = true, value = "Üye Grubu nesnesi için isim değeri.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public MemberGroup priceIndex(Integer priceIndex) {
    this.priceIndex = priceIndex;
    return this;
  }

   /**
   * Üye Grubunun fiyat indisi. Örnek Fiyat 2.
   * minimum: 1
   * maximum: 5
   * @return priceIndex
  **/
  @ApiModelProperty(example = "1", required = true, value = "Üye Grubunun fiyat indisi. Örnek Fiyat 2.")
  public Integer getPriceIndex() {
    return priceIndex;
  }

  public void setPriceIndex(Integer priceIndex) {
    this.priceIndex = priceIndex;
  }

  public MemberGroup allowedPaymentGateways(String allowedPaymentGateways) {
    this.allowedPaymentGateways = allowedPaymentGateways;
    return this;
  }

   /**
   * Üye Grubunun izin verilmiş ödeme kanalları.
   * @return allowedPaymentGateways
  **/
  @ApiModelProperty(example = "custom", required = true, value = "Üye Grubunun izin verilmiş ödeme kanalları.")
  public String getAllowedPaymentGateways() {
    return allowedPaymentGateways;
  }

  public void setAllowedPaymentGateways(String allowedPaymentGateways) {
    this.allowedPaymentGateways = allowedPaymentGateways;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MemberGroup memberGroup = (MemberGroup) o;
    return Objects.equals(this.id, memberGroup.id) &&
        Objects.equals(this.name, memberGroup.name) &&
        Objects.equals(this.priceIndex, memberGroup.priceIndex) &&
        Objects.equals(this.allowedPaymentGateways, memberGroup.allowedPaymentGateways);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, priceIndex, allowedPaymentGateways);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MemberGroup {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    priceIndex: ").append(toIndentedString(priceIndex)).append("\n");
    sb.append("    allowedPaymentGateways: ").append(toIndentedString(allowedPaymentGateways)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

