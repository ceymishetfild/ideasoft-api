package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Member;
import java.io.IOException;
import org.threeten.bp.OffsetDateTime;

/**
 * CurrentAccount
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class CurrentAccount {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("code")
  private String code = null;

  @SerializedName("title")
  private String title = null;

  @SerializedName("balance")
  private Float balance = null;

  @SerializedName("riskLimit")
  private Float riskLimit = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  @SerializedName("member")
  private Member member = null;

  public CurrentAccount id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Cari hesap nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Cari hesap nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public CurrentAccount code(String code) {
    this.code = code;
    return this;
  }

   /**
   * Cari hesap için düzenlenebilir bir kod değeri.
   * @return code
  **/
  @ApiModelProperty(example = "cari-hesap-kod-ornegi", value = "Cari hesap için düzenlenebilir bir kod değeri.")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public CurrentAccount title(String title) {
    this.title = title;
    return this;
  }

   /**
   * Cari hesap nesnesinin başlığı.
   * @return title
  **/
  @ApiModelProperty(example = "Cari Hesap Başlığı", required = true, value = "Cari hesap nesnesinin başlığı.")
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public CurrentAccount balance(Float balance) {
    this.balance = balance;
    return this;
  }

   /**
   * Cari hesabın bakiyesi.
   * @return balance
  **/
  @ApiModelProperty(example = "155.5", value = "Cari hesabın bakiyesi.")
  public Float getBalance() {
    return balance;
  }

  public void setBalance(Float balance) {
    this.balance = balance;
  }

  public CurrentAccount riskLimit(Float riskLimit) {
    this.riskLimit = riskLimit;
    return this;
  }

   /**
   * Cari hesap için belirlenmiş risk limiti.
   * minimum: 0
   * @return riskLimit
  **/
  @ApiModelProperty(example = "155.5", value = "Cari hesap için belirlenmiş risk limiti.")
  public Float getRiskLimit() {
    return riskLimit;
  }

  public void setRiskLimit(Float riskLimit) {
    this.riskLimit = riskLimit;
  }

   /**
   * Cari hesap nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Cari hesap nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

   /**
   * Cari hesap nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Cari hesap nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public CurrentAccount member(Member member) {
    this.member = member;
    return this;
  }

   /**
   * Get member
   * @return member
  **/
  @ApiModelProperty(value = "")
  public Member getMember() {
    return member;
  }

  public void setMember(Member member) {
    this.member = member;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CurrentAccount currentAccount = (CurrentAccount) o;
    return Objects.equals(this.id, currentAccount.id) &&
        Objects.equals(this.code, currentAccount.code) &&
        Objects.equals(this.title, currentAccount.title) &&
        Objects.equals(this.balance, currentAccount.balance) &&
        Objects.equals(this.riskLimit, currentAccount.riskLimit) &&
        Objects.equals(this.createdAt, currentAccount.createdAt) &&
        Objects.equals(this.updatedAt, currentAccount.updatedAt) &&
        Objects.equals(this.member, currentAccount.member);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, code, title, balance, riskLimit, createdAt, updatedAt, member);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CurrentAccount {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    balance: ").append(toIndentedString(balance)).append("\n");
    sb.append("    riskLimit: ").append(toIndentedString(riskLimit)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    member: ").append(toIndentedString(member)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

