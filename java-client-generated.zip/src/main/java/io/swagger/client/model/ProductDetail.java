package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Product;
import java.io.IOException;

/**
 * ProductDetail
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ProductDetail {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("sku")
  private String sku = null;

  @SerializedName("details")
  private String details = null;

  @SerializedName("extraDetails")
  private String extraDetails = null;

  @SerializedName("product")
  private Product product = null;

  public ProductDetail id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Ürün detayı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Ürün detayı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductDetail sku(String sku) {
    this.sku = sku;
    return this;
  }

   /**
   * Ürünün stok kodu.
   * @return sku
  **/
  @ApiModelProperty(example = "KAL-1234", value = "Ürünün stok kodu.")
  public String getSku() {
    return sku;
  }

  public void setSku(String sku) {
    this.sku = sku;
  }

  public ProductDetail details(String details) {
    this.details = details;
    return this;
  }

   /**
   * Detay bilgisi.
   * @return details
  **/
  @ApiModelProperty(example = "<div><strong><br /><table style=\"border-collapse:collapse;width:100%;\"><tbody><tr><td>&nbsp;Özellik</td><td>Tipi&nbsp;</td></tr><tr><td>&nbsp;Uç tipi</td><td>&nbsp;2B</td></tr></tbody></table></strong></div><br/>", value = "Detay bilgisi.")
  public String getDetails() {
    return details;
  }

  public void setDetails(String details) {
    this.details = details;
  }

  public ProductDetail extraDetails(String extraDetails) {
    this.extraDetails = extraDetails;
    return this;
  }

   /**
   * Ürün ekstra detaylı bilgi.
   * @return extraDetails
  **/
  @ApiModelProperty(example = "Ekstra detay.", value = "Ürün ekstra detaylı bilgi.")
  public String getExtraDetails() {
    return extraDetails;
  }

  public void setExtraDetails(String extraDetails) {
    this.extraDetails = extraDetails;
  }

  public ProductDetail product(Product product) {
    this.product = product;
    return this;
  }

   /**
   * Get product
   * @return product
  **/
  @ApiModelProperty(value = "")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProductDetail productDetail = (ProductDetail) o;
    return Objects.equals(this.id, productDetail.id) &&
        Objects.equals(this.sku, productDetail.sku) &&
        Objects.equals(this.details, productDetail.details) &&
        Objects.equals(this.extraDetails, productDetail.extraDetails) &&
        Objects.equals(this.product, productDetail.product);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, sku, details, extraDetails, product);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductDetail {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    sku: ").append(toIndentedString(sku)).append("\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("    extraDetails: ").append(toIndentedString(extraDetails)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

