package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Order;
import java.io.IOException;
import org.threeten.bp.OffsetDateTime;

/**
 * Shipment
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Shipment {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("barcode")
  private String barcode = null;

  @SerializedName("waybillNo")
  private String waybillNo = null;

  @SerializedName("invoiceKey")
  private String invoiceKey = null;

  @SerializedName("cargoOffice")
  private String cargoOffice = null;

  @SerializedName("code")
  private String code = null;

  @SerializedName("deliveryType")
  private String deliveryType = null;

  /**
   * Faturanın pakete dahillik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Dahil.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Dahil değil.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(InvoiceIncludedEnum.Adapter.class)
  public enum InvoiceIncludedEnum {
    _0("0"),
    
    _1("1");

    private String value;

    InvoiceIncludedEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static InvoiceIncludedEnum fromValue(String text) {
      for (InvoiceIncludedEnum b : InvoiceIncludedEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<InvoiceIncludedEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final InvoiceIncludedEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public InvoiceIncludedEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return InvoiceIncludedEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("invoiceIncluded")
  private InvoiceIncludedEnum invoiceIncluded = null;

  @SerializedName("payAtDoorAmount")
  private Float payAtDoorAmount = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  /**
   * Teslimat nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    NUMBER_0(0),
    
    NUMBER_1(1);

    private Integer value;

    StatusEnum(Integer value) {
      this.value = value;
    }

    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        Integer value = jsonReader.nextInt();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  @SerializedName("order")
  private Order order = null;

  public Shipment id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Teslimat nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Teslimat nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Shipment barcode(String barcode) {
    this.barcode = barcode;
    return this;
  }

   /**
   * Teslimat barkodu.
   * @return barcode
  **/
  @ApiModelProperty(example = "12345678ASD", value = "Teslimat barkodu.")
  public String getBarcode() {
    return barcode;
  }

  public void setBarcode(String barcode) {
    this.barcode = barcode;
  }

  public Shipment waybillNo(String waybillNo) {
    this.waybillNo = waybillNo;
    return this;
  }

   /**
   * Teslimat fatura numarası.
   * @return waybillNo
  **/
  @ApiModelProperty(example = "A-1002", value = "Teslimat fatura numarası.")
  public String getWaybillNo() {
    return waybillNo;
  }

  public void setWaybillNo(String waybillNo) {
    this.waybillNo = waybillNo;
  }

  public Shipment invoiceKey(String invoiceKey) {
    this.invoiceKey = invoiceKey;
    return this;
  }

   /**
   * Teslimat irsaliye makbuzu numarası.
   * @return invoiceKey
  **/
  @ApiModelProperty(example = "A-1231", value = "Teslimat irsaliye makbuzu numarası.")
  public String getInvoiceKey() {
    return invoiceKey;
  }

  public void setInvoiceKey(String invoiceKey) {
    this.invoiceKey = invoiceKey;
  }

  public Shipment cargoOffice(String cargoOffice) {
    this.cargoOffice = cargoOffice;
    return this;
  }

   /**
   * Teslimatın kargo şubesi
   * @return cargoOffice
  **/
  @ApiModelProperty(example = "Üsküdar", value = "Teslimatın kargo şubesi")
  public String getCargoOffice() {
    return cargoOffice;
  }

  public void setCargoOffice(String cargoOffice) {
    this.cargoOffice = cargoOffice;
  }

  public Shipment code(String code) {
    this.code = code;
    return this;
  }

   /**
   * Teslimat kodu. Kargo takip kodu.
   * @return code
  **/
  @ApiModelProperty(example = "KOD123456", value = "Teslimat kodu. Kargo takip kodu.")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public Shipment deliveryType(String deliveryType) {
    this.deliveryType = deliveryType;
    return this;
  }

   /**
   * Teslimat tipi
   * @return deliveryType
  **/
  @ApiModelProperty(example = "deliveryType", value = "Teslimat tipi")
  public String getDeliveryType() {
    return deliveryType;
  }

  public void setDeliveryType(String deliveryType) {
    this.deliveryType = deliveryType;
  }

  public Shipment invoiceIncluded(InvoiceIncludedEnum invoiceIncluded) {
    this.invoiceIncluded = invoiceIncluded;
    return this;
  }

   /**
   * Faturanın pakete dahillik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Dahil.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Dahil değil.&lt;br&gt;&lt;/div&gt;
   * @return invoiceIncluded
  **/
  @ApiModelProperty(example = "1", value = "Faturanın pakete dahillik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Dahil.<br><code>0</code> : Dahil değil.<br></div>")
  public InvoiceIncludedEnum getInvoiceIncluded() {
    return invoiceIncluded;
  }

  public void setInvoiceIncluded(InvoiceIncludedEnum invoiceIncluded) {
    this.invoiceIncluded = invoiceIncluded;
  }

  public Shipment payAtDoorAmount(Float payAtDoorAmount) {
    this.payAtDoorAmount = payAtDoorAmount;
    return this;
  }

   /**
   * Kapıda ödeme hizmeti bedeli.
   * minimum: 0
   * @return payAtDoorAmount
  **/
  @ApiModelProperty(example = "5.0", value = "Kapıda ödeme hizmeti bedeli.")
  public Float getPayAtDoorAmount() {
    return payAtDoorAmount;
  }

  public void setPayAtDoorAmount(Float payAtDoorAmount) {
    this.payAtDoorAmount = payAtDoorAmount;
  }

   /**
   * Teslimat nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Teslimat nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

  public Shipment status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Teslimat nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @ApiModelProperty(example = "1", required = true, value = "Teslimat nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Shipment order(Order order) {
    this.order = order;
    return this;
  }

   /**
   * Get order
   * @return order
  **/
  @ApiModelProperty(value = "")
  public Order getOrder() {
    return order;
  }

  public void setOrder(Order order) {
    this.order = order;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Shipment shipment = (Shipment) o;
    return Objects.equals(this.id, shipment.id) &&
        Objects.equals(this.barcode, shipment.barcode) &&
        Objects.equals(this.waybillNo, shipment.waybillNo) &&
        Objects.equals(this.invoiceKey, shipment.invoiceKey) &&
        Objects.equals(this.cargoOffice, shipment.cargoOffice) &&
        Objects.equals(this.code, shipment.code) &&
        Objects.equals(this.deliveryType, shipment.deliveryType) &&
        Objects.equals(this.invoiceIncluded, shipment.invoiceIncluded) &&
        Objects.equals(this.payAtDoorAmount, shipment.payAtDoorAmount) &&
        Objects.equals(this.createdAt, shipment.createdAt) &&
        Objects.equals(this.status, shipment.status) &&
        Objects.equals(this.order, shipment.order);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, barcode, waybillNo, invoiceKey, cargoOffice, code, deliveryType, invoiceIncluded, payAtDoorAmount, createdAt, status, order);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Shipment {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    barcode: ").append(toIndentedString(barcode)).append("\n");
    sb.append("    waybillNo: ").append(toIndentedString(waybillNo)).append("\n");
    sb.append("    invoiceKey: ").append(toIndentedString(invoiceKey)).append("\n");
    sb.append("    cargoOffice: ").append(toIndentedString(cargoOffice)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    deliveryType: ").append(toIndentedString(deliveryType)).append("\n");
    sb.append("    invoiceIncluded: ").append(toIndentedString(invoiceIncluded)).append("\n");
    sb.append("    payAtDoorAmount: ").append(toIndentedString(payAtDoorAmount)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    order: ").append(toIndentedString(order)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

