package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Product;
import io.swagger.client.model.Tag;
import java.io.IOException;

/**
 * ProductToTag
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ProductToTag {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("product")
  private Product product = null;

  @SerializedName("tag")
  private Tag tag = null;

  public ProductToTag id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Ürün SEO+ etiketi bağı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Ürün SEO+ etiketi bağı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductToTag product(Product product) {
    this.product = product;
    return this;
  }

   /**
   * Get product
   * @return product
  **/
  @ApiModelProperty(value = "")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public ProductToTag tag(Tag tag) {
    this.tag = tag;
    return this;
  }

   /**
   * Get tag
   * @return tag
  **/
  @ApiModelProperty(value = "")
  public Tag getTag() {
    return tag;
  }

  public void setTag(Tag tag) {
    this.tag = tag;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProductToTag productToTag = (ProductToTag) o;
    return Objects.equals(this.id, productToTag.id) &&
        Objects.equals(this.product, productToTag.product) &&
        Objects.equals(this.tag, productToTag.tag);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, product, tag);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductToTag {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("    tag: ").append(toIndentedString(tag)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

