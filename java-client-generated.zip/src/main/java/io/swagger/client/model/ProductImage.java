package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Product;
import java.io.IOException;

/**
 * ProductImage
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ProductImage {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("filename")
  private String filename = null;

  /**
   * Resim için geçerli dosya uzantıları.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;jpg&lt;/code&gt; : jpg dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;png&lt;/code&gt; : png dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;gif&lt;/code&gt; : gif dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;jpeg&lt;/code&gt; : jpeg dosyaları için geçerli uzantı.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(ExtensionEnum.Adapter.class)
  public enum ExtensionEnum {
    JPG("jpg"),
    
    PNG("png"),
    
    GIF("gif"),
    
    JPEG("jpeg");

    private String value;

    ExtensionEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static ExtensionEnum fromValue(String text) {
      for (ExtensionEnum b : ExtensionEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<ExtensionEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final ExtensionEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public ExtensionEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return ExtensionEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("extension")
  private ExtensionEnum extension = null;

  @SerializedName("directoryName")
  private String directoryName = null;

  @SerializedName("revision")
  private String revision = null;

  @SerializedName("sortOrder")
  private Integer sortOrder = null;

  @SerializedName("product")
  private Product product = null;

  @SerializedName("attachment")
  private String attachment = null;

  public ProductImage id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Ürün resmi nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Ürün resmi nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductImage filename(String filename) {
    this.filename = filename;
    return this;
  }

   /**
   * Ürün resminin dosya adı. Uzantı olmadan yazılmalıdır.
   * @return filename
  **/
  @ApiModelProperty(example = "ornek-urun-gorseli", required = true, value = "Ürün resminin dosya adı. Uzantı olmadan yazılmalıdır.")
  public String getFilename() {
    return filename;
  }

  public void setFilename(String filename) {
    this.filename = filename;
  }

  public ProductImage extension(ExtensionEnum extension) {
    this.extension = extension;
    return this;
  }

   /**
   * Resim için geçerli dosya uzantıları.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;jpg&lt;/code&gt; : jpg dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;png&lt;/code&gt; : png dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;gif&lt;/code&gt; : gif dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;jpeg&lt;/code&gt; : jpeg dosyaları için geçerli uzantı.&lt;br&gt;&lt;/div&gt;
   * @return extension
  **/
  @ApiModelProperty(example = "jpg", required = true, value = "Resim için geçerli dosya uzantıları.<div class='idea_choice_list'><code>jpg</code> : jpg dosyaları için geçerli uzantı.<br><code>png</code> : png dosyaları için geçerli uzantı.<br><code>gif</code> : gif dosyaları için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyaları için geçerli uzantı.<br></div>")
  public ExtensionEnum getExtension() {
    return extension;
  }

  public void setExtension(ExtensionEnum extension) {
    this.extension = extension;
  }

   /**
   * Dosya konumu adı. API otomatik oluşturur.
   * @return directoryName
  **/
  @ApiModelProperty(example = "030", value = "Dosya konumu adı. API otomatik oluşturur.")
  public String getDirectoryName() {
    return directoryName;
  }

   /**
   * Revision değeri aynı isimle eklediğiniz resimlerin ön bellekten yüklenmesini engellemek için gerekli bir değerdir. Aynı isimle tekrardan resim yüklenirken bir önceki resimden farklı bir değer almalıdır.
   * @return revision
  **/
  @ApiModelProperty(example = "1000", value = "Revision değeri aynı isimle eklediğiniz resimlerin ön bellekten yüklenmesini engellemek için gerekli bir değerdir. Aynı isimle tekrardan resim yüklenirken bir önceki resimden farklı bir değer almalıdır.")
  public String getRevision() {
    return revision;
  }

  public ProductImage sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

   /**
   * Resmin sıralama değeri. Ürün içerisindeki 8 fotoğraf içinden hangisi olacağını belirler.
   * minimum: 1
   * maximum: 8
   * @return sortOrder
  **/
  @ApiModelProperty(example = "1", required = true, value = "Resmin sıralama değeri. Ürün içerisindeki 8 fotoğraf içinden hangisi olacağını belirler.")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public ProductImage product(Product product) {
    this.product = product;
    return this;
  }

   /**
   * Get product
   * @return product
  **/
  @ApiModelProperty(value = "")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public ProductImage attachment(String attachment) {
    this.attachment = attachment;
    return this;
  }

   /**
   * Ürün resminin base64 formatına çevrilmiş resim kodu. Oluşturma(POST) isteği esnasında başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
   * @return attachment
  **/
  @ApiModelProperty(example = "data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAABvJJREFUeNrEV2uMVdUV/va55z5nhnnB8BAmwoAOFSJohBTb0FFSjSFggzFqYmx/VFPbxl8lRGvxj9FE0aCJ0cT4qCaaKIZUkzGhFUUgqfKIaGRAlNIZBmZg3o/7OI/db+1zzp1zZy6JNkFPZs85556z1/r2t7619jpKa42f8rDl3/OLFv2ydcGCvzfmsvWu5/mAukzuNKxEwhovOsUzZ3v+/MczZ941AFoXzH/ntoXz53oDA9CWOFeXbcXK95CcOxt7tPcybwMA9ZlM1um/gPzkJLSacq5iZ6V9+Moy9xbD5ofv/dAAKs7NEkTKtnU5BI7rOm4iAZ+udOgkPqHIc6HkopZOSSGGPV6nUnybINQPZIsLcVUCHg+zmOA3H5484Hq8aQOug75cBmd2Pge1YgW+yeVwevtj8NJpaALRnOfBN+9qBNe6ip2KwTnis8yAZIJvhprBqWMl0HS+Dw0tczHrllsxdGA/1l91NQr9/ciTAZmXIijRjlMswSawQrGIRC7Lp9ZMOelgTpR9hgHfMEBkaiZalwZsJsbI229hfPUq1G3YAOvDTnxHZ4fufwAjjz8OtyaH72Y34793340+hub4vfdCJ214jPWM1YsPWWzIQBBwOnAjENOHEJoh3R/vhbN4CdZuuQNDu3ej9557cONVy9CcziL74J/gZWvQfvvtKFJDS3+zhVpJMs5uVZviS3xOMaAj56gyFErJJFI9PRj98hgyfX0Y7epCy/KfIXX4MI6/8TrQ1CQ0wptgFlFbenKC9nnvX8qmNj7LGhA6HNLlBoKoljyw+fzC4SOYl8/DLRQCBwQGxtx3XRoMtBSIkdqVlWpd1Z5FW36FCL0I7SWyOsx7V9QrZw5tW/CoA5+C0zZTWPRLIE5+wthSId3VAMhz7U1jwJWMu2RZkQTj/wyVXVtrwKQuDsFdvx5uczNw7pzUEiSWLsXExs1oWLQQgwyFYaCKTUujUoQSD1d7M2Il7ygiTZQcMylz7AtMfvIJkrU1yL7yMrzz57CqqRHDO3ei6WwP3P37cXUmA2/XLmiGyQ9XO92u+Io0oCRuu9rbL7alU81OSJcOy22C9P6H5blYVwfLItYijRKQohPlOPCoB0vCwXt57k2MB2f+lszVoDk/ibpUmsgzFRUzyetvi6WBLV1ds8NCRBHSYQRAnCs6/4gTFz+9A+tItQFA50UaNfTpwGYynYLrckVSWaN4W1JvEhg7ehSj2/+G9PCwEWschI5nQYmTHVF1OUYa33LlrU89hV9v3IgBpqAne0WphLbFiyvieWFwEI3z5gSGph/z5+M055x+8A9IskDFRV0KtoJQA0TmxAsF6c1TbNd33IR3H34Y/7h2JTpXrcKeDTdjpKe7wscLmzeju7MzUHdY0uNHY3s73KQUJa9s34ntplYU9EAc4fB9o4Pi6Ch+++STuPbR7biytRW/P3IUY9wbximw7t5ejNLQPKkDY2M41d0d6IHjyKFD6GVmGFBkQITomLoQ2PdiyWFFoqsslwKCEzhZjqGaGowxBKq+Hq/cdx969+3DGw/cj57OD5FumYODL72E99atw8iJE3htxzP4gCV5D0M31NcPTeqnquyUj4inMgCpAfEhEZIKZ0JkVkGd8LqB23NOznynlmMyX0DH1r9g4ZobcPbIYVx8fzd+9+qrKM2Zg/5//RNIJc2GNt2+jveEcitFw4+JJL5jRbulyWtuNq7RTSI4y+8sUEPJFIuRh7pcLT565BEUGL7MrFkmQ6KSrGJbcAQhBKDKDqIWzFAVAgiuA1ZkWKTVt204RlgeVMJiP0BgZGeS+tj06F/Rk83BWbIE9uiIma9iAHToc0qEmLljiWvJbXnZodEi01KcuwzLV3v34vyxY2wwWT8KJZzc9yn6Gf9MTS1sgvum6wTefOghDB48CJ1OVd0RK9pyP6I81gf6UXryPIvxTF5zDTTTc1lHB4bpfMXq1VANDVhw3XUYPH4cS1gtW9aswS9I++dbt+JXy5dj2aZNGD51yuyQ0xmI0tWOKI8Lw2d7leWePs4C5KxciZ/feSd8jiJLb8e2bbBIv1Q12ZZvWbsWCd77UppptO2KK3DlgQOwqQubXdHAZ5/BZVW1crly7vmxjtsup2G8FaDQcnyl+4kn0MKJzW1twZbMkCjLqqhoSnI/NChilXtFQIWREfQxVF8/swOKNuK0q1jraU9RAlR8pkmjefIk/n3XXUg11JsW/Pt+xhlQBFscGjRNqiXFKtbsGFtxACJGr9rOTRCKhkpj4+HD7/kZIkvkn0VRSnZ401pjFatBUVueSkhMqxkinULp//81OPNIGM0hU0bBQrHN8f0f7YvYDTrjZ+MheJEKZnXVjQG4y3oIAXmOHXLzPwEGAGpnmoeyFBLeAAAAAElFTkSuQmCC", required = true, value = "Ürün resminin base64 formatına çevrilmiş resim kodu. Oluşturma(POST) isteği esnasında başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.")
  public String getAttachment() {
    return attachment;
  }

  public void setAttachment(String attachment) {
    this.attachment = attachment;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProductImage productImage = (ProductImage) o;
    return Objects.equals(this.id, productImage.id) &&
        Objects.equals(this.filename, productImage.filename) &&
        Objects.equals(this.extension, productImage.extension) &&
        Objects.equals(this.directoryName, productImage.directoryName) &&
        Objects.equals(this.revision, productImage.revision) &&
        Objects.equals(this.sortOrder, productImage.sortOrder) &&
        Objects.equals(this.product, productImage.product) &&
        Objects.equals(this.attachment, productImage.attachment);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, filename, extension, directoryName, revision, sortOrder, product, attachment);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductImage {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    filename: ").append(toIndentedString(filename)).append("\n");
    sb.append("    extension: ").append(toIndentedString(extension)).append("\n");
    sb.append("    directoryName: ").append(toIndentedString(directoryName)).append("\n");
    sb.append("    revision: ").append(toIndentedString(revision)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("    attachment: ").append(toIndentedString(attachment)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

