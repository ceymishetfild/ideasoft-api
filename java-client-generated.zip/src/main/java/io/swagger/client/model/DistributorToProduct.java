package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Distributor;
import io.swagger.client.model.Product;
import java.io.IOException;

/**
 * DistributorToProduct
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class DistributorToProduct {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("distributor")
  private Distributor distributor = null;

  @SerializedName("product")
  private Product product = null;

  public DistributorToProduct id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Distribütor ürün bağı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Distribütor ürün bağı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public DistributorToProduct distributor(Distributor distributor) {
    this.distributor = distributor;
    return this;
  }

   /**
   * Get distributor
   * @return distributor
  **/
  @ApiModelProperty(value = "")
  public Distributor getDistributor() {
    return distributor;
  }

  public void setDistributor(Distributor distributor) {
    this.distributor = distributor;
  }

  public DistributorToProduct product(Product product) {
    this.product = product;
    return this;
  }

   /**
   * Get product
   * @return product
  **/
  @ApiModelProperty(value = "")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DistributorToProduct distributorToProduct = (DistributorToProduct) o;
    return Objects.equals(this.id, distributorToProduct.id) &&
        Objects.equals(this.distributor, distributorToProduct.distributor) &&
        Objects.equals(this.product, distributorToProduct.product);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, distributor, product);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DistributorToProduct {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    distributor: ").append(toIndentedString(distributor)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

