package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.ExtraInfo;
import io.swagger.client.model.Product;
import java.io.IOException;

/**
 * ExtraInfoToProduct
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ExtraInfoToProduct {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("value")
  private String value = null;

  @SerializedName("extraInfo")
  private ExtraInfo extraInfo = null;

  @SerializedName("product")
  private Product product = null;

  public ExtraInfoToProduct id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Ek bilgi ürün bağı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Ek bilgi ürün bağı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ExtraInfoToProduct value(String value) {
    this.value = value;
    return this;
  }

   /**
   * Ek bilgi ürün bağı değeridir. Ek bilgi renk ise bu değer kırmızı olabilir.
   * @return value
  **/
  @ApiModelProperty(example = "Kırmızı", required = true, value = "Ek bilgi ürün bağı değeridir. Ek bilgi renk ise bu değer kırmızı olabilir.")
  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public ExtraInfoToProduct extraInfo(ExtraInfo extraInfo) {
    this.extraInfo = extraInfo;
    return this;
  }

   /**
   * Get extraInfo
   * @return extraInfo
  **/
  @ApiModelProperty(value = "")
  public ExtraInfo getExtraInfo() {
    return extraInfo;
  }

  public void setExtraInfo(ExtraInfo extraInfo) {
    this.extraInfo = extraInfo;
  }

  public ExtraInfoToProduct product(Product product) {
    this.product = product;
    return this;
  }

   /**
   * Get product
   * @return product
  **/
  @ApiModelProperty(value = "")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ExtraInfoToProduct extraInfoToProduct = (ExtraInfoToProduct) o;
    return Objects.equals(this.id, extraInfoToProduct.id) &&
        Objects.equals(this.value, extraInfoToProduct.value) &&
        Objects.equals(this.extraInfo, extraInfoToProduct.extraInfo) &&
        Objects.equals(this.product, extraInfoToProduct.product);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, value, extraInfo, product);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ExtraInfoToProduct {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    value: ").append(toIndentedString(value)).append("\n");
    sb.append("    extraInfo: ").append(toIndentedString(extraInfo)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

