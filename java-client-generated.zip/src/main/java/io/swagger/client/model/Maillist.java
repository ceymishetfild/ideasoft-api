package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.MaillistGroup;
import java.io.IOException;
import org.threeten.bp.OffsetDateTime;

/**
 * Maillist
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Maillist {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("name")
  private String name = null;

  @SerializedName("email")
  private String email = null;

  @SerializedName("lastMailSentDate")
  private OffsetDateTime lastMailSentDate = null;

  @SerializedName("creatorIpAddress")
  private String creatorIpAddress = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  @SerializedName("maillistGroup")
  private MaillistGroup maillistGroup = null;

  public Maillist id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Mail listesi nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Mail listesi nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Maillist name(String name) {
    this.name = name;
    return this;
  }

   /**
   * Mail listesi nesnesi için isim değeri.
   * @return name
  **/
  @ApiModelProperty(example = "Mail listesi", required = true, value = "Mail listesi nesnesi için isim değeri.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Maillist email(String email) {
    this.email = email;
    return this;
  }

   /**
   * Ziyaretçi veya üyenin mail adresi.
   * @return email
  **/
  @ApiModelProperty(example = "johndoe@ideasoft.com.tr", required = true, value = "Ziyaretçi veya üyenin mail adresi.")
  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public Maillist lastMailSentDate(OffsetDateTime lastMailSentDate) {
    this.lastMailSentDate = lastMailSentDate;
    return this;
  }

   /**
   * En son e-mail gönderilen zaman.
   * @return lastMailSentDate
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "En son e-mail gönderilen zaman.")
  public OffsetDateTime getLastMailSentDate() {
    return lastMailSentDate;
  }

  public void setLastMailSentDate(OffsetDateTime lastMailSentDate) {
    this.lastMailSentDate = lastMailSentDate;
  }

  public Maillist creatorIpAddress(String creatorIpAddress) {
    this.creatorIpAddress = creatorIpAddress;
    return this;
  }

   /**
   * Mail listesi nesnesini oluşturan kişinin IP adresi.
   * @return creatorIpAddress
  **/
  @ApiModelProperty(example = "192.168.1.1", value = "Mail listesi nesnesini oluşturan kişinin IP adresi.")
  public String getCreatorIpAddress() {
    return creatorIpAddress;
  }

  public void setCreatorIpAddress(String creatorIpAddress) {
    this.creatorIpAddress = creatorIpAddress;
  }

   /**
   * Mail listesi nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", required = true, value = "Mail listesi nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

   /**
   * Mail listesi nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", required = true, value = "Mail listesi nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public Maillist maillistGroup(MaillistGroup maillistGroup) {
    this.maillistGroup = maillistGroup;
    return this;
  }

   /**
   * Get maillistGroup
   * @return maillistGroup
  **/
  @ApiModelProperty(value = "")
  public MaillistGroup getMaillistGroup() {
    return maillistGroup;
  }

  public void setMaillistGroup(MaillistGroup maillistGroup) {
    this.maillistGroup = maillistGroup;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Maillist maillist = (Maillist) o;
    return Objects.equals(this.id, maillist.id) &&
        Objects.equals(this.name, maillist.name) &&
        Objects.equals(this.email, maillist.email) &&
        Objects.equals(this.lastMailSentDate, maillist.lastMailSentDate) &&
        Objects.equals(this.creatorIpAddress, maillist.creatorIpAddress) &&
        Objects.equals(this.createdAt, maillist.createdAt) &&
        Objects.equals(this.updatedAt, maillist.updatedAt) &&
        Objects.equals(this.maillistGroup, maillist.maillistGroup);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, email, lastMailSentDate, creatorIpAddress, createdAt, updatedAt, maillistGroup);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Maillist {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    lastMailSentDate: ").append(toIndentedString(lastMailSentDate)).append("\n");
    sb.append("    creatorIpAddress: ").append(toIndentedString(creatorIpAddress)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    maillistGroup: ").append(toIndentedString(maillistGroup)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

