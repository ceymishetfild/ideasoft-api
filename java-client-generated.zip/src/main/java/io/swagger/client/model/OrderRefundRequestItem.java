package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.OrderItem;
import io.swagger.client.model.OrderRefundRequest;
import java.io.IOException;
import org.threeten.bp.OffsetDateTime;

/**
 * OrderRefundRequestItem
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class OrderRefundRequestItem {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("amount")
  private Float amount = null;

  @SerializedName("reason")
  private String reason = null;

  @SerializedName("details")
  private String details = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  @SerializedName("orderItem")
  private OrderItem orderItem = null;

  @SerializedName("orderRefundRequest")
  private OrderRefundRequest orderRefundRequest = null;

  public OrderRefundRequestItem id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Sipariş iptal talebi kalemi nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Sipariş iptal talebi kalemi nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OrderRefundRequestItem amount(Float amount) {
    this.amount = amount;
    return this;
  }

   /**
   * Sipariş iptal talebi istenen ürün miktarı.
   * minimum: 0
   * @return amount
  **/
  @ApiModelProperty(example = "1.0", required = true, value = "Sipariş iptal talebi istenen ürün miktarı.")
  public Float getAmount() {
    return amount;
  }

  public void setAmount(Float amount) {
    this.amount = amount;
  }

  public OrderRefundRequestItem reason(String reason) {
    this.reason = reason;
    return this;
  }

   /**
   * Sipariş iptal talebi sebebi. Tanımlı dört seçenekten biri seçilmelidir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Ürünü iade etmek istiyorum.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Ürünü değiştirmek istiyorum.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Faturadaki ürünler ile bana gelen ürünler farklı.&lt;/code&gt; : &lt;br&gt;&lt;code&gt;Diğer&lt;/code&gt; : &lt;br&gt;&lt;/div&gt;
   * @return reason
  **/
  @ApiModelProperty(example = "Ürünü iade etmek istiyorum.", required = true, value = "Sipariş iptal talebi sebebi. Tanımlı dört seçenekten biri seçilmelidir.<div class='idea_choice_list'><code>Ürünü iade etmek istiyorum.</code> : <br><code>Ürünü değiştirmek istiyorum.</code> : <br><code>Faturadaki ürünler ile bana gelen ürünler farklı.</code> : <br><code>Diğer</code> : <br></div>")
  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }

  public OrderRefundRequestItem details(String details) {
    this.details = details;
    return this;
  }

   /**
   * Sipariş iptal talebinin detaylı açıklaması.
   * @return details
  **/
  @ApiModelProperty(example = "Ürünü iade etmek istiyorum. Çünkü ürünü beğenmedim.", required = true, value = "Sipariş iptal talebinin detaylı açıklaması.")
  public String getDetails() {
    return details;
  }

  public void setDetails(String details) {
    this.details = details;
  }

   /**
   * Sipariş iptal talebi kalemi nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Sipariş iptal talebi kalemi nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

   /**
   * Sipariş iptal talebi kalemi nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Sipariş iptal talebi kalemi nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public OrderRefundRequestItem orderItem(OrderItem orderItem) {
    this.orderItem = orderItem;
    return this;
  }

   /**
   * Get orderItem
   * @return orderItem
  **/
  @ApiModelProperty(value = "")
  public OrderItem getOrderItem() {
    return orderItem;
  }

  public void setOrderItem(OrderItem orderItem) {
    this.orderItem = orderItem;
  }

  public OrderRefundRequestItem orderRefundRequest(OrderRefundRequest orderRefundRequest) {
    this.orderRefundRequest = orderRefundRequest;
    return this;
  }

   /**
   * Get orderRefundRequest
   * @return orderRefundRequest
  **/
  @ApiModelProperty(value = "")
  public OrderRefundRequest getOrderRefundRequest() {
    return orderRefundRequest;
  }

  public void setOrderRefundRequest(OrderRefundRequest orderRefundRequest) {
    this.orderRefundRequest = orderRefundRequest;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrderRefundRequestItem orderRefundRequestItem = (OrderRefundRequestItem) o;
    return Objects.equals(this.id, orderRefundRequestItem.id) &&
        Objects.equals(this.amount, orderRefundRequestItem.amount) &&
        Objects.equals(this.reason, orderRefundRequestItem.reason) &&
        Objects.equals(this.details, orderRefundRequestItem.details) &&
        Objects.equals(this.createdAt, orderRefundRequestItem.createdAt) &&
        Objects.equals(this.updatedAt, orderRefundRequestItem.updatedAt) &&
        Objects.equals(this.orderItem, orderRefundRequestItem.orderItem) &&
        Objects.equals(this.orderRefundRequest, orderRefundRequestItem.orderRefundRequest);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, amount, reason, details, createdAt, updatedAt, orderItem, orderRefundRequest);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderRefundRequestItem {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    reason: ").append(toIndentedString(reason)).append("\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    orderItem: ").append(toIndentedString(orderItem)).append("\n");
    sb.append("    orderRefundRequest: ").append(toIndentedString(orderRefundRequest)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

