package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.SpecGroup;
import java.io.IOException;

/**
 * SpecName
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class SpecName {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("name")
  private String name = null;

  /**
   * Özellik tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(ChoiceTypeEnum.Adapter.class)
  public enum ChoiceTypeEnum {
    SINGULAR("singular"),
    
    PLURAL("plural");

    private String value;

    ChoiceTypeEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static ChoiceTypeEnum fromValue(String text) {
      for (ChoiceTypeEnum b : ChoiceTypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<ChoiceTypeEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final ChoiceTypeEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public ChoiceTypeEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return ChoiceTypeEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("choiceType")
  private ChoiceTypeEnum choiceType = null;

  @SerializedName("sortOrder")
  private Integer sortOrder = null;

  /**
   * Ürün özelliği aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    _0("0"),
    
    _1("1");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  @SerializedName("specGroup")
  private SpecGroup specGroup = null;

  public SpecName id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Ürün özelliği nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Ürün özelliği nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public SpecName name(String name) {
    this.name = name;
    return this;
  }

   /**
   * Ürün özelliği nesnesi için isim değeri.
   * @return name
  **/
  @ApiModelProperty(example = "Kapasite", required = true, value = "Ürün özelliği nesnesi için isim değeri.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public SpecName choiceType(ChoiceTypeEnum choiceType) {
    this.choiceType = choiceType;
    return this;
  }

   /**
   * Özellik tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul&lt;br&gt;&lt;/div&gt;
   * @return choiceType
  **/
  @ApiModelProperty(example = "singular", required = true, value = "Özellik tipini belirtir.<div class='idea_choice_list'><code>singular</code> : Tekil<br><code>plural</code> : Çoğul<br></div>")
  public ChoiceTypeEnum getChoiceType() {
    return choiceType;
  }

  public void setChoiceType(ChoiceTypeEnum choiceType) {
    this.choiceType = choiceType;
  }

  public SpecName sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

   /**
   * Ürün özelliği sıralama değeri.
   * minimum: 0
   * maximum: 999
   * @return sortOrder
  **/
  @ApiModelProperty(example = "999", value = "Ürün özelliği sıralama değeri.")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public SpecName status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Ürün özelliği aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @ApiModelProperty(example = "1", required = true, value = "Ürün özelliği aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public SpecName specGroup(SpecGroup specGroup) {
    this.specGroup = specGroup;
    return this;
  }

   /**
   * Get specGroup
   * @return specGroup
  **/
  @ApiModelProperty(value = "")
  public SpecGroup getSpecGroup() {
    return specGroup;
  }

  public void setSpecGroup(SpecGroup specGroup) {
    this.specGroup = specGroup;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SpecName specName = (SpecName) o;
    return Objects.equals(this.id, specName.id) &&
        Objects.equals(this.name, specName.name) &&
        Objects.equals(this.choiceType, specName.choiceType) &&
        Objects.equals(this.sortOrder, specName.sortOrder) &&
        Objects.equals(this.status, specName.status) &&
        Objects.equals(this.specGroup, specName.specGroup);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, choiceType, sortOrder, status, specGroup);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SpecName {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    choiceType: ").append(toIndentedString(choiceType)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    specGroup: ").append(toIndentedString(specGroup)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

