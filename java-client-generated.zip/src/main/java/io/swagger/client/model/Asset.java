package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.IOException;
import org.threeten.bp.OffsetDateTime;

/**
 * Asset
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Asset {
  @SerializedName("key")
  private String key = null;

  @SerializedName("contentType")
  private String contentType = null;

  @SerializedName("attachment")
  private String attachment = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  public Asset key(String key) {
    this.key = key;
    return this;
  }

   /**
   * Tema Dosyası nesnesi anahtar değeri.
   * @return key
  **/
  @ApiModelProperty(example = "configs/settings_data.json", value = "Tema Dosyası nesnesi anahtar değeri.")
  public String getKey() {
    return key;
  }

  public void setKey(String key) {
    this.key = key;
  }

  public Asset contentType(String contentType) {
    this.contentType = contentType;
    return this;
  }

   /**
   * Tema Dosyası içerik tipi. Geçerli bir MIME Content-Type verilmelidir.
   * @return contentType
  **/
  @ApiModelProperty(example = "text/plain", value = "Tema Dosyası içerik tipi. Geçerli bir MIME Content-Type verilmelidir.")
  public String getContentType() {
    return contentType;
  }

  public void setContentType(String contentType) {
    this.contentType = contentType;
  }

  public Asset attachment(String attachment) {
    this.attachment = attachment;
    return this;
  }

   /**
   * Tema Dosyası içeriği.
   * @return attachment
  **/
  @ApiModelProperty(example = "{   \"display_stock_code\": 1,   \"use_social_links\": 1,   \"use_image_zoom\": 1,   \"display_category_logo\": 0,   \"display_category_subcategories\": 1,   \"display_category_brands\": 1,   \"display_sorting_options\": 1,   \"display_compare_button\": 1,   \"use_shorter_product_label\": 1,   \"display_order_tax_information\": 1,   \"use_lazy_load\": 0,   \"use_facebook_login\": 0,   \"use_google_login\": 0,   \"use_popup_cart\": 0,   \"brand_view_type\": \"name\",   \"showcase_repeat_columns\": 2,   \"use_rich_snippets\": 0,   \"optioned_product_view_type\": \"dropdown\",   \"optioned_product_price_view_type\": \"name_with_tax_string\",   \"quantity_selector_type\": \"dropdown\",   \"display_product_bread_crumb\": 1,   \"display_tax_information_on_showcase\": 1,   \"display_without_tax_price\": 1,   \"allow_product_comments\": 1,   \"display_product_attributes\": 1,   \"product_zoom_size\": 240,   \"display_category_bread_crumb\": 0,   \"display_included_tax_string_on_showcase\": 1,   \"display_retailer_comparison_price\": 0,   \"use_search_auto_complete\": 0,   \"use_lock_right_click\": 0,   \"display_category_or_brand_filter\": 0,   \"display_product_lowest_installment\": 1,   \"nopic_image\": \"\",   \"product_detail_page_tabs\": {  \"display_product_comments\": 1,   \"display_similar_products\": 1,  \"display_payment_options\": 1,  \"display_product_feeds\": 1,  \"display_special_information_area\": 1   },   \"logo\": \"\" }", value = "Tema Dosyası içeriği.")
  public String getAttachment() {
    return attachment;
  }

  public void setAttachment(String attachment) {
    this.attachment = attachment;
  }

  public Asset createdAt(OffsetDateTime createdAt) {
    this.createdAt = createdAt;
    return this;
  }

   /**
   * Tema Dosyası nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Tema Dosyası nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(OffsetDateTime createdAt) {
    this.createdAt = createdAt;
  }

  public Asset updatedAt(OffsetDateTime updatedAt) {
    this.updatedAt = updatedAt;
    return this;
  }

   /**
   * Tema Dosyası nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Tema Dosyası nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(OffsetDateTime updatedAt) {
    this.updatedAt = updatedAt;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Asset asset = (Asset) o;
    return Objects.equals(this.key, asset.key) &&
        Objects.equals(this.contentType, asset.contentType) &&
        Objects.equals(this.attachment, asset.attachment) &&
        Objects.equals(this.createdAt, asset.createdAt) &&
        Objects.equals(this.updatedAt, asset.updatedAt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(key, contentType, attachment, createdAt, updatedAt);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Asset {\n");
    
    sb.append("    key: ").append(toIndentedString(key)).append("\n");
    sb.append("    contentType: ").append(toIndentedString(contentType)).append("\n");
    sb.append("    attachment: ").append(toIndentedString(attachment)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

