package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Brand;
import io.swagger.client.model.Currency;
import io.swagger.client.model.Product;
import io.swagger.client.model.ProductImage;
import io.swagger.client.model.ProductPrice;
import io.swagger.client.model.ProductToCategory;
import io.swagger.client.model.ProductToCountDown;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;

/**
 * Product
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Product {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("name")
  private String name = null;

  @SerializedName("slug")
  private String slug = null;

  @SerializedName("fullName")
  private String fullName = null;

  @SerializedName("sku")
  private String sku = null;

  @SerializedName("barcode")
  private String barcode = null;

  @SerializedName("price1")
  private Float price1 = null;

  @SerializedName("warranty")
  private Integer warranty = null;

  @SerializedName("tax")
  private Integer tax = null;

  @SerializedName("stockAmount")
  private Float stockAmount = null;

  @SerializedName("volumetricWeight")
  private Float volumetricWeight = null;

  @SerializedName("buyingPrice")
  private Float buyingPrice = null;

  /**
   * Ürünün stok tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Piece&lt;/code&gt; : Stok tipi birimi Adet&lt;br&gt;&lt;code&gt;cm&lt;/code&gt; : Stok tipi birimi Santimetre&lt;br&gt;&lt;code&gt;Dozen&lt;/code&gt; : Stok tipi birimi Düzine&lt;br&gt;&lt;code&gt;gram&lt;/code&gt; : Stok tipi birimi Gram&lt;br&gt;&lt;code&gt;kg&lt;/code&gt; : Stok tipi birimi Kilogram&lt;br&gt;&lt;code&gt;Person&lt;/code&gt; : Stok tipi birimi Kişi&lt;br&gt;&lt;code&gt;Package&lt;/code&gt; : Stok tipi birimi Paket&lt;br&gt;&lt;code&gt;metre&lt;/code&gt; : Stok tipi birimi Metre&lt;br&gt;&lt;code&gt;m2&lt;/code&gt; : Stok tipi birimi Metrekare&lt;br&gt;&lt;code&gt;pair&lt;/code&gt; : Stok tipi birimi Çift&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(StockTypeLabelEnum.Adapter.class)
  public enum StockTypeLabelEnum {
    PIECE("Piece"),
    
    CM("cm"),
    
    DOZEN("Dozen"),
    
    GRAM("gram"),
    
    KG("kg"),
    
    PERSON("Person"),
    
    PACKAGE("Package"),
    
    METRE("metre"),
    
    M2("m2"),
    
    PAIR("pair");

    private String value;

    StockTypeLabelEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StockTypeLabelEnum fromValue(String text) {
      for (StockTypeLabelEnum b : StockTypeLabelEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StockTypeLabelEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StockTypeLabelEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StockTypeLabelEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return StockTypeLabelEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("stockTypeLabel")
  private StockTypeLabelEnum stockTypeLabel = null;

  @SerializedName("discount")
  private Float discount = null;

  /**
   * Ürünün indirim tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : İndirim yüzdesi&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : İndirimli fiyat&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(DiscountTypeEnum.Adapter.class)
  public enum DiscountTypeEnum {
    NUMBER_0(0),
    
    NUMBER_1(1);

    private Integer value;

    DiscountTypeEnum(Integer value) {
      this.value = value;
    }

    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static DiscountTypeEnum fromValue(String text) {
      for (DiscountTypeEnum b : DiscountTypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<DiscountTypeEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final DiscountTypeEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public DiscountTypeEnum read(final JsonReader jsonReader) throws IOException {
        Integer value = jsonReader.nextInt();
        return DiscountTypeEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("discountType")
  private DiscountTypeEnum discountType = null;

  @SerializedName("moneyOrderDiscount")
  private Float moneyOrderDiscount = null;

  /**
   * Ürün nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    NUMBER_0(0),
    
    NUMBER_1(1);

    private Integer value;

    StatusEnum(Integer value) {
      this.value = value;
    }

    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        Integer value = jsonReader.nextInt();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  /**
   * Ürün fiyatlarına KDV dahil olup olmadığın belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : KDV Dahil&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : KDV Hariç&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(TaxIncludedEnum.Adapter.class)
  public enum TaxIncludedEnum {
    _0("0"),
    
    _1("1");

    private String value;

    TaxIncludedEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static TaxIncludedEnum fromValue(String text) {
      for (TaxIncludedEnum b : TaxIncludedEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<TaxIncludedEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final TaxIncludedEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public TaxIncludedEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return TaxIncludedEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("taxIncluded")
  private TaxIncludedEnum taxIncluded = null;

  @SerializedName("distributor")
  private String distributor = null;

  /**
   * Ürünün hediyeli olup olmadığını belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hediyeli&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hediyeli Değil&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(IsGiftedEnum.Adapter.class)
  public enum IsGiftedEnum {
    _0("0"),
    
    _1("1");

    private String value;

    IsGiftedEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static IsGiftedEnum fromValue(String text) {
      for (IsGiftedEnum b : IsGiftedEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<IsGiftedEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final IsGiftedEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public IsGiftedEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return IsGiftedEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("isGifted")
  private IsGiftedEnum isGifted = null;

  @SerializedName("gift")
  private String gift = null;

  /**
   * Kargo ücreti için sistemin kullanılıp kullanılmama değerini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sistem seçeneği seçili&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sistem seçeneği seçili değil&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(CustomShippingDisabledEnum.Adapter.class)
  public enum CustomShippingDisabledEnum {
    _0("0"),
    
    _1("1");

    private String value;

    CustomShippingDisabledEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static CustomShippingDisabledEnum fromValue(String text) {
      for (CustomShippingDisabledEnum b : CustomShippingDisabledEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<CustomShippingDisabledEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final CustomShippingDisabledEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public CustomShippingDisabledEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return CustomShippingDisabledEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("customShippingDisabled")
  private CustomShippingDisabledEnum customShippingDisabled = null;

  @SerializedName("customShippingCost")
  private Float customShippingCost = null;

  @SerializedName("marketPriceDetail")
  private String marketPriceDetail = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  @SerializedName("metaKeywords")
  private String metaKeywords = null;

  @SerializedName("metaDescription")
  private String metaDescription = null;

  @SerializedName("pageTitle")
  private String pageTitle = null;

  /**
   * Ürünün varyantının olup olmadığı değerini belirtir. (API otomatik olarak bu değeri atar.)&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Varyantı var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Varyantı yok&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(HasOptionEnum.Adapter.class)
  public enum HasOptionEnum {
    _0("0"),
    
    _1("1");

    private String value;

    HasOptionEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static HasOptionEnum fromValue(String text) {
      for (HasOptionEnum b : HasOptionEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<HasOptionEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final HasOptionEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public HasOptionEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return HasOptionEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("hasOption")
  private HasOptionEnum hasOption = null;

  @SerializedName("shortDetails")
  private String shortDetails = null;

  @SerializedName("searchKeywords")
  private String searchKeywords = null;

  @SerializedName("installmentThreshold")
  private String installmentThreshold = null;

  @SerializedName("homeSortOrder")
  private Integer homeSortOrder = null;

  @SerializedName("popularSortOrder")
  private Integer popularSortOrder = null;

  @SerializedName("brandSortOrder")
  private Integer brandSortOrder = null;

  @SerializedName("featuredSortOrder")
  private Integer featuredSortOrder = null;

  @SerializedName("campaignedSortOrder")
  private Integer campaignedSortOrder = null;

  @SerializedName("newSortOrder")
  private Integer newSortOrder = null;

  @SerializedName("discountedSortOrder")
  private Integer discountedSortOrder = null;

  @SerializedName("brand")
  private Brand brand = null;

  @SerializedName("currency")
  private Currency currency = null;

  @SerializedName("parent")
  private Product parent = null;

  @SerializedName("countdown")
  private ProductToCountDown countdown = null;

  @SerializedName("prices")
  private List<ProductPrice> prices = null;

  @SerializedName("images")
  private List<ProductImage> images = null;

  @SerializedName("productToCategories")
  private List<ProductToCategory> productToCategories = null;

  public Product id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Ürün nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Ürün nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Product name(String name) {
    this.name = name;
    return this;
  }

   /**
   * Ürünün adı
   * @return name
  **/
  @ApiModelProperty(example = "Kalem", required = true, value = "Ürünün adı")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Product slug(String slug) {
    this.slug = slug;
    return this;
  }

   /**
   * Slug değeri ilgili nesnenin Url değeridir.
   * @return slug
  **/
  @ApiModelProperty(example = "kalem", value = "Slug değeri ilgili nesnenin Url değeridir.")
  public String getSlug() {
    return slug;
  }

  public void setSlug(String slug) {
    this.slug = slug;
  }

  public Product fullName(String fullName) {
    this.fullName = fullName;
    return this;
  }

   /**
   * Ürünün tam adı. Bu değer bir varyant için ana ürünün adı ve varyant adının birleşiminden oluşur. Örneğin Kırmızı varyantı için Kalem Kırmızı olur.
   * @return fullName
  **/
  @ApiModelProperty(example = "kalem", required = true, value = "Ürünün tam adı. Bu değer bir varyant için ana ürünün adı ve varyant adının birleşiminden oluşur. Örneğin Kırmızı varyantı için Kalem Kırmızı olur.")
  public String getFullName() {
    return fullName;
  }

  public void setFullName(String fullName) {
    this.fullName = fullName;
  }

  public Product sku(String sku) {
    this.sku = sku;
    return this;
  }

   /**
   * Ürünün stok kodu. ID değeri gibi eşsiz bir kimlik değeridir.
   * @return sku
  **/
  @ApiModelProperty(example = "KAL-1234", required = true, value = "Ürünün stok kodu. ID değeri gibi eşsiz bir kimlik değeridir.")
  public String getSku() {
    return sku;
  }

  public void setSku(String sku) {
    this.sku = sku;
  }

  public Product barcode(String barcode) {
    this.barcode = barcode;
    return this;
  }

   /**
   * Ürünün barkodu.
   * @return barcode
  **/
  @ApiModelProperty(example = "869456789874", value = "Ürünün barkodu.")
  public String getBarcode() {
    return barcode;
  }

  public void setBarcode(String barcode) {
    this.barcode = barcode;
  }

  public Product price1(Float price1) {
    this.price1 = price1;
    return this;
  }

   /**
   * Ürünün Fiyat 1 bilgisi.
   * minimum: 0
   * @return price1
  **/
  @ApiModelProperty(example = "10.0", required = true, value = "Ürünün Fiyat 1 bilgisi.")
  public Float getPrice1() {
    return price1;
  }

  public void setPrice1(Float price1) {
    this.price1 = price1;
  }

  public Product warranty(Integer warranty) {
    this.warranty = warranty;
    return this;
  }

   /**
   * Ürünün garanti süresi.
   * minimum: 0
   * @return warranty
  **/
  @ApiModelProperty(example = "24", value = "Ürünün garanti süresi.")
  public Integer getWarranty() {
    return warranty;
  }

  public void setWarranty(Integer warranty) {
    this.warranty = warranty;
  }

  public Product tax(Integer tax) {
    this.tax = tax;
    return this;
  }

   /**
   * Ürünün KDV oranı.
   * minimum: 0
   * @return tax
  **/
  @ApiModelProperty(example = "18", value = "Ürünün KDV oranı.")
  public Integer getTax() {
    return tax;
  }

  public void setTax(Integer tax) {
    this.tax = tax;
  }

  public Product stockAmount(Float stockAmount) {
    this.stockAmount = stockAmount;
    return this;
  }

   /**
   * Ürünün stok tipi cinsinden miktarı.
   * minimum: 0
   * @return stockAmount
  **/
  @ApiModelProperty(example = "10.0", value = "Ürünün stok tipi cinsinden miktarı.")
  public Float getStockAmount() {
    return stockAmount;
  }

  public void setStockAmount(Float stockAmount) {
    this.stockAmount = stockAmount;
  }

  public Product volumetricWeight(Float volumetricWeight) {
    this.volumetricWeight = volumetricWeight;
    return this;
  }

   /**
   * Ürünün desisi.
   * minimum: 0
   * @return volumetricWeight
  **/
  @ApiModelProperty(example = "1.0", value = "Ürünün desisi.")
  public Float getVolumetricWeight() {
    return volumetricWeight;
  }

  public void setVolumetricWeight(Float volumetricWeight) {
    this.volumetricWeight = volumetricWeight;
  }

  public Product buyingPrice(Float buyingPrice) {
    this.buyingPrice = buyingPrice;
    return this;
  }

   /**
   * Ürünün alış fiyatı.
   * minimum: 0
   * @return buyingPrice
  **/
  @ApiModelProperty(example = "5.0", value = "Ürünün alış fiyatı.")
  public Float getBuyingPrice() {
    return buyingPrice;
  }

  public void setBuyingPrice(Float buyingPrice) {
    this.buyingPrice = buyingPrice;
  }

  public Product stockTypeLabel(StockTypeLabelEnum stockTypeLabel) {
    this.stockTypeLabel = stockTypeLabel;
    return this;
  }

   /**
   * Ürünün stok tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Piece&lt;/code&gt; : Stok tipi birimi Adet&lt;br&gt;&lt;code&gt;cm&lt;/code&gt; : Stok tipi birimi Santimetre&lt;br&gt;&lt;code&gt;Dozen&lt;/code&gt; : Stok tipi birimi Düzine&lt;br&gt;&lt;code&gt;gram&lt;/code&gt; : Stok tipi birimi Gram&lt;br&gt;&lt;code&gt;kg&lt;/code&gt; : Stok tipi birimi Kilogram&lt;br&gt;&lt;code&gt;Person&lt;/code&gt; : Stok tipi birimi Kişi&lt;br&gt;&lt;code&gt;Package&lt;/code&gt; : Stok tipi birimi Paket&lt;br&gt;&lt;code&gt;metre&lt;/code&gt; : Stok tipi birimi Metre&lt;br&gt;&lt;code&gt;m2&lt;/code&gt; : Stok tipi birimi Metrekare&lt;br&gt;&lt;code&gt;pair&lt;/code&gt; : Stok tipi birimi Çift&lt;br&gt;&lt;/div&gt;
   * @return stockTypeLabel
  **/
  @ApiModelProperty(example = "Piece", value = "Ürünün stok tipi.<div class='idea_choice_list'><code>Piece</code> : Stok tipi birimi Adet<br><code>cm</code> : Stok tipi birimi Santimetre<br><code>Dozen</code> : Stok tipi birimi Düzine<br><code>gram</code> : Stok tipi birimi Gram<br><code>kg</code> : Stok tipi birimi Kilogram<br><code>Person</code> : Stok tipi birimi Kişi<br><code>Package</code> : Stok tipi birimi Paket<br><code>metre</code> : Stok tipi birimi Metre<br><code>m2</code> : Stok tipi birimi Metrekare<br><code>pair</code> : Stok tipi birimi Çift<br></div>")
  public StockTypeLabelEnum getStockTypeLabel() {
    return stockTypeLabel;
  }

  public void setStockTypeLabel(StockTypeLabelEnum stockTypeLabel) {
    this.stockTypeLabel = stockTypeLabel;
  }

  public Product discount(Float discount) {
    this.discount = discount;
    return this;
  }

   /**
   * Ürünün indirim değeri. Örneğin; discountType 1 olursa %5, 0 olursa 5 tl anlamına gelir.
   * minimum: 0
   * @return discount
  **/
  @ApiModelProperty(example = "5.0", value = "Ürünün indirim değeri. Örneğin; discountType 1 olursa %5, 0 olursa 5 tl anlamına gelir.")
  public Float getDiscount() {
    return discount;
  }

  public void setDiscount(Float discount) {
    this.discount = discount;
  }

  public Product discountType(DiscountTypeEnum discountType) {
    this.discountType = discountType;
    return this;
  }

   /**
   * Ürünün indirim tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : İndirim yüzdesi&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : İndirimli fiyat&lt;br&gt;&lt;/div&gt;
   * @return discountType
  **/
  @ApiModelProperty(example = "1", value = "Ürünün indirim tipini belirtir.<div class='idea_choice_list'><code>1</code> : İndirim yüzdesi<br><code>0</code> : İndirimli fiyat<br></div>")
  public DiscountTypeEnum getDiscountType() {
    return discountType;
  }

  public void setDiscountType(DiscountTypeEnum discountType) {
    this.discountType = discountType;
  }

  public Product moneyOrderDiscount(Float moneyOrderDiscount) {
    this.moneyOrderDiscount = moneyOrderDiscount;
    return this;
  }

   /**
   * Havale indirimi yüzdesi.
   * minimum: 0
   * maximum: 99.99
   * @return moneyOrderDiscount
  **/
  @ApiModelProperty(example = "10.0", value = "Havale indirimi yüzdesi.")
  public Float getMoneyOrderDiscount() {
    return moneyOrderDiscount;
  }

  public void setMoneyOrderDiscount(Float moneyOrderDiscount) {
    this.moneyOrderDiscount = moneyOrderDiscount;
  }

  public Product status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Ürün nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @ApiModelProperty(example = "1", required = true, value = "Ürün nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif<br><code>0</code> : Pasif<br></div>")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Product taxIncluded(TaxIncludedEnum taxIncluded) {
    this.taxIncluded = taxIncluded;
    return this;
  }

   /**
   * Ürün fiyatlarına KDV dahil olup olmadığın belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : KDV Dahil&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : KDV Hariç&lt;br&gt;&lt;/div&gt;
   * @return taxIncluded
  **/
  @ApiModelProperty(example = "1", value = "Ürün fiyatlarına KDV dahil olup olmadığın belirten değer.<div class='idea_choice_list'><code>1</code> : KDV Dahil<br><code>0</code> : KDV Hariç<br></div>")
  public TaxIncludedEnum getTaxIncluded() {
    return taxIncluded;
  }

  public void setTaxIncluded(TaxIncludedEnum taxIncluded) {
    this.taxIncluded = taxIncluded;
  }

  public Product distributor(String distributor) {
    this.distributor = distributor;
    return this;
  }

   /**
   * Ürünün distribütör bilgisi
   * @return distributor
  **/
  @ApiModelProperty(example = "superTedarik", value = "Ürünün distribütör bilgisi")
  public String getDistributor() {
    return distributor;
  }

  public void setDistributor(String distributor) {
    this.distributor = distributor;
  }

  public Product isGifted(IsGiftedEnum isGifted) {
    this.isGifted = isGifted;
    return this;
  }

   /**
   * Ürünün hediyeli olup olmadığını belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hediyeli&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hediyeli Değil&lt;br&gt;&lt;/div&gt;
   * @return isGifted
  **/
  @ApiModelProperty(example = "0", value = "Ürünün hediyeli olup olmadığını belirtir.<div class='idea_choice_list'><code>1</code> : Hediyeli<br><code>0</code> : Hediyeli Değil<br></div>")
  public IsGiftedEnum getIsGifted() {
    return isGifted;
  }

  public void setIsGifted(IsGiftedEnum isGifted) {
    this.isGifted = isGifted;
  }

  public Product gift(String gift) {
    this.gift = gift;
    return this;
  }

   /**
   * Ürünün yanında hediye olarak vermek istediğiniz hediyeyi bu alanda metin ya da rakamla belirtebilirsiniz.
   * @return gift
  **/
  @ApiModelProperty(example = "Silgi hediyeli.", value = "Ürünün yanında hediye olarak vermek istediğiniz hediyeyi bu alanda metin ya da rakamla belirtebilirsiniz.")
  public String getGift() {
    return gift;
  }

  public void setGift(String gift) {
    this.gift = gift;
  }

  public Product customShippingDisabled(CustomShippingDisabledEnum customShippingDisabled) {
    this.customShippingDisabled = customShippingDisabled;
    return this;
  }

   /**
   * Kargo ücreti için sistemin kullanılıp kullanılmama değerini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sistem seçeneği seçili&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sistem seçeneği seçili değil&lt;br&gt;&lt;/div&gt;
   * @return customShippingDisabled
  **/
  @ApiModelProperty(example = "1", value = "Kargo ücreti için sistemin kullanılıp kullanılmama değerini belirtir.<div class='idea_choice_list'><code>1</code> : Sistem seçeneği seçili<br><code>0</code> : Sistem seçeneği seçili değil<br></div>")
  public CustomShippingDisabledEnum getCustomShippingDisabled() {
    return customShippingDisabled;
  }

  public void setCustomShippingDisabled(CustomShippingDisabledEnum customShippingDisabled) {
    this.customShippingDisabled = customShippingDisabled;
  }

  public Product customShippingCost(Float customShippingCost) {
    this.customShippingCost = customShippingCost;
    return this;
  }

   /**
   * Sistem seçeneği seçilmemişse ürün için girilmesi gereken kargo ücreti.
   * minimum: 0
   * @return customShippingCost
  **/
  @ApiModelProperty(example = "5.0", value = "Sistem seçeneği seçilmemişse ürün için girilmesi gereken kargo ücreti.")
  public Float getCustomShippingCost() {
    return customShippingCost;
  }

  public void setCustomShippingCost(Float customShippingCost) {
    this.customShippingCost = customShippingCost;
  }

  public Product marketPriceDetail(String marketPriceDetail) {
    this.marketPriceDetail = marketPriceDetail;
    return this;
  }

   /**
   * Ürünün piyasa fiyatı
   * @return marketPriceDetail
  **/
  @ApiModelProperty(example = "8", value = "Ürünün piyasa fiyatı")
  public String getMarketPriceDetail() {
    return marketPriceDetail;
  }

  public void setMarketPriceDetail(String marketPriceDetail) {
    this.marketPriceDetail = marketPriceDetail;
  }

   /**
   * Ürün nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Ürün nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

   /**
   * Ürün nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Ürün nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public Product metaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
    return this;
  }

   /**
   * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.
   * @return metaKeywords
  **/
  @ApiModelProperty(example = "kırmızı, kalem, kırtasiye", value = "Arama motorları tarafından tespit edilebilecek anahtar kelimeler.")
  public String getMetaKeywords() {
    return metaKeywords;
  }

  public void setMetaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
  }

  public Product metaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
    return this;
  }

   /**
   * Arama motorları tarafından tespit edilebilecek açıklama yazısı.
   * @return metaDescription
  **/
  @ApiModelProperty(example = "Kaliteli kırtasiye ürünleri.", value = "Arama motorları tarafından tespit edilebilecek açıklama yazısı.")
  public String getMetaDescription() {
    return metaDescription;
  }

  public void setMetaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
  }

  public Product pageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
    return this;
  }

   /**
   * Ürün nesnesinin etiket başlığı.
   * @return pageTitle
  **/
  @ApiModelProperty(example = "Kırmızı Kalem", value = "Ürün nesnesinin etiket başlığı.")
  public String getPageTitle() {
    return pageTitle;
  }

  public void setPageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
  }

  public Product hasOption(HasOptionEnum hasOption) {
    this.hasOption = hasOption;
    return this;
  }

   /**
   * Ürünün varyantının olup olmadığı değerini belirtir. (API otomatik olarak bu değeri atar.)&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Varyantı var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Varyantı yok&lt;br&gt;&lt;/div&gt;
   * @return hasOption
  **/
  @ApiModelProperty(example = "1", value = "Ürünün varyantının olup olmadığı değerini belirtir. (API otomatik olarak bu değeri atar.)<div class='idea_choice_list'><code>1</code> : Varyantı var<br><code>0</code> : Varyantı yok<br></div>")
  public HasOptionEnum getHasOption() {
    return hasOption;
  }

  public void setHasOption(HasOptionEnum hasOption) {
    this.hasOption = hasOption;
  }

  public Product shortDetails(String shortDetails) {
    this.shortDetails = shortDetails;
    return this;
  }

   /**
   * Ürünün kısa açıklaması.
   * @return shortDetails
  **/
  @ApiModelProperty(example = "Yumuşak uçlu, kırmızı renkli kalem.", value = "Ürünün kısa açıklaması.")
  public String getShortDetails() {
    return shortDetails;
  }

  public void setShortDetails(String shortDetails) {
    this.shortDetails = shortDetails;
  }

  public Product searchKeywords(String searchKeywords) {
    this.searchKeywords = searchKeywords;
    return this;
  }

   /**
   * Ziyaretçilerinizin site içindeki ürünlerinizin hangi anahtar kelimelerine göre bulacağını belirler.Kelimeler arasında virgül bırakılarak girilmelidir.(etiket1,etiket2)
   * @return searchKeywords
  **/
  @ApiModelProperty(example = "kırmızı, kalem, kırtasiye", value = "Ziyaretçilerinizin site içindeki ürünlerinizin hangi anahtar kelimelerine göre bulacağını belirler.Kelimeler arasında virgül bırakılarak girilmelidir.(etiket1,etiket2)")
  public String getSearchKeywords() {
    return searchKeywords;
  }

  public void setSearchKeywords(String searchKeywords) {
    this.searchKeywords = searchKeywords;
  }

  public Product installmentThreshold(String installmentThreshold) {
    this.installmentThreshold = installmentThreshold;
    return this;
  }

   /**
   * Ürüne özel yasal veya isteğe bağlı belirleyebiliceğiniz taksit adedini belirtir. Ürüne özel bir belirleme yapmak istemiyorsanız &#39;-&#39; işareti kullanabilirsiniz.
   * @return installmentThreshold
  **/
  @ApiModelProperty(example = "-", value = "Ürüne özel yasal veya isteğe bağlı belirleyebiliceğiniz taksit adedini belirtir. Ürüne özel bir belirleme yapmak istemiyorsanız '-' işareti kullanabilirsiniz.")
  public String getInstallmentThreshold() {
    return installmentThreshold;
  }

  public void setInstallmentThreshold(String installmentThreshold) {
    this.installmentThreshold = installmentThreshold;
  }

  public Product homeSortOrder(Integer homeSortOrder) {
    this.homeSortOrder = homeSortOrder;
    return this;
  }

   /**
   * Anasayfa vitrini sırası.
   * maximum: 99
   * @return homeSortOrder
  **/
  @ApiModelProperty(example = "99", value = "Anasayfa vitrini sırası.")
  public Integer getHomeSortOrder() {
    return homeSortOrder;
  }

  public void setHomeSortOrder(Integer homeSortOrder) {
    this.homeSortOrder = homeSortOrder;
  }

  public Product popularSortOrder(Integer popularSortOrder) {
    this.popularSortOrder = popularSortOrder;
    return this;
  }

   /**
   * Popüler ürünler vitrini sırası.
   * maximum: 99
   * @return popularSortOrder
  **/
  @ApiModelProperty(example = "99", value = "Popüler ürünler vitrini sırası.")
  public Integer getPopularSortOrder() {
    return popularSortOrder;
  }

  public void setPopularSortOrder(Integer popularSortOrder) {
    this.popularSortOrder = popularSortOrder;
  }

  public Product brandSortOrder(Integer brandSortOrder) {
    this.brandSortOrder = brandSortOrder;
    return this;
  }

   /**
   * Marka vitrini sırası.
   * maximum: 9999
   * @return brandSortOrder
  **/
  @ApiModelProperty(example = "9999", value = "Marka vitrini sırası.")
  public Integer getBrandSortOrder() {
    return brandSortOrder;
  }

  public void setBrandSortOrder(Integer brandSortOrder) {
    this.brandSortOrder = brandSortOrder;
  }

  public Product featuredSortOrder(Integer featuredSortOrder) {
    this.featuredSortOrder = featuredSortOrder;
    return this;
  }

   /**
   * Sponsor ürünler vitrini sırası
   * maximum: 9999
   * @return featuredSortOrder
  **/
  @ApiModelProperty(example = "9999", value = "Sponsor ürünler vitrini sırası")
  public Integer getFeaturedSortOrder() {
    return featuredSortOrder;
  }

  public void setFeaturedSortOrder(Integer featuredSortOrder) {
    this.featuredSortOrder = featuredSortOrder;
  }

  public Product campaignedSortOrder(Integer campaignedSortOrder) {
    this.campaignedSortOrder = campaignedSortOrder;
    return this;
  }

   /**
   * Kampanyalı ürünler vitrini sırası.
   * maximum: 9999
   * @return campaignedSortOrder
  **/
  @ApiModelProperty(example = "9999", value = "Kampanyalı ürünler vitrini sırası.")
  public Integer getCampaignedSortOrder() {
    return campaignedSortOrder;
  }

  public void setCampaignedSortOrder(Integer campaignedSortOrder) {
    this.campaignedSortOrder = campaignedSortOrder;
  }

  public Product newSortOrder(Integer newSortOrder) {
    this.newSortOrder = newSortOrder;
    return this;
  }

   /**
   * Yeni ürünler vitrini sırası.
   * maximum: 9999
   * @return newSortOrder
  **/
  @ApiModelProperty(example = "9999", value = "Yeni ürünler vitrini sırası.")
  public Integer getNewSortOrder() {
    return newSortOrder;
  }

  public void setNewSortOrder(Integer newSortOrder) {
    this.newSortOrder = newSortOrder;
  }

  public Product discountedSortOrder(Integer discountedSortOrder) {
    this.discountedSortOrder = discountedSortOrder;
    return this;
  }

   /**
   * İndirimli ürünler vitrini sırası
   * maximum: 9999
   * @return discountedSortOrder
  **/
  @ApiModelProperty(example = "9999", value = "İndirimli ürünler vitrini sırası")
  public Integer getDiscountedSortOrder() {
    return discountedSortOrder;
  }

  public void setDiscountedSortOrder(Integer discountedSortOrder) {
    this.discountedSortOrder = discountedSortOrder;
  }

  public Product brand(Brand brand) {
    this.brand = brand;
    return this;
  }

   /**
   * Get brand
   * @return brand
  **/
  @ApiModelProperty(value = "")
  public Brand getBrand() {
    return brand;
  }

  public void setBrand(Brand brand) {
    this.brand = brand;
  }

  public Product currency(Currency currency) {
    this.currency = currency;
    return this;
  }

   /**
   * Get currency
   * @return currency
  **/
  @ApiModelProperty(value = "")
  public Currency getCurrency() {
    return currency;
  }

  public void setCurrency(Currency currency) {
    this.currency = currency;
  }

  public Product parent(Product parent) {
    this.parent = parent;
    return this;
  }

   /**
   * Get parent
   * @return parent
  **/
  @ApiModelProperty(value = "")
  public Product getParent() {
    return parent;
  }

  public void setParent(Product parent) {
    this.parent = parent;
  }

  public Product countdown(ProductToCountDown countdown) {
    this.countdown = countdown;
    return this;
  }

   /**
   * Get countdown
   * @return countdown
  **/
  @ApiModelProperty(value = "")
  public ProductToCountDown getCountdown() {
    return countdown;
  }

  public void setCountdown(ProductToCountDown countdown) {
    this.countdown = countdown;
  }

  public Product prices(List<ProductPrice> prices) {
    this.prices = prices;
    return this;
  }

  public Product addPricesItem(ProductPrice pricesItem) {
    if (this.prices == null) {
      this.prices = new ArrayList<ProductPrice>();
    }
    this.prices.add(pricesItem);
    return this;
  }

   /**
   * Ürünün fiyatları.
   * @return prices
  **/
  @ApiModelProperty(value = "Ürünün fiyatları.")
  public List<ProductPrice> getPrices() {
    return prices;
  }

  public void setPrices(List<ProductPrice> prices) {
    this.prices = prices;
  }

  public Product images(List<ProductImage> images) {
    this.images = images;
    return this;
  }

  public Product addImagesItem(ProductImage imagesItem) {
    if (this.images == null) {
      this.images = new ArrayList<ProductImage>();
    }
    this.images.add(imagesItem);
    return this;
  }

   /**
   * Ürünün resimleri.
   * @return images
  **/
  @ApiModelProperty(value = "Ürünün resimleri.")
  public List<ProductImage> getImages() {
    return images;
  }

  public void setImages(List<ProductImage> images) {
    this.images = images;
  }

  public Product productToCategories(List<ProductToCategory> productToCategories) {
    this.productToCategories = productToCategories;
    return this;
  }

  public Product addProductToCategoriesItem(ProductToCategory productToCategoriesItem) {
    if (this.productToCategories == null) {
      this.productToCategories = new ArrayList<ProductToCategory>();
    }
    this.productToCategories.add(productToCategoriesItem);
    return this;
  }

   /**
   * Ürünün kategorileri.
   * @return productToCategories
  **/
  @ApiModelProperty(value = "Ürünün kategorileri.")
  public List<ProductToCategory> getProductToCategories() {
    return productToCategories;
  }

  public void setProductToCategories(List<ProductToCategory> productToCategories) {
    this.productToCategories = productToCategories;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Product product = (Product) o;
    return Objects.equals(this.id, product.id) &&
        Objects.equals(this.name, product.name) &&
        Objects.equals(this.slug, product.slug) &&
        Objects.equals(this.fullName, product.fullName) &&
        Objects.equals(this.sku, product.sku) &&
        Objects.equals(this.barcode, product.barcode) &&
        Objects.equals(this.price1, product.price1) &&
        Objects.equals(this.warranty, product.warranty) &&
        Objects.equals(this.tax, product.tax) &&
        Objects.equals(this.stockAmount, product.stockAmount) &&
        Objects.equals(this.volumetricWeight, product.volumetricWeight) &&
        Objects.equals(this.buyingPrice, product.buyingPrice) &&
        Objects.equals(this.stockTypeLabel, product.stockTypeLabel) &&
        Objects.equals(this.discount, product.discount) &&
        Objects.equals(this.discountType, product.discountType) &&
        Objects.equals(this.moneyOrderDiscount, product.moneyOrderDiscount) &&
        Objects.equals(this.status, product.status) &&
        Objects.equals(this.taxIncluded, product.taxIncluded) &&
        Objects.equals(this.distributor, product.distributor) &&
        Objects.equals(this.isGifted, product.isGifted) &&
        Objects.equals(this.gift, product.gift) &&
        Objects.equals(this.customShippingDisabled, product.customShippingDisabled) &&
        Objects.equals(this.customShippingCost, product.customShippingCost) &&
        Objects.equals(this.marketPriceDetail, product.marketPriceDetail) &&
        Objects.equals(this.createdAt, product.createdAt) &&
        Objects.equals(this.updatedAt, product.updatedAt) &&
        Objects.equals(this.metaKeywords, product.metaKeywords) &&
        Objects.equals(this.metaDescription, product.metaDescription) &&
        Objects.equals(this.pageTitle, product.pageTitle) &&
        Objects.equals(this.hasOption, product.hasOption) &&
        Objects.equals(this.shortDetails, product.shortDetails) &&
        Objects.equals(this.searchKeywords, product.searchKeywords) &&
        Objects.equals(this.installmentThreshold, product.installmentThreshold) &&
        Objects.equals(this.homeSortOrder, product.homeSortOrder) &&
        Objects.equals(this.popularSortOrder, product.popularSortOrder) &&
        Objects.equals(this.brandSortOrder, product.brandSortOrder) &&
        Objects.equals(this.featuredSortOrder, product.featuredSortOrder) &&
        Objects.equals(this.campaignedSortOrder, product.campaignedSortOrder) &&
        Objects.equals(this.newSortOrder, product.newSortOrder) &&
        Objects.equals(this.discountedSortOrder, product.discountedSortOrder) &&
        Objects.equals(this.brand, product.brand) &&
        Objects.equals(this.currency, product.currency) &&
        Objects.equals(this.parent, product.parent) &&
        Objects.equals(this.countdown, product.countdown) &&
        Objects.equals(this.prices, product.prices) &&
        Objects.equals(this.images, product.images) &&
        Objects.equals(this.productToCategories, product.productToCategories);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, slug, fullName, sku, barcode, price1, warranty, tax, stockAmount, volumetricWeight, buyingPrice, stockTypeLabel, discount, discountType, moneyOrderDiscount, status, taxIncluded, distributor, isGifted, gift, customShippingDisabled, customShippingCost, marketPriceDetail, createdAt, updatedAt, metaKeywords, metaDescription, pageTitle, hasOption, shortDetails, searchKeywords, installmentThreshold, homeSortOrder, popularSortOrder, brandSortOrder, featuredSortOrder, campaignedSortOrder, newSortOrder, discountedSortOrder, brand, currency, parent, countdown, prices, images, productToCategories);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Product {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    slug: ").append(toIndentedString(slug)).append("\n");
    sb.append("    fullName: ").append(toIndentedString(fullName)).append("\n");
    sb.append("    sku: ").append(toIndentedString(sku)).append("\n");
    sb.append("    barcode: ").append(toIndentedString(barcode)).append("\n");
    sb.append("    price1: ").append(toIndentedString(price1)).append("\n");
    sb.append("    warranty: ").append(toIndentedString(warranty)).append("\n");
    sb.append("    tax: ").append(toIndentedString(tax)).append("\n");
    sb.append("    stockAmount: ").append(toIndentedString(stockAmount)).append("\n");
    sb.append("    volumetricWeight: ").append(toIndentedString(volumetricWeight)).append("\n");
    sb.append("    buyingPrice: ").append(toIndentedString(buyingPrice)).append("\n");
    sb.append("    stockTypeLabel: ").append(toIndentedString(stockTypeLabel)).append("\n");
    sb.append("    discount: ").append(toIndentedString(discount)).append("\n");
    sb.append("    discountType: ").append(toIndentedString(discountType)).append("\n");
    sb.append("    moneyOrderDiscount: ").append(toIndentedString(moneyOrderDiscount)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    taxIncluded: ").append(toIndentedString(taxIncluded)).append("\n");
    sb.append("    distributor: ").append(toIndentedString(distributor)).append("\n");
    sb.append("    isGifted: ").append(toIndentedString(isGifted)).append("\n");
    sb.append("    gift: ").append(toIndentedString(gift)).append("\n");
    sb.append("    customShippingDisabled: ").append(toIndentedString(customShippingDisabled)).append("\n");
    sb.append("    customShippingCost: ").append(toIndentedString(customShippingCost)).append("\n");
    sb.append("    marketPriceDetail: ").append(toIndentedString(marketPriceDetail)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    metaKeywords: ").append(toIndentedString(metaKeywords)).append("\n");
    sb.append("    metaDescription: ").append(toIndentedString(metaDescription)).append("\n");
    sb.append("    pageTitle: ").append(toIndentedString(pageTitle)).append("\n");
    sb.append("    hasOption: ").append(toIndentedString(hasOption)).append("\n");
    sb.append("    shortDetails: ").append(toIndentedString(shortDetails)).append("\n");
    sb.append("    searchKeywords: ").append(toIndentedString(searchKeywords)).append("\n");
    sb.append("    installmentThreshold: ").append(toIndentedString(installmentThreshold)).append("\n");
    sb.append("    homeSortOrder: ").append(toIndentedString(homeSortOrder)).append("\n");
    sb.append("    popularSortOrder: ").append(toIndentedString(popularSortOrder)).append("\n");
    sb.append("    brandSortOrder: ").append(toIndentedString(brandSortOrder)).append("\n");
    sb.append("    featuredSortOrder: ").append(toIndentedString(featuredSortOrder)).append("\n");
    sb.append("    campaignedSortOrder: ").append(toIndentedString(campaignedSortOrder)).append("\n");
    sb.append("    newSortOrder: ").append(toIndentedString(newSortOrder)).append("\n");
    sb.append("    discountedSortOrder: ").append(toIndentedString(discountedSortOrder)).append("\n");
    sb.append("    brand: ").append(toIndentedString(brand)).append("\n");
    sb.append("    currency: ").append(toIndentedString(currency)).append("\n");
    sb.append("    parent: ").append(toIndentedString(parent)).append("\n");
    sb.append("    countdown: ").append(toIndentedString(countdown)).append("\n");
    sb.append("    prices: ").append(toIndentedString(prices)).append("\n");
    sb.append("    images: ").append(toIndentedString(images)).append("\n");
    sb.append("    productToCategories: ").append(toIndentedString(productToCategories)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

