package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.IOException;

/**
 * OrderItemCustomization
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class OrderItemCustomization {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("productCustomizationGroupId")
  private Integer productCustomizationGroupId = null;

  @SerializedName("productCustomizationGroupName")
  private String productCustomizationGroupName = null;

  @SerializedName("productCustomizationGroupSortOrder")
  private Integer productCustomizationGroupSortOrder = null;

  @SerializedName("productCustomizationFieldId")
  private Integer productCustomizationFieldId = null;

  @SerializedName("productCustomizationFieldType")
  private String productCustomizationFieldType = null;

  @SerializedName("productCustomizationFieldName")
  private String productCustomizationFieldName = null;

  @SerializedName("productCustomizationFieldValue")
  private String productCustomizationFieldValue = null;

  @SerializedName("cartItemAttributeId")
  private Integer cartItemAttributeId = null;

  public OrderItemCustomization id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Sipariş kalemi özelleştirme kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Sipariş kalemi özelleştirme kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OrderItemCustomization productCustomizationGroupId(Integer productCustomizationGroupId) {
    this.productCustomizationGroupId = productCustomizationGroupId;
    return this;
  }

   /**
   * Ürün özelleştirme grubu nesnesi kimlik değeri.
   * @return productCustomizationGroupId
  **/
  @ApiModelProperty(example = "123", value = "Ürün özelleştirme grubu nesnesi kimlik değeri.")
  public Integer getProductCustomizationGroupId() {
    return productCustomizationGroupId;
  }

  public void setProductCustomizationGroupId(Integer productCustomizationGroupId) {
    this.productCustomizationGroupId = productCustomizationGroupId;
  }

  public OrderItemCustomization productCustomizationGroupName(String productCustomizationGroupName) {
    this.productCustomizationGroupName = productCustomizationGroupName;
    return this;
  }

   /**
   * Ürün özelleştirme grubu nesnesinin grup adı.
   * @return productCustomizationGroupName
  **/
  @ApiModelProperty(example = "productCustomizationGroupName", value = "Ürün özelleştirme grubu nesnesinin grup adı.")
  public String getProductCustomizationGroupName() {
    return productCustomizationGroupName;
  }

  public void setProductCustomizationGroupName(String productCustomizationGroupName) {
    this.productCustomizationGroupName = productCustomizationGroupName;
  }

  public OrderItemCustomization productCustomizationGroupSortOrder(Integer productCustomizationGroupSortOrder) {
    this.productCustomizationGroupSortOrder = productCustomizationGroupSortOrder;
    return this;
  }

   /**
   * Ürün özelleştirme grubu nesnesinin sıralaması.
   * @return productCustomizationGroupSortOrder
  **/
  @ApiModelProperty(example = "999", value = "Ürün özelleştirme grubu nesnesinin sıralaması.")
  public Integer getProductCustomizationGroupSortOrder() {
    return productCustomizationGroupSortOrder;
  }

  public void setProductCustomizationGroupSortOrder(Integer productCustomizationGroupSortOrder) {
    this.productCustomizationGroupSortOrder = productCustomizationGroupSortOrder;
  }

  public OrderItemCustomization productCustomizationFieldId(Integer productCustomizationFieldId) {
    this.productCustomizationFieldId = productCustomizationFieldId;
    return this;
  }

   /**
   * Ürün özelleştirme nesnesi kimlik değeri..
   * @return productCustomizationFieldId
  **/
  @ApiModelProperty(example = "123", value = "Ürün özelleştirme nesnesi kimlik değeri..")
  public Integer getProductCustomizationFieldId() {
    return productCustomizationFieldId;
  }

  public void setProductCustomizationFieldId(Integer productCustomizationFieldId) {
    this.productCustomizationFieldId = productCustomizationFieldId;
  }

  public OrderItemCustomization productCustomizationFieldType(String productCustomizationFieldType) {
    this.productCustomizationFieldType = productCustomizationFieldType;
    return this;
  }

   /**
   * Ürün özelleştirme nesnesinin alan tipi.
   * @return productCustomizationFieldType
  **/
  @ApiModelProperty(example = "Kısa Bilgi Alanı", value = "Ürün özelleştirme nesnesinin alan tipi.")
  public String getProductCustomizationFieldType() {
    return productCustomizationFieldType;
  }

  public void setProductCustomizationFieldType(String productCustomizationFieldType) {
    this.productCustomizationFieldType = productCustomizationFieldType;
  }

  public OrderItemCustomization productCustomizationFieldName(String productCustomizationFieldName) {
    this.productCustomizationFieldName = productCustomizationFieldName;
    return this;
  }

   /**
   * Ürün özelleştirme nesnesinin alan adı.
   * @return productCustomizationFieldName
  **/
  @ApiModelProperty(example = "productCustomizationFieldName", value = "Ürün özelleştirme nesnesinin alan adı.")
  public String getProductCustomizationFieldName() {
    return productCustomizationFieldName;
  }

  public void setProductCustomizationFieldName(String productCustomizationFieldName) {
    this.productCustomizationFieldName = productCustomizationFieldName;
  }

  public OrderItemCustomization productCustomizationFieldValue(String productCustomizationFieldValue) {
    this.productCustomizationFieldValue = productCustomizationFieldValue;
    return this;
  }

   /**
   * Ürün özelleştirme nesnesinin değeri.
   * @return productCustomizationFieldValue
  **/
  @ApiModelProperty(example = "productCustomizationFieldValue", value = "Ürün özelleştirme nesnesinin değeri.")
  public String getProductCustomizationFieldValue() {
    return productCustomizationFieldValue;
  }

  public void setProductCustomizationFieldValue(String productCustomizationFieldValue) {
    this.productCustomizationFieldValue = productCustomizationFieldValue;
  }

  public OrderItemCustomization cartItemAttributeId(Integer cartItemAttributeId) {
    this.cartItemAttributeId = cartItemAttributeId;
    return this;
  }

   /**
   * Sepet kalemi özelliği nesnesi kimlik değeri.
   * @return cartItemAttributeId
  **/
  @ApiModelProperty(example = "123", value = "Sepet kalemi özelliği nesnesi kimlik değeri.")
  public Integer getCartItemAttributeId() {
    return cartItemAttributeId;
  }

  public void setCartItemAttributeId(Integer cartItemAttributeId) {
    this.cartItemAttributeId = cartItemAttributeId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrderItemCustomization orderItemCustomization = (OrderItemCustomization) o;
    return Objects.equals(this.id, orderItemCustomization.id) &&
        Objects.equals(this.productCustomizationGroupId, orderItemCustomization.productCustomizationGroupId) &&
        Objects.equals(this.productCustomizationGroupName, orderItemCustomization.productCustomizationGroupName) &&
        Objects.equals(this.productCustomizationGroupSortOrder, orderItemCustomization.productCustomizationGroupSortOrder) &&
        Objects.equals(this.productCustomizationFieldId, orderItemCustomization.productCustomizationFieldId) &&
        Objects.equals(this.productCustomizationFieldType, orderItemCustomization.productCustomizationFieldType) &&
        Objects.equals(this.productCustomizationFieldName, orderItemCustomization.productCustomizationFieldName) &&
        Objects.equals(this.productCustomizationFieldValue, orderItemCustomization.productCustomizationFieldValue) &&
        Objects.equals(this.cartItemAttributeId, orderItemCustomization.cartItemAttributeId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, productCustomizationGroupId, productCustomizationGroupName, productCustomizationGroupSortOrder, productCustomizationFieldId, productCustomizationFieldType, productCustomizationFieldName, productCustomizationFieldValue, cartItemAttributeId);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderItemCustomization {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    productCustomizationGroupId: ").append(toIndentedString(productCustomizationGroupId)).append("\n");
    sb.append("    productCustomizationGroupName: ").append(toIndentedString(productCustomizationGroupName)).append("\n");
    sb.append("    productCustomizationGroupSortOrder: ").append(toIndentedString(productCustomizationGroupSortOrder)).append("\n");
    sb.append("    productCustomizationFieldId: ").append(toIndentedString(productCustomizationFieldId)).append("\n");
    sb.append("    productCustomizationFieldType: ").append(toIndentedString(productCustomizationFieldType)).append("\n");
    sb.append("    productCustomizationFieldName: ").append(toIndentedString(productCustomizationFieldName)).append("\n");
    sb.append("    productCustomizationFieldValue: ").append(toIndentedString(productCustomizationFieldValue)).append("\n");
    sb.append("    cartItemAttributeId: ").append(toIndentedString(cartItemAttributeId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

