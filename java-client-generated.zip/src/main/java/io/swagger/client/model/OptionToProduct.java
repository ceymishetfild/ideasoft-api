package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.OptionGroup;
import io.swagger.client.model.Options;
import io.swagger.client.model.Product;
import java.io.IOException;

/**
 * OptionToProduct
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class OptionToProduct {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("parentProductId")
  private Integer parentProductId = null;

  @SerializedName("optionGroup")
  private OptionGroup optionGroup = null;

  @SerializedName("option")
  private Options option = null;

  @SerializedName("product")
  private Product product = null;

  public OptionToProduct id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Varyant ürün bağı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Varyant ürün bağı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OptionToProduct parentProductId(Integer parentProductId) {
    this.parentProductId = parentProductId;
    return this;
  }

   /**
   * Ana ürünün benzersiz kimlik değeri.
   * @return parentProductId
  **/
  @ApiModelProperty(example = "123", required = true, value = "Ana ürünün benzersiz kimlik değeri.")
  public Integer getParentProductId() {
    return parentProductId;
  }

  public void setParentProductId(Integer parentProductId) {
    this.parentProductId = parentProductId;
  }

  public OptionToProduct optionGroup(OptionGroup optionGroup) {
    this.optionGroup = optionGroup;
    return this;
  }

   /**
   * Get optionGroup
   * @return optionGroup
  **/
  @ApiModelProperty(value = "")
  public OptionGroup getOptionGroup() {
    return optionGroup;
  }

  public void setOptionGroup(OptionGroup optionGroup) {
    this.optionGroup = optionGroup;
  }

  public OptionToProduct option(Options option) {
    this.option = option;
    return this;
  }

   /**
   * Get option
   * @return option
  **/
  @ApiModelProperty(value = "")
  public Options getOption() {
    return option;
  }

  public void setOption(Options option) {
    this.option = option;
  }

  public OptionToProduct product(Product product) {
    this.product = product;
    return this;
  }

   /**
   * Get product
   * @return product
  **/
  @ApiModelProperty(value = "")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OptionToProduct optionToProduct = (OptionToProduct) o;
    return Objects.equals(this.id, optionToProduct.id) &&
        Objects.equals(this.parentProductId, optionToProduct.parentProductId) &&
        Objects.equals(this.optionGroup, optionToProduct.optionGroup) &&
        Objects.equals(this.option, optionToProduct.option) &&
        Objects.equals(this.product, optionToProduct.product);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, parentProductId, optionGroup, option, product);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OptionToProduct {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    parentProductId: ").append(toIndentedString(parentProductId)).append("\n");
    sb.append("    optionGroup: ").append(toIndentedString(optionGroup)).append("\n");
    sb.append("    option: ").append(toIndentedString(option)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

