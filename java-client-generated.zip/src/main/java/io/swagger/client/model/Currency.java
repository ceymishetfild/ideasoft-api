package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.IOException;
import org.threeten.bp.OffsetDateTime;

/**
 * Currency
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Currency {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("label")
  private String label = null;

  @SerializedName("buyingPrice")
  private Float buyingPrice = null;

  @SerializedName("sellingPrice")
  private Float sellingPrice = null;

  @SerializedName("abbr")
  private String abbr = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  /**
   * Kur nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    _0("0"),
    
    _1("1");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  /**
   * Kurun birincil kur olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Birincil kur.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Birincil kur değil.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(IsPrimaryEnum.Adapter.class)
  public enum IsPrimaryEnum {
    _0("0"),
    
    _1("1");

    private String value;

    IsPrimaryEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static IsPrimaryEnum fromValue(String text) {
      for (IsPrimaryEnum b : IsPrimaryEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<IsPrimaryEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final IsPrimaryEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public IsPrimaryEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return IsPrimaryEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("isPrimary")
  private IsPrimaryEnum isPrimary = null;

  public Currency id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Kur nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Kur nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

   /**
   * Kur etiketi.
   * @return label
  **/
  @ApiModelProperty(example = "TL", value = "Kur etiketi.")
  public String getLabel() {
    return label;
  }

  public Currency buyingPrice(Float buyingPrice) {
    this.buyingPrice = buyingPrice;
    return this;
  }

   /**
   * Kurun alış fiyatı.
   * minimum: 0
   * @return buyingPrice
  **/
  @ApiModelProperty(example = "1.0", value = "Kurun alış fiyatı.")
  public Float getBuyingPrice() {
    return buyingPrice;
  }

  public void setBuyingPrice(Float buyingPrice) {
    this.buyingPrice = buyingPrice;
  }

  public Currency sellingPrice(Float sellingPrice) {
    this.sellingPrice = sellingPrice;
    return this;
  }

   /**
   * Kurun satış fiyatı.
   * minimum: 0
   * @return sellingPrice
  **/
  @ApiModelProperty(example = "1.0", value = "Kurun satış fiyatı.")
  public Float getSellingPrice() {
    return sellingPrice;
  }

  public void setSellingPrice(Float sellingPrice) {
    this.sellingPrice = sellingPrice;
  }

   /**
   * Kurun kısaltması.
   * @return abbr
  **/
  @ApiModelProperty(example = "TL", value = "Kurun kısaltması.")
  public String getAbbr() {
    return abbr;
  }

  public Currency updatedAt(OffsetDateTime updatedAt) {
    this.updatedAt = updatedAt;
    return this;
  }

   /**
   * Kur nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Kur nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(OffsetDateTime updatedAt) {
    this.updatedAt = updatedAt;
  }

  public Currency status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Kur nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @ApiModelProperty(example = "1", value = "Kur nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Currency isPrimary(IsPrimaryEnum isPrimary) {
    this.isPrimary = isPrimary;
    return this;
  }

   /**
   * Kurun birincil kur olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Birincil kur.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Birincil kur değil.&lt;br&gt;&lt;/div&gt;
   * @return isPrimary
  **/
  @ApiModelProperty(example = "1", value = "Kurun birincil kur olup olmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Birincil kur.<br><code>0</code> : Birincil kur değil.<br></div>")
  public IsPrimaryEnum getIsPrimary() {
    return isPrimary;
  }

  public void setIsPrimary(IsPrimaryEnum isPrimary) {
    this.isPrimary = isPrimary;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Currency currency = (Currency) o;
    return Objects.equals(this.id, currency.id) &&
        Objects.equals(this.label, currency.label) &&
        Objects.equals(this.buyingPrice, currency.buyingPrice) &&
        Objects.equals(this.sellingPrice, currency.sellingPrice) &&
        Objects.equals(this.abbr, currency.abbr) &&
        Objects.equals(this.updatedAt, currency.updatedAt) &&
        Objects.equals(this.status, currency.status) &&
        Objects.equals(this.isPrimary, currency.isPrimary);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, label, buyingPrice, sellingPrice, abbr, updatedAt, status, isPrimary);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Currency {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    label: ").append(toIndentedString(label)).append("\n");
    sb.append("    buyingPrice: ").append(toIndentedString(buyingPrice)).append("\n");
    sb.append("    sellingPrice: ").append(toIndentedString(sellingPrice)).append("\n");
    sb.append("    abbr: ").append(toIndentedString(abbr)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    isPrimary: ").append(toIndentedString(isPrimary)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

