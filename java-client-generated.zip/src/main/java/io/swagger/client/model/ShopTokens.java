package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.IOException;

/**
 * ShopTokens
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ShopTokens {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("code")
  private String code = null;

  public ShopTokens id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Hediye çeki nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Hediye çeki nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ShopTokens code(String code) {
    this.code = code;
    return this;
  }

   /**
   * Hediye çekinin benzersiz kodu. Admin panelinden düzenlenebilir.
   * @return code
  **/
  @ApiModelProperty(example = "HEDIYE2018", value = "Hediye çekinin benzersiz kodu. Admin panelinden düzenlenebilir.")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShopTokens shopTokens = (ShopTokens) o;
    return Objects.equals(this.id, shopTokens.id) &&
        Objects.equals(this.code, shopTokens.code);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, code);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShopTokens {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

