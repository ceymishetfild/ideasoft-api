package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.OrderItem;
import io.swagger.client.model.Product;
import io.swagger.client.model.Shipment;
import java.io.IOException;
import org.threeten.bp.OffsetDateTime;

/**
 * ShipmentItem
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ShipmentItem {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("rootProductId")
  private Integer rootProductId = null;

  @SerializedName("amount")
  private Integer amount = null;

  @SerializedName("price")
  private Float price = null;

  @SerializedName("productLabel")
  private String productLabel = null;

  /**
   * Ürünün kur bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;USD&lt;/code&gt; : Amerikan Doları&lt;br&gt;&lt;code&gt;EUR&lt;/code&gt; : Euro&lt;br&gt;&lt;code&gt;TL&lt;/code&gt; : Türk Lirası&lt;br&gt;&lt;code&gt;GBP&lt;/code&gt; : İngiliz Sterlini&lt;br&gt;&lt;code&gt;JPY&lt;/code&gt; : Japon Yeni&lt;br&gt;&lt;code&gt;CNY&lt;/code&gt; : Çin Yuanı&lt;br&gt;&lt;code&gt;GR&lt;/code&gt; : Gram Altın&lt;br&gt;&lt;code&gt;CHF&lt;/code&gt; : İsviçre Frangı&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(CurrencyEnum.Adapter.class)
  public enum CurrencyEnum {
    USD("USD"),
    
    EUR("EUR"),
    
    TL("TL"),
    
    GBP("GBP"),
    
    JPY("JPY"),
    
    CNY("CNY"),
    
    GR("GR"),
    
    CHF("CHF");

    private String value;

    CurrencyEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static CurrencyEnum fromValue(String text) {
      for (CurrencyEnum b : CurrencyEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<CurrencyEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final CurrencyEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public CurrencyEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return CurrencyEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("currency")
  private CurrencyEnum currency = null;

  @SerializedName("tax")
  private Integer tax = null;

  @SerializedName("dm3")
  private Float dm3 = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  /**
   * Teslimat Kalemi nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    NUMBER_0(0),
    
    NUMBER_1(1);

    private Integer value;

    StatusEnum(Integer value) {
      this.value = value;
    }

    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        Integer value = jsonReader.nextInt();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  @SerializedName("orderItem")
  private OrderItem orderItem = null;

  @SerializedName("product")
  private Product product = null;

  @SerializedName("shipment")
  private Shipment shipment = null;

  public ShipmentItem id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Teslimat Kalemi nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Teslimat Kalemi nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ShipmentItem rootProductId(Integer rootProductId) {
    this.rootProductId = rootProductId;
    return this;
  }

   /**
   * Ana ürünün id değeri.
   * minimum: 0
   * @return rootProductId
  **/
  @ApiModelProperty(example = "123", value = "Ana ürünün id değeri.")
  public Integer getRootProductId() {
    return rootProductId;
  }

  public void setRootProductId(Integer rootProductId) {
    this.rootProductId = rootProductId;
  }

  public ShipmentItem amount(Integer amount) {
    this.amount = amount;
    return this;
  }

   /**
   * Ürünün stok tipi cinsinden miktarı.
   * minimum: 0
   * @return amount
  **/
  @ApiModelProperty(example = "2", required = true, value = "Ürünün stok tipi cinsinden miktarı.")
  public Integer getAmount() {
    return amount;
  }

  public void setAmount(Integer amount) {
    this.amount = amount;
  }

  public ShipmentItem price(Float price) {
    this.price = price;
    return this;
  }

   /**
   * Ürünün fiyatı.
   * minimum: 0
   * @return price
  **/
  @ApiModelProperty(example = "20.0", required = true, value = "Ürünün fiyatı.")
  public Float getPrice() {
    return price;
  }

  public void setPrice(Float price) {
    this.price = price;
  }

  public ShipmentItem productLabel(String productLabel) {
    this.productLabel = productLabel;
    return this;
  }

   /**
   * Ürün başlığı.
   * @return productLabel
  **/
  @ApiModelProperty(example = "Kırmızı Kalem", value = "Ürün başlığı.")
  public String getProductLabel() {
    return productLabel;
  }

  public void setProductLabel(String productLabel) {
    this.productLabel = productLabel;
  }

  public ShipmentItem currency(CurrencyEnum currency) {
    this.currency = currency;
    return this;
  }

   /**
   * Ürünün kur bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;USD&lt;/code&gt; : Amerikan Doları&lt;br&gt;&lt;code&gt;EUR&lt;/code&gt; : Euro&lt;br&gt;&lt;code&gt;TL&lt;/code&gt; : Türk Lirası&lt;br&gt;&lt;code&gt;GBP&lt;/code&gt; : İngiliz Sterlini&lt;br&gt;&lt;code&gt;JPY&lt;/code&gt; : Japon Yeni&lt;br&gt;&lt;code&gt;CNY&lt;/code&gt; : Çin Yuanı&lt;br&gt;&lt;code&gt;GR&lt;/code&gt; : Gram Altın&lt;br&gt;&lt;code&gt;CHF&lt;/code&gt; : İsviçre Frangı&lt;br&gt;&lt;/div&gt;
   * @return currency
  **/
  @ApiModelProperty(example = "TL", required = true, value = "Ürünün kur bilgisi.<div class='idea_choice_list'><code>USD</code> : Amerikan Doları<br><code>EUR</code> : Euro<br><code>TL</code> : Türk Lirası<br><code>GBP</code> : İngiliz Sterlini<br><code>JPY</code> : Japon Yeni<br><code>CNY</code> : Çin Yuanı<br><code>GR</code> : Gram Altın<br><code>CHF</code> : İsviçre Frangı<br></div>")
  public CurrencyEnum getCurrency() {
    return currency;
  }

  public void setCurrency(CurrencyEnum currency) {
    this.currency = currency;
  }

  public ShipmentItem tax(Integer tax) {
    this.tax = tax;
    return this;
  }

   /**
   * Ürünün vergi değeri.
   * minimum: 0
   * @return tax
  **/
  @ApiModelProperty(example = "18", value = "Ürünün vergi değeri.")
  public Integer getTax() {
    return tax;
  }

  public void setTax(Integer tax) {
    this.tax = tax;
  }

  public ShipmentItem dm3(Float dm3) {
    this.dm3 = dm3;
    return this;
  }

   /**
   * Ürünün desi bilgisi.
   * minimum: 0
   * @return dm3
  **/
  @ApiModelProperty(example = "1.0", required = true, value = "Ürünün desi bilgisi.")
  public Float getDm3() {
    return dm3;
  }

  public void setDm3(Float dm3) {
    this.dm3 = dm3;
  }

   /**
   * Teslimat Kalemi nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Teslimat Kalemi nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

  public ShipmentItem status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Teslimat Kalemi nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @ApiModelProperty(example = "1", required = true, value = "Teslimat Kalemi nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public ShipmentItem updatedAt(OffsetDateTime updatedAt) {
    this.updatedAt = updatedAt;
    return this;
  }

   /**
   * Teslimat Kalemi nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Teslimat Kalemi nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(OffsetDateTime updatedAt) {
    this.updatedAt = updatedAt;
  }

  public ShipmentItem orderItem(OrderItem orderItem) {
    this.orderItem = orderItem;
    return this;
  }

   /**
   * Get orderItem
   * @return orderItem
  **/
  @ApiModelProperty(value = "")
  public OrderItem getOrderItem() {
    return orderItem;
  }

  public void setOrderItem(OrderItem orderItem) {
    this.orderItem = orderItem;
  }

  public ShipmentItem product(Product product) {
    this.product = product;
    return this;
  }

   /**
   * Get product
   * @return product
  **/
  @ApiModelProperty(value = "")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public ShipmentItem shipment(Shipment shipment) {
    this.shipment = shipment;
    return this;
  }

   /**
   * Get shipment
   * @return shipment
  **/
  @ApiModelProperty(value = "")
  public Shipment getShipment() {
    return shipment;
  }

  public void setShipment(Shipment shipment) {
    this.shipment = shipment;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShipmentItem shipmentItem = (ShipmentItem) o;
    return Objects.equals(this.id, shipmentItem.id) &&
        Objects.equals(this.rootProductId, shipmentItem.rootProductId) &&
        Objects.equals(this.amount, shipmentItem.amount) &&
        Objects.equals(this.price, shipmentItem.price) &&
        Objects.equals(this.productLabel, shipmentItem.productLabel) &&
        Objects.equals(this.currency, shipmentItem.currency) &&
        Objects.equals(this.tax, shipmentItem.tax) &&
        Objects.equals(this.dm3, shipmentItem.dm3) &&
        Objects.equals(this.createdAt, shipmentItem.createdAt) &&
        Objects.equals(this.status, shipmentItem.status) &&
        Objects.equals(this.updatedAt, shipmentItem.updatedAt) &&
        Objects.equals(this.orderItem, shipmentItem.orderItem) &&
        Objects.equals(this.product, shipmentItem.product) &&
        Objects.equals(this.shipment, shipmentItem.shipment);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, rootProductId, amount, price, productLabel, currency, tax, dm3, createdAt, status, updatedAt, orderItem, product, shipment);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShipmentItem {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    rootProductId: ").append(toIndentedString(rootProductId)).append("\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    price: ").append(toIndentedString(price)).append("\n");
    sb.append("    productLabel: ").append(toIndentedString(productLabel)).append("\n");
    sb.append("    currency: ").append(toIndentedString(currency)).append("\n");
    sb.append("    tax: ").append(toIndentedString(tax)).append("\n");
    sb.append("    dm3: ").append(toIndentedString(dm3)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    orderItem: ").append(toIndentedString(orderItem)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("    shipment: ").append(toIndentedString(shipment)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

