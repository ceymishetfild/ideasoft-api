package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.ShippingProvider;
import java.io.IOException;

/**
 * ShippingProviderSetting
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ShippingProviderSetting {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("varKey")
  private String varKey = null;

  @SerializedName("varValue")
  private String varValue = null;

  @SerializedName("shippingProvider")
  private ShippingProvider shippingProvider = null;

  public ShippingProviderSetting id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Teslimat hizmeti sağlayıcısı ayarı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Teslimat hizmeti sağlayıcısı ayarı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ShippingProviderSetting varKey(String varKey) {
    this.varKey = varKey;
    return this;
  }

   /**
   * Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken anahtarı.
   * @return varKey
  **/
  @ApiModelProperty(example = "var-key", required = true, value = "Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken anahtarı.")
  public String getVarKey() {
    return varKey;
  }

  public void setVarKey(String varKey) {
    this.varKey = varKey;
  }

  public ShippingProviderSetting varValue(String varValue) {
    this.varValue = varValue;
    return this;
  }

   /**
   * Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken değeri.
   * @return varValue
  **/
  @ApiModelProperty(example = "var-value", required = true, value = "Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken değeri.")
  public String getVarValue() {
    return varValue;
  }

  public void setVarValue(String varValue) {
    this.varValue = varValue;
  }

  public ShippingProviderSetting shippingProvider(ShippingProvider shippingProvider) {
    this.shippingProvider = shippingProvider;
    return this;
  }

   /**
   * Get shippingProvider
   * @return shippingProvider
  **/
  @ApiModelProperty(value = "")
  public ShippingProvider getShippingProvider() {
    return shippingProvider;
  }

  public void setShippingProvider(ShippingProvider shippingProvider) {
    this.shippingProvider = shippingProvider;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShippingProviderSetting shippingProviderSetting = (ShippingProviderSetting) o;
    return Objects.equals(this.id, shippingProviderSetting.id) &&
        Objects.equals(this.varKey, shippingProviderSetting.varKey) &&
        Objects.equals(this.varValue, shippingProviderSetting.varValue) &&
        Objects.equals(this.shippingProvider, shippingProviderSetting.shippingProvider);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, varKey, varValue, shippingProvider);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShippingProviderSetting {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    varKey: ").append(toIndentedString(varKey)).append("\n");
    sb.append("    varValue: ").append(toIndentedString(varValue)).append("\n");
    sb.append("    shippingProvider: ").append(toIndentedString(shippingProvider)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

