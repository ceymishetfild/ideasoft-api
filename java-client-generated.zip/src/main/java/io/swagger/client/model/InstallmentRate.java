package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.PaymentGateway;
import java.io.IOException;

/**
 * InstallmentRate
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class InstallmentRate {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("installment")
  private Integer installment = null;

  @SerializedName("rate")
  private Float rate = null;

  @SerializedName("paymentGateway")
  private PaymentGateway paymentGateway = null;

  public InstallmentRate id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Taksit oranı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Taksit oranı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public InstallmentRate installment(Integer installment) {
    this.installment = installment;
    return this;
  }

   /**
   * Taksit adeti.
   * @return installment
  **/
  @ApiModelProperty(example = "3", required = true, value = "Taksit adeti.")
  public Integer getInstallment() {
    return installment;
  }

  public void setInstallment(Integer installment) {
    this.installment = installment;
  }

  public InstallmentRate rate(Float rate) {
    this.rate = rate;
    return this;
  }

   /**
   * Taksit adeti için oran bilgisi.
   * minimum: 0
   * @return rate
  **/
  @ApiModelProperty(example = "1.2", required = true, value = "Taksit adeti için oran bilgisi.")
  public Float getRate() {
    return rate;
  }

  public void setRate(Float rate) {
    this.rate = rate;
  }

  public InstallmentRate paymentGateway(PaymentGateway paymentGateway) {
    this.paymentGateway = paymentGateway;
    return this;
  }

   /**
   * Get paymentGateway
   * @return paymentGateway
  **/
  @ApiModelProperty(value = "")
  public PaymentGateway getPaymentGateway() {
    return paymentGateway;
  }

  public void setPaymentGateway(PaymentGateway paymentGateway) {
    this.paymentGateway = paymentGateway;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InstallmentRate installmentRate = (InstallmentRate) o;
    return Objects.equals(this.id, installmentRate.id) &&
        Objects.equals(this.installment, installmentRate.installment) &&
        Objects.equals(this.rate, installmentRate.rate) &&
        Objects.equals(this.paymentGateway, installmentRate.paymentGateway);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, installment, rate, paymentGateway);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InstallmentRate {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    installment: ").append(toIndentedString(installment)).append("\n");
    sb.append("    rate: ").append(toIndentedString(rate)).append("\n");
    sb.append("    paymentGateway: ").append(toIndentedString(paymentGateway)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

