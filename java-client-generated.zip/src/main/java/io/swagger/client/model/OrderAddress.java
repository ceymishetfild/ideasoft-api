package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Order;
import java.io.IOException;

/**
 * OrderAddress
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class OrderAddress {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("firstname")
  private String firstname = null;

  @SerializedName("surname")
  private String surname = null;

  @SerializedName("country")
  private String country = null;

  @SerializedName("location")
  private String location = null;

  @SerializedName("subLocation")
  private String subLocation = null;

  @SerializedName("address")
  private String address = null;

  @SerializedName("phoneNumber")
  private String phoneNumber = null;

  @SerializedName("mobilePhoneNumber")
  private String mobilePhoneNumber = null;

  @SerializedName("order")
  private Order order = null;

  public OrderAddress id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Sipariş adresi nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Sipariş adresi nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OrderAddress firstname(String firstname) {
    this.firstname = firstname;
    return this;
  }

   /**
   * Müşterinin ismi.
   * @return firstname
  **/
  @ApiModelProperty(example = "John", required = true, value = "Müşterinin ismi.")
  public String getFirstname() {
    return firstname;
  }

  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }

  public OrderAddress surname(String surname) {
    this.surname = surname;
    return this;
  }

   /**
   * Müşterinin soy ismi.
   * @return surname
  **/
  @ApiModelProperty(example = "Doe", required = true, value = "Müşterinin soy ismi.")
  public String getSurname() {
    return surname;
  }

  public void setSurname(String surname) {
    this.surname = surname;
  }

  public OrderAddress country(String country) {
    this.country = country;
    return this;
  }

   /**
   * Müşterinin ülke bilgisi.
   * @return country
  **/
  @ApiModelProperty(example = "Türkiye", required = true, value = "Müşterinin ülke bilgisi.")
  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public OrderAddress location(String location) {
    this.location = location;
    return this;
  }

   /**
   * Müşterinin şehir bilgisi.
   * @return location
  **/
  @ApiModelProperty(example = "İstanbul", required = true, value = "Müşterinin şehir bilgisi.")
  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public OrderAddress subLocation(String subLocation) {
    this.subLocation = subLocation;
    return this;
  }

   /**
   * Müşterinin ilçe bilgisi.
   * @return subLocation
  **/
  @ApiModelProperty(example = "Üsküdar", value = "Müşterinin ilçe bilgisi.")
  public String getSubLocation() {
    return subLocation;
  }

  public void setSubLocation(String subLocation) {
    this.subLocation = subLocation;
  }

  public OrderAddress address(String address) {
    this.address = address;
    return this;
  }

   /**
   * Müşterinin adres bilgisi.
   * @return address
  **/
  @ApiModelProperty(example = "Cumhuriyet Mah. Libadiye Cad. Çimen Sok. No:2", required = true, value = "Müşterinin adres bilgisi.")
  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public OrderAddress phoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
    return this;
  }

   /**
   * Müşterinin telefon numarası.
   * @return phoneNumber
  **/
  @ApiModelProperty(example = "+90 (216) 326 04 77", required = true, value = "Müşterinin telefon numarası.")
  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public OrderAddress mobilePhoneNumber(String mobilePhoneNumber) {
    this.mobilePhoneNumber = mobilePhoneNumber;
    return this;
  }

   /**
   * Müşterinin mobil telefon numarası.
   * @return mobilePhoneNumber
  **/
  @ApiModelProperty(example = "+90 (555) 555 55 55", value = "Müşterinin mobil telefon numarası.")
  public String getMobilePhoneNumber() {
    return mobilePhoneNumber;
  }

  public void setMobilePhoneNumber(String mobilePhoneNumber) {
    this.mobilePhoneNumber = mobilePhoneNumber;
  }

  public OrderAddress order(Order order) {
    this.order = order;
    return this;
  }

   /**
   * Get order
   * @return order
  **/
  @ApiModelProperty(value = "")
  public Order getOrder() {
    return order;
  }

  public void setOrder(Order order) {
    this.order = order;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrderAddress orderAddress = (OrderAddress) o;
    return Objects.equals(this.id, orderAddress.id) &&
        Objects.equals(this.firstname, orderAddress.firstname) &&
        Objects.equals(this.surname, orderAddress.surname) &&
        Objects.equals(this.country, orderAddress.country) &&
        Objects.equals(this.location, orderAddress.location) &&
        Objects.equals(this.subLocation, orderAddress.subLocation) &&
        Objects.equals(this.address, orderAddress.address) &&
        Objects.equals(this.phoneNumber, orderAddress.phoneNumber) &&
        Objects.equals(this.mobilePhoneNumber, orderAddress.mobilePhoneNumber) &&
        Objects.equals(this.order, orderAddress.order);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, firstname, surname, country, location, subLocation, address, phoneNumber, mobilePhoneNumber, order);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderAddress {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    firstname: ").append(toIndentedString(firstname)).append("\n");
    sb.append("    surname: ").append(toIndentedString(surname)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("    location: ").append(toIndentedString(location)).append("\n");
    sb.append("    subLocation: ").append(toIndentedString(subLocation)).append("\n");
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
    sb.append("    mobilePhoneNumber: ").append(toIndentedString(mobilePhoneNumber)).append("\n");
    sb.append("    order: ").append(toIndentedString(order)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

