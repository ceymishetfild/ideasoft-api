package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.IOException;

/**
 * ShopUserlevels
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ShopUserlevels {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("label")
  private String label = null;

  @SerializedName("roles")
  private String roles = null;

  public ShopUserlevels id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Yönetici grubu nesnesinin benzersiz rakamsal kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Yönetici grubu nesnesinin benzersiz rakamsal kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ShopUserlevels label(String label) {
    this.label = label;
    return this;
  }

   /**
   * Yönetici grubu ismi.
   * @return label
  **/
  @ApiModelProperty(example = "Yönetici", value = "Yönetici grubu ismi.")
  public String getLabel() {
    return label;
  }

  public void setLabel(String label) {
    this.label = label;
  }

  public ShopUserlevels roles(String roles) {
    this.roles = roles;
    return this;
  }

   /**
   * Yönetici grubunun sahip olduğu roller.
   * @return roles
  **/
  @ApiModelProperty(example = "", value = "Yönetici grubunun sahip olduğu roller.")
  public String getRoles() {
    return roles;
  }

  public void setRoles(String roles) {
    this.roles = roles;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShopUserlevels shopUserlevels = (ShopUserlevels) o;
    return Objects.equals(this.id, shopUserlevels.id) &&
        Objects.equals(this.label, shopUserlevels.label) &&
        Objects.equals(this.roles, shopUserlevels.roles);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, label, roles);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShopUserlevels {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    label: ").append(toIndentedString(label)).append("\n");
    sb.append("    roles: ").append(toIndentedString(roles)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

