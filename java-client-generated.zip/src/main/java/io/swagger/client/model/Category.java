package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Category;
import java.io.IOException;
import org.threeten.bp.OffsetDateTime;

/**
 * Category
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Category {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("name")
  private String name = null;

  @SerializedName("slug")
  private String slug = null;

  @SerializedName("sortOrder")
  private Integer sortOrder = null;

  /**
   * Kategori nesnesinin aktiflik durumunu belirten değer.
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    _0("0"),
    
    _1("1");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  @SerializedName("percent")
  private Float percent = null;

  @SerializedName("imageFile")
  private String imageFile = null;

  @SerializedName("distributor")
  private String distributor = null;

  @SerializedName("displayShowcaseContent")
  private Integer displayShowcaseContent = null;

  @SerializedName("showcaseContent")
  private String showcaseContent = null;

  @SerializedName("showcaseContentDisplayType")
  private Integer showcaseContentDisplayType = null;

  /**
   * Kategori nesnesinin alt kategori barındırma durumu. Bu değer otomatik oluşturulur.
   */
  @JsonAdapter(HasChildrenEnum.Adapter.class)
  public enum HasChildrenEnum {
    _0("0"),
    
    _1("1");

    private String value;

    HasChildrenEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static HasChildrenEnum fromValue(String text) {
      for (HasChildrenEnum b : HasChildrenEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<HasChildrenEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final HasChildrenEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public HasChildrenEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return HasChildrenEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("hasChildren")
  private HasChildrenEnum hasChildren = null;

  @SerializedName("metaKeywords")
  private String metaKeywords = null;

  @SerializedName("metaDescription")
  private String metaDescription = null;

  @SerializedName("pageTitle")
  private String pageTitle = null;

  @SerializedName("parent")
  private Category parent = null;

  @SerializedName("attachment")
  private String attachment = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  public Category id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Kategori nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Kategori nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Category name(String name) {
    this.name = name;
    return this;
  }

   /**
   * Kategori nesnesi için isim değeri.
   * @return name
  **/
  @ApiModelProperty(example = "Kırtasiye", required = true, value = "Kategori nesnesi için isim değeri.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Category slug(String slug) {
    this.slug = slug;
    return this;
  }

   /**
   * Slug değeri ilgili nesnenin Url değeridir.
   * @return slug
  **/
  @ApiModelProperty(example = "kirtasiye", value = "Slug değeri ilgili nesnenin Url değeridir.")
  public String getSlug() {
    return slug;
  }

  public void setSlug(String slug) {
    this.slug = slug;
  }

  public Category sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

   /**
   * Kategori nesnesi için sıralama değeri.
   * minimum: 0
   * maximum: 999
   * @return sortOrder
  **/
  @ApiModelProperty(example = "999", value = "Kategori nesnesi için sıralama değeri.")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public Category status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Kategori nesnesinin aktiflik durumunu belirten değer.
   * @return status
  **/
  @ApiModelProperty(example = "1", required = true, value = "Kategori nesnesinin aktiflik durumunu belirten değer.")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Category percent(Float percent) {
    this.percent = percent;
    return this;
  }

   /**
   * Kategori nesnesinin fiyat katsayısı.
   * minimum: 0
   * @return percent
  **/
  @ApiModelProperty(example = "1.0", value = "Kategori nesnesinin fiyat katsayısı.")
  public Float getPercent() {
    return percent;
  }

  public void setPercent(Float percent) {
    this.percent = percent;
  }

  public Category imageFile(String imageFile) {
    this.imageFile = imageFile;
    return this;
  }

   /**
   * Kategori nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF
   * @return imageFile
  **/
  @ApiModelProperty(example = "kalem.jpg", value = "Kategori nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF")
  public String getImageFile() {
    return imageFile;
  }

  public void setImageFile(String imageFile) {
    this.imageFile = imageFile;
  }

  public Category distributor(String distributor) {
    this.distributor = distributor;
    return this;
  }

   /**
   * Her zaman null değer alır. Pratikte kullanımı yoktur.
   * @return distributor
  **/
  @ApiModelProperty(example = "", value = "Her zaman null değer alır. Pratikte kullanımı yoktur.")
  public String getDistributor() {
    return distributor;
  }

  public void setDistributor(String distributor) {
    this.distributor = distributor;
  }

  public Category displayShowcaseContent(Integer displayShowcaseContent) {
    this.displayShowcaseContent = displayShowcaseContent;
    return this;
  }

   /**
   * Kategori nesnesinin üst içerik metninin gösterim durumu.
   * @return displayShowcaseContent
  **/
  @ApiModelProperty(example = "1", value = "Kategori nesnesinin üst içerik metninin gösterim durumu.")
  public Integer getDisplayShowcaseContent() {
    return displayShowcaseContent;
  }

  public void setDisplayShowcaseContent(Integer displayShowcaseContent) {
    this.displayShowcaseContent = displayShowcaseContent;
  }

  public Category showcaseContent(String showcaseContent) {
    this.showcaseContent = showcaseContent;
    return this;
  }

   /**
   * Kategori nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir.
   * @return showcaseContent
  **/
  @ApiModelProperty(example = "Üst içerik metni.", value = "Kategori nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir.")
  public String getShowcaseContent() {
    return showcaseContent;
  }

  public void setShowcaseContent(String showcaseContent) {
    this.showcaseContent = showcaseContent;
  }

  public Category showcaseContentDisplayType(Integer showcaseContentDisplayType) {
    this.showcaseContentDisplayType = showcaseContentDisplayType;
    return this;
  }

   /**
   * Kategori nesnesinin üst içerik metninin gösterim tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kategori içeriği.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Kategori ve üst kategori içeriği.&lt;br&gt;&lt;code&gt;3&lt;/code&gt; : Kategori ve tüm üst kategoriler.&lt;br&gt;&lt;/div&gt;
   * @return showcaseContentDisplayType
  **/
  @ApiModelProperty(example = "3", required = true, value = "Kategori nesnesinin üst içerik metninin gösterim tipi.<div class='idea_choice_list'><code>1</code> : Kategori içeriği.<br><code>2</code> : Kategori ve üst kategori içeriği.<br><code>3</code> : Kategori ve tüm üst kategoriler.<br></div>")
  public Integer getShowcaseContentDisplayType() {
    return showcaseContentDisplayType;
  }

  public void setShowcaseContentDisplayType(Integer showcaseContentDisplayType) {
    this.showcaseContentDisplayType = showcaseContentDisplayType;
  }

   /**
   * Kategori nesnesinin alt kategori barındırma durumu. Bu değer otomatik oluşturulur.
   * @return hasChildren
  **/
  @ApiModelProperty(example = "1", value = "Kategori nesnesinin alt kategori barındırma durumu. Bu değer otomatik oluşturulur.")
  public HasChildrenEnum getHasChildren() {
    return hasChildren;
  }

  public Category metaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
    return this;
  }

   /**
   * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.
   * @return metaKeywords
  **/
  @ApiModelProperty(example = "kırmızı, kalem, kırtasiye", value = "Arama motorları tarafından tespit edilebilecek anahtar kelimeler.")
  public String getMetaKeywords() {
    return metaKeywords;
  }

  public void setMetaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
  }

  public Category metaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
    return this;
  }

   /**
   * Arama motorları tarafından tespit edilebilecek açıklama yazısı.
   * @return metaDescription
  **/
  @ApiModelProperty(example = "Kaliteli kırtasiye ürünleri.", value = "Arama motorları tarafından tespit edilebilecek açıklama yazısı.")
  public String getMetaDescription() {
    return metaDescription;
  }

  public void setMetaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
  }

  public Category pageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
    return this;
  }

   /**
   * Kategori nesnesinin etiket başlığı.
   * @return pageTitle
  **/
  @ApiModelProperty(example = "Kırmızı Kalem", value = "Kategori nesnesinin etiket başlığı.")
  public String getPageTitle() {
    return pageTitle;
  }

  public void setPageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
  }

  public Category parent(Category parent) {
    this.parent = parent;
    return this;
  }

   /**
   * Get parent
   * @return parent
  **/
  @ApiModelProperty(value = "")
  public Category getParent() {
    return parent;
  }

  public void setParent(Category parent) {
    this.parent = parent;
  }

  public Category attachment(String attachment) {
    this.attachment = attachment;
    return this;
  }

   /**
   * Kategori nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
   * @return attachment
  **/
  @ApiModelProperty(example = "Buraya example gelecek.", value = "Kategori nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.")
  public String getAttachment() {
    return attachment;
  }

  public void setAttachment(String attachment) {
    this.attachment = attachment;
  }

   /**
   * Kategori nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Kategori nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

   /**
   * Kategori nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Kategori nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Category category = (Category) o;
    return Objects.equals(this.id, category.id) &&
        Objects.equals(this.name, category.name) &&
        Objects.equals(this.slug, category.slug) &&
        Objects.equals(this.sortOrder, category.sortOrder) &&
        Objects.equals(this.status, category.status) &&
        Objects.equals(this.percent, category.percent) &&
        Objects.equals(this.imageFile, category.imageFile) &&
        Objects.equals(this.distributor, category.distributor) &&
        Objects.equals(this.displayShowcaseContent, category.displayShowcaseContent) &&
        Objects.equals(this.showcaseContent, category.showcaseContent) &&
        Objects.equals(this.showcaseContentDisplayType, category.showcaseContentDisplayType) &&
        Objects.equals(this.hasChildren, category.hasChildren) &&
        Objects.equals(this.metaKeywords, category.metaKeywords) &&
        Objects.equals(this.metaDescription, category.metaDescription) &&
        Objects.equals(this.pageTitle, category.pageTitle) &&
        Objects.equals(this.parent, category.parent) &&
        Objects.equals(this.attachment, category.attachment) &&
        Objects.equals(this.createdAt, category.createdAt) &&
        Objects.equals(this.updatedAt, category.updatedAt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, slug, sortOrder, status, percent, imageFile, distributor, displayShowcaseContent, showcaseContent, showcaseContentDisplayType, hasChildren, metaKeywords, metaDescription, pageTitle, parent, attachment, createdAt, updatedAt);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Category {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    slug: ").append(toIndentedString(slug)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    percent: ").append(toIndentedString(percent)).append("\n");
    sb.append("    imageFile: ").append(toIndentedString(imageFile)).append("\n");
    sb.append("    distributor: ").append(toIndentedString(distributor)).append("\n");
    sb.append("    displayShowcaseContent: ").append(toIndentedString(displayShowcaseContent)).append("\n");
    sb.append("    showcaseContent: ").append(toIndentedString(showcaseContent)).append("\n");
    sb.append("    showcaseContentDisplayType: ").append(toIndentedString(showcaseContentDisplayType)).append("\n");
    sb.append("    hasChildren: ").append(toIndentedString(hasChildren)).append("\n");
    sb.append("    metaKeywords: ").append(toIndentedString(metaKeywords)).append("\n");
    sb.append("    metaDescription: ").append(toIndentedString(metaDescription)).append("\n");
    sb.append("    pageTitle: ").append(toIndentedString(pageTitle)).append("\n");
    sb.append("    parent: ").append(toIndentedString(parent)).append("\n");
    sb.append("    attachment: ").append(toIndentedString(attachment)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

