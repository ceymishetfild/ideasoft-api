package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Country;
import io.swagger.client.model.Location;
import io.swagger.client.model.MemberAddress;
import io.swagger.client.model.ShippingCompany;
import java.io.IOException;
import org.threeten.bp.LocalDate;
import org.threeten.bp.OffsetDateTime;

/**
 * PreOrderInfo
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class PreOrderInfo {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("sessionId")
  private String sessionId = null;

  @SerializedName("customerFirstname")
  private String customerFirstname = null;

  @SerializedName("customerSurname")
  private String customerSurname = null;

  @SerializedName("customerEmail")
  private String customerEmail = null;

  @SerializedName("shippingFirstname")
  private String shippingFirstname = null;

  @SerializedName("shippingSurname")
  private String shippingSurname = null;

  @SerializedName("shippingAddress")
  private String shippingAddress = null;

  @SerializedName("shippingPhoneNumber")
  private String shippingPhoneNumber = null;

  @SerializedName("shippingMobilePhoneNumber")
  private String shippingMobilePhoneNumber = null;

  @SerializedName("shippingLocationName")
  private String shippingLocationName = null;

  @SerializedName("shippingTown")
  private String shippingTown = null;

  /**
   * Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yok&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(DifferentBillingAddressEnum.Adapter.class)
  public enum DifferentBillingAddressEnum {
    _0("0"),
    
    _1("1");

    private String value;

    DifferentBillingAddressEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static DifferentBillingAddressEnum fromValue(String text) {
      for (DifferentBillingAddressEnum b : DifferentBillingAddressEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<DifferentBillingAddressEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final DifferentBillingAddressEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public DifferentBillingAddressEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return DifferentBillingAddressEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("differentBillingAddress")
  private DifferentBillingAddressEnum differentBillingAddress = null;

  @SerializedName("billingFirstname")
  private String billingFirstname = null;

  @SerializedName("billingSurname")
  private String billingSurname = null;

  @SerializedName("billingAddress")
  private String billingAddress = null;

  @SerializedName("billingPhoneNumber")
  private String billingPhoneNumber = null;

  @SerializedName("billingMobilePhoneNumber")
  private String billingMobilePhoneNumber = null;

  @SerializedName("billingLocationName")
  private String billingLocationName = null;

  @SerializedName("billingTown")
  private String billingTown = null;

  /**
   * Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(BillingInvoiceTypeEnum.Adapter.class)
  public enum BillingInvoiceTypeEnum {
    INDIVIDUAL("individual"),
    
    CORPORATE("corporate");

    private String value;

    BillingInvoiceTypeEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static BillingInvoiceTypeEnum fromValue(String text) {
      for (BillingInvoiceTypeEnum b : BillingInvoiceTypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<BillingInvoiceTypeEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final BillingInvoiceTypeEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public BillingInvoiceTypeEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return BillingInvoiceTypeEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("billingInvoiceType")
  private BillingInvoiceTypeEnum billingInvoiceType = null;

  @SerializedName("billingIdentityRegistrationNumber")
  private String billingIdentityRegistrationNumber = null;

  @SerializedName("billingTaxOffice")
  private String billingTaxOffice = null;

  @SerializedName("billingTaxNo")
  private String billingTaxNo = null;

  /**
   * Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(IsEinvoiceUserEnum.Adapter.class)
  public enum IsEinvoiceUserEnum {
    _0("0"),
    
    _1("1");

    private String value;

    IsEinvoiceUserEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static IsEinvoiceUserEnum fromValue(String text) {
      for (IsEinvoiceUserEnum b : IsEinvoiceUserEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<IsEinvoiceUserEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final IsEinvoiceUserEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public IsEinvoiceUserEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return IsEinvoiceUserEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("isEinvoiceUser")
  private IsEinvoiceUserEnum isEinvoiceUser = null;

  /**
   * Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(UseGiftPackageEnum.Adapter.class)
  public enum UseGiftPackageEnum {
    _0("0"),
    
    _1("1");

    private String value;

    UseGiftPackageEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static UseGiftPackageEnum fromValue(String text) {
      for (UseGiftPackageEnum b : UseGiftPackageEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<UseGiftPackageEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final UseGiftPackageEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public UseGiftPackageEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return UseGiftPackageEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("useGiftPackage")
  private UseGiftPackageEnum useGiftPackage = null;

  @SerializedName("giftNote")
  private String giftNote = null;

  @SerializedName("imageFile")
  private String imageFile = null;

  @SerializedName("deliveryDate")
  private LocalDate deliveryDate = null;

  @SerializedName("deliveryTime")
  private String deliveryTime = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  @SerializedName("billingCountry")
  private Country billingCountry = null;

  @SerializedName("billingLocation")
  private Location billingLocation = null;

  @SerializedName("shippingCompany")
  private ShippingCompany shippingCompany = null;

  @SerializedName("shippingCountry")
  private Country shippingCountry = null;

  @SerializedName("shippingLocation")
  private Location shippingLocation = null;

  @SerializedName("memberShippingAddress")
  private MemberAddress memberShippingAddress = null;

  @SerializedName("memberBillingAddress")
  private MemberAddress memberBillingAddress = null;

  public PreOrderInfo id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Sipariş öncesi bilgisi nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Sipariş öncesi bilgisi nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public PreOrderInfo sessionId(String sessionId) {
    this.sessionId = sessionId;
    return this;
  }

   /**
   * Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri.
   * @return sessionId
  **/
  @ApiModelProperty(example = "oibtkn9rspcdbmphf8iceondg1", required = true, value = "Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri.")
  public String getSessionId() {
    return sessionId;
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  public PreOrderInfo customerFirstname(String customerFirstname) {
    this.customerFirstname = customerFirstname;
    return this;
  }

   /**
   * Müşterinin ismi.
   * @return customerFirstname
  **/
  @ApiModelProperty(example = "John", value = "Müşterinin ismi.")
  public String getCustomerFirstname() {
    return customerFirstname;
  }

  public void setCustomerFirstname(String customerFirstname) {
    this.customerFirstname = customerFirstname;
  }

  public PreOrderInfo customerSurname(String customerSurname) {
    this.customerSurname = customerSurname;
    return this;
  }

   /**
   * Müşterinin soy ismi.
   * @return customerSurname
  **/
  @ApiModelProperty(example = "Doe", value = "Müşterinin soy ismi.")
  public String getCustomerSurname() {
    return customerSurname;
  }

  public void setCustomerSurname(String customerSurname) {
    this.customerSurname = customerSurname;
  }

  public PreOrderInfo customerEmail(String customerEmail) {
    this.customerEmail = customerEmail;
    return this;
  }

   /**
   * Müşterinin e-mail adresi.
   * @return customerEmail
  **/
  @ApiModelProperty(example = "johndoe@ideasoft.com.tr", value = "Müşterinin e-mail adresi.")
  public String getCustomerEmail() {
    return customerEmail;
  }

  public void setCustomerEmail(String customerEmail) {
    this.customerEmail = customerEmail;
  }

  public PreOrderInfo shippingFirstname(String shippingFirstname) {
    this.shippingFirstname = shippingFirstname;
    return this;
  }

   /**
   * Teslimat yapılacak kişinin ismi.
   * @return shippingFirstname
  **/
  @ApiModelProperty(example = "John", required = true, value = "Teslimat yapılacak kişinin ismi.")
  public String getShippingFirstname() {
    return shippingFirstname;
  }

  public void setShippingFirstname(String shippingFirstname) {
    this.shippingFirstname = shippingFirstname;
  }

  public PreOrderInfo shippingSurname(String shippingSurname) {
    this.shippingSurname = shippingSurname;
    return this;
  }

   /**
   * Teslimat yapılacak kişinin soy ismi.
   * @return shippingSurname
  **/
  @ApiModelProperty(example = "Doe", required = true, value = "Teslimat yapılacak kişinin soy ismi.")
  public String getShippingSurname() {
    return shippingSurname;
  }

  public void setShippingSurname(String shippingSurname) {
    this.shippingSurname = shippingSurname;
  }

  public PreOrderInfo shippingAddress(String shippingAddress) {
    this.shippingAddress = shippingAddress;
    return this;
  }

   /**
   * Teslimat adresi bilgileri.
   * @return shippingAddress
  **/
  @ApiModelProperty(example = "Cumhuriyet Mah. Libadiye Cad. Çimen Sok. No:2", required = true, value = "Teslimat adresi bilgileri.")
  public String getShippingAddress() {
    return shippingAddress;
  }

  public void setShippingAddress(String shippingAddress) {
    this.shippingAddress = shippingAddress;
  }

  public PreOrderInfo shippingPhoneNumber(String shippingPhoneNumber) {
    this.shippingPhoneNumber = shippingPhoneNumber;
    return this;
  }

   /**
   * Teslimat yapılacak kişinin telefon numarası.
   * @return shippingPhoneNumber
  **/
  @ApiModelProperty(example = "+90 (216) 326 04 77", required = true, value = "Teslimat yapılacak kişinin telefon numarası.")
  public String getShippingPhoneNumber() {
    return shippingPhoneNumber;
  }

  public void setShippingPhoneNumber(String shippingPhoneNumber) {
    this.shippingPhoneNumber = shippingPhoneNumber;
  }

  public PreOrderInfo shippingMobilePhoneNumber(String shippingMobilePhoneNumber) {
    this.shippingMobilePhoneNumber = shippingMobilePhoneNumber;
    return this;
  }

   /**
   * Teslimat yapılacak kişinin mobil telefon numarası.
   * @return shippingMobilePhoneNumber
  **/
  @ApiModelProperty(example = "+90 (555) 555 55 55", required = true, value = "Teslimat yapılacak kişinin mobil telefon numarası.")
  public String getShippingMobilePhoneNumber() {
    return shippingMobilePhoneNumber;
  }

  public void setShippingMobilePhoneNumber(String shippingMobilePhoneNumber) {
    this.shippingMobilePhoneNumber = shippingMobilePhoneNumber;
  }

  public PreOrderInfo shippingLocationName(String shippingLocationName) {
    this.shippingLocationName = shippingLocationName;
    return this;
  }

   /**
   * Teslimat şehri.
   * @return shippingLocationName
  **/
  @ApiModelProperty(example = "İstanbul", required = true, value = "Teslimat şehri.")
  public String getShippingLocationName() {
    return shippingLocationName;
  }

  public void setShippingLocationName(String shippingLocationName) {
    this.shippingLocationName = shippingLocationName;
  }

  public PreOrderInfo shippingTown(String shippingTown) {
    this.shippingTown = shippingTown;
    return this;
  }

   /**
   * Teslimat ilçesi.
   * @return shippingTown
  **/
  @ApiModelProperty(example = "Üsküdar", required = true, value = "Teslimat ilçesi.")
  public String getShippingTown() {
    return shippingTown;
  }

  public void setShippingTown(String shippingTown) {
    this.shippingTown = shippingTown;
  }

  public PreOrderInfo differentBillingAddress(DifferentBillingAddressEnum differentBillingAddress) {
    this.differentBillingAddress = differentBillingAddress;
    return this;
  }

   /**
   * Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yok&lt;br&gt;&lt;/div&gt;
   * @return differentBillingAddress
  **/
  @ApiModelProperty(example = "0", value = "Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.<div class='idea_choice_list'><code>1</code> : Var<br><code>0</code> : Yok<br></div>")
  public DifferentBillingAddressEnum getDifferentBillingAddress() {
    return differentBillingAddress;
  }

  public void setDifferentBillingAddress(DifferentBillingAddressEnum differentBillingAddress) {
    this.differentBillingAddress = differentBillingAddress;
  }

  public PreOrderInfo billingFirstname(String billingFirstname) {
    this.billingFirstname = billingFirstname;
    return this;
  }

   /**
   * Fatura kesilen kişinin ismi.
   * @return billingFirstname
  **/
  @ApiModelProperty(example = "John", required = true, value = "Fatura kesilen kişinin ismi.")
  public String getBillingFirstname() {
    return billingFirstname;
  }

  public void setBillingFirstname(String billingFirstname) {
    this.billingFirstname = billingFirstname;
  }

  public PreOrderInfo billingSurname(String billingSurname) {
    this.billingSurname = billingSurname;
    return this;
  }

   /**
   * Fatura kesilen kişinin soy ismi.
   * @return billingSurname
  **/
  @ApiModelProperty(example = "Doe", required = true, value = "Fatura kesilen kişinin soy ismi.")
  public String getBillingSurname() {
    return billingSurname;
  }

  public void setBillingSurname(String billingSurname) {
    this.billingSurname = billingSurname;
  }

  public PreOrderInfo billingAddress(String billingAddress) {
    this.billingAddress = billingAddress;
    return this;
  }

   /**
   * Fatura adresi bilgileri.
   * @return billingAddress
  **/
  @ApiModelProperty(example = "Cumhuriyet Mah. Libadiye Cad. Çimen Sok. No:2", required = true, value = "Fatura adresi bilgileri.")
  public String getBillingAddress() {
    return billingAddress;
  }

  public void setBillingAddress(String billingAddress) {
    this.billingAddress = billingAddress;
  }

  public PreOrderInfo billingPhoneNumber(String billingPhoneNumber) {
    this.billingPhoneNumber = billingPhoneNumber;
    return this;
  }

   /**
   * Fatura kesilen kişinin telefon numarası.
   * @return billingPhoneNumber
  **/
  @ApiModelProperty(example = "+90 (216) 326 04 77", required = true, value = "Fatura kesilen kişinin telefon numarası.")
  public String getBillingPhoneNumber() {
    return billingPhoneNumber;
  }

  public void setBillingPhoneNumber(String billingPhoneNumber) {
    this.billingPhoneNumber = billingPhoneNumber;
  }

  public PreOrderInfo billingMobilePhoneNumber(String billingMobilePhoneNumber) {
    this.billingMobilePhoneNumber = billingMobilePhoneNumber;
    return this;
  }

   /**
   * Fatura kesilen kişinin mobil telefon numarası.
   * @return billingMobilePhoneNumber
  **/
  @ApiModelProperty(example = "+90 (555) 555 55 55", required = true, value = "Fatura kesilen kişinin mobil telefon numarası.")
  public String getBillingMobilePhoneNumber() {
    return billingMobilePhoneNumber;
  }

  public void setBillingMobilePhoneNumber(String billingMobilePhoneNumber) {
    this.billingMobilePhoneNumber = billingMobilePhoneNumber;
  }

  public PreOrderInfo billingLocationName(String billingLocationName) {
    this.billingLocationName = billingLocationName;
    return this;
  }

   /**
   * Fatura adresi şehri
   * @return billingLocationName
  **/
  @ApiModelProperty(example = "İstanbul", required = true, value = "Fatura adresi şehri")
  public String getBillingLocationName() {
    return billingLocationName;
  }

  public void setBillingLocationName(String billingLocationName) {
    this.billingLocationName = billingLocationName;
  }

  public PreOrderInfo billingTown(String billingTown) {
    this.billingTown = billingTown;
    return this;
  }

   /**
   * Fatura adresi ilçesi.
   * @return billingTown
  **/
  @ApiModelProperty(example = "Üsküdar", required = true, value = "Fatura adresi ilçesi.")
  public String getBillingTown() {
    return billingTown;
  }

  public void setBillingTown(String billingTown) {
    this.billingTown = billingTown;
  }

  public PreOrderInfo billingInvoiceType(BillingInvoiceTypeEnum billingInvoiceType) {
    this.billingInvoiceType = billingInvoiceType;
    return this;
  }

   /**
   * Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt;
   * @return billingInvoiceType
  **/
  @ApiModelProperty(example = "individual", required = true, value = "Fatura tipini belirtir.<div class='idea_choice_list'><code>individual</code> : Bireysel<br><code>corporate</code> : Kurumsal<br></div>")
  public BillingInvoiceTypeEnum getBillingInvoiceType() {
    return billingInvoiceType;
  }

  public void setBillingInvoiceType(BillingInvoiceTypeEnum billingInvoiceType) {
    this.billingInvoiceType = billingInvoiceType;
  }

  public PreOrderInfo billingIdentityRegistrationNumber(String billingIdentityRegistrationNumber) {
    this.billingIdentityRegistrationNumber = billingIdentityRegistrationNumber;
    return this;
  }

   /**
   * Fatura kesilen kişinin TC kimlik numarası.
   * @return billingIdentityRegistrationNumber
  **/
  @ApiModelProperty(example = "11111111111", value = "Fatura kesilen kişinin TC kimlik numarası.")
  public String getBillingIdentityRegistrationNumber() {
    return billingIdentityRegistrationNumber;
  }

  public void setBillingIdentityRegistrationNumber(String billingIdentityRegistrationNumber) {
    this.billingIdentityRegistrationNumber = billingIdentityRegistrationNumber;
  }

  public PreOrderInfo billingTaxOffice(String billingTaxOffice) {
    this.billingTaxOffice = billingTaxOffice;
    return this;
  }

   /**
   * Fatura kesilen kişi/kurumun vergi dairesi.
   * @return billingTaxOffice
  **/
  @ApiModelProperty(example = "Üsküdar", value = "Fatura kesilen kişi/kurumun vergi dairesi.")
  public String getBillingTaxOffice() {
    return billingTaxOffice;
  }

  public void setBillingTaxOffice(String billingTaxOffice) {
    this.billingTaxOffice = billingTaxOffice;
  }

  public PreOrderInfo billingTaxNo(String billingTaxNo) {
    this.billingTaxNo = billingTaxNo;
    return this;
  }

   /**
   * Fatura kesilen kişi/kurum vergi numarası.
   * @return billingTaxNo
  **/
  @ApiModelProperty(example = "9325912620", value = "Fatura kesilen kişi/kurum vergi numarası.")
  public String getBillingTaxNo() {
    return billingTaxNo;
  }

  public void setBillingTaxNo(String billingTaxNo) {
    this.billingTaxNo = billingTaxNo;
  }

  public PreOrderInfo isEinvoiceUser(IsEinvoiceUserEnum isEinvoiceUser) {
    this.isEinvoiceUser = isEinvoiceUser;
    return this;
  }

   /**
   * Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt;
   * @return isEinvoiceUser
  **/
  @ApiModelProperty(example = "1", value = "Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div>")
  public IsEinvoiceUserEnum getIsEinvoiceUser() {
    return isEinvoiceUser;
  }

  public void setIsEinvoiceUser(IsEinvoiceUserEnum isEinvoiceUser) {
    this.isEinvoiceUser = isEinvoiceUser;
  }

  public PreOrderInfo useGiftPackage(UseGiftPackageEnum useGiftPackage) {
    this.useGiftPackage = useGiftPackage;
    return this;
  }

   /**
   * Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt;
   * @return useGiftPackage
  **/
  @ApiModelProperty(example = "0", value = "Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div>")
  public UseGiftPackageEnum getUseGiftPackage() {
    return useGiftPackage;
  }

  public void setUseGiftPackage(UseGiftPackageEnum useGiftPackage) {
    this.useGiftPackage = useGiftPackage;
  }

  public PreOrderInfo giftNote(String giftNote) {
    this.giftNote = giftNote;
    return this;
  }

   /**
   * Hediye notu bilgisi.
   * @return giftNote
  **/
  @ApiModelProperty(example = "Doğum günün kutlu olsun.", value = "Hediye notu bilgisi.")
  public String getGiftNote() {
    return giftNote;
  }

  public void setGiftNote(String giftNote) {
    this.giftNote = giftNote;
  }

  public PreOrderInfo imageFile(String imageFile) {
    this.imageFile = imageFile;
    return this;
  }

   /**
   * Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif
   * @return imageFile
  **/
  @ApiModelProperty(example = "kalem.jpg", value = "Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif")
  public String getImageFile() {
    return imageFile;
  }

  public void setImageFile(String imageFile) {
    this.imageFile = imageFile;
  }

  public PreOrderInfo deliveryDate(LocalDate deliveryDate) {
    this.deliveryDate = deliveryDate;
    return this;
  }

   /**
   * Müşterinin teslimatın gerçekleşmisini istediği tarih.
   * @return deliveryDate
  **/
  @ApiModelProperty(example = "2018-02-21T18:30:00+0000", value = "Müşterinin teslimatın gerçekleşmisini istediği tarih.")
  public LocalDate getDeliveryDate() {
    return deliveryDate;
  }

  public void setDeliveryDate(LocalDate deliveryDate) {
    this.deliveryDate = deliveryDate;
  }

  public PreOrderInfo deliveryTime(String deliveryTime) {
    this.deliveryTime = deliveryTime;
    return this;
  }

   /**
   * API bu değeri otomatik oluşturur.
   * @return deliveryTime
  **/
  @ApiModelProperty(example = "18:00-19:00", value = "API bu değeri otomatik oluşturur.")
  public String getDeliveryTime() {
    return deliveryTime;
  }

  public void setDeliveryTime(String deliveryTime) {
    this.deliveryTime = deliveryTime;
  }

   /**
   * Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

   /**
   * Sipariş öncesi bilgisi nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Sipariş öncesi bilgisi nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public PreOrderInfo billingCountry(Country billingCountry) {
    this.billingCountry = billingCountry;
    return this;
  }

   /**
   * Get billingCountry
   * @return billingCountry
  **/
  @ApiModelProperty(value = "")
  public Country getBillingCountry() {
    return billingCountry;
  }

  public void setBillingCountry(Country billingCountry) {
    this.billingCountry = billingCountry;
  }

  public PreOrderInfo billingLocation(Location billingLocation) {
    this.billingLocation = billingLocation;
    return this;
  }

   /**
   * Get billingLocation
   * @return billingLocation
  **/
  @ApiModelProperty(value = "")
  public Location getBillingLocation() {
    return billingLocation;
  }

  public void setBillingLocation(Location billingLocation) {
    this.billingLocation = billingLocation;
  }

  public PreOrderInfo shippingCompany(ShippingCompany shippingCompany) {
    this.shippingCompany = shippingCompany;
    return this;
  }

   /**
   * Get shippingCompany
   * @return shippingCompany
  **/
  @ApiModelProperty(value = "")
  public ShippingCompany getShippingCompany() {
    return shippingCompany;
  }

  public void setShippingCompany(ShippingCompany shippingCompany) {
    this.shippingCompany = shippingCompany;
  }

  public PreOrderInfo shippingCountry(Country shippingCountry) {
    this.shippingCountry = shippingCountry;
    return this;
  }

   /**
   * Get shippingCountry
   * @return shippingCountry
  **/
  @ApiModelProperty(value = "")
  public Country getShippingCountry() {
    return shippingCountry;
  }

  public void setShippingCountry(Country shippingCountry) {
    this.shippingCountry = shippingCountry;
  }

  public PreOrderInfo shippingLocation(Location shippingLocation) {
    this.shippingLocation = shippingLocation;
    return this;
  }

   /**
   * Get shippingLocation
   * @return shippingLocation
  **/
  @ApiModelProperty(value = "")
  public Location getShippingLocation() {
    return shippingLocation;
  }

  public void setShippingLocation(Location shippingLocation) {
    this.shippingLocation = shippingLocation;
  }

  public PreOrderInfo memberShippingAddress(MemberAddress memberShippingAddress) {
    this.memberShippingAddress = memberShippingAddress;
    return this;
  }

   /**
   * Get memberShippingAddress
   * @return memberShippingAddress
  **/
  @ApiModelProperty(value = "")
  public MemberAddress getMemberShippingAddress() {
    return memberShippingAddress;
  }

  public void setMemberShippingAddress(MemberAddress memberShippingAddress) {
    this.memberShippingAddress = memberShippingAddress;
  }

  public PreOrderInfo memberBillingAddress(MemberAddress memberBillingAddress) {
    this.memberBillingAddress = memberBillingAddress;
    return this;
  }

   /**
   * Get memberBillingAddress
   * @return memberBillingAddress
  **/
  @ApiModelProperty(value = "")
  public MemberAddress getMemberBillingAddress() {
    return memberBillingAddress;
  }

  public void setMemberBillingAddress(MemberAddress memberBillingAddress) {
    this.memberBillingAddress = memberBillingAddress;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PreOrderInfo preOrderInfo = (PreOrderInfo) o;
    return Objects.equals(this.id, preOrderInfo.id) &&
        Objects.equals(this.sessionId, preOrderInfo.sessionId) &&
        Objects.equals(this.customerFirstname, preOrderInfo.customerFirstname) &&
        Objects.equals(this.customerSurname, preOrderInfo.customerSurname) &&
        Objects.equals(this.customerEmail, preOrderInfo.customerEmail) &&
        Objects.equals(this.shippingFirstname, preOrderInfo.shippingFirstname) &&
        Objects.equals(this.shippingSurname, preOrderInfo.shippingSurname) &&
        Objects.equals(this.shippingAddress, preOrderInfo.shippingAddress) &&
        Objects.equals(this.shippingPhoneNumber, preOrderInfo.shippingPhoneNumber) &&
        Objects.equals(this.shippingMobilePhoneNumber, preOrderInfo.shippingMobilePhoneNumber) &&
        Objects.equals(this.shippingLocationName, preOrderInfo.shippingLocationName) &&
        Objects.equals(this.shippingTown, preOrderInfo.shippingTown) &&
        Objects.equals(this.differentBillingAddress, preOrderInfo.differentBillingAddress) &&
        Objects.equals(this.billingFirstname, preOrderInfo.billingFirstname) &&
        Objects.equals(this.billingSurname, preOrderInfo.billingSurname) &&
        Objects.equals(this.billingAddress, preOrderInfo.billingAddress) &&
        Objects.equals(this.billingPhoneNumber, preOrderInfo.billingPhoneNumber) &&
        Objects.equals(this.billingMobilePhoneNumber, preOrderInfo.billingMobilePhoneNumber) &&
        Objects.equals(this.billingLocationName, preOrderInfo.billingLocationName) &&
        Objects.equals(this.billingTown, preOrderInfo.billingTown) &&
        Objects.equals(this.billingInvoiceType, preOrderInfo.billingInvoiceType) &&
        Objects.equals(this.billingIdentityRegistrationNumber, preOrderInfo.billingIdentityRegistrationNumber) &&
        Objects.equals(this.billingTaxOffice, preOrderInfo.billingTaxOffice) &&
        Objects.equals(this.billingTaxNo, preOrderInfo.billingTaxNo) &&
        Objects.equals(this.isEinvoiceUser, preOrderInfo.isEinvoiceUser) &&
        Objects.equals(this.useGiftPackage, preOrderInfo.useGiftPackage) &&
        Objects.equals(this.giftNote, preOrderInfo.giftNote) &&
        Objects.equals(this.imageFile, preOrderInfo.imageFile) &&
        Objects.equals(this.deliveryDate, preOrderInfo.deliveryDate) &&
        Objects.equals(this.deliveryTime, preOrderInfo.deliveryTime) &&
        Objects.equals(this.createdAt, preOrderInfo.createdAt) &&
        Objects.equals(this.updatedAt, preOrderInfo.updatedAt) &&
        Objects.equals(this.billingCountry, preOrderInfo.billingCountry) &&
        Objects.equals(this.billingLocation, preOrderInfo.billingLocation) &&
        Objects.equals(this.shippingCompany, preOrderInfo.shippingCompany) &&
        Objects.equals(this.shippingCountry, preOrderInfo.shippingCountry) &&
        Objects.equals(this.shippingLocation, preOrderInfo.shippingLocation) &&
        Objects.equals(this.memberShippingAddress, preOrderInfo.memberShippingAddress) &&
        Objects.equals(this.memberBillingAddress, preOrderInfo.memberBillingAddress);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, sessionId, customerFirstname, customerSurname, customerEmail, shippingFirstname, shippingSurname, shippingAddress, shippingPhoneNumber, shippingMobilePhoneNumber, shippingLocationName, shippingTown, differentBillingAddress, billingFirstname, billingSurname, billingAddress, billingPhoneNumber, billingMobilePhoneNumber, billingLocationName, billingTown, billingInvoiceType, billingIdentityRegistrationNumber, billingTaxOffice, billingTaxNo, isEinvoiceUser, useGiftPackage, giftNote, imageFile, deliveryDate, deliveryTime, createdAt, updatedAt, billingCountry, billingLocation, shippingCompany, shippingCountry, shippingLocation, memberShippingAddress, memberBillingAddress);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PreOrderInfo {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    sessionId: ").append(toIndentedString(sessionId)).append("\n");
    sb.append("    customerFirstname: ").append(toIndentedString(customerFirstname)).append("\n");
    sb.append("    customerSurname: ").append(toIndentedString(customerSurname)).append("\n");
    sb.append("    customerEmail: ").append(toIndentedString(customerEmail)).append("\n");
    sb.append("    shippingFirstname: ").append(toIndentedString(shippingFirstname)).append("\n");
    sb.append("    shippingSurname: ").append(toIndentedString(shippingSurname)).append("\n");
    sb.append("    shippingAddress: ").append(toIndentedString(shippingAddress)).append("\n");
    sb.append("    shippingPhoneNumber: ").append(toIndentedString(shippingPhoneNumber)).append("\n");
    sb.append("    shippingMobilePhoneNumber: ").append(toIndentedString(shippingMobilePhoneNumber)).append("\n");
    sb.append("    shippingLocationName: ").append(toIndentedString(shippingLocationName)).append("\n");
    sb.append("    shippingTown: ").append(toIndentedString(shippingTown)).append("\n");
    sb.append("    differentBillingAddress: ").append(toIndentedString(differentBillingAddress)).append("\n");
    sb.append("    billingFirstname: ").append(toIndentedString(billingFirstname)).append("\n");
    sb.append("    billingSurname: ").append(toIndentedString(billingSurname)).append("\n");
    sb.append("    billingAddress: ").append(toIndentedString(billingAddress)).append("\n");
    sb.append("    billingPhoneNumber: ").append(toIndentedString(billingPhoneNumber)).append("\n");
    sb.append("    billingMobilePhoneNumber: ").append(toIndentedString(billingMobilePhoneNumber)).append("\n");
    sb.append("    billingLocationName: ").append(toIndentedString(billingLocationName)).append("\n");
    sb.append("    billingTown: ").append(toIndentedString(billingTown)).append("\n");
    sb.append("    billingInvoiceType: ").append(toIndentedString(billingInvoiceType)).append("\n");
    sb.append("    billingIdentityRegistrationNumber: ").append(toIndentedString(billingIdentityRegistrationNumber)).append("\n");
    sb.append("    billingTaxOffice: ").append(toIndentedString(billingTaxOffice)).append("\n");
    sb.append("    billingTaxNo: ").append(toIndentedString(billingTaxNo)).append("\n");
    sb.append("    isEinvoiceUser: ").append(toIndentedString(isEinvoiceUser)).append("\n");
    sb.append("    useGiftPackage: ").append(toIndentedString(useGiftPackage)).append("\n");
    sb.append("    giftNote: ").append(toIndentedString(giftNote)).append("\n");
    sb.append("    imageFile: ").append(toIndentedString(imageFile)).append("\n");
    sb.append("    deliveryDate: ").append(toIndentedString(deliveryDate)).append("\n");
    sb.append("    deliveryTime: ").append(toIndentedString(deliveryTime)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    billingCountry: ").append(toIndentedString(billingCountry)).append("\n");
    sb.append("    billingLocation: ").append(toIndentedString(billingLocation)).append("\n");
    sb.append("    shippingCompany: ").append(toIndentedString(shippingCompany)).append("\n");
    sb.append("    shippingCountry: ").append(toIndentedString(shippingCountry)).append("\n");
    sb.append("    shippingLocation: ").append(toIndentedString(shippingLocation)).append("\n");
    sb.append("    memberShippingAddress: ").append(toIndentedString(memberShippingAddress)).append("\n");
    sb.append("    memberBillingAddress: ").append(toIndentedString(memberBillingAddress)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

