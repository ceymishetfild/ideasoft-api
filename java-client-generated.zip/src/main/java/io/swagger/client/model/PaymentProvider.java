package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.PaymentProviderSetting;
import io.swagger.client.model.PaymentType;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * PaymentProvider
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class PaymentProvider {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("code")
  private String code = null;

  @SerializedName("name")
  private String name = null;

  /**
   * Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer.
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    _0("0"),
    
    _1("1");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  @SerializedName("paymentType")
  private PaymentType paymentType = null;

  @SerializedName("settings")
  private List<PaymentProviderSetting> settings = null;

  public PaymentProvider id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Ödeme altyapısı sağlayıcısı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Ödeme altyapısı sağlayıcısı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public PaymentProvider code(String code) {
    this.code = code;
    return this;
  }

   /**
   * Ödeme altyapısı sağlayıcısı için ön tanımlanmış kod değeri.
   * @return code
  **/
  @ApiModelProperty(example = "MoneyOrder", required = true, value = "Ödeme altyapısı sağlayıcısı için ön tanımlanmış kod değeri.")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public PaymentProvider name(String name) {
    this.name = name;
    return this;
  }

   /**
   * Ödeme altyapısı sağlayıcısı için isim değeri.
   * @return name
  **/
  @ApiModelProperty(example = "Havale", required = true, value = "Ödeme altyapısı sağlayıcısı için isim değeri.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public PaymentProvider status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer.
   * @return status
  **/
  @ApiModelProperty(example = "1", required = true, value = "Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer.")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public PaymentProvider paymentType(PaymentType paymentType) {
    this.paymentType = paymentType;
    return this;
  }

   /**
   * Get paymentType
   * @return paymentType
  **/
  @ApiModelProperty(value = "")
  public PaymentType getPaymentType() {
    return paymentType;
  }

  public void setPaymentType(PaymentType paymentType) {
    this.paymentType = paymentType;
  }

  public PaymentProvider settings(List<PaymentProviderSetting> settings) {
    this.settings = settings;
    return this;
  }

  public PaymentProvider addSettingsItem(PaymentProviderSetting settingsItem) {
    if (this.settings == null) {
      this.settings = new ArrayList<PaymentProviderSetting>();
    }
    this.settings.add(settingsItem);
    return this;
  }

   /**
   * Ödeme altyapısı sağlayıcısı ayarları
   * @return settings
  **/
  @ApiModelProperty(value = "Ödeme altyapısı sağlayıcısı ayarları")
  public List<PaymentProviderSetting> getSettings() {
    return settings;
  }

  public void setSettings(List<PaymentProviderSetting> settings) {
    this.settings = settings;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PaymentProvider paymentProvider = (PaymentProvider) o;
    return Objects.equals(this.id, paymentProvider.id) &&
        Objects.equals(this.code, paymentProvider.code) &&
        Objects.equals(this.name, paymentProvider.name) &&
        Objects.equals(this.status, paymentProvider.status) &&
        Objects.equals(this.paymentType, paymentProvider.paymentType) &&
        Objects.equals(this.settings, paymentProvider.settings);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, code, name, status, paymentType, settings);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PaymentProvider {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    paymentType: ").append(toIndentedString(paymentType)).append("\n");
    sb.append("    settings: ").append(toIndentedString(settings)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

