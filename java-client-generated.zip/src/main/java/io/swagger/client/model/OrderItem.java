package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Order;
import io.swagger.client.model.OrderItemSubscription;
import io.swagger.client.model.Product;
import java.io.IOException;

/**
 * OrderItem
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class OrderItem {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("productName")
  private String productName = null;

  @SerializedName("productSku")
  private String productSku = null;

  @SerializedName("productBarcode")
  private String productBarcode = null;

  @SerializedName("productPrice")
  private Float productPrice = null;

  @SerializedName("productCurrency")
  private String productCurrency = null;

  @SerializedName("productQuantity")
  private Float productQuantity = null;

  @SerializedName("productTax")
  private Integer productTax = null;

  @SerializedName("productDiscount")
  private Float productDiscount = null;

  @SerializedName("productMoneyOrderDiscount")
  private Float productMoneyOrderDiscount = null;

  @SerializedName("productWeight")
  private Float productWeight = null;

  @SerializedName("productStockTypeLabel")
  private String productStockTypeLabel = null;

  /**
   * Ürünün promosyon olup olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;0&lt;/code&gt; : Ürün promosyon değil.&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Ürün promosyon.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(IsProductPromotionedEnum.Adapter.class)
  public enum IsProductPromotionedEnum {
    _0("0"),
    
    _1("1");

    private String value;

    IsProductPromotionedEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static IsProductPromotionedEnum fromValue(String text) {
      for (IsProductPromotionedEnum b : IsProductPromotionedEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<IsProductPromotionedEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final IsProductPromotionedEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public IsProductPromotionedEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return IsProductPromotionedEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("isProductPromotioned")
  private IsProductPromotionedEnum isProductPromotioned = null;

  @SerializedName("discount")
  private Float discount = null;

  @SerializedName("order")
  private Order order = null;

  @SerializedName("product")
  private Product product = null;

  @SerializedName("orderItemSubscription")
  private OrderItemSubscription orderItemSubscription = null;

  public OrderItem id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Sipariş kalemi nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Sipariş kalemi nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OrderItem productName(String productName) {
    this.productName = productName;
    return this;
  }

   /**
   * Ürünün adı.
   * @return productName
  **/
  @ApiModelProperty(example = "Kalem", required = true, value = "Ürünün adı.")
  public String getProductName() {
    return productName;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

  public OrderItem productSku(String productSku) {
    this.productSku = productSku;
    return this;
  }

   /**
   * Ürünün stok kodu.
   * @return productSku
  **/
  @ApiModelProperty(example = "KAL-1234", required = true, value = "Ürünün stok kodu.")
  public String getProductSku() {
    return productSku;
  }

  public void setProductSku(String productSku) {
    this.productSku = productSku;
  }

  public OrderItem productBarcode(String productBarcode) {
    this.productBarcode = productBarcode;
    return this;
  }

   /**
   * Ürünün barkodu.
   * @return productBarcode
  **/
  @ApiModelProperty(example = "869456789874", value = "Ürünün barkodu.")
  public String getProductBarcode() {
    return productBarcode;
  }

  public void setProductBarcode(String productBarcode) {
    this.productBarcode = productBarcode;
  }

  public OrderItem productPrice(Float productPrice) {
    this.productPrice = productPrice;
    return this;
  }

   /**
   * Ürünün fiyatı.
   * minimum: 0
   * @return productPrice
  **/
  @ApiModelProperty(example = "15.0", required = true, value = "Ürünün fiyatı.")
  public Float getProductPrice() {
    return productPrice;
  }

  public void setProductPrice(Float productPrice) {
    this.productPrice = productPrice;
  }

  public OrderItem productCurrency(String productCurrency) {
    this.productCurrency = productCurrency;
    return this;
  }

   /**
   * Ürünün kuru.
   * @return productCurrency
  **/
  @ApiModelProperty(example = "TL", required = true, value = "Ürünün kuru.")
  public String getProductCurrency() {
    return productCurrency;
  }

  public void setProductCurrency(String productCurrency) {
    this.productCurrency = productCurrency;
  }

  public OrderItem productQuantity(Float productQuantity) {
    this.productQuantity = productQuantity;
    return this;
  }

   /**
   * Ürünün stok tipi cinsinden miktarı.
   * minimum: 0.001
   * @return productQuantity
  **/
  @ApiModelProperty(example = "1.0", required = true, value = "Ürünün stok tipi cinsinden miktarı.")
  public Float getProductQuantity() {
    return productQuantity;
  }

  public void setProductQuantity(Float productQuantity) {
    this.productQuantity = productQuantity;
  }

  public OrderItem productTax(Integer productTax) {
    this.productTax = productTax;
    return this;
  }

   /**
   * Ürünün vergisi
   * minimum: 0
   * @return productTax
  **/
  @ApiModelProperty(example = "18", required = true, value = "Ürünün vergisi")
  public Integer getProductTax() {
    return productTax;
  }

  public void setProductTax(Integer productTax) {
    this.productTax = productTax;
  }

  public OrderItem productDiscount(Float productDiscount) {
    this.productDiscount = productDiscount;
    return this;
  }

   /**
   * Ürünün standart indirim değeri.
   * @return productDiscount
  **/
  @ApiModelProperty(example = "5.0", required = true, value = "Ürünün standart indirim değeri.")
  public Float getProductDiscount() {
    return productDiscount;
  }

  public void setProductDiscount(Float productDiscount) {
    this.productDiscount = productDiscount;
  }

  public OrderItem productMoneyOrderDiscount(Float productMoneyOrderDiscount) {
    this.productMoneyOrderDiscount = productMoneyOrderDiscount;
    return this;
  }

   /**
   * Ürünün havale indirim değeri.
   * minimum: 0
   * @return productMoneyOrderDiscount
  **/
  @ApiModelProperty(example = "5.0", required = true, value = "Ürünün havale indirim değeri.")
  public Float getProductMoneyOrderDiscount() {
    return productMoneyOrderDiscount;
  }

  public void setProductMoneyOrderDiscount(Float productMoneyOrderDiscount) {
    this.productMoneyOrderDiscount = productMoneyOrderDiscount;
  }

  public OrderItem productWeight(Float productWeight) {
    this.productWeight = productWeight;
    return this;
  }

   /**
   * Ürünün ağırlığı.
   * minimum: 0
   * @return productWeight
  **/
  @ApiModelProperty(example = "1.2", required = true, value = "Ürünün ağırlığı.")
  public Float getProductWeight() {
    return productWeight;
  }

  public void setProductWeight(Float productWeight) {
    this.productWeight = productWeight;
  }

  public OrderItem productStockTypeLabel(String productStockTypeLabel) {
    this.productStockTypeLabel = productStockTypeLabel;
    return this;
  }

   /**
   * Ürünün stok tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Adet&lt;/code&gt; : Stok tipi birimi Adet&lt;br&gt;&lt;code&gt;cm&lt;/code&gt; : Stok tipi birimi Santimetre&lt;br&gt;&lt;code&gt;Düzine&lt;/code&gt; : Stok tipi birimi Düzine&lt;br&gt;&lt;code&gt;gram&lt;/code&gt; : Stok tipi birimi Gram&lt;br&gt;&lt;code&gt;kg&lt;/code&gt; : Stok tipi birimi Kilogram&lt;br&gt;&lt;code&gt;Kişi&lt;/code&gt; : Stok tipi birimi Kişi&lt;br&gt;&lt;code&gt;Paket&lt;/code&gt; : Stok tipi birimi Paket&lt;br&gt;&lt;code&gt;metre&lt;/code&gt; : Stok tipi birimi Metre&lt;br&gt;&lt;code&gt;m2&lt;/code&gt; : Stok tipi birimi Metre kare&lt;br&gt;&lt;code&gt;Çift&lt;/code&gt; : Stok tipi birimi Çift&lt;br&gt;&lt;/div&gt;
   * @return productStockTypeLabel
  **/
  @ApiModelProperty(example = "Adet", required = true, value = "Ürünün stok tipi.<div class='idea_choice_list'><code>Adet</code> : Stok tipi birimi Adet<br><code>cm</code> : Stok tipi birimi Santimetre<br><code>Düzine</code> : Stok tipi birimi Düzine<br><code>gram</code> : Stok tipi birimi Gram<br><code>kg</code> : Stok tipi birimi Kilogram<br><code>Kişi</code> : Stok tipi birimi Kişi<br><code>Paket</code> : Stok tipi birimi Paket<br><code>metre</code> : Stok tipi birimi Metre<br><code>m2</code> : Stok tipi birimi Metre kare<br><code>Çift</code> : Stok tipi birimi Çift<br></div>")
  public String getProductStockTypeLabel() {
    return productStockTypeLabel;
  }

  public void setProductStockTypeLabel(String productStockTypeLabel) {
    this.productStockTypeLabel = productStockTypeLabel;
  }

  public OrderItem isProductPromotioned(IsProductPromotionedEnum isProductPromotioned) {
    this.isProductPromotioned = isProductPromotioned;
    return this;
  }

   /**
   * Ürünün promosyon olup olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;0&lt;/code&gt; : Ürün promosyon değil.&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Ürün promosyon.&lt;br&gt;&lt;/div&gt;
   * @return isProductPromotioned
  **/
  @ApiModelProperty(example = "0", value = "Ürünün promosyon olup olmadığını belirten değer.<div class='idea_choice_list'><code>0</code> : Ürün promosyon değil.<br><code>1</code> : Ürün promosyon.<br></div>")
  public IsProductPromotionedEnum getIsProductPromotioned() {
    return isProductPromotioned;
  }

  public void setIsProductPromotioned(IsProductPromotionedEnum isProductPromotioned) {
    this.isProductPromotioned = isProductPromotioned;
  }

  public OrderItem discount(Float discount) {
    this.discount = discount;
    return this;
  }

   /**
   * Ürünün hediye çeki indirim değeri.
   * minimum: 0
   * @return discount
  **/
  @ApiModelProperty(example = "5.0", required = true, value = "Ürünün hediye çeki indirim değeri.")
  public Float getDiscount() {
    return discount;
  }

  public void setDiscount(Float discount) {
    this.discount = discount;
  }

  public OrderItem order(Order order) {
    this.order = order;
    return this;
  }

   /**
   * Get order
   * @return order
  **/
  @ApiModelProperty(value = "")
  public Order getOrder() {
    return order;
  }

  public void setOrder(Order order) {
    this.order = order;
  }

  public OrderItem product(Product product) {
    this.product = product;
    return this;
  }

   /**
   * Get product
   * @return product
  **/
  @ApiModelProperty(value = "")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public OrderItem orderItemSubscription(OrderItemSubscription orderItemSubscription) {
    this.orderItemSubscription = orderItemSubscription;
    return this;
  }

   /**
   * Get orderItemSubscription
   * @return orderItemSubscription
  **/
  @ApiModelProperty(value = "")
  public OrderItemSubscription getOrderItemSubscription() {
    return orderItemSubscription;
  }

  public void setOrderItemSubscription(OrderItemSubscription orderItemSubscription) {
    this.orderItemSubscription = orderItemSubscription;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrderItem orderItem = (OrderItem) o;
    return Objects.equals(this.id, orderItem.id) &&
        Objects.equals(this.productName, orderItem.productName) &&
        Objects.equals(this.productSku, orderItem.productSku) &&
        Objects.equals(this.productBarcode, orderItem.productBarcode) &&
        Objects.equals(this.productPrice, orderItem.productPrice) &&
        Objects.equals(this.productCurrency, orderItem.productCurrency) &&
        Objects.equals(this.productQuantity, orderItem.productQuantity) &&
        Objects.equals(this.productTax, orderItem.productTax) &&
        Objects.equals(this.productDiscount, orderItem.productDiscount) &&
        Objects.equals(this.productMoneyOrderDiscount, orderItem.productMoneyOrderDiscount) &&
        Objects.equals(this.productWeight, orderItem.productWeight) &&
        Objects.equals(this.productStockTypeLabel, orderItem.productStockTypeLabel) &&
        Objects.equals(this.isProductPromotioned, orderItem.isProductPromotioned) &&
        Objects.equals(this.discount, orderItem.discount) &&
        Objects.equals(this.order, orderItem.order) &&
        Objects.equals(this.product, orderItem.product) &&
        Objects.equals(this.orderItemSubscription, orderItem.orderItemSubscription);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, productName, productSku, productBarcode, productPrice, productCurrency, productQuantity, productTax, productDiscount, productMoneyOrderDiscount, productWeight, productStockTypeLabel, isProductPromotioned, discount, order, product, orderItemSubscription);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderItem {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    productName: ").append(toIndentedString(productName)).append("\n");
    sb.append("    productSku: ").append(toIndentedString(productSku)).append("\n");
    sb.append("    productBarcode: ").append(toIndentedString(productBarcode)).append("\n");
    sb.append("    productPrice: ").append(toIndentedString(productPrice)).append("\n");
    sb.append("    productCurrency: ").append(toIndentedString(productCurrency)).append("\n");
    sb.append("    productQuantity: ").append(toIndentedString(productQuantity)).append("\n");
    sb.append("    productTax: ").append(toIndentedString(productTax)).append("\n");
    sb.append("    productDiscount: ").append(toIndentedString(productDiscount)).append("\n");
    sb.append("    productMoneyOrderDiscount: ").append(toIndentedString(productMoneyOrderDiscount)).append("\n");
    sb.append("    productWeight: ").append(toIndentedString(productWeight)).append("\n");
    sb.append("    productStockTypeLabel: ").append(toIndentedString(productStockTypeLabel)).append("\n");
    sb.append("    isProductPromotioned: ").append(toIndentedString(isProductPromotioned)).append("\n");
    sb.append("    discount: ").append(toIndentedString(discount)).append("\n");
    sb.append("    order: ").append(toIndentedString(order)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("    orderItemSubscription: ").append(toIndentedString(orderItemSubscription)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

