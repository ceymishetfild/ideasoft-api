package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.IOException;

/**
 * QuickCart
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class QuickCart {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("name")
  private String name = null;

  @SerializedName("url")
  private String url = null;

  @SerializedName("shortUrl")
  private String shortUrl = null;

  public QuickCart id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Hızlı satın al bağlantısı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Hızlı satın al bağlantısı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public QuickCart name(String name) {
    this.name = name;
    return this;
  }

   /**
   * Hızlı satın al bağlantısı nesnesi için isim değeri.
   * @return name
  **/
  @ApiModelProperty(example = "Hızlı Kalem Al", required = true, value = "Hızlı satın al bağlantısı nesnesi için isim değeri.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public QuickCart url(String url) {
    this.url = url;
    return this;
  }

   /**
   * Hızlı satın al bağlantısı url&#39;si.
   * @return url
  **/
  @ApiModelProperty(example = "products%5B0%5D%5Bid%5D=31&products%5B0%5D%5Bamount%5D=1", required = true, value = "Hızlı satın al bağlantısı url'si.")
  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public QuickCart shortUrl(String shortUrl) {
    this.shortUrl = shortUrl;
    return this;
  }

   /**
   * Hızlı satın al bağlantısı için kısaltılmış url.
   * @return shortUrl
  **/
  @ApiModelProperty(example = "https://goo.gl/VJ2FSF", value = "Hızlı satın al bağlantısı için kısaltılmış url.")
  public String getShortUrl() {
    return shortUrl;
  }

  public void setShortUrl(String shortUrl) {
    this.shortUrl = shortUrl;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    QuickCart quickCart = (QuickCart) o;
    return Objects.equals(this.id, quickCart.id) &&
        Objects.equals(this.name, quickCart.name) &&
        Objects.equals(this.url, quickCart.url) &&
        Objects.equals(this.shortUrl, quickCart.shortUrl);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, url, shortUrl);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class QuickCart {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    url: ").append(toIndentedString(url)).append("\n");
    sb.append("    shortUrl: ").append(toIndentedString(shortUrl)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

