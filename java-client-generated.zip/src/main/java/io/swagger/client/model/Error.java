package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.IOException;

/**
 * Error
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Error {
  @SerializedName("code")
  private Integer code = null;

  @SerializedName("errorMessage")
  private String errorMessage = null;

  @SerializedName("errorCode")
  private Integer errorCode = null;

  public Error code(Integer code) {
    this.code = code;
    return this;
  }

   /**
   * HTTP Hata kodu.
   * minimum: 100
   * maximum: 600
   * @return code
  **/
  @ApiModelProperty(example = "400", value = "HTTP Hata kodu.")
  public Integer getCode() {
    return code;
  }

  public void setCode(Integer code) {
    this.code = code;
  }

  public Error errorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
    return this;
  }

   /**
   * Hata mesajı. Hata mesajları İngilizce dilindedir.
   * @return errorMessage
  **/
  @ApiModelProperty(example = "Error message of the subjected error.", value = "Hata mesajı. Hata mesajları İngilizce dilindedir.")
  public String getErrorMessage() {
    return errorMessage;
  }

  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  public Error errorCode(Integer errorCode) {
    this.errorCode = errorCode;
    return this;
  }

   /**
   * Hata kodu. Eğer ek bir hata kodu varsa bu alanda belirtilir.
   * @return errorCode
  **/
  @ApiModelProperty(example = "0", value = "Hata kodu. Eğer ek bir hata kodu varsa bu alanda belirtilir.")
  public Integer getErrorCode() {
    return errorCode;
  }

  public void setErrorCode(Integer errorCode) {
    this.errorCode = errorCode;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Error error = (Error) o;
    return Objects.equals(this.code, error.code) &&
        Objects.equals(this.errorMessage, error.errorMessage) &&
        Objects.equals(this.errorCode, error.errorCode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code, errorMessage, errorCode);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Error {\n");
    
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    errorMessage: ").append(toIndentedString(errorMessage)).append("\n");
    sb.append("    errorCode: ").append(toIndentedString(errorCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

