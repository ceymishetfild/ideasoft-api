package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Cart;
import io.swagger.client.model.CartItemAttribute;
import io.swagger.client.model.Product;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;

/**
 * CartItem
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class CartItem {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("parentProductId")
  private Integer parentProductId = null;

  @SerializedName("quantity")
  private Float quantity = null;

  @SerializedName("categoryId")
  private Integer categoryId = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  @SerializedName("cart")
  private Cart cart = null;

  @SerializedName("product")
  private Product product = null;

  @SerializedName("attributes")
  private List<CartItemAttribute> attributes = null;

  public CartItem id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Sepet kalemi nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Sepet kalemi nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

   /**
   * Ana ürünün benzersiz rakamsal kimlik değeri.
   * minimum: 0
   * @return parentProductId
  **/
  @ApiModelProperty(example = "123", value = "Ana ürünün benzersiz rakamsal kimlik değeri.")
  public Integer getParentProductId() {
    return parentProductId;
  }

  public CartItem quantity(Float quantity) {
    this.quantity = quantity;
    return this;
  }

   /**
   * Sepetteki kalem adedi.
   * minimum: 0
   * @return quantity
  **/
  @ApiModelProperty(example = "15.0", required = true, value = "Sepetteki kalem adedi.")
  public Float getQuantity() {
    return quantity;
  }

  public void setQuantity(Float quantity) {
    this.quantity = quantity;
  }

   /**
   * Sepetteki kaleme ait kategorinin benzersiz kimlik değeri.
   * minimum: 0
   * @return categoryId
  **/
  @ApiModelProperty(example = "123", value = "Sepetteki kaleme ait kategorinin benzersiz kimlik değeri.")
  public Integer getCategoryId() {
    return categoryId;
  }

   /**
   * Sepet kalemi nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Sepet kalemi nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

   /**
   * Sepet kalemi nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Sepet kalemi nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public CartItem cart(Cart cart) {
    this.cart = cart;
    return this;
  }

   /**
   * Get cart
   * @return cart
  **/
  @ApiModelProperty(value = "")
  public Cart getCart() {
    return cart;
  }

  public void setCart(Cart cart) {
    this.cart = cart;
  }

  public CartItem product(Product product) {
    this.product = product;
    return this;
  }

   /**
   * Get product
   * @return product
  **/
  @ApiModelProperty(value = "")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public CartItem attributes(List<CartItemAttribute> attributes) {
    this.attributes = attributes;
    return this;
  }

  public CartItem addAttributesItem(CartItemAttribute attributesItem) {
    if (this.attributes == null) {
      this.attributes = new ArrayList<CartItemAttribute>();
    }
    this.attributes.add(attributesItem);
    return this;
  }

   /**
   * Sepet kalemi özelliği barındıran liste.
   * @return attributes
  **/
  @ApiModelProperty(value = "Sepet kalemi özelliği barındıran liste.")
  public List<CartItemAttribute> getAttributes() {
    return attributes;
  }

  public void setAttributes(List<CartItemAttribute> attributes) {
    this.attributes = attributes;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CartItem cartItem = (CartItem) o;
    return Objects.equals(this.id, cartItem.id) &&
        Objects.equals(this.parentProductId, cartItem.parentProductId) &&
        Objects.equals(this.quantity, cartItem.quantity) &&
        Objects.equals(this.categoryId, cartItem.categoryId) &&
        Objects.equals(this.createdAt, cartItem.createdAt) &&
        Objects.equals(this.updatedAt, cartItem.updatedAt) &&
        Objects.equals(this.cart, cartItem.cart) &&
        Objects.equals(this.product, cartItem.product) &&
        Objects.equals(this.attributes, cartItem.attributes);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, parentProductId, quantity, categoryId, createdAt, updatedAt, cart, product, attributes);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CartItem {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    parentProductId: ").append(toIndentedString(parentProductId)).append("\n");
    sb.append("    quantity: ").append(toIndentedString(quantity)).append("\n");
    sb.append("    categoryId: ").append(toIndentedString(categoryId)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    cart: ").append(toIndentedString(cart)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("    attributes: ").append(toIndentedString(attributes)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

