package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Product;
import java.io.IOException;

/**
 * ProductSpecialInfo
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ProductSpecialInfo {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("title")
  private String title = null;

  @SerializedName("content")
  private String content = null;

  @SerializedName("status")
  private Integer status = null;

  @SerializedName("product")
  private Product product = null;

  public ProductSpecialInfo id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Özel bilgi alanı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Özel bilgi alanı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductSpecialInfo title(String title) {
    this.title = title;
    return this;
  }

   /**
   * Özel bilgi alanı başlığı.
   * @return title
  **/
  @ApiModelProperty(example = "ProductSpecialInfo", required = true, value = "Özel bilgi alanı başlığı.")
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public ProductSpecialInfo content(String content) {
    this.content = content;
    return this;
  }

   /**
   * Özel bilgi alanı içeriği.
   * @return content
  **/
  @ApiModelProperty(example = "Özel bilgi alanı içeriği.", required = true, value = "Özel bilgi alanı içeriği.")
  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public ProductSpecialInfo status(Integer status) {
    this.status = status;
    return this;
  }

   /**
   * Özel bilgi alanı aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @ApiModelProperty(example = "0", required = true, value = "Özel bilgi alanı aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
  public Integer getStatus() {
    return status;
  }

  public void setStatus(Integer status) {
    this.status = status;
  }

  public ProductSpecialInfo product(Product product) {
    this.product = product;
    return this;
  }

   /**
   * Get product
   * @return product
  **/
  @ApiModelProperty(value = "")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProductSpecialInfo productSpecialInfo = (ProductSpecialInfo) o;
    return Objects.equals(this.id, productSpecialInfo.id) &&
        Objects.equals(this.title, productSpecialInfo.title) &&
        Objects.equals(this.content, productSpecialInfo.content) &&
        Objects.equals(this.status, productSpecialInfo.status) &&
        Objects.equals(this.product, productSpecialInfo.product);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, title, content, status, product);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductSpecialInfo {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

