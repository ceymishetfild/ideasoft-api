package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.IOException;

/**
 * OptionGroup
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class OptionGroup {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("title")
  private String title = null;

  @SerializedName("sortOrder")
  private Integer sortOrder = null;

  /**
   * Varyant grubunun filtre menüsündeki gösterim durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Gösterilsin.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Gösterilmesin.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(FilterStatusEnum.Adapter.class)
  public enum FilterStatusEnum {
    _0("0"),
    
    _1("1");

    private String value;

    FilterStatusEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static FilterStatusEnum fromValue(String text) {
      for (FilterStatusEnum b : FilterStatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<FilterStatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final FilterStatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public FilterStatusEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return FilterStatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("filterStatus")
  private FilterStatusEnum filterStatus = null;

  public OptionGroup id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Varyant grubu nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Varyant grubu nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OptionGroup title(String title) {
    this.title = title;
    return this;
  }

   /**
   * Varyant grubunun başlığı. Varyant değeri kırmızı ise bu değer renk olabilir.
   * @return title
  **/
  @ApiModelProperty(example = "Renk", required = true, value = "Varyant grubunun başlığı. Varyant değeri kırmızı ise bu değer renk olabilir.")
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public OptionGroup sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

   /**
   * Varyant grubunun sıralama değeri.
   * minimum: 0
   * maximum: 9999
   * @return sortOrder
  **/
  @ApiModelProperty(example = "9999", value = "Varyant grubunun sıralama değeri.")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public OptionGroup filterStatus(FilterStatusEnum filterStatus) {
    this.filterStatus = filterStatus;
    return this;
  }

   /**
   * Varyant grubunun filtre menüsündeki gösterim durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Gösterilsin.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Gösterilmesin.&lt;br&gt;&lt;/div&gt;
   * @return filterStatus
  **/
  @ApiModelProperty(example = "1", value = "Varyant grubunun filtre menüsündeki gösterim durumu.<div class='idea_choice_list'><code>1</code> : Gösterilsin.<br><code>0</code> : Gösterilmesin.<br></div>")
  public FilterStatusEnum getFilterStatus() {
    return filterStatus;
  }

  public void setFilterStatus(FilterStatusEnum filterStatus) {
    this.filterStatus = filterStatus;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OptionGroup optionGroup = (OptionGroup) o;
    return Objects.equals(this.id, optionGroup.id) &&
        Objects.equals(this.title, optionGroup.title) &&
        Objects.equals(this.sortOrder, optionGroup.sortOrder) &&
        Objects.equals(this.filterStatus, optionGroup.filterStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, title, sortOrder, filterStatus);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OptionGroup {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    filterStatus: ").append(toIndentedString(filterStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

