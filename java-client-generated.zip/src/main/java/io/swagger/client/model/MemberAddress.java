package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Country;
import io.swagger.client.model.Location;
import io.swagger.client.model.Member;
import io.swagger.client.model.Town;
import java.io.IOException;
import org.threeten.bp.OffsetDateTime;

/**
 * MemberAddress
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class MemberAddress {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("name")
  private String name = null;

  @SerializedName("type")
  private String type = null;

  @SerializedName("firstname")
  private String firstname = null;

  @SerializedName("surname")
  private String surname = null;

  @SerializedName("address")
  private String address = null;

  @SerializedName("subLocationName")
  private String subLocationName = null;

  @SerializedName("phoneNumber")
  private String phoneNumber = null;

  @SerializedName("mobilePhoneNumber")
  private String mobilePhoneNumber = null;

  @SerializedName("tcId")
  private String tcId = null;

  @SerializedName("taxNumber")
  private String taxNumber = null;

  @SerializedName("taxOffice")
  private String taxOffice = null;

  @SerializedName("invoiceType")
  private String invoiceType = null;

  @SerializedName("isEinvoiceUser")
  private Boolean isEinvoiceUser = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  @SerializedName("member")
  private Member member = null;

  @SerializedName("country")
  private Country country = null;

  @SerializedName("location")
  private Location location = null;

  @SerializedName("subLocation")
  private Town subLocation = null;

  public MemberAddress id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Üye adresi nesnesinin benzersiz rakamsal kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Üye adresi nesnesinin benzersiz rakamsal kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public MemberAddress name(String name) {
    this.name = name;
    return this;
  }

   /**
   * Üye Adresi adı.
   * @return name
  **/
  @ApiModelProperty(example = "Ev", value = "Üye Adresi adı.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public MemberAddress type(String type) {
    this.type = type;
    return this;
  }

   /**
   * Üye Adresi tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;shipping&lt;/code&gt; : Teslimat adresi.&lt;br&gt;&lt;code&gt;billing&lt;/code&gt; : Fatura adresi.&lt;br&gt;&lt;/div&gt;
   * @return type
  **/
  @ApiModelProperty(example = "shipping", value = "Üye Adresi tipi.<div class='idea_choice_list'><code>shipping</code> : Teslimat adresi.<br><code>billing</code> : Fatura adresi.<br></div>")
  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public MemberAddress firstname(String firstname) {
    this.firstname = firstname;
    return this;
  }

   /**
   * Üyenin ismi.
   * @return firstname
  **/
  @ApiModelProperty(example = "John", value = "Üyenin ismi.")
  public String getFirstname() {
    return firstname;
  }

  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }

  public MemberAddress surname(String surname) {
    this.surname = surname;
    return this;
  }

   /**
   * Üyenin soy ismi.
   * @return surname
  **/
  @ApiModelProperty(example = "Doe", value = "Üyenin soy ismi.")
  public String getSurname() {
    return surname;
  }

  public void setSurname(String surname) {
    this.surname = surname;
  }

  public MemberAddress address(String address) {
    this.address = address;
    return this;
  }

   /**
   * Üyenin adres bilgileri.
   * @return address
  **/
  @ApiModelProperty(example = "Cumhuriyet Mah. Libadiye Cad. Çimen Sok. No:2", value = "Üyenin adres bilgileri.")
  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public MemberAddress subLocationName(String subLocationName) {
    this.subLocationName = subLocationName;
    return this;
  }

   /**
   * İlçe adı.
   * @return subLocationName
  **/
  @ApiModelProperty(example = "Üsküdar", value = "İlçe adı.")
  public String getSubLocationName() {
    return subLocationName;
  }

  public void setSubLocationName(String subLocationName) {
    this.subLocationName = subLocationName;
  }

  public MemberAddress phoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
    return this;
  }

   /**
   * Üyenin telefon numarası.
   * @return phoneNumber
  **/
  @ApiModelProperty(example = "+90 (216) 326 04 77", value = "Üyenin telefon numarası.")
  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public MemberAddress mobilePhoneNumber(String mobilePhoneNumber) {
    this.mobilePhoneNumber = mobilePhoneNumber;
    return this;
  }

   /**
   * Üyenin mobil telefon numarası.
   * @return mobilePhoneNumber
  **/
  @ApiModelProperty(value = "Üyenin mobil telefon numarası.")
  public String getMobilePhoneNumber() {
    return mobilePhoneNumber;
  }

  public void setMobilePhoneNumber(String mobilePhoneNumber) {
    this.mobilePhoneNumber = mobilePhoneNumber;
  }

  public MemberAddress tcId(String tcId) {
    this.tcId = tcId;
    return this;
  }

   /**
   * Üyenin TC kimlik numarası.
   * @return tcId
  **/
  @ApiModelProperty(example = "11111111111", value = "Üyenin TC kimlik numarası.")
  public String getTcId() {
    return tcId;
  }

  public void setTcId(String tcId) {
    this.tcId = tcId;
  }

  public MemberAddress taxNumber(String taxNumber) {
    this.taxNumber = taxNumber;
    return this;
  }

   /**
   * Üyenin vergi numarası.
   * @return taxNumber
  **/
  @ApiModelProperty(example = "1966712049", value = "Üyenin vergi numarası.")
  public String getTaxNumber() {
    return taxNumber;
  }

  public void setTaxNumber(String taxNumber) {
    this.taxNumber = taxNumber;
  }

  public MemberAddress taxOffice(String taxOffice) {
    this.taxOffice = taxOffice;
    return this;
  }

   /**
   * Üyenin vergi dairesi.
   * @return taxOffice
  **/
  @ApiModelProperty(example = "Üsküdar", value = "Üyenin vergi dairesi.")
  public String getTaxOffice() {
    return taxOffice;
  }

  public void setTaxOffice(String taxOffice) {
    this.taxOffice = taxOffice;
  }

  public MemberAddress invoiceType(String invoiceType) {
    this.invoiceType = invoiceType;
    return this;
  }

   /**
   * Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt;
   * @return invoiceType
  **/
  @ApiModelProperty(example = "individual", value = "Fatura tipini belirtir.<div class='idea_choice_list'><code>individual</code> : Bireysel<br><code>corporate</code> : Kurumsal<br></div>")
  public String getInvoiceType() {
    return invoiceType;
  }

  public void setInvoiceType(String invoiceType) {
    this.invoiceType = invoiceType;
  }

  public MemberAddress isEinvoiceUser(Boolean isEinvoiceUser) {
    this.isEinvoiceUser = isEinvoiceUser;
    return this;
  }

   /**
   * Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt;
   * @return isEinvoiceUser
  **/
  @ApiModelProperty(example = "false", value = "Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div>")
  public Boolean isIsEinvoiceUser() {
    return isEinvoiceUser;
  }

  public void setIsEinvoiceUser(Boolean isEinvoiceUser) {
    this.isEinvoiceUser = isEinvoiceUser;
  }

  public MemberAddress createdAt(OffsetDateTime createdAt) {
    this.createdAt = createdAt;
    return this;
  }

   /**
   * Tema nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Tema nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(OffsetDateTime createdAt) {
    this.createdAt = createdAt;
  }

  public MemberAddress updatedAt(OffsetDateTime updatedAt) {
    this.updatedAt = updatedAt;
    return this;
  }

   /**
   * Tema nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Tema nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(OffsetDateTime updatedAt) {
    this.updatedAt = updatedAt;
  }

  public MemberAddress member(Member member) {
    this.member = member;
    return this;
  }

   /**
   * Get member
   * @return member
  **/
  @ApiModelProperty(value = "")
  public Member getMember() {
    return member;
  }

  public void setMember(Member member) {
    this.member = member;
  }

  public MemberAddress country(Country country) {
    this.country = country;
    return this;
  }

   /**
   * Get country
   * @return country
  **/
  @ApiModelProperty(value = "")
  public Country getCountry() {
    return country;
  }

  public void setCountry(Country country) {
    this.country = country;
  }

  public MemberAddress location(Location location) {
    this.location = location;
    return this;
  }

   /**
   * Get location
   * @return location
  **/
  @ApiModelProperty(value = "")
  public Location getLocation() {
    return location;
  }

  public void setLocation(Location location) {
    this.location = location;
  }

  public MemberAddress subLocation(Town subLocation) {
    this.subLocation = subLocation;
    return this;
  }

   /**
   * Get subLocation
   * @return subLocation
  **/
  @ApiModelProperty(value = "")
  public Town getSubLocation() {
    return subLocation;
  }

  public void setSubLocation(Town subLocation) {
    this.subLocation = subLocation;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MemberAddress memberAddress = (MemberAddress) o;
    return Objects.equals(this.id, memberAddress.id) &&
        Objects.equals(this.name, memberAddress.name) &&
        Objects.equals(this.type, memberAddress.type) &&
        Objects.equals(this.firstname, memberAddress.firstname) &&
        Objects.equals(this.surname, memberAddress.surname) &&
        Objects.equals(this.address, memberAddress.address) &&
        Objects.equals(this.subLocationName, memberAddress.subLocationName) &&
        Objects.equals(this.phoneNumber, memberAddress.phoneNumber) &&
        Objects.equals(this.mobilePhoneNumber, memberAddress.mobilePhoneNumber) &&
        Objects.equals(this.tcId, memberAddress.tcId) &&
        Objects.equals(this.taxNumber, memberAddress.taxNumber) &&
        Objects.equals(this.taxOffice, memberAddress.taxOffice) &&
        Objects.equals(this.invoiceType, memberAddress.invoiceType) &&
        Objects.equals(this.isEinvoiceUser, memberAddress.isEinvoiceUser) &&
        Objects.equals(this.createdAt, memberAddress.createdAt) &&
        Objects.equals(this.updatedAt, memberAddress.updatedAt) &&
        Objects.equals(this.member, memberAddress.member) &&
        Objects.equals(this.country, memberAddress.country) &&
        Objects.equals(this.location, memberAddress.location) &&
        Objects.equals(this.subLocation, memberAddress.subLocation);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, type, firstname, surname, address, subLocationName, phoneNumber, mobilePhoneNumber, tcId, taxNumber, taxOffice, invoiceType, isEinvoiceUser, createdAt, updatedAt, member, country, location, subLocation);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MemberAddress {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    firstname: ").append(toIndentedString(firstname)).append("\n");
    sb.append("    surname: ").append(toIndentedString(surname)).append("\n");
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    subLocationName: ").append(toIndentedString(subLocationName)).append("\n");
    sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
    sb.append("    mobilePhoneNumber: ").append(toIndentedString(mobilePhoneNumber)).append("\n");
    sb.append("    tcId: ").append(toIndentedString(tcId)).append("\n");
    sb.append("    taxNumber: ").append(toIndentedString(taxNumber)).append("\n");
    sb.append("    taxOffice: ").append(toIndentedString(taxOffice)).append("\n");
    sb.append("    invoiceType: ").append(toIndentedString(invoiceType)).append("\n");
    sb.append("    isEinvoiceUser: ").append(toIndentedString(isEinvoiceUser)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    member: ").append(toIndentedString(member)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("    location: ").append(toIndentedString(location)).append("\n");
    sb.append("    subLocation: ").append(toIndentedString(subLocation)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

