package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.IOException;

/**
 * ShopPreference
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ShopPreference {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("varKey")
  private String varKey = null;

  @SerializedName("varValue")
  private String varValue = null;

  public ShopPreference id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Tanımlama nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Tanımlama nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ShopPreference varKey(String varKey) {
    this.varKey = varKey;
    return this;
  }

   /**
   * Tanımlama nesnesi için değişken anahtarı.
   * @return varKey
  **/
  @ApiModelProperty(example = "company_name", value = "Tanımlama nesnesi için değişken anahtarı.")
  public String getVarKey() {
    return varKey;
  }

  public void setVarKey(String varKey) {
    this.varKey = varKey;
  }

  public ShopPreference varValue(String varValue) {
    this.varValue = varValue;
    return this;
  }

   /**
   * Tanımlama nesnesi için değişken değeri.
   * @return varValue
  **/
  @ApiModelProperty(example = "Ideasoft Yazılım San. ve Tic. A.Ş.", value = "Tanımlama nesnesi için değişken değeri.")
  public String getVarValue() {
    return varValue;
  }

  public void setVarValue(String varValue) {
    this.varValue = varValue;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShopPreference shopPreference = (ShopPreference) o;
    return Objects.equals(this.id, shopPreference.id) &&
        Objects.equals(this.varKey, shopPreference.varKey) &&
        Objects.equals(this.varValue, shopPreference.varValue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, varKey, varValue);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShopPreference {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    varKey: ").append(toIndentedString(varKey)).append("\n");
    sb.append("    varValue: ").append(toIndentedString(varValue)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

