package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Product;
import java.io.IOException;
import org.threeten.bp.OffsetDateTime;

/**
 * ProductToCountDown
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ProductToCountDown {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("startDate")
  private OffsetDateTime startDate = null;

  @SerializedName("endDate")
  private OffsetDateTime endDate = null;

  @SerializedName("expireDate")
  private OffsetDateTime expireDate = null;

  /**
   * Geri sayımın aktiflik durumu bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(UseCountDownEnum.Adapter.class)
  public enum UseCountDownEnum {
    _0("0"),
    
    _1("1");

    private String value;

    UseCountDownEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static UseCountDownEnum fromValue(String text) {
      for (UseCountDownEnum b : UseCountDownEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<UseCountDownEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final UseCountDownEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public UseCountDownEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return UseCountDownEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("useCountDown")
  private UseCountDownEnum useCountDown = null;

  @SerializedName("product")
  private Product product = null;

  public ProductToCountDown id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Ürün geri sayım bağı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Ürün geri sayım bağı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ProductToCountDown startDate(OffsetDateTime startDate) {
    this.startDate = startDate;
    return this;
  }

   /**
   * Geri sayımın başlangıç tarihi.
   * @return startDate
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Geri sayımın başlangıç tarihi.")
  public OffsetDateTime getStartDate() {
    return startDate;
  }

  public void setStartDate(OffsetDateTime startDate) {
    this.startDate = startDate;
  }

  public ProductToCountDown endDate(OffsetDateTime endDate) {
    this.endDate = endDate;
    return this;
  }

   /**
   * Geri sayımın bitiş tarihi.
   * @return endDate
  **/
  @ApiModelProperty(example = "2018-02-26T09:36:03+0300", value = "Geri sayımın bitiş tarihi.")
  public OffsetDateTime getEndDate() {
    return endDate;
  }

  public void setEndDate(OffsetDateTime endDate) {
    this.endDate = endDate;
  }

  public ProductToCountDown expireDate(OffsetDateTime expireDate) {
    this.expireDate = expireDate;
    return this;
  }

   /**
   * Geri sayımın ürün için geçersiz olma tarihi.
   * @return expireDate
  **/
  @ApiModelProperty(example = "2018-02-26T09:36:03+0300", value = "Geri sayımın ürün için geçersiz olma tarihi.")
  public OffsetDateTime getExpireDate() {
    return expireDate;
  }

  public void setExpireDate(OffsetDateTime expireDate) {
    this.expireDate = expireDate;
  }

  public ProductToCountDown useCountDown(UseCountDownEnum useCountDown) {
    this.useCountDown = useCountDown;
    return this;
  }

   /**
   * Geri sayımın aktiflik durumu bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return useCountDown
  **/
  @ApiModelProperty(example = "0", required = true, value = "Geri sayımın aktiflik durumu bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
  public UseCountDownEnum getUseCountDown() {
    return useCountDown;
  }

  public void setUseCountDown(UseCountDownEnum useCountDown) {
    this.useCountDown = useCountDown;
  }

  public ProductToCountDown product(Product product) {
    this.product = product;
    return this;
  }

   /**
   * Get product
   * @return product
  **/
  @ApiModelProperty(value = "")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProductToCountDown productToCountDown = (ProductToCountDown) o;
    return Objects.equals(this.id, productToCountDown.id) &&
        Objects.equals(this.startDate, productToCountDown.startDate) &&
        Objects.equals(this.endDate, productToCountDown.endDate) &&
        Objects.equals(this.expireDate, productToCountDown.expireDate) &&
        Objects.equals(this.useCountDown, productToCountDown.useCountDown) &&
        Objects.equals(this.product, productToCountDown.product);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, startDate, endDate, expireDate, useCountDown, product);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductToCountDown {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("    endDate: ").append(toIndentedString(endDate)).append("\n");
    sb.append("    expireDate: ").append(toIndentedString(expireDate)).append("\n");
    sb.append("    useCountDown: ").append(toIndentedString(useCountDown)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

