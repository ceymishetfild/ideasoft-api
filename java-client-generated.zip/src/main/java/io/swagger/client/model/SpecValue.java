package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.SpecGroup;
import io.swagger.client.model.SpecName;
import java.io.IOException;

/**
 * SpecValue
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class SpecValue {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("name")
  private String name = null;

  @SerializedName("sortOrder")
  private Integer sortOrder = null;

  /**
   * Ürün özellik değeri logo görseli için geçerli dosya uzantıları.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;jpg&lt;/code&gt; : jpg dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;png&lt;/code&gt; : png dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;gif&lt;/code&gt; : gif dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;jpeg&lt;/code&gt; : jpeg dosyaları için geçerli uzantı.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(LogoEnum.Adapter.class)
  public enum LogoEnum {
    JPG("jpg"),
    
    PNG("png"),
    
    GIF("gif"),
    
    JPEG("jpeg");

    private String value;

    LogoEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static LogoEnum fromValue(String text) {
      for (LogoEnum b : LogoEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<LogoEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final LogoEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public LogoEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return LogoEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("logo")
  private LogoEnum logo = null;

  /**
   * Ürün özellik değerinin aktiflik bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    _0("0"),
    
    _1("1");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  @SerializedName("attachment")
  private String attachment = null;

  @SerializedName("specGroup")
  private SpecGroup specGroup = null;

  @SerializedName("specName")
  private SpecName specName = null;

  public SpecValue id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Ürün özellik değeri nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Ürün özellik değeri nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public SpecValue name(String name) {
    this.name = name;
    return this;
  }

   /**
   * Ürün özellik değeri nesnesi için isim değeri.
   * @return name
  **/
  @ApiModelProperty(example = "8 GB", required = true, value = "Ürün özellik değeri nesnesi için isim değeri.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public SpecValue sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

   /**
   * Ürün özellik değeri nesnesi için sıralama değeri.
   * minimum: 0
   * maximum: 999
   * @return sortOrder
  **/
  @ApiModelProperty(example = "999", value = "Ürün özellik değeri nesnesi için sıralama değeri.")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public SpecValue logo(LogoEnum logo) {
    this.logo = logo;
    return this;
  }

   /**
   * Ürün özellik değeri logo görseli için geçerli dosya uzantıları.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;jpg&lt;/code&gt; : jpg dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;png&lt;/code&gt; : png dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;gif&lt;/code&gt; : gif dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;jpeg&lt;/code&gt; : jpeg dosyaları için geçerli uzantı.&lt;br&gt;&lt;/div&gt;
   * @return logo
  **/
  @ApiModelProperty(example = "jpg", value = "Ürün özellik değeri logo görseli için geçerli dosya uzantıları.<div class='idea_choice_list'><code>jpg</code> : jpg dosyaları için geçerli uzantı.<br><code>png</code> : png dosyaları için geçerli uzantı.<br><code>gif</code> : gif dosyaları için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyaları için geçerli uzantı.<br></div>")
  public LogoEnum getLogo() {
    return logo;
  }

  public void setLogo(LogoEnum logo) {
    this.logo = logo;
  }

  public SpecValue status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Ürün özellik değerinin aktiflik bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @ApiModelProperty(example = "1", required = true, value = "Ürün özellik değerinin aktiflik bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public SpecValue attachment(String attachment) {
    this.attachment = attachment;
    return this;
  }

   /**
   * Ürün görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
   * @return attachment
  **/
  @ApiModelProperty(example = "Buraya örnek gelecek.", value = "Ürün görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.")
  public String getAttachment() {
    return attachment;
  }

  public void setAttachment(String attachment) {
    this.attachment = attachment;
  }

  public SpecValue specGroup(SpecGroup specGroup) {
    this.specGroup = specGroup;
    return this;
  }

   /**
   * Get specGroup
   * @return specGroup
  **/
  @ApiModelProperty(value = "")
  public SpecGroup getSpecGroup() {
    return specGroup;
  }

  public void setSpecGroup(SpecGroup specGroup) {
    this.specGroup = specGroup;
  }

  public SpecValue specName(SpecName specName) {
    this.specName = specName;
    return this;
  }

   /**
   * Get specName
   * @return specName
  **/
  @ApiModelProperty(value = "")
  public SpecName getSpecName() {
    return specName;
  }

  public void setSpecName(SpecName specName) {
    this.specName = specName;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SpecValue specValue = (SpecValue) o;
    return Objects.equals(this.id, specValue.id) &&
        Objects.equals(this.name, specValue.name) &&
        Objects.equals(this.sortOrder, specValue.sortOrder) &&
        Objects.equals(this.logo, specValue.logo) &&
        Objects.equals(this.status, specValue.status) &&
        Objects.equals(this.attachment, specValue.attachment) &&
        Objects.equals(this.specGroup, specValue.specGroup) &&
        Objects.equals(this.specName, specValue.specName);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, sortOrder, logo, status, attachment, specGroup, specName);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SpecValue {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    logo: ").append(toIndentedString(logo)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    attachment: ").append(toIndentedString(attachment)).append("\n");
    sb.append("    specGroup: ").append(toIndentedString(specGroup)).append("\n");
    sb.append("    specName: ").append(toIndentedString(specName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

