package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.PaymentGatewaySetting;
import io.swagger.client.model.PaymentProvider;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * PaymentGateway
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class PaymentGateway {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("code")
  private String code = null;

  @SerializedName("name")
  private String name = null;

  /**
   * Ödeme kanalının aktiflik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    ACTIVE("active"),
    
    PASSIVE("passive");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  @SerializedName("sortOrder")
  private Integer sortOrder = null;

  @SerializedName("paymentProvider")
  private PaymentProvider paymentProvider = null;

  @SerializedName("settings")
  private List<PaymentGatewaySetting> settings = null;

  public PaymentGateway id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Ödeme kanalı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Ödeme kanalı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public PaymentGateway code(String code) {
    this.code = code;
    return this;
  }

   /**
   * Ödeme kanalı için ön tanımlanmış kod değeri.
   * @return code
  **/
  @ApiModelProperty(example = "ideabank", required = true, value = "Ödeme kanalı için ön tanımlanmış kod değeri.")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public PaymentGateway name(String name) {
    this.name = name;
    return this;
  }

   /**
   * Ödeme kanalı nesnesi için isim değeri.
   * @return name
  **/
  @ApiModelProperty(example = "Idea Bank", required = true, value = "Ödeme kanalı nesnesi için isim değeri.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public PaymentGateway status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Ödeme kanalının aktiflik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @ApiModelProperty(example = "active", required = true, value = "Ödeme kanalının aktiflik durumu.<div class='idea_choice_list'><code>active</code> : Aktif<br><code>passive</code> : Pasif<br></div>")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public PaymentGateway sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

   /**
   * Ödeme kanalı nesnesi için sıralama değeri.
   * minimum: 0
   * @return sortOrder
  **/
  @ApiModelProperty(example = "999", value = "Ödeme kanalı nesnesi için sıralama değeri.")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public PaymentGateway paymentProvider(PaymentProvider paymentProvider) {
    this.paymentProvider = paymentProvider;
    return this;
  }

   /**
   * Get paymentProvider
   * @return paymentProvider
  **/
  @ApiModelProperty(value = "")
  public PaymentProvider getPaymentProvider() {
    return paymentProvider;
  }

  public void setPaymentProvider(PaymentProvider paymentProvider) {
    this.paymentProvider = paymentProvider;
  }

  public PaymentGateway settings(List<PaymentGatewaySetting> settings) {
    this.settings = settings;
    return this;
  }

  public PaymentGateway addSettingsItem(PaymentGatewaySetting settingsItem) {
    if (this.settings == null) {
      this.settings = new ArrayList<PaymentGatewaySetting>();
    }
    this.settings.add(settingsItem);
    return this;
  }

   /**
   * Ödeme kanalı ayarları.
   * @return settings
  **/
  @ApiModelProperty(value = "Ödeme kanalı ayarları.")
  public List<PaymentGatewaySetting> getSettings() {
    return settings;
  }

  public void setSettings(List<PaymentGatewaySetting> settings) {
    this.settings = settings;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PaymentGateway paymentGateway = (PaymentGateway) o;
    return Objects.equals(this.id, paymentGateway.id) &&
        Objects.equals(this.code, paymentGateway.code) &&
        Objects.equals(this.name, paymentGateway.name) &&
        Objects.equals(this.status, paymentGateway.status) &&
        Objects.equals(this.sortOrder, paymentGateway.sortOrder) &&
        Objects.equals(this.paymentProvider, paymentGateway.paymentProvider) &&
        Objects.equals(this.settings, paymentGateway.settings);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, code, name, status, sortOrder, paymentProvider, settings);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PaymentGateway {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    paymentProvider: ").append(toIndentedString(paymentProvider)).append("\n");
    sb.append("    settings: ").append(toIndentedString(settings)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

