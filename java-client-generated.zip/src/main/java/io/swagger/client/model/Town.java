package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Location;
import io.swagger.client.model.TownGroup;
import java.io.IOException;

/**
 * Town
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Town {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("name")
  private String name = null;

  /**
   * İlçenin aktiflik bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    _0("0"),
    
    _1("1");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  @SerializedName("location")
  private Location location = null;

  @SerializedName("townGroup")
  private TownGroup townGroup = null;

  public Town id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * İlçe nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "İlçe nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Town name(String name) {
    this.name = name;
    return this;
  }

   /**
   * İlçe nesnesi için isim değeri.
   * @return name
  **/
  @ApiModelProperty(example = "Üsküdar", required = true, value = "İlçe nesnesi için isim değeri.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Town status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * İlçenin aktiflik bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @ApiModelProperty(example = "1", required = true, value = "İlçenin aktiflik bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Town location(Location location) {
    this.location = location;
    return this;
  }

   /**
   * Get location
   * @return location
  **/
  @ApiModelProperty(value = "")
  public Location getLocation() {
    return location;
  }

  public void setLocation(Location location) {
    this.location = location;
  }

  public Town townGroup(TownGroup townGroup) {
    this.townGroup = townGroup;
    return this;
  }

   /**
   * Get townGroup
   * @return townGroup
  **/
  @ApiModelProperty(value = "")
  public TownGroup getTownGroup() {
    return townGroup;
  }

  public void setTownGroup(TownGroup townGroup) {
    this.townGroup = townGroup;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Town town = (Town) o;
    return Objects.equals(this.id, town.id) &&
        Objects.equals(this.name, town.name) &&
        Objects.equals(this.status, town.status) &&
        Objects.equals(this.location, town.location) &&
        Objects.equals(this.townGroup, town.townGroup);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, status, location, townGroup);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Town {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    location: ").append(toIndentedString(location)).append("\n");
    sb.append("    townGroup: ").append(toIndentedString(townGroup)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

