package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.MemberGroup;
import io.swagger.client.model.ShopUserlevels;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * User
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class User {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("firstname")
  private String firstname = null;

  @SerializedName("surname")
  private String surname = null;

  @SerializedName("email")
  private String email = null;

  @SerializedName("username")
  private String username = null;

  @SerializedName("phoneNumber")
  private String phoneNumber = null;

  /**
   * Yöneticinin aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Askıya alınmış.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    NUMBER_0(0),
    
    NUMBER_1(1),
    
    NUMBER_2(2);

    private Integer value;

    StatusEnum(Integer value) {
      this.value = value;
    }

    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        Integer value = jsonReader.nextInt();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  /**
   * Yöneticinin site sahibi olma durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Site sahibi.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Site sahibi değil.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(IsOwnerEnum.Adapter.class)
  public enum IsOwnerEnum {
    _0("0"),
    
    _1("1");

    private String value;

    IsOwnerEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static IsOwnerEnum fromValue(String text) {
      for (IsOwnerEnum b : IsOwnerEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<IsOwnerEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final IsOwnerEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public IsOwnerEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return IsOwnerEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("isOwner")
  private IsOwnerEnum isOwner = null;

  @SerializedName("membergroups")
  private List<MemberGroup> membergroups = null;

  /**
   * Yöneticinin SMS verifikasyonu yapılma bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : SMS verifikasyon yapılmış.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : SMS verifikasyon yapılmamış.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(SmsApprovedEnum.Adapter.class)
  public enum SmsApprovedEnum {
    _0("0"),
    
    _1("1");

    private String value;

    SmsApprovedEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static SmsApprovedEnum fromValue(String text) {
      for (SmsApprovedEnum b : SmsApprovedEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<SmsApprovedEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final SmsApprovedEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public SmsApprovedEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return SmsApprovedEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("smsApproved")
  private SmsApprovedEnum smsApproved = null;

  @SerializedName("userlevel")
  private ShopUserlevels userlevel = null;

  public User id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Yönetici nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Yönetici nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public User firstname(String firstname) {
    this.firstname = firstname;
    return this;
  }

   /**
   * Yöneticinin ismi.
   * @return firstname
  **/
  @ApiModelProperty(example = "John", value = "Yöneticinin ismi.")
  public String getFirstname() {
    return firstname;
  }

  public void setFirstname(String firstname) {
    this.firstname = firstname;
  }

  public User surname(String surname) {
    this.surname = surname;
    return this;
  }

   /**
   * Yöneticinin soy ismi.
   * @return surname
  **/
  @ApiModelProperty(example = "Doe", value = "Yöneticinin soy ismi.")
  public String getSurname() {
    return surname;
  }

  public void setSurname(String surname) {
    this.surname = surname;
  }

  public User email(String email) {
    this.email = email;
    return this;
  }

   /**
   * Yöneticinin e-mail adresi.
   * @return email
  **/
  @ApiModelProperty(example = "johndoe@ideasoft.com.tr", required = true, value = "Yöneticinin e-mail adresi.")
  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public User username(String username) {
    this.username = username;
    return this;
  }

   /**
   * Yöneticinin kullanıcı adı.
   * @return username
  **/
  @ApiModelProperty(example = "yonetici", required = true, value = "Yöneticinin kullanıcı adı.")
  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public User phoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
    return this;
  }

   /**
   * Yöneticinin telefon numarası.
   * @return phoneNumber
  **/
  @ApiModelProperty(example = "+90 (555) 555 55 55", value = "Yöneticinin telefon numarası.")
  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public User status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Yöneticinin aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Askıya alınmış.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @ApiModelProperty(example = "1", required = true, value = "Yöneticinin aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br><code>2</code> : Askıya alınmış.<br></div>")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public User isOwner(IsOwnerEnum isOwner) {
    this.isOwner = isOwner;
    return this;
  }

   /**
   * Yöneticinin site sahibi olma durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Site sahibi.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Site sahibi değil.&lt;br&gt;&lt;/div&gt;
   * @return isOwner
  **/
  @ApiModelProperty(example = "1", value = "Yöneticinin site sahibi olma durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Site sahibi.<br><code>0</code> : Site sahibi değil.<br></div>")
  public IsOwnerEnum getIsOwner() {
    return isOwner;
  }

  public void setIsOwner(IsOwnerEnum isOwner) {
    this.isOwner = isOwner;
  }

  public User membergroups(List<MemberGroup> membergroups) {
    this.membergroups = membergroups;
    return this;
  }

  public User addMembergroupsItem(MemberGroup membergroupsItem) {
    if (this.membergroups == null) {
      this.membergroups = new ArrayList<MemberGroup>();
    }
    this.membergroups.add(membergroupsItem);
    return this;
  }

   /**
   * İlgili üye grubu.
   * @return membergroups
  **/
  @ApiModelProperty(value = "İlgili üye grubu.")
  public List<MemberGroup> getMembergroups() {
    return membergroups;
  }

  public void setMembergroups(List<MemberGroup> membergroups) {
    this.membergroups = membergroups;
  }

  public User smsApproved(SmsApprovedEnum smsApproved) {
    this.smsApproved = smsApproved;
    return this;
  }

   /**
   * Yöneticinin SMS verifikasyonu yapılma bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : SMS verifikasyon yapılmış.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : SMS verifikasyon yapılmamış.&lt;br&gt;&lt;/div&gt;
   * @return smsApproved
  **/
  @ApiModelProperty(example = "1", value = "Yöneticinin SMS verifikasyonu yapılma bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : SMS verifikasyon yapılmış.<br><code>0</code> : SMS verifikasyon yapılmamış.<br></div>")
  public SmsApprovedEnum getSmsApproved() {
    return smsApproved;
  }

  public void setSmsApproved(SmsApprovedEnum smsApproved) {
    this.smsApproved = smsApproved;
  }

  public User userlevel(ShopUserlevels userlevel) {
    this.userlevel = userlevel;
    return this;
  }

   /**
   * Get userlevel
   * @return userlevel
  **/
  @ApiModelProperty(value = "")
  public ShopUserlevels getUserlevel() {
    return userlevel;
  }

  public void setUserlevel(ShopUserlevels userlevel) {
    this.userlevel = userlevel;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    User user = (User) o;
    return Objects.equals(this.id, user.id) &&
        Objects.equals(this.firstname, user.firstname) &&
        Objects.equals(this.surname, user.surname) &&
        Objects.equals(this.email, user.email) &&
        Objects.equals(this.username, user.username) &&
        Objects.equals(this.phoneNumber, user.phoneNumber) &&
        Objects.equals(this.status, user.status) &&
        Objects.equals(this.isOwner, user.isOwner) &&
        Objects.equals(this.membergroups, user.membergroups) &&
        Objects.equals(this.smsApproved, user.smsApproved) &&
        Objects.equals(this.userlevel, user.userlevel);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, firstname, surname, email, username, phoneNumber, status, isOwner, membergroups, smsApproved, userlevel);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class User {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    firstname: ").append(toIndentedString(firstname)).append("\n");
    sb.append("    surname: ").append(toIndentedString(surname)).append("\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    isOwner: ").append(toIndentedString(isOwner)).append("\n");
    sb.append("    membergroups: ").append(toIndentedString(membergroups)).append("\n");
    sb.append("    smsApproved: ").append(toIndentedString(smsApproved)).append("\n");
    sb.append("    userlevel: ").append(toIndentedString(userlevel)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

