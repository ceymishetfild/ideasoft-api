package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Order;
import java.io.IOException;
import org.threeten.bp.OffsetDateTime;

/**
 * OrderUserNote
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class OrderUserNote {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("userEmail")
  private String userEmail = null;

  @SerializedName("userFirstname")
  private String userFirstname = null;

  @SerializedName("userSurname")
  private String userSurname = null;

  @SerializedName("note")
  private String note = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  @SerializedName("order")
  private Order order = null;

  public OrderUserNote id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Sipariş yönetici notu nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Sipariş yönetici notu nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OrderUserNote userEmail(String userEmail) {
    this.userEmail = userEmail;
    return this;
  }

   /**
   * Yöneticinin(admin) e-mail adresi.
   * @return userEmail
  **/
  @ApiModelProperty(example = "johndoe@ideasoft.com.tr", required = true, value = "Yöneticinin(admin) e-mail adresi.")
  public String getUserEmail() {
    return userEmail;
  }

  public void setUserEmail(String userEmail) {
    this.userEmail = userEmail;
  }

  public OrderUserNote userFirstname(String userFirstname) {
    this.userFirstname = userFirstname;
    return this;
  }

   /**
   * Yöneticinin(admin) ismi.
   * @return userFirstname
  **/
  @ApiModelProperty(example = "John", value = "Yöneticinin(admin) ismi.")
  public String getUserFirstname() {
    return userFirstname;
  }

  public void setUserFirstname(String userFirstname) {
    this.userFirstname = userFirstname;
  }

  public OrderUserNote userSurname(String userSurname) {
    this.userSurname = userSurname;
    return this;
  }

   /**
   * Yöneticinin(admin) soy ismi.
   * @return userSurname
  **/
  @ApiModelProperty(example = "Doe", value = "Yöneticinin(admin) soy ismi.")
  public String getUserSurname() {
    return userSurname;
  }

  public void setUserSurname(String userSurname) {
    this.userSurname = userSurname;
  }

  public OrderUserNote note(String note) {
    this.note = note;
    return this;
  }

   /**
   * Yöneticinin(admin) sipariş için girdiği not.
   * @return note
  **/
  @ApiModelProperty(example = "Kutulanırken dikkat edilecek.", required = true, value = "Yöneticinin(admin) sipariş için girdiği not.")
  public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }

   /**
   * Sipariş yönetici notu nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", required = true, value = "Sipariş yönetici notu nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

   /**
   * Sipariş yönetici notu nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", required = true, value = "Sipariş yönetici notu nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public OrderUserNote order(Order order) {
    this.order = order;
    return this;
  }

   /**
   * Get order
   * @return order
  **/
  @ApiModelProperty(value = "")
  public Order getOrder() {
    return order;
  }

  public void setOrder(Order order) {
    this.order = order;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrderUserNote orderUserNote = (OrderUserNote) o;
    return Objects.equals(this.id, orderUserNote.id) &&
        Objects.equals(this.userEmail, orderUserNote.userEmail) &&
        Objects.equals(this.userFirstname, orderUserNote.userFirstname) &&
        Objects.equals(this.userSurname, orderUserNote.userSurname) &&
        Objects.equals(this.note, orderUserNote.note) &&
        Objects.equals(this.createdAt, orderUserNote.createdAt) &&
        Objects.equals(this.updatedAt, orderUserNote.updatedAt) &&
        Objects.equals(this.order, orderUserNote.order);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, userEmail, userFirstname, userSurname, note, createdAt, updatedAt, order);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderUserNote {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    userEmail: ").append(toIndentedString(userEmail)).append("\n");
    sb.append("    userFirstname: ").append(toIndentedString(userFirstname)).append("\n");
    sb.append("    userSurname: ").append(toIndentedString(userSurname)).append("\n");
    sb.append("    note: ").append(toIndentedString(note)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    order: ").append(toIndentedString(order)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

