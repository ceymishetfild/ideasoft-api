package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.OptionGroup;
import java.io.IOException;

/**
 * Options
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Options {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("title")
  private String title = null;

  @SerializedName("sortOrder")
  private Integer sortOrder = null;

  /**
   * Logo görselinin adı.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;jpg&lt;/code&gt; : jpg dosyası için geçerli uzantı.&lt;br&gt;&lt;code&gt;png&lt;/code&gt; : png dosyası için geçerli uzantı.&lt;br&gt;&lt;code&gt;gif&lt;/code&gt; : gif dosyası için geçerli uzantı.&lt;br&gt;&lt;code&gt;jpeg&lt;/code&gt; : jpeg dosyası için geçerli uzantı.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(LogoEnum.Adapter.class)
  public enum LogoEnum {
    JPG("jpg"),
    
    PNG("png"),
    
    GIF("gif"),
    
    JPEG("jpeg");

    private String value;

    LogoEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static LogoEnum fromValue(String text) {
      for (LogoEnum b : LogoEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<LogoEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final LogoEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public LogoEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return LogoEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("logo")
  private LogoEnum logo = null;

  @SerializedName("optionGroup")
  private OptionGroup optionGroup = null;

  @SerializedName("attachment")
  private String attachment = null;

  public Options id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Varyant nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Varyant nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Options title(String title) {
    this.title = title;
    return this;
  }

   /**
   * Varyant başlığı. Varyant Grubu renk is bu değer kırmızı olabilir.
   * @return title
  **/
  @ApiModelProperty(example = "Kırmızı", required = true, value = "Varyant başlığı. Varyant Grubu renk is bu değer kırmızı olabilir.")
  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public Options sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

   /**
   * Varyant nesnesi için sıralama değeri.
   * minimum: 0
   * maximum: 9999
   * @return sortOrder
  **/
  @ApiModelProperty(example = "999", value = "Varyant nesnesi için sıralama değeri.")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public Options logo(LogoEnum logo) {
    this.logo = logo;
    return this;
  }

   /**
   * Logo görselinin adı.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;jpg&lt;/code&gt; : jpg dosyası için geçerli uzantı.&lt;br&gt;&lt;code&gt;png&lt;/code&gt; : png dosyası için geçerli uzantı.&lt;br&gt;&lt;code&gt;gif&lt;/code&gt; : gif dosyası için geçerli uzantı.&lt;br&gt;&lt;code&gt;jpeg&lt;/code&gt; : jpeg dosyası için geçerli uzantı.&lt;br&gt;&lt;/div&gt;
   * @return logo
  **/
  @ApiModelProperty(example = "logo.jpg", value = "Logo görselinin adı.<div class='idea_choice_list'><code>jpg</code> : jpg dosyası için geçerli uzantı.<br><code>png</code> : png dosyası için geçerli uzantı.<br><code>gif</code> : gif dosyası için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyası için geçerli uzantı.<br></div>")
  public LogoEnum getLogo() {
    return logo;
  }

  public void setLogo(LogoEnum logo) {
    this.logo = logo;
  }

  public Options optionGroup(OptionGroup optionGroup) {
    this.optionGroup = optionGroup;
    return this;
  }

   /**
   * Get optionGroup
   * @return optionGroup
  **/
  @ApiModelProperty(value = "")
  public OptionGroup getOptionGroup() {
    return optionGroup;
  }

  public void setOptionGroup(OptionGroup optionGroup) {
    this.optionGroup = optionGroup;
  }

  public Options attachment(String attachment) {
    this.attachment = attachment;
    return this;
  }

   /**
   * Varyant nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
   * @return attachment
  **/
  @ApiModelProperty(example = "Buraya example gelecek.", value = "Varyant nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.")
  public String getAttachment() {
    return attachment;
  }

  public void setAttachment(String attachment) {
    this.attachment = attachment;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Options options = (Options) o;
    return Objects.equals(this.id, options.id) &&
        Objects.equals(this.title, options.title) &&
        Objects.equals(this.sortOrder, options.sortOrder) &&
        Objects.equals(this.logo, options.logo) &&
        Objects.equals(this.optionGroup, options.optionGroup) &&
        Objects.equals(this.attachment, options.attachment);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, title, sortOrder, logo, optionGroup, attachment);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Options {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    logo: ").append(toIndentedString(logo)).append("\n");
    sb.append("    optionGroup: ").append(toIndentedString(optionGroup)).append("\n");
    sb.append("    attachment: ").append(toIndentedString(attachment)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

