package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.BillingAddress;
import io.swagger.client.model.Maillist;
import io.swagger.client.model.Member;
import io.swagger.client.model.OrderDetail;
import io.swagger.client.model.OrderItem;
import io.swagger.client.model.ShippingAddress;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;

/**
 * Order
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Order {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("customerFirstname")
  private String customerFirstname = null;

  @SerializedName("customerSurname")
  private String customerSurname = null;

  @SerializedName("customerEmail")
  private String customerEmail = null;

  @SerializedName("customerPhone")
  private String customerPhone = null;

  @SerializedName("paymentTypeName")
  private String paymentTypeName = null;

  @SerializedName("paymentProviderCode")
  private String paymentProviderCode = null;

  @SerializedName("paymentProviderName")
  private String paymentProviderName = null;

  @SerializedName("paymentGatewayCode")
  private String paymentGatewayCode = null;

  @SerializedName("paymentGatewayName")
  private String paymentGatewayName = null;

  @SerializedName("bankName")
  private String bankName = null;

  @SerializedName("clientIp")
  private String clientIp = null;

  @SerializedName("userAgent")
  private String userAgent = null;

  @SerializedName("currency")
  private String currency = null;

  @SerializedName("currencyRates")
  private String currencyRates = null;

  @SerializedName("amount")
  private Float amount = null;

  @SerializedName("couponDiscount")
  private Float couponDiscount = null;

  @SerializedName("taxAmount")
  private Float taxAmount = null;

  @SerializedName("promotionDiscount")
  private Float promotionDiscount = null;

  @SerializedName("generalAmount")
  private Float generalAmount = null;

  @SerializedName("shippingAmount")
  private Float shippingAmount = null;

  @SerializedName("additionalServiceAmount")
  private Float additionalServiceAmount = null;

  @SerializedName("finalAmount")
  private Float finalAmount = null;

  @SerializedName("sumOfGainedPoints")
  private Float sumOfGainedPoints = null;

  @SerializedName("installment")
  private Integer installment = null;

  @SerializedName("installmentRate")
  private Float installmentRate = null;

  @SerializedName("extraInstallment")
  private Integer extraInstallment = null;

  @SerializedName("transactionId")
  private String transactionId = null;

  /**
   * Siparişin müşteri notuna sahiplik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sipariş müşteri notuna sahip.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sipariş müşteri notuna sahip değil.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(HasUserNoteEnum.Adapter.class)
  public enum HasUserNoteEnum {
    _0("0"),
    
    _1("1");

    private String value;

    HasUserNoteEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static HasUserNoteEnum fromValue(String text) {
      for (HasUserNoteEnum b : HasUserNoteEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<HasUserNoteEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final HasUserNoteEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public HasUserNoteEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return HasUserNoteEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("hasUserNote")
  private HasUserNoteEnum hasUserNote = null;

  /**
   * Sipariş durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    DELETED("deleted"),
    
    WAITING_FOR_APPROVAL("waiting_for_approval"),
    
    APPROVED("approved"),
    
    FULFILLED("fulfilled"),
    
    CANCELLED("cancelled"),
    
    DELIVERED("delivered"),
    
    ON_ACCUMULATION("on_accumulation"),
    
    WAITING_FOR_PAYMENT("waiting_for_payment"),
    
    BEING_PREPARED("being_prepared"),
    
    REFUNDED("refunded"),
    
    PERSONAL_STATUS_1("personal_status_1"),
    
    PERSONAL_STATUS_2("personal_status_2"),
    
    PERSONAL_STATUS_3("personal_status_3");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  /**
   * Ödeme durumu bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;success&lt;/code&gt; : Başarılı&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(PaymentStatusEnum.Adapter.class)
  public enum PaymentStatusEnum {
    IN_TRANSACTION("in_transaction"),
    
    FAILED("failed"),
    
    SUCCESS("success");

    private String value;

    PaymentStatusEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static PaymentStatusEnum fromValue(String text) {
      for (PaymentStatusEnum b : PaymentStatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<PaymentStatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final PaymentStatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public PaymentStatusEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return PaymentStatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("paymentStatus")
  private PaymentStatusEnum paymentStatus = null;

  @SerializedName("errorMessage")
  private String errorMessage = null;

  /**
   * Siparişin gerçekleştiği cihaz bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil&lt;br&gt;&lt;code&gt;tablet&lt;/code&gt; : Tablet&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(DeviceTypeEnum.Adapter.class)
  public enum DeviceTypeEnum {
    DESKTOP("desktop"),
    
    MOBILE("mobile"),
    
    TABLET("tablet");

    private String value;

    DeviceTypeEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static DeviceTypeEnum fromValue(String text) {
      for (DeviceTypeEnum b : DeviceTypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<DeviceTypeEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final DeviceTypeEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public DeviceTypeEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return DeviceTypeEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("deviceType")
  private DeviceTypeEnum deviceType = null;

  @SerializedName("referrer")
  private String referrer = null;

  @SerializedName("invoicePrintCount")
  private Integer invoicePrintCount = null;

  /**
   * Hediye paketi istenilmesi durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hediye paketi istiyorum&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hediye paketi istemiyorum&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(UseGiftPackageEnum.Adapter.class)
  public enum UseGiftPackageEnum {
    _0("0"),
    
    _1("1");

    private String value;

    UseGiftPackageEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static UseGiftPackageEnum fromValue(String text) {
      for (UseGiftPackageEnum b : UseGiftPackageEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<UseGiftPackageEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final UseGiftPackageEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public UseGiftPackageEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return UseGiftPackageEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("useGiftPackage")
  private UseGiftPackageEnum useGiftPackage = null;

  @SerializedName("giftNote")
  private String giftNote = null;

  @SerializedName("memberGroupName")
  private String memberGroupName = null;

  /**
   * Promosyon kullanılma durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Promosyon kullan&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Promosyon kullanma&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(UsePromotionEnum.Adapter.class)
  public enum UsePromotionEnum {
    _0("0"),
    
    _1("1");

    private String value;

    UsePromotionEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static UsePromotionEnum fromValue(String text) {
      for (UsePromotionEnum b : UsePromotionEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<UsePromotionEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final UsePromotionEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public UsePromotionEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return UsePromotionEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("usePromotion")
  private UsePromotionEnum usePromotion = null;

  @SerializedName("shippingProviderCode")
  private String shippingProviderCode = null;

  @SerializedName("shippingProviderName")
  private String shippingProviderName = null;

  @SerializedName("shippingCompanyName")
  private String shippingCompanyName = null;

  /**
   * Siparişin kargo ödeme tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı Ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici Ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için geçerli değil.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(ShippingPaymentTypeEnum.Adapter.class)
  public enum ShippingPaymentTypeEnum {
    CASH_ON_DELIVERY("cash_on_delivery"),
    
    STANDART_DELIVERY("standart_delivery"),
    
    NOT_APPLICABLE("not_applicable");

    private String value;

    ShippingPaymentTypeEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static ShippingPaymentTypeEnum fromValue(String text) {
      for (ShippingPaymentTypeEnum b : ShippingPaymentTypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<ShippingPaymentTypeEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final ShippingPaymentTypeEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public ShippingPaymentTypeEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return ShippingPaymentTypeEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("shippingPaymentType")
  private ShippingPaymentTypeEnum shippingPaymentType = null;

  @SerializedName("shippingTrackingCode")
  private String shippingTrackingCode = null;

  @SerializedName("source")
  private String source = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  @SerializedName("maillist")
  private Maillist maillist = null;

  @SerializedName("member")
  private Member member = null;

  @SerializedName("orderDetails")
  private List<OrderDetail> orderDetails = null;

  @SerializedName("orderItems")
  private List<OrderItem> orderItems = null;

  @SerializedName("shippingAddress")
  private ShippingAddress shippingAddress = null;

  @SerializedName("billingAddress")
  private BillingAddress billingAddress = null;

  public Order id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Sipariş nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Sipariş nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Order customerFirstname(String customerFirstname) {
    this.customerFirstname = customerFirstname;
    return this;
  }

   /**
   * Müşterinin ismi.
   * @return customerFirstname
  **/
  @ApiModelProperty(example = "John", required = true, value = "Müşterinin ismi.")
  public String getCustomerFirstname() {
    return customerFirstname;
  }

  public void setCustomerFirstname(String customerFirstname) {
    this.customerFirstname = customerFirstname;
  }

  public Order customerSurname(String customerSurname) {
    this.customerSurname = customerSurname;
    return this;
  }

   /**
   * Müşterinin soy ismi.
   * @return customerSurname
  **/
  @ApiModelProperty(example = "Doe", required = true, value = "Müşterinin soy ismi.")
  public String getCustomerSurname() {
    return customerSurname;
  }

  public void setCustomerSurname(String customerSurname) {
    this.customerSurname = customerSurname;
  }

  public Order customerEmail(String customerEmail) {
    this.customerEmail = customerEmail;
    return this;
  }

   /**
   * Müşterinin e-mail adresi.
   * @return customerEmail
  **/
  @ApiModelProperty(example = "johndoe@ideasoft.com.tr", required = true, value = "Müşterinin e-mail adresi.")
  public String getCustomerEmail() {
    return customerEmail;
  }

  public void setCustomerEmail(String customerEmail) {
    this.customerEmail = customerEmail;
  }

  public Order customerPhone(String customerPhone) {
    this.customerPhone = customerPhone;
    return this;
  }

   /**
   * Müşterinin telefon numarası.
   * @return customerPhone
  **/
  @ApiModelProperty(example = "+90 (216) 326 04 77", required = true, value = "Müşterinin telefon numarası.")
  public String getCustomerPhone() {
    return customerPhone;
  }

  public void setCustomerPhone(String customerPhone) {
    this.customerPhone = customerPhone;
  }

  public Order paymentTypeName(String paymentTypeName) {
    this.paymentTypeName = paymentTypeName;
    return this;
  }

   /**
   * Siparişin ödeme tipi.
   * @return paymentTypeName
  **/
  @ApiModelProperty(example = "Havale", required = true, value = "Siparişin ödeme tipi.")
  public String getPaymentTypeName() {
    return paymentTypeName;
  }

  public void setPaymentTypeName(String paymentTypeName) {
    this.paymentTypeName = paymentTypeName;
  }

  public Order paymentProviderCode(String paymentProviderCode) {
    this.paymentProviderCode = paymentProviderCode;
    return this;
  }

   /**
   * Siparişin ödeme altyapısı sağlayıcısının kodu. Ön tanımlıdır. API otomatik oluşturur.
   * @return paymentProviderCode
  **/
  @ApiModelProperty(example = "MoneyOrder", required = true, value = "Siparişin ödeme altyapısı sağlayıcısının kodu. Ön tanımlıdır. API otomatik oluşturur.")
  public String getPaymentProviderCode() {
    return paymentProviderCode;
  }

  public void setPaymentProviderCode(String paymentProviderCode) {
    this.paymentProviderCode = paymentProviderCode;
  }

  public Order paymentProviderName(String paymentProviderName) {
    this.paymentProviderName = paymentProviderName;
    return this;
  }

   /**
   * Siparişin ödeme altyapısı sağlayıcısının adı. Ön tanımlıdır. API otomatik oluşturur.
   * @return paymentProviderName
  **/
  @ApiModelProperty(example = "Havale", required = true, value = "Siparişin ödeme altyapısı sağlayıcısının adı. Ön tanımlıdır. API otomatik oluşturur.")
  public String getPaymentProviderName() {
    return paymentProviderName;
  }

  public void setPaymentProviderName(String paymentProviderName) {
    this.paymentProviderName = paymentProviderName;
  }

  public Order paymentGatewayCode(String paymentGatewayCode) {
    this.paymentGatewayCode = paymentGatewayCode;
    return this;
  }

   /**
   * Siparişin ödeme kanalının kodu. Ön tanımlıdır. API otomatik oluşturur.
   * @return paymentGatewayCode
  **/
  @ApiModelProperty(example = "ideabank_1", required = true, value = "Siparişin ödeme kanalının kodu. Ön tanımlıdır. API otomatik oluşturur.")
  public String getPaymentGatewayCode() {
    return paymentGatewayCode;
  }

  public void setPaymentGatewayCode(String paymentGatewayCode) {
    this.paymentGatewayCode = paymentGatewayCode;
  }

  public Order paymentGatewayName(String paymentGatewayName) {
    this.paymentGatewayName = paymentGatewayName;
    return this;
  }

   /**
   * Siparişin ödeme kanalının adı. Ön tanımlıdır. API otomatik oluşturur.
   * @return paymentGatewayName
  **/
  @ApiModelProperty(example = "IdeaBank", required = true, value = "Siparişin ödeme kanalının adı. Ön tanımlıdır. API otomatik oluşturur.")
  public String getPaymentGatewayName() {
    return paymentGatewayName;
  }

  public void setPaymentGatewayName(String paymentGatewayName) {
    this.paymentGatewayName = paymentGatewayName;
  }

  public Order bankName(String bankName) {
    this.bankName = bankName;
    return this;
  }

   /**
   * Siparişin banka adı. Ön tanımlıdır. API otomatik oluşturur.
   * @return bankName
  **/
  @ApiModelProperty(example = "IdeaBank", value = "Siparişin banka adı. Ön tanımlıdır. API otomatik oluşturur.")
  public String getBankName() {
    return bankName;
  }

  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  public Order clientIp(String clientIp) {
    this.clientIp = clientIp;
    return this;
  }

   /**
   * Müşterinin IP adresi.
   * @return clientIp
  **/
  @ApiModelProperty(example = "192.168.1.1", required = true, value = "Müşterinin IP adresi.")
  public String getClientIp() {
    return clientIp;
  }

  public void setClientIp(String clientIp) {
    this.clientIp = clientIp;
  }

  public Order userAgent(String userAgent) {
    this.userAgent = userAgent;
    return this;
  }

   /**
   * Siparişin gerçekleştiği tarayıcı bilgisi.
   * @return userAgent
  **/
  @ApiModelProperty(example = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36", value = "Siparişin gerçekleştiği tarayıcı bilgisi.")
  public String getUserAgent() {
    return userAgent;
  }

  public void setUserAgent(String userAgent) {
    this.userAgent = userAgent;
  }

  public Order currency(String currency) {
    this.currency = currency;
    return this;
  }

   /**
   * Kur bilgisi.
   * @return currency
  **/
  @ApiModelProperty(example = "TL", required = true, value = "Kur bilgisi.")
  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public Order currencyRates(String currencyRates) {
    this.currencyRates = currencyRates;
    return this;
  }

   /**
   * Kur oranları.
   * @return currencyRates
  **/
  @ApiModelProperty(example = "{\"TL\":[1,1],\"USD\":[3.7698,3.7766],\"EUR\":[4.6575,4.6659],\"GBP\":[5.2597,5.2872]}", required = true, value = "Kur oranları.")
  public String getCurrencyRates() {
    return currencyRates;
  }

  public void setCurrencyRates(String currencyRates) {
    this.currencyRates = currencyRates;
  }

  public Order amount(Float amount) {
    this.amount = amount;
    return this;
  }

   /**
   * Siparişin vergi hariç fiyatı.
   * minimum: 0
   * @return amount
  **/
  @ApiModelProperty(example = "1.69492", required = true, value = "Siparişin vergi hariç fiyatı.")
  public Float getAmount() {
    return amount;
  }

  public void setAmount(Float amount) {
    this.amount = amount;
  }

  public Order couponDiscount(Float couponDiscount) {
    this.couponDiscount = couponDiscount;
    return this;
  }

   /**
   * Siparişte kullanılan hediye çeki indirimi tutarı.
   * minimum: 0
   * @return couponDiscount
  **/
  @ApiModelProperty(example = "0.0", required = true, value = "Siparişte kullanılan hediye çeki indirimi tutarı.")
  public Float getCouponDiscount() {
    return couponDiscount;
  }

  public void setCouponDiscount(Float couponDiscount) {
    this.couponDiscount = couponDiscount;
  }

  public Order taxAmount(Float taxAmount) {
    this.taxAmount = taxAmount;
    return this;
  }

   /**
   * Siparişin vergi tutarı.
   * minimum: 0
   * @return taxAmount
  **/
  @ApiModelProperty(example = "0.30508", required = true, value = "Siparişin vergi tutarı.")
  public Float getTaxAmount() {
    return taxAmount;
  }

  public void setTaxAmount(Float taxAmount) {
    this.taxAmount = taxAmount;
  }

  public Order promotionDiscount(Float promotionDiscount) {
    this.promotionDiscount = promotionDiscount;
    return this;
  }

   /**
   * Siparişte kullanılan promosyon indirimi tutarı.
   * minimum: 0
   * @return promotionDiscount
  **/
  @ApiModelProperty(example = "0.0", required = true, value = "Siparişte kullanılan promosyon indirimi tutarı.")
  public Float getPromotionDiscount() {
    return promotionDiscount;
  }

  public void setPromotionDiscount(Float promotionDiscount) {
    this.promotionDiscount = promotionDiscount;
  }

  public Order generalAmount(Float generalAmount) {
    this.generalAmount = generalAmount;
    return this;
  }

   /**
   * Siparişin genel fiyat tutarı. orderAmount, couponDiscount, taxAmount, promotionDiscount, shippingAmount, additionalServiceAmount tutarlarının toplamı.
   * minimum: 0
   * @return generalAmount
  **/
  @ApiModelProperty(example = "2.0", required = true, value = "Siparişin genel fiyat tutarı. orderAmount, couponDiscount, taxAmount, promotionDiscount, shippingAmount, additionalServiceAmount tutarlarının toplamı.")
  public Float getGeneralAmount() {
    return generalAmount;
  }

  public void setGeneralAmount(Float generalAmount) {
    this.generalAmount = generalAmount;
  }

  public Order shippingAmount(Float shippingAmount) {
    this.shippingAmount = shippingAmount;
    return this;
  }

   /**
   * Siparişin teslimat ücreti.
   * minimum: 0
   * @return shippingAmount
  **/
  @ApiModelProperty(example = "5.0", required = true, value = "Siparişin teslimat ücreti.")
  public Float getShippingAmount() {
    return shippingAmount;
  }

  public void setShippingAmount(Float shippingAmount) {
    this.shippingAmount = shippingAmount;
  }

  public Order additionalServiceAmount(Float additionalServiceAmount) {
    this.additionalServiceAmount = additionalServiceAmount;
    return this;
  }

   /**
   * Siparişin ek hizmet bedeli ücreti.
   * @return additionalServiceAmount
  **/
  @ApiModelProperty(example = "0.0", required = true, value = "Siparişin ek hizmet bedeli ücreti.")
  public Float getAdditionalServiceAmount() {
    return additionalServiceAmount;
  }

  public void setAdditionalServiceAmount(Float additionalServiceAmount) {
    this.additionalServiceAmount = additionalServiceAmount;
  }

  public Order finalAmount(Float finalAmount) {
    this.finalAmount = finalAmount;
    return this;
  }

   /**
   * Siparişin son ödeme tutarı. generalAmount değerinin üzerine taksitten kaynaklı vade farkı bedeli eklenmiş hali.
   * minimum: 0
   * @return finalAmount
  **/
  @ApiModelProperty(example = "2.0", required = true, value = "Siparişin son ödeme tutarı. generalAmount değerinin üzerine taksitten kaynaklı vade farkı bedeli eklenmiş hali.")
  public Float getFinalAmount() {
    return finalAmount;
  }

  public void setFinalAmount(Float finalAmount) {
    this.finalAmount = finalAmount;
  }

  public Order sumOfGainedPoints(Float sumOfGainedPoints) {
    this.sumOfGainedPoints = sumOfGainedPoints;
    return this;
  }

   /**
   * Siparişten kazanılan puan tutarı.
   * minimum: 0
   * @return sumOfGainedPoints
  **/
  @ApiModelProperty(example = "200.0", value = "Siparişten kazanılan puan tutarı.")
  public Float getSumOfGainedPoints() {
    return sumOfGainedPoints;
  }

  public void setSumOfGainedPoints(Float sumOfGainedPoints) {
    this.sumOfGainedPoints = sumOfGainedPoints;
  }

  public Order installment(Integer installment) {
    this.installment = installment;
    return this;
  }

   /**
   * Siparişin taksit adeti.
   * minimum: 0
   * maximum: 12
   * @return installment
  **/
  @ApiModelProperty(example = "0", value = "Siparişin taksit adeti.")
  public Integer getInstallment() {
    return installment;
  }

  public void setInstallment(Integer installment) {
    this.installment = installment;
  }

  public Order installmentRate(Float installmentRate) {
    this.installmentRate = installmentRate;
    return this;
  }

   /**
   * Siparişin taksit oranı.
   * @return installmentRate
  **/
  @ApiModelProperty(example = "1.0", value = "Siparişin taksit oranı.")
  public Float getInstallmentRate() {
    return installmentRate;
  }

  public void setInstallmentRate(Float installmentRate) {
    this.installmentRate = installmentRate;
  }

  public Order extraInstallment(Integer extraInstallment) {
    this.extraInstallment = extraInstallment;
    return this;
  }

   /**
   * Siparişin ek taksit adeti.
   * minimum: 0
   * maximum: 12
   * @return extraInstallment
  **/
  @ApiModelProperty(example = "0", value = "Siparişin ek taksit adeti.")
  public Integer getExtraInstallment() {
    return extraInstallment;
  }

  public void setExtraInstallment(Integer extraInstallment) {
    this.extraInstallment = extraInstallment;
  }

  public Order transactionId(String transactionId) {
    this.transactionId = transactionId;
    return this;
  }

   /**
   * Siparişin numarası.
   * @return transactionId
  **/
  @ApiModelProperty(example = "c88728ce28151", value = "Siparişin numarası.")
  public String getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(String transactionId) {
    this.transactionId = transactionId;
  }

  public Order hasUserNote(HasUserNoteEnum hasUserNote) {
    this.hasUserNote = hasUserNote;
    return this;
  }

   /**
   * Siparişin müşteri notuna sahiplik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sipariş müşteri notuna sahip.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sipariş müşteri notuna sahip değil.&lt;br&gt;&lt;/div&gt;
   * @return hasUserNote
  **/
  @ApiModelProperty(example = "0", value = "Siparişin müşteri notuna sahiplik durumu.<div class='idea_choice_list'><code>1</code> : Sipariş müşteri notuna sahip.<br><code>0</code> : Sipariş müşteri notuna sahip değil.<br></div>")
  public HasUserNoteEnum getHasUserNote() {
    return hasUserNote;
  }

  public void setHasUserNote(HasUserNoteEnum hasUserNote) {
    this.hasUserNote = hasUserNote;
  }

  public Order status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Sipariş durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @ApiModelProperty(example = "waiting_for_approval", required = true, value = "Sipariş durumu.<div class='idea_choice_list'><code>deleted</code> : Silindi<br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br></div>")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Order paymentStatus(PaymentStatusEnum paymentStatus) {
    this.paymentStatus = paymentStatus;
    return this;
  }

   /**
   * Ödeme durumu bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;success&lt;/code&gt; : Başarılı&lt;br&gt;&lt;/div&gt;
   * @return paymentStatus
  **/
  @ApiModelProperty(example = "success", required = true, value = "Ödeme durumu bilgisi.<div class='idea_choice_list'><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br><code>failed</code> : Hatalı Ödemeler<br><code>success</code> : Başarılı<br></div>")
  public PaymentStatusEnum getPaymentStatus() {
    return paymentStatus;
  }

  public void setPaymentStatus(PaymentStatusEnum paymentStatus) {
    this.paymentStatus = paymentStatus;
  }

  public Order errorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
    return this;
  }

   /**
   * Siparişin hata mesajı.
   * @return errorMessage
  **/
  @ApiModelProperty(example = "Limit yetersiz.", value = "Siparişin hata mesajı.")
  public String getErrorMessage() {
    return errorMessage;
  }

  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  public Order deviceType(DeviceTypeEnum deviceType) {
    this.deviceType = deviceType;
    return this;
  }

   /**
   * Siparişin gerçekleştiği cihaz bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil&lt;br&gt;&lt;code&gt;tablet&lt;/code&gt; : Tablet&lt;br&gt;&lt;/div&gt;
   * @return deviceType
  **/
  @ApiModelProperty(example = "desktop", required = true, value = "Siparişin gerçekleştiği cihaz bilgisi.<div class='idea_choice_list'><code>desktop</code> : Masaüstü<br><code>mobile</code> : Mobil<br><code>tablet</code> : Tablet<br></div>")
  public DeviceTypeEnum getDeviceType() {
    return deviceType;
  }

  public void setDeviceType(DeviceTypeEnum deviceType) {
    this.deviceType = deviceType;
  }

  public Order referrer(String referrer) {
    this.referrer = referrer;
    return this;
  }

   /**
   * Siparişe yönlendiren web-sitesi adresi. Yönlendirmeyi yapan web-sitesinin tam URL bilgisini de içerir. API otomatik oluşturur.
   * @return referrer
  **/
  @ApiModelProperty(example = "www.referrer.com", value = "Siparişe yönlendiren web-sitesi adresi. Yönlendirmeyi yapan web-sitesinin tam URL bilgisini de içerir. API otomatik oluşturur.")
  public String getReferrer() {
    return referrer;
  }

  public void setReferrer(String referrer) {
    this.referrer = referrer;
  }

  public Order invoicePrintCount(Integer invoicePrintCount) {
    this.invoicePrintCount = invoicePrintCount;
    return this;
  }

   /**
   * Sipariş için alınan fatura çıktısı adedi.
   * minimum: 0
   * @return invoicePrintCount
  **/
  @ApiModelProperty(example = "1", value = "Sipariş için alınan fatura çıktısı adedi.")
  public Integer getInvoicePrintCount() {
    return invoicePrintCount;
  }

  public void setInvoicePrintCount(Integer invoicePrintCount) {
    this.invoicePrintCount = invoicePrintCount;
  }

  public Order useGiftPackage(UseGiftPackageEnum useGiftPackage) {
    this.useGiftPackage = useGiftPackage;
    return this;
  }

   /**
   * Hediye paketi istenilmesi durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hediye paketi istiyorum&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hediye paketi istemiyorum&lt;br&gt;&lt;/div&gt;
   * @return useGiftPackage
  **/
  @ApiModelProperty(example = "0", value = "Hediye paketi istenilmesi durumu.<div class='idea_choice_list'><code>1</code> : Hediye paketi istiyorum<br><code>0</code> : Hediye paketi istemiyorum<br></div>")
  public UseGiftPackageEnum getUseGiftPackage() {
    return useGiftPackage;
  }

  public void setUseGiftPackage(UseGiftPackageEnum useGiftPackage) {
    this.useGiftPackage = useGiftPackage;
  }

  public Order giftNote(String giftNote) {
    this.giftNote = giftNote;
    return this;
  }

   /**
   * Hediye notu.
   * @return giftNote
  **/
  @ApiModelProperty(example = "Doğum günün kutlu olsun.", value = "Hediye notu.")
  public String getGiftNote() {
    return giftNote;
  }

  public void setGiftNote(String giftNote) {
    this.giftNote = giftNote;
  }

  public Order memberGroupName(String memberGroupName) {
    this.memberGroupName = memberGroupName;
    return this;
  }

   /**
   * Üye grubu adı.
   * @return memberGroupName
  **/
  @ApiModelProperty(example = "Üyeliksiz alışveriş", value = "Üye grubu adı.")
  public String getMemberGroupName() {
    return memberGroupName;
  }

  public void setMemberGroupName(String memberGroupName) {
    this.memberGroupName = memberGroupName;
  }

  public Order usePromotion(UsePromotionEnum usePromotion) {
    this.usePromotion = usePromotion;
    return this;
  }

   /**
   * Promosyon kullanılma durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Promosyon kullan&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Promosyon kullanma&lt;br&gt;&lt;/div&gt;
   * @return usePromotion
  **/
  @ApiModelProperty(example = "0", value = "Promosyon kullanılma durumu.<div class='idea_choice_list'><code>1</code> : Promosyon kullan<br><code>0</code> : Promosyon kullanma<br></div>")
  public UsePromotionEnum getUsePromotion() {
    return usePromotion;
  }

  public void setUsePromotion(UsePromotionEnum usePromotion) {
    this.usePromotion = usePromotion;
  }

  public Order shippingProviderCode(String shippingProviderCode) {
    this.shippingProviderCode = shippingProviderCode;
    return this;
  }

   /**
   * Siparişin teslimat hizmeti sağlayıcısı kodu. Ön tanımlıdır. API otomatik oluşturur.
   * @return shippingProviderCode
  **/
  @ApiModelProperty(example = "idea", value = "Siparişin teslimat hizmeti sağlayıcısı kodu. Ön tanımlıdır. API otomatik oluşturur.")
  public String getShippingProviderCode() {
    return shippingProviderCode;
  }

  public void setShippingProviderCode(String shippingProviderCode) {
    this.shippingProviderCode = shippingProviderCode;
  }

  public Order shippingProviderName(String shippingProviderName) {
    this.shippingProviderName = shippingProviderName;
    return this;
  }

   /**
   * Siparişin teslimat hizmeti sağlayıcısı adı. Ön tanımlıdır.
   * @return shippingProviderName
  **/
  @ApiModelProperty(example = "Idea Cargo", value = "Siparişin teslimat hizmeti sağlayıcısı adı. Ön tanımlıdır.")
  public String getShippingProviderName() {
    return shippingProviderName;
  }

  public void setShippingProviderName(String shippingProviderName) {
    this.shippingProviderName = shippingProviderName;
  }

  public Order shippingCompanyName(String shippingCompanyName) {
    this.shippingCompanyName = shippingCompanyName;
    return this;
  }

   /**
   * Siparişin kargo firması adı. Ön tanımlıdır.
   * @return shippingCompanyName
  **/
  @ApiModelProperty(example = "Idea Cargo", value = "Siparişin kargo firması adı. Ön tanımlıdır.")
  public String getShippingCompanyName() {
    return shippingCompanyName;
  }

  public void setShippingCompanyName(String shippingCompanyName) {
    this.shippingCompanyName = shippingCompanyName;
  }

  public Order shippingPaymentType(ShippingPaymentTypeEnum shippingPaymentType) {
    this.shippingPaymentType = shippingPaymentType;
    return this;
  }

   /**
   * Siparişin kargo ödeme tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı Ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici Ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için geçerli değil.&lt;br&gt;&lt;/div&gt;
   * @return shippingPaymentType
  **/
  @ApiModelProperty(example = "standart_delivery", value = "Siparişin kargo ödeme tipi.<div class='idea_choice_list'><code>cash_on_delivery</code> : Alıcı Ödemeli<br><code>standart_delivery</code> : Gönderici Ödemeli<br><code>not_applicable</code> : Bu alan için geçerli değil.<br></div>")
  public ShippingPaymentTypeEnum getShippingPaymentType() {
    return shippingPaymentType;
  }

  public void setShippingPaymentType(ShippingPaymentTypeEnum shippingPaymentType) {
    this.shippingPaymentType = shippingPaymentType;
  }

  public Order shippingTrackingCode(String shippingTrackingCode) {
    this.shippingTrackingCode = shippingTrackingCode;
    return this;
  }

   /**
   * Siparişin kargo takip kodu.
   * @return shippingTrackingCode
  **/
  @ApiModelProperty(example = "123123IDEA", value = "Siparişin kargo takip kodu.")
  public String getShippingTrackingCode() {
    return shippingTrackingCode;
  }

  public void setShippingTrackingCode(String shippingTrackingCode) {
    this.shippingTrackingCode = shippingTrackingCode;
  }

  public Order source(String source) {
    this.source = source;
    return this;
  }

   /**
   * Siparişin kaynak bilgisi. Siparişin kaynak yazılımını belirtir.
   * @return source
  **/
  @ApiModelProperty(example = "IdeaShop Payment", required = true, value = "Siparişin kaynak bilgisi. Siparişin kaynak yazılımını belirtir.")
  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

   /**
   * Sipariş nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Sipariş nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

   /**
   * Sipariş nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Sipariş nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public Order maillist(Maillist maillist) {
    this.maillist = maillist;
    return this;
  }

   /**
   * Get maillist
   * @return maillist
  **/
  @ApiModelProperty(value = "")
  public Maillist getMaillist() {
    return maillist;
  }

  public void setMaillist(Maillist maillist) {
    this.maillist = maillist;
  }

  public Order member(Member member) {
    this.member = member;
    return this;
  }

   /**
   * Get member
   * @return member
  **/
  @ApiModelProperty(value = "")
  public Member getMember() {
    return member;
  }

  public void setMember(Member member) {
    this.member = member;
  }

  public Order orderDetails(List<OrderDetail> orderDetails) {
    this.orderDetails = orderDetails;
    return this;
  }

  public Order addOrderDetailsItem(OrderDetail orderDetailsItem) {
    if (this.orderDetails == null) {
      this.orderDetails = new ArrayList<OrderDetail>();
    }
    this.orderDetails.add(orderDetailsItem);
    return this;
  }

   /**
   * Sipariş detayları.
   * @return orderDetails
  **/
  @ApiModelProperty(value = "Sipariş detayları.")
  public List<OrderDetail> getOrderDetails() {
    return orderDetails;
  }

  public void setOrderDetails(List<OrderDetail> orderDetails) {
    this.orderDetails = orderDetails;
  }

  public Order orderItems(List<OrderItem> orderItems) {
    this.orderItems = orderItems;
    return this;
  }

  public Order addOrderItemsItem(OrderItem orderItemsItem) {
    if (this.orderItems == null) {
      this.orderItems = new ArrayList<OrderItem>();
    }
    this.orderItems.add(orderItemsItem);
    return this;
  }

   /**
   * Sipariş kalemleri.
   * @return orderItems
  **/
  @ApiModelProperty(value = "Sipariş kalemleri.")
  public List<OrderItem> getOrderItems() {
    return orderItems;
  }

  public void setOrderItems(List<OrderItem> orderItems) {
    this.orderItems = orderItems;
  }

  public Order shippingAddress(ShippingAddress shippingAddress) {
    this.shippingAddress = shippingAddress;
    return this;
  }

   /**
   * Get shippingAddress
   * @return shippingAddress
  **/
  @ApiModelProperty(value = "")
  public ShippingAddress getShippingAddress() {
    return shippingAddress;
  }

  public void setShippingAddress(ShippingAddress shippingAddress) {
    this.shippingAddress = shippingAddress;
  }

  public Order billingAddress(BillingAddress billingAddress) {
    this.billingAddress = billingAddress;
    return this;
  }

   /**
   * Get billingAddress
   * @return billingAddress
  **/
  @ApiModelProperty(value = "")
  public BillingAddress getBillingAddress() {
    return billingAddress;
  }

  public void setBillingAddress(BillingAddress billingAddress) {
    this.billingAddress = billingAddress;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Order order = (Order) o;
    return Objects.equals(this.id, order.id) &&
        Objects.equals(this.customerFirstname, order.customerFirstname) &&
        Objects.equals(this.customerSurname, order.customerSurname) &&
        Objects.equals(this.customerEmail, order.customerEmail) &&
        Objects.equals(this.customerPhone, order.customerPhone) &&
        Objects.equals(this.paymentTypeName, order.paymentTypeName) &&
        Objects.equals(this.paymentProviderCode, order.paymentProviderCode) &&
        Objects.equals(this.paymentProviderName, order.paymentProviderName) &&
        Objects.equals(this.paymentGatewayCode, order.paymentGatewayCode) &&
        Objects.equals(this.paymentGatewayName, order.paymentGatewayName) &&
        Objects.equals(this.bankName, order.bankName) &&
        Objects.equals(this.clientIp, order.clientIp) &&
        Objects.equals(this.userAgent, order.userAgent) &&
        Objects.equals(this.currency, order.currency) &&
        Objects.equals(this.currencyRates, order.currencyRates) &&
        Objects.equals(this.amount, order.amount) &&
        Objects.equals(this.couponDiscount, order.couponDiscount) &&
        Objects.equals(this.taxAmount, order.taxAmount) &&
        Objects.equals(this.promotionDiscount, order.promotionDiscount) &&
        Objects.equals(this.generalAmount, order.generalAmount) &&
        Objects.equals(this.shippingAmount, order.shippingAmount) &&
        Objects.equals(this.additionalServiceAmount, order.additionalServiceAmount) &&
        Objects.equals(this.finalAmount, order.finalAmount) &&
        Objects.equals(this.sumOfGainedPoints, order.sumOfGainedPoints) &&
        Objects.equals(this.installment, order.installment) &&
        Objects.equals(this.installmentRate, order.installmentRate) &&
        Objects.equals(this.extraInstallment, order.extraInstallment) &&
        Objects.equals(this.transactionId, order.transactionId) &&
        Objects.equals(this.hasUserNote, order.hasUserNote) &&
        Objects.equals(this.status, order.status) &&
        Objects.equals(this.paymentStatus, order.paymentStatus) &&
        Objects.equals(this.errorMessage, order.errorMessage) &&
        Objects.equals(this.deviceType, order.deviceType) &&
        Objects.equals(this.referrer, order.referrer) &&
        Objects.equals(this.invoicePrintCount, order.invoicePrintCount) &&
        Objects.equals(this.useGiftPackage, order.useGiftPackage) &&
        Objects.equals(this.giftNote, order.giftNote) &&
        Objects.equals(this.memberGroupName, order.memberGroupName) &&
        Objects.equals(this.usePromotion, order.usePromotion) &&
        Objects.equals(this.shippingProviderCode, order.shippingProviderCode) &&
        Objects.equals(this.shippingProviderName, order.shippingProviderName) &&
        Objects.equals(this.shippingCompanyName, order.shippingCompanyName) &&
        Objects.equals(this.shippingPaymentType, order.shippingPaymentType) &&
        Objects.equals(this.shippingTrackingCode, order.shippingTrackingCode) &&
        Objects.equals(this.source, order.source) &&
        Objects.equals(this.createdAt, order.createdAt) &&
        Objects.equals(this.updatedAt, order.updatedAt) &&
        Objects.equals(this.maillist, order.maillist) &&
        Objects.equals(this.member, order.member) &&
        Objects.equals(this.orderDetails, order.orderDetails) &&
        Objects.equals(this.orderItems, order.orderItems) &&
        Objects.equals(this.shippingAddress, order.shippingAddress) &&
        Objects.equals(this.billingAddress, order.billingAddress);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, customerFirstname, customerSurname, customerEmail, customerPhone, paymentTypeName, paymentProviderCode, paymentProviderName, paymentGatewayCode, paymentGatewayName, bankName, clientIp, userAgent, currency, currencyRates, amount, couponDiscount, taxAmount, promotionDiscount, generalAmount, shippingAmount, additionalServiceAmount, finalAmount, sumOfGainedPoints, installment, installmentRate, extraInstallment, transactionId, hasUserNote, status, paymentStatus, errorMessage, deviceType, referrer, invoicePrintCount, useGiftPackage, giftNote, memberGroupName, usePromotion, shippingProviderCode, shippingProviderName, shippingCompanyName, shippingPaymentType, shippingTrackingCode, source, createdAt, updatedAt, maillist, member, orderDetails, orderItems, shippingAddress, billingAddress);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Order {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    customerFirstname: ").append(toIndentedString(customerFirstname)).append("\n");
    sb.append("    customerSurname: ").append(toIndentedString(customerSurname)).append("\n");
    sb.append("    customerEmail: ").append(toIndentedString(customerEmail)).append("\n");
    sb.append("    customerPhone: ").append(toIndentedString(customerPhone)).append("\n");
    sb.append("    paymentTypeName: ").append(toIndentedString(paymentTypeName)).append("\n");
    sb.append("    paymentProviderCode: ").append(toIndentedString(paymentProviderCode)).append("\n");
    sb.append("    paymentProviderName: ").append(toIndentedString(paymentProviderName)).append("\n");
    sb.append("    paymentGatewayCode: ").append(toIndentedString(paymentGatewayCode)).append("\n");
    sb.append("    paymentGatewayName: ").append(toIndentedString(paymentGatewayName)).append("\n");
    sb.append("    bankName: ").append(toIndentedString(bankName)).append("\n");
    sb.append("    clientIp: ").append(toIndentedString(clientIp)).append("\n");
    sb.append("    userAgent: ").append(toIndentedString(userAgent)).append("\n");
    sb.append("    currency: ").append(toIndentedString(currency)).append("\n");
    sb.append("    currencyRates: ").append(toIndentedString(currencyRates)).append("\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    couponDiscount: ").append(toIndentedString(couponDiscount)).append("\n");
    sb.append("    taxAmount: ").append(toIndentedString(taxAmount)).append("\n");
    sb.append("    promotionDiscount: ").append(toIndentedString(promotionDiscount)).append("\n");
    sb.append("    generalAmount: ").append(toIndentedString(generalAmount)).append("\n");
    sb.append("    shippingAmount: ").append(toIndentedString(shippingAmount)).append("\n");
    sb.append("    additionalServiceAmount: ").append(toIndentedString(additionalServiceAmount)).append("\n");
    sb.append("    finalAmount: ").append(toIndentedString(finalAmount)).append("\n");
    sb.append("    sumOfGainedPoints: ").append(toIndentedString(sumOfGainedPoints)).append("\n");
    sb.append("    installment: ").append(toIndentedString(installment)).append("\n");
    sb.append("    installmentRate: ").append(toIndentedString(installmentRate)).append("\n");
    sb.append("    extraInstallment: ").append(toIndentedString(extraInstallment)).append("\n");
    sb.append("    transactionId: ").append(toIndentedString(transactionId)).append("\n");
    sb.append("    hasUserNote: ").append(toIndentedString(hasUserNote)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    paymentStatus: ").append(toIndentedString(paymentStatus)).append("\n");
    sb.append("    errorMessage: ").append(toIndentedString(errorMessage)).append("\n");
    sb.append("    deviceType: ").append(toIndentedString(deviceType)).append("\n");
    sb.append("    referrer: ").append(toIndentedString(referrer)).append("\n");
    sb.append("    invoicePrintCount: ").append(toIndentedString(invoicePrintCount)).append("\n");
    sb.append("    useGiftPackage: ").append(toIndentedString(useGiftPackage)).append("\n");
    sb.append("    giftNote: ").append(toIndentedString(giftNote)).append("\n");
    sb.append("    memberGroupName: ").append(toIndentedString(memberGroupName)).append("\n");
    sb.append("    usePromotion: ").append(toIndentedString(usePromotion)).append("\n");
    sb.append("    shippingProviderCode: ").append(toIndentedString(shippingProviderCode)).append("\n");
    sb.append("    shippingProviderName: ").append(toIndentedString(shippingProviderName)).append("\n");
    sb.append("    shippingCompanyName: ").append(toIndentedString(shippingCompanyName)).append("\n");
    sb.append("    shippingPaymentType: ").append(toIndentedString(shippingPaymentType)).append("\n");
    sb.append("    shippingTrackingCode: ").append(toIndentedString(shippingTrackingCode)).append("\n");
    sb.append("    source: ").append(toIndentedString(source)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    maillist: ").append(toIndentedString(maillist)).append("\n");
    sb.append("    member: ").append(toIndentedString(member)).append("\n");
    sb.append("    orderDetails: ").append(toIndentedString(orderDetails)).append("\n");
    sb.append("    orderItems: ").append(toIndentedString(orderItems)).append("\n");
    sb.append("    shippingAddress: ").append(toIndentedString(shippingAddress)).append("\n");
    sb.append("    billingAddress: ").append(toIndentedString(billingAddress)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

