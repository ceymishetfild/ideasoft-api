package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.IOException;
import org.threeten.bp.OffsetDateTime;

/**
 * Brand
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class Brand {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("name")
  private String name = null;

  @SerializedName("slug")
  private String slug = null;

  @SerializedName("sortOrder")
  private Integer sortOrder = null;

  /**
   * Marka nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    _0("0"),
    
    _1("1");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  @SerializedName("distributor")
  private String distributor = null;

  @SerializedName("imageFile")
  private String imageFile = null;

  @SerializedName("showcaseContent")
  private String showcaseContent = null;

  /**
   * Marka nesnesi üst içerik metninin gösterim durumu.
   */
  @JsonAdapter(DisplayShowcaseContentEnum.Adapter.class)
  public enum DisplayShowcaseContentEnum {
    _0("0"),
    
    _1("1");

    private String value;

    DisplayShowcaseContentEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static DisplayShowcaseContentEnum fromValue(String text) {
      for (DisplayShowcaseContentEnum b : DisplayShowcaseContentEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<DisplayShowcaseContentEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final DisplayShowcaseContentEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public DisplayShowcaseContentEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return DisplayShowcaseContentEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("displayShowcaseContent")
  private DisplayShowcaseContentEnum displayShowcaseContent = null;

  @SerializedName("metaKeywords")
  private String metaKeywords = null;

  @SerializedName("metaDescription")
  private String metaDescription = null;

  @SerializedName("pageTitle")
  private String pageTitle = null;

  @SerializedName("attachment")
  private String attachment = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("updatedAt")
  private OffsetDateTime updatedAt = null;

  public Brand id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Marka nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Marka nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Brand name(String name) {
    this.name = name;
    return this;
  }

   /**
   * Marka nesnesi için isim değeri.
   * @return name
  **/
  @ApiModelProperty(example = "Idea Kalem", required = true, value = "Marka nesnesi için isim değeri.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Brand slug(String slug) {
    this.slug = slug;
    return this;
  }

   /**
   * Slug değeri ilgili nesnenin Url değeridir.
   * @return slug
  **/
  @ApiModelProperty(example = "idea-kalem", value = "Slug değeri ilgili nesnenin Url değeridir.")
  public String getSlug() {
    return slug;
  }

  public void setSlug(String slug) {
    this.slug = slug;
  }

  public Brand sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

   /**
   * Marka nesnesi için sıralama değeri.
   * minimum: 0
   * maximum: 999
   * @return sortOrder
  **/
  @ApiModelProperty(example = "999", value = "Marka nesnesi için sıralama değeri.")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public Brand status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Marka nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @ApiModelProperty(example = "1", required = true, value = "Marka nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Brand distributor(String distributor) {
    this.distributor = distributor;
    return this;
  }

   /**
   * Markanın tedarikçisi.
   * @return distributor
  **/
  @ApiModelProperty(example = "Super Tedarik", value = "Markanın tedarikçisi.")
  public String getDistributor() {
    return distributor;
  }

  public void setDistributor(String distributor) {
    this.distributor = distributor;
  }

  public Brand imageFile(String imageFile) {
    this.imageFile = imageFile;
    return this;
  }

   /**
   * Marka nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF
   * @return imageFile
  **/
  @ApiModelProperty(example = "kalem.jpg", value = "Marka nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF")
  public String getImageFile() {
    return imageFile;
  }

  public void setImageFile(String imageFile) {
    this.imageFile = imageFile;
  }

  public Brand showcaseContent(String showcaseContent) {
    this.showcaseContent = showcaseContent;
    return this;
  }

   /**
   * Marka nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir.
   * @return showcaseContent
  **/
  @ApiModelProperty(example = "Üst içerik metni.", value = "Marka nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir.")
  public String getShowcaseContent() {
    return showcaseContent;
  }

  public void setShowcaseContent(String showcaseContent) {
    this.showcaseContent = showcaseContent;
  }

  public Brand displayShowcaseContent(DisplayShowcaseContentEnum displayShowcaseContent) {
    this.displayShowcaseContent = displayShowcaseContent;
    return this;
  }

   /**
   * Marka nesnesi üst içerik metninin gösterim durumu.
   * @return displayShowcaseContent
  **/
  @ApiModelProperty(example = "1", value = "Marka nesnesi üst içerik metninin gösterim durumu.")
  public DisplayShowcaseContentEnum getDisplayShowcaseContent() {
    return displayShowcaseContent;
  }

  public void setDisplayShowcaseContent(DisplayShowcaseContentEnum displayShowcaseContent) {
    this.displayShowcaseContent = displayShowcaseContent;
  }

  public Brand metaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
    return this;
  }

   /**
   * Arama motorları tarafından tespit edilebilecek anahtar kelimeler.
   * @return metaKeywords
  **/
  @ApiModelProperty(example = "kırmızı, kalem, kırtasiye", value = "Arama motorları tarafından tespit edilebilecek anahtar kelimeler.")
  public String getMetaKeywords() {
    return metaKeywords;
  }

  public void setMetaKeywords(String metaKeywords) {
    this.metaKeywords = metaKeywords;
  }

  public Brand metaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
    return this;
  }

   /**
   * Arama motorları tarafından tespit edilebilecek açıklama yazısı.
   * @return metaDescription
  **/
  @ApiModelProperty(example = "Kaliteli kırtasiye ürünleri.", value = "Arama motorları tarafından tespit edilebilecek açıklama yazısı.")
  public String getMetaDescription() {
    return metaDescription;
  }

  public void setMetaDescription(String metaDescription) {
    this.metaDescription = metaDescription;
  }

  public Brand pageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
    return this;
  }

   /**
   * Marka nesnesinin etiket başlığı.
   * @return pageTitle
  **/
  @ApiModelProperty(example = "Kırmızı Kalem", value = "Marka nesnesinin etiket başlığı.")
  public String getPageTitle() {
    return pageTitle;
  }

  public void setPageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
  }

  public Brand attachment(String attachment) {
    this.attachment = attachment;
    return this;
  }

   /**
   * Marka nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
   * @return attachment
  **/
  @ApiModelProperty(example = "Buraya example gelecek.", value = "Marka nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.")
  public String getAttachment() {
    return attachment;
  }

  public void setAttachment(String attachment) {
    this.attachment = attachment;
  }

   /**
   * Marka nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Marka nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

   /**
   * Marka nesnesinin güncellenme zamanı.
   * @return updatedAt
  **/
  @ApiModelProperty(example = "2018-02-21T15:01:03+0300", value = "Marka nesnesinin güncellenme zamanı.")
  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Brand brand = (Brand) o;
    return Objects.equals(this.id, brand.id) &&
        Objects.equals(this.name, brand.name) &&
        Objects.equals(this.slug, brand.slug) &&
        Objects.equals(this.sortOrder, brand.sortOrder) &&
        Objects.equals(this.status, brand.status) &&
        Objects.equals(this.distributor, brand.distributor) &&
        Objects.equals(this.imageFile, brand.imageFile) &&
        Objects.equals(this.showcaseContent, brand.showcaseContent) &&
        Objects.equals(this.displayShowcaseContent, brand.displayShowcaseContent) &&
        Objects.equals(this.metaKeywords, brand.metaKeywords) &&
        Objects.equals(this.metaDescription, brand.metaDescription) &&
        Objects.equals(this.pageTitle, brand.pageTitle) &&
        Objects.equals(this.attachment, brand.attachment) &&
        Objects.equals(this.createdAt, brand.createdAt) &&
        Objects.equals(this.updatedAt, brand.updatedAt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, slug, sortOrder, status, distributor, imageFile, showcaseContent, displayShowcaseContent, metaKeywords, metaDescription, pageTitle, attachment, createdAt, updatedAt);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Brand {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    slug: ").append(toIndentedString(slug)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    distributor: ").append(toIndentedString(distributor)).append("\n");
    sb.append("    imageFile: ").append(toIndentedString(imageFile)).append("\n");
    sb.append("    showcaseContent: ").append(toIndentedString(showcaseContent)).append("\n");
    sb.append("    displayShowcaseContent: ").append(toIndentedString(displayShowcaseContent)).append("\n");
    sb.append("    metaKeywords: ").append(toIndentedString(metaKeywords)).append("\n");
    sb.append("    metaDescription: ").append(toIndentedString(metaDescription)).append("\n");
    sb.append("    pageTitle: ").append(toIndentedString(pageTitle)).append("\n");
    sb.append("    attachment: ").append(toIndentedString(attachment)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

