package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Order;
import java.io.IOException;

/**
 * OrderDetail
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class OrderDetail {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("varKey")
  private String varKey = null;

  @SerializedName("varValue")
  private String varValue = null;

  @SerializedName("order")
  private Order order = null;

  public OrderDetail id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Sipariş detayı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Sipariş detayı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public OrderDetail varKey(String varKey) {
    this.varKey = varKey;
    return this;
  }

   /**
   * Sipariş detayı nesnesi için değişken anahtarı.
   * @return varKey
  **/
  @ApiModelProperty(example = "bank_account_detail", required = true, value = "Sipariş detayı nesnesi için değişken anahtarı.")
  public String getVarKey() {
    return varKey;
  }

  public void setVarKey(String varKey) {
    this.varKey = varKey;
  }

  public OrderDetail varValue(String varValue) {
    this.varValue = varValue;
    return this;
  }

   /**
   * Sipariş detayı nesnesi için değişken değeri.
   * @return varValue
  **/
  @ApiModelProperty(example = "{\"branch_name\":\"Tuzla/İstanbul\",\"branch_code\":\"238\",\"account_name\":\"IdeaSoft Kurumsal\",\"account_code\":\"123123\",\"account_type\":\"Kurumsal\",\"uses_iban\":\"0\"}", required = true, value = "Sipariş detayı nesnesi için değişken değeri.")
  public String getVarValue() {
    return varValue;
  }

  public void setVarValue(String varValue) {
    this.varValue = varValue;
  }

  public OrderDetail order(Order order) {
    this.order = order;
    return this;
  }

   /**
   * Get order
   * @return order
  **/
  @ApiModelProperty(value = "")
  public Order getOrder() {
    return order;
  }

  public void setOrder(Order order) {
    this.order = order;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrderDetail orderDetail = (OrderDetail) o;
    return Objects.equals(this.id, orderDetail.id) &&
        Objects.equals(this.varKey, orderDetail.varKey) &&
        Objects.equals(this.varValue, orderDetail.varValue) &&
        Objects.equals(this.order, orderDetail.order);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, varKey, varValue, order);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderDetail {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    varKey: ").append(toIndentedString(varKey)).append("\n");
    sb.append("    varValue: ").append(toIndentedString(varValue)).append("\n");
    sb.append("    order: ").append(toIndentedString(order)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

