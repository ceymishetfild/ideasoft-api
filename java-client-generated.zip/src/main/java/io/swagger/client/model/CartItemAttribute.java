package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.CartItem;
import java.io.IOException;
import org.threeten.bp.OffsetDateTime;

/**
 * CartItemAttribute
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class CartItemAttribute {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("name")
  private String name = null;

  @SerializedName("value")
  private String value = null;

  @SerializedName("createdAt")
  private OffsetDateTime createdAt = null;

  @SerializedName("cartItem")
  private CartItem cartItem = null;

  public CartItemAttribute id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Sepet kalemi özelliği nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Sepet kalemi özelliği nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public CartItemAttribute name(String name) {
    this.name = name;
    return this;
  }

   /**
   * Sepet kalemi özelliği nesnesinin isim değeri. Örneğin, sepet kalemi kalem ise bu değer renk olabilir.
   * @return name
  **/
  @ApiModelProperty(example = "Renk", value = "Sepet kalemi özelliği nesnesinin isim değeri. Örneğin, sepet kalemi kalem ise bu değer renk olabilir.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public CartItemAttribute value(String value) {
    this.value = value;
    return this;
  }

   /**
   * Sepet kalemi özelliği nesnesinin değeri. Örneğin, sepet kalemi kalem, isim değeri renk ise bu değer kırmızı olabilir.
   * @return value
  **/
  @ApiModelProperty(example = "Kırmızı", value = "Sepet kalemi özelliği nesnesinin değeri. Örneğin, sepet kalemi kalem, isim değeri renk ise bu değer kırmızı olabilir.")
  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

   /**
   * Sepet kalemi özelliği nesnesinin oluşturulma zamanı.
   * @return createdAt
  **/
  @ApiModelProperty(example = "2018-02-21T09:36:03+0300", value = "Sepet kalemi özelliği nesnesinin oluşturulma zamanı.")
  public OffsetDateTime getCreatedAt() {
    return createdAt;
  }

  public CartItemAttribute cartItem(CartItem cartItem) {
    this.cartItem = cartItem;
    return this;
  }

   /**
   * Get cartItem
   * @return cartItem
  **/
  @ApiModelProperty(value = "")
  public CartItem getCartItem() {
    return cartItem;
  }

  public void setCartItem(CartItem cartItem) {
    this.cartItem = cartItem;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CartItemAttribute cartItemAttribute = (CartItemAttribute) o;
    return Objects.equals(this.id, cartItemAttribute.id) &&
        Objects.equals(this.name, cartItemAttribute.name) &&
        Objects.equals(this.value, cartItemAttribute.value) &&
        Objects.equals(this.createdAt, cartItemAttribute.createdAt) &&
        Objects.equals(this.cartItem, cartItemAttribute.cartItem);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, value, createdAt, cartItem);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CartItemAttribute {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    value: ").append(toIndentedString(value)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    cartItem: ").append(toIndentedString(cartItem)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

