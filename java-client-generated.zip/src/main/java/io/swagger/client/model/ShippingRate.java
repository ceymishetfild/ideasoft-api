package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.Region;
import io.swagger.client.model.ShippingCompany;
import java.io.IOException;

/**
 * ShippingRate
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ShippingRate {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("volumetricWeightStart")
  private Integer volumetricWeightStart = null;

  @SerializedName("volumetricWeightEnd")
  private Integer volumetricWeightEnd = null;

  @SerializedName("rate")
  private Float rate = null;

  @SerializedName("region")
  private Region region = null;

  @SerializedName("shippingCompany")
  private ShippingCompany shippingCompany = null;

  public ShippingRate id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Kargo oranı nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Kargo oranı nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ShippingRate volumetricWeightStart(Integer volumetricWeightStart) {
    this.volumetricWeightStart = volumetricWeightStart;
    return this;
  }

   /**
   * İlgili kargo firması, ilgili bölge ve ilgili orana ait minimum desi değeri.
   * @return volumetricWeightStart
  **/
  @ApiModelProperty(example = "0", required = true, value = "İlgili kargo firması, ilgili bölge ve ilgili orana ait minimum desi değeri.")
  public Integer getVolumetricWeightStart() {
    return volumetricWeightStart;
  }

  public void setVolumetricWeightStart(Integer volumetricWeightStart) {
    this.volumetricWeightStart = volumetricWeightStart;
  }

  public ShippingRate volumetricWeightEnd(Integer volumetricWeightEnd) {
    this.volumetricWeightEnd = volumetricWeightEnd;
    return this;
  }

   /**
   * İlgili kargo firması, ilgili bölge ve ilgili orana ait maximum desi değeri.
   * @return volumetricWeightEnd
  **/
  @ApiModelProperty(example = "1", required = true, value = "İlgili kargo firması, ilgili bölge ve ilgili orana ait maximum desi değeri.")
  public Integer getVolumetricWeightEnd() {
    return volumetricWeightEnd;
  }

  public void setVolumetricWeightEnd(Integer volumetricWeightEnd) {
    this.volumetricWeightEnd = volumetricWeightEnd;
  }

  public ShippingRate rate(Float rate) {
    this.rate = rate;
    return this;
  }

   /**
   * Seçili bölge ve kargo firması için kargo oranı.
   * minimum: 0
   * @return rate
  **/
  @ApiModelProperty(example = "1.0", required = true, value = "Seçili bölge ve kargo firması için kargo oranı.")
  public Float getRate() {
    return rate;
  }

  public void setRate(Float rate) {
    this.rate = rate;
  }

  public ShippingRate region(Region region) {
    this.region = region;
    return this;
  }

   /**
   * Get region
   * @return region
  **/
  @ApiModelProperty(value = "")
  public Region getRegion() {
    return region;
  }

  public void setRegion(Region region) {
    this.region = region;
  }

  public ShippingRate shippingCompany(ShippingCompany shippingCompany) {
    this.shippingCompany = shippingCompany;
    return this;
  }

   /**
   * Get shippingCompany
   * @return shippingCompany
  **/
  @ApiModelProperty(value = "")
  public ShippingCompany getShippingCompany() {
    return shippingCompany;
  }

  public void setShippingCompany(ShippingCompany shippingCompany) {
    this.shippingCompany = shippingCompany;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShippingRate shippingRate = (ShippingRate) o;
    return Objects.equals(this.id, shippingRate.id) &&
        Objects.equals(this.volumetricWeightStart, shippingRate.volumetricWeightStart) &&
        Objects.equals(this.volumetricWeightEnd, shippingRate.volumetricWeightEnd) &&
        Objects.equals(this.rate, shippingRate.rate) &&
        Objects.equals(this.region, shippingRate.region) &&
        Objects.equals(this.shippingCompany, shippingRate.shippingCompany);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, volumetricWeightStart, volumetricWeightEnd, rate, region, shippingCompany);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShippingRate {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    volumetricWeightStart: ").append(toIndentedString(volumetricWeightStart)).append("\n");
    sb.append("    volumetricWeightEnd: ").append(toIndentedString(volumetricWeightEnd)).append("\n");
    sb.append("    rate: ").append(toIndentedString(rate)).append("\n");
    sb.append("    region: ").append(toIndentedString(region)).append("\n");
    sb.append("    shippingCompany: ").append(toIndentedString(shippingCompany)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

