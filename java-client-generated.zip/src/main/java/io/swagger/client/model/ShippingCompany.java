package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.ShippingProvider;
import java.io.IOException;

/**
 * ShippingCompany
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2018-06-07T09:33:52.729Z")
public class ShippingCompany {
  @SerializedName("id")
  private Integer id = null;

  @SerializedName("name")
  private String name = null;

  /**
   * Kargo firması nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;active&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(StatusEnum.Adapter.class)
  public enum StatusEnum {
    ACTIVE("active"),
    
    PASSIVE("passive");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<StatusEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final StatusEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public StatusEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return StatusEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("status")
  private StatusEnum status = null;

  @SerializedName("extraPrice")
  private Float extraPrice = null;

  @SerializedName("extraVolumetricWeightPrice")
  private Float extraVolumetricWeightPrice = null;

  @SerializedName("freeShipmentOrderPrice")
  private Float freeShipmentOrderPrice = null;

  @SerializedName("freeShipmentVolumetricWeightLimit")
  private Float freeShipmentVolumetricWeightLimit = null;

  @SerializedName("sortOrder")
  private Integer sortOrder = null;

  @SerializedName("companyCode")
  private String companyCode = null;

  /**
   * Kargo firması için ödeme tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli.&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli.&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil.&lt;br&gt;&lt;/div&gt;
   */
  @JsonAdapter(PaymentTypeEnum.Adapter.class)
  public enum PaymentTypeEnum {
    CASH_ON_DELIVERY("cash_on_delivery"),
    
    STANDART_DELIVERY("standart_delivery"),
    
    NOT_APPLICABLE("not_applicable");

    private String value;

    PaymentTypeEnum(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    public static PaymentTypeEnum fromValue(String text) {
      for (PaymentTypeEnum b : PaymentTypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }

    public static class Adapter extends TypeAdapter<PaymentTypeEnum> {
      @Override
      public void write(final JsonWriter jsonWriter, final PaymentTypeEnum enumeration) throws IOException {
        jsonWriter.value(enumeration.getValue());
      }

      @Override
      public PaymentTypeEnum read(final JsonReader jsonReader) throws IOException {
        String value = jsonReader.nextString();
        return PaymentTypeEnum.fromValue(String.valueOf(value));
      }
    }
  }

  @SerializedName("paymentType")
  private PaymentTypeEnum paymentType = null;

  @SerializedName("shippingProvider")
  private ShippingProvider shippingProvider = null;

  public ShippingCompany id(Integer id) {
    this.id = id;
    return this;
  }

   /**
   * Kargo firması nesnesi kimlik değeri.
   * @return id
  **/
  @ApiModelProperty(example = "123", value = "Kargo firması nesnesi kimlik değeri.")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public ShippingCompany name(String name) {
    this.name = name;
    return this;
  }

   /**
   * Kargo firması nesnesi için isim değeri.
   * @return name
  **/
  @ApiModelProperty(example = "Idea Cargo", required = true, value = "Kargo firması nesnesi için isim değeri.")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public ShippingCompany status(StatusEnum status) {
    this.status = status;
    return this;
  }

   /**
   * Kargo firması nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;active&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt;
   * @return status
  **/
  @ApiModelProperty(example = "active", required = true, value = "Kargo firması nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>active</code> : Aktif.<br><code>passive</code> : Pasif.<br></div>")
  public StatusEnum getStatus() {
    return status;
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public ShippingCompany extraPrice(Float extraPrice) {
    this.extraPrice = extraPrice;
    return this;
  }

   /**
   * Kargo firması için sabit ücret. Sabit bir kargo ücreti uygulayacaksanız her sipariş için sabit kargo ücreti girebilirsiniz. Desi bilgilerini kaydetmeniz durumunda desi toplamlarının üzerine sabit ücret eklenecektir.
   * minimum: 0
   * @return extraPrice
  **/
  @ApiModelProperty(example = "5.0", value = "Kargo firması için sabit ücret. Sabit bir kargo ücreti uygulayacaksanız her sipariş için sabit kargo ücreti girebilirsiniz. Desi bilgilerini kaydetmeniz durumunda desi toplamlarının üzerine sabit ücret eklenecektir.")
  public Float getExtraPrice() {
    return extraPrice;
  }

  public void setExtraPrice(Float extraPrice) {
    this.extraPrice = extraPrice;
  }

  public ShippingCompany extraVolumetricWeightPrice(Float extraVolumetricWeightPrice) {
    this.extraVolumetricWeightPrice = extraVolumetricWeightPrice;
    return this;
  }

   /**
   * Kargo firması için girmiş olduğunuz desi bilgileri 50 Desiye kadar girilebilmektedir. 50&#39;nin üzeri veya girmiş olduğunuz desi miktarının üzerine her +1 desi için eklenecek olan kargo ücreti.
   * minimum: 0
   * @return extraVolumetricWeightPrice
  **/
  @ApiModelProperty(example = "10.0", value = "Kargo firması için girmiş olduğunuz desi bilgileri 50 Desiye kadar girilebilmektedir. 50'nin üzeri veya girmiş olduğunuz desi miktarının üzerine her +1 desi için eklenecek olan kargo ücreti.")
  public Float getExtraVolumetricWeightPrice() {
    return extraVolumetricWeightPrice;
  }

  public void setExtraVolumetricWeightPrice(Float extraVolumetricWeightPrice) {
    this.extraVolumetricWeightPrice = extraVolumetricWeightPrice;
  }

  public ShippingCompany freeShipmentOrderPrice(Float freeShipmentOrderPrice) {
    this.freeShipmentOrderPrice = freeShipmentOrderPrice;
    return this;
  }

   /**
   * Alışveriş sepeti toplamı belirlediğiniz Ücretsiz kargo limitini geçtiğinde müşterileriniz ücretsiz kargo hizmetinden faydalanabilirler.(Örn: X Lira üzeri ücretsiz Kargo!)
   * minimum: 0
   * @return freeShipmentOrderPrice
  **/
  @ApiModelProperty(example = "100.0", value = "Alışveriş sepeti toplamı belirlediğiniz Ücretsiz kargo limitini geçtiğinde müşterileriniz ücretsiz kargo hizmetinden faydalanabilirler.(Örn: X Lira üzeri ücretsiz Kargo!)")
  public Float getFreeShipmentOrderPrice() {
    return freeShipmentOrderPrice;
  }

  public void setFreeShipmentOrderPrice(Float freeShipmentOrderPrice) {
    this.freeShipmentOrderPrice = freeShipmentOrderPrice;
  }

  public ShippingCompany freeShipmentVolumetricWeightLimit(Float freeShipmentVolumetricWeightLimit) {
    this.freeShipmentVolumetricWeightLimit = freeShipmentVolumetricWeightLimit;
    return this;
  }

   /**
   * Ücretsiz kargo miktarı için maksimum ücretsiz desi miktarıdır. Alışveriş sırasındaki desi miktarı ücretsiz desi miktarından fazlaysa, + Desi miktarını sipariş sırasında sistem müşteriden tahsil eder.(Örn: X TL üzeri ücretsiz kargo! Fakat X desiye kadar)Üzeri müşteriden tahsil edilir.
   * minimum: 0
   * @return freeShipmentVolumetricWeightLimit
  **/
  @ApiModelProperty(example = "1.0", value = "Ücretsiz kargo miktarı için maksimum ücretsiz desi miktarıdır. Alışveriş sırasındaki desi miktarı ücretsiz desi miktarından fazlaysa, + Desi miktarını sipariş sırasında sistem müşteriden tahsil eder.(Örn: X TL üzeri ücretsiz kargo! Fakat X desiye kadar)Üzeri müşteriden tahsil edilir.")
  public Float getFreeShipmentVolumetricWeightLimit() {
    return freeShipmentVolumetricWeightLimit;
  }

  public void setFreeShipmentVolumetricWeightLimit(Float freeShipmentVolumetricWeightLimit) {
    this.freeShipmentVolumetricWeightLimit = freeShipmentVolumetricWeightLimit;
  }

  public ShippingCompany sortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
    return this;
  }

   /**
   * Kargo firması nesnesi için sıralama değeri.
   * minimum: 0
   * @return sortOrder
  **/
  @ApiModelProperty(example = "999", value = "Kargo firması nesnesi için sıralama değeri.")
  public Integer getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }

  public ShippingCompany companyCode(String companyCode) {
    this.companyCode = companyCode;
    return this;
  }

   /**
   * API tarafından otomatik oluşturulan kargo firması kodu.
   * @return companyCode
  **/
  @ApiModelProperty(example = "CMP12KD", value = "API tarafından otomatik oluşturulan kargo firması kodu.")
  public String getCompanyCode() {
    return companyCode;
  }

  public void setCompanyCode(String companyCode) {
    this.companyCode = companyCode;
  }

  public ShippingCompany paymentType(PaymentTypeEnum paymentType) {
    this.paymentType = paymentType;
    return this;
  }

   /**
   * Kargo firması için ödeme tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli.&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli.&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil.&lt;br&gt;&lt;/div&gt;
   * @return paymentType
  **/
  @ApiModelProperty(example = "standart_delivery", value = "Kargo firması için ödeme tipi.<div class='idea_choice_list'><code>cash_on_delivery</code> : Alıcı ödemeli.<br><code>standart_delivery</code> : Gönderici ödemeli.<br><code>not_applicable</code> : Bu alan için uygulanabilir değil.<br></div>")
  public PaymentTypeEnum getPaymentType() {
    return paymentType;
  }

  public void setPaymentType(PaymentTypeEnum paymentType) {
    this.paymentType = paymentType;
  }

  public ShippingCompany shippingProvider(ShippingProvider shippingProvider) {
    this.shippingProvider = shippingProvider;
    return this;
  }

   /**
   * Get shippingProvider
   * @return shippingProvider
  **/
  @ApiModelProperty(value = "")
  public ShippingProvider getShippingProvider() {
    return shippingProvider;
  }

  public void setShippingProvider(ShippingProvider shippingProvider) {
    this.shippingProvider = shippingProvider;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShippingCompany shippingCompany = (ShippingCompany) o;
    return Objects.equals(this.id, shippingCompany.id) &&
        Objects.equals(this.name, shippingCompany.name) &&
        Objects.equals(this.status, shippingCompany.status) &&
        Objects.equals(this.extraPrice, shippingCompany.extraPrice) &&
        Objects.equals(this.extraVolumetricWeightPrice, shippingCompany.extraVolumetricWeightPrice) &&
        Objects.equals(this.freeShipmentOrderPrice, shippingCompany.freeShipmentOrderPrice) &&
        Objects.equals(this.freeShipmentVolumetricWeightLimit, shippingCompany.freeShipmentVolumetricWeightLimit) &&
        Objects.equals(this.sortOrder, shippingCompany.sortOrder) &&
        Objects.equals(this.companyCode, shippingCompany.companyCode) &&
        Objects.equals(this.paymentType, shippingCompany.paymentType) &&
        Objects.equals(this.shippingProvider, shippingCompany.shippingProvider);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, status, extraPrice, extraVolumetricWeightPrice, freeShipmentOrderPrice, freeShipmentVolumetricWeightLimit, sortOrder, companyCode, paymentType, shippingProvider);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShippingCompany {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    extraPrice: ").append(toIndentedString(extraPrice)).append("\n");
    sb.append("    extraVolumetricWeightPrice: ").append(toIndentedString(extraVolumetricWeightPrice)).append("\n");
    sb.append("    freeShipmentOrderPrice: ").append(toIndentedString(freeShipmentOrderPrice)).append("\n");
    sb.append("    freeShipmentVolumetricWeightLimit: ").append(toIndentedString(freeShipmentVolumetricWeightLimit)).append("\n");
    sb.append("    sortOrder: ").append(toIndentedString(sortOrder)).append("\n");
    sb.append("    companyCode: ").append(toIndentedString(companyCode)).append("\n");
    sb.append("    paymentType: ").append(toIndentedString(paymentType)).append("\n");
    sb.append("    shippingProvider: ").append(toIndentedString(shippingProvider)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}

