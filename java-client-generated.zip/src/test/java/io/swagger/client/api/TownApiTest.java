package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.Town;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for TownApi
 */
@Ignore
public class TownApiTest {

    private final TownApi api = new TownApi();

    
    /**
     * İlçe Listesi Alma
     *
     * İlçe listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void townsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer location = null;
        Integer townGroup = null;
        String name = null;
        String status = null;
        Town response = api.townsGet(sort, limit, page, sinceId, location, townGroup, name, status);

        // TODO: test validations
    }
    
    /**
     * İlçe Silme
     *
     * Kalıcı olarak ilgili İlçeyi siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void townsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.townsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * İlçe Alma
     *
     * İlgili İlçeyi getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void townsIdGetTest() throws ApiException {
        Integer id = null;
        Town response = api.townsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * İlçe Güncelleme
     *
     * İlgili İlçeyi günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void townsIdPutTest() throws ApiException {
        Integer id = null;
        Town town = null;
        Town response = api.townsIdPut(id, town);

        // TODO: test validations
    }
    
    /**
     * İlçe Oluşturma
     *
     * Yeni bir İlçe oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void townsPostTest() throws ApiException {
        Town town = null;
        Town response = api.townsPost(town);

        // TODO: test validations
    }
    
}
