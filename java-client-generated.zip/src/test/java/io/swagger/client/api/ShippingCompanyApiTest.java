package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.ShippingCompany;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ShippingCompanyApi
 */
@Ignore
public class ShippingCompanyApiTest {

    private final ShippingCompanyApi api = new ShippingCompanyApi();

    
    /**
     * Kargo Firması Listesi Alma
     *
     * Kargo Firması listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingCompaniesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        String companyCode = null;
        String paymentType = null;
        Integer shippingProvider = null;
        ShippingCompany response = api.shippingCompaniesGet(sort, limit, page, sinceId, name, companyCode, paymentType, shippingProvider);

        // TODO: test validations
    }
    
    /**
     * Kargo Firması Silme
     *
     * Kalıcı olarak ilgili Kargo Firmasını siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingCompaniesIdDeleteTest() throws ApiException {
        Integer id = null;
        api.shippingCompaniesIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Kargo Firması Alma
     *
     * İlgili Kargo Firmasını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingCompaniesIdGetTest() throws ApiException {
        Integer id = null;
        ShippingCompany response = api.shippingCompaniesIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Kargo Firması Güncelleme
     *
     * İlgili Kargo Firmasını günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingCompaniesIdPutTest() throws ApiException {
        Integer id = null;
        ShippingCompany shippingCompany = null;
        ShippingCompany response = api.shippingCompaniesIdPut(id, shippingCompany);

        // TODO: test validations
    }
    
    /**
     * Kargo Firması Oluşturma
     *
     * Yeni bir Kargo Firması oluşturur relationship.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingCompaniesPostTest() throws ApiException {
        ShippingCompany shippingCompany = null;
        ShippingCompany response = api.shippingCompaniesPost(shippingCompany);

        // TODO: test validations
    }
    
}
