package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Category;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for CategoryApi
 */
@Ignore
public class CategoryApiTest {

    private final CategoryApi api = new CategoryApi();

    
    /**
     * Kategori Listesi Alma
     *
     * Kategori listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void categoriesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        Integer status = null;
        String distributor = null;
        Integer parent = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        Category response = api.categoriesGet(sort, limit, page, sinceId, name, status, distributor, parent, startDate, endDate, startUpdatedAt, endUpdatedAt);

        // TODO: test validations
    }
    
    /**
     * Kategori Silme
     *
     * Kalıcı olarak ilgili Kategoriyi siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void categoriesIdDeleteTest() throws ApiException {
        Integer id = null;
        api.categoriesIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Kategori Alma
     *
     * İlgili Kategoriyi getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void categoriesIdGetTest() throws ApiException {
        Integer id = null;
        Category response = api.categoriesIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Kategori Güncelleme
     *
     * İlgili Kategoriyi günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void categoriesIdPutTest() throws ApiException {
        Integer id = null;
        Category category = null;
        Category response = api.categoriesIdPut(id, category);

        // TODO: test validations
    }
    
    /**
     * Kategori Oluşturma
     *
     * Yeni bir Kategori oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void categoriesPostTest() throws ApiException {
        Category category = null;
        Category response = api.categoriesPost(category);

        // TODO: test validations
    }
    
}
