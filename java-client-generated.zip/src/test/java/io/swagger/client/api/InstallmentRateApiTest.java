package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.InstallmentRate;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for InstallmentRateApi
 */
@Ignore
public class InstallmentRateApiTest {

    private final InstallmentRateApi api = new InstallmentRateApi();

    
    /**
     * Taksit Oranı Listesi Alma
     *
     * Taksit Oranı listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void installmentRatesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer paymentGateway = null;
        InstallmentRate response = api.installmentRatesGet(sort, limit, page, sinceId, paymentGateway);

        // TODO: test validations
    }
    
    /**
     * Taksit Oranı Alma
     *
     * İlgili Taksit Oranını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void installmentRatesIdGetTest() throws ApiException {
        Integer id = null;
        InstallmentRate response = api.installmentRatesIdGet(id);

        // TODO: test validations
    }
    
}
