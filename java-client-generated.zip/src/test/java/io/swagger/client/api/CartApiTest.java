package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Cart;
import io.swagger.client.model.Error;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for CartApi
 */
@Ignore
public class CartApiTest {

    private final CartApi api = new CartApi();

    
    /**
     * Sepet Silme
     *
     * Kalıcı olarak ilgili Sepeti siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void cartsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.cartsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Sepet Alma
     *
     * İlgili Sepet getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void cartsIdGetTest() throws ApiException {
        Integer id = null;
        Cart response = api.cartsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Sepet Oluşturma
     *
     * Yeni bir Sepet oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void cartsPostTest() throws ApiException {
        Cart cart = null;
        Cart response = api.cartsPost(cart);

        // TODO: test validations
    }
    
}
