package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.ProductProtection;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ProductProtectionApi
 */
@Ignore
public class ProductProtectionApiTest {

    private final ProductProtectionApi api = new ProductProtectionApi();

    
    /**
     * Entegrasyon Seçeneği Listesi Alma
     *
     * Entegrasyon Seçeneği listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productProtectionsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer isPriceProtected = null;
        Integer isStockProtected = null;
        Integer product = null;
        ProductProtection response = api.productProtectionsGet(sort, limit, page, sinceId, isPriceProtected, isStockProtected, product);

        // TODO: test validations
    }
    
    /**
     * Entegrasyon Seçeneği Silme
     *
     * Kalıcı olarak ilgili Entegrasyon Seçeneğini siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productProtectionsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.productProtectionsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Entegrasyon Seçeneği Alma
     *
     * İlgili Entegrasyon Seçeneğini getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productProtectionsIdGetTest() throws ApiException {
        Integer id = null;
        ProductProtection response = api.productProtectionsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Entegrasyon Seçeneği Güncelleme
     *
     * İlgili Entegrasyon Seçeneğini günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productProtectionsIdPutTest() throws ApiException {
        Integer id = null;
        ProductProtection productProtection = null;
        ProductProtection response = api.productProtectionsIdPut(id, productProtection);

        // TODO: test validations
    }
    
    /**
     * Entegrasyon Seçeneği Oluşturma
     *
     * Yeni bir Entegrasyon Seçeneği oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productProtectionsPostTest() throws ApiException {
        ProductProtection productProtection = null;
        ProductProtection response = api.productProtectionsPost(productProtection);

        // TODO: test validations
    }
    
}
