package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.FavouritedProduct;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for FavouritedProductApi
 */
@Ignore
public class FavouritedProductApiTest {

    private final FavouritedProductApi api = new FavouritedProductApi();

    
    /**
     * Favori Ürün Listesi Alma
     *
     * Favori Ürün listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void favouritedProductsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer product = null;
        FavouritedProduct response = api.favouritedProductsGet(sort, limit, page, sinceId, product);

        // TODO: test validations
    }
    
    /**
     * Favori Ürün Silme
     *
     * Kalıcı olarak ilgili Favori Ürünü siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void favouritedProductsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.favouritedProductsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Favori Ürün Alma
     *
     * İlgili Favori Ürünü getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void favouritedProductsIdGetTest() throws ApiException {
        Integer id = null;
        FavouritedProduct response = api.favouritedProductsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Favori Ürün Güncelleme
     *
     * İlgili Favori Ürünü günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void favouritedProductsIdPutTest() throws ApiException {
        Integer id = null;
        FavouritedProduct favouritedProduct = null;
        FavouritedProduct response = api.favouritedProductsIdPut(id, favouritedProduct);

        // TODO: test validations
    }
    
    /**
     * Favori Ürün Oluşturma
     *
     * Yeni bir Favori Ürün oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void favouritedProductsPostTest() throws ApiException {
        FavouritedProduct favouritedProduct = null;
        FavouritedProduct response = api.favouritedProductsPost(favouritedProduct);

        // TODO: test validations
    }
    
}
