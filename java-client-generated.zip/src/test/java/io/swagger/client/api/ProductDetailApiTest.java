package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.ProductDetail;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ProductDetailApi
 */
@Ignore
public class ProductDetailApiTest {

    private final ProductDetailApi api = new ProductDetailApi();

    
    /**
     * Ürün Detay Listesi Alma
     *
     * Ürün Detay listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productDetailsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String sku = null;
        ProductDetail response = api.productDetailsGet(sort, limit, page, sinceId, sku);

        // TODO: test validations
    }
    
    /**
     * Ürün Detay Silme
     *
     * Kalıcı olarak ilgili Ürün Detayını siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productDetailsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.productDetailsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Detay Alma
     *
     * İlgili Ürün Detayını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productDetailsIdGetTest() throws ApiException {
        Integer id = null;
        ProductDetail response = api.productDetailsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Detay Güncelleme
     *
     * İlgili Ürün Detayını günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productDetailsIdPutTest() throws ApiException {
        Integer id = null;
        ProductDetail productDetail = null;
        ProductDetail response = api.productDetailsIdPut(id, productDetail);

        // TODO: test validations
    }
    
    /**
     * Ürün Detay Oluşturma
     *
     * Yeni bir Ürün Detay oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productDetailsPostTest() throws ApiException {
        ProductDetail productDetail = null;
        ProductDetail response = api.productDetailsPost(productDetail);

        // TODO: test validations
    }
    
}
