package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.Region;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for RegionApi
 */
@Ignore
public class RegionApiTest {

    private final RegionApi api = new RegionApi();

    
    /**
     * Bölge Listesi Alma
     *
     * Bölge listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void regionsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        Region response = api.regionsGet(sort, limit, page, sinceId, name);

        // TODO: test validations
    }
    
    /**
     * Bölge Alma
     *
     * İlgili Bölgeyi getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void regionsIdGetTest() throws ApiException {
        Integer id = null;
        Region response = api.regionsIdGet(id);

        // TODO: test validations
    }
    
}
