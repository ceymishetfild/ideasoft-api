package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.SelectionGroup;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for SelectionGroupApi
 */
@Ignore
public class SelectionGroupApiTest {

    private final SelectionGroupApi api = new SelectionGroupApi();

    
    /**
     * Ek Özellik Grubu Listesi Alma
     *
     * Ek Özellik Grubu listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void selectionGroupsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String title = null;
        SelectionGroup response = api.selectionGroupsGet(sort, limit, page, sinceId, title);

        // TODO: test validations
    }
    
    /**
     * Ek Özellik Grubu Silme
     *
     * Kalıcı olarak ilgili Ek Özellik Grubunu siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void selectionGroupsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.selectionGroupsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ek Özellik Grubu Alma
     *
     * İlgili Ek Özellik Grubunu getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void selectionGroupsIdGetTest() throws ApiException {
        Integer id = null;
        SelectionGroup response = api.selectionGroupsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ek Özellik Grubu Güncelleme
     *
     * İlgili Ek Özellik Grubunu günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void selectionGroupsIdPutTest() throws ApiException {
        Integer id = null;
        SelectionGroup selectionGroup = null;
        SelectionGroup response = api.selectionGroupsIdPut(id, selectionGroup);

        // TODO: test validations
    }
    
    /**
     * Ek Özellik Grubu Oluşturma
     *
     * Yeni bir Ek Özellik Grubu oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void selectionGroupsPostTest() throws ApiException {
        SelectionGroup selectionGroup = null;
        SelectionGroup response = api.selectionGroupsPost(selectionGroup);

        // TODO: test validations
    }
    
}
