package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.Tag;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for TagApi
 */
@Ignore
public class TagApiTest {

    private final TagApi api = new TagApi();

    
    /**
     * SEO+ Etiketi Listesi Alma
     *
     * SEO+ Etiketi listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void tagsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        Tag response = api.tagsGet(sort, limit, page, sinceId, name);

        // TODO: test validations
    }
    
    /**
     * SEO+ Etiketi Silme
     *
     * Kalıcı olarak ilgili SEO+ Etiketini siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void tagsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.tagsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * SEO+ Etiketi Alma
     *
     * İlgili SEO+ Etiketini getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void tagsIdGetTest() throws ApiException {
        Integer id = null;
        Tag response = api.tagsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * SEO+ Etiketi Güncelleme
     *
     * İlgili SEO+ Etiketini günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void tagsIdPutTest() throws ApiException {
        Integer id = null;
        Tag tag = null;
        Tag response = api.tagsIdPut(id, tag);

        // TODO: test validations
    }
    
    /**
     * SEO+ Etiketi Oluşturma
     *
     * Yeni bir SEO+ Etiketi oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void tagsPostTest() throws ApiException {
        Tag tag = null;
        Tag response = api.tagsPost(tag);

        // TODO: test validations
    }
    
}
