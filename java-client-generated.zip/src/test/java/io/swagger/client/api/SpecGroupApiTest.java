package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.SpecGroup;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for SpecGroupApi
 */
@Ignore
public class SpecGroupApiTest {

    private final SpecGroupApi api = new SpecGroupApi();

    
    /**
     * Ürün Özellik Grubu Listesi Alma
     *
     * Ürün Özellik Grubu listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specGroupsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        SpecGroup response = api.specGroupsGet(sort, limit, page, sinceId, name);

        // TODO: test validations
    }
    
    /**
     * Ürün Özellik Grubu Silme
     *
     * Kalıcı olarak ilgili Ürün Özellik Grubunu siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specGroupsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.specGroupsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Özellik Grubu Alma
     *
     * İlgili Ürün Özellik Grubunu getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specGroupsIdGetTest() throws ApiException {
        Integer id = null;
        SpecGroup response = api.specGroupsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Özellik Grubu Güncelleme
     *
     * İlgili Ürün Özellik Grubunu günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specGroupsIdPutTest() throws ApiException {
        Integer id = null;
        SpecGroup specGroup = null;
        SpecGroup response = api.specGroupsIdPut(id, specGroup);

        // TODO: test validations
    }
    
    /**
     * Ürün Özellik Grubu Oluşturma
     *
     * Yeni bir Ürün Özellik Grubu oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specGroupsPostTest() throws ApiException {
        SpecGroup specGroup = null;
        SpecGroup response = api.specGroupsPost(specGroup);

        // TODO: test validations
    }
    
}
