package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.Maillist;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for MaillistApi
 */
@Ignore
public class MaillistApiTest {

    private final MaillistApi api = new MaillistApi();

    
    /**
     * Mail Listesi Listesi Alma
     *
     * Mail Listesi listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void maillistsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        String email = null;
        Integer maillistGroup = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        Maillist response = api.maillistsGet(sort, limit, page, sinceId, name, email, maillistGroup, startDate, endDate, startUpdatedAt, endUpdatedAt);

        // TODO: test validations
    }
    
    /**
     * Mail Listesi Silme
     *
     * Kalıcı olarak ilgili Mail Listesini siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void maillistsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.maillistsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Mail Listesi Alma
     *
     * İlgili Mail Listesini getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void maillistsIdGetTest() throws ApiException {
        Integer id = null;
        Maillist response = api.maillistsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Mail Listesi Güncelleme
     *
     * İlgili Mail Listesini günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void maillistsIdPutTest() throws ApiException {
        Integer id = null;
        Maillist maillist = null;
        Maillist response = api.maillistsIdPut(id, maillist);

        // TODO: test validations
    }
    
    /**
     * Mail Listesi Oluşturma
     *
     * Yeni bir Mail Listesini oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void maillistsPostTest() throws ApiException {
        Maillist maillist = null;
        Maillist response = api.maillistsPost(maillist);

        // TODO: test validations
    }
    
}
