package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.OrderUserNote;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for OrderUserNoteApi
 */
@Ignore
public class OrderUserNoteApiTest {

    private final OrderUserNoteApi api = new OrderUserNoteApi();

    
    /**
     * Sipariş Yönetici Notu Listesi Alma
     *
     * Sipariş Yönetici Notu listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderUserNotesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer order = null;
        String userEmail = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        OrderUserNote response = api.orderUserNotesGet(sort, limit, page, sinceId, order, userEmail, startDate, endDate, startUpdatedAt, endUpdatedAt);

        // TODO: test validations
    }
    
    /**
     * Sipariş Yönetici Notu Silme
     *
     * Kalıcı olarak ilgili Sipariş Yönetici Notunu siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderUserNotesIdDeleteTest() throws ApiException {
        Integer id = null;
        api.orderUserNotesIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Sipariş Yönetici Notu Alma
     *
     * İlgili Sipariş Yönetici Notunu getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderUserNotesIdGetTest() throws ApiException {
        Integer id = null;
        OrderUserNote response = api.orderUserNotesIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Sipariş Yönetici Notu Güncelleme
     *
     * İlgili Sipariş Yönetici Notunu günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderUserNotesIdPutTest() throws ApiException {
        Integer id = null;
        OrderUserNote orderUserNote = null;
        OrderUserNote response = api.orderUserNotesIdPut(id, orderUserNote);

        // TODO: test validations
    }
    
    /**
     * Sipariş Yönetici Notu Oluşturma
     *
     * Yeni bir Sipariş Yönetici Notu oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderUserNotesPostTest() throws ApiException {
        OrderUserNote orderUserNote = null;
        OrderUserNote response = api.orderUserNotesPost(orderUserNote);

        // TODO: test validations
    }
    
}
