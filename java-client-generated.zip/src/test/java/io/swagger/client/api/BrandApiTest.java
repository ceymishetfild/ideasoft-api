package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Brand;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for BrandApi
 */
@Ignore
public class BrandApiTest {

    private final BrandApi api = new BrandApi();

    
    /**
     * Marka Listesi Alma
     *
     * Marka listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void brandsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        Integer status = null;
        String distributor = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        List<String> q = null;
        Brand response = api.brandsGet(sort, limit, page, sinceId, name, status, distributor, startDate, endDate, startUpdatedAt, endUpdatedAt, q);

        // TODO: test validations
    }
    
    /**
     * Marka Silme
     *
     * Kalıcı olarak ilgili Markayı siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void brandsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.brandsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Marka Alma
     *
     * İlgili Markayı getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void brandsIdGetTest() throws ApiException {
        Integer id = null;
        Brand response = api.brandsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Marka Güncelleme
     *
     * İlgili Markayı günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void brandsIdPutTest() throws ApiException {
        Integer id = null;
        Brand brand = null;
        Brand response = api.brandsIdPut(id, brand);

        // TODO: test validations
    }
    
    /**
     * Marka Oluşturma
     *
     * Yeni bir Marka oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void brandsPostTest() throws ApiException {
        Brand brand = null;
        Brand response = api.brandsPost(brand);

        // TODO: test validations
    }
    
}
