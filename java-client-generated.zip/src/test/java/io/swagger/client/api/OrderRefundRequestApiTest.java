package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.OrderRefundRequest;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for OrderRefundRequestApi
 */
@Ignore
public class OrderRefundRequestApiTest {

    private final OrderRefundRequestApi api = new OrderRefundRequestApi();

    
    /**
     * Sipariş İptal Talebi Listesi Alma
     *
     * Sipariş İptal Talebi listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderRefundRequestsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer order = null;
        Integer member = null;
        String code = null;
        String status = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        OrderRefundRequest response = api.orderRefundRequestsGet(sort, limit, page, sinceId, order, member, code, status, startDate, endDate, startUpdatedAt, endUpdatedAt);

        // TODO: test validations
    }
    
    /**
     * Sipariş İptal Talebi Silme
     *
     * Kalıcı olarak ilgili Sipariş İptal Talebini siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderRefundRequestsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.orderRefundRequestsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Sipariş İptal Talebi Alma
     *
     * İlgili Sipariş İptal Talebini getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderRefundRequestsIdGetTest() throws ApiException {
        Integer id = null;
        OrderRefundRequest response = api.orderRefundRequestsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Sipariş İptal Talebi Güncelleme
     *
     * İlgili Sipariş İptal Talebini günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderRefundRequestsIdPutTest() throws ApiException {
        Integer id = null;
        OrderRefundRequest orderRefundRequest = null;
        OrderRefundRequest response = api.orderRefundRequestsIdPut(id, orderRefundRequest);

        // TODO: test validations
    }
    
    /**
     * Sipariş İptal Talebi Oluşturma
     *
     * Yeni bir Sipariş İptal Talebi oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderRefundRequestsPostTest() throws ApiException {
        OrderRefundRequest orderRefundRequest = null;
        OrderRefundRequest response = api.orderRefundRequestsPost(orderRefundRequest);

        // TODO: test validations
    }
    
}
