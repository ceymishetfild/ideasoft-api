package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.ProductImage;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ProductImageApi
 */
@Ignore
public class ProductImageApiTest {

    private final ProductImageApi api = new ProductImageApi();

    
    /**
     * Ürün Resim Listesi Alma
     *
     * Ürün Resim listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productImagesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String fileName = null;
        Integer product = null;
        ProductImage response = api.productImagesGet(sort, limit, page, sinceId, fileName, product);

        // TODO: test validations
    }
    
    /**
     * Ürün Resim Silme
     *
     * Kalıcı olarak ilgili Ürün Resmini siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productImagesIdDeleteTest() throws ApiException {
        Integer id = null;
        api.productImagesIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Resim Alma
     *
     * İlgili Ürün Resmini getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productImagesIdGetTest() throws ApiException {
        Integer id = null;
        ProductImage response = api.productImagesIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Resim Oluşturma
     *
     * Yeni bir Ürün Resim oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productImagesPostTest() throws ApiException {
        ProductImage productImage = null;
        ProductImage response = api.productImagesPost(productImage);

        // TODO: test validations
    }
    
}
