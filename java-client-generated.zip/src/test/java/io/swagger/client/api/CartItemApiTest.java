package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.CartItem;
import io.swagger.client.model.Error;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for CartItemApi
 */
@Ignore
public class CartItemApiTest {

    private final CartItemApi api = new CartItemApi();

    
    /**
     * Sepet Kalemi Silme
     *
     * Kalıcı olarak ilgili Sepet Kalemini siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void cartItemsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.cartItemsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Sepet Kalemi Güncelleme
     *
     * İlgili Sepet Kalemini günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void cartItemsIdPutTest() throws ApiException {
        Integer id = null;
        CartItem response = api.cartItemsIdPut(id);

        // TODO: test validations
    }
    
    /**
     * Sepet Kalemi Oluşturma
     *
     * Yeni bir Sepet Kalemi oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void cartItemsPostTest() throws ApiException {
        CartItem cartItem = null;
        CartItem response = api.cartItemsPost(cartItem);

        // TODO: test validations
    }
    
}
