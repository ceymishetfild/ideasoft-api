package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.OrderDetail;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for OrderDetailApi
 */
@Ignore
public class OrderDetailApiTest {

    private final OrderDetailApi api = new OrderDetailApi();

    
    /**
     * Sipariş Detayı Listesi Alma
     *
     * Sipariş Detayı listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderDetailsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer order = null;
        OrderDetail response = api.orderDetailsGet(sort, limit, page, sinceId, order);

        // TODO: test validations
    }
    
    /**
     * Sipariş Detayı Silme
     *
     * Kalıcı olarak ilgili Sipariş Detayı siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderDetailsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.orderDetailsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Sipariş Detayı Alma
     *
     * İlgili Sipariş Detayı getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderDetailsIdGetTest() throws ApiException {
        Integer id = null;
        OrderDetail response = api.orderDetailsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Sipariş Detayı Güncelleme
     *
     * İlgili Sipariş Detayı günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderDetailsIdPutTest() throws ApiException {
        Integer id = null;
        OrderDetail orderDetail = null;
        OrderDetail response = api.orderDetailsIdPut(id, orderDetail);

        // TODO: test validations
    }
    
    /**
     * Sipariş Detayı Oluşturma
     *
     * Yeni bir Sipariş Detayı oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderDetailsPostTest() throws ApiException {
        OrderDetail orderDetail = null;
        OrderDetail response = api.orderDetailsPost(orderDetail);

        // TODO: test validations
    }
    
}
