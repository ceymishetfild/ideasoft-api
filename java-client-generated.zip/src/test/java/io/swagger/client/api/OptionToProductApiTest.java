package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.OptionToProduct;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for OptionToProductApi
 */
@Ignore
public class OptionToProductApiTest {

    private final OptionToProductApi api = new OptionToProductApi();

    
    /**
     * Varyant Ürün Bağı Listesi Alma
     *
     * Varyant Ürün Bağı listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void optionToProductsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer product = null;
        Integer optionGroup = null;
        Integer option = null;
        Integer parentProductId = null;
        OptionToProduct response = api.optionToProductsGet(sort, limit, page, sinceId, product, optionGroup, option, parentProductId);

        // TODO: test validations
    }
    
    /**
     * Varyant Ürün Bağı Silme
     *
     * Kalıcı olarak ilgili Varyant Ürün Bağını siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void optionToProductsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.optionToProductsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Varyant Ürün Bağı Alma
     *
     * İlgili Varyant Ürün Bağını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void optionToProductsIdGetTest() throws ApiException {
        Integer id = null;
        OptionToProduct response = api.optionToProductsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Varyant Ürün Bağı Güncelleme
     *
     * İlgili Varyant Ürün Bağını günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void optionToProductsIdPutTest() throws ApiException {
        Integer id = null;
        OptionToProduct optionToProduct = null;
        OptionToProduct response = api.optionToProductsIdPut(id, optionToProduct);

        // TODO: test validations
    }
    
    /**
     * Varyant Ürün Bağı Oluşturma
     *
     * Yeni bir Varyant Ürün Bağı oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void optionToProductsPostTest() throws ApiException {
        OptionToProduct optionToProduct = null;
        OptionToProduct response = api.optionToProductsPost(optionToProduct);

        // TODO: test validations
    }
    
}
