package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.ProductSpecialInfo;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ProductSpecialInfoApi
 */
@Ignore
public class ProductSpecialInfoApiTest {

    private final ProductSpecialInfoApi api = new ProductSpecialInfoApi();

    
    /**
     * Ürün Özel Bilgi Alanı Listesi Alma
     *
     * Ürün Özel Bilgi Alanı listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productSpecialInfosGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String title = null;
        Integer status = null;
        Integer product = null;
        ProductSpecialInfo response = api.productSpecialInfosGet(sort, limit, page, sinceId, title, status, product);

        // TODO: test validations
    }
    
    /**
     * Ürün Özel Bilgi Alanı
     *
     * Kalıcı olarak ilgili Ürün Özel Bilgi Alanını siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productSpecialInfosIdDeleteTest() throws ApiException {
        Integer id = null;
        api.productSpecialInfosIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Özel Bilgi Alanı
     *
     * İlgili Ürün Özel Bilgi Alanını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productSpecialInfosIdGetTest() throws ApiException {
        Integer id = null;
        ProductSpecialInfo response = api.productSpecialInfosIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Özel Bilgi Alanı Güncelleme
     *
     * İlgili Ürün Özel Bilgi Alanını günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productSpecialInfosIdPutTest() throws ApiException {
        Integer id = null;
        ProductSpecialInfo productSpecialInfo = null;
        ProductSpecialInfo response = api.productSpecialInfosIdPut(id, productSpecialInfo);

        // TODO: test validations
    }
    
    /**
     * Ürün Özel Bilgi Alanı Oluşturma
     *
     * Yeni bir Ürün Özel Bilgi Alanı oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productSpecialInfosPostTest() throws ApiException {
        ProductSpecialInfo productSpecialInfo = null;
        ProductSpecialInfo response = api.productSpecialInfosPost(productSpecialInfo);

        // TODO: test validations
    }
    
}
