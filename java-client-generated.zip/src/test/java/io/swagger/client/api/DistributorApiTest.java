package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Distributor;
import io.swagger.client.model.Error;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for DistributorApi
 */
@Ignore
public class DistributorApiTest {

    private final DistributorApi api = new DistributorApi();

    
    /**
     * Distribütör Listesi Alma
     *
     * Distribütör listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void distributorsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        String email = null;
        String phone = null;
        String contactPerson = null;
        Distributor response = api.distributorsGet(sort, limit, page, sinceId, name, email, phone, contactPerson);

        // TODO: test validations
    }
    
    /**
     * Distribütör Silme
     *
     * Kalıcı olarak ilgili Distribütörü siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void distributorsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.distributorsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Distribütör Alma
     *
     * İlgili Distribütörü getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void distributorsIdGetTest() throws ApiException {
        Integer id = null;
        Distributor response = api.distributorsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Distribütör Güncelleme
     *
     * İlgili Distribütörü günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void distributorsIdPutTest() throws ApiException {
        Integer id = null;
        Distributor distributor = null;
        Distributor response = api.distributorsIdPut(id, distributor);

        // TODO: test validations
    }
    
    /**
     * Distribütör Oluşturma
     *
     * Yeni bir Distribütör oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void distributorsPostTest() throws ApiException {
        Distributor distributor = null;
        Distributor response = api.distributorsPost(distributor);

        // TODO: test validations
    }
    
}
