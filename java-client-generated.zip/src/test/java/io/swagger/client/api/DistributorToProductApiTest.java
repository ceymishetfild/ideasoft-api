package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.DistributorToProduct;
import io.swagger.client.model.Error;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for DistributorToProductApi
 */
@Ignore
public class DistributorToProductApiTest {

    private final DistributorToProductApi api = new DistributorToProductApi();

    
    /**
     * Distribütör Ürün Bağı Listesi Alma
     *
     * Distribütör Ürün Bağı listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void distributorToProductsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer distributor = null;
        Integer product = null;
        DistributorToProduct response = api.distributorToProductsGet(sort, limit, page, sinceId, distributor, product);

        // TODO: test validations
    }
    
    /**
     * Distribütör Ürün Bağı Silme
     *
     * Kalıcı olarak ilgili Distribütör Ürün Bağını siler
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void distributorToProductsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.distributorToProductsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Distribütör Ürün Bağı Alma
     *
     * İlgili Distribütör Ürün Bağını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void distributorToProductsIdGetTest() throws ApiException {
        Integer id = null;
        DistributorToProduct response = api.distributorToProductsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Distribütör Ürün Bağı Güncelleme
     *
     * İlgili Distribütör Ürün Bağını günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void distributorToProductsIdPutTest() throws ApiException {
        Integer id = null;
        DistributorToProduct distributorToProduct = null;
        DistributorToProduct response = api.distributorToProductsIdPut(id, distributorToProduct);

        // TODO: test validations
    }
    
    /**
     * Distribütör Ürün Bağı Oluşturma
     *
     * Yeni bir Distribütör Ürün Bağı oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void distributorToProductsPostTest() throws ApiException {
        DistributorToProduct distributorToProduct = null;
        DistributorToProduct response = api.distributorToProductsPost(distributorToProduct);

        // TODO: test validations
    }
    
}
