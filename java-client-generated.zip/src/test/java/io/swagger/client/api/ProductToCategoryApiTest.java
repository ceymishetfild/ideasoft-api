package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.ProductToCategory;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ProductToCategoryApi
 */
@Ignore
public class ProductToCategoryApiTest {

    private final ProductToCategoryApi api = new ProductToCategoryApi();

    
    /**
     * Ürün Kategori Bağı Listesi Alma
     *
     * Ürün Kategori Bağı listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productToCategoriesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer product = null;
        Integer category = null;
        ProductToCategory response = api.productToCategoriesGet(sort, limit, page, sinceId, product, category);

        // TODO: test validations
    }
    
    /**
     * Ürün Kategori Bağı Silme
     *
     * Kalıcı olarak ilgili Ürün Kategori Bağını siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productToCategoriesIdDeleteTest() throws ApiException {
        Integer id = null;
        api.productToCategoriesIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Kategori Bağı Alma
     *
     * İlgili Ürün Kategori Bağını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productToCategoriesIdGetTest() throws ApiException {
        Integer id = null;
        ProductToCategory response = api.productToCategoriesIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Kategori Bağı Güncelleme
     *
     * İlgili Ürün Kategori Bağını günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productToCategoriesIdPutTest() throws ApiException {
        Integer id = null;
        ProductToCategory productToCategory = null;
        ProductToCategory response = api.productToCategoriesIdPut(id, productToCategory);

        // TODO: test validations
    }
    
    /**
     * Ürün Kategori Bağı Oluşturma
     *
     * Yeni bir Ürün Kategori Bağı oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productToCategoriesPostTest() throws ApiException {
        ProductToCategory productToCategory = null;
        ProductToCategory response = api.productToCategoriesPost(productToCategory);

        // TODO: test validations
    }
    
}
