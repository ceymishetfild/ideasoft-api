package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.PaymentGateway;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for PaymentGatewayApi
 */
@Ignore
public class PaymentGatewayApiTest {

    private final PaymentGatewayApi api = new PaymentGatewayApi();

    
    /**
     * Ödeme Kanalı Listesi Alma
     *
     * Ödeme Kanalı listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void paymentGatewaysGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String code = null;
        String name = null;
        PaymentGateway response = api.paymentGatewaysGet(sort, limit, page, sinceId, code, name);

        // TODO: test validations
    }
    
    /**
     * Ödeme Kanalı Alma
     *
     * İlgili Ödeme Kanalını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void paymentGatewaysIdGetTest() throws ApiException {
        Integer id = null;
        PaymentGateway response = api.paymentGatewaysIdGet(id);

        // TODO: test validations
    }
    
}
