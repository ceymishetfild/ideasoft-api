package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Currency;
import io.swagger.client.model.Error;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for CurrencyApi
 */
@Ignore
public class CurrencyApiTest {

    private final CurrencyApi api = new CurrencyApi();

    
    /**
     * Kur Listesi Alma
     *
     * Kur listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void currenciesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String label = null;
        String abbr = null;
        Integer status = null;
        Currency response = api.currenciesGet(sort, limit, page, sinceId, label, abbr, status);

        // TODO: test validations
    }
    
    /**
     * Kur Alma
     *
     * İlgili Kur getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void currenciesIdGetTest() throws ApiException {
        Integer id = null;
        Currency response = api.currenciesIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Kur Güncelleme
     *
     * İlgili Kur günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void currenciesIdPutTest() throws ApiException {
        Integer id = null;
        Currency currency = null;
        Currency response = api.currenciesIdPut(id, currency);

        // TODO: test validations
    }
    
}
