package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.MemberGroup;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for MemberGroupApi
 */
@Ignore
public class MemberGroupApiTest {

    private final MemberGroupApi api = new MemberGroupApi();

    
    /**
     * Üye Grubu Listesi Alma
     *
     * Üye Grubu listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void memberGroupsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        MemberGroup response = api.memberGroupsGet(sort, limit, page, sinceId, name);

        // TODO: test validations
    }
    
    /**
     * Üye Grubu Silme
     *
     * Kalıcı olarak ilgili Üye Grubunu siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void memberGroupsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.memberGroupsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Üye Grubu Alma
     *
     * İlgili Üye Grubunu getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void memberGroupsIdGetTest() throws ApiException {
        Integer id = null;
        MemberGroup response = api.memberGroupsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Üye Grubu Güncelleme
     *
     * İlgili Üye Grubunu günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void memberGroupsIdPutTest() throws ApiException {
        Integer id = null;
        MemberGroup memberGroup = null;
        MemberGroup response = api.memberGroupsIdPut(id, memberGroup);

        // TODO: test validations
    }
    
    /**
     * Üye Grubu Oluşturma
     *
     * Yeni bir Üye Grubu oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void memberGroupsPostTest() throws ApiException {
        MemberGroup memberGroup = null;
        MemberGroup response = api.memberGroupsPost(memberGroup);

        // TODO: test validations
    }
    
}
