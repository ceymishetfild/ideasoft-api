package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.QuickCart;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for QuickCartApi
 */
@Ignore
public class QuickCartApiTest {

    private final QuickCartApi api = new QuickCartApi();

    
    /**
     * Hızlı Satın Al Bağlantısı Alma
     *
     * Hızlı Satın Al Bağlantısı döndürür.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void quickCartsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        QuickCart response = api.quickCartsGet(sort, limit, page, sinceId, name);

        // TODO: test validations
    }
    
    /**
     * Hızlı Satın Al Bağlantısı Silme
     *
     * Kalıcı olarak ilgili Hızlı Satın Al Bağlantısını siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void quickCartsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.quickCartsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Hızlı Satın Al Bağlantısı Alma
     *
     * İlgili Hızlı Satın Al Bağlantısını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void quickCartsIdGetTest() throws ApiException {
        Integer id = null;
        QuickCart response = api.quickCartsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Hızlı Satın Al Bağlantısı Güncelleme
     *
     * İlgili Hızlı Satın Al Bağlantısını günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void quickCartsIdPutTest() throws ApiException {
        Integer id = null;
        QuickCart quickCart = null;
        QuickCart response = api.quickCartsIdPut(id, quickCart);

        // TODO: test validations
    }
    
    /**
     * Hızlı Satın Al Bağlantısı Oluşturma
     *
     * Yeni bir Hızlı Satın Al Bağlantısı oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void quickCartsPostTest() throws ApiException {
        QuickCart quickCart = null;
        QuickCart response = api.quickCartsPost(quickCart);

        // TODO: test validations
    }
    
}
