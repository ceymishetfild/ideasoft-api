package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.Payment;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for PaymentApi
 */
@Ignore
public class PaymentApiTest {

    private final PaymentApi api = new PaymentApi();

    
    /**
     * Ödeme Listesi Alma
     *
     * Ödeme listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void paymentsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String transactionId = null;
        String memberEmail = null;
        Integer member = null;
        String status = null;
        String paymentTypeName = null;
        LocalDate startDate = null;
        String endDate = null;
        Payment response = api.paymentsGet(sort, limit, page, sinceId, transactionId, memberEmail, member, status, paymentTypeName, startDate, endDate);

        // TODO: test validations
    }
    
    /**
     * Ödeme Silme
     *
     * Kalıcı olarak ilgili Ödemeyi siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void paymentsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.paymentsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ödeme Alma
     *
     * İlgili Ödemeyi getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void paymentsIdGetTest() throws ApiException {
        Integer id = null;
        Payment response = api.paymentsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ödeme Güncelleme
     *
     * İlgili Ödemeyi günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void paymentsIdPutTest() throws ApiException {
        Integer id = null;
        Payment payment = null;
        Payment response = api.paymentsIdPut(id, payment);

        // TODO: test validations
    }
    
    /**
     * Ödeme Oluşturma
     *
     * Yeni bir Ödeme oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void paymentsPostTest() throws ApiException {
        Payment payment = null;
        Payment response = api.paymentsPost(payment);

        // TODO: test validations
    }
    
}
