package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.Selection;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for SelectionApi
 */
@Ignore
public class SelectionApiTest {

    private final SelectionApi api = new SelectionApi();

    
    /**
     * Ek Özellik Listesi Alma
     *
     * Ek Özellik listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void selectionsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String title = null;
        Integer selectionGroup = null;
        Selection response = api.selectionsGet(sort, limit, page, sinceId, title, selectionGroup);

        // TODO: test validations
    }
    
    /**
     * Ek Özellik Silme
     *
     * Kalıcı olarak ilgili Ek Özelliği siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void selectionsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.selectionsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ek Özellik Alma
     *
     * İlgili Ek Özelliği getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void selectionsIdGetTest() throws ApiException {
        Integer id = null;
        Selection response = api.selectionsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ek Özellik Güncelleme
     *
     * İlgili Ek Özelliği günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void selectionsIdPutTest() throws ApiException {
        Integer id = null;
        Selection selection = null;
        Selection response = api.selectionsIdPut(id, selection);

        // TODO: test validations
    }
    
    /**
     * Ek Özellik Oluşturma
     *
     * Yeni bir Ek Özellik oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void selectionsPostTest() throws ApiException {
        Selection selection = null;
        Selection response = api.selectionsPost(selection);

        // TODO: test validations
    }
    
}
