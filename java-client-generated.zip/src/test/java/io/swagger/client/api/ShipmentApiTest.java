package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.Shipment;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ShipmentApi
 */
@Ignore
public class ShipmentApiTest {

    private final ShipmentApi api = new ShipmentApi();

    
    /**
     * Teslimat Listesi Alma
     *
     * Teslimat listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shipmentsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String code = null;
        String invoiceKey = null;
        String barcode = null;
        Integer order = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        Shipment response = api.shipmentsGet(sort, limit, page, sinceId, code, invoiceKey, barcode, order, startDate, endDate, startUpdatedAt, endUpdatedAt);

        // TODO: test validations
    }
    
    /**
     * Teslimat Silme
     *
     * Kalıcı olarak ilgili Teslimatı siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shipmentsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.shipmentsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Teslimat Alma
     *
     * İlgili Teslimatı getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shipmentsIdGetTest() throws ApiException {
        Integer id = null;
        Shipment response = api.shipmentsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Teslimat Güncelleme
     *
     * İlgili Teslimatı günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shipmentsIdPutTest() throws ApiException {
        Integer id = null;
        Shipment shipment = null;
        Shipment response = api.shipmentsIdPut(id, shipment);

        // TODO: test validations
    }
    
    /**
     * Teslimat Oluşturma
     *
     * Yeni bir Teslimat oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shipmentsPostTest() throws ApiException {
        Shipment shipment = null;
        Shipment response = api.shipmentsPost(shipment);

        // TODO: test validations
    }
    
}
