package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.Product;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ProductApi
 */
@Ignore
public class ProductApiTest {

    private final ProductApi api = new ProductApi();

    
    /**
     * Ürün Listesi Alma
     *
     * Ürün listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String parent = null;
        Integer brand = null;
        String sku = null;
        String name = null;
        String distributor = null;
        List<String> q = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        Product response = api.productsGet(sort, limit, page, sinceId, parent, brand, sku, name, distributor, q, startDate, endDate, startUpdatedAt, endUpdatedAt);

        // TODO: test validations
    }
    
    /**
     * Ürün Silme
     *
     * Kalıcı olarak ilgili Ürünü siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.productsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Alma
     *
     * İlgili Ürünü getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productsIdGetTest() throws ApiException {
        Integer id = null;
        Product response = api.productsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Güncelleme
     *
     * İlgili Ürünü günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productsIdPutTest() throws ApiException {
        Integer id = null;
        Product product = null;
        Product response = api.productsIdPut(id, product);

        // TODO: test validations
    }
    
    /**
     * Ürün Oluşturma
     *
     * Yeni bir Ürün oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productsPostTest() throws ApiException {
        Product product = null;
        Product response = api.productsPost(product);

        // TODO: test validations
    }
    
}
