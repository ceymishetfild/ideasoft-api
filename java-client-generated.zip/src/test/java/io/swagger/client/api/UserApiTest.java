package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.User;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for UserApi
 */
@Ignore
public class UserApiTest {

    private final UserApi api = new UserApi();

    
    /**
     * Yönetici Listesi Alma
     *
     * Yönetici listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void usersGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String firstname = null;
        String surname = null;
        String email = null;
        String username = null;
        String phoneNumber = null;
        Integer isOwner = null;
        String status = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        User response = api.usersGet(sort, limit, page, sinceId, firstname, surname, email, username, phoneNumber, isOwner, status, startDate, endDate, startUpdatedAt, endUpdatedAt);

        // TODO: test validations
    }
    
    /**
     * Yönetici Alma
     *
     * İlgili Yöneticiyi  getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void usersIdGetTest() throws ApiException {
        Integer id = null;
        User response = api.usersIdGet(id);

        // TODO: test validations
    }
    
}
