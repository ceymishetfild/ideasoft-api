package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.ShippingProvider;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ShippingProviderApi
 */
@Ignore
public class ShippingProviderApiTest {

    private final ShippingProviderApi api = new ShippingProviderApi();

    
    /**
     * Teslimat Hizmeti Sağlayıcısı Listesi Alma
     *
     * Teslimat Hizmeti Sağlayıcısı listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingProvidersGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String code = null;
        String name = null;
        ShippingProvider response = api.shippingProvidersGet(sort, limit, page, sinceId, code, name);

        // TODO: test validations
    }
    
    /**
     * Teslimat Hizmeti Sağlayıcısı Alma
     *
     * İlgili Teslimat Hizmeti Sağlayıcısını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingProvidersIdGetTest() throws ApiException {
        Integer id = null;
        ShippingProvider response = api.shippingProvidersIdGet(id);

        // TODO: test validations
    }
    
}
