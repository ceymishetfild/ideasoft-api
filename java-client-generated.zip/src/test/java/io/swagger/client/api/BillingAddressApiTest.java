package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.BillingAddress;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for BillingAddressApi
 */
@Ignore
public class BillingAddressApiTest {

    private final BillingAddressApi api = new BillingAddressApi();

    
    /**
     * Fatura Adresi Listesi Alma
     *
     * Fatura Adresi listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void billingAddressesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer order = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        BillingAddress response = api.billingAddressesGet(sort, limit, page, sinceId, order, startDate, endDate, startUpdatedAt, endUpdatedAt);

        // TODO: test validations
    }
    
    /**
     * Fatura Adresi Alma
     *
     * İlgili Fatura Adresini getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void billingAddressesIdGetTest() throws ApiException {
        Integer id = null;
        BillingAddress response = api.billingAddressesIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Fatura Adresi Güncelleme
     *
     * İlgili Fatura Adresini günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void billingAddressesIdPutTest() throws ApiException {
        Integer id = null;
        BillingAddress billingAddress = null;
        BillingAddress response = api.billingAddressesIdPut(id, billingAddress);

        // TODO: test validations
    }
    
    /**
     * Fatura Adresi Oluşturma
     *
     * Yeni bir Fatura Adresi oluşturur. Fatura Adresi oluşturabilmek için geçerli bir önceden tanımlanmış Sipariş id değerine ihtiyaç vardır.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void billingAddressesPostTest() throws ApiException {
        BillingAddress billingAddress = null;
        BillingAddress response = api.billingAddressesPost(billingAddress);

        // TODO: test validations
    }
    
}
