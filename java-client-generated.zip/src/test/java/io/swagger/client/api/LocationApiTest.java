package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.Location;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for LocationApi
 */
@Ignore
public class LocationApiTest {

    private final LocationApi api = new LocationApi();

    
    /**
     * Şehir Listesi Alma
     *
     * Şehir listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void locationsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        Integer country = null;
        Integer region = null;
        Location response = api.locationsGet(sort, limit, page, sinceId, name, country, region);

        // TODO: test validations
    }
    
    /**
     * Şehir Alma
     *
     * İlgili Şehir getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void locationsIdGetTest() throws ApiException {
        Integer id = null;
        Location response = api.locationsIdGet(id);

        // TODO: test validations
    }
    
}
