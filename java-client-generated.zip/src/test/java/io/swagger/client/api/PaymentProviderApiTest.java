package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.PaymentProvider;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for PaymentProviderApi
 */
@Ignore
public class PaymentProviderApiTest {

    private final PaymentProviderApi api = new PaymentProviderApi();

    
    /**
     * Ödeme Altyapısı Sağlayıcısı Listesi Alma
     *
     * Ödeme Altyapısı Sağlayıcısı listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void paymentProvidersGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String code = null;
        String name = null;
        PaymentProvider response = api.paymentProvidersGet(sort, limit, page, sinceId, code, name);

        // TODO: test validations
    }
    
    /**
     * Ödeme Altyapısı Sağlayıcısı Alma
     *
     * İlgili Ödeme Altyapısı Sağlayıcısını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void paymentProvidersIdGetTest() throws ApiException {
        Integer id = null;
        PaymentProvider response = api.paymentProvidersIdGet(id);

        // TODO: test validations
    }
    
}
