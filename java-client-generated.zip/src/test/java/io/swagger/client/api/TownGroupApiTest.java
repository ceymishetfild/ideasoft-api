package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.TownGroup;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for TownGroupApi
 */
@Ignore
public class TownGroupApiTest {

    private final TownGroupApi api = new TownGroupApi();

    
    /**
     * İlçe Grubu Listesi Alma
     *
     * İlçe Grubu listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void townGroupsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        TownGroup response = api.townGroupsGet(sort, limit, page, sinceId, name);

        // TODO: test validations
    }
    
    /**
     * İlçe Grubu Silme
     *
     * Kalıcı olarak ilgili İlçe Grubunu siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void townGroupsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.townGroupsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * İlçe Grubu Alma
     *
     * İlgili İlçe Grubunu getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void townGroupsIdGetTest() throws ApiException {
        Integer id = null;
        TownGroup response = api.townGroupsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * İlçe Grubu Güncelleme
     *
     * İlgili İlçe Grubunu günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void townGroupsIdPutTest() throws ApiException {
        Integer id = null;
        TownGroup townGroup = null;
        TownGroup response = api.townGroupsIdPut(id, townGroup);

        // TODO: test validations
    }
    
    /**
     * İlçe Grubu Oluşturma
     *
     * Yeni bir İlçe Grubu oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void townGroupsPostTest() throws ApiException {
        TownGroup townGroup = null;
        TownGroup response = api.townGroupsPost(townGroup);

        // TODO: test validations
    }
    
}
