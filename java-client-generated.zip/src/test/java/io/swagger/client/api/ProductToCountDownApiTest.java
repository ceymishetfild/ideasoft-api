package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.ProductToCountDown;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ProductToCountDownApi
 */
@Ignore
public class ProductToCountDownApiTest {

    private final ProductToCountDownApi api = new ProductToCountDownApi();

    
    /**
     * Ürün Geri Sayım Bağı Listesi Alma
     *
     * Ürün Geri Sayım Bağı listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productToCountDownsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer product = null;
        ProductToCountDown response = api.productToCountDownsGet(sort, limit, page, sinceId, product);

        // TODO: test validations
    }
    
    /**
     * Ürün Geri Sayım Bağı Silme
     *
     * Kalıcı olarak ilgili Ürün Geri Sayım Bağını siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productToCountDownsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.productToCountDownsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Geri Sayım Bağı Alma
     *
     * İlgili Ürün Geri Sayım Bağını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productToCountDownsIdGetTest() throws ApiException {
        Integer id = null;
        ProductToCountDown response = api.productToCountDownsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Geri Sayım Bağı Güncelleme
     *
     * İlgili Ürün Geri Sayım Bağını günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productToCountDownsIdPutTest() throws ApiException {
        Integer id = null;
        ProductToCountDown productToCountDown = null;
        ProductToCountDown response = api.productToCountDownsIdPut(id, productToCountDown);

        // TODO: test validations
    }
    
    /**
     * Ürün Geri Sayım Bağı Oluşturma
     *
     * Yeni bir Ürün Geri Sayım Bağı oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productToCountDownsPostTest() throws ApiException {
        ProductToCountDown productToCountDown = null;
        ProductToCountDown response = api.productToCountDownsPost(productToCountDown);

        // TODO: test validations
    }
    
}
