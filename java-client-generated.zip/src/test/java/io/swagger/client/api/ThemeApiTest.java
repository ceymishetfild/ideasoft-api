package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Asset;
import io.swagger.client.model.Error;
import io.swagger.client.model.Theme;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ThemeApi
 */
@Ignore
public class ThemeApiTest {

    private final ThemeApi api = new ThemeApi();

    
    /**
     * Tema Listesi Alma
     *
     * Tema listesi verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void themesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer status = null;
        String platform = null;
        String type = null;
        Theme response = api.themesGet(sort, limit, page, sinceId, status, platform, type);

        // TODO: test validations
    }
    
    /**
     * Tema Dosyası Listesi Alma
     *
     * Tema Dosyası listesi verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void themesIdAssetsGetTest() throws ApiException {
        Integer id = null;
        String key = null;
        Asset response = api.themesIdAssetsGet(id, key);

        // TODO: test validations
    }
    
    /**
     * Tema Dosyası Silme
     *
     * Kalıcı olarak ilgili Tema Dosyasını siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void themesIdAssetskeykeyDeleteTest() throws ApiException {
        Integer id = null;
        String key = null;
        api.themesIdAssetskeykeyDelete(id, key);

        // TODO: test validations
    }
    
    /**
     * Tema Dosyası Alma
     *
     * İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void themesIdAssetskeykeyGetTest() throws ApiException {
        Integer id = null;
        String key = null;
        Asset response = api.themesIdAssetskeykeyGet(id, key);

        // TODO: test validations
    }
    
    /**
     * Tema Dosyası Güncelleme
     *
     * Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void themesIdAssetskeykeyPutTest() throws ApiException {
        Integer id = null;
        Theme theme = null;
        Asset asset = null;
        Asset response = api.themesIdAssetskeykeyPut(id, theme, asset);

        // TODO: test validations
    }
    
    /**
     * Tema Silme
     *
     * Kalıcı olarak ilgili Temayı siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void themesIdDeleteTest() throws ApiException {
        Integer id = null;
        api.themesIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Tema Alma
     *
     * İlgili Temayı getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void themesIdGetTest() throws ApiException {
        Integer id = null;
        Theme response = api.themesIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Tema Güncelleme
     *
     * İlgili Temayı günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void themesIdPutTest() throws ApiException {
        Integer id = null;
        Theme theme = null;
        Theme response = api.themesIdPut(id, theme);

        // TODO: test validations
    }
    
    /**
     * Tema Oluşturma
     *
     * Yeni bir tema oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void themesPostTest() throws ApiException {
        Theme theme = null;
        Theme response = api.themesPost(theme);

        // TODO: test validations
    }
    
}
