package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.SelectionToProduct;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for SelectionToProductApi
 */
@Ignore
public class SelectionToProductApiTest {

    private final SelectionToProductApi api = new SelectionToProductApi();

    
    /**
     * Ek Özellik Ürün Bağı Listesi Alma
     *
     * Ek Özellik Ürün Bağı listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void selectionToProductsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer selection = null;
        Integer product = null;
        SelectionToProduct response = api.selectionToProductsGet(sort, limit, page, sinceId, selection, product);

        // TODO: test validations
    }
    
    /**
     * Ek Özellik Ürün Bağı Silme
     *
     * Kalıcı olarak ilgili Ek Özellik Ürün Bağını siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void selectionToProductsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.selectionToProductsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ek Özellik Ürün Bağı Alma
     *
     * İlgili Ek Özellik Ürün Bağını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void selectionToProductsIdGetTest() throws ApiException {
        Integer id = null;
        SelectionToProduct response = api.selectionToProductsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ek Özellik Ürün Bağı Güncelleme
     *
     * İlgili Ek Özellik Ürün Bağını günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void selectionToProductsIdPutTest() throws ApiException {
        Integer id = null;
        SelectionToProduct selectionToProduct = null;
        SelectionToProduct response = api.selectionToProductsIdPut(id, selectionToProduct);

        // TODO: test validations
    }
    
    /**
     * Ek Özellik Ürün Bağı Oluşturma
     *
     * Yeni bir Ek Özellik Ürün Bağı oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void selectionToProductsPostTest() throws ApiException {
        SelectionToProduct selectionToProduct = null;
        SelectionToProduct response = api.selectionToProductsPost(selectionToProduct);

        // TODO: test validations
    }
    
}
