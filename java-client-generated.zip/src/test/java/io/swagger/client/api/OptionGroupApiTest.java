package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.OptionGroup;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for OptionGroupApi
 */
@Ignore
public class OptionGroupApiTest {

    private final OptionGroupApi api = new OptionGroupApi();

    
    /**
     * Varyant Grubu Listesi Alma
     *
     * Varyant Grubu listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void optionGroupsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String title = null;
        OptionGroup response = api.optionGroupsGet(sort, limit, page, sinceId, title);

        // TODO: test validations
    }
    
    /**
     * Varyant Grubu Silme
     *
     * Kalıcı olarak ilgili Varyant Grubunu siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void optionGroupsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.optionGroupsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Varyant Grubu Alma
     *
     * İlgili Varyant Grubunu getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void optionGroupsIdGetTest() throws ApiException {
        Integer id = null;
        OptionGroup response = api.optionGroupsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Varyant Grubu Güncelleme
     *
     * İlgili Varyant Grubunu günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void optionGroupsIdPutTest() throws ApiException {
        Integer id = null;
        OptionGroup optionGroup = null;
        OptionGroup response = api.optionGroupsIdPut(id, optionGroup);

        // TODO: test validations
    }
    
    /**
     * Varyant Grubu Oluşturma
     *
     * Yeni bir Varyant Grubu oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void optionGroupsPostTest() throws ApiException {
        OptionGroup optionGroup = null;
        OptionGroup response = api.optionGroupsPost(optionGroup);

        // TODO: test validations
    }
    
}
