package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.ExtraInfoToProduct;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ExtraInfoToProductApi
 */
@Ignore
public class ExtraInfoToProductApiTest {

    private final ExtraInfoToProductApi api = new ExtraInfoToProductApi();

    
    /**
     * Ek Bilgi Ürün Bağı Listesi Alma
     *
     * Ek Bilgi Ürün Bağı listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void extraInfoToProductsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer extraInfo = null;
        Integer product = null;
        ExtraInfoToProduct response = api.extraInfoToProductsGet(sort, limit, page, sinceId, extraInfo, product);

        // TODO: test validations
    }
    
    /**
     * Ek Bilgi Ürün Bağı Silme
     *
     * Kalıcı olarak ilgili Ek Bilgi Ürün Bağını siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void extraInfoToProductsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.extraInfoToProductsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ek Bilgi Ürün Bağı Alma
     *
     * İlgili Ek Bilgi Ürün Bağını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void extraInfoToProductsIdGetTest() throws ApiException {
        Integer id = null;
        ExtraInfoToProduct response = api.extraInfoToProductsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ek Bilgi Ürün Bağı Güncelleme
     *
     * İlgili Ek Bilgi Ürün Bağını günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void extraInfoToProductsIdPutTest() throws ApiException {
        Integer id = null;
        ExtraInfoToProduct extraInfoToProduct = null;
        ExtraInfoToProduct response = api.extraInfoToProductsIdPut(id, extraInfoToProduct);

        // TODO: test validations
    }
    
    /**
     * Ek Bilgi Ürün Bağı Oluşturma
     *
     * Yeni bir Ek Bilgi Ürün Bağı oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void extraInfoToProductsPostTest() throws ApiException {
        ExtraInfoToProduct extraInfoToProduct = null;
        ExtraInfoToProduct response = api.extraInfoToProductsPost(extraInfoToProduct);

        // TODO: test validations
    }
    
}
