package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.SpecValue;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for SpecValueApi
 */
@Ignore
public class SpecValueApiTest {

    private final SpecValueApi api = new SpecValueApi();

    
    /**
     * Ürün Özellik Değeri Listesi Alma
     *
     * Ürün Özellik Değeri listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specValuesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        Integer specName = null;
        Integer specValue = null;
        SpecValue response = api.specValuesGet(sort, limit, page, sinceId, name, specName, specValue);

        // TODO: test validations
    }
    
    /**
     * Ürün Özellik Değeri Silme
     *
     * Kalıcı olarak ilgili Ürün Özellik Değerini siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specValuesIdDeleteTest() throws ApiException {
        Integer id = null;
        api.specValuesIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Özellik Değeri Alma
     *
     * İlgili Ürün Özellik Değerini getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specValuesIdGetTest() throws ApiException {
        Integer id = null;
        SpecValue response = api.specValuesIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Özellik Değeri Güncelleme
     *
     * İlgili Ürün Özellik Değerini günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specValuesIdPutTest() throws ApiException {
        Integer id = null;
        SpecValue specValue = null;
        SpecValue response = api.specValuesIdPut(id, specValue);

        // TODO: test validations
    }
    
    /**
     * Ürün Özellik Değeri Oluşturma
     *
     * Yeni bir Ürün Özellik Değeri oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specValuesPostTest() throws ApiException {
        SpecValue specValue = null;
        SpecValue response = api.specValuesPost(specValue);

        // TODO: test validations
    }
    
}
