package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.PreOrderInfo;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for PreOrderInfoApi
 */
@Ignore
public class PreOrderInfoApiTest {

    private final PreOrderInfoApi api = new PreOrderInfoApi();

    
    /**
     * Sipariş Öncesi Bilgisi Listesi Alma
     *
     * Sipariş Öncesi Bilgisi listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void preOrderInfosGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String sessionId = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        PreOrderInfo response = api.preOrderInfosGet(sort, limit, page, sinceId, sessionId, startDate, endDate, startUpdatedAt, endUpdatedAt);

        // TODO: test validations
    }
    
    /**
     * Sipariş Öncesi Bilgisi Silme
     *
     * Kalıcı olarak ilgili Sipariş Öncesi Bilgisini siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void preOrderInfosIdDeleteTest() throws ApiException {
        Integer id = null;
        api.preOrderInfosIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Sipariş Öncesi Bilgisi Alma
     *
     * İlgili Sipariş Öncesi Bilgisini getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void preOrderInfosIdGetTest() throws ApiException {
        Integer id = null;
        PreOrderInfo response = api.preOrderInfosIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Sipariş Öncesi Bilgisi Güncelleme
     *
     * İlgili Sipariş Öncesi Bilgisini günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void preOrderInfosIdPutTest() throws ApiException {
        Integer id = null;
        PreOrderInfo preOrderInfo = null;
        PreOrderInfo response = api.preOrderInfosIdPut(id, preOrderInfo);

        // TODO: test validations
    }
    
    /**
     * Sipariş Öncesi Bilgisi Oluşturma
     *
     * Yeni bir Sipariş Öncesi Bilgisi oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void preOrderInfosPostTest() throws ApiException {
        PreOrderInfo preOrderInfo = null;
        PreOrderInfo response = api.preOrderInfosPost(preOrderInfo);

        // TODO: test validations
    }
    
}
