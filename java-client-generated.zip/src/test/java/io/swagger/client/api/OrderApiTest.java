package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.Order;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for OrderApi
 */
@Ignore
public class OrderApiTest {

    private final OrderApi api = new OrderApi();

    
    /**
     * Sipariş Listesi Alma
     *
     * Sipariş listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void ordersGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String transactionId = null;
        String customerEmail = null;
        Integer member = null;
        String status = null;
        String paymentStatus = null;
        String paymentTypeName = null;
        String shippingProviderCode = null;
        List<String> q = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        Order response = api.ordersGet(sort, limit, page, sinceId, transactionId, customerEmail, member, status, paymentStatus, paymentTypeName, shippingProviderCode, q, startDate, endDate, startUpdatedAt, endUpdatedAt);

        // TODO: test validations
    }
    
    /**
     * Sipariş Silme
     *
     * Kalıcı olarak ilgili Siparişi siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void ordersIdDeleteTest() throws ApiException {
        Integer id = null;
        api.ordersIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Sipariş Alma
     *
     * İlgili Siparişi getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void ordersIdGetTest() throws ApiException {
        Integer id = null;
        Order response = api.ordersIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Sipariş Güncelleme
     *
     * İlgili Siparişi günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void ordersIdPutTest() throws ApiException {
        Integer id = null;
        Order order = null;
        Order response = api.ordersIdPut(id, order);

        // TODO: test validations
    }
    
    /**
     * Sipariş Oluşturma
     *
     * Yeni bir Sipariş oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void ordersPostTest() throws ApiException {
        Order order = null;
        Order response = api.ordersPost(order);

        // TODO: test validations
    }
    
}
