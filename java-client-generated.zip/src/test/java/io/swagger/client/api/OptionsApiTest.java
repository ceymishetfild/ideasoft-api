package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.Options;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for OptionsApi
 */
@Ignore
public class OptionsApiTest {

    private final OptionsApi api = new OptionsApi();

    
    /**
     * Varyant Listesi Alma
     *
     * Varyant listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void optionsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String title = null;
        Integer optionGroup = null;
        Options response = api.optionsGet(sort, limit, page, sinceId, title, optionGroup);

        // TODO: test validations
    }
    
    /**
     * Varyant Silme
     *
     * Kalıcı olarak ilgili Varyantı siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void optionsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.optionsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Varyant Alma
     *
     * İlgili Varyantı getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void optionsIdGetTest() throws ApiException {
        Integer id = null;
        Options response = api.optionsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Varyant Güncelleme
     *
     * İlgili Varyantı günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void optionsIdPutTest() throws ApiException {
        Integer id = null;
        Options options = null;
        Options response = api.optionsIdPut(id, options);

        // TODO: test validations
    }
    
    /**
     * Varyant Oluşturma
     *
     * Yeni bir Varyant oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void optionsPostTest() throws ApiException {
        Options options = null;
        Options response = api.optionsPost(options);

        // TODO: test validations
    }
    
}
