package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.ShipmentItem;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ShipmentItemApi
 */
@Ignore
public class ShipmentItemApiTest {

    private final ShipmentItemApi api = new ShipmentItemApi();

    
    /**
     * Teslimat Kalemi Listesi Alma
     *
     * Teslimat Kalemi listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shipmentItemsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer product = null;
        Integer shipment = null;
        Integer orderItem = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        ShipmentItem response = api.shipmentItemsGet(sort, limit, page, sinceId, product, shipment, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt);

        // TODO: test validations
    }
    
    /**
     * Teslimat Kalemi Silme
     *
     * Kalıcı olarak ilgili Teslimat Kalemini siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shipmentItemsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.shipmentItemsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Teslimat Kalemi Alma
     *
     * İlgili Teslimat Kalemini getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shipmentItemsIdGetTest() throws ApiException {
        Integer id = null;
        ShipmentItem response = api.shipmentItemsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Teslimat Kalemi Güncelleme
     *
     * İlgili Teslimat Kalemini günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shipmentItemsIdPutTest() throws ApiException {
        Integer id = null;
        ShipmentItem shipmentItem = null;
        ShipmentItem response = api.shipmentItemsIdPut(id, shipmentItem);

        // TODO: test validations
    }
    
    /**
     * Teslimat Kalemi Oluşturma
     *
     * Yeni bir Teslimat Kalemi oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shipmentItemsPostTest() throws ApiException {
        ShipmentItem shipmentItem = null;
        ShipmentItem response = api.shipmentItemsPost(shipmentItem);

        // TODO: test validations
    }
    
}
