package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.OrderItem;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for OrderItemApi
 */
@Ignore
public class OrderItemApiTest {

    private final OrderItemApi api = new OrderItemApi();

    
    /**
     * Sipariş Kalemi Listesi Alma
     *
     * Sipariş Kalemi listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderItemsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer order = null;
        String productName = null;
        String productSku = null;
        String productBarcode = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        OrderItem response = api.orderItemsGet(sort, limit, page, sinceId, order, productName, productSku, productBarcode, startDate, endDate, startUpdatedAt, endUpdatedAt);

        // TODO: test validations
    }
    
    /**
     * Sipariş Kalemi Alma
     *
     * İlgili Sipariş Kalemini getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderItemsIdGetTest() throws ApiException {
        Integer id = null;
        OrderItem response = api.orderItemsIdGet(id);

        // TODO: test validations
    }
    
}
