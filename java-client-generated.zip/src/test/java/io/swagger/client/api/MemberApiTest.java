package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.Member;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for MemberApi
 */
@Ignore
public class MemberApiTest {

    private final MemberApi api = new MemberApi();

    
    /**
     * Üye Grafik Aksiyonu
     *
     * Zaman bazında üye genel istatistiklerini getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void membersChartsGetTest() throws ApiException {
        String timeFrame = null;
        String startDate = null;
        Member response = api.membersChartsGet(timeFrame, startDate);

        // TODO: test validations
    }
    
    /**
     * Üye Birleşik Aksiyonu
     *
     * Bugün, aylık, yıllık ve toplam üye oturum açma istatistiklerini totalCount cinsinden getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void membersCombinedGetTest() throws ApiException {
        Member response = api.membersCombinedGet();

        // TODO: test validations
    }
    
    /**
     * Üye Listesi Alma
     *
     * Üye listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void membersGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String firstname = null;
        String surname = null;
        String email = null;
        String password = null;
        String gender = null;
        String mobilePhoneNumber = null;
        String phoneNumber = null;
        Integer memberGroup = null;
        Integer location = null;
        Integer country = null;
        Integer referredMember = null;
        List<String> q = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        Member response = api.membersGet(sort, limit, page, sinceId, firstname, surname, email, password, gender, mobilePhoneNumber, phoneNumber, memberGroup, location, country, referredMember, q, startDate, endDate, startUpdatedAt, endUpdatedAt);

        // TODO: test validations
    }
    
    /**
     * Üye Silme
     *
     * Kalıcı olarak ilgili Üyeyi siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void membersIdDeleteTest() throws ApiException {
        Integer id = null;
        api.membersIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Üye Alma
     *
     * İlgili Üyeyi getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void membersIdGetTest() throws ApiException {
        Integer id = null;
        Member response = api.membersIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Üye Güncelleme
     *
     * İlgili Üyeyi günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void membersIdPutTest() throws ApiException {
        Integer id = null;
        Member member = null;
        Member response = api.membersIdPut(id, member);

        // TODO: test validations
    }
    
    /**
     * Üye Oluşturma
     *
     * Yeni bir Üye oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void membersPostTest() throws ApiException {
        Member member = null;
        Member response = api.membersPost(member);

        // TODO: test validations
    }
    
}
