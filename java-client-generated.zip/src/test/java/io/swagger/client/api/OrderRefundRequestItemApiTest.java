package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.OrderRefundRequestItem;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for OrderRefundRequestItemApi
 */
@Ignore
public class OrderRefundRequestItemApiTest {

    private final OrderRefundRequestItemApi api = new OrderRefundRequestItemApi();

    
    /**
     * Sipariş İptal Talebi Kalemi Listesi Alma
     *
     * Sipariş İptal Talebi Kalemi listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderRefundRequestItemsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer orderRefundRequest = null;
        Integer orderItem = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        OrderRefundRequestItem response = api.orderRefundRequestItemsGet(sort, limit, page, sinceId, orderRefundRequest, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt);

        // TODO: test validations
    }
    
    /**
     * Sipariş İptal Talebi Kalemi Silme
     *
     * Kalıcı olarak ilgili Sipariş İptal Talebi Kalemini siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderRefundRequestItemsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.orderRefundRequestItemsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Sipariş İptal Talebi Kalemi Alma
     *
     * İlgili Sipariş İptal Talebi Kalemini getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderRefundRequestItemsIdGetTest() throws ApiException {
        Integer id = null;
        OrderRefundRequestItem response = api.orderRefundRequestItemsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Sipariş İptal Talebi Kalemi Güncelleme
     *
     * İlgili Sipariş İptal Talebi Kalemini günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderRefundRequestItemsIdPutTest() throws ApiException {
        Integer id = null;
        OrderRefundRequestItem orderRefundRequestItem = null;
        OrderRefundRequestItem response = api.orderRefundRequestItemsIdPut(id, orderRefundRequestItem);

        // TODO: test validations
    }
    
    /**
     * Sipariş İptal Talebi Kalemi Oluşturma
     *
     * Yeni bir Sipariş İptal Talebi Kalemi oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void orderRefundRequestItemsPostTest() throws ApiException {
        OrderRefundRequestItem orderRefundRequestItem = null;
        OrderRefundRequestItem response = api.orderRefundRequestItemsPost(orderRefundRequestItem);

        // TODO: test validations
    }
    
}
