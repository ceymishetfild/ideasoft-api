package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.SpecName;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for SpecNameApi
 */
@Ignore
public class SpecNameApiTest {

    private final SpecNameApi api = new SpecNameApi();

    
    /**
     * Ürün Özelliği Listesi Alma
     *
     * Ürün Özelliği listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specNamesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        Integer specGroup = null;
        String choiceType = null;
        SpecName response = api.specNamesGet(sort, limit, page, sinceId, name, specGroup, choiceType);

        // TODO: test validations
    }
    
    /**
     * Ürün Özelliği Silme
     *
     * Kalıcı olarak ilgili Ürün Özelliğini siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specNamesIdDeleteTest() throws ApiException {
        Integer id = null;
        api.specNamesIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Özelliği Alma
     *
     * İlgili Ürün Özelliğini getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specNamesIdGetTest() throws ApiException {
        Integer id = null;
        SpecName response = api.specNamesIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Özelliği Güncelleme
     *
     * İlgili Ürün Özelliğini günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specNamesIdPutTest() throws ApiException {
        Integer id = null;
        SpecName specName = null;
        SpecName response = api.specNamesIdPut(id, specName);

        // TODO: test validations
    }
    
    /**
     * Ürün Özelliği Oluşturma
     *
     * Yeni bir Ürün Özelliği oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specNamesPostTest() throws ApiException {
        SpecName specName = null;
        SpecName response = api.specNamesPost(specName);

        // TODO: test validations
    }
    
}
