package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.ProductToTag;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ProductToTagApi
 */
@Ignore
public class ProductToTagApiTest {

    private final ProductToTagApi api = new ProductToTagApi();

    
    /**
     * Ürün SEO+ Bağı Listesi Alma
     *
     * Ürün SEO+ Bağı listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productToTagsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer product = null;
        Integer tag = null;
        ProductToTag response = api.productToTagsGet(sort, limit, page, sinceId, product, tag);

        // TODO: test validations
    }
    
    /**
     * Ürün SEO+ Bağı Silme
     *
     * Kalıcı olarak ilgili Ürün SEO+ Bağını siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productToTagsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.productToTagsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ürün SEO+ Bağı Alma
     *
     * İlgili Ürün SEO+ Bağını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productToTagsIdGetTest() throws ApiException {
        Integer id = null;
        ProductToTag response = api.productToTagsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ürün SEO+ Bağı Güncelleme
     *
     * İlgili Ürün SEO+ Bağını günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productToTagsIdPutTest() throws ApiException {
        Integer id = null;
        ProductToTag productToTag = null;
        ProductToTag response = api.productToTagsIdPut(id, productToTag);

        // TODO: test validations
    }
    
    /**
     * Ürün SEO+ Bağı Oluşturma
     *
     * Yeni bir Ürün SEO+ Bağı oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productToTagsPostTest() throws ApiException {
        ProductToTag productToTag = null;
        ProductToTag response = api.productToTagsPost(productToTag);

        // TODO: test validations
    }
    
}
