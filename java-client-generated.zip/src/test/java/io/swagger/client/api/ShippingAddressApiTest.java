package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.ShippingAddress;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ShippingAddressApi
 */
@Ignore
public class ShippingAddressApiTest {

    private final ShippingAddressApi api = new ShippingAddressApi();

    
    /**
     * Teslimat Adresi Listesi Alma
     *
     * Teslimat Adresi listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingAddressesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer order = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        ShippingAddress response = api.shippingAddressesGet(sort, limit, page, sinceId, order, startDate, endDate, startUpdatedAt, endUpdatedAt);

        // TODO: test validations
    }
    
    /**
     * Teslimat Adresi Alma
     *
     * İlgili Teslimat Adresi getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingAddressesIdGetTest() throws ApiException {
        Integer id = null;
        ShippingAddress response = api.shippingAddressesIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Teslimat Adresi Güncelleme
     *
     * İlgili Teslimat Adresi günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingAddressesIdPutTest() throws ApiException {
        Integer id = null;
        ShippingAddress shippingAddress = null;
        ShippingAddress response = api.shippingAddressesIdPut(id, shippingAddress);

        // TODO: test validations
    }
    
    /**
     * Teslimat Adresi Oluşturma
     *
     * Yeni bir Teslimat Adresi oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingAddressesPostTest() throws ApiException {
        ShippingAddress shippingAddress = null;
        ShippingAddress response = api.shippingAddressesPost(shippingAddress);

        // TODO: test validations
    }
    
}
