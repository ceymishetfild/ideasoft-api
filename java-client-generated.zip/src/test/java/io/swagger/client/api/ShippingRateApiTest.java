package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.ShippingRate;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ShippingRateApi
 */
@Ignore
public class ShippingRateApiTest {

    private final ShippingRateApi api = new ShippingRateApi();

    
    /**
     * Kargo Oranı Listesi Alma
     *
     * Kargo Oranı listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingRatesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer shippingCompany = null;
        Integer region = null;
        ShippingRate response = api.shippingRatesGet(sort, limit, page, sinceId, shippingCompany, region);

        // TODO: test validations
    }
    
    /**
     * Kargo Oranı Silme
     *
     * Kalıcı olarak ilgili Kargo Oranını siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingRatesIdDeleteTest() throws ApiException {
        Integer id = null;
        api.shippingRatesIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Kargo Oranı Alma
     *
     * İlgili Kargo Oranını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingRatesIdGetTest() throws ApiException {
        Integer id = null;
        ShippingRate response = api.shippingRatesIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Kargo Oranı Güncelleme
     *
     * İlgili Kargo Oranını günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingRatesIdPutTest() throws ApiException {
        Integer id = null;
        ShippingRate shippingRate = null;
        ShippingRate response = api.shippingRatesIdPut(id, shippingRate);

        // TODO: test validations
    }
    
    /**
     * Kargo Oranı Oluşturma
     *
     * Yeni bir Kargo Oranı oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void shippingRatesPostTest() throws ApiException {
        ShippingRate shippingRate = null;
        ShippingRate response = api.shippingRatesPost(shippingRate);

        // TODO: test validations
    }
    
}
