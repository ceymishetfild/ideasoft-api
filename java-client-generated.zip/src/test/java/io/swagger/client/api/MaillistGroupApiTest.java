package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.MaillistGroup;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for MaillistGroupApi
 */
@Ignore
public class MaillistGroupApiTest {

    private final MaillistGroupApi api = new MaillistGroupApi();

    
    /**
     * Mail Listesi Grubu Listesi Alma
     *
     * Mail Listesi Grubu listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void maillistGroupsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        MaillistGroup response = api.maillistGroupsGet(sort, limit, page, sinceId, name);

        // TODO: test validations
    }
    
    /**
     * Mail Listesi Grubu Silme
     *
     * Kalıcı olarak ilgili Mail Listesi Grubunu siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void maillistGroupsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.maillistGroupsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Mail Listesi Grubu Alma
     *
     * İlgili Mail Listesi Grubunu getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void maillistGroupsIdGetTest() throws ApiException {
        Integer id = null;
        MaillistGroup response = api.maillistGroupsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Mail Listesi Grubu Güncelleme
     *
     * İlgili Mail Listesi Grubunu günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void maillistGroupsIdPutTest() throws ApiException {
        Integer id = null;
        MaillistGroup maillistGroup = null;
        MaillistGroup response = api.maillistGroupsIdPut(id, maillistGroup);

        // TODO: test validations
    }
    
    /**
     * Mail Listesi Grubu Oluşturma
     *
     * Yeni bir Mail Listesi Grubu oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void maillistGroupsPostTest() throws ApiException {
        MaillistGroup maillistGroup = null;
        MaillistGroup response = api.maillistGroupsPost(maillistGroup);

        // TODO: test validations
    }
    
}
