package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.ProductPrice;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ProductPriceApi
 */
@Ignore
public class ProductPriceApiTest {

    private final ProductPriceApi api = new ProductPriceApi();

    
    /**
     * Ürün Fiyat Listesi Alma
     *
     * Ürün Fiyat listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productPricesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer type = null;
        Integer product = null;
        ProductPrice response = api.productPricesGet(sort, limit, page, sinceId, type, product);

        // TODO: test validations
    }
    
    /**
     * Ürün Fiyat Silme
     *
     * Kalıcı olarak ilgili Ürün Fiyatını siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productPricesIdDeleteTest() throws ApiException {
        Integer id = null;
        api.productPricesIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Fiyat Alma
     *
     * İlgili Ürün Fiyatını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productPricesIdGetTest() throws ApiException {
        Integer id = null;
        ProductPrice response = api.productPricesIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Fiyat Güncelleme
     *
     * İlgili Ürün Fiyatını günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productPricesIdPutTest() throws ApiException {
        Integer id = null;
        ProductPrice productPrice = null;
        ProductPrice response = api.productPricesIdPut(id, productPrice);

        // TODO: test validations
    }
    
    /**
     * Ürün Fiyat Oluşturma
     *
     * Yeni bir Ürün Fiyat oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productPricesPostTest() throws ApiException {
        ProductPrice productPrice = null;
        ProductPrice response = api.productPricesPost(productPrice);

        // TODO: test validations
    }
    
}
