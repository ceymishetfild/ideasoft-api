package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.ProductButton;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ProductButtonApi
 */
@Ignore
public class ProductButtonApiTest {

    private final ProductButtonApi api = new ProductButtonApi();

    
    /**
     * Ürün ve Stok Butonu Listesi Alma
     *
     * Ürün ve Stok Butonu listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productButtonsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer fastShipping = null;
        Integer sameDayShipping = null;
        Integer threeDaysDelivery = null;
        Integer fiveDaysDelivery = null;
        Integer sevenDaysDelivery = null;
        Integer freeShipping = null;
        Integer deliveryFromStock = null;
        Integer preOrderedProduct = null;
        Integer askStock = null;
        Integer campaignedProduct = null;
        Integer product = null;
        ProductButton response = api.productButtonsGet(sort, limit, page, sinceId, fastShipping, sameDayShipping, threeDaysDelivery, fiveDaysDelivery, sevenDaysDelivery, freeShipping, deliveryFromStock, preOrderedProduct, askStock, campaignedProduct, product);

        // TODO: test validations
    }
    
    /**
     * Ürün ve Stok Butonu Silme
     *
     * Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productButtonsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.productButtonsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ürün ve Stok Butonu Alma
     *
     * İlgili Ürün ve Stok Butonunu getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productButtonsIdGetTest() throws ApiException {
        Integer id = null;
        ProductButton response = api.productButtonsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ürün ve Stok Butonu Güncelleme
     *
     * İlgili Ürün ve Stok Butonunu günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productButtonsIdPutTest() throws ApiException {
        Integer id = null;
        ProductButton productButton = null;
        ProductButton response = api.productButtonsIdPut(id, productButton);

        // TODO: test validations
    }
    
    /**
     * Ürün ve Stok Butonu Oluşturma
     *
     * Yeni bir Ürün ve Stok Butonu oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void productButtonsPostTest() throws ApiException {
        ProductButton productButton = null;
        ProductButton response = api.productButtonsPost(productButton);

        // TODO: test validations
    }
    
}
