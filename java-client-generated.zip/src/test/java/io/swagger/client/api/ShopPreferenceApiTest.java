package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.ShopPreference;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ShopPreferenceApi
 */
@Ignore
public class ShopPreferenceApiTest {

    private final ShopPreferenceApi api = new ShopPreferenceApi();

    
    /**
     * Tanımlamalar Listesi Alma
     *
     * Tanımlamalar listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void preferencesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String varKey = null;
        ShopPreference response = api.preferencesGet(sort, limit, page, sinceId, varKey);

        // TODO: test validations
    }
    
    /**
     * Tanımlamalar Alma
     *
     * İlgili Tanımlamayı getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void preferencesIdGetTest() throws ApiException {
        Integer id = null;
        ShopPreference response = api.preferencesIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Tanımlamalar Güncelleme
     *
     * İlgili Tanımlamayı günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void preferencesIdPutTest() throws ApiException {
        Integer id = null;
        ShopPreference shopPreference = null;
        ShopPreference response = api.preferencesIdPut(id, shopPreference);

        // TODO: test validations
    }
    
}
