package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import io.swagger.client.model.MemberAddress;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for MemberAddressApi
 */
@Ignore
public class MemberAddressApiTest {

    private final MemberAddressApi api = new MemberAddressApi();

    
    /**
     * Üye Adresi Listeleme
     *
     * Üye Adresi listesi verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void memberAddressesGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer member = null;
        LocalDate startDate = null;
        String endDate = null;
        MemberAddress response = api.memberAddressesGet(sort, limit, page, sinceId, member, startDate, endDate);

        // TODO: test validations
    }
    
    /**
     * Üye Adresi Silme
     *
     * Kalıcı olarak ilgili Üye Adresini siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void memberAddressesIdDeleteTest() throws ApiException {
        Integer id = null;
        api.memberAddressesIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Üye Adresi Alma
     *
     * İlgili Üye Adresini getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void memberAddressesIdGetTest() throws ApiException {
        Integer id = null;
        MemberAddress response = api.memberAddressesIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Üye Adresi Güncelleme
     *
     * İlgili Üye Adresini günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void memberAddressesIdPutTest() throws ApiException {
        Integer id = null;
        MemberAddress memberAddress = null;
        MemberAddress response = api.memberAddressesIdPut(id, memberAddress);

        // TODO: test validations
    }
    
    /**
     * Üye Adresi Oluşturma
     *
     * Yeni bir Üye Adresi oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void memberAddressesPostTest() throws ApiException {
        MemberAddress memberAddress = null;
        MemberAddress response = api.memberAddressesPost(memberAddress);

        // TODO: test validations
    }
    
}
