package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.ExtraInfo;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for ExtraInfoApi
 */
@Ignore
public class ExtraInfoApiTest {

    private final ExtraInfoApi api = new ExtraInfoApi();

    
    /**
     * Ek Bilgi Listesi Alma
     *
     * Ek Bilgi listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void extraInfosGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String name = null;
        ExtraInfo response = api.extraInfosGet(sort, limit, page, sinceId, name);

        // TODO: test validations
    }
    
    /**
     * Ek Bilgi Silme
     *
     * Kalıcı olarak ilgili Ek Bilgiyi siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void extraInfosIdDeleteTest() throws ApiException {
        Integer id = null;
        api.extraInfosIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ek Bilgi Alma
     *
     * İlgili Ek Bilgiyi getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void extraInfosIdGetTest() throws ApiException {
        Integer id = null;
        ExtraInfo response = api.extraInfosIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ek Bilgi Güncelleme
     *
     * İlgili Ek Bilgiyi günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void extraInfosIdPutTest() throws ApiException {
        Integer id = null;
        ExtraInfo extraInfo = null;
        ExtraInfo response = api.extraInfosIdPut(id, extraInfo);

        // TODO: test validations
    }
    
    /**
     * Ek Bilgi Oluşturma
     *
     * Yeni bir Ek Bilgi oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void extraInfosPostTest() throws ApiException {
        ExtraInfo extraInfo = null;
        ExtraInfo response = api.extraInfosPost(extraInfo);

        // TODO: test validations
    }
    
}
