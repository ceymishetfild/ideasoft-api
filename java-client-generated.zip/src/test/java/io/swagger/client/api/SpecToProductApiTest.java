package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.Error;
import io.swagger.client.model.SpecToProduct;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for SpecToProductApi
 */
@Ignore
public class SpecToProductApiTest {

    private final SpecToProductApi api = new SpecToProductApi();

    
    /**
     * Ürün Özellik Ürün Bağı Listesi Alma
     *
     * Ürün Özellik Ürün Bağı listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specToProductsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        Integer product = null;
        Integer specGroup = null;
        Integer specName = null;
        Integer specValue = null;
        SpecToProduct response = api.specToProductsGet(sort, limit, page, sinceId, product, specGroup, specName, specValue);

        // TODO: test validations
    }
    
    /**
     * Ürün Özellik Ürün Bağı Silme
     *
     * Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specToProductsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.specToProductsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Özellik Ürün Bağı Alma
     *
     * İlgili Ürün Özellik Ürün Bağını getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specToProductsIdGetTest() throws ApiException {
        Integer id = null;
        SpecToProduct response = api.specToProductsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Ürün Özellik Ürün Bağı Güncelleme
     *
     * İlgili Ürün Özellik Ürün Bağını günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specToProductsIdPutTest() throws ApiException {
        Integer id = null;
        SpecToProduct specToProduct = null;
        SpecToProduct response = api.specToProductsIdPut(id, specToProduct);

        // TODO: test validations
    }
    
    /**
     * Ürün Özellik Ürün Bağı Oluşturma
     *
     * Yeni bir Ürün Özellik Ürün Bağı oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void specToProductsPostTest() throws ApiException {
        SpecToProduct specToProduct = null;
        SpecToProduct response = api.specToProductsPost(specToProduct);

        // TODO: test validations
    }
    
}
