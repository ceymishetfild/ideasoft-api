package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.model.CurrentAccount;
import io.swagger.client.model.Error;
import org.threeten.bp.LocalDate;
import org.junit.Test;
import org.junit.Ignore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * API tests for CurrentAccountApi
 */
@Ignore
public class CurrentAccountApiTest {

    private final CurrentAccountApi api = new CurrentAccountApi();

    
    /**
     * Cari Hesap Listesi Alma
     *
     * Cari Hesap listesini verir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void currentAccountsGetTest() throws ApiException {
        String sort = null;
        Integer limit = null;
        Integer page = null;
        Integer sinceId = null;
        String code = null;
        String title = null;
        LocalDate startDate = null;
        String endDate = null;
        LocalDate startUpdatedAt = null;
        String endUpdatedAt = null;
        String member = null;
        CurrentAccount response = api.currentAccountsGet(sort, limit, page, sinceId, code, title, startDate, endDate, startUpdatedAt, endUpdatedAt, member);

        // TODO: test validations
    }
    
    /**
     * Cari Hesap Silme
     *
     * Kalıcı olarak ilgili Cari Hesabı siler.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void currentAccountsIdDeleteTest() throws ApiException {
        Integer id = null;
        api.currentAccountsIdDelete(id);

        // TODO: test validations
    }
    
    /**
     * Cari Hesap Alma
     *
     * İlgili Cari Hesabı getirir.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void currentAccountsIdGetTest() throws ApiException {
        Integer id = null;
        CurrentAccount response = api.currentAccountsIdGet(id);

        // TODO: test validations
    }
    
    /**
     * Cari Hesap Güncelleme
     *
     * İlgili Cari Hesabı günceller.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void currentAccountsIdPutTest() throws ApiException {
        Integer id = null;
        CurrentAccount currentAccount = null;
        CurrentAccount response = api.currentAccountsIdPut(id, currentAccount);

        // TODO: test validations
    }
    
    /**
     * Cari Hesap Oluşturma
     *
     * Yeni bir Cari Hesap oluşturur.
     *
     * @throws ApiException
     *          if the Api call fails
     */
    @Test
    public void currentAccountsPostTest() throws ApiException {
        CurrentAccount currentAccount = null;
        CurrentAccount response = api.currentAccountsPost(currentAccount);

        // TODO: test validations
    }
    
}
