# swagger-java-client

## Requirements

Building the API client library requires [Maven](https://maven.apache.org/) to be installed.

## Installation

To install the API client library to your local Maven repository, simply execute:

```shell
mvn install
```

To deploy it to a remote Maven repository instead, configure the settings of the repository and execute:

```shell
mvn deploy
```

Refer to the [official documentation](https://maven.apache.org/plugins/maven-deploy-plugin/usage.html) for more information.

### Maven users

Add this dependency to your project's POM:

```xml
<dependency>
    <groupId>io.swagger</groupId>
    <artifactId>swagger-java-client</artifactId>
    <version>1.0.0</version>
    <scope>compile</scope>
</dependency>
```

### Gradle users

Add this dependency to your project's build file:

```groovy
compile "io.swagger:swagger-java-client:1.0.0"
```

### Others

At first generate the JAR by executing:

    mvn package

Then manually install the following JARs:

* target/swagger-java-client-1.0.0.jar
* target/lib/*.jar

## Getting Started

Please follow the [installation](#installation) instruction and execute the following Java code:

```java

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.BillingAddressApi;

import java.io.File;
import java.util.*;

public class BillingAddressApiExample {

    public static void main(String[] args) {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        
        // Configure OAuth2 access token for authorization: OAuth2
        OAuth OAuth2 = (OAuth) defaultClient.getAuthentication("OAuth2");
        OAuth2.setAccessToken("YOUR ACCESS TOKEN");

        BillingAddressApi apiInstance = new BillingAddressApi();
        String sort = "sort_example"; // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
        Integer limit = 20; // Integer | Bir sayfada gelecek sonuç adedi
        Integer page = 1; // Integer | Hangi sayfadan başlanacağı
        Integer sinceId = 56; // Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
        Integer order = 56; // Integer | Sipariş id
        LocalDate startDate = new LocalDate(); // LocalDate | createdAt değeri için başlangıç tarihi
        String endDate = "endDate_example"; // String | createdAt değeri için bitiş tarihi
        LocalDate startUpdatedAt = new LocalDate(); // LocalDate | updatedAt değeri için başlangıç tarihi
        String endUpdatedAt = "endUpdatedAt_example"; // String | updatedAt değeri için bitiş tarihi
        try {
            BillingAddress result = apiInstance.billingAddressesGet(sort, limit, page, sinceId, order, startDate, endDate, startUpdatedAt, endUpdatedAt);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling BillingAddressApi#billingAddressesGet");
            e.printStackTrace();
        }
    }
}

```

## Documentation for API Endpoints

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*BillingAddressApi* | [**billingAddressesGet**](docs/BillingAddressApi.md#billingAddressesGet) | **GET** /billing_addresses | Fatura Adresi Listesi Alma
*BillingAddressApi* | [**billingAddressesIdGet**](docs/BillingAddressApi.md#billingAddressesIdGet) | **GET** /billing_addresses/{id} | Fatura Adresi Alma
*BillingAddressApi* | [**billingAddressesIdPut**](docs/BillingAddressApi.md#billingAddressesIdPut) | **PUT** /billing_addresses/{id} | Fatura Adresi Güncelleme
*BillingAddressApi* | [**billingAddressesPost**](docs/BillingAddressApi.md#billingAddressesPost) | **POST** /billing_addresses | Fatura Adresi Oluşturma
*BrandApi* | [**brandsGet**](docs/BrandApi.md#brandsGet) | **GET** /brands | Marka Listesi Alma
*BrandApi* | [**brandsIdDelete**](docs/BrandApi.md#brandsIdDelete) | **DELETE** /brands/{id} | Marka Silme
*BrandApi* | [**brandsIdGet**](docs/BrandApi.md#brandsIdGet) | **GET** /brands/{id} | Marka Alma
*BrandApi* | [**brandsIdPut**](docs/BrandApi.md#brandsIdPut) | **PUT** /brands/{id} | Marka Güncelleme
*BrandApi* | [**brandsPost**](docs/BrandApi.md#brandsPost) | **POST** /brands | Marka Oluşturma
*CacheApi* | [**cacheDelete**](docs/CacheApi.md#cacheDelete) | **DELETE** /cache | Önbellek Silme
*CartApi* | [**cartsIdDelete**](docs/CartApi.md#cartsIdDelete) | **DELETE** /carts/{id} | Sepet Silme
*CartApi* | [**cartsIdGet**](docs/CartApi.md#cartsIdGet) | **GET** /carts/{id} | Sepet Alma
*CartApi* | [**cartsPost**](docs/CartApi.md#cartsPost) | **POST** /carts | Sepet Oluşturma
*CartItemApi* | [**cartItemsIdDelete**](docs/CartItemApi.md#cartItemsIdDelete) | **DELETE** /cart_items/{id} | Sepet Kalemi Silme
*CartItemApi* | [**cartItemsIdPut**](docs/CartItemApi.md#cartItemsIdPut) | **PUT** /cart_items/{id} | Sepet Kalemi Güncelleme
*CartItemApi* | [**cartItemsPost**](docs/CartItemApi.md#cartItemsPost) | **POST** /cart_items | Sepet Kalemi Oluşturma
*CategoryApi* | [**categoriesGet**](docs/CategoryApi.md#categoriesGet) | **GET** /categories | Kategori Listesi Alma
*CategoryApi* | [**categoriesIdDelete**](docs/CategoryApi.md#categoriesIdDelete) | **DELETE** /categories/{id} | Kategori Silme
*CategoryApi* | [**categoriesIdGet**](docs/CategoryApi.md#categoriesIdGet) | **GET** /categories/{id} | Kategori Alma
*CategoryApi* | [**categoriesIdPut**](docs/CategoryApi.md#categoriesIdPut) | **PUT** /categories/{id} | Kategori Güncelleme
*CategoryApi* | [**categoriesPost**](docs/CategoryApi.md#categoriesPost) | **POST** /categories | Kategori Oluşturma
*CurrencyApi* | [**currenciesGet**](docs/CurrencyApi.md#currenciesGet) | **GET** /currencies | Kur Listesi Alma
*CurrencyApi* | [**currenciesIdGet**](docs/CurrencyApi.md#currenciesIdGet) | **GET** /currencies/{id} | Kur Alma
*CurrencyApi* | [**currenciesIdPut**](docs/CurrencyApi.md#currenciesIdPut) | **PUT** /currencies/{id} | Kur Güncelleme
*CurrentAccountApi* | [**currentAccountsGet**](docs/CurrentAccountApi.md#currentAccountsGet) | **GET** /current_accounts | Cari Hesap Listesi Alma
*CurrentAccountApi* | [**currentAccountsIdDelete**](docs/CurrentAccountApi.md#currentAccountsIdDelete) | **DELETE** /current_accounts/{id} | Cari Hesap Silme
*CurrentAccountApi* | [**currentAccountsIdGet**](docs/CurrentAccountApi.md#currentAccountsIdGet) | **GET** /current_accounts/{id} | Cari Hesap Alma
*CurrentAccountApi* | [**currentAccountsIdPut**](docs/CurrentAccountApi.md#currentAccountsIdPut) | **PUT** /current_accounts/{id} | Cari Hesap Güncelleme
*CurrentAccountApi* | [**currentAccountsPost**](docs/CurrentAccountApi.md#currentAccountsPost) | **POST** /current_accounts | Cari Hesap Oluşturma
*DistributorApi* | [**distributorsGet**](docs/DistributorApi.md#distributorsGet) | **GET** /distributors | Distribütör Listesi Alma
*DistributorApi* | [**distributorsIdDelete**](docs/DistributorApi.md#distributorsIdDelete) | **DELETE** /distributors/{id} | Distribütör Silme
*DistributorApi* | [**distributorsIdGet**](docs/DistributorApi.md#distributorsIdGet) | **GET** /distributors/{id} | Distribütör Alma
*DistributorApi* | [**distributorsIdPut**](docs/DistributorApi.md#distributorsIdPut) | **PUT** /distributors/{id} | Distribütör Güncelleme
*DistributorApi* | [**distributorsPost**](docs/DistributorApi.md#distributorsPost) | **POST** /distributors | Distribütör Oluşturma
*DistributorToProductApi* | [**distributorToProductsGet**](docs/DistributorToProductApi.md#distributorToProductsGet) | **GET** /distributor_to_products | Distribütör Ürün Bağı Listesi Alma
*DistributorToProductApi* | [**distributorToProductsIdDelete**](docs/DistributorToProductApi.md#distributorToProductsIdDelete) | **DELETE** /distributor_to_products/{id} | Distribütör Ürün Bağı Silme
*DistributorToProductApi* | [**distributorToProductsIdGet**](docs/DistributorToProductApi.md#distributorToProductsIdGet) | **GET** /distributor_to_products/{id} | Distribütör Ürün Bağı Alma
*DistributorToProductApi* | [**distributorToProductsIdPut**](docs/DistributorToProductApi.md#distributorToProductsIdPut) | **PUT** /distributor_to_products/{id} | Distribütör Ürün Bağı Güncelleme
*DistributorToProductApi* | [**distributorToProductsPost**](docs/DistributorToProductApi.md#distributorToProductsPost) | **POST** /distributor_to_products | Distribütör Ürün Bağı Oluşturma
*ExtraInfoApi* | [**extraInfosGet**](docs/ExtraInfoApi.md#extraInfosGet) | **GET** /extra_infos | Ek Bilgi Listesi Alma
*ExtraInfoApi* | [**extraInfosIdDelete**](docs/ExtraInfoApi.md#extraInfosIdDelete) | **DELETE** /extra_infos/{id} | Ek Bilgi Silme
*ExtraInfoApi* | [**extraInfosIdGet**](docs/ExtraInfoApi.md#extraInfosIdGet) | **GET** /extra_infos/{id} | Ek Bilgi Alma
*ExtraInfoApi* | [**extraInfosIdPut**](docs/ExtraInfoApi.md#extraInfosIdPut) | **PUT** /extra_infos/{id} | Ek Bilgi Güncelleme
*ExtraInfoApi* | [**extraInfosPost**](docs/ExtraInfoApi.md#extraInfosPost) | **POST** /extra_infos | Ek Bilgi Oluşturma
*ExtraInfoToProductApi* | [**extraInfoToProductsGet**](docs/ExtraInfoToProductApi.md#extraInfoToProductsGet) | **GET** /extra_info_to_products | Ek Bilgi Ürün Bağı Listesi Alma
*ExtraInfoToProductApi* | [**extraInfoToProductsIdDelete**](docs/ExtraInfoToProductApi.md#extraInfoToProductsIdDelete) | **DELETE** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Silme
*ExtraInfoToProductApi* | [**extraInfoToProductsIdGet**](docs/ExtraInfoToProductApi.md#extraInfoToProductsIdGet) | **GET** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Alma
*ExtraInfoToProductApi* | [**extraInfoToProductsIdPut**](docs/ExtraInfoToProductApi.md#extraInfoToProductsIdPut) | **PUT** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Güncelleme
*ExtraInfoToProductApi* | [**extraInfoToProductsPost**](docs/ExtraInfoToProductApi.md#extraInfoToProductsPost) | **POST** /extra_info_to_products | Ek Bilgi Ürün Bağı Oluşturma
*FavouritedProductApi* | [**favouritedProductsGet**](docs/FavouritedProductApi.md#favouritedProductsGet) | **GET** /favourited_products | Favori Ürün Listesi Alma
*FavouritedProductApi* | [**favouritedProductsIdDelete**](docs/FavouritedProductApi.md#favouritedProductsIdDelete) | **DELETE** /favourited_products/{id} | Favori Ürün Silme
*FavouritedProductApi* | [**favouritedProductsIdGet**](docs/FavouritedProductApi.md#favouritedProductsIdGet) | **GET** /favourited_products/{id} | Favori Ürün Alma
*FavouritedProductApi* | [**favouritedProductsIdPut**](docs/FavouritedProductApi.md#favouritedProductsIdPut) | **PUT** /favourited_products/{id} | Favori Ürün Güncelleme
*FavouritedProductApi* | [**favouritedProductsPost**](docs/FavouritedProductApi.md#favouritedProductsPost) | **POST** /favourited_products | Favori Ürün Oluşturma
*InstallmentRateApi* | [**installmentRatesGet**](docs/InstallmentRateApi.md#installmentRatesGet) | **GET** /installment_rates | Taksit Oranı Listesi Alma
*InstallmentRateApi* | [**installmentRatesIdGet**](docs/InstallmentRateApi.md#installmentRatesIdGet) | **GET** /installment_rates/{id} | Taksit Oranı Alma
*LocationApi* | [**locationsGet**](docs/LocationApi.md#locationsGet) | **GET** /locations | Şehir Listesi Alma
*LocationApi* | [**locationsIdGet**](docs/LocationApi.md#locationsIdGet) | **GET** /locations/{id} | Şehir Alma
*MaillistApi* | [**maillistsGet**](docs/MaillistApi.md#maillistsGet) | **GET** /maillists | Mail Listesi Listesi Alma
*MaillistApi* | [**maillistsIdDelete**](docs/MaillistApi.md#maillistsIdDelete) | **DELETE** /maillists/{id} | Mail Listesi Silme
*MaillistApi* | [**maillistsIdGet**](docs/MaillistApi.md#maillistsIdGet) | **GET** /maillists/{id} | Mail Listesi Alma
*MaillistApi* | [**maillistsIdPut**](docs/MaillistApi.md#maillistsIdPut) | **PUT** /maillists/{id} | Mail Listesi Güncelleme
*MaillistApi* | [**maillistsPost**](docs/MaillistApi.md#maillistsPost) | **POST** /maillists | Mail Listesi Oluşturma
*MaillistGroupApi* | [**maillistGroupsGet**](docs/MaillistGroupApi.md#maillistGroupsGet) | **GET** /maillist_groups | Mail Listesi Grubu Listesi Alma
*MaillistGroupApi* | [**maillistGroupsIdDelete**](docs/MaillistGroupApi.md#maillistGroupsIdDelete) | **DELETE** /maillist_groups/{id} | Mail Listesi Grubu Silme
*MaillistGroupApi* | [**maillistGroupsIdGet**](docs/MaillistGroupApi.md#maillistGroupsIdGet) | **GET** /maillist_groups/{id} | Mail Listesi Grubu Alma
*MaillistGroupApi* | [**maillistGroupsIdPut**](docs/MaillistGroupApi.md#maillistGroupsIdPut) | **PUT** /maillist_groups/{id} | Mail Listesi Grubu Güncelleme
*MaillistGroupApi* | [**maillistGroupsPost**](docs/MaillistGroupApi.md#maillistGroupsPost) | **POST** /maillist_groups | Mail Listesi Grubu Oluşturma
*MemberApi* | [**membersChartsGet**](docs/MemberApi.md#membersChartsGet) | **GET** /members/charts | Üye Grafik Aksiyonu
*MemberApi* | [**membersCombinedGet**](docs/MemberApi.md#membersCombinedGet) | **GET** /members/combined | Üye Birleşik Aksiyonu
*MemberApi* | [**membersGet**](docs/MemberApi.md#membersGet) | **GET** /members | Üye Listesi Alma
*MemberApi* | [**membersIdDelete**](docs/MemberApi.md#membersIdDelete) | **DELETE** /members/{id} | Üye Silme
*MemberApi* | [**membersIdGet**](docs/MemberApi.md#membersIdGet) | **GET** /members/{id} | Üye Alma
*MemberApi* | [**membersIdPut**](docs/MemberApi.md#membersIdPut) | **PUT** /members/{id} | Üye Güncelleme
*MemberApi* | [**membersPost**](docs/MemberApi.md#membersPost) | **POST** /members | Üye Oluşturma
*MemberAddressApi* | [**memberAddressesGet**](docs/MemberAddressApi.md#memberAddressesGet) | **GET** /member_addresses | Üye Adresi Listeleme
*MemberAddressApi* | [**memberAddressesIdDelete**](docs/MemberAddressApi.md#memberAddressesIdDelete) | **DELETE** /member_addresses/{id} | Üye Adresi Silme
*MemberAddressApi* | [**memberAddressesIdGet**](docs/MemberAddressApi.md#memberAddressesIdGet) | **GET** /member_addresses/{id} | Üye Adresi Alma
*MemberAddressApi* | [**memberAddressesIdPut**](docs/MemberAddressApi.md#memberAddressesIdPut) | **PUT** /member_addresses/{id} | Üye Adresi Güncelleme
*MemberAddressApi* | [**memberAddressesPost**](docs/MemberAddressApi.md#memberAddressesPost) | **POST** /member_addresses | Üye Adresi Oluşturma
*MemberGroupApi* | [**memberGroupsGet**](docs/MemberGroupApi.md#memberGroupsGet) | **GET** /member_groups | Üye Grubu Listesi Alma
*MemberGroupApi* | [**memberGroupsIdDelete**](docs/MemberGroupApi.md#memberGroupsIdDelete) | **DELETE** /member_groups/{id} | Üye Grubu Silme
*MemberGroupApi* | [**memberGroupsIdGet**](docs/MemberGroupApi.md#memberGroupsIdGet) | **GET** /member_groups/{id} | Üye Grubu Alma
*MemberGroupApi* | [**memberGroupsIdPut**](docs/MemberGroupApi.md#memberGroupsIdPut) | **PUT** /member_groups/{id} | Üye Grubu Güncelleme
*MemberGroupApi* | [**memberGroupsPost**](docs/MemberGroupApi.md#memberGroupsPost) | **POST** /member_groups | Üye Grubu Oluşturma
*OptionGroupApi* | [**optionGroupsGet**](docs/OptionGroupApi.md#optionGroupsGet) | **GET** /option_groups | Varyant Grubu Listesi Alma
*OptionGroupApi* | [**optionGroupsIdDelete**](docs/OptionGroupApi.md#optionGroupsIdDelete) | **DELETE** /option_groups/{id} | Varyant Grubu Silme
*OptionGroupApi* | [**optionGroupsIdGet**](docs/OptionGroupApi.md#optionGroupsIdGet) | **GET** /option_groups/{id} | Varyant Grubu Alma
*OptionGroupApi* | [**optionGroupsIdPut**](docs/OptionGroupApi.md#optionGroupsIdPut) | **PUT** /option_groups/{id} | Varyant Grubu Güncelleme
*OptionGroupApi* | [**optionGroupsPost**](docs/OptionGroupApi.md#optionGroupsPost) | **POST** /option_groups | Varyant Grubu Oluşturma
*OptionToProductApi* | [**optionToProductsGet**](docs/OptionToProductApi.md#optionToProductsGet) | **GET** /option_to_products | Varyant Ürün Bağı Listesi Alma
*OptionToProductApi* | [**optionToProductsIdDelete**](docs/OptionToProductApi.md#optionToProductsIdDelete) | **DELETE** /option_to_products/{id} | Varyant Ürün Bağı Silme
*OptionToProductApi* | [**optionToProductsIdGet**](docs/OptionToProductApi.md#optionToProductsIdGet) | **GET** /option_to_products/{id} | Varyant Ürün Bağı Alma
*OptionToProductApi* | [**optionToProductsIdPut**](docs/OptionToProductApi.md#optionToProductsIdPut) | **PUT** /option_to_products/{id} | Varyant Ürün Bağı Güncelleme
*OptionToProductApi* | [**optionToProductsPost**](docs/OptionToProductApi.md#optionToProductsPost) | **POST** /option_to_products | Varyant Ürün Bağı Oluşturma
*OptionsApi* | [**optionsGet**](docs/OptionsApi.md#optionsGet) | **GET** /options | Varyant Listesi Alma
*OptionsApi* | [**optionsIdDelete**](docs/OptionsApi.md#optionsIdDelete) | **DELETE** /options/{id} | Varyant Silme
*OptionsApi* | [**optionsIdGet**](docs/OptionsApi.md#optionsIdGet) | **GET** /options/{id} | Varyant Alma
*OptionsApi* | [**optionsIdPut**](docs/OptionsApi.md#optionsIdPut) | **PUT** /options/{id} | Varyant Güncelleme
*OptionsApi* | [**optionsPost**](docs/OptionsApi.md#optionsPost) | **POST** /options | Varyant Oluşturma
*OrderApi* | [**ordersGet**](docs/OrderApi.md#ordersGet) | **GET** /orders | Sipariş Listesi Alma
*OrderApi* | [**ordersIdDelete**](docs/OrderApi.md#ordersIdDelete) | **DELETE** /orders/{id} | Sipariş Silme
*OrderApi* | [**ordersIdGet**](docs/OrderApi.md#ordersIdGet) | **GET** /orders/{id} | Sipariş Alma
*OrderApi* | [**ordersIdPut**](docs/OrderApi.md#ordersIdPut) | **PUT** /orders/{id} | Sipariş Güncelleme
*OrderApi* | [**ordersPost**](docs/OrderApi.md#ordersPost) | **POST** /orders | Sipariş Oluşturma
*OrderDetailApi* | [**orderDetailsGet**](docs/OrderDetailApi.md#orderDetailsGet) | **GET** /order_details | Sipariş Detayı Listesi Alma
*OrderDetailApi* | [**orderDetailsIdDelete**](docs/OrderDetailApi.md#orderDetailsIdDelete) | **DELETE** /order_details/{id} | Sipariş Detayı Silme
*OrderDetailApi* | [**orderDetailsIdGet**](docs/OrderDetailApi.md#orderDetailsIdGet) | **GET** /order_details/{id} | Sipariş Detayı Alma
*OrderDetailApi* | [**orderDetailsIdPut**](docs/OrderDetailApi.md#orderDetailsIdPut) | **PUT** /order_details/{id} | Sipariş Detayı Güncelleme
*OrderDetailApi* | [**orderDetailsPost**](docs/OrderDetailApi.md#orderDetailsPost) | **POST** /order_details | Sipariş Detayı Oluşturma
*OrderItemApi* | [**orderItemsGet**](docs/OrderItemApi.md#orderItemsGet) | **GET** /order_items | Sipariş Kalemi Listesi Alma
*OrderItemApi* | [**orderItemsIdGet**](docs/OrderItemApi.md#orderItemsIdGet) | **GET** /order_items/{id} | Sipariş Kalemi Alma
*OrderRefundRequestApi* | [**orderRefundRequestsGet**](docs/OrderRefundRequestApi.md#orderRefundRequestsGet) | **GET** /order_refund_requests | Sipariş İptal Talebi Listesi Alma
*OrderRefundRequestApi* | [**orderRefundRequestsIdDelete**](docs/OrderRefundRequestApi.md#orderRefundRequestsIdDelete) | **DELETE** /order_refund_requests/{id} | Sipariş İptal Talebi Silme
*OrderRefundRequestApi* | [**orderRefundRequestsIdGet**](docs/OrderRefundRequestApi.md#orderRefundRequestsIdGet) | **GET** /order_refund_requests/{id} | Sipariş İptal Talebi Alma
*OrderRefundRequestApi* | [**orderRefundRequestsIdPut**](docs/OrderRefundRequestApi.md#orderRefundRequestsIdPut) | **PUT** /order_refund_requests/{id} | Sipariş İptal Talebi Güncelleme
*OrderRefundRequestApi* | [**orderRefundRequestsPost**](docs/OrderRefundRequestApi.md#orderRefundRequestsPost) | **POST** /order_refund_requests | Sipariş İptal Talebi Oluşturma
*OrderRefundRequestItemApi* | [**orderRefundRequestItemsGet**](docs/OrderRefundRequestItemApi.md#orderRefundRequestItemsGet) | **GET** /order_refund_request_items | Sipariş İptal Talebi Kalemi Listesi Alma
*OrderRefundRequestItemApi* | [**orderRefundRequestItemsIdDelete**](docs/OrderRefundRequestItemApi.md#orderRefundRequestItemsIdDelete) | **DELETE** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Silme
*OrderRefundRequestItemApi* | [**orderRefundRequestItemsIdGet**](docs/OrderRefundRequestItemApi.md#orderRefundRequestItemsIdGet) | **GET** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Alma
*OrderRefundRequestItemApi* | [**orderRefundRequestItemsIdPut**](docs/OrderRefundRequestItemApi.md#orderRefundRequestItemsIdPut) | **PUT** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Güncelleme
*OrderRefundRequestItemApi* | [**orderRefundRequestItemsPost**](docs/OrderRefundRequestItemApi.md#orderRefundRequestItemsPost) | **POST** /order_refund_request_items | Sipariş İptal Talebi Kalemi Oluşturma
*OrderUserNoteApi* | [**orderUserNotesGet**](docs/OrderUserNoteApi.md#orderUserNotesGet) | **GET** /order_user_notes | Sipariş Yönetici Notu Listesi Alma
*OrderUserNoteApi* | [**orderUserNotesIdDelete**](docs/OrderUserNoteApi.md#orderUserNotesIdDelete) | **DELETE** /order_user_notes/{id} | Sipariş Yönetici Notu Silme
*OrderUserNoteApi* | [**orderUserNotesIdGet**](docs/OrderUserNoteApi.md#orderUserNotesIdGet) | **GET** /order_user_notes/{id} | Sipariş Yönetici Notu Alma
*OrderUserNoteApi* | [**orderUserNotesIdPut**](docs/OrderUserNoteApi.md#orderUserNotesIdPut) | **PUT** /order_user_notes/{id} | Sipariş Yönetici Notu Güncelleme
*OrderUserNoteApi* | [**orderUserNotesPost**](docs/OrderUserNoteApi.md#orderUserNotesPost) | **POST** /order_user_notes | Sipariş Yönetici Notu Oluşturma
*PaymentApi* | [**paymentsGet**](docs/PaymentApi.md#paymentsGet) | **GET** /payments | Ödeme Listesi Alma
*PaymentApi* | [**paymentsIdDelete**](docs/PaymentApi.md#paymentsIdDelete) | **DELETE** /payments/{id} | Ödeme Silme
*PaymentApi* | [**paymentsIdGet**](docs/PaymentApi.md#paymentsIdGet) | **GET** /payments/{id} | Ödeme Alma
*PaymentApi* | [**paymentsIdPut**](docs/PaymentApi.md#paymentsIdPut) | **PUT** /payments/{id} | Ödeme Güncelleme
*PaymentApi* | [**paymentsPost**](docs/PaymentApi.md#paymentsPost) | **POST** /payments | Ödeme Oluşturma
*PaymentGatewayApi* | [**paymentGatewaysGet**](docs/PaymentGatewayApi.md#paymentGatewaysGet) | **GET** /payment_gateways | Ödeme Kanalı Listesi Alma
*PaymentGatewayApi* | [**paymentGatewaysIdGet**](docs/PaymentGatewayApi.md#paymentGatewaysIdGet) | **GET** /payment_gateways/{id} | Ödeme Kanalı Alma
*PaymentProviderApi* | [**paymentProvidersGet**](docs/PaymentProviderApi.md#paymentProvidersGet) | **GET** /payment_providers | Ödeme Altyapısı Sağlayıcısı Listesi Alma
*PaymentProviderApi* | [**paymentProvidersIdGet**](docs/PaymentProviderApi.md#paymentProvidersIdGet) | **GET** /payment_providers/{id} | Ödeme Altyapısı Sağlayıcısı Alma
*PreOrderInfoApi* | [**preOrderInfosGet**](docs/PreOrderInfoApi.md#preOrderInfosGet) | **GET** /pre_order_infos | Sipariş Öncesi Bilgisi Listesi Alma
*PreOrderInfoApi* | [**preOrderInfosIdDelete**](docs/PreOrderInfoApi.md#preOrderInfosIdDelete) | **DELETE** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Silme
*PreOrderInfoApi* | [**preOrderInfosIdGet**](docs/PreOrderInfoApi.md#preOrderInfosIdGet) | **GET** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Alma
*PreOrderInfoApi* | [**preOrderInfosIdPut**](docs/PreOrderInfoApi.md#preOrderInfosIdPut) | **PUT** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Güncelleme
*PreOrderInfoApi* | [**preOrderInfosPost**](docs/PreOrderInfoApi.md#preOrderInfosPost) | **POST** /pre_order_infos | Sipariş Öncesi Bilgisi Oluşturma
*ProductApi* | [**productsGet**](docs/ProductApi.md#productsGet) | **GET** /products | Ürün Listesi Alma
*ProductApi* | [**productsIdDelete**](docs/ProductApi.md#productsIdDelete) | **DELETE** /products/{id} | Ürün Silme
*ProductApi* | [**productsIdGet**](docs/ProductApi.md#productsIdGet) | **GET** /products/{id} | Ürün Alma
*ProductApi* | [**productsIdPut**](docs/ProductApi.md#productsIdPut) | **PUT** /products/{id} | Ürün Güncelleme
*ProductApi* | [**productsPost**](docs/ProductApi.md#productsPost) | **POST** /products | Ürün Oluşturma
*ProductButtonApi* | [**productButtonsGet**](docs/ProductButtonApi.md#productButtonsGet) | **GET** /product_buttons | Ürün ve Stok Butonu Listesi Alma
*ProductButtonApi* | [**productButtonsIdDelete**](docs/ProductButtonApi.md#productButtonsIdDelete) | **DELETE** /product_buttons/{id} | Ürün ve Stok Butonu Silme
*ProductButtonApi* | [**productButtonsIdGet**](docs/ProductButtonApi.md#productButtonsIdGet) | **GET** /product_buttons/{id} | Ürün ve Stok Butonu Alma
*ProductButtonApi* | [**productButtonsIdPut**](docs/ProductButtonApi.md#productButtonsIdPut) | **PUT** /product_buttons/{id} | Ürün ve Stok Butonu Güncelleme
*ProductButtonApi* | [**productButtonsPost**](docs/ProductButtonApi.md#productButtonsPost) | **POST** /product_buttons | Ürün ve Stok Butonu Oluşturma
*ProductDetailApi* | [**productDetailsGet**](docs/ProductDetailApi.md#productDetailsGet) | **GET** /product_details | Ürün Detay Listesi Alma
*ProductDetailApi* | [**productDetailsIdDelete**](docs/ProductDetailApi.md#productDetailsIdDelete) | **DELETE** /product_details/{id} | Ürün Detay Silme
*ProductDetailApi* | [**productDetailsIdGet**](docs/ProductDetailApi.md#productDetailsIdGet) | **GET** /product_details/{id} | Ürün Detay Alma
*ProductDetailApi* | [**productDetailsIdPut**](docs/ProductDetailApi.md#productDetailsIdPut) | **PUT** /product_details/{id} | Ürün Detay Güncelleme
*ProductDetailApi* | [**productDetailsPost**](docs/ProductDetailApi.md#productDetailsPost) | **POST** /product_details | Ürün Detay Oluşturma
*ProductImageApi* | [**productImagesGet**](docs/ProductImageApi.md#productImagesGet) | **GET** /product_images | Ürün Resim Listesi Alma
*ProductImageApi* | [**productImagesIdDelete**](docs/ProductImageApi.md#productImagesIdDelete) | **DELETE** /product_images/{id} | Ürün Resim Silme
*ProductImageApi* | [**productImagesIdGet**](docs/ProductImageApi.md#productImagesIdGet) | **GET** /product_images/{id} | Ürün Resim Alma
*ProductImageApi* | [**productImagesPost**](docs/ProductImageApi.md#productImagesPost) | **POST** /product_images | Ürün Resim Oluşturma
*ProductPriceApi* | [**productPricesGet**](docs/ProductPriceApi.md#productPricesGet) | **GET** /product_prices | Ürün Fiyat Listesi Alma
*ProductPriceApi* | [**productPricesIdDelete**](docs/ProductPriceApi.md#productPricesIdDelete) | **DELETE** /product_prices/{id} | Ürün Fiyat Silme
*ProductPriceApi* | [**productPricesIdGet**](docs/ProductPriceApi.md#productPricesIdGet) | **GET** /product_prices/{id} | Ürün Fiyat Alma
*ProductPriceApi* | [**productPricesIdPut**](docs/ProductPriceApi.md#productPricesIdPut) | **PUT** /product_prices/{id} | Ürün Fiyat Güncelleme
*ProductPriceApi* | [**productPricesPost**](docs/ProductPriceApi.md#productPricesPost) | **POST** /product_prices | Ürün Fiyat Oluşturma
*ProductProtectionApi* | [**productProtectionsGet**](docs/ProductProtectionApi.md#productProtectionsGet) | **GET** /product_protections | Entegrasyon Seçeneği Listesi Alma
*ProductProtectionApi* | [**productProtectionsIdDelete**](docs/ProductProtectionApi.md#productProtectionsIdDelete) | **DELETE** /product_protections/{id} | Entegrasyon Seçeneği Silme
*ProductProtectionApi* | [**productProtectionsIdGet**](docs/ProductProtectionApi.md#productProtectionsIdGet) | **GET** /product_protections/{id} | Entegrasyon Seçeneği Alma
*ProductProtectionApi* | [**productProtectionsIdPut**](docs/ProductProtectionApi.md#productProtectionsIdPut) | **PUT** /product_protections/{id} | Entegrasyon Seçeneği Güncelleme
*ProductProtectionApi* | [**productProtectionsPost**](docs/ProductProtectionApi.md#productProtectionsPost) | **POST** /product_protections | Entegrasyon Seçeneği Oluşturma
*ProductSpecialInfoApi* | [**productSpecialInfosGet**](docs/ProductSpecialInfoApi.md#productSpecialInfosGet) | **GET** /product_special_infos | Ürün Özel Bilgi Alanı Listesi Alma
*ProductSpecialInfoApi* | [**productSpecialInfosIdDelete**](docs/ProductSpecialInfoApi.md#productSpecialInfosIdDelete) | **DELETE** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
*ProductSpecialInfoApi* | [**productSpecialInfosIdGet**](docs/ProductSpecialInfoApi.md#productSpecialInfosIdGet) | **GET** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
*ProductSpecialInfoApi* | [**productSpecialInfosIdPut**](docs/ProductSpecialInfoApi.md#productSpecialInfosIdPut) | **PUT** /product_special_infos/{id} | Ürün Özel Bilgi Alanı Güncelleme
*ProductSpecialInfoApi* | [**productSpecialInfosPost**](docs/ProductSpecialInfoApi.md#productSpecialInfosPost) | **POST** /product_special_infos | Ürün Özel Bilgi Alanı Oluşturma
*ProductToCategoryApi* | [**productToCategoriesGet**](docs/ProductToCategoryApi.md#productToCategoriesGet) | **GET** /product_to_categories | Ürün Kategori Bağı Listesi Alma
*ProductToCategoryApi* | [**productToCategoriesIdDelete**](docs/ProductToCategoryApi.md#productToCategoriesIdDelete) | **DELETE** /product_to_categories/{id} | Ürün Kategori Bağı Silme
*ProductToCategoryApi* | [**productToCategoriesIdGet**](docs/ProductToCategoryApi.md#productToCategoriesIdGet) | **GET** /product_to_categories/{id} | Ürün Kategori Bağı Alma
*ProductToCategoryApi* | [**productToCategoriesIdPut**](docs/ProductToCategoryApi.md#productToCategoriesIdPut) | **PUT** /product_to_categories/{id} | Ürün Kategori Bağı Güncelleme
*ProductToCategoryApi* | [**productToCategoriesPost**](docs/ProductToCategoryApi.md#productToCategoriesPost) | **POST** /product_to_categories | Ürün Kategori Bağı Oluşturma
*ProductToCountDownApi* | [**productToCountDownsGet**](docs/ProductToCountDownApi.md#productToCountDownsGet) | **GET** /product_to_count_downs | Ürün Geri Sayım Bağı Listesi Alma
*ProductToCountDownApi* | [**productToCountDownsIdDelete**](docs/ProductToCountDownApi.md#productToCountDownsIdDelete) | **DELETE** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Silme
*ProductToCountDownApi* | [**productToCountDownsIdGet**](docs/ProductToCountDownApi.md#productToCountDownsIdGet) | **GET** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Alma
*ProductToCountDownApi* | [**productToCountDownsIdPut**](docs/ProductToCountDownApi.md#productToCountDownsIdPut) | **PUT** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Güncelleme
*ProductToCountDownApi* | [**productToCountDownsPost**](docs/ProductToCountDownApi.md#productToCountDownsPost) | **POST** /product_to_count_downs | Ürün Geri Sayım Bağı Oluşturma
*ProductToTagApi* | [**productToTagsGet**](docs/ProductToTagApi.md#productToTagsGet) | **GET** /product_to_tags | Ürün SEO+ Bağı Listesi Alma
*ProductToTagApi* | [**productToTagsIdDelete**](docs/ProductToTagApi.md#productToTagsIdDelete) | **DELETE** /product_to_tags/{id} | Ürün SEO+ Bağı Silme
*ProductToTagApi* | [**productToTagsIdGet**](docs/ProductToTagApi.md#productToTagsIdGet) | **GET** /product_to_tags/{id} | Ürün SEO+ Bağı Alma
*ProductToTagApi* | [**productToTagsIdPut**](docs/ProductToTagApi.md#productToTagsIdPut) | **PUT** /product_to_tags/{id} | Ürün SEO+ Bağı Güncelleme
*ProductToTagApi* | [**productToTagsPost**](docs/ProductToTagApi.md#productToTagsPost) | **POST** /product_to_tags | Ürün SEO+ Bağı Oluşturma
*QuickCartApi* | [**quickCartsGet**](docs/QuickCartApi.md#quickCartsGet) | **GET** /quick_carts | Hızlı Satın Al Bağlantısı Alma
*QuickCartApi* | [**quickCartsIdDelete**](docs/QuickCartApi.md#quickCartsIdDelete) | **DELETE** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Silme
*QuickCartApi* | [**quickCartsIdGet**](docs/QuickCartApi.md#quickCartsIdGet) | **GET** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Alma
*QuickCartApi* | [**quickCartsIdPut**](docs/QuickCartApi.md#quickCartsIdPut) | **PUT** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Güncelleme
*QuickCartApi* | [**quickCartsPost**](docs/QuickCartApi.md#quickCartsPost) | **POST** /quick_carts | Hızlı Satın Al Bağlantısı Oluşturma
*RegionApi* | [**regionsGet**](docs/RegionApi.md#regionsGet) | **GET** /regions | Bölge Listesi Alma
*RegionApi* | [**regionsIdGet**](docs/RegionApi.md#regionsIdGet) | **GET** /regions/{id} | Bölge Alma
*SelectionApi* | [**selectionsGet**](docs/SelectionApi.md#selectionsGet) | **GET** /selections | Ek Özellik Listesi Alma
*SelectionApi* | [**selectionsIdDelete**](docs/SelectionApi.md#selectionsIdDelete) | **DELETE** /selections/{id} | Ek Özellik Silme
*SelectionApi* | [**selectionsIdGet**](docs/SelectionApi.md#selectionsIdGet) | **GET** /selections/{id} | Ek Özellik Alma
*SelectionApi* | [**selectionsIdPut**](docs/SelectionApi.md#selectionsIdPut) | **PUT** /selections/{id} | Ek Özellik Güncelleme
*SelectionApi* | [**selectionsPost**](docs/SelectionApi.md#selectionsPost) | **POST** /selections | Ek Özellik Oluşturma
*SelectionGroupApi* | [**selectionGroupsGet**](docs/SelectionGroupApi.md#selectionGroupsGet) | **GET** /selection_groups | Ek Özellik Grubu Listesi Alma
*SelectionGroupApi* | [**selectionGroupsIdDelete**](docs/SelectionGroupApi.md#selectionGroupsIdDelete) | **DELETE** /selection_groups/{id} | Ek Özellik Grubu Silme
*SelectionGroupApi* | [**selectionGroupsIdGet**](docs/SelectionGroupApi.md#selectionGroupsIdGet) | **GET** /selection_groups/{id} | Ek Özellik Grubu Alma
*SelectionGroupApi* | [**selectionGroupsIdPut**](docs/SelectionGroupApi.md#selectionGroupsIdPut) | **PUT** /selection_groups/{id} | Ek Özellik Grubu Güncelleme
*SelectionGroupApi* | [**selectionGroupsPost**](docs/SelectionGroupApi.md#selectionGroupsPost) | **POST** /selection_groups | Ek Özellik Grubu Oluşturma
*SelectionToProductApi* | [**selectionToProductsGet**](docs/SelectionToProductApi.md#selectionToProductsGet) | **GET** /selection_to_products | Ek Özellik Ürün Bağı Listesi Alma
*SelectionToProductApi* | [**selectionToProductsIdDelete**](docs/SelectionToProductApi.md#selectionToProductsIdDelete) | **DELETE** /selection_to_products/{id} | Ek Özellik Ürün Bağı Silme
*SelectionToProductApi* | [**selectionToProductsIdGet**](docs/SelectionToProductApi.md#selectionToProductsIdGet) | **GET** /selection_to_products/{id} | Ek Özellik Ürün Bağı Alma
*SelectionToProductApi* | [**selectionToProductsIdPut**](docs/SelectionToProductApi.md#selectionToProductsIdPut) | **PUT** /selection_to_products/{id} | Ek Özellik Ürün Bağı Güncelleme
*SelectionToProductApi* | [**selectionToProductsPost**](docs/SelectionToProductApi.md#selectionToProductsPost) | **POST** /selection_to_products | Ek Özellik Ürün Bağı Oluşturma
*ShipmentApi* | [**shipmentsGet**](docs/ShipmentApi.md#shipmentsGet) | **GET** /shipments | Teslimat Listesi Alma
*ShipmentApi* | [**shipmentsIdDelete**](docs/ShipmentApi.md#shipmentsIdDelete) | **DELETE** /shipments/{id} | Teslimat Silme
*ShipmentApi* | [**shipmentsIdGet**](docs/ShipmentApi.md#shipmentsIdGet) | **GET** /shipments/{id} | Teslimat Alma
*ShipmentApi* | [**shipmentsIdPut**](docs/ShipmentApi.md#shipmentsIdPut) | **PUT** /shipments/{id} | Teslimat Güncelleme
*ShipmentApi* | [**shipmentsPost**](docs/ShipmentApi.md#shipmentsPost) | **POST** /shipments | Teslimat Oluşturma
*ShipmentItemApi* | [**shipmentItemsGet**](docs/ShipmentItemApi.md#shipmentItemsGet) | **GET** /shipment_items | Teslimat Kalemi Listesi Alma
*ShipmentItemApi* | [**shipmentItemsIdDelete**](docs/ShipmentItemApi.md#shipmentItemsIdDelete) | **DELETE** /shipment_items/{id} | Teslimat Kalemi Silme
*ShipmentItemApi* | [**shipmentItemsIdGet**](docs/ShipmentItemApi.md#shipmentItemsIdGet) | **GET** /shipment_items/{id} | Teslimat Kalemi Alma
*ShipmentItemApi* | [**shipmentItemsIdPut**](docs/ShipmentItemApi.md#shipmentItemsIdPut) | **PUT** /shipment_items/{id} | Teslimat Kalemi Güncelleme
*ShipmentItemApi* | [**shipmentItemsPost**](docs/ShipmentItemApi.md#shipmentItemsPost) | **POST** /shipment_items | Teslimat Kalemi Oluşturma
*ShippingAddressApi* | [**shippingAddressesGet**](docs/ShippingAddressApi.md#shippingAddressesGet) | **GET** /shipping_addresses | Teslimat Adresi Listesi Alma
*ShippingAddressApi* | [**shippingAddressesIdGet**](docs/ShippingAddressApi.md#shippingAddressesIdGet) | **GET** /shipping_addresses/{id} | Teslimat Adresi Alma
*ShippingAddressApi* | [**shippingAddressesIdPut**](docs/ShippingAddressApi.md#shippingAddressesIdPut) | **PUT** /shipping_addresses/{id} | Teslimat Adresi Güncelleme
*ShippingAddressApi* | [**shippingAddressesPost**](docs/ShippingAddressApi.md#shippingAddressesPost) | **POST** /shipping_addresses | Teslimat Adresi Oluşturma
*ShippingCompanyApi* | [**shippingCompaniesGet**](docs/ShippingCompanyApi.md#shippingCompaniesGet) | **GET** /shipping_companies | Kargo Firması Listesi Alma
*ShippingCompanyApi* | [**shippingCompaniesIdDelete**](docs/ShippingCompanyApi.md#shippingCompaniesIdDelete) | **DELETE** /shipping_companies/{id} | Kargo Firması Silme
*ShippingCompanyApi* | [**shippingCompaniesIdGet**](docs/ShippingCompanyApi.md#shippingCompaniesIdGet) | **GET** /shipping_companies/{id} | Kargo Firması Alma
*ShippingCompanyApi* | [**shippingCompaniesIdPut**](docs/ShippingCompanyApi.md#shippingCompaniesIdPut) | **PUT** /shipping_companies/{id} | Kargo Firması Güncelleme
*ShippingCompanyApi* | [**shippingCompaniesPost**](docs/ShippingCompanyApi.md#shippingCompaniesPost) | **POST** /shipping_companies | Kargo Firması Oluşturma
*ShippingProviderApi* | [**shippingProvidersGet**](docs/ShippingProviderApi.md#shippingProvidersGet) | **GET** /shipping_providers | Teslimat Hizmeti Sağlayıcısı Listesi Alma
*ShippingProviderApi* | [**shippingProvidersIdGet**](docs/ShippingProviderApi.md#shippingProvidersIdGet) | **GET** /shipping_providers/{id} | Teslimat Hizmeti Sağlayıcısı Alma
*ShippingRateApi* | [**shippingRatesGet**](docs/ShippingRateApi.md#shippingRatesGet) | **GET** /shipping_rates | Kargo Oranı Listesi Alma
*ShippingRateApi* | [**shippingRatesIdDelete**](docs/ShippingRateApi.md#shippingRatesIdDelete) | **DELETE** /shipping_rates/{id} | Kargo Oranı Silme
*ShippingRateApi* | [**shippingRatesIdGet**](docs/ShippingRateApi.md#shippingRatesIdGet) | **GET** /shipping_rates/{id} | Kargo Oranı Alma
*ShippingRateApi* | [**shippingRatesIdPut**](docs/ShippingRateApi.md#shippingRatesIdPut) | **PUT** /shipping_rates/{id} | Kargo Oranı Güncelleme
*ShippingRateApi* | [**shippingRatesPost**](docs/ShippingRateApi.md#shippingRatesPost) | **POST** /shipping_rates | Kargo Oranı Oluşturma
*ShopPreferenceApi* | [**preferencesGet**](docs/ShopPreferenceApi.md#preferencesGet) | **GET** /preferences | Tanımlamalar Listesi Alma
*ShopPreferenceApi* | [**preferencesIdGet**](docs/ShopPreferenceApi.md#preferencesIdGet) | **GET** /preferences/{id} | Tanımlamalar Alma
*ShopPreferenceApi* | [**preferencesIdPut**](docs/ShopPreferenceApi.md#preferencesIdPut) | **PUT** /preferences/{id} | Tanımlamalar Güncelleme
*SpecGroupApi* | [**specGroupsGet**](docs/SpecGroupApi.md#specGroupsGet) | **GET** /spec_groups | Ürün Özellik Grubu Listesi Alma
*SpecGroupApi* | [**specGroupsIdDelete**](docs/SpecGroupApi.md#specGroupsIdDelete) | **DELETE** /spec_groups/{id} | Ürün Özellik Grubu Silme
*SpecGroupApi* | [**specGroupsIdGet**](docs/SpecGroupApi.md#specGroupsIdGet) | **GET** /spec_groups/{id} | Ürün Özellik Grubu Alma
*SpecGroupApi* | [**specGroupsIdPut**](docs/SpecGroupApi.md#specGroupsIdPut) | **PUT** /spec_groups/{id} | Ürün Özellik Grubu Güncelleme
*SpecGroupApi* | [**specGroupsPost**](docs/SpecGroupApi.md#specGroupsPost) | **POST** /spec_groups | Ürün Özellik Grubu Oluşturma
*SpecNameApi* | [**specNamesGet**](docs/SpecNameApi.md#specNamesGet) | **GET** /spec_names | Ürün Özelliği Listesi Alma
*SpecNameApi* | [**specNamesIdDelete**](docs/SpecNameApi.md#specNamesIdDelete) | **DELETE** /spec_names/{id} | Ürün Özelliği Silme
*SpecNameApi* | [**specNamesIdGet**](docs/SpecNameApi.md#specNamesIdGet) | **GET** /spec_names/{id} | Ürün Özelliği Alma
*SpecNameApi* | [**specNamesIdPut**](docs/SpecNameApi.md#specNamesIdPut) | **PUT** /spec_names/{id} | Ürün Özelliği Güncelleme
*SpecNameApi* | [**specNamesPost**](docs/SpecNameApi.md#specNamesPost) | **POST** /spec_names | Ürün Özelliği Oluşturma
*SpecToProductApi* | [**specToProductsGet**](docs/SpecToProductApi.md#specToProductsGet) | **GET** /spec_to_products | Ürün Özellik Ürün Bağı Listesi Alma
*SpecToProductApi* | [**specToProductsIdDelete**](docs/SpecToProductApi.md#specToProductsIdDelete) | **DELETE** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Silme
*SpecToProductApi* | [**specToProductsIdGet**](docs/SpecToProductApi.md#specToProductsIdGet) | **GET** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Alma
*SpecToProductApi* | [**specToProductsIdPut**](docs/SpecToProductApi.md#specToProductsIdPut) | **PUT** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Güncelleme
*SpecToProductApi* | [**specToProductsPost**](docs/SpecToProductApi.md#specToProductsPost) | **POST** /spec_to_products | Ürün Özellik Ürün Bağı Oluşturma
*SpecValueApi* | [**specValuesGet**](docs/SpecValueApi.md#specValuesGet) | **GET** /spec_values | Ürün Özellik Değeri Listesi Alma
*SpecValueApi* | [**specValuesIdDelete**](docs/SpecValueApi.md#specValuesIdDelete) | **DELETE** /spec_values/{id} | Ürün Özellik Değeri Silme
*SpecValueApi* | [**specValuesIdGet**](docs/SpecValueApi.md#specValuesIdGet) | **GET** /spec_values/{id} | Ürün Özellik Değeri Alma
*SpecValueApi* | [**specValuesIdPut**](docs/SpecValueApi.md#specValuesIdPut) | **PUT** /spec_values/{id} | Ürün Özellik Değeri Güncelleme
*SpecValueApi* | [**specValuesPost**](docs/SpecValueApi.md#specValuesPost) | **POST** /spec_values | Ürün Özellik Değeri Oluşturma
*TagApi* | [**tagsGet**](docs/TagApi.md#tagsGet) | **GET** /tags | SEO+ Etiketi Listesi Alma
*TagApi* | [**tagsIdDelete**](docs/TagApi.md#tagsIdDelete) | **DELETE** /tags/{id} | SEO+ Etiketi Silme
*TagApi* | [**tagsIdGet**](docs/TagApi.md#tagsIdGet) | **GET** /tags/{id} | SEO+ Etiketi Alma
*TagApi* | [**tagsIdPut**](docs/TagApi.md#tagsIdPut) | **PUT** /tags/{id} | SEO+ Etiketi Güncelleme
*TagApi* | [**tagsPost**](docs/TagApi.md#tagsPost) | **POST** /tags | SEO+ Etiketi Oluşturma
*ThemeApi* | [**themesGet**](docs/ThemeApi.md#themesGet) | **GET** /themes | Tema Listesi Alma
*ThemeApi* | [**themesIdAssetsGet**](docs/ThemeApi.md#themesIdAssetsGet) | **GET** /themes/{id}/assets | Tema Dosyası Listesi Alma
*ThemeApi* | [**themesIdAssetskeykeyDelete**](docs/ThemeApi.md#themesIdAssetskeykeyDelete) | **DELETE** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Silme
*ThemeApi* | [**themesIdAssetskeykeyGet**](docs/ThemeApi.md#themesIdAssetskeykeyGet) | **GET** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Alma
*ThemeApi* | [**themesIdAssetskeykeyPut**](docs/ThemeApi.md#themesIdAssetskeykeyPut) | **PUT** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Güncelleme
*ThemeApi* | [**themesIdDelete**](docs/ThemeApi.md#themesIdDelete) | **DELETE** /themes/{id} | Tema Silme
*ThemeApi* | [**themesIdGet**](docs/ThemeApi.md#themesIdGet) | **GET** /themes/{id} | Tema Alma
*ThemeApi* | [**themesIdPut**](docs/ThemeApi.md#themesIdPut) | **PUT** /themes/{id} | Tema Güncelleme
*ThemeApi* | [**themesPost**](docs/ThemeApi.md#themesPost) | **POST** /themes | Tema Oluşturma
*TownApi* | [**townsGet**](docs/TownApi.md#townsGet) | **GET** /towns | İlçe Listesi Alma
*TownApi* | [**townsIdDelete**](docs/TownApi.md#townsIdDelete) | **DELETE** /towns/{id} | İlçe Silme
*TownApi* | [**townsIdGet**](docs/TownApi.md#townsIdGet) | **GET** /towns/{id} | İlçe Alma
*TownApi* | [**townsIdPut**](docs/TownApi.md#townsIdPut) | **PUT** /towns/{id} | İlçe Güncelleme
*TownApi* | [**townsPost**](docs/TownApi.md#townsPost) | **POST** /towns | İlçe Oluşturma
*TownGroupApi* | [**townGroupsGet**](docs/TownGroupApi.md#townGroupsGet) | **GET** /town_groups | İlçe Grubu Listesi Alma
*TownGroupApi* | [**townGroupsIdDelete**](docs/TownGroupApi.md#townGroupsIdDelete) | **DELETE** /town_groups/{id} | İlçe Grubu Silme
*TownGroupApi* | [**townGroupsIdGet**](docs/TownGroupApi.md#townGroupsIdGet) | **GET** /town_groups/{id} | İlçe Grubu Alma
*TownGroupApi* | [**townGroupsIdPut**](docs/TownGroupApi.md#townGroupsIdPut) | **PUT** /town_groups/{id} | İlçe Grubu Güncelleme
*TownGroupApi* | [**townGroupsPost**](docs/TownGroupApi.md#townGroupsPost) | **POST** /town_groups | İlçe Grubu Oluşturma
*UserApi* | [**usersGet**](docs/UserApi.md#usersGet) | **GET** /users | Yönetici Listesi Alma
*UserApi* | [**usersIdGet**](docs/UserApi.md#usersIdGet) | **GET** /users/{id} | Yönetici Alma


## Documentation for Models

 - [Asset](docs/Asset.md)
 - [BillingAddress](docs/BillingAddress.md)
 - [Brand](docs/Brand.md)
 - [Cart](docs/Cart.md)
 - [CartItem](docs/CartItem.md)
 - [CartItemAttribute](docs/CartItemAttribute.md)
 - [Category](docs/Category.md)
 - [Country](docs/Country.md)
 - [Currency](docs/Currency.md)
 - [CurrentAccount](docs/CurrentAccount.md)
 - [Distributor](docs/Distributor.md)
 - [DistributorToProduct](docs/DistributorToProduct.md)
 - [Error](docs/Error.md)
 - [ExtraInfo](docs/ExtraInfo.md)
 - [ExtraInfoToProduct](docs/ExtraInfoToProduct.md)
 - [FavouritedProduct](docs/FavouritedProduct.md)
 - [InstallmentRate](docs/InstallmentRate.md)
 - [Location](docs/Location.md)
 - [Maillist](docs/Maillist.md)
 - [MaillistGroup](docs/MaillistGroup.md)
 - [Member](docs/Member.md)
 - [MemberAddress](docs/MemberAddress.md)
 - [MemberGroup](docs/MemberGroup.md)
 - [OptionGroup](docs/OptionGroup.md)
 - [OptionToProduct](docs/OptionToProduct.md)
 - [Options](docs/Options.md)
 - [Order](docs/Order.md)
 - [OrderAddress](docs/OrderAddress.md)
 - [OrderDetail](docs/OrderDetail.md)
 - [OrderItem](docs/OrderItem.md)
 - [OrderItemCustomization](docs/OrderItemCustomization.md)
 - [OrderItemSubscription](docs/OrderItemSubscription.md)
 - [OrderRefundRequest](docs/OrderRefundRequest.md)
 - [OrderRefundRequestItem](docs/OrderRefundRequestItem.md)
 - [OrderUserNote](docs/OrderUserNote.md)
 - [Payment](docs/Payment.md)
 - [PaymentGateway](docs/PaymentGateway.md)
 - [PaymentGatewaySetting](docs/PaymentGatewaySetting.md)
 - [PaymentProvider](docs/PaymentProvider.md)
 - [PaymentProviderSetting](docs/PaymentProviderSetting.md)
 - [PaymentType](docs/PaymentType.md)
 - [PreOrderInfo](docs/PreOrderInfo.md)
 - [Product](docs/Product.md)
 - [ProductButton](docs/ProductButton.md)
 - [ProductDetail](docs/ProductDetail.md)
 - [ProductImage](docs/ProductImage.md)
 - [ProductPrice](docs/ProductPrice.md)
 - [ProductProtection](docs/ProductProtection.md)
 - [ProductSpecialInfo](docs/ProductSpecialInfo.md)
 - [ProductToCategory](docs/ProductToCategory.md)
 - [ProductToCountDown](docs/ProductToCountDown.md)
 - [ProductToTag](docs/ProductToTag.md)
 - [QuickCart](docs/QuickCart.md)
 - [Region](docs/Region.md)
 - [Selection](docs/Selection.md)
 - [SelectionGroup](docs/SelectionGroup.md)
 - [SelectionToProduct](docs/SelectionToProduct.md)
 - [Shipment](docs/Shipment.md)
 - [ShipmentItem](docs/ShipmentItem.md)
 - [ShippingAddress](docs/ShippingAddress.md)
 - [ShippingCompany](docs/ShippingCompany.md)
 - [ShippingProvider](docs/ShippingProvider.md)
 - [ShippingProviderSetting](docs/ShippingProviderSetting.md)
 - [ShippingRate](docs/ShippingRate.md)
 - [ShopCampaigns](docs/ShopCampaigns.md)
 - [ShopPreference](docs/ShopPreference.md)
 - [ShopTokens](docs/ShopTokens.md)
 - [ShopUserlevels](docs/ShopUserlevels.md)
 - [SpecGroup](docs/SpecGroup.md)
 - [SpecName](docs/SpecName.md)
 - [SpecToProduct](docs/SpecToProduct.md)
 - [SpecValue](docs/SpecValue.md)
 - [Tag](docs/Tag.md)
 - [Theme](docs/Theme.md)
 - [Town](docs/Town.md)
 - [TownGroup](docs/TownGroup.md)
 - [User](docs/User.md)


## Documentation for Authorization

Authentication schemes defined for the API:
### OAuth2

- **Type**: OAuth
- **Flow**: accessCode
- **Authorization URL**: http://magaza-adiniz.myideasoft.ide/admin/user/auth
- **Scopes**: 
  - catalog_read: Katalog okuma izni
  - catalog_write: Katalog okuma / yazma izni
  - order_read: Sipariş okuma izni
  - order_write: Sipariş okuma / yazma izni
  - others_read: Diğer okuma izni
  - others_write: Diğer okuma / yazma izni
  - theme_read: Tema okuma izni
  - theme_write: Tema okuma / yazma izni


## Recommendation

It's recommended to create an instance of `ApiClient` per thread in a multithreaded environment to avoid any potential issues.

## Author

techsupport@ideasoft.com.tr

