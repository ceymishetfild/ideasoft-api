# IdeaSoftApi.OptionToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**optionToProductsGet**](OptionToProductApi.md#optionToProductsGet) | **GET** /option_to_products | Varyant Ürün Bağı Listesi Alma
[**optionToProductsIdDelete**](OptionToProductApi.md#optionToProductsIdDelete) | **DELETE** /option_to_products/{id} | Varyant Ürün Bağı Silme
[**optionToProductsIdGet**](OptionToProductApi.md#optionToProductsIdGet) | **GET** /option_to_products/{id} | Varyant Ürün Bağı Alma
[**optionToProductsIdPut**](OptionToProductApi.md#optionToProductsIdPut) | **PUT** /option_to_products/{id} | Varyant Ürün Bağı Güncelleme
[**optionToProductsPost**](OptionToProductApi.md#optionToProductsPost) | **POST** /option_to_products | Varyant Ürün Bağı Oluşturma


<a name="optionToProductsGet"></a>
# **optionToProductsGet**
> OptionToProduct optionToProductsGet(opts)

Varyant Ürün Bağı Listesi Alma

Varyant Ürün Bağı listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.OptionToProductApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'product': 56, // Number | Ürün id
  'optionGroup': 56, // Number | Varyant Grubu id
  'option': 56, // Number | Varyant id
  'parentProductId': 56 // Number | Ana Ürün id
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.optionToProductsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **product** | **Number**| Ürün id | [optional] 
 **optionGroup** | **Number**| Varyant Grubu id | [optional] 
 **option** | **Number**| Varyant id | [optional] 
 **parentProductId** | **Number**| Ana Ürün id | [optional] 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionToProductsIdDelete"></a>
# **optionToProductsIdDelete**
> optionToProductsIdDelete(id)

Varyant Ürün Bağı Silme

Kalıcı olarak ilgili Varyant Ürün Bağını siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.OptionToProductApi();

var id = 56; // Number | Varyant Ürün Bağı nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.optionToProductsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Varyant Ürün Bağı nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionToProductsIdGet"></a>
# **optionToProductsIdGet**
> OptionToProduct optionToProductsIdGet(id)

Varyant Ürün Bağı Alma

İlgili Varyant Ürün Bağını getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.OptionToProductApi();

var id = 56; // Number | Varyant Ürün Bağı nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.optionToProductsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Varyant Ürün Bağı nesnesinin id değeri | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionToProductsIdPut"></a>
# **optionToProductsIdPut**
> OptionToProduct optionToProductsIdPut(id, optionToProduct)

Varyant Ürün Bağı Güncelleme

İlgili Varyant Ürün Bağını günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.OptionToProductApi();

var id = 56; // Number | Varyant Ürün Bağı nesnesinin id değeri

var optionToProduct = new IdeaSoftApi.OptionToProduct(); // OptionToProduct |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.optionToProductsIdPut(id, optionToProduct, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Varyant Ürün Bağı nesnesinin id değeri | 
 **optionToProduct** | [**OptionToProduct**](OptionToProduct.md)|  nesnesi | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionToProductsPost"></a>
# **optionToProductsPost**
> OptionToProduct optionToProductsPost(optionToProduct)

Varyant Ürün Bağı Oluşturma

Yeni bir Varyant Ürün Bağı oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.OptionToProductApi();

var optionToProduct = new IdeaSoftApi.OptionToProduct(); // OptionToProduct |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.optionToProductsPost(optionToProduct, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **optionToProduct** | [**OptionToProduct**](OptionToProduct.md)|  nesnesi | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

