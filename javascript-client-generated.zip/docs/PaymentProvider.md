# IdeaSoftApi.PaymentProvider

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Ödeme altyapısı sağlayıcısı nesnesi kimlik değeri. | [optional] 
**code** | **String** | Ödeme altyapısı sağlayıcısı için ön tanımlanmış kod değeri. | 
**name** | **String** | Ödeme altyapısı sağlayıcısı için isim değeri. | 
**status** | **String** | Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer. | 
**paymentType** | [**PaymentType**](PaymentType.md) |  | [optional] 
**settings** | [**[PaymentProviderSetting]**](PaymentProviderSetting.md) | Ödeme altyapısı sağlayıcısı ayarları | [optional] 


<a name="StatusEnum"></a>
## Enum: StatusEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




