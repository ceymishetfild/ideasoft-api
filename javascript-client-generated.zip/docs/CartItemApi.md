# IdeaSoftApi.CartItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cartItemsIdDelete**](CartItemApi.md#cartItemsIdDelete) | **DELETE** /cart_items/{id} | Sepet Kalemi Silme
[**cartItemsIdPut**](CartItemApi.md#cartItemsIdPut) | **PUT** /cart_items/{id} | Sepet Kalemi Güncelleme
[**cartItemsPost**](CartItemApi.md#cartItemsPost) | **POST** /cart_items | Sepet Kalemi Oluşturma


<a name="cartItemsIdDelete"></a>
# **cartItemsIdDelete**
> cartItemsIdDelete(id)

Sepet Kalemi Silme

Kalıcı olarak ilgili Sepet Kalemini siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.CartItemApi();

var id = 56; // Number | Sepet Kalemi nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.cartItemsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sepet Kalemi nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="cartItemsIdPut"></a>
# **cartItemsIdPut**
> CartItem cartItemsIdPut(id)

Sepet Kalemi Güncelleme

İlgili Sepet Kalemini günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.CartItemApi();

var id = 56; // Number | Sepet Kalemi nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.cartItemsIdPut(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sepet Kalemi nesnesinin id değeri | 

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="cartItemsPost"></a>
# **cartItemsPost**
> CartItem cartItemsPost(cartItem)

Sepet Kalemi Oluşturma

Yeni bir Sepet Kalemi oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.CartItemApi();

var cartItem = new IdeaSoftApi.CartItem(); // CartItem |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.cartItemsPost(cartItem, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartItem** | [**CartItem**](CartItem.md)|  nesnesi | 

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

