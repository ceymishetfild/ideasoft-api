# IdeaSoftApi.CartItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cartItemsIdDelete**](CartItemApi.md#cartItemsIdDelete) | **DELETE** /cart_items/{id} | Sepet Kalemi Silme
[**cartItemsIdPut**](CartItemApi.md#cartItemsIdPut) | **PUT** /cart_items/{id} | Sepet Kalemi Güncelleme
[**cartItemsPost**](CartItemApi.md#cartItemsPost) | **POST** /cart_items | Sepet Kalemi Oluşturma


<a name="cartItemsIdDelete"></a>
# **cartItemsIdDelete**
> cartItemsIdDelete(id)

Sepet Kalemi Silme

Kalıcı olarak ilgili Sepet Kalemini siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.CartItemApi();

let id = 56; // Number | Sepet Kalemi nesnesinin id değeri


apiInstance.cartItemsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sepet Kalemi nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="cartItemsIdPut"></a>
# **cartItemsIdPut**
> CartItem cartItemsIdPut(id)

Sepet Kalemi Güncelleme

İlgili Sepet Kalemini günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.CartItemApi();

let id = 56; // Number | Sepet Kalemi nesnesinin id değeri


apiInstance.cartItemsIdPut(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sepet Kalemi nesnesinin id değeri | 

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="cartItemsPost"></a>
# **cartItemsPost**
> CartItem cartItemsPost(cartItem)

Sepet Kalemi Oluşturma

Yeni bir Sepet Kalemi oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.CartItemApi();

let cartItem = new IdeaSoftApi.CartItem(); // CartItem | CartItem nesnesi


apiInstance.cartItemsPost(cartItem, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartItem** | [**CartItem**](CartItem.md)| CartItem nesnesi | 

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

