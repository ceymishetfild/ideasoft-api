# IdeaSoftApi.ThemeApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**themesGet**](ThemeApi.md#themesGet) | **GET** /themes | Tema Listesi Alma
[**themesIdAssetsGet**](ThemeApi.md#themesIdAssetsGet) | **GET** /themes/{id}/assets | Tema Dosyası Listesi Alma
[**themesIdAssetskeykeyDelete**](ThemeApi.md#themesIdAssetskeykeyDelete) | **DELETE** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Silme
[**themesIdAssetskeykeyGet**](ThemeApi.md#themesIdAssetskeykeyGet) | **GET** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Alma
[**themesIdAssetskeykeyPut**](ThemeApi.md#themesIdAssetskeykeyPut) | **PUT** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Güncelleme
[**themesIdDelete**](ThemeApi.md#themesIdDelete) | **DELETE** /themes/{id} | Tema Silme
[**themesIdGet**](ThemeApi.md#themesIdGet) | **GET** /themes/{id} | Tema Alma
[**themesIdPut**](ThemeApi.md#themesIdPut) | **PUT** /themes/{id} | Tema Güncelleme
[**themesPost**](ThemeApi.md#themesPost) | **POST** /themes | Tema Oluşturma


<a name="themesGet"></a>
# **themesGet**
> Theme themesGet(opts)

Tema Listesi Alma

Tema listesi verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ThemeApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
  'status': 56, // Number | Tema durumu
  'platform': "platform_example", // String | Tema platformu
  'type': "type_example" // String | Tema tipi
};

apiInstance.themesGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional] 
 **status** | **Number**| Tema durumu | [optional] 
 **platform** | **String**| Tema platformu | [optional] 
 **type** | **String**| Tema tipi | [optional] 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesIdAssetsGet"></a>
# **themesIdAssetsGet**
> Asset themesIdAssetsGet(id, opts)

Tema Dosyası Listesi Alma

Tema Dosyası listesi verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ThemeApi();

let id = 56; // Number | Tema nesnesinin id değeri

let opts = { 
  'key': "key_example" // String | Tema Dosyası nesnesi anahtar değeri.
};

apiInstance.themesIdAssetsGet(id, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Tema nesnesinin id değeri | 
 **key** | **String**| Tema Dosyası nesnesi anahtar değeri. | [optional] 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesIdAssetskeykeyDelete"></a>
# **themesIdAssetskeykeyDelete**
> themesIdAssetskeykeyDelete(id, key)

Tema Dosyası Silme

Kalıcı olarak ilgili Tema Dosyasını siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ThemeApi();

let id = 56; // Number | Tema nesnesinin id değeri

let key = "key_example"; // String | Tema Dosyası nesnesi anahtar değeri.


apiInstance.themesIdAssetskeykeyDelete(id, key, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Tema nesnesinin id değeri | 
 **key** | **String**| Tema Dosyası nesnesi anahtar değeri. | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesIdAssetskeykeyGet"></a>
# **themesIdAssetskeykeyGet**
> Asset themesIdAssetskeykeyGet(id, key)

Tema Dosyası Alma

İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ThemeApi();

let id = 56; // Number | Tema nesnesinin id değeri

let key = "key_example"; // String | Tema Dosyası nesnesi anahtar değeri.


apiInstance.themesIdAssetskeykeyGet(id, key, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Tema nesnesinin id değeri | 
 **key** | **String**| Tema Dosyası nesnesi anahtar değeri. | 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesIdAssetskeykeyPut"></a>
# **themesIdAssetskeykeyPut**
> Asset themesIdAssetskeykeyPut(id, theme, asset)

Tema Dosyası Güncelleme

Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ThemeApi();

let id = 56; // Number | Tema nesnesinin id değeri

let theme = new IdeaSoftApi.Theme(); // Theme | Theme nesnesi

let asset = new IdeaSoftApi.Asset(); // Asset | Asset nesnesi


apiInstance.themesIdAssetskeykeyPut(id, theme, asset, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Tema nesnesinin id değeri | 
 **theme** | [**Theme**](Theme.md)| Theme nesnesi | 
 **asset** | [**Asset**](Asset.md)| Asset nesnesi | 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesIdDelete"></a>
# **themesIdDelete**
> themesIdDelete(id)

Tema Silme

Kalıcı olarak ilgili Temayı siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ThemeApi();

let id = 56; // Number | Tema nesnesinin id değeri


apiInstance.themesIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Tema nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesIdGet"></a>
# **themesIdGet**
> Theme themesIdGet(id)

Tema Alma

İlgili Temayı getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ThemeApi();

let id = 56; // Number | Tema nesnesinin id değeri


apiInstance.themesIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Tema nesnesinin id değeri | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesIdPut"></a>
# **themesIdPut**
> Theme themesIdPut(id, theme)

Tema Güncelleme

İlgili Temayı günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ThemeApi();

let id = 56; // Number | Tema nesnesinin id değeri

let theme = new IdeaSoftApi.Theme(); // Theme | Theme nesnesi


apiInstance.themesIdPut(id, theme, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Tema nesnesinin id değeri | 
 **theme** | [**Theme**](Theme.md)| Theme nesnesi | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="themesPost"></a>
# **themesPost**
> Theme themesPost(theme)

Tema Oluşturma

Yeni bir tema oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ThemeApi();

let theme = new IdeaSoftApi.Theme(); // Theme | Theme nesnesi


apiInstance.themesPost(theme, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **theme** | [**Theme**](Theme.md)| Theme nesnesi | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

