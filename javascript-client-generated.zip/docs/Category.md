# IdeaSoftApi.Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Kategori nesnesi kimlik değeri. | [optional] 
**name** | **String** | Kategori nesnesi için isim değeri. | 
**slug** | **String** | Slug değeri ilgili nesnenin Url değeridir. | [optional] 
**sortOrder** | **Number** | Kategori nesnesi için sıralama değeri. | [optional] 
**status** | **String** | Kategori nesnesinin aktiflik durumunu belirten değer. | 
**percent** | **Number** | Kategori nesnesinin fiyat katsayısı. | [optional] 
**imageFile** | **String** | Kategori nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF | [optional] 
**distributor** | **String** | Her zaman null değer alır. Pratikte kullanımı yoktur. | [optional] 
**displayShowcaseContent** | **Number** | Kategori nesnesinin üst içerik metninin gösterim durumu. | [optional] 
**showcaseContent** | **String** | Kategori nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir. | [optional] 
**showcaseContentDisplayType** | **Number** | Kategori nesnesinin üst içerik metninin gösterim tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kategori içeriği.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Kategori ve üst kategori içeriği.&lt;br&gt;&lt;code&gt;3&lt;/code&gt; : Kategori ve tüm üst kategoriler.&lt;br&gt;&lt;/div&gt; | 
**hasChildren** | **String** | Kategori nesnesinin alt kategori barındırma durumu. Bu değer otomatik oluşturulur. | [optional] 
**metaKeywords** | **String** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] 
**metaDescription** | **String** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] 
**pageTitle** | **String** | Kategori nesnesinin etiket başlığı. | [optional] 
**parent** | [**Category**](Category.md) | Üst kategori olan kategori nesnesi. | [optional] 
**attachment** | **String** | Kategori nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. | [optional] 
**createdAt** | **Date** | Kategori nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **Date** | Kategori nesnesinin güncellenme zamanı. | [optional] 


<a name="StatusEnum"></a>
## Enum: StatusEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="HasChildrenEnum"></a>
## Enum: HasChildrenEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




