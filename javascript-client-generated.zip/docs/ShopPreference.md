# IdeaSoftApi.ShopPreference

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Tanımlama nesnesi kimlik değeri. | [optional] 
**varKey** | **String** | Tanımlama nesnesi için değişken anahtarı. | [optional] 
**varValue** | **String** | Tanımlama nesnesi için değişken değeri. | [optional] 


