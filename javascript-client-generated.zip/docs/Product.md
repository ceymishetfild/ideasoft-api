# IdeaSoftApi.Product

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Ürün nesnesi kimlik değeri. | [optional] 
**name** | **String** | Ürünün adı | 
**slug** | **String** | Slug değeri ilgili nesnenin Url değeridir. | [optional] 
**fullName** | **String** | Ürünün tam adı. Bu değer bir varyant için ana ürünün adı ve varyant adının birleşiminden oluşur. Örneğin Kırmızı varyantı için Kalem Kırmızı olur. | 
**sku** | **String** | Ürünün stok kodu. ID değeri gibi eşsiz bir kimlik değeridir. | 
**barcode** | **String** | Ürünün barkodu. | [optional] 
**price1** | **Number** | Ürünün Fiyat 1 bilgisi. | 
**warranty** | **Number** | Ürünün garanti süresi. | [optional] 
**tax** | **Number** | Ürünün KDV oranı. | [optional] 
**stockAmount** | **Number** | Ürünün stok tipi cinsinden miktarı. | [optional] 
**volumetricWeight** | **Number** | Ürünün desisi. | [optional] 
**buyingPrice** | **Number** | Ürünün alış fiyatı. | [optional] 
**stockTypeLabel** | **String** | Ürünün stok tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Piece&lt;/code&gt; : Stok tipi birimi Adet&lt;br&gt;&lt;code&gt;cm&lt;/code&gt; : Stok tipi birimi Santimetre&lt;br&gt;&lt;code&gt;Dozen&lt;/code&gt; : Stok tipi birimi Düzine&lt;br&gt;&lt;code&gt;gram&lt;/code&gt; : Stok tipi birimi Gram&lt;br&gt;&lt;code&gt;kg&lt;/code&gt; : Stok tipi birimi Kilogram&lt;br&gt;&lt;code&gt;Person&lt;/code&gt; : Stok tipi birimi Kişi&lt;br&gt;&lt;code&gt;Package&lt;/code&gt; : Stok tipi birimi Paket&lt;br&gt;&lt;code&gt;metre&lt;/code&gt; : Stok tipi birimi Metre&lt;br&gt;&lt;code&gt;m2&lt;/code&gt; : Stok tipi birimi Metrekare&lt;br&gt;&lt;code&gt;pair&lt;/code&gt; : Stok tipi birimi Çift&lt;br&gt;&lt;/div&gt; | [optional] 
**discount** | **Number** | Ürünün indirim değeri. Örneğin; discountType 1 olursa %5, 0 olursa 5 tl anlamına gelir. | [optional] 
**discountType** | **Number** | Ürünün indirim tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : İndirim yüzdesi&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : İndirimli fiyat&lt;br&gt;&lt;/div&gt; | [optional] 
**moneyOrderDiscount** | **Number** | Havale indirimi yüzdesi. | [optional] 
**status** | **Number** | Ürün nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;/div&gt; | 
**taxIncluded** | **String** | Ürün fiyatlarına KDV dahil olup olmadığın belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : KDV Dahil&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : KDV Hariç&lt;br&gt;&lt;/div&gt; | [optional] 
**distributor** | **String** | Ürünün distribütör bilgisi | [optional] 
**isGifted** | **String** | Ürünün hediyeli olup olmadığını belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hediyeli&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hediyeli Değil&lt;br&gt;&lt;/div&gt; | [optional] 
**gift** | **String** | Ürünün yanında hediye olarak vermek istediğiniz hediyeyi bu alanda metin ya da rakamla belirtebilirsiniz. | [optional] 
**customShippingDisabled** | **String** | Kargo ücreti için sistemin kullanılıp kullanılmama değerini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sistem seçeneği seçili&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sistem seçeneği seçili değil&lt;br&gt;&lt;/div&gt; | [optional] 
**customShippingCost** | **Number** | Sistem seçeneği seçilmemişse ürün için girilmesi gereken kargo ücreti. | [optional] 
**marketPriceDetail** | **String** | Ürünün piyasa fiyatı | [optional] 
**createdAt** | **Date** | Ürün nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **Date** | Ürün nesnesinin güncellenme zamanı. | [optional] 
**metaKeywords** | **String** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] 
**metaDescription** | **String** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] 
**pageTitle** | **String** | Ürün nesnesinin etiket başlığı. | [optional] 
**hasOption** | **String** | Ürünün varyantının olup olmadığı değerini belirtir. (API otomatik olarak bu değeri atar.)&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Varyantı var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Varyantı yok&lt;br&gt;&lt;/div&gt; | [optional] 
**shortDetails** | **String** | Ürünün kısa açıklaması. | [optional] 
**searchKeywords** | **String** | Ziyaretçilerinizin site içindeki ürünlerinizin hangi anahtar kelimelerine göre bulacağını belirler.Kelimeler arasında virgül bırakılarak girilmelidir.(etiket1,etiket2) | [optional] 
**installmentThreshold** | **String** | Ürüne özel yasal veya isteğe bağlı belirleyebiliceğiniz taksit adedini belirtir. Ürüne özel bir belirleme yapmak istemiyorsanız &#39;-&#39; işareti kullanabilirsiniz. | [optional] 
**homeSortOrder** | **Number** | Anasayfa vitrini sırası. | [optional] 
**popularSortOrder** | **Number** | Popüler ürünler vitrini sırası. | [optional] 
**brandSortOrder** | **Number** | Marka vitrini sırası. | [optional] 
**featuredSortOrder** | **Number** | Sponsor ürünler vitrini sırası | [optional] 
**campaignedSortOrder** | **Number** | Kampanyalı ürünler vitrini sırası. | [optional] 
**newSortOrder** | **Number** | Yeni ürünler vitrini sırası. | [optional] 
**discountedSortOrder** | **Number** | İndirimli ürünler vitrini sırası | [optional] 
**brand** | [**Brand**](Brand.md) | Marka nesnesi. | [optional] 
**currency** | [**Currency**](Currency.md) | Kur nesnesi. | 
**parent** | [**Product**](Product.md) | Ana ürün olan ürün nesnesi. | [optional] 
**countdown** | [**ProductToCountDown**](ProductToCountDown.md) | Ürün geri sayım bağı nesnesi. | [optional] 
**prices** | [**[ProductPrice]**](ProductPrice.md) | Ürünün fiyatları. | [optional] 
**images** | [**[ProductImage]**](ProductImage.md) | Ürünün resimleri. | [optional] 
**productToCategories** | [**[ProductToCategory]**](ProductToCategory.md) | Ürünün kategorileri. | [optional] 


<a name="StockTypeLabelEnum"></a>
## Enum: StockTypeLabelEnum


* `Piece` (value: `"Piece"`)

* `cm` (value: `"cm"`)

* `Dozen` (value: `"Dozen"`)

* `gram` (value: `"gram"`)

* `kg` (value: `"kg"`)

* `Person` (value: `"Person"`)

* `Package` (value: `"Package"`)

* `metre` (value: `"metre"`)

* `m2` (value: `"m2"`)

* `pair` (value: `"pair"`)




<a name="DiscountTypeEnum"></a>
## Enum: DiscountTypeEnum


* `0` (value: `0`)

* `1` (value: `1`)




<a name="StatusEnum"></a>
## Enum: StatusEnum


* `0` (value: `0`)

* `1` (value: `1`)




<a name="TaxIncludedEnum"></a>
## Enum: TaxIncludedEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="IsGiftedEnum"></a>
## Enum: IsGiftedEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="CustomShippingDisabledEnum"></a>
## Enum: CustomShippingDisabledEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="HasOptionEnum"></a>
## Enum: HasOptionEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




