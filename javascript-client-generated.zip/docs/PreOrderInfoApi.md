# IdeaSoftApi.PreOrderInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**preOrderInfosGet**](PreOrderInfoApi.md#preOrderInfosGet) | **GET** /pre_order_infos | Sipariş Öncesi Bilgisi Listesi Alma
[**preOrderInfosIdDelete**](PreOrderInfoApi.md#preOrderInfosIdDelete) | **DELETE** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Silme
[**preOrderInfosIdGet**](PreOrderInfoApi.md#preOrderInfosIdGet) | **GET** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Alma
[**preOrderInfosIdPut**](PreOrderInfoApi.md#preOrderInfosIdPut) | **PUT** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Güncelleme
[**preOrderInfosPost**](PreOrderInfoApi.md#preOrderInfosPost) | **POST** /pre_order_infos | Sipariş Öncesi Bilgisi Oluşturma


<a name="preOrderInfosGet"></a>
# **preOrderInfosGet**
> PreOrderInfo preOrderInfosGet(opts)

Sipariş Öncesi Bilgisi Listesi Alma

Sipariş Öncesi Bilgisi listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.PreOrderInfoApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'sessionId': "sessionId_example", // String | Sipariş Öncesi Bilgisi session id.
  'startDate': new Date("2013-10-20"), // Date | createdAt değeri için başlangıç tarihi
  'endDate': "endDate_example", // String | createdAt değeri için bitiş tarihi
  'startUpdatedAt': new Date("2013-10-20"), // Date | updatedAt değeri için başlangıç tarihi
  'endUpdatedAt': "endUpdatedAt_example" // String | updatedAt değeri için bitiş tarihi
};

apiInstance.preOrderInfosGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **sessionId** | **String**| Sipariş Öncesi Bilgisi session id. | [optional] 
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="preOrderInfosIdDelete"></a>
# **preOrderInfosIdDelete**
> preOrderInfosIdDelete(id)

Sipariş Öncesi Bilgisi Silme

Kalıcı olarak ilgili Sipariş Öncesi Bilgisini siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.PreOrderInfoApi();

let id = 56; // Number | Sipariş Öncesi Bilgisi nesnesinin id değeri


apiInstance.preOrderInfosIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="preOrderInfosIdGet"></a>
# **preOrderInfosIdGet**
> PreOrderInfo preOrderInfosIdGet(id)

Sipariş Öncesi Bilgisi Alma

İlgili Sipariş Öncesi Bilgisini getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.PreOrderInfoApi();

let id = 56; // Number | Sipariş Öncesi Bilgisi nesnesinin id değeri


apiInstance.preOrderInfosIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="preOrderInfosIdPut"></a>
# **preOrderInfosIdPut**
> PreOrderInfo preOrderInfosIdPut(id, preOrderInfo)

Sipariş Öncesi Bilgisi Güncelleme

İlgili Sipariş Öncesi Bilgisini günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.PreOrderInfoApi();

let id = 56; // Number | Sipariş Öncesi Bilgisi nesnesinin id değeri

let preOrderInfo = new IdeaSoftApi.PreOrderInfo(); // PreOrderInfo | PreOrderInfo nesnesi


apiInstance.preOrderInfosIdPut(id, preOrderInfo, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 
 **preOrderInfo** | [**PreOrderInfo**](PreOrderInfo.md)| PreOrderInfo nesnesi | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="preOrderInfosPost"></a>
# **preOrderInfosPost**
> PreOrderInfo preOrderInfosPost(preOrderInfo)

Sipariş Öncesi Bilgisi Oluşturma

Yeni bir Sipariş Öncesi Bilgisi oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.PreOrderInfoApi();

let preOrderInfo = new IdeaSoftApi.PreOrderInfo(); // PreOrderInfo | PreOrderInfo nesnesi


apiInstance.preOrderInfosPost(preOrderInfo, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **preOrderInfo** | [**PreOrderInfo**](PreOrderInfo.md)| PreOrderInfo nesnesi | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

