# IdeaSoftApi.PaymentApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**paymentsGet**](PaymentApi.md#paymentsGet) | **GET** /payments | Ödeme Listesi Alma
[**paymentsIdDelete**](PaymentApi.md#paymentsIdDelete) | **DELETE** /payments/{id} | Ödeme Silme
[**paymentsIdGet**](PaymentApi.md#paymentsIdGet) | **GET** /payments/{id} | Ödeme Alma
[**paymentsIdPut**](PaymentApi.md#paymentsIdPut) | **PUT** /payments/{id} | Ödeme Güncelleme
[**paymentsPost**](PaymentApi.md#paymentsPost) | **POST** /payments | Ödeme Oluşturma


<a name="paymentsGet"></a>
# **paymentsGet**
> Payment paymentsGet(opts)

Ödeme Listesi Alma

Ödeme listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.PaymentApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'transactionId': "transactionId_example", // String | İşlem id.
  'memberEmail': "memberEmail_example", // String | Müşteri e-mail.
  'member': 56, // Number | Üye id
  'status': "status_example", // String | Status şu değerleri alabilir: <br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br><code>deleted</code> : Silindi<br><code>failed</code> : Hatalı Ödemeler<br><code>in_transaction</code> : Sonuçlanmamış Ödemeler
  'paymentTypeName': "paymentTypeName_example", // String | Ödeme tipi adı şu değerleri alabilir: <br><code>Havale</code><br><code>Özel Ödeme Sistemi</code><br><code>Kredi Kartı</code><br><code>Paypal</code><br><code>GarantiPay</code><br><code>Mail Order</code><br><code>BKM Express</code><br><code>Kapıda Ödeme Nakit</code><br><code>Kapıda Ödeme Kredi Kartı</code>
  'startDate': new Date("2013-10-20"), // Date | createdAt değeri için başlangıç tarihi
  'endDate': "endDate_example" // String | createdAt değeri için bitiş tarihi
};

apiInstance.paymentsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **transactionId** | **String**| İşlem id. | [optional] 
 **memberEmail** | **String**| Müşteri e-mail. | [optional] 
 **member** | **Number**| Üye id | [optional] 
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler | [optional] 
 **paymentTypeName** | **String**| Ödeme tipi adı şu değerleri alabilir: &lt;br&gt;&lt;code&gt;Havale&lt;/code&gt;&lt;br&gt;&lt;code&gt;Özel Ödeme Sistemi&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kredi Kartı&lt;/code&gt;&lt;br&gt;&lt;code&gt;Paypal&lt;/code&gt;&lt;br&gt;&lt;code&gt;GarantiPay&lt;/code&gt;&lt;br&gt;&lt;code&gt;Mail Order&lt;/code&gt;&lt;br&gt;&lt;code&gt;BKM Express&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kapıda Ödeme Nakit&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kapıda Ödeme Kredi Kartı&lt;/code&gt; | [optional] 
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional] 

### Return type

[**Payment**](Payment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="paymentsIdDelete"></a>
# **paymentsIdDelete**
> paymentsIdDelete(id)

Ödeme Silme

Kalıcı olarak ilgili Ödemeyi siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.PaymentApi();

let id = 56; // Number | Ödeme nesnesinin id değeri


apiInstance.paymentsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ödeme nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="paymentsIdGet"></a>
# **paymentsIdGet**
> Payment paymentsIdGet(id)

Ödeme Alma

İlgili Ödemeyi getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.PaymentApi();

let id = 56; // Number | Ödeme nesnesinin id değeri


apiInstance.paymentsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ödeme nesnesinin id değeri | 

### Return type

[**Payment**](Payment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="paymentsIdPut"></a>
# **paymentsIdPut**
> Payment paymentsIdPut(id, payment)

Ödeme Güncelleme

İlgili Ödemeyi günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.PaymentApi();

let id = 56; // Number | Ödeme nesnesinin id değeri

let payment = new IdeaSoftApi.Payment(); // Payment | Payment nesnesi


apiInstance.paymentsIdPut(id, payment, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ödeme nesnesinin id değeri | 
 **payment** | [**Payment**](Payment.md)| Payment nesnesi | 

### Return type

[**Payment**](Payment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="paymentsPost"></a>
# **paymentsPost**
> Payment paymentsPost(payment)

Ödeme Oluşturma

Yeni bir Ödeme oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.PaymentApi();

let payment = new IdeaSoftApi.Payment(); // Payment | Payment nesnesi


apiInstance.paymentsPost(payment, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **payment** | [**Payment**](Payment.md)| Payment nesnesi | 

### Return type

[**Payment**](Payment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

