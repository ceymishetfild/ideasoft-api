# IdeaSoftApi.ExtraInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extraInfosGet**](ExtraInfoApi.md#extraInfosGet) | **GET** /extra_infos | Ek Bilgi Listesi Alma
[**extraInfosIdDelete**](ExtraInfoApi.md#extraInfosIdDelete) | **DELETE** /extra_infos/{id} | Ek Bilgi Silme
[**extraInfosIdGet**](ExtraInfoApi.md#extraInfosIdGet) | **GET** /extra_infos/{id} | Ek Bilgi Alma
[**extraInfosIdPut**](ExtraInfoApi.md#extraInfosIdPut) | **PUT** /extra_infos/{id} | Ek Bilgi Güncelleme
[**extraInfosPost**](ExtraInfoApi.md#extraInfosPost) | **POST** /extra_infos | Ek Bilgi Oluşturma


<a name="extraInfosGet"></a>
# **extraInfosGet**
> ExtraInfo extraInfosGet(opts)

Ek Bilgi Listesi Alma

Ek Bilgi listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ExtraInfoApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'name': "name_example" // String | Ek Bilgi adı
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.extraInfosGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **String**| Ek Bilgi adı | [optional] 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfosIdDelete"></a>
# **extraInfosIdDelete**
> extraInfosIdDelete(id)

Ek Bilgi Silme

Kalıcı olarak ilgili Ek Bilgiyi siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ExtraInfoApi();

var id = 56; // Number | Ek Bilgi nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.extraInfosIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Bilgi nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfosIdGet"></a>
# **extraInfosIdGet**
> ExtraInfo extraInfosIdGet(id)

Ek Bilgi Alma

İlgili Ek Bilgiyi getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ExtraInfoApi();

var id = 56; // Number | Ek Bilgi nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.extraInfosIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Bilgi nesnesinin id değeri | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfosIdPut"></a>
# **extraInfosIdPut**
> ExtraInfo extraInfosIdPut(id, extraInfo)

Ek Bilgi Güncelleme

İlgili Ek Bilgiyi günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ExtraInfoApi();

var id = 56; // Number | Ek Bilgi nesnesinin id değeri

var extraInfo = new IdeaSoftApi.ExtraInfo(); // ExtraInfo |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.extraInfosIdPut(id, extraInfo, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Bilgi nesnesinin id değeri | 
 **extraInfo** | [**ExtraInfo**](ExtraInfo.md)|  nesnesi | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfosPost"></a>
# **extraInfosPost**
> ExtraInfo extraInfosPost(extraInfo)

Ek Bilgi Oluşturma

Yeni bir Ek Bilgi oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ExtraInfoApi();

var extraInfo = new IdeaSoftApi.ExtraInfo(); // ExtraInfo |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.extraInfosPost(extraInfo, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extraInfo** | [**ExtraInfo**](ExtraInfo.md)|  nesnesi | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

