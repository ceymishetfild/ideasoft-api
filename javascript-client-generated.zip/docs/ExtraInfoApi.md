# IdeaSoftApi.ExtraInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extraInfosGet**](ExtraInfoApi.md#extraInfosGet) | **GET** /extra_infos | Ek Bilgi Listesi Alma
[**extraInfosIdDelete**](ExtraInfoApi.md#extraInfosIdDelete) | **DELETE** /extra_infos/{id} | Ek Bilgi Silme
[**extraInfosIdGet**](ExtraInfoApi.md#extraInfosIdGet) | **GET** /extra_infos/{id} | Ek Bilgi Alma
[**extraInfosIdPut**](ExtraInfoApi.md#extraInfosIdPut) | **PUT** /extra_infos/{id} | Ek Bilgi Güncelleme
[**extraInfosPost**](ExtraInfoApi.md#extraInfosPost) | **POST** /extra_infos | Ek Bilgi Oluşturma


<a name="extraInfosGet"></a>
# **extraInfosGet**
> ExtraInfo extraInfosGet(opts)

Ek Bilgi Listesi Alma

Ek Bilgi listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ExtraInfoApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'name': "name_example" // String | Ek Bilgi adı
};

apiInstance.extraInfosGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **String**| Ek Bilgi adı | [optional] 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfosIdDelete"></a>
# **extraInfosIdDelete**
> extraInfosIdDelete(id)

Ek Bilgi Silme

Kalıcı olarak ilgili Ek Bilgiyi siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ExtraInfoApi();

let id = 56; // Number | Ek Bilgi nesnesinin id değeri


apiInstance.extraInfosIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Bilgi nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfosIdGet"></a>
# **extraInfosIdGet**
> ExtraInfo extraInfosIdGet(id)

Ek Bilgi Alma

İlgili Ek Bilgiyi getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ExtraInfoApi();

let id = 56; // Number | Ek Bilgi nesnesinin id değeri


apiInstance.extraInfosIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Bilgi nesnesinin id değeri | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfosIdPut"></a>
# **extraInfosIdPut**
> ExtraInfo extraInfosIdPut(id, extraInfo)

Ek Bilgi Güncelleme

İlgili Ek Bilgiyi günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ExtraInfoApi();

let id = 56; // Number | Ek Bilgi nesnesinin id değeri

let extraInfo = new IdeaSoftApi.ExtraInfo(); // ExtraInfo | ExtraInfo nesnesi


apiInstance.extraInfosIdPut(id, extraInfo, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Bilgi nesnesinin id değeri | 
 **extraInfo** | [**ExtraInfo**](ExtraInfo.md)| ExtraInfo nesnesi | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfosPost"></a>
# **extraInfosPost**
> ExtraInfo extraInfosPost(extraInfo)

Ek Bilgi Oluşturma

Yeni bir Ek Bilgi oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ExtraInfoApi();

let extraInfo = new IdeaSoftApi.ExtraInfo(); // ExtraInfo | ExtraInfo nesnesi


apiInstance.extraInfosPost(extraInfo, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extraInfo** | [**ExtraInfo**](ExtraInfo.md)| ExtraInfo nesnesi | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

