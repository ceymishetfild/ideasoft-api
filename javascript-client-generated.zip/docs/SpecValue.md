# IdeaSoftApi.SpecValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Ürün özellik değeri nesnesi kimlik değeri. | [optional] 
**name** | **String** | Ürün özellik değeri nesnesi için isim değeri. | 
**sortOrder** | **Number** | Ürün özellik değeri nesnesi için sıralama değeri. | [optional] 
**logo** | **String** | Ürün özellik değeri logo görseli için geçerli dosya uzantıları.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;jpg&lt;/code&gt; : jpg dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;png&lt;/code&gt; : png dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;gif&lt;/code&gt; : gif dosyaları için geçerli uzantı.&lt;br&gt;&lt;code&gt;jpeg&lt;/code&gt; : jpeg dosyaları için geçerli uzantı.&lt;br&gt;&lt;/div&gt; | [optional] 
**status** | **String** | Ürün özellik değerinin aktiflik bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**attachment** | **String** | Ürün görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. | [optional] 
**specGroup** | [**SpecGroup**](SpecGroup.md) | Ürün özelliği grubu nesnesi. | 
**specName** | [**SpecName**](SpecName.md) | Ürün özelliği nesnesi. | 


<a name="LogoEnum"></a>
## Enum: LogoEnum


* `jpg` (value: `"jpg"`)

* `png` (value: `"png"`)

* `gif` (value: `"gif"`)

* `jpeg` (value: `"jpeg"`)




<a name="StatusEnum"></a>
## Enum: StatusEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




