# IdeaSoftApi.SelectionToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selectionToProductsGet**](SelectionToProductApi.md#selectionToProductsGet) | **GET** /selection_to_products | Ek Özellik Ürün Bağı Listesi Alma
[**selectionToProductsIdDelete**](SelectionToProductApi.md#selectionToProductsIdDelete) | **DELETE** /selection_to_products/{id} | Ek Özellik Ürün Bağı Silme
[**selectionToProductsIdGet**](SelectionToProductApi.md#selectionToProductsIdGet) | **GET** /selection_to_products/{id} | Ek Özellik Ürün Bağı Alma
[**selectionToProductsIdPut**](SelectionToProductApi.md#selectionToProductsIdPut) | **PUT** /selection_to_products/{id} | Ek Özellik Ürün Bağı Güncelleme
[**selectionToProductsPost**](SelectionToProductApi.md#selectionToProductsPost) | **POST** /selection_to_products | Ek Özellik Ürün Bağı Oluşturma


<a name="selectionToProductsGet"></a>
# **selectionToProductsGet**
> SelectionToProduct selectionToProductsGet(opts)

Ek Özellik Ürün Bağı Listesi Alma

Ek Özellik Ürün Bağı listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SelectionToProductApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'selection': 56, // Number | Ek Özellik id
  'product': 56 // Number | Ürün id
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.selectionToProductsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **selection** | **Number**| Ek Özellik id | [optional] 
 **product** | **Number**| Ürün id | [optional] 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionToProductsIdDelete"></a>
# **selectionToProductsIdDelete**
> selectionToProductsIdDelete(id)

Ek Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ek Özellik Ürün Bağını siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SelectionToProductApi();

var id = 56; // Number | Ek Özellik Ürün Bağı nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.selectionToProductsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionToProductsIdGet"></a>
# **selectionToProductsIdGet**
> SelectionToProduct selectionToProductsIdGet(id)

Ek Özellik Ürün Bağı Alma

İlgili Ek Özellik Ürün Bağını getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SelectionToProductApi();

var id = 56; // Number | Ek Özellik Ürün Bağı nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.selectionToProductsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionToProductsIdPut"></a>
# **selectionToProductsIdPut**
> SelectionToProduct selectionToProductsIdPut(id, selectionToProduct)

Ek Özellik Ürün Bağı Güncelleme

İlgili Ek Özellik Ürün Bağını günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SelectionToProductApi();

var id = 56; // Number | Ek Özellik Ürün Bağı nesnesinin id değeri

var selectionToProduct = new IdeaSoftApi.SelectionToProduct(); // SelectionToProduct |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.selectionToProductsIdPut(id, selectionToProduct, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Özellik Ürün Bağı nesnesinin id değeri | 
 **selectionToProduct** | [**SelectionToProduct**](SelectionToProduct.md)|  nesnesi | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionToProductsPost"></a>
# **selectionToProductsPost**
> SelectionToProduct selectionToProductsPost(selectionToProduct)

Ek Özellik Ürün Bağı Oluşturma

Yeni bir Ek Özellik Ürün Bağı oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SelectionToProductApi();

var selectionToProduct = new IdeaSoftApi.SelectionToProduct(); // SelectionToProduct |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.selectionToProductsPost(selectionToProduct, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selectionToProduct** | [**SelectionToProduct**](SelectionToProduct.md)|  nesnesi | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

