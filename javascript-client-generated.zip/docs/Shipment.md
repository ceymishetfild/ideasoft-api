# IdeaSoftApi.Shipment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Teslimat nesnesi kimlik değeri. | [optional] 
**barcode** | **String** | Teslimat barkodu. | [optional] 
**waybillNo** | **String** | Teslimat fatura numarası. | [optional] 
**invoiceKey** | **String** | Teslimat irsaliye makbuzu numarası. | [optional] 
**cargoOffice** | **String** | Teslimatın kargo şubesi | [optional] 
**code** | **String** | Teslimat kodu. Kargo takip kodu. | [optional] 
**deliveryType** | **String** | Teslimat tipi | [optional] 
**invoiceIncluded** | **String** | Faturanın pakete dahillik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Dahil.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Dahil değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**payAtDoorAmount** | **Number** | Kapıda ödeme hizmeti bedeli. | [optional] 
**createdAt** | **Date** | Teslimat nesnesinin oluşturulma zamanı. | [optional] 
**status** | **Number** | Teslimat nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**order** | [**Order**](Order.md) |  | [optional] 


<a name="InvoiceIncludedEnum"></a>
## Enum: InvoiceIncludedEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="StatusEnum"></a>
## Enum: StatusEnum


* `0` (value: `0`)

* `1` (value: `1`)




