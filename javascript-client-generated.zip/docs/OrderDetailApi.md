# IdeaSoftApi.OrderDetailApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**orderDetailsGet**](OrderDetailApi.md#orderDetailsGet) | **GET** /order_details | Sipariş Detayı Listesi Alma
[**orderDetailsIdDelete**](OrderDetailApi.md#orderDetailsIdDelete) | **DELETE** /order_details/{id} | Sipariş Detayı Silme
[**orderDetailsIdGet**](OrderDetailApi.md#orderDetailsIdGet) | **GET** /order_details/{id} | Sipariş Detayı Alma
[**orderDetailsIdPut**](OrderDetailApi.md#orderDetailsIdPut) | **PUT** /order_details/{id} | Sipariş Detayı Güncelleme
[**orderDetailsPost**](OrderDetailApi.md#orderDetailsPost) | **POST** /order_details | Sipariş Detayı Oluşturma


<a name="orderDetailsGet"></a>
# **orderDetailsGet**
> OrderDetail orderDetailsGet(opts)

Sipariş Detayı Listesi Alma

Sipariş Detayı listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OrderDetailApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'order': 56 // Number | Sipariş id
};

apiInstance.orderDetailsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **Number**| Sipariş id | [optional] 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderDetailsIdDelete"></a>
# **orderDetailsIdDelete**
> orderDetailsIdDelete(id)

Sipariş Detayı Silme

Kalıcı olarak ilgili Sipariş Detayı siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OrderDetailApi();

let id = 56; // Number | Sipariş Detayı nesnesinin id değeri


apiInstance.orderDetailsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sipariş Detayı nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderDetailsIdGet"></a>
# **orderDetailsIdGet**
> OrderDetail orderDetailsIdGet(id)

Sipariş Detayı Alma

İlgili Sipariş Detayı getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OrderDetailApi();

let id = 56; // Number | Sipariş Detayı nesnesinin id değeri


apiInstance.orderDetailsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sipariş Detayı nesnesinin id değeri | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderDetailsIdPut"></a>
# **orderDetailsIdPut**
> OrderDetail orderDetailsIdPut(id, orderDetail)

Sipariş Detayı Güncelleme

İlgili Sipariş Detayı günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OrderDetailApi();

let id = 56; // Number | Sipariş Detayı nesnesinin id değeri

let orderDetail = new IdeaSoftApi.OrderDetail(); // OrderDetail | OrderDetail nesnesi


apiInstance.orderDetailsIdPut(id, orderDetail, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sipariş Detayı nesnesinin id değeri | 
 **orderDetail** | [**OrderDetail**](OrderDetail.md)| OrderDetail nesnesi | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderDetailsPost"></a>
# **orderDetailsPost**
> OrderDetail orderDetailsPost(orderDetail)

Sipariş Detayı Oluşturma

Yeni bir Sipariş Detayı oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OrderDetailApi();

let orderDetail = new IdeaSoftApi.OrderDetail(); // OrderDetail | OrderDetail nesnesi


apiInstance.orderDetailsPost(orderDetail, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orderDetail** | [**OrderDetail**](OrderDetail.md)| OrderDetail nesnesi | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

