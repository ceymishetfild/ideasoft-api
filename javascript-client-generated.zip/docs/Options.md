# IdeaSoftApi.Options

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Varyant nesnesi kimlik değeri. | [optional] 
**title** | **String** | Varyant başlığı. Varyant Grubu renk is bu değer kırmızı olabilir. | 
**sortOrder** | **Number** | Varyant nesnesi için sıralama değeri. | [optional] 
**logo** | **String** | Logo görselinin adı.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;jpg&lt;/code&gt; : jpg dosyası için geçerli uzantı.&lt;br&gt;&lt;code&gt;png&lt;/code&gt; : png dosyası için geçerli uzantı.&lt;br&gt;&lt;code&gt;gif&lt;/code&gt; : gif dosyası için geçerli uzantı.&lt;br&gt;&lt;code&gt;jpeg&lt;/code&gt; : jpeg dosyası için geçerli uzantı.&lt;br&gt;&lt;/div&gt; | [optional] 
**optionGroup** | [**OptionGroup**](OptionGroup.md) | Varyant grubu nesnesi. | 
**attachment** | **String** | Varyant nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. | [optional] 


<a name="LogoEnum"></a>
## Enum: LogoEnum


* `jpg` (value: `"jpg"`)

* `png` (value: `"png"`)

* `gif` (value: `"gif"`)

* `jpeg` (value: `"jpeg"`)




