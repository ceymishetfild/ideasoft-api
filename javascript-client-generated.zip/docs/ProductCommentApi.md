# IdeaSoftApi.ProductCommentApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productCommentsGet**](ProductCommentApi.md#productCommentsGet) | **GET** /product_comments | Ürün Yorumları Listesi Alma
[**productCommentsIdDelete**](ProductCommentApi.md#productCommentsIdDelete) | **DELETE** /product_comments/{id} | Ürün Yorumu Silme
[**productCommentsIdGet**](ProductCommentApi.md#productCommentsIdGet) | **GET** /product_comments/{id} | Ürün Yorumu Alma
[**productCommentsIdPut**](ProductCommentApi.md#productCommentsIdPut) | **PUT** /product_comments/{id} | Ürün Yorumu Güncelleme
[**productCommentsPost**](ProductCommentApi.md#productCommentsPost) | **POST** /product_comments | Ürün Yorumu Oluşturma


<a name="productCommentsGet"></a>
# **productCommentsGet**
> ProductComment productCommentsGet(opts)

Ürün Yorumları Listesi Alma

Ürün Yorumları listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductCommentApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
  'status': "status_example", // String | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
  'isAnonymous': "isAnonymous_example", // String | IsAnonymous şu değerleri alabilir: <br><code>0</code> : Anonim değil<br><code>1</code> : Anonim
  'member': 56, // Number | Üye id
  'product': 56, // Number | Ürün id
  'startDate': new Date("2013-10-20"), // Date | createdAt değeri için başlangıç tarihi
  'endDate': "endDate_example", // String | createdAt değeri için bitiş tarihi
  'startUpdatedAt': new Date("2013-10-20"), // Date | updatedAt değeri için başlangıç tarihi
  'endUpdatedAt': "endUpdatedAt_example" // String | updatedAt değeri için bitiş tarihi
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productCommentsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional] 
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **isAnonymous** | **String**| IsAnonymous şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Anonim değil&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Anonim | [optional] 
 **member** | **Number**| Üye id | [optional] 
 **product** | **Number**| Ürün id | [optional] 
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productCommentsIdDelete"></a>
# **productCommentsIdDelete**
> productCommentsIdDelete(id)

Ürün Yorumu Silme

Kalıcı olarak ilgili Ürün Yorumunu siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductCommentApi();

var id = 56; // Number | Ürün Yorumu nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.productCommentsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Yorumu nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productCommentsIdGet"></a>
# **productCommentsIdGet**
> ProductComment productCommentsIdGet(id)

Ürün Yorumu Alma

İlgili Ürün Yorumunu getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductCommentApi();

var id = 56; // Number | Ürün Yorumu nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productCommentsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Yorumu nesnesinin id değeri | 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productCommentsIdPut"></a>
# **productCommentsIdPut**
> ProductComment productCommentsIdPut(id, productComment)

Ürün Yorumu Güncelleme

İlgili Ürün Yorumunu günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductCommentApi();

var id = 56; // Number | Ürün Yorumu nesnesinin id değeri

var productComment = new IdeaSoftApi.ProductComment(); // ProductComment |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productCommentsIdPut(id, productComment, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Yorumu nesnesinin id değeri | 
 **productComment** | [**ProductComment**](ProductComment.md)|  nesnesi | 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productCommentsPost"></a>
# **productCommentsPost**
> ProductComment productCommentsPost(productComment)

Ürün Yorumu Oluşturma

Yeni bir Ürün Yorumu oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductCommentApi();

var productComment = new IdeaSoftApi.ProductComment(); // ProductComment |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productCommentsPost(productComment, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productComment** | [**ProductComment**](ProductComment.md)|  nesnesi | 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

