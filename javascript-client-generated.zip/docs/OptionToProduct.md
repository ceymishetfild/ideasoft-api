# IdeaSoftApi.OptionToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Varyant ürün bağı nesnesi kimlik değeri. | [optional] 
**parentProductId** | **Number** | Ana ürünün benzersiz kimlik değeri. | 
**optionGroup** | [**OptionGroup**](OptionGroup.md) | Varyant grubu nesnesi. | 
**option** | [**Options**](Options.md) | Varyant nesnesi. | 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 


