# IdeaSoftApi.MaillistGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Mail listesi grubu nesnesi kimlik değeri. | [optional] 
**name** | **String** | Mail listesi grubu nesnesi için isim değeri. | 


