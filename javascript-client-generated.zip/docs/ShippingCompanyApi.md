# IdeaSoftApi.ShippingCompanyApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shippingCompaniesGet**](ShippingCompanyApi.md#shippingCompaniesGet) | **GET** /shipping_companies | Kargo Firması Listesi Alma
[**shippingCompaniesIdDelete**](ShippingCompanyApi.md#shippingCompaniesIdDelete) | **DELETE** /shipping_companies/{id} | Kargo Firması Silme
[**shippingCompaniesIdGet**](ShippingCompanyApi.md#shippingCompaniesIdGet) | **GET** /shipping_companies/{id} | Kargo Firması Alma
[**shippingCompaniesIdPut**](ShippingCompanyApi.md#shippingCompaniesIdPut) | **PUT** /shipping_companies/{id} | Kargo Firması Güncelleme
[**shippingCompaniesPost**](ShippingCompanyApi.md#shippingCompaniesPost) | **POST** /shipping_companies | Kargo Firması Oluşturma


<a name="shippingCompaniesGet"></a>
# **shippingCompaniesGet**
> ShippingCompany shippingCompaniesGet(opts)

Kargo Firması Listesi Alma

Kargo Firması listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ShippingCompanyApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'name': "name_example", // String | Kargo firması adı
  'companyCode': "companyCode_example", // String | Kargo firması kodu
  'paymentType': "paymentType_example", // String | Ödeme Tipi şu değerleri alabilir: <br><code>cash_on_delivery</code> : Alıcı ödemeli<br><code>standart_delivery</code> : Gönderici ödemeli<br><code>not_applicable</code> : Bu alan için uygulanabilir değil
  'shippingProvider': 56 // Number | Teslimat Hizmeti Sağlayıcısı id
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.shippingCompaniesGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **String**| Kargo firması adı | [optional] 
 **companyCode** | **String**| Kargo firması kodu | [optional] 
 **paymentType** | **String**| Ödeme Tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil | [optional] 
 **shippingProvider** | **Number**| Teslimat Hizmeti Sağlayıcısı id | [optional] 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingCompaniesIdDelete"></a>
# **shippingCompaniesIdDelete**
> shippingCompaniesIdDelete(id)

Kargo Firması Silme

Kalıcı olarak ilgili Kargo Firmasını siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ShippingCompanyApi();

var id = 56; // Number | Kargo Firması nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.shippingCompaniesIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Kargo Firması nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingCompaniesIdGet"></a>
# **shippingCompaniesIdGet**
> ShippingCompany shippingCompaniesIdGet(id)

Kargo Firması Alma

İlgili Kargo Firmasını getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ShippingCompanyApi();

var id = 56; // Number | Kargo Firması nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.shippingCompaniesIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Kargo Firması nesnesinin id değeri | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingCompaniesIdPut"></a>
# **shippingCompaniesIdPut**
> ShippingCompany shippingCompaniesIdPut(id, shippingCompany)

Kargo Firması Güncelleme

İlgili Kargo Firmasını günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ShippingCompanyApi();

var id = 56; // Number | Kargo Firması nesnesinin id değeri

var shippingCompany = new IdeaSoftApi.ShippingCompany(); // ShippingCompany |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.shippingCompaniesIdPut(id, shippingCompany, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Kargo Firması nesnesinin id değeri | 
 **shippingCompany** | [**ShippingCompany**](ShippingCompany.md)|  nesnesi | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingCompaniesPost"></a>
# **shippingCompaniesPost**
> ShippingCompany shippingCompaniesPost(shippingCompany)

Kargo Firması Oluşturma

Yeni bir Kargo Firması oluşturur relationship.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ShippingCompanyApi();

var shippingCompany = new IdeaSoftApi.ShippingCompany(); // ShippingCompany |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.shippingCompaniesPost(shippingCompany, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shippingCompany** | [**ShippingCompany**](ShippingCompany.md)|  nesnesi | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

