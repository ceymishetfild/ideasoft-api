# IdeaSoftApi.ShippingCompanyApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shippingCompaniesGet**](ShippingCompanyApi.md#shippingCompaniesGet) | **GET** /shipping_companies | Kargo Firması Listesi Alma
[**shippingCompaniesIdDelete**](ShippingCompanyApi.md#shippingCompaniesIdDelete) | **DELETE** /shipping_companies/{id} | Kargo Firması Silme
[**shippingCompaniesIdGet**](ShippingCompanyApi.md#shippingCompaniesIdGet) | **GET** /shipping_companies/{id} | Kargo Firması Alma
[**shippingCompaniesIdPut**](ShippingCompanyApi.md#shippingCompaniesIdPut) | **PUT** /shipping_companies/{id} | Kargo Firması Güncelleme
[**shippingCompaniesPost**](ShippingCompanyApi.md#shippingCompaniesPost) | **POST** /shipping_companies | Kargo Firması Oluşturma


<a name="shippingCompaniesGet"></a>
# **shippingCompaniesGet**
> ShippingCompany shippingCompaniesGet(opts)

Kargo Firması Listesi Alma

Kargo Firması listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ShippingCompanyApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'name': "name_example", // String | Kargo firması adı
  'companyCode': "companyCode_example", // String | Kargo firması kodu
  'paymentType': "paymentType_example", // String | Ödeme Tipi şu değerleri alabilir: <br><code>cash_on_delivery</code> : Alıcı ödemeli<br><code>standart_delivery</code> : Gönderici ödemeli<br><code>not_applicable</code> : Bu alan için uygulanabilir değil
  'shippingProvider': 56 // Number | Teslimat Hizmeti Sağlayıcısı id
};

apiInstance.shippingCompaniesGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **String**| Kargo firması adı | [optional] 
 **companyCode** | **String**| Kargo firması kodu | [optional] 
 **paymentType** | **String**| Ödeme Tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil | [optional] 
 **shippingProvider** | **Number**| Teslimat Hizmeti Sağlayıcısı id | [optional] 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingCompaniesIdDelete"></a>
# **shippingCompaniesIdDelete**
> shippingCompaniesIdDelete(id)

Kargo Firması Silme

Kalıcı olarak ilgili Kargo Firmasını siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ShippingCompanyApi();

let id = 56; // Number | Kargo Firması nesnesinin id değeri


apiInstance.shippingCompaniesIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Kargo Firması nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingCompaniesIdGet"></a>
# **shippingCompaniesIdGet**
> ShippingCompany shippingCompaniesIdGet(id)

Kargo Firması Alma

İlgili Kargo Firmasını getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ShippingCompanyApi();

let id = 56; // Number | Kargo Firması nesnesinin id değeri


apiInstance.shippingCompaniesIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Kargo Firması nesnesinin id değeri | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingCompaniesIdPut"></a>
# **shippingCompaniesIdPut**
> ShippingCompany shippingCompaniesIdPut(id, shippingCompany)

Kargo Firması Güncelleme

İlgili Kargo Firmasını günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ShippingCompanyApi();

let id = 56; // Number | Kargo Firması nesnesinin id değeri

let shippingCompany = new IdeaSoftApi.ShippingCompany(); // ShippingCompany | ShippingCompany nesnesi


apiInstance.shippingCompaniesIdPut(id, shippingCompany, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Kargo Firması nesnesinin id değeri | 
 **shippingCompany** | [**ShippingCompany**](ShippingCompany.md)| ShippingCompany nesnesi | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingCompaniesPost"></a>
# **shippingCompaniesPost**
> ShippingCompany shippingCompaniesPost(shippingCompany)

Kargo Firması Oluşturma

Yeni bir Kargo Firması oluşturur relationship.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ShippingCompanyApi();

let shippingCompany = new IdeaSoftApi.ShippingCompany(); // ShippingCompany | ShippingCompany nesnesi


apiInstance.shippingCompaniesPost(shippingCompany, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shippingCompany** | [**ShippingCompany**](ShippingCompany.md)| ShippingCompany nesnesi | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

