# IdeaSoftApi.SelectionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selectionGroupsGet**](SelectionGroupApi.md#selectionGroupsGet) | **GET** /selection_groups | Ek Özellik Grubu Listesi Alma
[**selectionGroupsIdDelete**](SelectionGroupApi.md#selectionGroupsIdDelete) | **DELETE** /selection_groups/{id} | Ek Özellik Grubu Silme
[**selectionGroupsIdGet**](SelectionGroupApi.md#selectionGroupsIdGet) | **GET** /selection_groups/{id} | Ek Özellik Grubu Alma
[**selectionGroupsIdPut**](SelectionGroupApi.md#selectionGroupsIdPut) | **PUT** /selection_groups/{id} | Ek Özellik Grubu Güncelleme
[**selectionGroupsPost**](SelectionGroupApi.md#selectionGroupsPost) | **POST** /selection_groups | Ek Özellik Grubu Oluşturma


<a name="selectionGroupsGet"></a>
# **selectionGroupsGet**
> SelectionGroup selectionGroupsGet(opts)

Ek Özellik Grubu Listesi Alma

Ek Özellik Grubu listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SelectionGroupApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'title': "title_example" // String | Ek Özellik Grubu başlığı
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.selectionGroupsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **title** | **String**| Ek Özellik Grubu başlığı | [optional] 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionGroupsIdDelete"></a>
# **selectionGroupsIdDelete**
> selectionGroupsIdDelete(id)

Ek Özellik Grubu Silme

Kalıcı olarak ilgili Ek Özellik Grubunu siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SelectionGroupApi();

var id = 56; // Number | Ek Özellik Grubu nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.selectionGroupsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Özellik Grubu nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionGroupsIdGet"></a>
# **selectionGroupsIdGet**
> SelectionGroup selectionGroupsIdGet(id)

Ek Özellik Grubu Alma

İlgili Ek Özellik Grubunu getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SelectionGroupApi();

var id = 56; // Number | Ek Özellik Grubu nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.selectionGroupsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Özellik Grubu nesnesinin id değeri | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionGroupsIdPut"></a>
# **selectionGroupsIdPut**
> SelectionGroup selectionGroupsIdPut(id, selectionGroup)

Ek Özellik Grubu Güncelleme

İlgili Ek Özellik Grubunu günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SelectionGroupApi();

var id = 56; // Number | Ek Özellik Grubu nesnesinin id değeri

var selectionGroup = new IdeaSoftApi.SelectionGroup(); // SelectionGroup |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.selectionGroupsIdPut(id, selectionGroup, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Özellik Grubu nesnesinin id değeri | 
 **selectionGroup** | [**SelectionGroup**](SelectionGroup.md)|  nesnesi | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionGroupsPost"></a>
# **selectionGroupsPost**
> SelectionGroup selectionGroupsPost(selectionGroup)

Ek Özellik Grubu Oluşturma

Yeni bir Ek Özellik Grubu oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SelectionGroupApi();

var selectionGroup = new IdeaSoftApi.SelectionGroup(); // SelectionGroup |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.selectionGroupsPost(selectionGroup, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selectionGroup** | [**SelectionGroup**](SelectionGroup.md)|  nesnesi | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

