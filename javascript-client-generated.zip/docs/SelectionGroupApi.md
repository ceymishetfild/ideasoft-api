# IdeaSoftApi.SelectionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selectionGroupsGet**](SelectionGroupApi.md#selectionGroupsGet) | **GET** /selection_groups | Ek Özellik Grubu Listesi Alma
[**selectionGroupsIdDelete**](SelectionGroupApi.md#selectionGroupsIdDelete) | **DELETE** /selection_groups/{id} | Ek Özellik Grubu Silme
[**selectionGroupsIdGet**](SelectionGroupApi.md#selectionGroupsIdGet) | **GET** /selection_groups/{id} | Ek Özellik Grubu Alma
[**selectionGroupsIdPut**](SelectionGroupApi.md#selectionGroupsIdPut) | **PUT** /selection_groups/{id} | Ek Özellik Grubu Güncelleme
[**selectionGroupsPost**](SelectionGroupApi.md#selectionGroupsPost) | **POST** /selection_groups | Ek Özellik Grubu Oluşturma


<a name="selectionGroupsGet"></a>
# **selectionGroupsGet**
> SelectionGroup selectionGroupsGet(opts)

Ek Özellik Grubu Listesi Alma

Ek Özellik Grubu listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SelectionGroupApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'title': "title_example" // String | Ek Özellik Grubu başlığı
};

apiInstance.selectionGroupsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **title** | **String**| Ek Özellik Grubu başlığı | [optional] 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionGroupsIdDelete"></a>
# **selectionGroupsIdDelete**
> selectionGroupsIdDelete(id)

Ek Özellik Grubu Silme

Kalıcı olarak ilgili Ek Özellik Grubunu siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SelectionGroupApi();

let id = 56; // Number | Ek Özellik Grubu nesnesinin id değeri


apiInstance.selectionGroupsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Özellik Grubu nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionGroupsIdGet"></a>
# **selectionGroupsIdGet**
> SelectionGroup selectionGroupsIdGet(id)

Ek Özellik Grubu Alma

İlgili Ek Özellik Grubunu getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SelectionGroupApi();

let id = 56; // Number | Ek Özellik Grubu nesnesinin id değeri


apiInstance.selectionGroupsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Özellik Grubu nesnesinin id değeri | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionGroupsIdPut"></a>
# **selectionGroupsIdPut**
> SelectionGroup selectionGroupsIdPut(id, selectionGroup)

Ek Özellik Grubu Güncelleme

İlgili Ek Özellik Grubunu günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SelectionGroupApi();

let id = 56; // Number | Ek Özellik Grubu nesnesinin id değeri

let selectionGroup = new IdeaSoftApi.SelectionGroup(); // SelectionGroup | SelectionGroup nesnesi


apiInstance.selectionGroupsIdPut(id, selectionGroup, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Özellik Grubu nesnesinin id değeri | 
 **selectionGroup** | [**SelectionGroup**](SelectionGroup.md)| SelectionGroup nesnesi | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionGroupsPost"></a>
# **selectionGroupsPost**
> SelectionGroup selectionGroupsPost(selectionGroup)

Ek Özellik Grubu Oluşturma

Yeni bir Ek Özellik Grubu oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SelectionGroupApi();

let selectionGroup = new IdeaSoftApi.SelectionGroup(); // SelectionGroup | SelectionGroup nesnesi


apiInstance.selectionGroupsPost(selectionGroup, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selectionGroup** | [**SelectionGroup**](SelectionGroup.md)| SelectionGroup nesnesi | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

