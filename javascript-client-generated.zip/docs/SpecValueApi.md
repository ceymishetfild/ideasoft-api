# IdeaSoftApi.SpecValueApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specValuesGet**](SpecValueApi.md#specValuesGet) | **GET** /spec_values | Ürün Özellik Değeri Listesi Alma
[**specValuesIdDelete**](SpecValueApi.md#specValuesIdDelete) | **DELETE** /spec_values/{id} | Ürün Özellik Değeri Silme
[**specValuesIdGet**](SpecValueApi.md#specValuesIdGet) | **GET** /spec_values/{id} | Ürün Özellik Değeri Alma
[**specValuesIdPut**](SpecValueApi.md#specValuesIdPut) | **PUT** /spec_values/{id} | Ürün Özellik Değeri Güncelleme
[**specValuesPost**](SpecValueApi.md#specValuesPost) | **POST** /spec_values | Ürün Özellik Değeri Oluşturma


<a name="specValuesGet"></a>
# **specValuesGet**
> SpecValue specValuesGet(opts)

Ürün Özellik Değeri Listesi Alma

Ürün Özellik Değeri listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SpecValueApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'name': "name_example", // String | Ürün özellik adı
  'specName': 56, // Number | Ürün özellik id
  'specValue': 56 // Number | Ürün özellik değeri id
};

apiInstance.specValuesGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **String**| Ürün özellik adı | [optional] 
 **specName** | **Number**| Ürün özellik id | [optional] 
 **specValue** | **Number**| Ürün özellik değeri id | [optional] 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specValuesIdDelete"></a>
# **specValuesIdDelete**
> specValuesIdDelete(id)

Ürün Özellik Değeri Silme

Kalıcı olarak ilgili Ürün Özellik Değerini siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SpecValueApi();

let id = 56; // Number | Ürün Özellik Değeri nesnesinin id değeri


apiInstance.specValuesIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik Değeri nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specValuesIdGet"></a>
# **specValuesIdGet**
> SpecValue specValuesIdGet(id)

Ürün Özellik Değeri Alma

İlgili Ürün Özellik Değerini getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SpecValueApi();

let id = 56; // Number | Ürün Özellik Değeri nesnesinin id değeri


apiInstance.specValuesIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik Değeri nesnesinin id değeri | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specValuesIdPut"></a>
# **specValuesIdPut**
> SpecValue specValuesIdPut(id, specValue)

Ürün Özellik Değeri Güncelleme

İlgili Ürün Özellik Değerini günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SpecValueApi();

let id = 56; // Number | Ürün Özellik Değeri nesnesinin id değeri

let specValue = new IdeaSoftApi.SpecValue(); // SpecValue | SpecValue nesnesi


apiInstance.specValuesIdPut(id, specValue, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik Değeri nesnesinin id değeri | 
 **specValue** | [**SpecValue**](SpecValue.md)| SpecValue nesnesi | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specValuesPost"></a>
# **specValuesPost**
> SpecValue specValuesPost(specValue)

Ürün Özellik Değeri Oluşturma

Yeni bir Ürün Özellik Değeri oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SpecValueApi();

let specValue = new IdeaSoftApi.SpecValue(); // SpecValue | SpecValue nesnesi


apiInstance.specValuesPost(specValue, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specValue** | [**SpecValue**](SpecValue.md)| SpecValue nesnesi | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

