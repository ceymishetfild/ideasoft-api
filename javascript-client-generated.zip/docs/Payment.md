# IdeaSoftApi.Payment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Ödeme nesnesi kimlik değeri. | [optional] 
**memberFirstname** | **String** | Üyenin ismi. | 
**memberSurname** | **String** | Üyenin soy ismi. | 
**memberEmail** | **String** | Üyenin e-mail adresi. | 
**memberPhone** | **String** | Üyenin telefon numarası. | [optional] 
**paymentTypeName** | **String** | Ödeme tipi | 
**paymentProviderCode** | **String** | Ödeme hizmeti sağlayıcısı kodu. Bu değer ön tanımlıdır. | 
**paymentProviderName** | **String** | Ödeme hizmeti sağlayıcısı adı. Bu değer ön tanımlıdır. | 
**paymentGatewayName** | **String** | Ödeme kanalı adı. Bu değer ön tanımlıdır. | 
**paymentGatewayCode** | **String** | Ödeme kanalı kodu. Bu değer ön tanımlıdır. | 
**bankName** | **String** | Ödeme yapılan banka. Bu değer ön tanımlıdır. | [optional] 
**deviceType** | **String** | Ödemenin gerçekleştiği cihaz bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil&lt;br&gt;&lt;code&gt;tablet&lt;/code&gt; : Tablet&lt;br&gt;&lt;/div&gt; | 
**clientIp** | **String** | Müşterinin IP adresi. | 
**currencyRates** | **String** | Kur oranları. | 
**amount** | **Number** | Ödemenin saf fiyatı. | 
**finalAmount** | **Number** | Ödemenin son fiyatı. | 
**sumOfGainedPoints** | **Number** | Ödemeden kazanılan toplam puan. | [optional] 
**installment** | **Number** | Ödemenin standart taksit sayısı. | 
**installmentRate** | **Number** | Ödemenin taksit oranı. | 
**extraInstallment** | **Number** | Ödemenin ekstra taksit sayısı. | [optional] 
**currency** | **String** | Kur bilgisi. | 
**transactionId** | **String** | Siparişin numarası. | [optional] 
**memberNote** | **String** | Müşterinin ödeme notu. | [optional] 
**userNote** | **String** | Yönetici(admin) ödeme notu. | [optional] 
**status** | **String** | Ödeme durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;/div&gt; | 
**errorMessage** | **String** | Ödemenin hata mesajı. | [optional] 
**cardSavingSystem** | **String** | Kart saklama sistemi. | [optional] 
**createdAt** | **Date** | Ödeme nesnesinin oluşturulma zamanı. | [optional] 
**member** | [**Member**](Member.md) |  | [optional] 


<a name="DeviceTypeEnum"></a>
## Enum: DeviceTypeEnum


* `desktop` (value: `"desktop"`)

* `mobile` (value: `"mobile"`)

* `tablet` (value: `"tablet"`)




<a name="StatusEnum"></a>
## Enum: StatusEnum


* `deleted` (value: `"deleted"`)

* `waiting_for_approval` (value: `"waiting_for_approval"`)

* `approved` (value: `"approved"`)

* `fulfilled` (value: `"fulfilled"`)

* `cancelled` (value: `"cancelled"`)

* `delivered` (value: `"delivered"`)

* `on_accumulation` (value: `"on_accumulation"`)

* `waiting_for_payment` (value: `"waiting_for_payment"`)

* `being_prepared` (value: `"being_prepared"`)

* `refunded` (value: `"refunded"`)

* `personal_status_1` (value: `"personal_status_1"`)

* `personal_status_2` (value: `"personal_status_2"`)

* `personal_status_3` (value: `"personal_status_3"`)

* `failed` (value: `"failed"`)

* `in_transaction` (value: `"in_transaction"`)




