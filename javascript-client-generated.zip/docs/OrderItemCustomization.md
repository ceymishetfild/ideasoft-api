# IdeaSoftApi.OrderItemCustomization

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Sipariş kalemi özelleştirme kimlik değeri. | [optional] 
**productCustomizationGroupId** | **Number** | Ürün özelleştirme grubu nesnesi kimlik değeri. | [optional] 
**productCustomizationGroupName** | **String** | Ürün özelleştirme grubu nesnesinin grup adı. | [optional] 
**productCustomizationGroupSortOrder** | **Number** | Ürün özelleştirme grubu nesnesinin sıralaması. | [optional] 
**productCustomizationFieldId** | **Number** | Ürün özelleştirme nesnesi kimlik değeri.. | [optional] 
**productCustomizationFieldType** | **String** | Ürün özelleştirme nesnesinin alan tipi. | [optional] 
**productCustomizationFieldName** | **String** | Ürün özelleştirme nesnesinin alan adı. | [optional] 
**productCustomizationFieldValue** | **String** | Ürün özelleştirme nesnesinin değeri. | [optional] 
**cartItemAttributeId** | **Number** | Sepet kalemi özelliği nesnesi kimlik değeri. | [optional] 


