# IdeaSoftApi.OptionGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Varyant grubu nesnesi kimlik değeri. | [optional] 
**title** | **String** | Varyant grubunun başlığı. Varyant değeri kırmızı ise bu değer renk olabilir. | 
**sortOrder** | **Number** | Varyant grubunun sıralama değeri. | [optional] 
**filterStatus** | **String** | Varyant grubunun filtre menüsündeki gösterim durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Gösterilsin.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Gösterilmesin.&lt;br&gt;&lt;/div&gt; | [optional] 


<a name="FilterStatusEnum"></a>
## Enum: FilterStatusEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




