# IdeaSoftApi.TownGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**townGroupsGet**](TownGroupApi.md#townGroupsGet) | **GET** /town_groups | İlçe Grubu Listesi Alma
[**townGroupsIdDelete**](TownGroupApi.md#townGroupsIdDelete) | **DELETE** /town_groups/{id} | İlçe Grubu Silme
[**townGroupsIdGet**](TownGroupApi.md#townGroupsIdGet) | **GET** /town_groups/{id} | İlçe Grubu Alma
[**townGroupsIdPut**](TownGroupApi.md#townGroupsIdPut) | **PUT** /town_groups/{id} | İlçe Grubu Güncelleme
[**townGroupsPost**](TownGroupApi.md#townGroupsPost) | **POST** /town_groups | İlçe Grubu Oluşturma


<a name="townGroupsGet"></a>
# **townGroupsGet**
> TownGroup townGroupsGet(opts)

İlçe Grubu Listesi Alma

İlçe Grubu listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.TownGroupApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'name': "name_example" // String | İlçe Grubu adı
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.townGroupsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **String**| İlçe Grubu adı | [optional] 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townGroupsIdDelete"></a>
# **townGroupsIdDelete**
> townGroupsIdDelete(id)

İlçe Grubu Silme

Kalıcı olarak ilgili İlçe Grubunu siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.TownGroupApi();

var id = 56; // Number | İlçe Grubu nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.townGroupsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| İlçe Grubu nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townGroupsIdGet"></a>
# **townGroupsIdGet**
> TownGroup townGroupsIdGet(id)

İlçe Grubu Alma

İlgili İlçe Grubunu getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.TownGroupApi();

var id = 56; // Number | İlçe Grubu nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.townGroupsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| İlçe Grubu nesnesinin id değeri | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townGroupsIdPut"></a>
# **townGroupsIdPut**
> TownGroup townGroupsIdPut(id, townGroup)

İlçe Grubu Güncelleme

İlgili İlçe Grubunu günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.TownGroupApi();

var id = 56; // Number | İlçe Grubu nesnesinin id değeri

var townGroup = new IdeaSoftApi.TownGroup(); // TownGroup |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.townGroupsIdPut(id, townGroup, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| İlçe Grubu nesnesinin id değeri | 
 **townGroup** | [**TownGroup**](TownGroup.md)|  nesnesi | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townGroupsPost"></a>
# **townGroupsPost**
> TownGroup townGroupsPost(townGroup)

İlçe Grubu Oluşturma

Yeni bir İlçe Grubu oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.TownGroupApi();

var townGroup = new IdeaSoftApi.TownGroup(); // TownGroup |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.townGroupsPost(townGroup, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **townGroup** | [**TownGroup**](TownGroup.md)|  nesnesi | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

