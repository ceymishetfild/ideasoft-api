# IdeaSoftApi.ProductPrice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Ürün fiyatı nesnesi kimlik değeri. | [optional] 
**value** | **Number** | Ürün fiyatı değeri. | 
**type** | **Number** | Ürün fiyatı indexi. Fiyat 2, Fiyat 3 gibi. | 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 


