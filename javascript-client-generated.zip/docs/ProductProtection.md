# IdeaSoftApi.ProductProtection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Entegrasyon seçeneği nesnesi kimlik değeri. | [optional] 
**isPriceProtected** | **String** | Ürün fiyatının korumalı olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Korumalı.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Korumasız.&lt;br&gt;&lt;/div&gt; | [optional] 
**isStockProtected** | **String** | Ürün stoğunun korumalı olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Korumalı.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Korumasız.&lt;br&gt;&lt;/div&gt; | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 


<a name="IsPriceProtectedEnum"></a>
## Enum: IsPriceProtectedEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="IsStockProtectedEnum"></a>
## Enum: IsStockProtectedEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




