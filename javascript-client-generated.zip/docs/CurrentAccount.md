# IdeaSoftApi.CurrentAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Cari hesap nesnesi kimlik değeri. | [optional] 
**code** | **String** | Cari hesap için düzenlenebilir bir kod değeri. | [optional] 
**title** | **String** | Cari hesap nesnesinin başlığı. | 
**balance** | **Number** | Cari hesabın bakiyesi. | [optional] 
**riskLimit** | **Number** | Cari hesap için belirlenmiş risk limiti. | [optional] 
**createdAt** | **Date** | Cari hesap nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **Date** | Cari hesap nesnesinin güncellenme zamanı. | [optional] 
**member** | [**Member**](Member.md) | Üye nesnesi. | 


