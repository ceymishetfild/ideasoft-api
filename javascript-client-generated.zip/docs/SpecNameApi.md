# IdeaSoftApi.SpecNameApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specNamesGet**](SpecNameApi.md#specNamesGet) | **GET** /spec_names | Ürün Özelliği Listesi Alma
[**specNamesIdDelete**](SpecNameApi.md#specNamesIdDelete) | **DELETE** /spec_names/{id} | Ürün Özelliği Silme
[**specNamesIdGet**](SpecNameApi.md#specNamesIdGet) | **GET** /spec_names/{id} | Ürün Özelliği Alma
[**specNamesIdPut**](SpecNameApi.md#specNamesIdPut) | **PUT** /spec_names/{id} | Ürün Özelliği Güncelleme
[**specNamesPost**](SpecNameApi.md#specNamesPost) | **POST** /spec_names | Ürün Özelliği Oluşturma


<a name="specNamesGet"></a>
# **specNamesGet**
> SpecName specNamesGet(opts)

Ürün Özelliği Listesi Alma

Ürün Özelliği listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SpecNameApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'name': "name_example", // String | Ürün Özelliği adı
  'specGroup': 56, // Number | Ürün özellik grubu id
  'choiceType': "choiceType_example" // String | Status şu değerleri alabilir: <br><code>singular</code> : Tekil<br><code>plural</code> : Çoğul
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.specNamesGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **String**| Ürün Özelliği adı | [optional] 
 **specGroup** | **Number**| Ürün özellik grubu id | [optional] 
 **choiceType** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul | [optional] 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specNamesIdDelete"></a>
# **specNamesIdDelete**
> specNamesIdDelete(id)

Ürün Özelliği Silme

Kalıcı olarak ilgili Ürün Özelliğini siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SpecNameApi();

var id = 56; // Number | Ürün Özellik nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.specNamesIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specNamesIdGet"></a>
# **specNamesIdGet**
> SpecName specNamesIdGet(id)

Ürün Özelliği Alma

İlgili Ürün Özelliğini getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SpecNameApi();

var id = 56; // Number | Ürün Özellik nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.specNamesIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik nesnesinin id değeri | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specNamesIdPut"></a>
# **specNamesIdPut**
> SpecName specNamesIdPut(id, specName)

Ürün Özelliği Güncelleme

İlgili Ürün Özelliğini günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SpecNameApi();

var id = 56; // Number | Ürün Özellik nesnesinin id değeri

var specName = new IdeaSoftApi.SpecName(); // SpecName |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.specNamesIdPut(id, specName, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik nesnesinin id değeri | 
 **specName** | [**SpecName**](SpecName.md)|  nesnesi | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specNamesPost"></a>
# **specNamesPost**
> SpecName specNamesPost(specName)

Ürün Özelliği Oluşturma

Yeni bir Ürün Özelliği oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SpecNameApi();

var specName = new IdeaSoftApi.SpecName(); // SpecName |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.specNamesPost(specName, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specName** | [**SpecName**](SpecName.md)|  nesnesi | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

