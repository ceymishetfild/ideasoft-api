# IdeaSoftApi.OrderUserNote

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Sipariş yönetici notu nesnesi kimlik değeri. | [optional] 
**userEmail** | **String** | Yöneticinin(admin) e-mail adresi. | 
**userFirstname** | **String** | Yöneticinin(admin) ismi. | [optional] 
**userSurname** | **String** | Yöneticinin(admin) soy ismi. | [optional] 
**note** | **String** | Yöneticinin(admin) sipariş için girdiği not. | 
**createdAt** | **Date** | Sipariş yönetici notu nesnesinin oluşturulma zamanı. | 
**updatedAt** | **Date** | Sipariş yönetici notu nesnesinin güncellenme zamanı. | 
**order** | [**Order**](Order.md) | Sipariş nesnesi. | 


