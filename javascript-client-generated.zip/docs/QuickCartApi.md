# IdeaSoftApi.QuickCartApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**quickCartsGet**](QuickCartApi.md#quickCartsGet) | **GET** /quick_carts | Hızlı Satın Al Bağlantısı Alma
[**quickCartsIdDelete**](QuickCartApi.md#quickCartsIdDelete) | **DELETE** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Silme
[**quickCartsIdGet**](QuickCartApi.md#quickCartsIdGet) | **GET** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Alma
[**quickCartsIdPut**](QuickCartApi.md#quickCartsIdPut) | **PUT** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Güncelleme
[**quickCartsPost**](QuickCartApi.md#quickCartsPost) | **POST** /quick_carts | Hızlı Satın Al Bağlantısı Oluşturma


<a name="quickCartsGet"></a>
# **quickCartsGet**
> QuickCart quickCartsGet(opts)

Hızlı Satın Al Bağlantısı Alma

Hızlı Satın Al Bağlantısı döndürür.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.QuickCartApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'name': "name_example" // String | Hızlı Satın Al Bağlantısı adı
};

apiInstance.quickCartsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **String**| Hızlı Satın Al Bağlantısı adı | [optional] 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="quickCartsIdDelete"></a>
# **quickCartsIdDelete**
> quickCartsIdDelete(id)

Hızlı Satın Al Bağlantısı Silme

Kalıcı olarak ilgili Hızlı Satın Al Bağlantısını siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.QuickCartApi();

let id = 56; // Number | Hızlı Satın Al nesnesinin id değeri


apiInstance.quickCartsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Hızlı Satın Al nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="quickCartsIdGet"></a>
# **quickCartsIdGet**
> QuickCart quickCartsIdGet(id)

Hızlı Satın Al Bağlantısı Alma

İlgili Hızlı Satın Al Bağlantısını getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.QuickCartApi();

let id = 56; // Number | Hızlı Satın Al nesnesinin id değeri


apiInstance.quickCartsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Hızlı Satın Al nesnesinin id değeri | 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="quickCartsIdPut"></a>
# **quickCartsIdPut**
> QuickCart quickCartsIdPut(id, quickCart)

Hızlı Satın Al Bağlantısı Güncelleme

İlgili Hızlı Satın Al Bağlantısını günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.QuickCartApi();

let id = 56; // Number | Hızlı Satın Al nesnesinin id değeri

let quickCart = new IdeaSoftApi.QuickCart(); // QuickCart | QuickCart nesnesi


apiInstance.quickCartsIdPut(id, quickCart, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Hızlı Satın Al nesnesinin id değeri | 
 **quickCart** | [**QuickCart**](QuickCart.md)| QuickCart nesnesi | 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="quickCartsPost"></a>
# **quickCartsPost**
> QuickCart quickCartsPost(quickCart)

Hızlı Satın Al Bağlantısı Oluşturma

Yeni bir Hızlı Satın Al Bağlantısı oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.QuickCartApi();

let quickCart = new IdeaSoftApi.QuickCart(); // QuickCart | QuickCart nesnesi


apiInstance.quickCartsPost(quickCart, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **quickCart** | [**QuickCart**](QuickCart.md)| QuickCart nesnesi | 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

