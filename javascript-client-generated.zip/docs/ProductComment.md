# IdeaSoftApi.ProductComment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Ürün yorumu nesnesi kimlik değeri. | [optional] 
**title** | **String** | Ürün yorumu başlığı. | 
**content** | **String** | Ürün yorumu içeriği. | 
**status** | **Boolean** | Ürün yorumu durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**rank** | **Number** | Ürün yorumunda ürüne verilen puan.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 1 puan.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : 2 puan.&lt;br&gt;&lt;code&gt;3&lt;/code&gt; : 3 puan.&lt;br&gt;&lt;code&gt;4&lt;/code&gt; : 4 puan.&lt;br&gt;&lt;code&gt;5&lt;/code&gt; : 5 puan.&lt;br&gt;&lt;/div&gt; | 
**isAnonymous** | **Boolean** | Ürün yorumu yapan kişinin anonim olup olmadığı bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Anonim.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Anonim değil.&lt;br&gt;&lt;/div&gt; | 
**createdAt** | **Date** | Ürün yorumu nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **Date** | Ürün yorumu nesnesinin güncellenme zamanı. | [optional] 
**member** | [**Member**](Member.md) | Yorumu yapan üye. | [optional] 
**product** | [**Product**](Product.md) | Yorum yapılan ürün. | [optional] 


<a name="RankEnum"></a>
## Enum: RankEnum


* `1` (value: `1`)

* `2` (value: `2`)

* `3` (value: `3`)

* `4` (value: `4`)

* `5` (value: `5`)




