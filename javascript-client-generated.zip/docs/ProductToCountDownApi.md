# IdeaSoftApi.ProductToCountDownApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productToCountDownsGet**](ProductToCountDownApi.md#productToCountDownsGet) | **GET** /product_to_count_downs | Ürün Geri Sayım Bağı Listesi Alma
[**productToCountDownsIdDelete**](ProductToCountDownApi.md#productToCountDownsIdDelete) | **DELETE** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Silme
[**productToCountDownsIdGet**](ProductToCountDownApi.md#productToCountDownsIdGet) | **GET** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Alma
[**productToCountDownsIdPut**](ProductToCountDownApi.md#productToCountDownsIdPut) | **PUT** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Güncelleme
[**productToCountDownsPost**](ProductToCountDownApi.md#productToCountDownsPost) | **POST** /product_to_count_downs | Ürün Geri Sayım Bağı Oluşturma


<a name="productToCountDownsGet"></a>
# **productToCountDownsGet**
> ProductToCountDown productToCountDownsGet(opts)

Ürün Geri Sayım Bağı Listesi Alma

Ürün Geri Sayım Bağı listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductToCountDownApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'product': 56 // Number | Ürün id
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productToCountDownsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **product** | **Number**| Ürün id | [optional] 

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCountDownsIdDelete"></a>
# **productToCountDownsIdDelete**
> productToCountDownsIdDelete(id)

Ürün Geri Sayım Bağı Silme

Kalıcı olarak ilgili Ürün Geri Sayım Bağını siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductToCountDownApi();

var id = 56; // Number | Ürün Geri Sayım Bağı nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.productToCountDownsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Geri Sayım Bağı nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCountDownsIdGet"></a>
# **productToCountDownsIdGet**
> ProductToCountDown productToCountDownsIdGet(id)

Ürün Geri Sayım Bağı Alma

İlgili Ürün Geri Sayım Bağını getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductToCountDownApi();

var id = 56; // Number | Ürün Geri Sayım Bağı nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productToCountDownsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Geri Sayım Bağı nesnesinin id değeri | 

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCountDownsIdPut"></a>
# **productToCountDownsIdPut**
> ProductToCountDown productToCountDownsIdPut(id, productToCountDown)

Ürün Geri Sayım Bağı Güncelleme

İlgili Ürün Geri Sayım Bağını günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductToCountDownApi();

var id = 56; // Number | Ürün Geri Sayım Bağı nesnesinin id değeri

var productToCountDown = new IdeaSoftApi.ProductToCountDown(); // ProductToCountDown |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productToCountDownsIdPut(id, productToCountDown, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Geri Sayım Bağı nesnesinin id değeri | 
 **productToCountDown** | [**ProductToCountDown**](ProductToCountDown.md)|  nesnesi | 

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCountDownsPost"></a>
# **productToCountDownsPost**
> ProductToCountDown productToCountDownsPost(productToCountDown)

Ürün Geri Sayım Bağı Oluşturma

Yeni bir Ürün Geri Sayım Bağı oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductToCountDownApi();

var productToCountDown = new IdeaSoftApi.ProductToCountDown(); // ProductToCountDown |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productToCountDownsPost(productToCountDown, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productToCountDown** | [**ProductToCountDown**](ProductToCountDown.md)|  nesnesi | 

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

