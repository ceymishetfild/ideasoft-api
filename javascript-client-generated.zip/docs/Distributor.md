# IdeaSoftApi.Distributor

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Distributor nesnesi kimlik değeri. | [optional] 
**name** | **String** | Distributor nesnesi için isim değeri. | 
**email** | **String** | E-mail adresi. | [optional] 
**phone** | **String** | Telefon numarası. | [optional] 
**contactPerson** | **String** | İletişim kişisi. | [optional] 


