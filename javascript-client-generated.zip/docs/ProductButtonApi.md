# IdeaSoftApi.ProductButtonApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productButtonsGet**](ProductButtonApi.md#productButtonsGet) | **GET** /product_buttons | Ürün ve Stok Butonu Listesi Alma
[**productButtonsIdDelete**](ProductButtonApi.md#productButtonsIdDelete) | **DELETE** /product_buttons/{id} | Ürün ve Stok Butonu Silme
[**productButtonsIdGet**](ProductButtonApi.md#productButtonsIdGet) | **GET** /product_buttons/{id} | Ürün ve Stok Butonu Alma
[**productButtonsIdPut**](ProductButtonApi.md#productButtonsIdPut) | **PUT** /product_buttons/{id} | Ürün ve Stok Butonu Güncelleme
[**productButtonsPost**](ProductButtonApi.md#productButtonsPost) | **POST** /product_buttons | Ürün ve Stok Butonu Oluşturma


<a name="productButtonsGet"></a>
# **productButtonsGet**
> ProductButton productButtonsGet(opts)

Ürün ve Stok Butonu Listesi Alma

Ürün ve Stok Butonu listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductButtonApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'fastShipping': "fastShipping_example", // String | Hızlı Gönderi butonuna sahip ürünler<code>0</code><br><code>1</code>
  'sameDayShipping': "sameDayShipping_example", // String | Aynı Gün Kargo butonuna sahip ürünler<code>0</code><br><code>1</code>
  'threeDaysDelivery': "threeDaysDelivery_example", // String | 3 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
  'fiveDaysDelivery': "fiveDaysDelivery_example", // String | 5 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
  'sevenDaysDelivery': "sevenDaysDelivery_example", // String | 7 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
  'freeShipping': "freeShipping_example", // String | Kargo Bedava butonuna sahip ürünler<code>0</code><br><code>1</code>
  'deliveryFromStock': "deliveryFromStock_example", // String | Stoktan Teslim butonuna sahip ürünler<code>0</code><br><code>1</code>
  'preOrderedProduct': "preOrderedProduct_example", // String | Ön Siparişli Ürün butonuna sahip ürünler<code>0</code><br><code>1</code>
  'askStock': "askStock_example", // String | Stok Sorunuz butonuna sahip ürünler<code>0</code><br><code>1</code>
  'campaignedProduct': "campaignedProduct_example", // String | Kampanyalı Ürün butonuna sahip ürünler<code>0</code><br><code>1</code>
  'product': 56 // Number | Ürün id
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productButtonsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **fastShipping** | **String**| Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **sameDayShipping** | **String**| Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **threeDaysDelivery** | **String**| 3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **fiveDaysDelivery** | **String**| 5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **sevenDaysDelivery** | **String**| 7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **freeShipping** | **String**| Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **deliveryFromStock** | **String**| Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **preOrderedProduct** | **String**| Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **askStock** | **String**| Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **campaignedProduct** | **String**| Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **product** | **Number**| Ürün id | [optional] 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productButtonsIdDelete"></a>
# **productButtonsIdDelete**
> productButtonsIdDelete(id)

Ürün ve Stok Butonu Silme

Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductButtonApi();

var id = 56; // Number | Ürün ve Stok Butonu nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.productButtonsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productButtonsIdGet"></a>
# **productButtonsIdGet**
> ProductButton productButtonsIdGet(id)

Ürün ve Stok Butonu Alma

İlgili Ürün ve Stok Butonunu getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductButtonApi();

var id = 56; // Number | Ürün ve Stok Butonu nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productButtonsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productButtonsIdPut"></a>
# **productButtonsIdPut**
> ProductButton productButtonsIdPut(id, productButton)

Ürün ve Stok Butonu Güncelleme

İlgili Ürün ve Stok Butonunu günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductButtonApi();

var id = 56; // Number | Ürün ve Stok Butonu nesnesinin id değeri

var productButton = new IdeaSoftApi.ProductButton(); // ProductButton |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productButtonsIdPut(id, productButton, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün ve Stok Butonu nesnesinin id değeri | 
 **productButton** | [**ProductButton**](ProductButton.md)|  nesnesi | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productButtonsPost"></a>
# **productButtonsPost**
> ProductButton productButtonsPost(productButton)

Ürün ve Stok Butonu Oluşturma

Yeni bir Ürün ve Stok Butonu oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductButtonApi();

var productButton = new IdeaSoftApi.ProductButton(); // ProductButton |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productButtonsPost(productButton, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productButton** | [**ProductButton**](ProductButton.md)|  nesnesi | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

