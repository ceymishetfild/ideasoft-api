# IdeaSoftApi.ProductButtonApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productButtonsGet**](ProductButtonApi.md#productButtonsGet) | **GET** /product_buttons | Ürün ve Stok Butonu Listesi Alma
[**productButtonsIdDelete**](ProductButtonApi.md#productButtonsIdDelete) | **DELETE** /product_buttons/{id} | Ürün ve Stok Butonu Silme
[**productButtonsIdGet**](ProductButtonApi.md#productButtonsIdGet) | **GET** /product_buttons/{id} | Ürün ve Stok Butonu Alma
[**productButtonsIdPut**](ProductButtonApi.md#productButtonsIdPut) | **PUT** /product_buttons/{id} | Ürün ve Stok Butonu Güncelleme
[**productButtonsPost**](ProductButtonApi.md#productButtonsPost) | **POST** /product_buttons | Ürün ve Stok Butonu Oluşturma


<a name="productButtonsGet"></a>
# **productButtonsGet**
> ProductButton productButtonsGet(opts)

Ürün ve Stok Butonu Listesi Alma

Ürün ve Stok Butonu listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductButtonApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'fastShipping': 56, // Number | Hızlı Gönderi butonuna sahip ürünler<code>0</code><br><code>1</code>
  'sameDayShipping': 56, // Number | Aynı Gün Kargo butonuna sahip ürünler<code>0</code><br><code>1</code>
  'threeDaysDelivery': 56, // Number | 3 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
  'fiveDaysDelivery': 56, // Number | 5 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
  'sevenDaysDelivery': 56, // Number | 7 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
  'freeShipping': 56, // Number | Kargo Bedava butonuna sahip ürünler<code>0</code><br><code>1</code>
  'deliveryFromStock': 56, // Number | Stoktan Teslim butonuna sahip ürünler<code>0</code><br><code>1</code>
  'preOrderedProduct': 56, // Number | Ön Siparişli Ürün butonuna sahip ürünler<code>0</code><br><code>1</code>
  'askStock': 56, // Number | Stok Sorunuz butonuna sahip ürünler<code>0</code><br><code>1</code>
  'campaignedProduct': 56, // Number | Kampanyalı Ürün butonuna sahip ürünler<code>0</code><br><code>1</code>
  'product': 56 // Number | Ürün id
};

apiInstance.productButtonsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **fastShipping** | **Number**| Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **sameDayShipping** | **Number**| Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **threeDaysDelivery** | **Number**| 3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **fiveDaysDelivery** | **Number**| 5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **sevenDaysDelivery** | **Number**| 7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **freeShipping** | **Number**| Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **deliveryFromStock** | **Number**| Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **preOrderedProduct** | **Number**| Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **askStock** | **Number**| Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **campaignedProduct** | **Number**| Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **product** | **Number**| Ürün id | [optional] 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productButtonsIdDelete"></a>
# **productButtonsIdDelete**
> productButtonsIdDelete(id)

Ürün ve Stok Butonu Silme

Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductButtonApi();

let id = 56; // Number | Ürün ve Stok Butonu nesnesinin id değeri


apiInstance.productButtonsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productButtonsIdGet"></a>
# **productButtonsIdGet**
> ProductButton productButtonsIdGet(id)

Ürün ve Stok Butonu Alma

İlgili Ürün ve Stok Butonunu getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductButtonApi();

let id = 56; // Number | Ürün ve Stok Butonu nesnesinin id değeri


apiInstance.productButtonsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productButtonsIdPut"></a>
# **productButtonsIdPut**
> ProductButton productButtonsIdPut(id, productButton)

Ürün ve Stok Butonu Güncelleme

İlgili Ürün ve Stok Butonunu günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductButtonApi();

let id = 56; // Number | Ürün ve Stok Butonu nesnesinin id değeri

let productButton = new IdeaSoftApi.ProductButton(); // ProductButton | ProductButton nesnesi


apiInstance.productButtonsIdPut(id, productButton, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün ve Stok Butonu nesnesinin id değeri | 
 **productButton** | [**ProductButton**](ProductButton.md)| ProductButton nesnesi | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productButtonsPost"></a>
# **productButtonsPost**
> ProductButton productButtonsPost(productButton)

Ürün ve Stok Butonu Oluşturma

Yeni bir Ürün ve Stok Butonu oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductButtonApi();

let productButton = new IdeaSoftApi.ProductButton(); // ProductButton | ProductButton nesnesi


apiInstance.productButtonsPost(productButton, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productButton** | [**ProductButton**](ProductButton.md)| ProductButton nesnesi | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

