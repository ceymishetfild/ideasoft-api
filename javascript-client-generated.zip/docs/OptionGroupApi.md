# IdeaSoftApi.OptionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**optionGroupsGet**](OptionGroupApi.md#optionGroupsGet) | **GET** /option_groups | Varyant Grubu Listesi Alma
[**optionGroupsIdDelete**](OptionGroupApi.md#optionGroupsIdDelete) | **DELETE** /option_groups/{id} | Varyant Grubu Silme
[**optionGroupsIdGet**](OptionGroupApi.md#optionGroupsIdGet) | **GET** /option_groups/{id} | Varyant Grubu Alma
[**optionGroupsIdPut**](OptionGroupApi.md#optionGroupsIdPut) | **PUT** /option_groups/{id} | Varyant Grubu Güncelleme
[**optionGroupsPost**](OptionGroupApi.md#optionGroupsPost) | **POST** /option_groups | Varyant Grubu Oluşturma


<a name="optionGroupsGet"></a>
# **optionGroupsGet**
> OptionGroup optionGroupsGet(opts)

Varyant Grubu Listesi Alma

Varyant Grubu listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OptionGroupApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'title': "title_example" // String | Varyant Grubu başlığı.
};

apiInstance.optionGroupsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **title** | **String**| Varyant Grubu başlığı. | [optional] 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionGroupsIdDelete"></a>
# **optionGroupsIdDelete**
> optionGroupsIdDelete(id)

Varyant Grubu Silme

Kalıcı olarak ilgili Varyant Grubunu siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OptionGroupApi();

let id = 56; // Number | Varyant Grubu nesnesinin id değeri


apiInstance.optionGroupsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Varyant Grubu nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionGroupsIdGet"></a>
# **optionGroupsIdGet**
> OptionGroup optionGroupsIdGet(id)

Varyant Grubu Alma

İlgili Varyant Grubunu getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OptionGroupApi();

let id = 56; // Number | Varyant Grubu nesnesinin id değeri


apiInstance.optionGroupsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Varyant Grubu nesnesinin id değeri | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionGroupsIdPut"></a>
# **optionGroupsIdPut**
> OptionGroup optionGroupsIdPut(id, optionGroup)

Varyant Grubu Güncelleme

İlgili Varyant Grubunu günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OptionGroupApi();

let id = 56; // Number | Varyant Grubu nesnesinin id değeri

let optionGroup = new IdeaSoftApi.OptionGroup(); // OptionGroup | OptionGroup nesnesi


apiInstance.optionGroupsIdPut(id, optionGroup, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Varyant Grubu nesnesinin id değeri | 
 **optionGroup** | [**OptionGroup**](OptionGroup.md)| OptionGroup nesnesi | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="optionGroupsPost"></a>
# **optionGroupsPost**
> OptionGroup optionGroupsPost(optionGroup)

Varyant Grubu Oluşturma

Yeni bir Varyant Grubu oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OptionGroupApi();

let optionGroup = new IdeaSoftApi.OptionGroup(); // OptionGroup | OptionGroup nesnesi


apiInstance.optionGroupsPost(optionGroup, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **optionGroup** | [**OptionGroup**](OptionGroup.md)| OptionGroup nesnesi | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

