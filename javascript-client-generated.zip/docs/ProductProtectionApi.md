# IdeaSoftApi.ProductProtectionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productProtectionsGet**](ProductProtectionApi.md#productProtectionsGet) | **GET** /product_protections | Entegrasyon Seçeneği Listesi Alma
[**productProtectionsIdDelete**](ProductProtectionApi.md#productProtectionsIdDelete) | **DELETE** /product_protections/{id} | Entegrasyon Seçeneği Silme
[**productProtectionsIdGet**](ProductProtectionApi.md#productProtectionsIdGet) | **GET** /product_protections/{id} | Entegrasyon Seçeneği Alma
[**productProtectionsIdPut**](ProductProtectionApi.md#productProtectionsIdPut) | **PUT** /product_protections/{id} | Entegrasyon Seçeneği Güncelleme
[**productProtectionsPost**](ProductProtectionApi.md#productProtectionsPost) | **POST** /product_protections | Entegrasyon Seçeneği Oluşturma


<a name="productProtectionsGet"></a>
# **productProtectionsGet**
> ProductProtection productProtectionsGet(opts)

Entegrasyon Seçeneği Listesi Alma

Entegrasyon Seçeneği listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductProtectionApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'isPriceProtected': 56, // Number | Fiyat korumalı ürünleri listeler<code>0</code><br><code>1</code>
  'isStockProtected': 56, // Number | Stok korumalı ürünleri listeler<code>0</code><br><code>1</code>
  'product': 56 // Number | Ürün id
};

apiInstance.productProtectionsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **isPriceProtected** | **Number**| Fiyat korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **isStockProtected** | **Number**| Stok korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **product** | **Number**| Ürün id | [optional] 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productProtectionsIdDelete"></a>
# **productProtectionsIdDelete**
> productProtectionsIdDelete(id)

Entegrasyon Seçeneği Silme

Kalıcı olarak ilgili Entegrasyon Seçeneğini siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductProtectionApi();

let id = 56; // Number | Entegrasyon Seçeneği nesnesinin id değeri


apiInstance.productProtectionsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Entegrasyon Seçeneği nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productProtectionsIdGet"></a>
# **productProtectionsIdGet**
> ProductProtection productProtectionsIdGet(id)

Entegrasyon Seçeneği Alma

İlgili Entegrasyon Seçeneğini getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductProtectionApi();

let id = 56; // Number | Entegrasyon Seçeneği nesnesinin id değeri


apiInstance.productProtectionsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Entegrasyon Seçeneği nesnesinin id değeri | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productProtectionsIdPut"></a>
# **productProtectionsIdPut**
> ProductProtection productProtectionsIdPut(id, productProtection)

Entegrasyon Seçeneği Güncelleme

İlgili Entegrasyon Seçeneğini günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductProtectionApi();

let id = 56; // Number | Entegrasyon Seçeneği nesnesinin id değeri

let productProtection = new IdeaSoftApi.ProductProtection(); // ProductProtection | ProductProtection nesnesi


apiInstance.productProtectionsIdPut(id, productProtection, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Entegrasyon Seçeneği nesnesinin id değeri | 
 **productProtection** | [**ProductProtection**](ProductProtection.md)| ProductProtection nesnesi | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productProtectionsPost"></a>
# **productProtectionsPost**
> ProductProtection productProtectionsPost(productProtection)

Entegrasyon Seçeneği Oluşturma

Yeni bir Entegrasyon Seçeneği oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductProtectionApi();

let productProtection = new IdeaSoftApi.ProductProtection(); // ProductProtection | ProductProtection nesnesi


apiInstance.productProtectionsPost(productProtection, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productProtection** | [**ProductProtection**](ProductProtection.md)| ProductProtection nesnesi | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

