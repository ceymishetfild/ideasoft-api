# IdeaSoftApi.MemberAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**memberAddressesGet**](MemberAddressApi.md#memberAddressesGet) | **GET** /member_addresses | Üye Adresi Listeleme
[**memberAddressesIdDelete**](MemberAddressApi.md#memberAddressesIdDelete) | **DELETE** /member_addresses/{id} | Üye Adresi Silme
[**memberAddressesIdGet**](MemberAddressApi.md#memberAddressesIdGet) | **GET** /member_addresses/{id} | Üye Adresi Alma
[**memberAddressesIdPut**](MemberAddressApi.md#memberAddressesIdPut) | **PUT** /member_addresses/{id} | Üye Adresi Güncelleme
[**memberAddressesPost**](MemberAddressApi.md#memberAddressesPost) | **POST** /member_addresses | Üye Adresi Oluşturma


<a name="memberAddressesGet"></a>
# **memberAddressesGet**
> MemberAddress memberAddressesGet(opts)

Üye Adresi Listeleme

Üye Adresi listesi verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.MemberAddressApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'member': 56, // Number | Üye id
  'startDate': new Date("2013-10-20"), // Date | createdAt değeri için başlangıç tarihi
  'endDate': "endDate_example" // String | createdAt değeri için bitiş tarihi
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.memberAddressesGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **member** | **Number**| Üye id | [optional] 
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional] 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberAddressesIdDelete"></a>
# **memberAddressesIdDelete**
> memberAddressesIdDelete(id)

Üye Adresi Silme

Kalıcı olarak ilgili Üye Adresini siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.MemberAddressApi();

var id = 56; // Number | Üye Adresi nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.memberAddressesIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Üye Adresi nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberAddressesIdGet"></a>
# **memberAddressesIdGet**
> MemberAddress memberAddressesIdGet(id)

Üye Adresi Alma

İlgili Üye Adresini getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.MemberAddressApi();

var id = 56; // Number | Üye Adresi nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.memberAddressesIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Üye Adresi nesnesinin id değeri | 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberAddressesIdPut"></a>
# **memberAddressesIdPut**
> MemberAddress memberAddressesIdPut(id, memberAddress)

Üye Adresi Güncelleme

İlgili Üye Adresini günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.MemberAddressApi();

var id = 56; // Number | Üye Adresi nesnesinin id değeri

var memberAddress = new IdeaSoftApi.MemberAddress(); // MemberAddress |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.memberAddressesIdPut(id, memberAddress, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Üye Adresi nesnesinin id değeri | 
 **memberAddress** | [**MemberAddress**](MemberAddress.md)|  nesnesi | 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberAddressesPost"></a>
# **memberAddressesPost**
> MemberAddress memberAddressesPost(memberAddress)

Üye Adresi Oluşturma

Yeni bir Üye Adresi oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.MemberAddressApi();

var memberAddress = new IdeaSoftApi.MemberAddress(); // MemberAddress |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.memberAddressesPost(memberAddress, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **memberAddress** | [**MemberAddress**](MemberAddress.md)|  nesnesi | 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

