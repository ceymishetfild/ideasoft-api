# IdeaSoftApi.CartItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Sepet kalemi nesnesi kimlik değeri. | [optional] 
**parentProductId** | **Number** | Ana ürünün benzersiz rakamsal kimlik değeri. | [optional] 
**quantity** | **Number** | Sepetteki kalem adedi. | 
**categoryId** | **Number** | Sepetteki kaleme ait kategorinin benzersiz kimlik değeri. | [optional] 
**createdAt** | **Date** | Sepet kalemi nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **Date** | Sepet kalemi nesnesinin güncellenme zamanı. | [optional] 
**cart** | [**Cart**](Cart.md) | Sepet nesnesi. | 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 
**attributes** | [**[CartItemAttribute]**](CartItemAttribute.md) | Sepet kalemi özelliği barındıran liste. | [optional] 


