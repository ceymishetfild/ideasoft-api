# IdeaSoftApi.OrderRefundRequestApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**orderRefundRequestsGet**](OrderRefundRequestApi.md#orderRefundRequestsGet) | **GET** /order_refund_requests | Sipariş İptal Talebi Listesi Alma
[**orderRefundRequestsIdDelete**](OrderRefundRequestApi.md#orderRefundRequestsIdDelete) | **DELETE** /order_refund_requests/{id} | Sipariş İptal Talebi Silme
[**orderRefundRequestsIdGet**](OrderRefundRequestApi.md#orderRefundRequestsIdGet) | **GET** /order_refund_requests/{id} | Sipariş İptal Talebi Alma
[**orderRefundRequestsIdPut**](OrderRefundRequestApi.md#orderRefundRequestsIdPut) | **PUT** /order_refund_requests/{id} | Sipariş İptal Talebi Güncelleme
[**orderRefundRequestsPost**](OrderRefundRequestApi.md#orderRefundRequestsPost) | **POST** /order_refund_requests | Sipariş İptal Talebi Oluşturma


<a name="orderRefundRequestsGet"></a>
# **orderRefundRequestsGet**
> OrderRefundRequest orderRefundRequestsGet(opts)

Sipariş İptal Talebi Listesi Alma

Sipariş İptal Talebi listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OrderRefundRequestApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'order': 56, // Number | Sipariş id
  'member': 56, // Number | Üye id
  'code': "code_example", // String | Sipariş İptal Talebi kodu
  'status': "status_example", // String | Status şu değerleri alabilir: <br><code>waiting_for_approval</code> : Onay bekliyor<br><code>approved</code> : Onaylandı<br><code>cancelled</code> : İptal edildi
  'startDate': new Date("2013-10-20"), // Date | createdAt değeri için başlangıç tarihi
  'endDate': "endDate_example", // String | createdAt değeri için bitiş tarihi
  'startUpdatedAt': new Date("2013-10-20"), // Date | updatedAt değeri için başlangıç tarihi
  'endUpdatedAt': "endUpdatedAt_example" // String | updatedAt değeri için bitiş tarihi
};

apiInstance.orderRefundRequestsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **Number**| Sipariş id | [optional] 
 **member** | **Number**| Üye id | [optional] 
 **code** | **String**| Sipariş İptal Talebi kodu | [optional] 
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi | [optional] 
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderRefundRequestsIdDelete"></a>
# **orderRefundRequestsIdDelete**
> orderRefundRequestsIdDelete(id)

Sipariş İptal Talebi Silme

Kalıcı olarak ilgili Sipariş İptal Talebini siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OrderRefundRequestApi();

let id = 56; // Number | Sipariş İptal Talebi nesnesinin id değeri


apiInstance.orderRefundRequestsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sipariş İptal Talebi nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderRefundRequestsIdGet"></a>
# **orderRefundRequestsIdGet**
> OrderRefundRequest orderRefundRequestsIdGet(id)

Sipariş İptal Talebi Alma

İlgili Sipariş İptal Talebini getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OrderRefundRequestApi();

let id = 56; // Number | Sipariş İptal Talebi nesnesinin id değeri


apiInstance.orderRefundRequestsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sipariş İptal Talebi nesnesinin id değeri | 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderRefundRequestsIdPut"></a>
# **orderRefundRequestsIdPut**
> OrderRefundRequest orderRefundRequestsIdPut(id, orderRefundRequest)

Sipariş İptal Talebi Güncelleme

İlgili Sipariş İptal Talebini günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OrderRefundRequestApi();

let id = 56; // Number | Sipariş İptal Talebi nesnesinin id değeri

let orderRefundRequest = new IdeaSoftApi.OrderRefundRequest(); // OrderRefundRequest | OrderRefundRequest nesnesi


apiInstance.orderRefundRequestsIdPut(id, orderRefundRequest, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sipariş İptal Talebi nesnesinin id değeri | 
 **orderRefundRequest** | [**OrderRefundRequest**](OrderRefundRequest.md)| OrderRefundRequest nesnesi | 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderRefundRequestsPost"></a>
# **orderRefundRequestsPost**
> OrderRefundRequest orderRefundRequestsPost(orderRefundRequest)

Sipariş İptal Talebi Oluşturma

Yeni bir Sipariş İptal Talebi oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OrderRefundRequestApi();

let orderRefundRequest = new IdeaSoftApi.OrderRefundRequest(); // OrderRefundRequest | OrderRefundRequest nesnesi


apiInstance.orderRefundRequestsPost(orderRefundRequest, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orderRefundRequest** | [**OrderRefundRequest**](OrderRefundRequest.md)| OrderRefundRequest nesnesi | 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

