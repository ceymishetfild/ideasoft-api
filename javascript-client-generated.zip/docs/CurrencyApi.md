# IdeaSoftApi.CurrencyApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**currenciesGet**](CurrencyApi.md#currenciesGet) | **GET** /currencies | Kur Listesi Alma
[**currenciesIdGet**](CurrencyApi.md#currenciesIdGet) | **GET** /currencies/{id} | Kur Alma
[**currenciesIdPut**](CurrencyApi.md#currenciesIdPut) | **PUT** /currencies/{id} | Kur Güncelleme


<a name="currenciesGet"></a>
# **currenciesGet**
> Currency currenciesGet(opts)

Kur Listesi Alma

Kur listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.CurrencyApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'label': "label_example", // String | Kur etiketi
  'abbr': "abbr_example", // String | Kur kısaltması
  'status': 56 // Number | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
};

apiInstance.currenciesGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **label** | **String**| Kur etiketi | [optional] 
 **abbr** | **String**| Kur kısaltması | [optional] 
 **status** | **Number**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 

### Return type

[**Currency**](Currency.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="currenciesIdGet"></a>
# **currenciesIdGet**
> Currency currenciesIdGet(id)

Kur Alma

İlgili Kur getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.CurrencyApi();

let id = 56; // Number | Kur nesnesinin id değeri


apiInstance.currenciesIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Kur nesnesinin id değeri | 

### Return type

[**Currency**](Currency.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="currenciesIdPut"></a>
# **currenciesIdPut**
> Currency currenciesIdPut(id, currency)

Kur Güncelleme

İlgili Kur günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.CurrencyApi();

let id = 56; // Number | Kur nesnesinin id değeri

let currency = new IdeaSoftApi.Currency(); // Currency | Currency nesnesi


apiInstance.currenciesIdPut(id, currency, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Kur nesnesinin id değeri | 
 **currency** | [**Currency**](Currency.md)| Currency nesnesi | 

### Return type

[**Currency**](Currency.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

