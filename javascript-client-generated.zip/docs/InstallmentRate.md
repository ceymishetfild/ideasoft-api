# IdeaSoftApi.InstallmentRate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Taksit oranı nesnesi kimlik değeri. | [optional] 
**installment** | **Number** | Taksit adeti. | 
**rate** | **Number** | Taksit adeti için oran bilgisi. | 
**paymentGateway** | [**PaymentGateway**](PaymentGateway.md) |  | [optional] 


