# IdeaSoftApi.ExtraInfoToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extraInfoToProductsGet**](ExtraInfoToProductApi.md#extraInfoToProductsGet) | **GET** /extra_info_to_products | Ek Bilgi Ürün Bağı Listesi Alma
[**extraInfoToProductsIdDelete**](ExtraInfoToProductApi.md#extraInfoToProductsIdDelete) | **DELETE** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Silme
[**extraInfoToProductsIdGet**](ExtraInfoToProductApi.md#extraInfoToProductsIdGet) | **GET** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Alma
[**extraInfoToProductsIdPut**](ExtraInfoToProductApi.md#extraInfoToProductsIdPut) | **PUT** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Güncelleme
[**extraInfoToProductsPost**](ExtraInfoToProductApi.md#extraInfoToProductsPost) | **POST** /extra_info_to_products | Ek Bilgi Ürün Bağı Oluşturma


<a name="extraInfoToProductsGet"></a>
# **extraInfoToProductsGet**
> ExtraInfoToProduct extraInfoToProductsGet(opts)

Ek Bilgi Ürün Bağı Listesi Alma

Ek Bilgi Ürün Bağı listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ExtraInfoToProductApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'extraInfo': 56, // Number | Ek bilgi id
  'product': 56 // Number | Ürün id
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.extraInfoToProductsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **extraInfo** | **Number**| Ek bilgi id | [optional] 
 **product** | **Number**| Ürün id | [optional] 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfoToProductsIdDelete"></a>
# **extraInfoToProductsIdDelete**
> extraInfoToProductsIdDelete(id)

Ek Bilgi Ürün Bağı Silme

Kalıcı olarak ilgili Ek Bilgi Ürün Bağını siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ExtraInfoToProductApi();

var id = 56; // Number | Ek Bilgi Ürün Bağı nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.extraInfoToProductsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfoToProductsIdGet"></a>
# **extraInfoToProductsIdGet**
> ExtraInfoToProduct extraInfoToProductsIdGet(id)

Ek Bilgi Ürün Bağı Alma

İlgili Ek Bilgi Ürün Bağını getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ExtraInfoToProductApi();

var id = 56; // Number | Ek Bilgi Ürün Bağı nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.extraInfoToProductsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfoToProductsIdPut"></a>
# **extraInfoToProductsIdPut**
> ExtraInfoToProduct extraInfoToProductsIdPut(id, extraInfoToProduct)

Ek Bilgi Ürün Bağı Güncelleme

İlgili Ek Bilgi Ürün Bağını günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ExtraInfoToProductApi();

var id = 56; // Number | Ek Bilgi Ürün Bağı nesnesinin id değeri

var extraInfoToProduct = new IdeaSoftApi.ExtraInfoToProduct(); // ExtraInfoToProduct |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.extraInfoToProductsIdPut(id, extraInfoToProduct, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 
 **extraInfoToProduct** | [**ExtraInfoToProduct**](ExtraInfoToProduct.md)|  nesnesi | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="extraInfoToProductsPost"></a>
# **extraInfoToProductsPost**
> ExtraInfoToProduct extraInfoToProductsPost(extraInfoToProduct)

Ek Bilgi Ürün Bağı Oluşturma

Yeni bir Ek Bilgi Ürün Bağı oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ExtraInfoToProductApi();

var extraInfoToProduct = new IdeaSoftApi.ExtraInfoToProduct(); // ExtraInfoToProduct |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.extraInfoToProductsPost(extraInfoToProduct, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extraInfoToProduct** | [**ExtraInfoToProduct**](ExtraInfoToProduct.md)|  nesnesi | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

