# IdeaSoftApi.SpecName

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Ürün özelliği nesnesi kimlik değeri. | [optional] 
**name** | **String** | Ürün özelliği nesnesi için isim değeri. | 
**choiceType** | **String** | Özellik tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul&lt;br&gt;&lt;/div&gt; | 
**sortOrder** | **Number** | Ürün özelliği sıralama değeri. | [optional] 
**status** | **String** | Ürün özelliği aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**specGroup** | [**SpecGroup**](SpecGroup.md) | specGroup | 


<a name="ChoiceTypeEnum"></a>
## Enum: ChoiceTypeEnum


* `singular` (value: `"singular"`)

* `plural` (value: `"plural"`)




<a name="StatusEnum"></a>
## Enum: StatusEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




