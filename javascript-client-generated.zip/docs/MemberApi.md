# IdeaSoftApi.MemberApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**membersChartsGet**](MemberApi.md#membersChartsGet) | **GET** /members/charts | Üye Grafik Aksiyonu
[**membersCombinedGet**](MemberApi.md#membersCombinedGet) | **GET** /members/combined | Üye Birleşik Aksiyonu
[**membersGet**](MemberApi.md#membersGet) | **GET** /members | Üye Listesi Alma
[**membersIdDelete**](MemberApi.md#membersIdDelete) | **DELETE** /members/{id} | Üye Silme
[**membersIdGet**](MemberApi.md#membersIdGet) | **GET** /members/{id} | Üye Alma
[**membersIdPut**](MemberApi.md#membersIdPut) | **PUT** /members/{id} | Üye Güncelleme
[**membersPost**](MemberApi.md#membersPost) | **POST** /members | Üye Oluşturma


<a name="membersChartsGet"></a>
# **membersChartsGet**
> Member membersChartsGet(timeFrame, startDate)

Üye Grafik Aksiyonu

Zaman bazında üye genel istatistiklerini getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.MemberApi();

let timeFrame = "timeFrame_example"; // String | Şu değerleri olabilir: full, year, month or week

let startDate = "startDate_example"; // String | Zaman aralığının başlangıcı


apiInstance.membersChartsGet(timeFrame, startDate, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timeFrame** | **String**| Şu değerleri olabilir: full, year, month or week | 
 **startDate** | **String**| Zaman aralığının başlangıcı | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="membersCombinedGet"></a>
# **membersCombinedGet**
> Member membersCombinedGet()

Üye Birleşik Aksiyonu

Bugün, aylık, yıllık ve toplam üye oturum açma istatistiklerini totalCount cinsinden getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.MemberApi();

apiInstance.membersCombinedGet((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="membersGet"></a>
# **membersGet**
> Member membersGet(opts)

Üye Listesi Alma

Üye listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.MemberApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'firstname': "firstname_example", // String | Adı
  'surname': "surname_example", // String | Soyadı
  'email': "email_example", // String | e-mail adresi
  'password': "password_example", // String | Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri
  'gender': "gender_example", // String | Cinsiyet şu değerleri alabilir: <br><code>male</code> : Erkek<br><code>female</code> : Kadın
  'mobilePhoneNumber': "mobilePhoneNumber_example", // String | Üye mobil telefon numarası
  'phoneNumber': "phoneNumber_example", // String | Üye telefon numarası
  'memberGroup': 56, // Number | Üye Grubu id
  'location': 56, // Number | Şehir id
  'country': 56, // Number | Ülke id
  'referredMember': 56, // Number | Tavsiye Üye id
  'q': ["q_example"], // [String] | Üye arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;]
  'startDate': new Date("2013-10-20"), // Date | createdAt değeri için başlangıç tarihi
  'endDate': "endDate_example", // String | createdAt değeri için bitiş tarihi
  'startUpdatedAt': new Date("2013-10-20"), // Date | updatedAt değeri için başlangıç tarihi
  'endUpdatedAt': "endUpdatedAt_example" // String | updatedAt değeri için bitiş tarihi
};

apiInstance.membersGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **firstname** | **String**| Adı | [optional] 
 **surname** | **String**| Soyadı | [optional] 
 **email** | **String**| e-mail adresi | [optional] 
 **password** | **String**| Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri | [optional] 
 **gender** | **String**| Cinsiyet şu değerleri alabilir: &lt;br&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın | [optional] 
 **mobilePhoneNumber** | **String**| Üye mobil telefon numarası | [optional] 
 **phoneNumber** | **String**| Üye telefon numarası | [optional] 
 **memberGroup** | **Number**| Üye Grubu id | [optional] 
 **location** | **Number**| Şehir id | [optional] 
 **country** | **Number**| Ülke id | [optional] 
 **referredMember** | **Number**| Tavsiye Üye id | [optional] 
 **q** | [**[String]**](String.md)| Üye arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="membersIdDelete"></a>
# **membersIdDelete**
> membersIdDelete(id)

Üye Silme

Kalıcı olarak ilgili Üyeyi siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.MemberApi();

let id = 56; // Number | Üye nesnesinin id değeri


apiInstance.membersIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Üye nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="membersIdGet"></a>
# **membersIdGet**
> Member membersIdGet(id)

Üye Alma

İlgili Üyeyi getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.MemberApi();

let id = 56; // Number | Üye nesnesinin id değeri


apiInstance.membersIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Üye nesnesinin id değeri | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="membersIdPut"></a>
# **membersIdPut**
> Member membersIdPut(id, member)

Üye Güncelleme

İlgili Üyeyi günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.MemberApi();

let id = 56; // Number | Üye nesnesinin id değeri

let member = new IdeaSoftApi.Member(); // Member | Member nesnesi


apiInstance.membersIdPut(id, member, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Üye nesnesinin id değeri | 
 **member** | [**Member**](Member.md)| Member nesnesi | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="membersPost"></a>
# **membersPost**
> Member membersPost(member)

Üye Oluşturma

Yeni bir Üye oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.MemberApi();

let member = new IdeaSoftApi.Member(); // Member | Member nesnesi


apiInstance.membersPost(member, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member** | [**Member**](Member.md)| Member nesnesi | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

