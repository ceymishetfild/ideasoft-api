# IdeaSoftApi.PaymentGatewayApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**paymentGatewaysGet**](PaymentGatewayApi.md#paymentGatewaysGet) | **GET** /payment_gateways | Ödeme Kanalı Listesi Alma
[**paymentGatewaysIdGet**](PaymentGatewayApi.md#paymentGatewaysIdGet) | **GET** /payment_gateways/{id} | Ödeme Kanalı Alma


<a name="paymentGatewaysGet"></a>
# **paymentGatewaysGet**
> PaymentGateway paymentGatewaysGet(opts)

Ödeme Kanalı Listesi Alma

Ödeme Kanalı listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.PaymentGatewayApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'code': "code_example", // String | Ödeme kanalı notu
  'name': "name_example" // String | Ödeme kanalı adı
};

apiInstance.paymentGatewaysGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **code** | **String**| Ödeme kanalı notu | [optional] 
 **name** | **String**| Ödeme kanalı adı | [optional] 

### Return type

[**PaymentGateway**](PaymentGateway.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="paymentGatewaysIdGet"></a>
# **paymentGatewaysIdGet**
> PaymentGateway paymentGatewaysIdGet(id)

Ödeme Kanalı Alma

İlgili Ödeme Kanalını getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.PaymentGatewayApi();

let id = 56; // Number | Ödeme Kanalı nesnesinin id değeri


apiInstance.paymentGatewaysIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ödeme Kanalı nesnesinin id değeri | 

### Return type

[**PaymentGateway**](PaymentGateway.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

