# IdeaSoftApi.Order

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Sipariş nesnesi kimlik değeri. | [optional] 
**customerFirstname** | **String** | Müşterinin ismi. | 
**customerSurname** | **String** | Müşterinin soy ismi. | 
**customerEmail** | **String** | Müşterinin e-mail adresi. | 
**customerPhone** | **String** | Müşterinin telefon numarası. | 
**paymentTypeName** | **String** | Siparişin ödeme tipi. | 
**paymentProviderCode** | **String** | Siparişin ödeme altyapısı sağlayıcısının kodu. Ön tanımlıdır. API otomatik oluşturur. | 
**paymentProviderName** | **String** | Siparişin ödeme altyapısı sağlayıcısının adı. Ön tanımlıdır. API otomatik oluşturur. | 
**paymentGatewayCode** | **String** | Siparişin ödeme kanalının kodu. Ön tanımlıdır. API otomatik oluşturur. | 
**paymentGatewayName** | **String** | Siparişin ödeme kanalının adı. Ön tanımlıdır. API otomatik oluşturur. | 
**bankName** | **String** | Siparişin banka adı. Ön tanımlıdır. API otomatik oluşturur. | [optional] 
**clientIp** | **String** | Müşterinin IP adresi. | 
**userAgent** | **String** | Siparişin gerçekleştiği tarayıcı bilgisi. | [optional] 
**currency** | **String** | Kur bilgisi. | 
**currencyRates** | **String** | Kur oranları. | 
**amount** | **Number** | Siparişin vergi hariç fiyatı. | 
**couponDiscount** | **Number** | Siparişte kullanılan hediye çeki indirimi tutarı. | 
**taxAmount** | **Number** | Siparişin vergi tutarı. | 
**promotionDiscount** | **Number** | Siparişte kullanılan promosyon indirimi tutarı. | 
**generalAmount** | **Number** | Siparişin genel fiyat tutarı. orderAmount, couponDiscount, taxAmount, promotionDiscount, shippingAmount, additionalServiceAmount tutarlarının toplamı. | 
**shippingAmount** | **Number** | Siparişin teslimat ücreti. | 
**additionalServiceAmount** | **Number** | Siparişin ek hizmet bedeli ücreti. | 
**finalAmount** | **Number** | Siparişin son ödeme tutarı. generalAmount değerinin üzerine taksitten kaynaklı vade farkı bedeli eklenmiş hali. | 
**sumOfGainedPoints** | **Number** | Siparişten kazanılan puan tutarı. | [optional] 
**installment** | **Number** | Siparişin taksit adeti. | [optional] 
**installmentRate** | **Number** | Siparişin taksit oranı. | [optional] 
**extraInstallment** | **Number** | Siparişin ek taksit adeti. | [optional] 
**transactionId** | **String** | Siparişin numarası. | [optional] 
**hasUserNote** | **String** | Siparişin müşteri notuna sahiplik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sipariş müşteri notuna sahip.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sipariş müşteri notuna sahip değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**status** | **String** | Sipariş durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;/div&gt; | 
**paymentStatus** | **String** | Ödeme durumu bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;success&lt;/code&gt; : Başarılı&lt;br&gt;&lt;/div&gt; | 
**errorMessage** | **String** | Siparişin hata mesajı. | [optional] 
**deviceType** | **String** | Siparişin gerçekleştiği cihaz bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil&lt;br&gt;&lt;code&gt;tablet&lt;/code&gt; : Tablet&lt;br&gt;&lt;/div&gt; | 
**referrer** | **String** | Siparişe yönlendiren web-sitesi adresi. Yönlendirmeyi yapan web-sitesinin tam URL bilgisini de içerir. API otomatik oluşturur. | [optional] 
**invoicePrintCount** | **Number** | Sipariş için alınan fatura çıktısı adedi. | [optional] 
**useGiftPackage** | **String** | Hediye paketi istenilmesi durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hediye paketi istiyorum&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hediye paketi istemiyorum&lt;br&gt;&lt;/div&gt; | [optional] 
**giftNote** | **String** | Hediye notu. | [optional] 
**memberGroupName** | **String** | Üye grubu adı. | [optional] 
**usePromotion** | **String** | Promosyon kullanılma durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Promosyon kullan&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Promosyon kullanma&lt;br&gt;&lt;/div&gt; | [optional] 
**shippingProviderCode** | **String** | Siparişin teslimat hizmeti sağlayıcısı kodu. Ön tanımlıdır. API otomatik oluşturur. | [optional] 
**shippingProviderName** | **String** | Siparişin teslimat hizmeti sağlayıcısı adı. Ön tanımlıdır. | [optional] 
**shippingCompanyName** | **String** | Siparişin kargo firması adı. Ön tanımlıdır. | [optional] 
**shippingPaymentType** | **String** | Siparişin kargo ödeme tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı Ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici Ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için geçerli değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**shippingTrackingCode** | **String** | Siparişin kargo takip kodu. | [optional] 
**source** | **String** | Siparişin kaynak bilgisi. Siparişin kaynak yazılımını belirtir. | 
**createdAt** | **Date** | Sipariş nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **Date** | Sipariş nesnesinin güncellenme zamanı. | [optional] 
**maillist** | [**Maillist**](Maillist.md) | Mail listesi nesnesi. | [optional] 
**member** | [**Member**](Member.md) | Üye nesnesi. | [optional] 
**orderDetails** | [**[OrderDetail]**](OrderDetail.md) | Sipariş detayları. | [optional] 
**orderItems** | [**[OrderItem]**](OrderItem.md) | Sipariş kalemleri. | [optional] 
**shippingAddress** | [**ShippingAddress**](ShippingAddress.md) | Teslimat adresi nesnesi. | [optional] 
**billingAddress** | [**BillingAddress**](BillingAddress.md) | Fatura adresi nesnesi. | [optional] 


<a name="HasUserNoteEnum"></a>
## Enum: HasUserNoteEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="StatusEnum"></a>
## Enum: StatusEnum


* `deleted` (value: `"deleted"`)

* `waiting_for_approval` (value: `"waiting_for_approval"`)

* `approved` (value: `"approved"`)

* `fulfilled` (value: `"fulfilled"`)

* `cancelled` (value: `"cancelled"`)

* `delivered` (value: `"delivered"`)

* `on_accumulation` (value: `"on_accumulation"`)

* `waiting_for_payment` (value: `"waiting_for_payment"`)

* `being_prepared` (value: `"being_prepared"`)

* `refunded` (value: `"refunded"`)

* `personal_status_1` (value: `"personal_status_1"`)

* `personal_status_2` (value: `"personal_status_2"`)

* `personal_status_3` (value: `"personal_status_3"`)




<a name="PaymentStatusEnum"></a>
## Enum: PaymentStatusEnum


* `in_transaction` (value: `"in_transaction"`)

* `failed` (value: `"failed"`)

* `success` (value: `"success"`)




<a name="DeviceTypeEnum"></a>
## Enum: DeviceTypeEnum


* `desktop` (value: `"desktop"`)

* `mobile` (value: `"mobile"`)

* `tablet` (value: `"tablet"`)




<a name="UseGiftPackageEnum"></a>
## Enum: UseGiftPackageEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="UsePromotionEnum"></a>
## Enum: UsePromotionEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="ShippingPaymentTypeEnum"></a>
## Enum: ShippingPaymentTypeEnum


* `cash_on_delivery` (value: `"cash_on_delivery"`)

* `standart_delivery` (value: `"standart_delivery"`)

* `not_applicable` (value: `"not_applicable"`)




