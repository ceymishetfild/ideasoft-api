# IdeaSoftApi.Region

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Bölge nesnesi kimlik değeri. | [optional] 
**name** | **String** | Bölge nesnesi için isim değeri. | 


