# IdeaSoftApi.SelectionGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Ek özellik grubu nesnesi kimlik değeri. | [optional] 
**title** | **String** | Ek özellik grubu nesnesinin başlığı. | 
**sortOrder** | **Number** | Ek özellik grubu nesnesi için sıralama değeri. | 


