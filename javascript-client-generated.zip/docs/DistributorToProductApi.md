# IdeaSoftApi.DistributorToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**distributorToProductsGet**](DistributorToProductApi.md#distributorToProductsGet) | **GET** /distributor_to_products | Distribütör Ürün Bağı Listesi Alma
[**distributorToProductsIdDelete**](DistributorToProductApi.md#distributorToProductsIdDelete) | **DELETE** /distributor_to_products/{id} | Distribütör Ürün Bağı Silme
[**distributorToProductsIdGet**](DistributorToProductApi.md#distributorToProductsIdGet) | **GET** /distributor_to_products/{id} | Distribütör Ürün Bağı Alma
[**distributorToProductsIdPut**](DistributorToProductApi.md#distributorToProductsIdPut) | **PUT** /distributor_to_products/{id} | Distribütör Ürün Bağı Güncelleme
[**distributorToProductsPost**](DistributorToProductApi.md#distributorToProductsPost) | **POST** /distributor_to_products | Distribütör Ürün Bağı Oluşturma


<a name="distributorToProductsGet"></a>
# **distributorToProductsGet**
> DistributorToProduct distributorToProductsGet(opts)

Distribütör Ürün Bağı Listesi Alma

Distribütör Ürün Bağı listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.DistributorToProductApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'distributor': 56, // Number | Distribütör id
  'product': 56 // Number | Ürün id
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.distributorToProductsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **distributor** | **Number**| Distribütör id | [optional] 
 **product** | **Number**| Ürün id | [optional] 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorToProductsIdDelete"></a>
# **distributorToProductsIdDelete**
> distributorToProductsIdDelete(id)

Distribütör Ürün Bağı Silme

Kalıcı olarak ilgili Distribütör Ürün Bağını siler

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.DistributorToProductApi();

var id = 56; // Number | Distribütör Ürün Bağı nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.distributorToProductsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Distribütör Ürün Bağı nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorToProductsIdGet"></a>
# **distributorToProductsIdGet**
> DistributorToProduct distributorToProductsIdGet(id)

Distribütör Ürün Bağı Alma

İlgili Distribütör Ürün Bağını getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.DistributorToProductApi();

var id = 56; // Number | Distribütör Ürün Bağı nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.distributorToProductsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Distribütör Ürün Bağı nesnesinin id değeri | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorToProductsIdPut"></a>
# **distributorToProductsIdPut**
> DistributorToProduct distributorToProductsIdPut(id, distributorToProduct)

Distribütör Ürün Bağı Güncelleme

İlgili Distribütör Ürün Bağını günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.DistributorToProductApi();

var id = 56; // Number | Distribütör Ürün Bağı nesnesinin id değeri

var distributorToProduct = new IdeaSoftApi.DistributorToProduct(); // DistributorToProduct |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.distributorToProductsIdPut(id, distributorToProduct, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Distribütör Ürün Bağı nesnesinin id değeri | 
 **distributorToProduct** | [**DistributorToProduct**](DistributorToProduct.md)|  nesnesi | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorToProductsPost"></a>
# **distributorToProductsPost**
> DistributorToProduct distributorToProductsPost(distributorToProduct)

Distribütör Ürün Bağı Oluşturma

Yeni bir Distribütör Ürün Bağı oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.DistributorToProductApi();

var distributorToProduct = new IdeaSoftApi.DistributorToProduct(); // DistributorToProduct |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.distributorToProductsPost(distributorToProduct, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **distributorToProduct** | [**DistributorToProduct**](DistributorToProduct.md)|  nesnesi | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

