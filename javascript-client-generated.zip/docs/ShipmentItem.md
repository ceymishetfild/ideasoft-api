# IdeaSoftApi.ShipmentItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Teslimat Kalemi nesnesi kimlik değeri. | [optional] 
**rootProductId** | **Number** | Ana ürünün id değeri. | [optional] 
**amount** | **Number** | Ürünün stok tipi cinsinden miktarı. | 
**price** | **Number** | Ürünün fiyatı. | 
**productLabel** | **String** | Ürün başlığı. | [optional] 
**currency** | **String** | Ürünün kur bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;USD&lt;/code&gt; : Amerikan Doları&lt;br&gt;&lt;code&gt;EUR&lt;/code&gt; : Euro&lt;br&gt;&lt;code&gt;TL&lt;/code&gt; : Türk Lirası&lt;br&gt;&lt;code&gt;GBP&lt;/code&gt; : İngiliz Sterlini&lt;br&gt;&lt;code&gt;JPY&lt;/code&gt; : Japon Yeni&lt;br&gt;&lt;code&gt;CNY&lt;/code&gt; : Çin Yuanı&lt;br&gt;&lt;code&gt;GR&lt;/code&gt; : Gram Altın&lt;br&gt;&lt;code&gt;CHF&lt;/code&gt; : İsviçre Frangı&lt;br&gt;&lt;/div&gt; | 
**tax** | **Number** | Ürünün vergi değeri. | [optional] 
**dm3** | **Number** | Ürünün desi bilgisi. | 
**createdAt** | **Date** | Teslimat Kalemi nesnesinin oluşturulma zamanı. | [optional] 
**status** | **Number** | Teslimat Kalemi nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**updatedAt** | **Date** | Teslimat Kalemi nesnesinin güncellenme zamanı. | [optional] 
**orderItem** | [**OrderItem**](OrderItem.md) |  | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 
**shipment** | [**Shipment**](Shipment.md) |  | [optional] 


<a name="CurrencyEnum"></a>
## Enum: CurrencyEnum


* `USD` (value: `"USD"`)

* `EUR` (value: `"EUR"`)

* `TL` (value: `"TL"`)

* `GBP` (value: `"GBP"`)

* `JPY` (value: `"JPY"`)

* `CNY` (value: `"CNY"`)

* `GR` (value: `"GR"`)

* `CHF` (value: `"CHF"`)




<a name="StatusEnum"></a>
## Enum: StatusEnum


* `0` (value: `0`)

* `1` (value: `1`)




