# IdeaSoftApi.Brand

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Marka nesnesi kimlik değeri. | [optional] 
**name** | **String** | Marka nesnesi için isim değeri. | 
**slug** | **String** | Slug değeri ilgili nesnenin Url değeridir. | [optional] 
**sortOrder** | **Number** | Marka nesnesi için sıralama değeri. | [optional] 
**status** | **String** | Marka nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**distributor** | **String** | Markanın tedarikçisi. | [optional] 
**imageFile** | **String** | Marka nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF | [optional] 
**showcaseContent** | **String** | Marka nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir. | [optional] 
**displayShowcaseContent** | **String** | Marka nesnesi üst içerik metninin gösterim durumu. | [optional] 
**metaKeywords** | **String** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] 
**metaDescription** | **String** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] 
**pageTitle** | **String** | Marka nesnesinin etiket başlığı. | [optional] 
**attachment** | **String** | Marka nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. | [optional] 
**createdAt** | **Date** | Marka nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **Date** | Marka nesnesinin güncellenme zamanı. | [optional] 


<a name="StatusEnum"></a>
## Enum: StatusEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="DisplayShowcaseContentEnum"></a>
## Enum: DisplayShowcaseContentEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




