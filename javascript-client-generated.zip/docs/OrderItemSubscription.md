# IdeaSoftApi.OrderItemSubscription

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Sipariş kalemi aboneliği kimlik değeri. | [optional] 


