# IdeaSoftApi.ShopTokens

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Hediye çeki nesnesi kimlik değeri. | [optional] 
**code** | **String** | Hediye çekinin benzersiz kodu. Admin panelinden düzenlenebilir. | [optional] 


