# IdeaSoftApi.SelectionToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Ek özellik ürün bağı nesnesi kimlik değeri. | [optional] 
**selection** | [**Selection**](Selection.md) | Ek özellik nesnesi. | 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 


