# IdeaSoftApi.CacheApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cacheDelete**](CacheApi.md#cacheDelete) | **DELETE** /cache | Önbellek Silme


<a name="cacheDelete"></a>
# **cacheDelete**
> cacheDelete()

Önbellek Silme

Kalıcı olarak Önbelleği siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');

var apiInstance = new IdeaSoftApi.CacheApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.cacheDelete(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

