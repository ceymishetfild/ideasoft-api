# IdeaSoftApi.ProductImageApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productImagesGet**](ProductImageApi.md#productImagesGet) | **GET** /product_images | Ürün Resim Listesi Alma
[**productImagesIdDelete**](ProductImageApi.md#productImagesIdDelete) | **DELETE** /product_images/{id} | Ürün Resim Silme
[**productImagesIdGet**](ProductImageApi.md#productImagesIdGet) | **GET** /product_images/{id} | Ürün Resim Alma
[**productImagesPost**](ProductImageApi.md#productImagesPost) | **POST** /product_images | Ürün Resim Oluşturma


<a name="productImagesGet"></a>
# **productImagesGet**
> ProductImage productImagesGet(opts)

Ürün Resim Listesi Alma

Ürün Resim listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductImageApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'fileName': "fileName_example", // String | Ürün Resim dosya adı
  'product': 56 // Number | Ürün id
};

apiInstance.productImagesGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **fileName** | **String**| Ürün Resim dosya adı | [optional] 
 **product** | **Number**| Ürün id | [optional] 

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productImagesIdDelete"></a>
# **productImagesIdDelete**
> productImagesIdDelete(id)

Ürün Resim Silme

Kalıcı olarak ilgili Ürün Resmini siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductImageApi();

let id = 56; // Number | Ürün Resmi nesnesinin id değeri


apiInstance.productImagesIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Resmi nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productImagesIdGet"></a>
# **productImagesIdGet**
> ProductImage productImagesIdGet(id)

Ürün Resim Alma

İlgili Ürün Resmini getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductImageApi();

let id = 56; // Number | Ürün Resmi nesnesinin id değeri


apiInstance.productImagesIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Resmi nesnesinin id değeri | 

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productImagesPost"></a>
# **productImagesPost**
> ProductImage productImagesPost(productImage)

Ürün Resim Oluşturma

Yeni bir Ürün Resim oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductImageApi();

let productImage = new IdeaSoftApi.ProductImage(); // ProductImage | ProductImage nesnesi


apiInstance.productImagesPost(productImage, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productImage** | [**ProductImage**](ProductImage.md)| ProductImage nesnesi | 

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

