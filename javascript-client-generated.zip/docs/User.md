# IdeaSoftApi.User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Yönetici nesnesi kimlik değeri. | [optional] 
**firstname** | **String** | Yöneticinin ismi. | [optional] 
**surname** | **String** | Yöneticinin soy ismi. | [optional] 
**email** | **String** | Yöneticinin e-mail adresi. | 
**username** | **String** | Yöneticinin kullanıcı adı. | 
**phoneNumber** | **String** | Yöneticinin telefon numarası. | [optional] 
**status** | **Number** | Yöneticinin aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Askıya alınmış.&lt;br&gt;&lt;/div&gt; | 
**isOwner** | **String** | Yöneticinin site sahibi olma durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Site sahibi.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Site sahibi değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**membergroups** | [**[MemberGroup]**](MemberGroup.md) | İlgili üye grubu. | [optional] 
**smsApproved** | **String** | Yöneticinin SMS verifikasyonu yapılma bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : SMS verifikasyon yapılmış.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : SMS verifikasyon yapılmamış.&lt;br&gt;&lt;/div&gt; | [optional] 
**userlevel** | [**ShopUserlevels**](ShopUserlevels.md) | Yönetici grubu nesnesi. | [optional] 


<a name="StatusEnum"></a>
## Enum: StatusEnum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)




<a name="IsOwnerEnum"></a>
## Enum: IsOwnerEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="SmsApprovedEnum"></a>
## Enum: SmsApprovedEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




