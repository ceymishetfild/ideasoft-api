# IdeaSoftApi.ProductSpecialInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productSpecialInfosGet**](ProductSpecialInfoApi.md#productSpecialInfosGet) | **GET** /product_special_infos | Ürün Özel Bilgi Alanı Listesi Alma
[**productSpecialInfosIdDelete**](ProductSpecialInfoApi.md#productSpecialInfosIdDelete) | **DELETE** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**productSpecialInfosIdGet**](ProductSpecialInfoApi.md#productSpecialInfosIdGet) | **GET** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**productSpecialInfosIdPut**](ProductSpecialInfoApi.md#productSpecialInfosIdPut) | **PUT** /product_special_infos/{id} | Ürün Özel Bilgi Alanı Güncelleme
[**productSpecialInfosPost**](ProductSpecialInfoApi.md#productSpecialInfosPost) | **POST** /product_special_infos | Ürün Özel Bilgi Alanı Oluşturma


<a name="productSpecialInfosGet"></a>
# **productSpecialInfosGet**
> ProductSpecialInfo productSpecialInfosGet(opts)

Ürün Özel Bilgi Alanı Listesi Alma

Ürün Özel Bilgi Alanı listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductSpecialInfoApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'title': "title_example", // String | Ürün Özel Bilgi Alanı başlığı
  'status': "status_example", // String | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
  'product': 56 // Number | Ürün id
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productSpecialInfosGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **title** | **String**| Ürün Özel Bilgi Alanı başlığı | [optional] 
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **product** | **Number**| Ürün id | [optional] 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productSpecialInfosIdDelete"></a>
# **productSpecialInfosIdDelete**
> productSpecialInfosIdDelete(id)

Ürün Özel Bilgi Alanı

Kalıcı olarak ilgili Ürün Özel Bilgi Alanını siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductSpecialInfoApi();

var id = 56; // Number | Ürün Özel Bilgi Alanı nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.productSpecialInfosIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productSpecialInfosIdGet"></a>
# **productSpecialInfosIdGet**
> ProductSpecialInfo productSpecialInfosIdGet(id)

Ürün Özel Bilgi Alanı

İlgili Ürün Özel Bilgi Alanını getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductSpecialInfoApi();

var id = 56; // Number | Ürün Özel Bilgi Alanı nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productSpecialInfosIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productSpecialInfosIdPut"></a>
# **productSpecialInfosIdPut**
> ProductSpecialInfo productSpecialInfosIdPut(id, productSpecialInfo)

Ürün Özel Bilgi Alanı Güncelleme

İlgili Ürün Özel Bilgi Alanını günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductSpecialInfoApi();

var id = 56; // Number | Ürün Özel Bilgi Alanı nesnesinin id değeri

var productSpecialInfo = new IdeaSoftApi.ProductSpecialInfo(); // ProductSpecialInfo |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productSpecialInfosIdPut(id, productSpecialInfo, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 
 **productSpecialInfo** | [**ProductSpecialInfo**](ProductSpecialInfo.md)|  nesnesi | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productSpecialInfosPost"></a>
# **productSpecialInfosPost**
> ProductSpecialInfo productSpecialInfosPost(productSpecialInfo)

Ürün Özel Bilgi Alanı Oluşturma

Yeni bir Ürün Özel Bilgi Alanı oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductSpecialInfoApi();

var productSpecialInfo = new IdeaSoftApi.ProductSpecialInfo(); // ProductSpecialInfo |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productSpecialInfosPost(productSpecialInfo, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productSpecialInfo** | [**ProductSpecialInfo**](ProductSpecialInfo.md)|  nesnesi | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

