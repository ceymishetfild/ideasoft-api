# IdeaSoftApi.FavouritedProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**favouritedProductsGet**](FavouritedProductApi.md#favouritedProductsGet) | **GET** /favourited_products | Favori Ürün Listesi Alma
[**favouritedProductsIdDelete**](FavouritedProductApi.md#favouritedProductsIdDelete) | **DELETE** /favourited_products/{id} | Favori Ürün Silme
[**favouritedProductsIdGet**](FavouritedProductApi.md#favouritedProductsIdGet) | **GET** /favourited_products/{id} | Favori Ürün Alma
[**favouritedProductsIdPut**](FavouritedProductApi.md#favouritedProductsIdPut) | **PUT** /favourited_products/{id} | Favori Ürün Güncelleme
[**favouritedProductsPost**](FavouritedProductApi.md#favouritedProductsPost) | **POST** /favourited_products | Favori Ürün Oluşturma


<a name="favouritedProductsGet"></a>
# **favouritedProductsGet**
> FavouritedProduct favouritedProductsGet(opts)

Favori Ürün Listesi Alma

Favori Ürün listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.FavouritedProductApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'product': 56 // Number | Ürün id
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.favouritedProductsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **product** | **Number**| Ürün id | [optional] 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="favouritedProductsIdDelete"></a>
# **favouritedProductsIdDelete**
> favouritedProductsIdDelete(id)

Favori Ürün Silme

Kalıcı olarak ilgili Favori Ürünü siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.FavouritedProductApi();

var id = 56; // Number | Favori Ürün nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.favouritedProductsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Favori Ürün nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="favouritedProductsIdGet"></a>
# **favouritedProductsIdGet**
> FavouritedProduct favouritedProductsIdGet(id)

Favori Ürün Alma

İlgili Favori Ürünü getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.FavouritedProductApi();

var id = 56; // Number | Favori Ürün nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.favouritedProductsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Favori Ürün nesnesinin id değeri | 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="favouritedProductsIdPut"></a>
# **favouritedProductsIdPut**
> FavouritedProduct favouritedProductsIdPut(id, favouritedProduct)

Favori Ürün Güncelleme

İlgili Favori Ürünü günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.FavouritedProductApi();

var id = 56; // Number | Favori Ürün nesnesinin id değeri

var favouritedProduct = new IdeaSoftApi.FavouritedProduct(); // FavouritedProduct |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.favouritedProductsIdPut(id, favouritedProduct, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Favori Ürün nesnesinin id değeri | 
 **favouritedProduct** | [**FavouritedProduct**](FavouritedProduct.md)|  nesnesi | 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="favouritedProductsPost"></a>
# **favouritedProductsPost**
> FavouritedProduct favouritedProductsPost(favouritedProduct)

Favori Ürün Oluşturma

Yeni bir Favori Ürün oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.FavouritedProductApi();

var favouritedProduct = new IdeaSoftApi.FavouritedProduct(); // FavouritedProduct |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.favouritedProductsPost(favouritedProduct, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **favouritedProduct** | [**FavouritedProduct**](FavouritedProduct.md)|  nesnesi | 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

