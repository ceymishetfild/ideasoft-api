# IdeaSoftApi.ShippingRate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Kargo oranı nesnesi kimlik değeri. | [optional] 
**volumetricWeightStart** | **Number** | İlgili kargo firması, ilgili bölge ve ilgili orana ait minimum desi değeri. | 
**volumetricWeightEnd** | **Number** | İlgili kargo firması, ilgili bölge ve ilgili orana ait maximum desi değeri. | 
**rate** | **Number** | Seçili bölge ve kargo firması için kargo oranı. | 
**region** | [**Region**](Region.md) |  | [optional] 
**shippingCompany** | [**ShippingCompany**](ShippingCompany.md) |  | [optional] 


