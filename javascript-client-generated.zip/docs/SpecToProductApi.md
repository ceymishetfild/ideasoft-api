# IdeaSoftApi.SpecToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specToProductsGet**](SpecToProductApi.md#specToProductsGet) | **GET** /spec_to_products | Ürün Özellik Ürün Bağı Listesi Alma
[**specToProductsIdDelete**](SpecToProductApi.md#specToProductsIdDelete) | **DELETE** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Silme
[**specToProductsIdGet**](SpecToProductApi.md#specToProductsIdGet) | **GET** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Alma
[**specToProductsIdPut**](SpecToProductApi.md#specToProductsIdPut) | **PUT** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Güncelleme
[**specToProductsPost**](SpecToProductApi.md#specToProductsPost) | **POST** /spec_to_products | Ürün Özellik Ürün Bağı Oluşturma


<a name="specToProductsGet"></a>
# **specToProductsGet**
> SpecToProduct specToProductsGet(opts)

Ürün Özellik Ürün Bağı Listesi Alma

Ürün Özellik Ürün Bağı listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SpecToProductApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'product': 56, // Number | Ürün id
  'specGroup': 56, // Number | Ürün özellik grubu id
  'specName': 56, // Number | Ürün özellik id
  'specValue': 56 // Number | Ürün özellik değeri id
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.specToProductsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **product** | **Number**| Ürün id | [optional] 
 **specGroup** | **Number**| Ürün özellik grubu id | [optional] 
 **specName** | **Number**| Ürün özellik id | [optional] 
 **specValue** | **Number**| Ürün özellik değeri id | [optional] 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specToProductsIdDelete"></a>
# **specToProductsIdDelete**
> specToProductsIdDelete(id)

Ürün Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SpecToProductApi();

var id = 56; // Number | Ürün Özellik Ürün Bağı nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.specToProductsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specToProductsIdGet"></a>
# **specToProductsIdGet**
> SpecToProduct specToProductsIdGet(id)

Ürün Özellik Ürün Bağı Alma

İlgili Ürün Özellik Ürün Bağını getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SpecToProductApi();

var id = 56; // Number | Ürün Özellik Ürün Bağı nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.specToProductsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specToProductsIdPut"></a>
# **specToProductsIdPut**
> SpecToProduct specToProductsIdPut(id, specToProduct)

Ürün Özellik Ürün Bağı Güncelleme

İlgili Ürün Özellik Ürün Bağını günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SpecToProductApi();

var id = 56; // Number | Ürün Özellik Ürün Bağı nesnesinin id değeri

var specToProduct = new IdeaSoftApi.SpecToProduct(); // SpecToProduct |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.specToProductsIdPut(id, specToProduct, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 
 **specToProduct** | [**SpecToProduct**](SpecToProduct.md)|  nesnesi | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specToProductsPost"></a>
# **specToProductsPost**
> SpecToProduct specToProductsPost(specToProduct)

Ürün Özellik Ürün Bağı Oluşturma

Yeni bir Ürün Özellik Ürün Bağı oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SpecToProductApi();

var specToProduct = new IdeaSoftApi.SpecToProduct(); // SpecToProduct |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.specToProductsPost(specToProduct, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specToProduct** | [**SpecToProduct**](SpecToProduct.md)|  nesnesi | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

