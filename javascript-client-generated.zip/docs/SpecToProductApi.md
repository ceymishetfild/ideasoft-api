# IdeaSoftApi.SpecToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specToProductsGet**](SpecToProductApi.md#specToProductsGet) | **GET** /spec_to_products | Ürün Özellik Ürün Bağı Listesi Alma
[**specToProductsIdDelete**](SpecToProductApi.md#specToProductsIdDelete) | **DELETE** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Silme
[**specToProductsIdGet**](SpecToProductApi.md#specToProductsIdGet) | **GET** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Alma
[**specToProductsIdPut**](SpecToProductApi.md#specToProductsIdPut) | **PUT** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Güncelleme
[**specToProductsPost**](SpecToProductApi.md#specToProductsPost) | **POST** /spec_to_products | Ürün Özellik Ürün Bağı Oluşturma


<a name="specToProductsGet"></a>
# **specToProductsGet**
> SpecToProduct specToProductsGet(opts)

Ürün Özellik Ürün Bağı Listesi Alma

Ürün Özellik Ürün Bağı listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SpecToProductApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'product': 56, // Number | Ürün id
  'specGroup': 56, // Number | Ürün özellik grubu id
  'specName': 56, // Number | Ürün özellik id
  'specValue': 56 // Number | Ürün özellik değeri id
};

apiInstance.specToProductsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **product** | **Number**| Ürün id | [optional] 
 **specGroup** | **Number**| Ürün özellik grubu id | [optional] 
 **specName** | **Number**| Ürün özellik id | [optional] 
 **specValue** | **Number**| Ürün özellik değeri id | [optional] 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specToProductsIdDelete"></a>
# **specToProductsIdDelete**
> specToProductsIdDelete(id)

Ürün Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SpecToProductApi();

let id = 56; // Number | Ürün Özellik Ürün Bağı nesnesinin id değeri


apiInstance.specToProductsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specToProductsIdGet"></a>
# **specToProductsIdGet**
> SpecToProduct specToProductsIdGet(id)

Ürün Özellik Ürün Bağı Alma

İlgili Ürün Özellik Ürün Bağını getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SpecToProductApi();

let id = 56; // Number | Ürün Özellik Ürün Bağı nesnesinin id değeri


apiInstance.specToProductsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specToProductsIdPut"></a>
# **specToProductsIdPut**
> SpecToProduct specToProductsIdPut(id, specToProduct)

Ürün Özellik Ürün Bağı Güncelleme

İlgili Ürün Özellik Ürün Bağını günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SpecToProductApi();

let id = 56; // Number | Ürün Özellik Ürün Bağı nesnesinin id değeri

let specToProduct = new IdeaSoftApi.SpecToProduct(); // SpecToProduct | SpecToProduct nesnesi


apiInstance.specToProductsIdPut(id, specToProduct, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 
 **specToProduct** | [**SpecToProduct**](SpecToProduct.md)| SpecToProduct nesnesi | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specToProductsPost"></a>
# **specToProductsPost**
> SpecToProduct specToProductsPost(specToProduct)

Ürün Özellik Ürün Bağı Oluşturma

Yeni bir Ürün Özellik Ürün Bağı oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SpecToProductApi();

let specToProduct = new IdeaSoftApi.SpecToProduct(); // SpecToProduct | SpecToProduct nesnesi


apiInstance.specToProductsPost(specToProduct, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specToProduct** | [**SpecToProduct**](SpecToProduct.md)| SpecToProduct nesnesi | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

