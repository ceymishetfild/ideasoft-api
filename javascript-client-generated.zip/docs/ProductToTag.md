# IdeaSoftApi.ProductToTag

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Ürün SEO+ etiketi bağı nesnesi kimlik değeri. | [optional] 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 
**tag** | [**Tag**](Tag.md) | SEO+ etiketi nesnesi. | 


