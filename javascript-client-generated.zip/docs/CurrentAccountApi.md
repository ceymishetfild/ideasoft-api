# IdeaSoftApi.CurrentAccountApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**currentAccountsGet**](CurrentAccountApi.md#currentAccountsGet) | **GET** /current_accounts | Cari Hesap Listesi Alma
[**currentAccountsIdDelete**](CurrentAccountApi.md#currentAccountsIdDelete) | **DELETE** /current_accounts/{id} | Cari Hesap Silme
[**currentAccountsIdGet**](CurrentAccountApi.md#currentAccountsIdGet) | **GET** /current_accounts/{id} | Cari Hesap Alma
[**currentAccountsIdPut**](CurrentAccountApi.md#currentAccountsIdPut) | **PUT** /current_accounts/{id} | Cari Hesap Güncelleme
[**currentAccountsPost**](CurrentAccountApi.md#currentAccountsPost) | **POST** /current_accounts | Cari Hesap Oluşturma


<a name="currentAccountsGet"></a>
# **currentAccountsGet**
> CurrentAccount currentAccountsGet(opts)

Cari Hesap Listesi Alma

Cari Hesap listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.CurrentAccountApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'code': "code_example", // String | Cari Hesap kodu
  'title': "title_example", // String | Cari Hesap başlığı
  'startDate': new Date("2013-10-20"), // Date | createdAt değeri için başlangıç tarihi
  'endDate': "endDate_example", // String | createdAt değeri için bitiş tarihi
  'startUpdatedAt': new Date("2013-10-20"), // Date | updatedAt değeri için başlangıç tarihi
  'endUpdatedAt': "endUpdatedAt_example", // String | updatedAt değeri için bitiş tarihi
  'member': "member_example" // String | İlgili üye
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.currentAccountsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **code** | **String**| Cari Hesap kodu | [optional] 
 **title** | **String**| Cari Hesap başlığı | [optional] 
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional] 
 **member** | **String**| İlgili üye | [optional] 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="currentAccountsIdDelete"></a>
# **currentAccountsIdDelete**
> currentAccountsIdDelete(id)

Cari Hesap Silme

Kalıcı olarak ilgili Cari Hesabı siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.CurrentAccountApi();

var id = 56; // Number | Cari Hesap nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.currentAccountsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Cari Hesap nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="currentAccountsIdGet"></a>
# **currentAccountsIdGet**
> CurrentAccount currentAccountsIdGet(id)

Cari Hesap Alma

İlgili Cari Hesabı getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.CurrentAccountApi();

var id = 56; // Number | Cari Hesap nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.currentAccountsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Cari Hesap nesnesinin id değeri | 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="currentAccountsIdPut"></a>
# **currentAccountsIdPut**
> CurrentAccount currentAccountsIdPut(id, currentAccount)

Cari Hesap Güncelleme

İlgili Cari Hesabı günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.CurrentAccountApi();

var id = 56; // Number | Cari Hesap nesnesinin id değeri

var currentAccount = new IdeaSoftApi.CurrentAccount(); // CurrentAccount |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.currentAccountsIdPut(id, currentAccount, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Cari Hesap nesnesinin id değeri | 
 **currentAccount** | [**CurrentAccount**](CurrentAccount.md)|  nesnesi | 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="currentAccountsPost"></a>
# **currentAccountsPost**
> CurrentAccount currentAccountsPost(currentAccount)

Cari Hesap Oluşturma

Yeni bir Cari Hesap oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.CurrentAccountApi();

var currentAccount = new IdeaSoftApi.CurrentAccount(); // CurrentAccount |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.currentAccountsPost(currentAccount, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **currentAccount** | [**CurrentAccount**](CurrentAccount.md)|  nesnesi | 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

