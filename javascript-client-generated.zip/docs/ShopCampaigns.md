# IdeaSoftApi.ShopCampaigns

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Promosyon nesnesi kimlik değeri. | [optional] 
**label** | **String** | Promosyon adı. | [optional] 


