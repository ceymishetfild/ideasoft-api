# IdeaSoftApi.ProductButton

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Ürün ve stok butonu nesnesi kimlik değeri. | [optional] 
**fastShipping** | **String** | Hızlı gönderi butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hızlı kargo butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hızlı kargo butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**sameDayShipping** | **String** | Aynı gün kargo butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aynı gün kargo butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Aynı gün kargo butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**threeDaysDelivery** | **String** | 3 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 3 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 3 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**fiveDaysDelivery** | **String** | 5 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 5 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 5 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**sevenDaysDelivery** | **String** | 7 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 7 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 7 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**freeShipping** | **String** | Kargo bedava butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kargo bedava butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kargo bedava butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**deliveryFromStock** | **String** | Stoktan teslim butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Stoktan teslim butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Stoktan teslim butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**preOrderedProduct** | **String** | Ön siparişli stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Ön siparişli ürün butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Ön siparişli ürün butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**limitedStock** | **String** | Sınırlı stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sınırlı stok butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sınırlı stok butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**askStock** | **String** | Stok sorunuz butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Stok sorunuz butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Stok sorunuz butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**campaignedProduct** | **String** | Kampanyalı stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalı ürün butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalı ürün butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 


<a name="FastShippingEnum"></a>
## Enum: FastShippingEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="SameDayShippingEnum"></a>
## Enum: SameDayShippingEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="ThreeDaysDeliveryEnum"></a>
## Enum: ThreeDaysDeliveryEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="FiveDaysDeliveryEnum"></a>
## Enum: FiveDaysDeliveryEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="SevenDaysDeliveryEnum"></a>
## Enum: SevenDaysDeliveryEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="FreeShippingEnum"></a>
## Enum: FreeShippingEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="DeliveryFromStockEnum"></a>
## Enum: DeliveryFromStockEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="PreOrderedProductEnum"></a>
## Enum: PreOrderedProductEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="LimitedStockEnum"></a>
## Enum: LimitedStockEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="AskStockEnum"></a>
## Enum: AskStockEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="CampaignedProductEnum"></a>
## Enum: CampaignedProductEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




