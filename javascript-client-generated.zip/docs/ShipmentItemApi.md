# IdeaSoftApi.ShipmentItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipmentItemsGet**](ShipmentItemApi.md#shipmentItemsGet) | **GET** /shipment_items | Teslimat Kalemi Listesi Alma
[**shipmentItemsIdDelete**](ShipmentItemApi.md#shipmentItemsIdDelete) | **DELETE** /shipment_items/{id} | Teslimat Kalemi Silme
[**shipmentItemsIdGet**](ShipmentItemApi.md#shipmentItemsIdGet) | **GET** /shipment_items/{id} | Teslimat Kalemi Alma
[**shipmentItemsIdPut**](ShipmentItemApi.md#shipmentItemsIdPut) | **PUT** /shipment_items/{id} | Teslimat Kalemi Güncelleme
[**shipmentItemsPost**](ShipmentItemApi.md#shipmentItemsPost) | **POST** /shipment_items | Teslimat Kalemi Oluşturma


<a name="shipmentItemsGet"></a>
# **shipmentItemsGet**
> ShipmentItem shipmentItemsGet(opts)

Teslimat Kalemi Listesi Alma

Teslimat Kalemi listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ShipmentItemApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'product': 56, // Number | Ürün id
  'shipment': 56, // Number | Teslimat id
  'orderItem': 56, // Number | Sipariş kalemi id
  'startDate': new Date("2013-10-20"), // Date | createdAt değeri için başlangıç tarihi
  'endDate': "endDate_example", // String | createdAt değeri için bitiş tarihi
  'startUpdatedAt': new Date("2013-10-20"), // Date | updatedAt değeri için başlangıç tarihi
  'endUpdatedAt': "endUpdatedAt_example" // String | updatedAt değeri için bitiş tarihi
};

apiInstance.shipmentItemsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **product** | **Number**| Ürün id | [optional] 
 **shipment** | **Number**| Teslimat id | [optional] 
 **orderItem** | **Number**| Sipariş kalemi id | [optional] 
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shipmentItemsIdDelete"></a>
# **shipmentItemsIdDelete**
> shipmentItemsIdDelete(id)

Teslimat Kalemi Silme

Kalıcı olarak ilgili Teslimat Kalemini siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ShipmentItemApi();

let id = 56; // Number | Teslimat Kalemi nesnesinin id değeri


apiInstance.shipmentItemsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Teslimat Kalemi nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shipmentItemsIdGet"></a>
# **shipmentItemsIdGet**
> ShipmentItem shipmentItemsIdGet(id)

Teslimat Kalemi Alma

İlgili Teslimat Kalemini getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ShipmentItemApi();

let id = 56; // Number | Teslimat Kalemi nesnesinin id değeri


apiInstance.shipmentItemsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Teslimat Kalemi nesnesinin id değeri | 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shipmentItemsIdPut"></a>
# **shipmentItemsIdPut**
> ShipmentItem shipmentItemsIdPut(id, shipmentItem)

Teslimat Kalemi Güncelleme

İlgili Teslimat Kalemini günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ShipmentItemApi();

let id = 56; // Number | Teslimat Kalemi nesnesinin id değeri

let shipmentItem = new IdeaSoftApi.ShipmentItem(); // ShipmentItem | ShipmentItem nesnesi


apiInstance.shipmentItemsIdPut(id, shipmentItem, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Teslimat Kalemi nesnesinin id değeri | 
 **shipmentItem** | [**ShipmentItem**](ShipmentItem.md)| ShipmentItem nesnesi | 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shipmentItemsPost"></a>
# **shipmentItemsPost**
> ShipmentItem shipmentItemsPost(shipmentItem)

Teslimat Kalemi Oluşturma

Yeni bir Teslimat Kalemi oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ShipmentItemApi();

let shipmentItem = new IdeaSoftApi.ShipmentItem(); // ShipmentItem | ShipmentItem nesnesi


apiInstance.shipmentItemsPost(shipmentItem, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipmentItem** | [**ShipmentItem**](ShipmentItem.md)| ShipmentItem nesnesi | 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

