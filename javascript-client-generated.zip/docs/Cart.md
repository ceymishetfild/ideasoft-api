# IdeaSoftApi.Cart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Sepet nesnesi kimlik değeri. | [optional] 
**sessionId** | **String** | Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri. | 
**locked** | **String** | Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz. | [optional] 
**createdAt** | **Date** | Sepet nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **Date** | Sepet nesnesinin güncellenme zamanı. | [optional] 
**chosenPromotion** | [**ShopCampaigns**](ShopCampaigns.md) | Promosyon nesnesi. | [optional] 
**member** | [**Member**](Member.md) | Üye nesnesi. | [optional] 
**chosenToken** | [**ShopTokens**](ShopTokens.md) | Hediye çeki nesnesi. | [optional] 
**items** | [**[CartItem]**](CartItem.md) | Sepet kalemi nesnelerini barındıran liste. | [optional] 


<a name="LockedEnum"></a>
## Enum: LockedEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




