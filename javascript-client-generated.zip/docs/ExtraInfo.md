# IdeaSoftApi.ExtraInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Ek bilgi nesnesi kimlik değeri. | [optional] 
**name** | **String** | Ek bilgi nesnesi için isim değeri. | 
**sortOrder** | **Number** | Ek bilgi nesnesi için sıralama değeri. | [optional] 


