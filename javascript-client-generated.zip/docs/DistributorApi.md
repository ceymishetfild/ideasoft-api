# IdeaSoftApi.DistributorApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**distributorsGet**](DistributorApi.md#distributorsGet) | **GET** /distributors | Distribütör Listesi Alma
[**distributorsIdDelete**](DistributorApi.md#distributorsIdDelete) | **DELETE** /distributors/{id} | Distribütör Silme
[**distributorsIdGet**](DistributorApi.md#distributorsIdGet) | **GET** /distributors/{id} | Distribütör Alma
[**distributorsIdPut**](DistributorApi.md#distributorsIdPut) | **PUT** /distributors/{id} | Distribütör Güncelleme
[**distributorsPost**](DistributorApi.md#distributorsPost) | **POST** /distributors | Distribütör Oluşturma


<a name="distributorsGet"></a>
# **distributorsGet**
> Distributor distributorsGet(opts)

Distribütör Listesi Alma

Distribütör listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.DistributorApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'name': "name_example", // String | Distribütör adı.
  'email': "email_example", // String | Distribütör email adresi
  'phone': "phone_example", // String | Distribütör telefonu
  'contactPerson': "contactPerson_example" // String | Distribütör sorumlu kişi
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.distributorsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **String**| Distribütör adı. | [optional] 
 **email** | **String**| Distribütör email adresi | [optional] 
 **phone** | **String**| Distribütör telefonu | [optional] 
 **contactPerson** | **String**| Distribütör sorumlu kişi | [optional] 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorsIdDelete"></a>
# **distributorsIdDelete**
> distributorsIdDelete(id)

Distribütör Silme

Kalıcı olarak ilgili Distribütörü siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.DistributorApi();

var id = 56; // Number | Distribütör nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.distributorsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Distribütör nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorsIdGet"></a>
# **distributorsIdGet**
> Distributor distributorsIdGet(id)

Distribütör Alma

İlgili Distribütörü getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.DistributorApi();

var id = 56; // Number | Distribütör nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.distributorsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Distribütör nesnesinin id değeri | 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorsIdPut"></a>
# **distributorsIdPut**
> Distributor distributorsIdPut(id, distributor)

Distribütör Güncelleme

İlgili Distribütörü günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.DistributorApi();

var id = 56; // Number | Distribütör nesnesinin id değeri

var distributor = new IdeaSoftApi.Distributor(); // Distributor |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.distributorsIdPut(id, distributor, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Distribütör nesnesinin id değeri | 
 **distributor** | [**Distributor**](Distributor.md)|  nesnesi | 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorsPost"></a>
# **distributorsPost**
> Distributor distributorsPost(distributor)

Distribütör Oluşturma

Yeni bir Distribütör oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.DistributorApi();

var distributor = new IdeaSoftApi.Distributor(); // Distributor |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.distributorsPost(distributor, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **distributor** | [**Distributor**](Distributor.md)|  nesnesi | 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

