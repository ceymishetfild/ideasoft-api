# IdeaSoftApi.DistributorApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**distributorsGet**](DistributorApi.md#distributorsGet) | **GET** /distributors | Distribütör Listesi Alma
[**distributorsIdDelete**](DistributorApi.md#distributorsIdDelete) | **DELETE** /distributors/{id} | Distribütör Silme
[**distributorsIdGet**](DistributorApi.md#distributorsIdGet) | **GET** /distributors/{id} | Distribütör Alma
[**distributorsIdPut**](DistributorApi.md#distributorsIdPut) | **PUT** /distributors/{id} | Distribütör Güncelleme
[**distributorsPost**](DistributorApi.md#distributorsPost) | **POST** /distributors | Distribütör Oluşturma


<a name="distributorsGet"></a>
# **distributorsGet**
> Distributor distributorsGet(opts)

Distribütör Listesi Alma

Distribütör listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.DistributorApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'name': "name_example", // String | Distribütör adı.
  'email': "email_example", // String | Distribütör email adresi
  'phone': "phone_example", // String | Distribütör telefonu
  'contactPerson': "contactPerson_example" // String | Distribütör sorumlu kişi
};

apiInstance.distributorsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **String**| Distribütör adı. | [optional] 
 **email** | **String**| Distribütör email adresi | [optional] 
 **phone** | **String**| Distribütör telefonu | [optional] 
 **contactPerson** | **String**| Distribütör sorumlu kişi | [optional] 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorsIdDelete"></a>
# **distributorsIdDelete**
> distributorsIdDelete(id)

Distribütör Silme

Kalıcı olarak ilgili Distribütörü siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.DistributorApi();

let id = 56; // Number | Distribütör nesnesinin id değeri


apiInstance.distributorsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Distribütör nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorsIdGet"></a>
# **distributorsIdGet**
> Distributor distributorsIdGet(id)

Distribütör Alma

İlgili Distribütörü getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.DistributorApi();

let id = 56; // Number | Distribütör nesnesinin id değeri


apiInstance.distributorsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Distribütör nesnesinin id değeri | 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorsIdPut"></a>
# **distributorsIdPut**
> Distributor distributorsIdPut(id, distributor)

Distribütör Güncelleme

İlgili Distribütörü günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.DistributorApi();

let id = 56; // Number | Distribütör nesnesinin id değeri

let distributor = new IdeaSoftApi.Distributor(); // Distributor | Distributor nesnesi


apiInstance.distributorsIdPut(id, distributor, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Distribütör nesnesinin id değeri | 
 **distributor** | [**Distributor**](Distributor.md)| Distributor nesnesi | 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="distributorsPost"></a>
# **distributorsPost**
> Distributor distributorsPost(distributor)

Distribütör Oluşturma

Yeni bir Distribütör oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.DistributorApi();

let distributor = new IdeaSoftApi.Distributor(); // Distributor | Distributor nesnesi


apiInstance.distributorsPost(distributor, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **distributor** | [**Distributor**](Distributor.md)| Distributor nesnesi | 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

