# IdeaSoftApi.MemberGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**memberGroupsGet**](MemberGroupApi.md#memberGroupsGet) | **GET** /member_groups | Üye Grubu Listesi Alma
[**memberGroupsIdDelete**](MemberGroupApi.md#memberGroupsIdDelete) | **DELETE** /member_groups/{id} | Üye Grubu Silme
[**memberGroupsIdGet**](MemberGroupApi.md#memberGroupsIdGet) | **GET** /member_groups/{id} | Üye Grubu Alma
[**memberGroupsIdPut**](MemberGroupApi.md#memberGroupsIdPut) | **PUT** /member_groups/{id} | Üye Grubu Güncelleme
[**memberGroupsPost**](MemberGroupApi.md#memberGroupsPost) | **POST** /member_groups | Üye Grubu Oluşturma


<a name="memberGroupsGet"></a>
# **memberGroupsGet**
> MemberGroup memberGroupsGet(opts)

Üye Grubu Listesi Alma

Üye Grubu listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.MemberGroupApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'name': "name_example" // String | Üye Grubu adı
};

apiInstance.memberGroupsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **String**| Üye Grubu adı | [optional] 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberGroupsIdDelete"></a>
# **memberGroupsIdDelete**
> memberGroupsIdDelete(id)

Üye Grubu Silme

Kalıcı olarak ilgili Üye Grubunu siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.MemberGroupApi();

let id = 56; // Number | Üye Grubu nesnesinin id değeri


apiInstance.memberGroupsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Üye Grubu nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberGroupsIdGet"></a>
# **memberGroupsIdGet**
> MemberGroup memberGroupsIdGet(id)

Üye Grubu Alma

İlgili Üye Grubunu getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.MemberGroupApi();

let id = 56; // Number | Üye Grubu nesnesinin id değeri


apiInstance.memberGroupsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Üye Grubu nesnesinin id değeri | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberGroupsIdPut"></a>
# **memberGroupsIdPut**
> MemberGroup memberGroupsIdPut(id, memberGroup)

Üye Grubu Güncelleme

İlgili Üye Grubunu günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.MemberGroupApi();

let id = 56; // Number | Üye Grubu nesnesinin id değeri

let memberGroup = new IdeaSoftApi.MemberGroup(); // MemberGroup | MemberGroup nesnesi


apiInstance.memberGroupsIdPut(id, memberGroup, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Üye Grubu nesnesinin id değeri | 
 **memberGroup** | [**MemberGroup**](MemberGroup.md)| MemberGroup nesnesi | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="memberGroupsPost"></a>
# **memberGroupsPost**
> MemberGroup memberGroupsPost(memberGroup)

Üye Grubu Oluşturma

Yeni bir Üye Grubu oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.MemberGroupApi();

let memberGroup = new IdeaSoftApi.MemberGroup(); // MemberGroup | MemberGroup nesnesi


apiInstance.memberGroupsPost(memberGroup, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **memberGroup** | [**MemberGroup**](MemberGroup.md)| MemberGroup nesnesi | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

