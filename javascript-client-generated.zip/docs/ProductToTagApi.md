# IdeaSoftApi.ProductToTagApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productToTagsGet**](ProductToTagApi.md#productToTagsGet) | **GET** /product_to_tags | Ürün SEO+ Bağı Listesi Alma
[**productToTagsIdDelete**](ProductToTagApi.md#productToTagsIdDelete) | **DELETE** /product_to_tags/{id} | Ürün SEO+ Bağı Silme
[**productToTagsIdGet**](ProductToTagApi.md#productToTagsIdGet) | **GET** /product_to_tags/{id} | Ürün SEO+ Bağı Alma
[**productToTagsIdPut**](ProductToTagApi.md#productToTagsIdPut) | **PUT** /product_to_tags/{id} | Ürün SEO+ Bağı Güncelleme
[**productToTagsPost**](ProductToTagApi.md#productToTagsPost) | **POST** /product_to_tags | Ürün SEO+ Bağı Oluşturma


<a name="productToTagsGet"></a>
# **productToTagsGet**
> ProductToTag productToTagsGet(opts)

Ürün SEO+ Bağı Listesi Alma

Ürün SEO+ Bağı listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductToTagApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'product': 56, // Number | Ürün id
  'tag': 56 // Number | Etiket id
};

apiInstance.productToTagsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **product** | **Number**| Ürün id | [optional] 
 **tag** | **Number**| Etiket id | [optional] 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToTagsIdDelete"></a>
# **productToTagsIdDelete**
> productToTagsIdDelete(id)

Ürün SEO+ Bağı Silme

Kalıcı olarak ilgili Ürün SEO+ Bağını siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductToTagApi();

let id = 56; // Number | Ürün SEO+ nesnesinin id değeri


apiInstance.productToTagsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün SEO+ nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToTagsIdGet"></a>
# **productToTagsIdGet**
> ProductToTag productToTagsIdGet(id)

Ürün SEO+ Bağı Alma

İlgili Ürün SEO+ Bağını getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductToTagApi();

let id = 56; // Number | Ürün SEO+ nesnesinin id değeri


apiInstance.productToTagsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün SEO+ nesnesinin id değeri | 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToTagsIdPut"></a>
# **productToTagsIdPut**
> ProductToTag productToTagsIdPut(id, productToTag)

Ürün SEO+ Bağı Güncelleme

İlgili Ürün SEO+ Bağını günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductToTagApi();

let id = 56; // Number | Ürün SEO+ nesnesinin id değeri

let productToTag = new IdeaSoftApi.ProductToTag(); // ProductToTag | ProductToTag nesnesi


apiInstance.productToTagsIdPut(id, productToTag, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün SEO+ nesnesinin id değeri | 
 **productToTag** | [**ProductToTag**](ProductToTag.md)| ProductToTag nesnesi | 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToTagsPost"></a>
# **productToTagsPost**
> ProductToTag productToTagsPost(productToTag)

Ürün SEO+ Bağı Oluşturma

Yeni bir Ürün SEO+ Bağı oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductToTagApi();

let productToTag = new IdeaSoftApi.ProductToTag(); // ProductToTag | ProductToTag nesnesi


apiInstance.productToTagsPost(productToTag, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productToTag** | [**ProductToTag**](ProductToTag.md)| ProductToTag nesnesi | 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

