# IdeaSoftApi.PreOrderInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Sipariş öncesi bilgisi nesnesi kimlik değeri. | [optional] 
**sessionId** | **String** | Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri. | 
**customerFirstname** | **String** | Müşterinin ismi. | [optional] 
**customerSurname** | **String** | Müşterinin soy ismi. | [optional] 
**customerEmail** | **String** | Müşterinin e-mail adresi. | [optional] 
**shippingFirstname** | **String** | Teslimat yapılacak kişinin ismi. | 
**shippingSurname** | **String** | Teslimat yapılacak kişinin soy ismi. | 
**shippingAddress** | **String** | Teslimat adresi bilgileri. | 
**shippingPhoneNumber** | **String** | Teslimat yapılacak kişinin telefon numarası. | 
**shippingMobilePhoneNumber** | **String** | Teslimat yapılacak kişinin mobil telefon numarası. | 
**shippingLocationName** | **String** | Teslimat şehri. | 
**shippingTown** | **String** | Teslimat ilçesi. | 
**differentBillingAddress** | **String** | Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yok&lt;br&gt;&lt;/div&gt; | [optional] 
**billingFirstname** | **String** | Fatura kesilen kişinin ismi. | 
**billingSurname** | **String** | Fatura kesilen kişinin soy ismi. | 
**billingAddress** | **String** | Fatura adresi bilgileri. | 
**billingPhoneNumber** | **String** | Fatura kesilen kişinin telefon numarası. | 
**billingMobilePhoneNumber** | **String** | Fatura kesilen kişinin mobil telefon numarası. | 
**billingLocationName** | **String** | Fatura adresi şehri | 
**billingTown** | **String** | Fatura adresi ilçesi. | 
**billingInvoiceType** | **String** | Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt; | 
**billingIdentityRegistrationNumber** | **String** | Fatura kesilen kişinin TC kimlik numarası. | [optional] 
**billingTaxOffice** | **String** | Fatura kesilen kişi/kurumun vergi dairesi. | [optional] 
**billingTaxNo** | **String** | Fatura kesilen kişi/kurum vergi numarası. | [optional] 
**isEinvoiceUser** | **String** | Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] 
**useGiftPackage** | **String** | Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] 
**giftNote** | **String** | Hediye notu bilgisi. | [optional] 
**imageFile** | **String** | Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif | [optional] 
**deliveryDate** | **Date** | Müşterinin teslimatın gerçekleşmisini istediği tarih. | [optional] 
**deliveryTime** | **String** | API bu değeri otomatik oluşturur. | [optional] 
**createdAt** | **Date** | Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **Date** | Sipariş öncesi bilgisi nesnesinin güncellenme zamanı. | [optional] 
**billingCountry** | [**Country**](Country.md) |  | [optional] 
**billingLocation** | [**Location**](Location.md) |  | [optional] 
**shippingCompany** | [**ShippingCompany**](ShippingCompany.md) |  | [optional] 
**shippingCountry** | [**Country**](Country.md) |  | [optional] 
**shippingLocation** | [**Location**](Location.md) |  | [optional] 
**memberShippingAddress** | [**MemberAddress**](MemberAddress.md) |  | [optional] 
**memberBillingAddress** | [**MemberAddress**](MemberAddress.md) |  | [optional] 


<a name="DifferentBillingAddressEnum"></a>
## Enum: DifferentBillingAddressEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="BillingInvoiceTypeEnum"></a>
## Enum: BillingInvoiceTypeEnum


* `individual` (value: `"individual"`)

* `corporate` (value: `"corporate"`)




<a name="IsEinvoiceUserEnum"></a>
## Enum: IsEinvoiceUserEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




<a name="UseGiftPackageEnum"></a>
## Enum: UseGiftPackageEnum


* `0` (value: `"0"`)

* `1` (value: `"1"`)




