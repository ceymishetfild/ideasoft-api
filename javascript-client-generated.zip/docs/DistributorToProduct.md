# IdeaSoftApi.DistributorToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Distribütor ürün bağı nesnesi kimlik değeri. | [optional] 
**distributor** | [**Distributor**](Distributor.md) | The description of the Distributor. | 
**product** | [**Product**](Product.md) | The description of the Product. | 


