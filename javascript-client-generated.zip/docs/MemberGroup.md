# IdeaSoftApi.MemberGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Üye Grubu nesnesi kimlik değeri. | [optional] 
**name** | **String** | Üye Grubu nesnesi için isim değeri. | 
**priceIndex** | **Number** | Üye Grubunun fiyat indisi. Örnek Fiyat 2. | 
**allowedPaymentGateways** | **String** | Üye Grubunun izin verilmiş ödeme kanalları. | 


