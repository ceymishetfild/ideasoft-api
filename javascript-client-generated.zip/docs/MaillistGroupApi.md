# IdeaSoftApi.MaillistGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**maillistGroupsGet**](MaillistGroupApi.md#maillistGroupsGet) | **GET** /maillist_groups | Mail Listesi Grubu Listesi Alma
[**maillistGroupsIdDelete**](MaillistGroupApi.md#maillistGroupsIdDelete) | **DELETE** /maillist_groups/{id} | Mail Listesi Grubu Silme
[**maillistGroupsIdGet**](MaillistGroupApi.md#maillistGroupsIdGet) | **GET** /maillist_groups/{id} | Mail Listesi Grubu Alma
[**maillistGroupsIdPut**](MaillistGroupApi.md#maillistGroupsIdPut) | **PUT** /maillist_groups/{id} | Mail Listesi Grubu Güncelleme
[**maillistGroupsPost**](MaillistGroupApi.md#maillistGroupsPost) | **POST** /maillist_groups | Mail Listesi Grubu Oluşturma


<a name="maillistGroupsGet"></a>
# **maillistGroupsGet**
> MaillistGroup maillistGroupsGet(opts)

Mail Listesi Grubu Listesi Alma

Mail Listesi Grubu listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.MaillistGroupApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'name': "name_example" // String | Mail Listesi Grubu adı
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.maillistGroupsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **String**| Mail Listesi Grubu adı | [optional] 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="maillistGroupsIdDelete"></a>
# **maillistGroupsIdDelete**
> maillistGroupsIdDelete(id)

Mail Listesi Grubu Silme

Kalıcı olarak ilgili Mail Listesi Grubunu siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.MaillistGroupApi();

var id = 56; // Number | Mail Listesi Grubu nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.maillistGroupsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Mail Listesi Grubu nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="maillistGroupsIdGet"></a>
# **maillistGroupsIdGet**
> MaillistGroup maillistGroupsIdGet(id)

Mail Listesi Grubu Alma

İlgili Mail Listesi Grubunu getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.MaillistGroupApi();

var id = 56; // Number | Mail Listesi Grubu nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.maillistGroupsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Mail Listesi Grubu nesnesinin id değeri | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="maillistGroupsIdPut"></a>
# **maillistGroupsIdPut**
> MaillistGroup maillistGroupsIdPut(id, maillistGroup)

Mail Listesi Grubu Güncelleme

İlgili Mail Listesi Grubunu günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.MaillistGroupApi();

var id = 56; // Number | Mail Listesi Grubu nesnesinin id değeri

var maillistGroup = new IdeaSoftApi.MaillistGroup(); // MaillistGroup |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.maillistGroupsIdPut(id, maillistGroup, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Mail Listesi Grubu nesnesinin id değeri | 
 **maillistGroup** | [**MaillistGroup**](MaillistGroup.md)|  nesnesi | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="maillistGroupsPost"></a>
# **maillistGroupsPost**
> MaillistGroup maillistGroupsPost(maillistGroup)

Mail Listesi Grubu Oluşturma

Yeni bir Mail Listesi Grubu oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.MaillistGroupApi();

var maillistGroup = new IdeaSoftApi.MaillistGroup(); // MaillistGroup |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.maillistGroupsPost(maillistGroup, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **maillistGroup** | [**MaillistGroup**](MaillistGroup.md)|  nesnesi | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

