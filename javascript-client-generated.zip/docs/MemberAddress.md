# IdeaSoftApi.MemberAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Üye adresi nesnesinin benzersiz rakamsal kimlik değeri. | [optional] 
**name** | **String** | Üye Adresi adı. | [optional] 
**type** | **String** | Üye Adresi tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;shipping&lt;/code&gt; : Teslimat adresi.&lt;br&gt;&lt;code&gt;billing&lt;/code&gt; : Fatura adresi.&lt;br&gt;&lt;/div&gt; | [optional] 
**firstname** | **String** | Üyenin ismi. | [optional] 
**surname** | **String** | Üyenin soy ismi. | [optional] 
**address** | **String** | Üyenin adres bilgileri. | [optional] 
**subLocationName** | **String** | İlçe adı. | [optional] 
**phoneNumber** | **String** | Üyenin telefon numarası. | [optional] 
**mobilePhoneNumber** | **String** | Üyenin mobil telefon numarası. | [optional] 
**tcId** | **String** | Üyenin TC kimlik numarası. | [optional] 
**taxNumber** | **String** | Üyenin vergi numarası. | [optional] 
**taxOffice** | **String** | Üyenin vergi dairesi. | [optional] 
**invoiceType** | **String** | Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt; | [optional] 
**isEinvoiceUser** | **Boolean** | Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] 
**createdAt** | **Date** | Tema nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **Date** | Tema nesnesinin güncellenme zamanı. | [optional] 
**member** | [**Member**](Member.md) |  | [optional] 
**country** | [**Country**](Country.md) |  | [optional] 
**location** | [**Location**](Location.md) |  | [optional] 
**subLocation** | [**Town**](Town.md) |  | [optional] 


