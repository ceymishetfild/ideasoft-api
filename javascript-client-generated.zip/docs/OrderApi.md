# IdeaSoftApi.OrderApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ordersGet**](OrderApi.md#ordersGet) | **GET** /orders | Sipariş Listesi Alma
[**ordersIdDelete**](OrderApi.md#ordersIdDelete) | **DELETE** /orders/{id} | Sipariş Silme
[**ordersIdGet**](OrderApi.md#ordersIdGet) | **GET** /orders/{id} | Sipariş Alma
[**ordersIdPut**](OrderApi.md#ordersIdPut) | **PUT** /orders/{id} | Sipariş Güncelleme
[**ordersPost**](OrderApi.md#ordersPost) | **POST** /orders | Sipariş Oluşturma


<a name="ordersGet"></a>
# **ordersGet**
> Order ordersGet(opts)

Sipariş Listesi Alma

Sipariş listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.OrderApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'transactionId': "transactionId_example", // String | İşlem id.
  'customerEmail': "customerEmail_example", // String | Müşteri e-mail.
  'member': 56, // Number | Üye id
  'status': "status_example", // String | Status şu değerleri alabilir: <br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br><code>deleted</code> : Silindi
  'paymentStatus': "paymentStatus_example", // String | Ödeme durumu şu değerleri alabilir: <br><code>success</code> : Başarılı<br><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br><code>failed</code> : Hatalı Ödemeler
  'paymentTypeName': "paymentTypeName_example", // String | Ödeme tipi şu değerleri alabilir: <br><code>Havale</code><br><code>Özel Ödeme Sistemi</code><br><code>Kredi Kartı</code><br><code>Paypal</code><br><code>GarantiPay</code><br><code>Mail Order</code><br><code>BKM Express</code><br><code>Kapıda Ödeme Nakit</code><br><code>Kapıda Ödeme Kredi Kartı</code>
  'shippingProviderCode': "shippingProviderCode_example", // String | Teslimat hizmeti sağlayıcıları kodu şu değerleri alabilir: <br><code>yurtici</code> : Yurtiçi Kargo<br><code>yurtici_self_service</code> : Yurtiçi Kargo (Self Service)<br><code>yurtici_api</code> : Yurtiçi Kargo (API)<br><code>ptt</code> : PTT Kargo<br><code>mng</code> : MNG Kargo<br><code>surat</code> : Sürat Kargo<br><code>ups</code> : UPS<br><code>aras</code> : Aras Kargo<br><code>other</code> : Diğer
  'q': ["q_example"], // [String] | Sipariş arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;]
  'startDate': new Date("2013-10-20"), // Date | createdAt değeri için başlangıç tarihi
  'endDate': "endDate_example", // String | createdAt değeri için bitiş tarihi
  'startUpdatedAt': new Date("2013-10-20"), // Date | updatedAt değeri için başlangıç tarihi
  'endUpdatedAt': "endUpdatedAt_example" // String | updatedAt değeri için bitiş tarihi
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.ordersGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **transactionId** | **String**| İşlem id. | [optional] 
 **customerEmail** | **String**| Müşteri e-mail. | [optional] 
 **member** | **Number**| Üye id | [optional] 
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi | [optional] 
 **paymentStatus** | **String**| Ödeme durumu şu değerleri alabilir: &lt;br&gt;&lt;code&gt;success&lt;/code&gt; : Başarılı&lt;br&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler | [optional] 
 **paymentTypeName** | **String**| Ödeme tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;Havale&lt;/code&gt;&lt;br&gt;&lt;code&gt;Özel Ödeme Sistemi&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kredi Kartı&lt;/code&gt;&lt;br&gt;&lt;code&gt;Paypal&lt;/code&gt;&lt;br&gt;&lt;code&gt;GarantiPay&lt;/code&gt;&lt;br&gt;&lt;code&gt;Mail Order&lt;/code&gt;&lt;br&gt;&lt;code&gt;BKM Express&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kapıda Ödeme Nakit&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kapıda Ödeme Kredi Kartı&lt;/code&gt; | [optional] 
 **shippingProviderCode** | **String**| Teslimat hizmeti sağlayıcıları kodu şu değerleri alabilir: &lt;br&gt;&lt;code&gt;yurtici&lt;/code&gt; : Yurtiçi Kargo&lt;br&gt;&lt;code&gt;yurtici_self_service&lt;/code&gt; : Yurtiçi Kargo (Self Service)&lt;br&gt;&lt;code&gt;yurtici_api&lt;/code&gt; : Yurtiçi Kargo (API)&lt;br&gt;&lt;code&gt;ptt&lt;/code&gt; : PTT Kargo&lt;br&gt;&lt;code&gt;mng&lt;/code&gt; : MNG Kargo&lt;br&gt;&lt;code&gt;surat&lt;/code&gt; : Sürat Kargo&lt;br&gt;&lt;code&gt;ups&lt;/code&gt; : UPS&lt;br&gt;&lt;code&gt;aras&lt;/code&gt; : Aras Kargo&lt;br&gt;&lt;code&gt;other&lt;/code&gt; : Diğer | [optional] 
 **q** | [**[String]**](String.md)| Sipariş arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="ordersIdDelete"></a>
# **ordersIdDelete**
> ordersIdDelete(id)

Sipariş Silme

Kalıcı olarak ilgili Siparişi siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.OrderApi();

var id = 56; // Number | Sipariş nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.ordersIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sipariş nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="ordersIdGet"></a>
# **ordersIdGet**
> Order ordersIdGet(id)

Sipariş Alma

İlgili Siparişi getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.OrderApi();

var id = 56; // Number | Sipariş nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.ordersIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sipariş nesnesinin id değeri | 

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="ordersIdPut"></a>
# **ordersIdPut**
> Order ordersIdPut(id, order)

Sipariş Güncelleme

İlgili Siparişi günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.OrderApi();

var id = 56; // Number | Sipariş nesnesinin id değeri

var order = new IdeaSoftApi.Order(); // Order |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.ordersIdPut(id, order, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sipariş nesnesinin id değeri | 
 **order** | [**Order**](Order.md)|  nesnesi | 

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="ordersPost"></a>
# **ordersPost**
> Order ordersPost(order)

Sipariş Oluşturma

Yeni bir Sipariş oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.OrderApi();

var order = new IdeaSoftApi.Order(); // Order |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.ordersPost(order, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order** | [**Order**](Order.md)|  nesnesi | 

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

