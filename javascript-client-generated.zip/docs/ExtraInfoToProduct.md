# IdeaSoftApi.ExtraInfoToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Ek bilgi ürün bağı nesnesi kimlik değeri. | [optional] 
**value** | **String** | Ek bilgi ürün bağı değeridir. Ek bilgi renk ise bu değer kırmızı olabilir. | 
**extraInfo** | [**ExtraInfo**](ExtraInfo.md) |  | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 


