# IdeaSoftApi.TownApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**townsGet**](TownApi.md#townsGet) | **GET** /towns | İlçe Listesi Alma
[**townsIdDelete**](TownApi.md#townsIdDelete) | **DELETE** /towns/{id} | İlçe Silme
[**townsIdGet**](TownApi.md#townsIdGet) | **GET** /towns/{id} | İlçe Alma
[**townsIdPut**](TownApi.md#townsIdPut) | **PUT** /towns/{id} | İlçe Güncelleme
[**townsPost**](TownApi.md#townsPost) | **POST** /towns | İlçe Oluşturma


<a name="townsGet"></a>
# **townsGet**
> Town townsGet(opts)

İlçe Listesi Alma

İlçe listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.TownApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'location': 56, // Number | Şehir id
  'townGroup': 56, // Number | İlçe grubu id
  'name': "name_example", // String | İlçe adı.
  'status': "status_example" // String | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
};

apiInstance.townsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **location** | **Number**| Şehir id | [optional] 
 **townGroup** | **Number**| İlçe grubu id | [optional] 
 **name** | **String**| İlçe adı. | [optional] 
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townsIdDelete"></a>
# **townsIdDelete**
> townsIdDelete(id)

İlçe Silme

Kalıcı olarak ilgili İlçeyi siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.TownApi();

let id = 56; // Number | İlçe nesnesinin id değeri


apiInstance.townsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| İlçe nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townsIdGet"></a>
# **townsIdGet**
> Town townsIdGet(id)

İlçe Alma

İlgili İlçeyi getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.TownApi();

let id = 56; // Number | İlçe nesnesinin id değeri


apiInstance.townsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| İlçe nesnesinin id değeri | 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townsIdPut"></a>
# **townsIdPut**
> Town townsIdPut(id, town)

İlçe Güncelleme

İlgili İlçeyi günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.TownApi();

let id = 56; // Number | İlçe nesnesinin id değeri

let town = new IdeaSoftApi.Town(); // Town | Town nesnesi


apiInstance.townsIdPut(id, town, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| İlçe nesnesinin id değeri | 
 **town** | [**Town**](Town.md)| Town nesnesi | 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="townsPost"></a>
# **townsPost**
> Town townsPost(town)

İlçe Oluşturma

Yeni bir İlçe oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.TownApi();

let town = new IdeaSoftApi.Town(); // Town | Town nesnesi


apiInstance.townsPost(town, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **town** | [**Town**](Town.md)| Town nesnesi | 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

