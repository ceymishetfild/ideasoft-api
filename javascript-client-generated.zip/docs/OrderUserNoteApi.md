# IdeaSoftApi.OrderUserNoteApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**orderUserNotesGet**](OrderUserNoteApi.md#orderUserNotesGet) | **GET** /order_user_notes | Sipariş Yönetici Notu Listesi Alma
[**orderUserNotesIdDelete**](OrderUserNoteApi.md#orderUserNotesIdDelete) | **DELETE** /order_user_notes/{id} | Sipariş Yönetici Notu Silme
[**orderUserNotesIdGet**](OrderUserNoteApi.md#orderUserNotesIdGet) | **GET** /order_user_notes/{id} | Sipariş Yönetici Notu Alma
[**orderUserNotesIdPut**](OrderUserNoteApi.md#orderUserNotesIdPut) | **PUT** /order_user_notes/{id} | Sipariş Yönetici Notu Güncelleme
[**orderUserNotesPost**](OrderUserNoteApi.md#orderUserNotesPost) | **POST** /order_user_notes | Sipariş Yönetici Notu Oluşturma


<a name="orderUserNotesGet"></a>
# **orderUserNotesGet**
> OrderUserNote orderUserNotesGet(opts)

Sipariş Yönetici Notu Listesi Alma

Sipariş Yönetici Notu listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OrderUserNoteApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'order': 56, // Number | Sipariş id
  'userEmail': "userEmail_example", // String | Yönetici e-mail
  'startDate': new Date("2013-10-20"), // Date | createdAt değeri için başlangıç tarihi
  'endDate': "endDate_example", // String | createdAt değeri için bitiş tarihi
  'startUpdatedAt': new Date("2013-10-20"), // Date | updatedAt değeri için başlangıç tarihi
  'endUpdatedAt': "endUpdatedAt_example" // String | updatedAt değeri için bitiş tarihi
};

apiInstance.orderUserNotesGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **Number**| Sipariş id | [optional] 
 **userEmail** | **String**| Yönetici e-mail | [optional] 
 **startDate** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderUserNotesIdDelete"></a>
# **orderUserNotesIdDelete**
> orderUserNotesIdDelete(id)

Sipariş Yönetici Notu Silme

Kalıcı olarak ilgili Sipariş Yönetici Notunu siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OrderUserNoteApi();

let id = 56; // Number | Sipariş Yönetici Notu nesnesinin id değeri


apiInstance.orderUserNotesIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sipariş Yönetici Notu nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderUserNotesIdGet"></a>
# **orderUserNotesIdGet**
> OrderUserNote orderUserNotesIdGet(id)

Sipariş Yönetici Notu Alma

İlgili Sipariş Yönetici Notunu getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OrderUserNoteApi();

let id = 56; // Number | Sipariş Yönetici Notu nesnesinin id değeri


apiInstance.orderUserNotesIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sipariş Yönetici Notu nesnesinin id değeri | 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderUserNotesIdPut"></a>
# **orderUserNotesIdPut**
> OrderUserNote orderUserNotesIdPut(id, orderUserNote)

Sipariş Yönetici Notu Güncelleme

İlgili Sipariş Yönetici Notunu günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OrderUserNoteApi();

let id = 56; // Number | Sipariş Yönetici Notu nesnesinin id değeri

let orderUserNote = new IdeaSoftApi.OrderUserNote(); // OrderUserNote | OrderUserNote nesnesi


apiInstance.orderUserNotesIdPut(id, orderUserNote, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Sipariş Yönetici Notu nesnesinin id değeri | 
 **orderUserNote** | [**OrderUserNote**](OrderUserNote.md)| OrderUserNote nesnesi | 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderUserNotesPost"></a>
# **orderUserNotesPost**
> OrderUserNote orderUserNotesPost(orderUserNote)

Sipariş Yönetici Notu Oluşturma

Yeni bir Sipariş Yönetici Notu oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.OrderUserNoteApi();

let orderUserNote = new IdeaSoftApi.OrderUserNote(); // OrderUserNote | OrderUserNote nesnesi


apiInstance.orderUserNotesPost(orderUserNote, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orderUserNote** | [**OrderUserNote**](OrderUserNote.md)| OrderUserNote nesnesi | 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

