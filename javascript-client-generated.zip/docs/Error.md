# IdeaSoftApi.Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Number** | HTTP Hata kodu. | [optional] 
**errorMessage** | **String** | Hata mesajı. Hata mesajları İngilizce dilindedir. | [optional] 
**errorCode** | **Number** | Hata kodu. Eğer ek bir hata kodu varsa bu alanda belirtilir. | [optional] 


