# IdeaSoftApi.ProductToCategoryApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productToCategoriesGet**](ProductToCategoryApi.md#productToCategoriesGet) | **GET** /product_to_categories | Ürün Kategori Bağı Listesi Alma
[**productToCategoriesIdDelete**](ProductToCategoryApi.md#productToCategoriesIdDelete) | **DELETE** /product_to_categories/{id} | Ürün Kategori Bağı Silme
[**productToCategoriesIdGet**](ProductToCategoryApi.md#productToCategoriesIdGet) | **GET** /product_to_categories/{id} | Ürün Kategori Bağı Alma
[**productToCategoriesIdPut**](ProductToCategoryApi.md#productToCategoriesIdPut) | **PUT** /product_to_categories/{id} | Ürün Kategori Bağı Güncelleme
[**productToCategoriesPost**](ProductToCategoryApi.md#productToCategoriesPost) | **POST** /product_to_categories | Ürün Kategori Bağı Oluşturma


<a name="productToCategoriesGet"></a>
# **productToCategoriesGet**
> ProductToCategory productToCategoriesGet(opts)

Ürün Kategori Bağı Listesi Alma

Ürün Kategori Bağı listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductToCategoryApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'product': 56, // Number | Ürün id
  'category': 56 // Number | Kategori id
};

apiInstance.productToCategoriesGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **product** | **Number**| Ürün id | [optional] 
 **category** | **Number**| Kategori id | [optional] 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCategoriesIdDelete"></a>
# **productToCategoriesIdDelete**
> productToCategoriesIdDelete(id)

Ürün Kategori Bağı Silme

Kalıcı olarak ilgili Ürün Kategori Bağını siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductToCategoryApi();

let id = 56; // Number | Ürün Kategori Bağı nesnesinin id değeri


apiInstance.productToCategoriesIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Kategori Bağı nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCategoriesIdGet"></a>
# **productToCategoriesIdGet**
> ProductToCategory productToCategoriesIdGet(id)

Ürün Kategori Bağı Alma

İlgili Ürün Kategori Bağını getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductToCategoryApi();

let id = 56; // Number | Ürün Kategori Bağı nesnesinin id değeri


apiInstance.productToCategoriesIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Kategori Bağı nesnesinin id değeri | 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCategoriesIdPut"></a>
# **productToCategoriesIdPut**
> ProductToCategory productToCategoriesIdPut(id, productToCategory)

Ürün Kategori Bağı Güncelleme

İlgili Ürün Kategori Bağını günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductToCategoryApi();

let id = 56; // Number | Ürün Kategori Bağı nesnesinin id değeri

let productToCategory = new IdeaSoftApi.ProductToCategory(); // ProductToCategory | ProductToCategory nesnesi


apiInstance.productToCategoriesIdPut(id, productToCategory, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Kategori Bağı nesnesinin id değeri | 
 **productToCategory** | [**ProductToCategory**](ProductToCategory.md)| ProductToCategory nesnesi | 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productToCategoriesPost"></a>
# **productToCategoriesPost**
> ProductToCategory productToCategoriesPost(productToCategory)

Ürün Kategori Bağı Oluşturma

Yeni bir Ürün Kategori Bağı oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductToCategoryApi();

let productToCategory = new IdeaSoftApi.ProductToCategory(); // ProductToCategory | ProductToCategory nesnesi


apiInstance.productToCategoriesPost(productToCategory, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productToCategory** | [**ProductToCategory**](ProductToCategory.md)| ProductToCategory nesnesi | 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

