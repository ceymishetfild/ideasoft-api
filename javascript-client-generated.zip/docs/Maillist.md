# IdeaSoftApi.Maillist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Mail listesi nesnesi kimlik değeri. | [optional] 
**name** | **String** | Mail listesi nesnesi için isim değeri. | 
**email** | **String** | Ziyaretçi veya üyenin mail adresi. | 
**lastMailSentDate** | **Date** | En son e-mail gönderilen zaman. | [optional] 
**creatorIpAddress** | **String** | Mail listesi nesnesini oluşturan kişinin IP adresi. | [optional] 
**createdAt** | **Date** | Mail listesi nesnesinin oluşturulma zamanı. | 
**updatedAt** | **Date** | Mail listesi nesnesinin güncellenme zamanı. | 
**maillistGroup** | [**MaillistGroup**](MaillistGroup.md) | Mail listesi grubu nesnesi. | 


