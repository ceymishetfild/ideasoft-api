# IdeaSoftApi.SelectionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selectionsGet**](SelectionApi.md#selectionsGet) | **GET** /selections | Ek Özellik Listesi Alma
[**selectionsIdDelete**](SelectionApi.md#selectionsIdDelete) | **DELETE** /selections/{id} | Ek Özellik Silme
[**selectionsIdGet**](SelectionApi.md#selectionsIdGet) | **GET** /selections/{id} | Ek Özellik Alma
[**selectionsIdPut**](SelectionApi.md#selectionsIdPut) | **PUT** /selections/{id} | Ek Özellik Güncelleme
[**selectionsPost**](SelectionApi.md#selectionsPost) | **POST** /selections | Ek Özellik Oluşturma


<a name="selectionsGet"></a>
# **selectionsGet**
> Selection selectionsGet(opts)

Ek Özellik Listesi Alma

Ek Özellik listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SelectionApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'title': "title_example", // String | Ek Özellik başlığı
  'selectionGroup': 56 // Number | Ek Özellik Grubu id
};

apiInstance.selectionsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **title** | **String**| Ek Özellik başlığı | [optional] 
 **selectionGroup** | **Number**| Ek Özellik Grubu id | [optional] 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionsIdDelete"></a>
# **selectionsIdDelete**
> selectionsIdDelete(id)

Ek Özellik Silme

Kalıcı olarak ilgili Ek Özelliği siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SelectionApi();

let id = 56; // Number | Ek Özellik nesnesinin id değeri


apiInstance.selectionsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Özellik nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionsIdGet"></a>
# **selectionsIdGet**
> Selection selectionsIdGet(id)

Ek Özellik Alma

İlgili Ek Özelliği getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SelectionApi();

let id = 56; // Number | Ek Özellik nesnesinin id değeri


apiInstance.selectionsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Özellik nesnesinin id değeri | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionsIdPut"></a>
# **selectionsIdPut**
> Selection selectionsIdPut(id, selection)

Ek Özellik Güncelleme

İlgili Ek Özelliği günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SelectionApi();

let id = 56; // Number | Ek Özellik nesnesinin id değeri

let selection = new IdeaSoftApi.Selection(); // Selection | Selection nesnesi


apiInstance.selectionsIdPut(id, selection, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ek Özellik nesnesinin id değeri | 
 **selection** | [**Selection**](Selection.md)| Selection nesnesi | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="selectionsPost"></a>
# **selectionsPost**
> Selection selectionsPost(selection)

Ek Özellik Oluşturma

Yeni bir Ek Özellik oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SelectionApi();

let selection = new IdeaSoftApi.Selection(); // Selection | Selection nesnesi


apiInstance.selectionsPost(selection, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selection** | [**Selection**](Selection.md)| Selection nesnesi | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

