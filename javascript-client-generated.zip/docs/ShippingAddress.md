# IdeaSoftApi.ShippingAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


