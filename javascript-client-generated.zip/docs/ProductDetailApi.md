# IdeaSoftApi.ProductDetailApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productDetailsGet**](ProductDetailApi.md#productDetailsGet) | **GET** /product_details | Ürün Detay Listesi Alma
[**productDetailsIdDelete**](ProductDetailApi.md#productDetailsIdDelete) | **DELETE** /product_details/{id} | Ürün Detay Silme
[**productDetailsIdGet**](ProductDetailApi.md#productDetailsIdGet) | **GET** /product_details/{id} | Ürün Detay Alma
[**productDetailsIdPut**](ProductDetailApi.md#productDetailsIdPut) | **PUT** /product_details/{id} | Ürün Detay Güncelleme
[**productDetailsPost**](ProductDetailApi.md#productDetailsPost) | **POST** /product_details | Ürün Detay Oluşturma


<a name="productDetailsGet"></a>
# **productDetailsGet**
> ProductDetail productDetailsGet(opts)

Ürün Detay Listesi Alma

Ürün Detay listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductDetailApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'sku': "sku_example" // String | Ürün stok kodu
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productDetailsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **sku** | **String**| Ürün stok kodu | [optional] 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productDetailsIdDelete"></a>
# **productDetailsIdDelete**
> productDetailsIdDelete(id)

Ürün Detay Silme

Kalıcı olarak ilgili Ürün Detayını siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductDetailApi();

var id = 56; // Number | Ürün Detay nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.productDetailsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Detay nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productDetailsIdGet"></a>
# **productDetailsIdGet**
> ProductDetail productDetailsIdGet(id)

Ürün Detay Alma

İlgili Ürün Detayını getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductDetailApi();

var id = 56; // Number | Ürün Detay nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productDetailsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Detay nesnesinin id değeri | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productDetailsIdPut"></a>
# **productDetailsIdPut**
> ProductDetail productDetailsIdPut(id, productDetail)

Ürün Detay Güncelleme

İlgili Ürün Detayını günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductDetailApi();

var id = 56; // Number | Ürün Detay nesnesinin id değeri

var productDetail = new IdeaSoftApi.ProductDetail(); // ProductDetail |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productDetailsIdPut(id, productDetail, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Detay nesnesinin id değeri | 
 **productDetail** | [**ProductDetail**](ProductDetail.md)|  nesnesi | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productDetailsPost"></a>
# **productDetailsPost**
> ProductDetail productDetailsPost(productDetail)

Ürün Detay Oluşturma

Yeni bir Ürün Detay oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.ProductDetailApi();

var productDetail = new IdeaSoftApi.ProductDetail(); // ProductDetail |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.productDetailsPost(productDetail, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productDetail** | [**ProductDetail**](ProductDetail.md)|  nesnesi | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

