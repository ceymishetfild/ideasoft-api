# IdeaSoftApi.ProductDetailApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productDetailsGet**](ProductDetailApi.md#productDetailsGet) | **GET** /product_details | Ürün Detay Listesi Alma
[**productDetailsIdDelete**](ProductDetailApi.md#productDetailsIdDelete) | **DELETE** /product_details/{id} | Ürün Detay Silme
[**productDetailsIdGet**](ProductDetailApi.md#productDetailsIdGet) | **GET** /product_details/{id} | Ürün Detay Alma
[**productDetailsIdPut**](ProductDetailApi.md#productDetailsIdPut) | **PUT** /product_details/{id} | Ürün Detay Güncelleme
[**productDetailsPost**](ProductDetailApi.md#productDetailsPost) | **POST** /product_details | Ürün Detay Oluşturma


<a name="productDetailsGet"></a>
# **productDetailsGet**
> ProductDetail productDetailsGet(opts)

Ürün Detay Listesi Alma

Ürün Detay listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductDetailApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'sku': "sku_example" // String | Ürün stok kodu
};

apiInstance.productDetailsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **sku** | **String**| Ürün stok kodu | [optional] 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productDetailsIdDelete"></a>
# **productDetailsIdDelete**
> productDetailsIdDelete(id)

Ürün Detay Silme

Kalıcı olarak ilgili Ürün Detayını siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductDetailApi();

let id = 56; // Number | Ürün Detay nesnesinin id değeri


apiInstance.productDetailsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Detay nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productDetailsIdGet"></a>
# **productDetailsIdGet**
> ProductDetail productDetailsIdGet(id)

Ürün Detay Alma

İlgili Ürün Detayını getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductDetailApi();

let id = 56; // Number | Ürün Detay nesnesinin id değeri


apiInstance.productDetailsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Detay nesnesinin id değeri | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productDetailsIdPut"></a>
# **productDetailsIdPut**
> ProductDetail productDetailsIdPut(id, productDetail)

Ürün Detay Güncelleme

İlgili Ürün Detayını günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductDetailApi();

let id = 56; // Number | Ürün Detay nesnesinin id değeri

let productDetail = new IdeaSoftApi.ProductDetail(); // ProductDetail | ProductDetail nesnesi


apiInstance.productDetailsIdPut(id, productDetail, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Detay nesnesinin id değeri | 
 **productDetail** | [**ProductDetail**](ProductDetail.md)| ProductDetail nesnesi | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="productDetailsPost"></a>
# **productDetailsPost**
> ProductDetail productDetailsPost(productDetail)

Ürün Detay Oluşturma

Yeni bir Ürün Detay oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ProductDetailApi();

let productDetail = new IdeaSoftApi.ProductDetail(); // ProductDetail | ProductDetail nesnesi


apiInstance.productDetailsPost(productDetail, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productDetail** | [**ProductDetail**](ProductDetail.md)| ProductDetail nesnesi | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

