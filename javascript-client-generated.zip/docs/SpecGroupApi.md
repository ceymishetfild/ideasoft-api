# IdeaSoftApi.SpecGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specGroupsGet**](SpecGroupApi.md#specGroupsGet) | **GET** /spec_groups | Ürün Özellik Grubu Listesi Alma
[**specGroupsIdDelete**](SpecGroupApi.md#specGroupsIdDelete) | **DELETE** /spec_groups/{id} | Ürün Özellik Grubu Silme
[**specGroupsIdGet**](SpecGroupApi.md#specGroupsIdGet) | **GET** /spec_groups/{id} | Ürün Özellik Grubu Alma
[**specGroupsIdPut**](SpecGroupApi.md#specGroupsIdPut) | **PUT** /spec_groups/{id} | Ürün Özellik Grubu Güncelleme
[**specGroupsPost**](SpecGroupApi.md#specGroupsPost) | **POST** /spec_groups | Ürün Özellik Grubu Oluşturma


<a name="specGroupsGet"></a>
# **specGroupsGet**
> SpecGroup specGroupsGet(opts)

Ürün Özellik Grubu Listesi Alma

Ürün Özellik Grubu listesini verir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SpecGroupApi();

var opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'ids': "ids_example", // String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  'name': "name_example" // String | Ürün Özellik Grubu adı
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.specGroupsGet(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **String**| Ürün Özellik Grubu adı | [optional] 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specGroupsIdDelete"></a>
# **specGroupsIdDelete**
> specGroupsIdDelete(id)

Ürün Özellik Grubu Silme

Kalıcı olarak ilgili Ürün Özellik Grubunu siler.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SpecGroupApi();

var id = 56; // Number | Ürün Özellik Grubu nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.specGroupsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik Grubu nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specGroupsIdGet"></a>
# **specGroupsIdGet**
> SpecGroup specGroupsIdGet(id)

Ürün Özellik Grubu Alma

İlgili Ürün Özellik Grubunu getirir.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SpecGroupApi();

var id = 56; // Number | Ürün Özellik Grubu nesnesinin id değeri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.specGroupsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik Grubu nesnesinin id değeri | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specGroupsIdPut"></a>
# **specGroupsIdPut**
> SpecGroup specGroupsIdPut(id, specGroup)

Ürün Özellik Grubu Güncelleme

İlgili Ürün Özellik Grubunu günceller.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SpecGroupApi();

var id = 56; // Number | Ürün Özellik Grubu nesnesinin id değeri

var specGroup = new IdeaSoftApi.SpecGroup(); // SpecGroup |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.specGroupsIdPut(id, specGroup, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik Grubu nesnesinin id değeri | 
 **specGroup** | [**SpecGroup**](SpecGroup.md)|  nesnesi | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specGroupsPost"></a>
# **specGroupsPost**
> SpecGroup specGroupsPost(specGroup)

Ürün Özellik Grubu Oluşturma

Yeni bir Ürün Özellik Grubu oluşturur.

### Example
```javascript
var IdeaSoftApi = require('idea_soft_api');
var defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
var OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new IdeaSoftApi.SpecGroupApi();

var specGroup = new IdeaSoftApi.SpecGroup(); // SpecGroup |  nesnesi


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.specGroupsPost(specGroup, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specGroup** | [**SpecGroup**](SpecGroup.md)|  nesnesi | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

