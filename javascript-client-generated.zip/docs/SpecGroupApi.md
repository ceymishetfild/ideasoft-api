# IdeaSoftApi.SpecGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specGroupsGet**](SpecGroupApi.md#specGroupsGet) | **GET** /spec_groups | Ürün Özellik Grubu Listesi Alma
[**specGroupsIdDelete**](SpecGroupApi.md#specGroupsIdDelete) | **DELETE** /spec_groups/{id} | Ürün Özellik Grubu Silme
[**specGroupsIdGet**](SpecGroupApi.md#specGroupsIdGet) | **GET** /spec_groups/{id} | Ürün Özellik Grubu Alma
[**specGroupsIdPut**](SpecGroupApi.md#specGroupsIdPut) | **PUT** /spec_groups/{id} | Ürün Özellik Grubu Güncelleme
[**specGroupsPost**](SpecGroupApi.md#specGroupsPost) | **POST** /spec_groups | Ürün Özellik Grubu Oluşturma


<a name="specGroupsGet"></a>
# **specGroupsGet**
> SpecGroup specGroupsGet(opts)

Ürün Özellik Grubu Listesi Alma

Ürün Özellik Grubu listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SpecGroupApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'name': "name_example" // String | Ürün Özellik Grubu adı
};

apiInstance.specGroupsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **String**| Ürün Özellik Grubu adı | [optional] 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specGroupsIdDelete"></a>
# **specGroupsIdDelete**
> specGroupsIdDelete(id)

Ürün Özellik Grubu Silme

Kalıcı olarak ilgili Ürün Özellik Grubunu siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SpecGroupApi();

let id = 56; // Number | Ürün Özellik Grubu nesnesinin id değeri


apiInstance.specGroupsIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik Grubu nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specGroupsIdGet"></a>
# **specGroupsIdGet**
> SpecGroup specGroupsIdGet(id)

Ürün Özellik Grubu Alma

İlgili Ürün Özellik Grubunu getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SpecGroupApi();

let id = 56; // Number | Ürün Özellik Grubu nesnesinin id değeri


apiInstance.specGroupsIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik Grubu nesnesinin id değeri | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specGroupsIdPut"></a>
# **specGroupsIdPut**
> SpecGroup specGroupsIdPut(id, specGroup)

Ürün Özellik Grubu Güncelleme

İlgili Ürün Özellik Grubunu günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SpecGroupApi();

let id = 56; // Number | Ürün Özellik Grubu nesnesinin id değeri

let specGroup = new IdeaSoftApi.SpecGroup(); // SpecGroup | SpecGroup nesnesi


apiInstance.specGroupsIdPut(id, specGroup, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Ürün Özellik Grubu nesnesinin id değeri | 
 **specGroup** | [**SpecGroup**](SpecGroup.md)| SpecGroup nesnesi | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="specGroupsPost"></a>
# **specGroupsPost**
> SpecGroup specGroupsPost(specGroup)

Ürün Özellik Grubu Oluşturma

Yeni bir Ürün Özellik Grubu oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.SpecGroupApi();

let specGroup = new IdeaSoftApi.SpecGroup(); // SpecGroup | SpecGroup nesnesi


apiInstance.specGroupsPost(specGroup, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specGroup** | [**SpecGroup**](SpecGroup.md)| SpecGroup nesnesi | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

