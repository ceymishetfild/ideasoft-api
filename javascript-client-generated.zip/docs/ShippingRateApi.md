# IdeaSoftApi.ShippingRateApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shippingRatesGet**](ShippingRateApi.md#shippingRatesGet) | **GET** /shipping_rates | Kargo Oranı Listesi Alma
[**shippingRatesIdDelete**](ShippingRateApi.md#shippingRatesIdDelete) | **DELETE** /shipping_rates/{id} | Kargo Oranı Silme
[**shippingRatesIdGet**](ShippingRateApi.md#shippingRatesIdGet) | **GET** /shipping_rates/{id} | Kargo Oranı Alma
[**shippingRatesIdPut**](ShippingRateApi.md#shippingRatesIdPut) | **PUT** /shipping_rates/{id} | Kargo Oranı Güncelleme
[**shippingRatesPost**](ShippingRateApi.md#shippingRatesPost) | **POST** /shipping_rates | Kargo Oranı Oluşturma


<a name="shippingRatesGet"></a>
# **shippingRatesGet**
> ShippingRate shippingRatesGet(opts)

Kargo Oranı Listesi Alma

Kargo Oranı listesini verir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ShippingRateApi();

let opts = { 
  'sort': "sort_example", // String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  'limit': 20, // Number | Bir sayfada gelecek sonuç adedi
  'page': 1, // Number | Hangi sayfadan başlanacağı
  'sinceId': 56, // Number | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  'shippingCompany': 56, // Number | Kargo firması id
  'region': 56 // Number | Bölge id
};

apiInstance.shippingRatesGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Number**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Number**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **Number**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **shippingCompany** | **Number**| Kargo firması id | [optional] 
 **region** | **Number**| Bölge id | [optional] 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingRatesIdDelete"></a>
# **shippingRatesIdDelete**
> shippingRatesIdDelete(id)

Kargo Oranı Silme

Kalıcı olarak ilgili Kargo Oranını siler.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ShippingRateApi();

let id = 56; // Number | Kargo Oranı nesnesinin id değeri


apiInstance.shippingRatesIdDelete(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Kargo Oranı nesnesinin id değeri | 

### Return type

null (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingRatesIdGet"></a>
# **shippingRatesIdGet**
> ShippingRate shippingRatesIdGet(id)

Kargo Oranı Alma

İlgili Kargo Oranını getirir.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ShippingRateApi();

let id = 56; // Number | Kargo Oranı nesnesinin id değeri


apiInstance.shippingRatesIdGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Kargo Oranı nesnesinin id değeri | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingRatesIdPut"></a>
# **shippingRatesIdPut**
> ShippingRate shippingRatesIdPut(id, shippingRate)

Kargo Oranı Güncelleme

İlgili Kargo Oranını günceller.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ShippingRateApi();

let id = 56; // Number | Kargo Oranı nesnesinin id değeri

let shippingRate = new IdeaSoftApi.ShippingRate(); // ShippingRate | ShippingRate nesnesi


apiInstance.shippingRatesIdPut(id, shippingRate, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| Kargo Oranı nesnesinin id değeri | 
 **shippingRate** | [**ShippingRate**](ShippingRate.md)| ShippingRate nesnesi | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="shippingRatesPost"></a>
# **shippingRatesPost**
> ShippingRate shippingRatesPost(shippingRate)

Kargo Oranı Oluşturma

Yeni bir Kargo Oranı oluşturur.

### Example
```javascript
import IdeaSoftApi from 'idea_soft_api';
let defaultClient = IdeaSoftApi.ApiClient.instance;

// Configure OAuth2 access token for authorization: OAuth2
let OAuth2 = defaultClient.authentications['OAuth2'];
OAuth2.accessToken = 'YOUR ACCESS TOKEN';

let apiInstance = new IdeaSoftApi.ShippingRateApi();

let shippingRate = new IdeaSoftApi.ShippingRate(); // ShippingRate | ShippingRate nesnesi


apiInstance.shippingRatesPost(shippingRate, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shippingRate** | [**ShippingRate**](ShippingRate.md)| ShippingRate nesnesi | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

