# SwaggerClient::SelectionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selections_get**](SelectionApi.md#selections_get) | **GET** /selections | Ek Özellik Listesi Alma
[**selections_id_delete**](SelectionApi.md#selections_id_delete) | **DELETE** /selections/{id} | Ek Özellik Silme
[**selections_id_get**](SelectionApi.md#selections_id_get) | **GET** /selections/{id} | Ek Özellik Alma
[**selections_id_put**](SelectionApi.md#selections_id_put) | **PUT** /selections/{id} | Ek Özellik Güncelleme
[**selections_post**](SelectionApi.md#selections_post) | **POST** /selections | Ek Özellik Oluşturma


# **selections_get**
> Selection selections_get(opts)

Ek Özellik Listesi Alma

Ek Özellik listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SelectionApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  title: "title_example", # String | Ek Özellik başlığı
  selection_group: 56 # Integer | Ek Özellik Grubu id
}

begin
  #Ek Özellik Listesi Alma
  result = api_instance.selections_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SelectionApi->selections_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **title** | **String**| Ek Özellik başlığı | [optional] 
 **selection_group** | **Integer**| Ek Özellik Grubu id | [optional] 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **selections_id_delete**
> selections_id_delete(id)

Ek Özellik Silme

Kalıcı olarak ilgili Ek Özelliği siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SelectionApi.new

id = 56 # Integer | Ek Özellik nesnesinin id değeri


begin
  #Ek Özellik Silme
  api_instance.selections_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SelectionApi->selections_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Özellik nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **selections_id_get**
> Selection selections_id_get(id)

Ek Özellik Alma

İlgili Ek Özelliği getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SelectionApi.new

id = 56 # Integer | Ek Özellik nesnesinin id değeri


begin
  #Ek Özellik Alma
  result = api_instance.selections_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SelectionApi->selections_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Özellik nesnesinin id değeri | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **selections_id_put**
> Selection selections_id_put(id, selection)

Ek Özellik Güncelleme

İlgili Ek Özelliği günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SelectionApi.new

id = 56 # Integer | Ek Özellik nesnesinin id değeri

selection = SwaggerClient::Selection.new # Selection | Selection nesnesi


begin
  #Ek Özellik Güncelleme
  result = api_instance.selections_id_put(id, selection)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SelectionApi->selections_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Özellik nesnesinin id değeri | 
 **selection** | [**Selection**](Selection.md)| Selection nesnesi | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **selections_post**
> Selection selections_post(selection)

Ek Özellik Oluşturma

Yeni bir Ek Özellik oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SelectionApi.new

selection = SwaggerClient::Selection.new # Selection | Selection nesnesi


begin
  #Ek Özellik Oluşturma
  result = api_instance.selections_post(selection)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SelectionApi->selections_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selection** | [**Selection**](Selection.md)| Selection nesnesi | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



