# SwaggerClient::MemberApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**members_charts_get**](MemberApi.md#members_charts_get) | **GET** /members/charts | Üye Grafik Aksiyonu
[**members_combined_get**](MemberApi.md#members_combined_get) | **GET** /members/combined | Üye Birleşik Aksiyonu
[**members_get**](MemberApi.md#members_get) | **GET** /members | Üye Listesi Alma
[**members_id_delete**](MemberApi.md#members_id_delete) | **DELETE** /members/{id} | Üye Silme
[**members_id_get**](MemberApi.md#members_id_get) | **GET** /members/{id} | Üye Alma
[**members_id_put**](MemberApi.md#members_id_put) | **PUT** /members/{id} | Üye Güncelleme
[**members_post**](MemberApi.md#members_post) | **POST** /members | Üye Oluşturma


# **members_charts_get**
> Member members_charts_get(time_frame, start_date)

Üye Grafik Aksiyonu

Zaman bazında üye genel istatistiklerini getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberApi.new

time_frame = "time_frame_example" # String | Şu değerleri olabilir: full, year, month or week

start_date = "start_date_example" # String | Zaman aralığının başlangıcı


begin
  #Üye Grafik Aksiyonu
  result = api_instance.members_charts_get(time_frame, start_date)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberApi->members_charts_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **time_frame** | **String**| Şu değerleri olabilir: full, year, month or week | 
 **start_date** | **String**| Zaman aralığının başlangıcı | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **members_combined_get**
> Member members_combined_get

Üye Birleşik Aksiyonu

Bugün, aylık, yıllık ve toplam üye oturum açma istatistiklerini totalCount cinsinden getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberApi.new

begin
  #Üye Birleşik Aksiyonu
  result = api_instance.members_combined_get
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberApi->members_combined_get: #{e}"
end
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **members_get**
> Member members_get(opts)

Üye Listesi Alma

Üye listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  firstname: "firstname_example", # String | Adı
  surname: "surname_example", # String | Soyadı
  email: "email_example", # String | e-mail adresi
  password: "password_example", # String | Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri
  gender: "gender_example", # String | Cinsiyet şu değerleri alabilir: <br><code>male</code> : Erkek<br><code>female</code> : Kadın
  mobile_phone_number: "mobile_phone_number_example", # String | Üye mobil telefon numarası
  phone_number: "phone_number_example", # String | Üye telefon numarası
  member_group: 56, # Integer | Üye Grubu id
  location: 56, # Integer | Şehir id
  country: 56, # Integer | Ülke id
  referred_member: 56, # Integer | Tavsiye Üye id
  q: ["q_example"], # Array<String> | Üye arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;]
  start_date: Date.parse("2013-10-20"), # Date | createdAt değeri için başlangıç tarihi
  end_date: "end_date_example", # String | createdAt değeri için bitiş tarihi
  start_updated_at: Date.parse("2013-10-20"), # Date | updatedAt değeri için başlangıç tarihi
  end_updated_at: "end_updated_at_example" # String | updatedAt değeri için bitiş tarihi
}

begin
  #Üye Listesi Alma
  result = api_instance.members_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberApi->members_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **firstname** | **String**| Adı | [optional] 
 **surname** | **String**| Soyadı | [optional] 
 **email** | **String**| e-mail adresi | [optional] 
 **password** | **String**| Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri | [optional] 
 **gender** | **String**| Cinsiyet şu değerleri alabilir: &lt;br&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın | [optional] 
 **mobile_phone_number** | **String**| Üye mobil telefon numarası | [optional] 
 **phone_number** | **String**| Üye telefon numarası | [optional] 
 **member_group** | **Integer**| Üye Grubu id | [optional] 
 **location** | **Integer**| Şehir id | [optional] 
 **country** | **Integer**| Ülke id | [optional] 
 **referred_member** | **Integer**| Tavsiye Üye id | [optional] 
 **q** | [**Array&lt;String&gt;**](String.md)| Üye arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 
 **start_date** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **members_id_delete**
> members_id_delete(id)

Üye Silme

Kalıcı olarak ilgili Üyeyi siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberApi.new

id = 56 # Integer | Üye nesnesinin id değeri


begin
  #Üye Silme
  api_instance.members_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberApi->members_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **members_id_get**
> Member members_id_get(id)

Üye Alma

İlgili Üyeyi getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberApi.new

id = 56 # Integer | Üye nesnesinin id değeri


begin
  #Üye Alma
  result = api_instance.members_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberApi->members_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye nesnesinin id değeri | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **members_id_put**
> Member members_id_put(id, member)

Üye Güncelleme

İlgili Üyeyi günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberApi.new

id = 56 # Integer | Üye nesnesinin id değeri

member = SwaggerClient::Member.new # Member | Member nesnesi


begin
  #Üye Güncelleme
  result = api_instance.members_id_put(id, member)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberApi->members_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye nesnesinin id değeri | 
 **member** | [**Member**](Member.md)| Member nesnesi | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **members_post**
> Member members_post(member)

Üye Oluşturma

Yeni bir Üye oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberApi.new

member = SwaggerClient::Member.new # Member | Member nesnesi


begin
  #Üye Oluşturma
  result = api_instance.members_post(member)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberApi->members_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member** | [**Member**](Member.md)| Member nesnesi | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



