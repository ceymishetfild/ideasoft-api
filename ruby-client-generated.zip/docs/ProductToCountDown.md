# SwaggerClient::ProductToCountDown

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ürün geri sayım bağı nesnesi kimlik değeri. | [optional] 
**start_date** | **DateTime** | Geri sayımın başlangıç tarihi. | [optional] 
**end_date** | **DateTime** | Geri sayımın bitiş tarihi. | [optional] 
**expire_date** | **DateTime** | Geri sayımın ürün için geçersiz olma tarihi. | [optional] 
**use_count_down** | **String** | Geri sayımın aktiflik durumu bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 


