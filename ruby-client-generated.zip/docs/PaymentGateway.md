# SwaggerClient::PaymentGateway

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ödeme kanalı nesnesi kimlik değeri. | [optional] 
**code** | **String** | Ödeme kanalı için ön tanımlanmış kod değeri. | 
**name** | **String** | Ödeme kanalı nesnesi için isim değeri. | 
**status** | **String** | Ödeme kanalının aktiflik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;/div&gt; | 
**sort_order** | **Integer** | Ödeme kanalı nesnesi için sıralama değeri. | [optional] 
**payment_provider** | [**PaymentProvider**](PaymentProvider.md) | Ödeme altyapısı sağlayıcısı nesnesi. | 
**settings** | [**Array&lt;PaymentGatewaySetting&gt;**](PaymentGatewaySetting.md) | Ödeme kanalı ayarları. | [optional] 


