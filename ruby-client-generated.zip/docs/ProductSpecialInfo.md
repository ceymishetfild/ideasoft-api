# SwaggerClient::ProductSpecialInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Özel bilgi alanı nesnesi kimlik değeri. | [optional] 
**title** | **String** | Özel bilgi alanı başlığı. | 
**content** | **String** | Özel bilgi alanı içeriği. | 
**status** | **Integer** | Özel bilgi alanı aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 


