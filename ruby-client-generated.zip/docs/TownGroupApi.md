# SwaggerClient::TownGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**town_groups_get**](TownGroupApi.md#town_groups_get) | **GET** /town_groups | İlçe Grubu Listesi Alma
[**town_groups_id_delete**](TownGroupApi.md#town_groups_id_delete) | **DELETE** /town_groups/{id} | İlçe Grubu Silme
[**town_groups_id_get**](TownGroupApi.md#town_groups_id_get) | **GET** /town_groups/{id} | İlçe Grubu Alma
[**town_groups_id_put**](TownGroupApi.md#town_groups_id_put) | **PUT** /town_groups/{id} | İlçe Grubu Güncelleme
[**town_groups_post**](TownGroupApi.md#town_groups_post) | **POST** /town_groups | İlçe Grubu Oluşturma


# **town_groups_get**
> TownGroup town_groups_get(opts)

İlçe Grubu Listesi Alma

İlçe Grubu listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::TownGroupApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  name: "name_example" # String | İlçe Grubu adı
}

begin
  #İlçe Grubu Listesi Alma
  result = api_instance.town_groups_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TownGroupApi->town_groups_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **String**| İlçe Grubu adı | [optional] 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **town_groups_id_delete**
> town_groups_id_delete(id)

İlçe Grubu Silme

Kalıcı olarak ilgili İlçe Grubunu siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::TownGroupApi.new

id = 56 # Integer | İlçe Grubu nesnesinin id değeri


begin
  #İlçe Grubu Silme
  api_instance.town_groups_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TownGroupApi->town_groups_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| İlçe Grubu nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **town_groups_id_get**
> TownGroup town_groups_id_get(id)

İlçe Grubu Alma

İlgili İlçe Grubunu getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::TownGroupApi.new

id = 56 # Integer | İlçe Grubu nesnesinin id değeri


begin
  #İlçe Grubu Alma
  result = api_instance.town_groups_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TownGroupApi->town_groups_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| İlçe Grubu nesnesinin id değeri | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **town_groups_id_put**
> TownGroup town_groups_id_put(id, town_group)

İlçe Grubu Güncelleme

İlgili İlçe Grubunu günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::TownGroupApi.new

id = 56 # Integer | İlçe Grubu nesnesinin id değeri

town_group = SwaggerClient::TownGroup.new # TownGroup |  nesnesi


begin
  #İlçe Grubu Güncelleme
  result = api_instance.town_groups_id_put(id, town_group)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TownGroupApi->town_groups_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| İlçe Grubu nesnesinin id değeri | 
 **town_group** | [**TownGroup**](TownGroup.md)|  nesnesi | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **town_groups_post**
> TownGroup town_groups_post(town_group)

İlçe Grubu Oluşturma

Yeni bir İlçe Grubu oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::TownGroupApi.new

town_group = SwaggerClient::TownGroup.new # TownGroup |  nesnesi


begin
  #İlçe Grubu Oluşturma
  result = api_instance.town_groups_post(town_group)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TownGroupApi->town_groups_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **town_group** | [**TownGroup**](TownGroup.md)|  nesnesi | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



