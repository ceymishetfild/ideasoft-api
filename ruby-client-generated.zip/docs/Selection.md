# SwaggerClient::Selection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ek özellik nesnesi kimlik değeri. | [optional] 
**title** | **String** | Ek özellik nesnesinin başlığı. | [optional] 
**sort_order** | **Integer** | Ek özellik nesnesi için sıralama değeri. | 
**selection_group** | [**SelectionGroup**](SelectionGroup.md) | Ek özellik grubu nesnesi. | 


