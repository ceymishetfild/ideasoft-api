# SwaggerClient::Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** | HTTP Hata kodu. | [optional] 
**error_message** | **String** | Hata mesajı. Hata mesajları İngilizce dilindedir. | [optional] 
**error_code** | **Integer** | Hata kodu. Eğer ek bir hata kodu varsa bu alanda belirtilir. | [optional] 


