# SwaggerClient::ShippingRateApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipping_rates_get**](ShippingRateApi.md#shipping_rates_get) | **GET** /shipping_rates | Kargo Oranı Listesi Alma
[**shipping_rates_id_delete**](ShippingRateApi.md#shipping_rates_id_delete) | **DELETE** /shipping_rates/{id} | Kargo Oranı Silme
[**shipping_rates_id_get**](ShippingRateApi.md#shipping_rates_id_get) | **GET** /shipping_rates/{id} | Kargo Oranı Alma
[**shipping_rates_id_put**](ShippingRateApi.md#shipping_rates_id_put) | **PUT** /shipping_rates/{id} | Kargo Oranı Güncelleme
[**shipping_rates_post**](ShippingRateApi.md#shipping_rates_post) | **POST** /shipping_rates | Kargo Oranı Oluşturma


# **shipping_rates_get**
> ShippingRate shipping_rates_get(opts)

Kargo Oranı Listesi Alma

Kargo Oranı listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingRateApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  shipping_company: 56, # Integer | Kargo firması id
  region: 56 # Integer | Bölge id
}

begin
  #Kargo Oranı Listesi Alma
  result = api_instance.shipping_rates_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingRateApi->shipping_rates_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **shipping_company** | **Integer**| Kargo firması id | [optional] 
 **region** | **Integer**| Bölge id | [optional] 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipping_rates_id_delete**
> shipping_rates_id_delete(id)

Kargo Oranı Silme

Kalıcı olarak ilgili Kargo Oranını siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingRateApi.new

id = 56 # Integer | Kargo Oranı nesnesinin id değeri


begin
  #Kargo Oranı Silme
  api_instance.shipping_rates_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingRateApi->shipping_rates_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kargo Oranı nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipping_rates_id_get**
> ShippingRate shipping_rates_id_get(id)

Kargo Oranı Alma

İlgili Kargo Oranını getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingRateApi.new

id = 56 # Integer | Kargo Oranı nesnesinin id değeri


begin
  #Kargo Oranı Alma
  result = api_instance.shipping_rates_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingRateApi->shipping_rates_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kargo Oranı nesnesinin id değeri | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipping_rates_id_put**
> ShippingRate shipping_rates_id_put(id, shipping_rate)

Kargo Oranı Güncelleme

İlgili Kargo Oranını günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingRateApi.new

id = 56 # Integer | Kargo Oranı nesnesinin id değeri

shipping_rate = SwaggerClient::ShippingRate.new # ShippingRate | ShippingRate nesnesi


begin
  #Kargo Oranı Güncelleme
  result = api_instance.shipping_rates_id_put(id, shipping_rate)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingRateApi->shipping_rates_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kargo Oranı nesnesinin id değeri | 
 **shipping_rate** | [**ShippingRate**](ShippingRate.md)| ShippingRate nesnesi | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipping_rates_post**
> ShippingRate shipping_rates_post(shipping_rate)

Kargo Oranı Oluşturma

Yeni bir Kargo Oranı oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingRateApi.new

shipping_rate = SwaggerClient::ShippingRate.new # ShippingRate | ShippingRate nesnesi


begin
  #Kargo Oranı Oluşturma
  result = api_instance.shipping_rates_post(shipping_rate)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingRateApi->shipping_rates_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipping_rate** | [**ShippingRate**](ShippingRate.md)| ShippingRate nesnesi | 

### Return type

[**ShippingRate**](ShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



