# SwaggerClient::DistributorToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**distributor_to_products_get**](DistributorToProductApi.md#distributor_to_products_get) | **GET** /distributor_to_products | Distribütör Ürün Bağı Listesi Alma
[**distributor_to_products_id_delete**](DistributorToProductApi.md#distributor_to_products_id_delete) | **DELETE** /distributor_to_products/{id} | Distribütör Ürün Bağı Silme
[**distributor_to_products_id_get**](DistributorToProductApi.md#distributor_to_products_id_get) | **GET** /distributor_to_products/{id} | Distribütör Ürün Bağı Alma
[**distributor_to_products_id_put**](DistributorToProductApi.md#distributor_to_products_id_put) | **PUT** /distributor_to_products/{id} | Distribütör Ürün Bağı Güncelleme
[**distributor_to_products_post**](DistributorToProductApi.md#distributor_to_products_post) | **POST** /distributor_to_products | Distribütör Ürün Bağı Oluşturma


# **distributor_to_products_get**
> DistributorToProduct distributor_to_products_get(opts)

Distribütör Ürün Bağı Listesi Alma

Distribütör Ürün Bağı listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::DistributorToProductApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  distributor: 56, # Integer | Distribütör id
  product: 56 # Integer | Ürün id
}

begin
  #Distribütör Ürün Bağı Listesi Alma
  result = api_instance.distributor_to_products_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling DistributorToProductApi->distributor_to_products_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **distributor** | **Integer**| Distribütör id | [optional] 
 **product** | **Integer**| Ürün id | [optional] 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **distributor_to_products_id_delete**
> distributor_to_products_id_delete(id)

Distribütör Ürün Bağı Silme

Kalıcı olarak ilgili Distribütör Ürün Bağını siler

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::DistributorToProductApi.new

id = 56 # Integer | Distribütör Ürün Bağı nesnesinin id değeri


begin
  #Distribütör Ürün Bağı Silme
  api_instance.distributor_to_products_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling DistributorToProductApi->distributor_to_products_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Distribütör Ürün Bağı nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **distributor_to_products_id_get**
> DistributorToProduct distributor_to_products_id_get(id)

Distribütör Ürün Bağı Alma

İlgili Distribütör Ürün Bağını getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::DistributorToProductApi.new

id = 56 # Integer | Distribütör Ürün Bağı nesnesinin id değeri


begin
  #Distribütör Ürün Bağı Alma
  result = api_instance.distributor_to_products_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling DistributorToProductApi->distributor_to_products_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Distribütör Ürün Bağı nesnesinin id değeri | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **distributor_to_products_id_put**
> DistributorToProduct distributor_to_products_id_put(id, distributor_to_product)

Distribütör Ürün Bağı Güncelleme

İlgili Distribütör Ürün Bağını günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::DistributorToProductApi.new

id = 56 # Integer | Distribütör Ürün Bağı nesnesinin id değeri

distributor_to_product = SwaggerClient::DistributorToProduct.new # DistributorToProduct |  nesnesi


begin
  #Distribütör Ürün Bağı Güncelleme
  result = api_instance.distributor_to_products_id_put(id, distributor_to_product)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling DistributorToProductApi->distributor_to_products_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Distribütör Ürün Bağı nesnesinin id değeri | 
 **distributor_to_product** | [**DistributorToProduct**](DistributorToProduct.md)|  nesnesi | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **distributor_to_products_post**
> DistributorToProduct distributor_to_products_post(distributor_to_product)

Distribütör Ürün Bağı Oluşturma

Yeni bir Distribütör Ürün Bağı oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::DistributorToProductApi.new

distributor_to_product = SwaggerClient::DistributorToProduct.new # DistributorToProduct |  nesnesi


begin
  #Distribütör Ürün Bağı Oluşturma
  result = api_instance.distributor_to_products_post(distributor_to_product)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling DistributorToProductApi->distributor_to_products_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **distributor_to_product** | [**DistributorToProduct**](DistributorToProduct.md)|  nesnesi | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



