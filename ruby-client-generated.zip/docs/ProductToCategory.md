# SwaggerClient::ProductToCategory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ürün kategori bağı nesnesi kimlik değeri. | [optional] 
**sort_order** | **Integer** | Ürün kategori bağının sıralama değeri. Özel sıra belirtmek istemiyorsanız 9999 olarak iletebilirsiniz. | [optional] 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 
**category** | [**Category**](Category.md) | Kategori nesnesi. | 


