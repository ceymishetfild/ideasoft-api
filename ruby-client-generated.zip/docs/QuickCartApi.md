# SwaggerClient::QuickCartApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**quick_carts_get**](QuickCartApi.md#quick_carts_get) | **GET** /quick_carts | Hızlı Satın Al Bağlantısı Alma
[**quick_carts_id_delete**](QuickCartApi.md#quick_carts_id_delete) | **DELETE** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Silme
[**quick_carts_id_get**](QuickCartApi.md#quick_carts_id_get) | **GET** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Alma
[**quick_carts_id_put**](QuickCartApi.md#quick_carts_id_put) | **PUT** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Güncelleme
[**quick_carts_post**](QuickCartApi.md#quick_carts_post) | **POST** /quick_carts | Hızlı Satın Al Bağlantısı Oluşturma


# **quick_carts_get**
> QuickCart quick_carts_get(opts)

Hızlı Satın Al Bağlantısı Alma

Hızlı Satın Al Bağlantısı döndürür.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::QuickCartApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  name: "name_example" # String | Hızlı Satın Al Bağlantısı adı
}

begin
  #Hızlı Satın Al Bağlantısı Alma
  result = api_instance.quick_carts_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling QuickCartApi->quick_carts_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **String**| Hızlı Satın Al Bağlantısı adı | [optional] 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **quick_carts_id_delete**
> quick_carts_id_delete(id)

Hızlı Satın Al Bağlantısı Silme

Kalıcı olarak ilgili Hızlı Satın Al Bağlantısını siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::QuickCartApi.new

id = 56 # Integer | Hızlı Satın Al nesnesinin id değeri


begin
  #Hızlı Satın Al Bağlantısı Silme
  api_instance.quick_carts_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling QuickCartApi->quick_carts_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Hızlı Satın Al nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **quick_carts_id_get**
> QuickCart quick_carts_id_get(id)

Hızlı Satın Al Bağlantısı Alma

İlgili Hızlı Satın Al Bağlantısını getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::QuickCartApi.new

id = 56 # Integer | Hızlı Satın Al nesnesinin id değeri


begin
  #Hızlı Satın Al Bağlantısı Alma
  result = api_instance.quick_carts_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling QuickCartApi->quick_carts_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Hızlı Satın Al nesnesinin id değeri | 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **quick_carts_id_put**
> QuickCart quick_carts_id_put(id, quick_cart)

Hızlı Satın Al Bağlantısı Güncelleme

İlgili Hızlı Satın Al Bağlantısını günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::QuickCartApi.new

id = 56 # Integer | Hızlı Satın Al nesnesinin id değeri

quick_cart = SwaggerClient::QuickCart.new # QuickCart |  nesnesi


begin
  #Hızlı Satın Al Bağlantısı Güncelleme
  result = api_instance.quick_carts_id_put(id, quick_cart)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling QuickCartApi->quick_carts_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Hızlı Satın Al nesnesinin id değeri | 
 **quick_cart** | [**QuickCart**](QuickCart.md)|  nesnesi | 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **quick_carts_post**
> QuickCart quick_carts_post(quick_cart)

Hızlı Satın Al Bağlantısı Oluşturma

Yeni bir Hızlı Satın Al Bağlantısı oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::QuickCartApi.new

quick_cart = SwaggerClient::QuickCart.new # QuickCart |  nesnesi


begin
  #Hızlı Satın Al Bağlantısı Oluşturma
  result = api_instance.quick_carts_post(quick_cart)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling QuickCartApi->quick_carts_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **quick_cart** | [**QuickCart**](QuickCart.md)|  nesnesi | 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



