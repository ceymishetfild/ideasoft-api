# SwaggerClient::OrderUserNote

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sipariş yönetici notu nesnesi kimlik değeri. | [optional] 
**user_email** | **String** | Yöneticinin(admin) e-mail adresi. | 
**user_firstname** | **String** | Yöneticinin(admin) ismi. | [optional] 
**user_surname** | **String** | Yöneticinin(admin) soy ismi. | [optional] 
**note** | **String** | Yöneticinin(admin) sipariş için girdiği not. | 
**created_at** | **DateTime** | Sipariş yönetici notu nesnesinin oluşturulma zamanı. | 
**updated_at** | **DateTime** | Sipariş yönetici notu nesnesinin güncellenme zamanı. | 
**order** | [**Order**](Order.md) | Sipariş nesnesi. | 


