# SwaggerClient::CartItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sepet kalemi nesnesi kimlik değeri. | [optional] 
**parent_product_id** | **Integer** | Ana ürünün benzersiz rakamsal kimlik değeri. | [optional] 
**quantity** | **Float** | Sepetteki kalem adedi. | 
**category_id** | **Integer** | Sepetteki kaleme ait kategorinin benzersiz kimlik değeri. | [optional] 
**created_at** | **DateTime** | Sepet kalemi nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Sepet kalemi nesnesinin güncellenme zamanı. | [optional] 
**cart** | [**Cart**](Cart.md) |  | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 
**attributes** | [**Array&lt;CartItemAttribute&gt;**](CartItemAttribute.md) | Sepet kalemi özelliği barındıran liste. | [optional] 


