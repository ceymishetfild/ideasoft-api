# SwaggerClient::BillingAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sipariş adresi nesnesi kimlik değeri. | [optional] 
**firstname** | **String** | Müşterinin ismi. | 
**surname** | **String** | Müşterinin soy ismi. | 
**country** | **String** | Müşterinin ülke bilgisi. | 
**location** | **String** | Müşterinin şehir bilgisi. | 
**sub_location** | **String** | Müşterinin ilçe bilgisi. | [optional] 
**address** | **String** | Müşterinin adres bilgisi. | 
**phone_number** | **String** | Müşterinin telefon numarası. | 
**mobile_phone_number** | **String** | Müşterinin mobil telefon numarası. | [optional] 
**order** | [**Order**](Order.md) | Sipariş nesnesi. | [optional] 


