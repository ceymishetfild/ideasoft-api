# SwaggerClient::ExtraInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extra_infos_get**](ExtraInfoApi.md#extra_infos_get) | **GET** /extra_infos | Ek Bilgi Listesi Alma
[**extra_infos_id_delete**](ExtraInfoApi.md#extra_infos_id_delete) | **DELETE** /extra_infos/{id} | Ek Bilgi Silme
[**extra_infos_id_get**](ExtraInfoApi.md#extra_infos_id_get) | **GET** /extra_infos/{id} | Ek Bilgi Alma
[**extra_infos_id_put**](ExtraInfoApi.md#extra_infos_id_put) | **PUT** /extra_infos/{id} | Ek Bilgi Güncelleme
[**extra_infos_post**](ExtraInfoApi.md#extra_infos_post) | **POST** /extra_infos | Ek Bilgi Oluşturma


# **extra_infos_get**
> ExtraInfo extra_infos_get(opts)

Ek Bilgi Listesi Alma

Ek Bilgi listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ExtraInfoApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  name: "name_example" # String | Ek Bilgi adı
}

begin
  #Ek Bilgi Listesi Alma
  result = api_instance.extra_infos_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ExtraInfoApi->extra_infos_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **String**| Ek Bilgi adı | [optional] 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **extra_infos_id_delete**
> extra_infos_id_delete(id)

Ek Bilgi Silme

Kalıcı olarak ilgili Ek Bilgiyi siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ExtraInfoApi.new

id = 56 # Integer | Ek Bilgi nesnesinin id değeri


begin
  #Ek Bilgi Silme
  api_instance.extra_infos_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ExtraInfoApi->extra_infos_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Bilgi nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **extra_infos_id_get**
> ExtraInfo extra_infos_id_get(id)

Ek Bilgi Alma

İlgili Ek Bilgiyi getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ExtraInfoApi.new

id = 56 # Integer | Ek Bilgi nesnesinin id değeri


begin
  #Ek Bilgi Alma
  result = api_instance.extra_infos_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ExtraInfoApi->extra_infos_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Bilgi nesnesinin id değeri | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **extra_infos_id_put**
> ExtraInfo extra_infos_id_put(id, extra_info)

Ek Bilgi Güncelleme

İlgili Ek Bilgiyi günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ExtraInfoApi.new

id = 56 # Integer | Ek Bilgi nesnesinin id değeri

extra_info = SwaggerClient::ExtraInfo.new # ExtraInfo | ExtraInfo nesnesi


begin
  #Ek Bilgi Güncelleme
  result = api_instance.extra_infos_id_put(id, extra_info)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ExtraInfoApi->extra_infos_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Bilgi nesnesinin id değeri | 
 **extra_info** | [**ExtraInfo**](ExtraInfo.md)| ExtraInfo nesnesi | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **extra_infos_post**
> ExtraInfo extra_infos_post(extra_info)

Ek Bilgi Oluşturma

Yeni bir Ek Bilgi oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ExtraInfoApi.new

extra_info = SwaggerClient::ExtraInfo.new # ExtraInfo | ExtraInfo nesnesi


begin
  #Ek Bilgi Oluşturma
  result = api_instance.extra_infos_post(extra_info)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ExtraInfoApi->extra_infos_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extra_info** | [**ExtraInfo**](ExtraInfo.md)| ExtraInfo nesnesi | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



