# SwaggerClient::LocationApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**locations_get**](LocationApi.md#locations_get) | **GET** /locations | Şehir Listesi Alma
[**locations_id_get**](LocationApi.md#locations_id_get) | **GET** /locations/{id} | Şehir Alma


# **locations_get**
> Location locations_get(opts)

Şehir Listesi Alma

Şehir listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::LocationApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  name: "name_example", # String | Şehir adı
  country: 56, # Integer | Ülke id
  region: 56 # Integer | Bölge id
}

begin
  #Şehir Listesi Alma
  result = api_instance.locations_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling LocationApi->locations_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **String**| Şehir adı | [optional] 
 **country** | **Integer**| Ülke id | [optional] 
 **region** | **Integer**| Bölge id | [optional] 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **locations_id_get**
> Location locations_id_get(id)

Şehir Alma

İlgili Şehir getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::LocationApi.new

id = 56 # Integer | Şehir nesnesinin id değeri


begin
  #Şehir Alma
  result = api_instance.locations_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling LocationApi->locations_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Şehir nesnesinin id değeri | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



