# SwaggerClient::MemberAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**member_addresses_get**](MemberAddressApi.md#member_addresses_get) | **GET** /member_addresses | Üye Adresi Listeleme
[**member_addresses_id_delete**](MemberAddressApi.md#member_addresses_id_delete) | **DELETE** /member_addresses/{id} | Üye Adresi Silme
[**member_addresses_id_get**](MemberAddressApi.md#member_addresses_id_get) | **GET** /member_addresses/{id} | Üye Adresi Alma
[**member_addresses_id_put**](MemberAddressApi.md#member_addresses_id_put) | **PUT** /member_addresses/{id} | Üye Adresi Güncelleme
[**member_addresses_post**](MemberAddressApi.md#member_addresses_post) | **POST** /member_addresses | Üye Adresi Oluşturma


# **member_addresses_get**
> MemberAddress member_addresses_get(opts)

Üye Adresi Listeleme

Üye Adresi listesi verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberAddressApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
  member: 56, # Integer | Üye id
  start_date: Date.parse("2013-10-20"), # Date | createdAt değeri için başlangıç tarihi
  end_date: "end_date_example" # String | createdAt değeri için bitiş tarihi
}

begin
  #Üye Adresi Listeleme
  result = api_instance.member_addresses_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberAddressApi->member_addresses_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional] 
 **member** | **Integer**| Üye id | [optional] 
 **start_date** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **String**| createdAt değeri için bitiş tarihi | [optional] 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **member_addresses_id_delete**
> member_addresses_id_delete(id)

Üye Adresi Silme

Kalıcı olarak ilgili Üye Adresini siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberAddressApi.new

id = 56 # Integer | Üye Adresi nesnesinin id değeri


begin
  #Üye Adresi Silme
  api_instance.member_addresses_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberAddressApi->member_addresses_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye Adresi nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **member_addresses_id_get**
> MemberAddress member_addresses_id_get(id)

Üye Adresi Alma

İlgili Üye Adresini getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberAddressApi.new

id = 56 # Integer | Üye Adresi nesnesinin id değeri


begin
  #Üye Adresi Alma
  result = api_instance.member_addresses_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberAddressApi->member_addresses_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye Adresi nesnesinin id değeri | 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **member_addresses_id_put**
> MemberAddress member_addresses_id_put(id, member_address)

Üye Adresi Güncelleme

İlgili Üye Adresini günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberAddressApi.new

id = 56 # Integer | Üye Adresi nesnesinin id değeri

member_address = SwaggerClient::MemberAddress.new # MemberAddress | MemberAddress nesnesi


begin
  #Üye Adresi Güncelleme
  result = api_instance.member_addresses_id_put(id, member_address)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberAddressApi->member_addresses_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye Adresi nesnesinin id değeri | 
 **member_address** | [**MemberAddress**](MemberAddress.md)| MemberAddress nesnesi | 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **member_addresses_post**
> MemberAddress member_addresses_post(member_address)

Üye Adresi Oluşturma

Yeni bir Üye Adresi oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberAddressApi.new

member_address = SwaggerClient::MemberAddress.new # MemberAddress | MemberAddress nesnesi


begin
  #Üye Adresi Oluşturma
  result = api_instance.member_addresses_post(member_address)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberAddressApi->member_addresses_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member_address** | [**MemberAddress**](MemberAddress.md)| MemberAddress nesnesi | 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



