# SwaggerClient::OptionsApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**options_get**](OptionsApi.md#options_get) | **GET** /options | Varyant Listesi Alma
[**options_id_delete**](OptionsApi.md#options_id_delete) | **DELETE** /options/{id} | Varyant Silme
[**options_id_get**](OptionsApi.md#options_id_get) | **GET** /options/{id} | Varyant Alma
[**options_id_put**](OptionsApi.md#options_id_put) | **PUT** /options/{id} | Varyant Güncelleme
[**options_post**](OptionsApi.md#options_post) | **POST** /options | Varyant Oluşturma


# **options_get**
> Options options_get(opts)

Varyant Listesi Alma

Varyant listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OptionsApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  title: "title_example", # String | Varyant başlığı
  option_group: 56 # Integer | Varyant Grubu id
}

begin
  #Varyant Listesi Alma
  result = api_instance.options_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OptionsApi->options_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **title** | **String**| Varyant başlığı | [optional] 
 **option_group** | **Integer**| Varyant Grubu id | [optional] 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **options_id_delete**
> options_id_delete(id)

Varyant Silme

Kalıcı olarak ilgili Varyantı siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OptionsApi.new

id = 56 # Integer | Varyant nesnesinin id değeri


begin
  #Varyant Silme
  api_instance.options_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OptionsApi->options_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **options_id_get**
> Options options_id_get(id)

Varyant Alma

İlgili Varyantı getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OptionsApi.new

id = 56 # Integer | Varyant nesnesinin id değeri


begin
  #Varyant Alma
  result = api_instance.options_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OptionsApi->options_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant nesnesinin id değeri | 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **options_id_put**
> Options options_id_put(id, options)

Varyant Güncelleme

İlgili Varyantı günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OptionsApi.new

id = 56 # Integer | Varyant nesnesinin id değeri

options = SwaggerClient::Options.new # Options | Options nesnesi


begin
  #Varyant Güncelleme
  result = api_instance.options_id_put(id, options)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OptionsApi->options_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant nesnesinin id değeri | 
 **options** | [**Options**](Options.md)| Options nesnesi | 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **options_post**
> Options options_post(options)

Varyant Oluşturma

Yeni bir Varyant oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OptionsApi.new

options = SwaggerClient::Options.new # Options | Options nesnesi


begin
  #Varyant Oluşturma
  result = api_instance.options_post(options)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OptionsApi->options_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **options** | [**Options**](Options.md)| Options nesnesi | 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



