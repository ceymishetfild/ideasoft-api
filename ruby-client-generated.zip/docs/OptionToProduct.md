# SwaggerClient::OptionToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Varyant ürün bağı nesnesi kimlik değeri. | [optional] 
**parent_product_id** | **Integer** | Ana ürünün benzersiz kimlik değeri. | 
**option_group** | [**OptionGroup**](OptionGroup.md) |  | [optional] 
**option** | [**Options**](Options.md) |  | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 


