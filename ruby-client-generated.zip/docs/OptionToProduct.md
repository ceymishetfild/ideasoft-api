# SwaggerClient::OptionToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Varyant ürün bağı nesnesi kimlik değeri. | [optional] 
**parent_product_id** | **Integer** | Ana ürünün benzersiz kimlik değeri. | 
**option_group** | [**OptionGroup**](OptionGroup.md) | Varyant grubu nesnesi. | 
**option** | [**Options**](Options.md) | Varyant nesnesi. | 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 


