# SwaggerClient::PaymentGatewaySetting

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ödeme kanalı ayarı nesnesi kimlik değeri. | [optional] 
**var_key** | **String** | Ödeme kanalı ayarı nesnesi için değişken anahtarı. | 
**var_value** | **String** | Ödeme kanalı ayarı nesnesi için değişken değeri. | 
**payment_gateway** | [**PaymentGateway**](PaymentGateway.md) |  | [optional] 


