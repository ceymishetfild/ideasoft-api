# SwaggerClient::OrderUserNoteApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**order_user_notes_get**](OrderUserNoteApi.md#order_user_notes_get) | **GET** /order_user_notes | Sipariş Yönetici Notu Listesi Alma
[**order_user_notes_id_delete**](OrderUserNoteApi.md#order_user_notes_id_delete) | **DELETE** /order_user_notes/{id} | Sipariş Yönetici Notu Silme
[**order_user_notes_id_get**](OrderUserNoteApi.md#order_user_notes_id_get) | **GET** /order_user_notes/{id} | Sipariş Yönetici Notu Alma
[**order_user_notes_id_put**](OrderUserNoteApi.md#order_user_notes_id_put) | **PUT** /order_user_notes/{id} | Sipariş Yönetici Notu Güncelleme
[**order_user_notes_post**](OrderUserNoteApi.md#order_user_notes_post) | **POST** /order_user_notes | Sipariş Yönetici Notu Oluşturma


# **order_user_notes_get**
> OrderUserNote order_user_notes_get(opts)

Sipariş Yönetici Notu Listesi Alma

Sipariş Yönetici Notu listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderUserNoteApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  order: 56, # Integer | Sipariş id
  user_email: "user_email_example", # String | Yönetici e-mail
  start_date: Date.parse("2013-10-20"), # Date | createdAt değeri için başlangıç tarihi
  end_date: "end_date_example", # String | createdAt değeri için bitiş tarihi
  start_updated_at: Date.parse("2013-10-20"), # Date | updatedAt değeri için başlangıç tarihi
  end_updated_at: "end_updated_at_example" # String | updatedAt değeri için bitiş tarihi
}

begin
  #Sipariş Yönetici Notu Listesi Alma
  result = api_instance.order_user_notes_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderUserNoteApi->order_user_notes_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **order** | **Integer**| Sipariş id | [optional] 
 **user_email** | **String**| Yönetici e-mail | [optional] 
 **start_date** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **order_user_notes_id_delete**
> order_user_notes_id_delete(id)

Sipariş Yönetici Notu Silme

Kalıcı olarak ilgili Sipariş Yönetici Notunu siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderUserNoteApi.new

id = 56 # Integer | Sipariş Yönetici Notu nesnesinin id değeri


begin
  #Sipariş Yönetici Notu Silme
  api_instance.order_user_notes_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderUserNoteApi->order_user_notes_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Yönetici Notu nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **order_user_notes_id_get**
> OrderUserNote order_user_notes_id_get(id)

Sipariş Yönetici Notu Alma

İlgili Sipariş Yönetici Notunu getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderUserNoteApi.new

id = 56 # Integer | Sipariş Yönetici Notu nesnesinin id değeri


begin
  #Sipariş Yönetici Notu Alma
  result = api_instance.order_user_notes_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderUserNoteApi->order_user_notes_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Yönetici Notu nesnesinin id değeri | 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **order_user_notes_id_put**
> OrderUserNote order_user_notes_id_put(id, order_user_note)

Sipariş Yönetici Notu Güncelleme

İlgili Sipariş Yönetici Notunu günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderUserNoteApi.new

id = 56 # Integer | Sipariş Yönetici Notu nesnesinin id değeri

order_user_note = SwaggerClient::OrderUserNote.new # OrderUserNote |  nesnesi


begin
  #Sipariş Yönetici Notu Güncelleme
  result = api_instance.order_user_notes_id_put(id, order_user_note)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderUserNoteApi->order_user_notes_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Yönetici Notu nesnesinin id değeri | 
 **order_user_note** | [**OrderUserNote**](OrderUserNote.md)|  nesnesi | 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **order_user_notes_post**
> OrderUserNote order_user_notes_post(order_user_note)

Sipariş Yönetici Notu Oluşturma

Yeni bir Sipariş Yönetici Notu oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderUserNoteApi.new

order_user_note = SwaggerClient::OrderUserNote.new # OrderUserNote |  nesnesi


begin
  #Sipariş Yönetici Notu Oluşturma
  result = api_instance.order_user_notes_post(order_user_note)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderUserNoteApi->order_user_notes_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_user_note** | [**OrderUserNote**](OrderUserNote.md)|  nesnesi | 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



