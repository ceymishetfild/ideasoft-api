# SwaggerClient::SelectionToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ek özellik ürün bağı nesnesi kimlik değeri. | [optional] 
**selection** | [**Selection**](Selection.md) | Ek özellik nesnesi. | 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 


