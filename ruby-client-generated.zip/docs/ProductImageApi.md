# SwaggerClient::ProductImageApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_images_get**](ProductImageApi.md#product_images_get) | **GET** /product_images | Ürün Resim Listesi Alma
[**product_images_id_delete**](ProductImageApi.md#product_images_id_delete) | **DELETE** /product_images/{id} | Ürün Resim Silme
[**product_images_id_get**](ProductImageApi.md#product_images_id_get) | **GET** /product_images/{id} | Ürün Resim Alma
[**product_images_post**](ProductImageApi.md#product_images_post) | **POST** /product_images | Ürün Resim Oluşturma


# **product_images_get**
> ProductImage product_images_get(opts)

Ürün Resim Listesi Alma

Ürün Resim listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductImageApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  file_name: "file_name_example", # String | Ürün Resim dosya adı
  product: 56 # Integer | Ürün id
}

begin
  #Ürün Resim Listesi Alma
  result = api_instance.product_images_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductImageApi->product_images_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **file_name** | **String**| Ürün Resim dosya adı | [optional] 
 **product** | **Integer**| Ürün id | [optional] 

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_images_id_delete**
> product_images_id_delete(id)

Ürün Resim Silme

Kalıcı olarak ilgili Ürün Resmini siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductImageApi.new

id = 56 # Integer | Ürün Resmi nesnesinin id değeri


begin
  #Ürün Resim Silme
  api_instance.product_images_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductImageApi->product_images_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Resmi nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_images_id_get**
> ProductImage product_images_id_get(id)

Ürün Resim Alma

İlgili Ürün Resmini getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductImageApi.new

id = 56 # Integer | Ürün Resmi nesnesinin id değeri


begin
  #Ürün Resim Alma
  result = api_instance.product_images_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductImageApi->product_images_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Resmi nesnesinin id değeri | 

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_images_post**
> ProductImage product_images_post(product_image)

Ürün Resim Oluşturma

Yeni bir Ürün Resim oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductImageApi.new

product_image = SwaggerClient::ProductImage.new # ProductImage | ProductImage nesnesi


begin
  #Ürün Resim Oluşturma
  result = api_instance.product_images_post(product_image)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductImageApi->product_images_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_image** | [**ProductImage**](ProductImage.md)| ProductImage nesnesi | 

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



