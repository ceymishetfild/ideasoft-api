# SwaggerClient::ProductCommentApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_comments_get**](ProductCommentApi.md#product_comments_get) | **GET** /product_comments | Ürün Yorumları Listesi Alma
[**product_comments_id_delete**](ProductCommentApi.md#product_comments_id_delete) | **DELETE** /product_comments/{id} | Ürün Yorumu Silme
[**product_comments_id_get**](ProductCommentApi.md#product_comments_id_get) | **GET** /product_comments/{id} | Ürün Yorumu Alma
[**product_comments_id_put**](ProductCommentApi.md#product_comments_id_put) | **PUT** /product_comments/{id} | Ürün Yorumu Güncelleme
[**product_comments_post**](ProductCommentApi.md#product_comments_post) | **POST** /product_comments | Ürün Yorumu Oluşturma


# **product_comments_get**
> ProductComment product_comments_get(opts)

Ürün Yorumları Listesi Alma

Ürün Yorumları listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductCommentApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
  status: "status_example", # String | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
  is_anonymous: "is_anonymous_example", # String | IsAnonymous şu değerleri alabilir: <br><code>0</code> : Anonim değil<br><code>1</code> : Anonim
  member: 56, # Integer | Üye id
  product: 56, # Integer | Ürün id
  start_date: Date.parse("2013-10-20"), # Date | createdAt değeri için başlangıç tarihi
  end_date: "end_date_example", # String | createdAt değeri için bitiş tarihi
  start_updated_at: Date.parse("2013-10-20"), # Date | updatedAt değeri için başlangıç tarihi
  end_updated_at: "end_updated_at_example" # String | updatedAt değeri için bitiş tarihi
}

begin
  #Ürün Yorumları Listesi Alma
  result = api_instance.product_comments_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductCommentApi->product_comments_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional] 
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **is_anonymous** | **String**| IsAnonymous şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Anonim değil&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Anonim | [optional] 
 **member** | **Integer**| Üye id | [optional] 
 **product** | **Integer**| Ürün id | [optional] 
 **start_date** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_comments_id_delete**
> product_comments_id_delete(id)

Ürün Yorumu Silme

Kalıcı olarak ilgili Ürün Yorumunu siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductCommentApi.new

id = 56 # Integer | Ürün Yorumu nesnesinin id değeri


begin
  #Ürün Yorumu Silme
  api_instance.product_comments_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductCommentApi->product_comments_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Yorumu nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_comments_id_get**
> ProductComment product_comments_id_get(id)

Ürün Yorumu Alma

İlgili Ürün Yorumunu getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductCommentApi.new

id = 56 # Integer | Ürün Yorumu nesnesinin id değeri


begin
  #Ürün Yorumu Alma
  result = api_instance.product_comments_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductCommentApi->product_comments_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Yorumu nesnesinin id değeri | 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_comments_id_put**
> ProductComment product_comments_id_put(id, product_comment)

Ürün Yorumu Güncelleme

İlgili Ürün Yorumunu günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductCommentApi.new

id = 56 # Integer | Ürün Yorumu nesnesinin id değeri

product_comment = SwaggerClient::ProductComment.new # ProductComment |  nesnesi


begin
  #Ürün Yorumu Güncelleme
  result = api_instance.product_comments_id_put(id, product_comment)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductCommentApi->product_comments_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Yorumu nesnesinin id değeri | 
 **product_comment** | [**ProductComment**](ProductComment.md)|  nesnesi | 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_comments_post**
> ProductComment product_comments_post(product_comment)

Ürün Yorumu Oluşturma

Yeni bir Ürün Yorumu oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductCommentApi.new

product_comment = SwaggerClient::ProductComment.new # ProductComment |  nesnesi


begin
  #Ürün Yorumu Oluşturma
  result = api_instance.product_comments_post(product_comment)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductCommentApi->product_comments_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_comment** | [**ProductComment**](ProductComment.md)|  nesnesi | 

### Return type

[**ProductComment**](ProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



