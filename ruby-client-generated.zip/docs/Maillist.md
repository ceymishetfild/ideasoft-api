# SwaggerClient::Maillist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Mail listesi nesnesi kimlik değeri. | [optional] 
**name** | **String** | Mail listesi nesnesi için isim değeri. | 
**email** | **String** | Ziyaretçi veya üyenin mail adresi. | 
**last_mail_sent_date** | **DateTime** | En son e-mail gönderilen zaman. | [optional] 
**creator_ip_address** | **String** | Mail listesi nesnesini oluşturan kişinin IP adresi. | [optional] 
**created_at** | **DateTime** | Mail listesi nesnesinin oluşturulma zamanı. | 
**updated_at** | **DateTime** | Mail listesi nesnesinin güncellenme zamanı. | 
**maillist_group** | [**MaillistGroup**](MaillistGroup.md) |  | [optional] 


