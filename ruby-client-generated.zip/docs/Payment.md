# SwaggerClient::Payment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ödeme nesnesi kimlik değeri. | [optional] 
**member_firstname** | **String** | Üyenin ismi. | 
**member_surname** | **String** | Üyenin soy ismi. | 
**member_email** | **String** | Üyenin e-mail adresi. | 
**member_phone** | **String** | Üyenin telefon numarası. | [optional] 
**payment_type_name** | **String** | Ödeme tipi | 
**payment_provider_code** | **String** | Ödeme hizmeti sağlayıcısı kodu. Bu değer ön tanımlıdır. | 
**payment_provider_name** | **String** | Ödeme hizmeti sağlayıcısı adı. Bu değer ön tanımlıdır. | 
**payment_gateway_name** | **String** | Ödeme kanalı adı. Bu değer ön tanımlıdır. | 
**payment_gateway_code** | **String** | Ödeme kanalı kodu. Bu değer ön tanımlıdır. | 
**bank_name** | **String** | Ödeme yapılan banka. Bu değer ön tanımlıdır. | [optional] 
**device_type** | **String** | Ödemenin gerçekleştiği cihaz bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil&lt;br&gt;&lt;code&gt;tablet&lt;/code&gt; : Tablet&lt;br&gt;&lt;/div&gt; | 
**client_ip** | **String** | Müşterinin IP adresi. | 
**currency_rates** | **String** | Kur oranları. | 
**amount** | **Float** | Ödemenin saf fiyatı. | 
**final_amount** | **Float** | Ödemenin son fiyatı. | 
**sum_of_gained_points** | **Float** | Ödemeden kazanılan toplam puan. | [optional] 
**installment** | **Integer** | Ödemenin standart taksit sayısı. | 
**installment_rate** | **Float** | Ödemenin taksit oranı. | 
**extra_installment** | **Integer** | Ödemenin ekstra taksit sayısı. | [optional] 
**currency** | **String** | Kur bilgisi. | 
**transaction_id** | **String** | Siparişin numarası. | [optional] 
**member_note** | **String** | Müşterinin ödeme notu. | [optional] 
**user_note** | **String** | Yönetici(admin) ödeme notu. | [optional] 
**status** | **String** | Ödeme durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;/div&gt; | 
**error_message** | **String** | Ödemenin hata mesajı. | [optional] 
**card_saving_system** | **String** | Kart saklama sistemi. | [optional] 
**created_at** | **DateTime** | Ödeme nesnesinin oluşturulma zamanı. | [optional] 
**member** | [**Member**](Member.md) | Üye nesnesi. | [optional] 


