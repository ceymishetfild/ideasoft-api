# SwaggerClient::SpecGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**spec_groups_get**](SpecGroupApi.md#spec_groups_get) | **GET** /spec_groups | Ürün Özellik Grubu Listesi Alma
[**spec_groups_id_delete**](SpecGroupApi.md#spec_groups_id_delete) | **DELETE** /spec_groups/{id} | Ürün Özellik Grubu Silme
[**spec_groups_id_get**](SpecGroupApi.md#spec_groups_id_get) | **GET** /spec_groups/{id} | Ürün Özellik Grubu Alma
[**spec_groups_id_put**](SpecGroupApi.md#spec_groups_id_put) | **PUT** /spec_groups/{id} | Ürün Özellik Grubu Güncelleme
[**spec_groups_post**](SpecGroupApi.md#spec_groups_post) | **POST** /spec_groups | Ürün Özellik Grubu Oluşturma


# **spec_groups_get**
> SpecGroup spec_groups_get(opts)

Ürün Özellik Grubu Listesi Alma

Ürün Özellik Grubu listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SpecGroupApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  name: "name_example" # String | Ürün Özellik Grubu adı
}

begin
  #Ürün Özellik Grubu Listesi Alma
  result = api_instance.spec_groups_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SpecGroupApi->spec_groups_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **String**| Ürün Özellik Grubu adı | [optional] 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **spec_groups_id_delete**
> spec_groups_id_delete(id)

Ürün Özellik Grubu Silme

Kalıcı olarak ilgili Ürün Özellik Grubunu siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SpecGroupApi.new

id = 56 # Integer | Ürün Özellik Grubu nesnesinin id değeri


begin
  #Ürün Özellik Grubu Silme
  api_instance.spec_groups_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SpecGroupApi->spec_groups_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Grubu nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **spec_groups_id_get**
> SpecGroup spec_groups_id_get(id)

Ürün Özellik Grubu Alma

İlgili Ürün Özellik Grubunu getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SpecGroupApi.new

id = 56 # Integer | Ürün Özellik Grubu nesnesinin id değeri


begin
  #Ürün Özellik Grubu Alma
  result = api_instance.spec_groups_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SpecGroupApi->spec_groups_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Grubu nesnesinin id değeri | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **spec_groups_id_put**
> SpecGroup spec_groups_id_put(id, spec_group)

Ürün Özellik Grubu Güncelleme

İlgili Ürün Özellik Grubunu günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SpecGroupApi.new

id = 56 # Integer | Ürün Özellik Grubu nesnesinin id değeri

spec_group = SwaggerClient::SpecGroup.new # SpecGroup |  nesnesi


begin
  #Ürün Özellik Grubu Güncelleme
  result = api_instance.spec_groups_id_put(id, spec_group)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SpecGroupApi->spec_groups_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Grubu nesnesinin id değeri | 
 **spec_group** | [**SpecGroup**](SpecGroup.md)|  nesnesi | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **spec_groups_post**
> SpecGroup spec_groups_post(spec_group)

Ürün Özellik Grubu Oluşturma

Yeni bir Ürün Özellik Grubu oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SpecGroupApi.new

spec_group = SwaggerClient::SpecGroup.new # SpecGroup |  nesnesi


begin
  #Ürün Özellik Grubu Oluşturma
  result = api_instance.spec_groups_post(spec_group)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SpecGroupApi->spec_groups_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **spec_group** | [**SpecGroup**](SpecGroup.md)|  nesnesi | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



