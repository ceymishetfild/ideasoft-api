# SwaggerClient::ShippingAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipping_addresses_get**](ShippingAddressApi.md#shipping_addresses_get) | **GET** /shipping_addresses | Teslimat Adresi Listesi Alma
[**shipping_addresses_id_get**](ShippingAddressApi.md#shipping_addresses_id_get) | **GET** /shipping_addresses/{id} | Teslimat Adresi Alma
[**shipping_addresses_id_put**](ShippingAddressApi.md#shipping_addresses_id_put) | **PUT** /shipping_addresses/{id} | Teslimat Adresi Güncelleme
[**shipping_addresses_post**](ShippingAddressApi.md#shipping_addresses_post) | **POST** /shipping_addresses | Teslimat Adresi Oluşturma


# **shipping_addresses_get**
> ShippingAddress shipping_addresses_get(opts)

Teslimat Adresi Listesi Alma

Teslimat Adresi listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingAddressApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  order: 56, # Integer | Sipariş id
  start_date: Date.parse("2013-10-20"), # Date | createdAt değeri için başlangıç tarihi
  end_date: "end_date_example", # String | createdAt değeri için bitiş tarihi
  start_updated_at: Date.parse("2013-10-20"), # Date | updatedAt değeri için başlangıç tarihi
  end_updated_at: "end_updated_at_example" # String | updatedAt değeri için bitiş tarihi
}

begin
  #Teslimat Adresi Listesi Alma
  result = api_instance.shipping_addresses_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingAddressApi->shipping_addresses_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **order** | **Integer**| Sipariş id | [optional] 
 **start_date** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipping_addresses_id_get**
> ShippingAddress shipping_addresses_id_get(id)

Teslimat Adresi Alma

İlgili Teslimat Adresi getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingAddressApi.new

id = 56 # Integer | Teslimat Adresi nesnesinin id değeri


begin
  #Teslimat Adresi Alma
  result = api_instance.shipping_addresses_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingAddressApi->shipping_addresses_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Teslimat Adresi nesnesinin id değeri | 

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipping_addresses_id_put**
> ShippingAddress shipping_addresses_id_put(id, shipping_address)

Teslimat Adresi Güncelleme

İlgili Teslimat Adresi günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingAddressApi.new

id = 56 # Integer | Teslimat Adresi nesnesinin id değeri

shipping_address = SwaggerClient::ShippingAddress.new # ShippingAddress |  nesnesi


begin
  #Teslimat Adresi Güncelleme
  result = api_instance.shipping_addresses_id_put(id, shipping_address)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingAddressApi->shipping_addresses_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Teslimat Adresi nesnesinin id değeri | 
 **shipping_address** | [**ShippingAddress**](ShippingAddress.md)|  nesnesi | 

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipping_addresses_post**
> ShippingAddress shipping_addresses_post(shipping_address)

Teslimat Adresi Oluşturma

Yeni bir Teslimat Adresi oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingAddressApi.new

shipping_address = SwaggerClient::ShippingAddress.new # ShippingAddress |  nesnesi


begin
  #Teslimat Adresi Oluşturma
  result = api_instance.shipping_addresses_post(shipping_address)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingAddressApi->shipping_addresses_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipping_address** | [**ShippingAddress**](ShippingAddress.md)|  nesnesi | 

### Return type

[**ShippingAddress**](ShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



