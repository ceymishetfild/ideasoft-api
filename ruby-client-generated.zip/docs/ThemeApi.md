# SwaggerClient::ThemeApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**themes_get**](ThemeApi.md#themes_get) | **GET** /themes | Tema Listesi Alma
[**themes_id_assets_get**](ThemeApi.md#themes_id_assets_get) | **GET** /themes/{id}/assets | Tema Dosyası Listesi Alma
[**themes_id_assetskeykey_delete**](ThemeApi.md#themes_id_assetskeykey_delete) | **DELETE** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Silme
[**themes_id_assetskeykey_get**](ThemeApi.md#themes_id_assetskeykey_get) | **GET** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Alma
[**themes_id_assetskeykey_put**](ThemeApi.md#themes_id_assetskeykey_put) | **PUT** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Güncelleme
[**themes_id_delete**](ThemeApi.md#themes_id_delete) | **DELETE** /themes/{id} | Tema Silme
[**themes_id_get**](ThemeApi.md#themes_id_get) | **GET** /themes/{id} | Tema Alma
[**themes_id_put**](ThemeApi.md#themes_id_put) | **PUT** /themes/{id} | Tema Güncelleme
[**themes_post**](ThemeApi.md#themes_post) | **POST** /themes | Tema Oluşturma


# **themes_get**
> Theme themes_get(opts)

Tema Listesi Alma

Tema listesi verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ThemeApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
  status: 56, # Integer | Tema durumu
  platform: "platform_example", # String | Tema platformu
  type: "type_example" # String | Tema tipi
}

begin
  #Tema Listesi Alma
  result = api_instance.themes_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ThemeApi->themes_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional] 
 **status** | **Integer**| Tema durumu | [optional] 
 **platform** | **String**| Tema platformu | [optional] 
 **type** | **String**| Tema tipi | [optional] 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **themes_id_assets_get**
> Asset themes_id_assets_get(id, opts)

Tema Dosyası Listesi Alma

Tema Dosyası listesi verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ThemeApi.new

id = 56 # Integer | Tema nesnesinin id değeri

opts = { 
  key: "key_example" # String | Tema Dosyası nesnesi anahtar değeri.
}

begin
  #Tema Dosyası Listesi Alma
  result = api_instance.themes_id_assets_get(id, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ThemeApi->themes_id_assets_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tema nesnesinin id değeri | 
 **key** | **String**| Tema Dosyası nesnesi anahtar değeri. | [optional] 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **themes_id_assetskeykey_delete**
> themes_id_assetskeykey_delete(id, key)

Tema Dosyası Silme

Kalıcı olarak ilgili Tema Dosyasını siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ThemeApi.new

id = 56 # Integer | Tema nesnesinin id değeri

key = "key_example" # String | Tema Dosyası nesnesi anahtar değeri.


begin
  #Tema Dosyası Silme
  api_instance.themes_id_assetskeykey_delete(id, key)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ThemeApi->themes_id_assetskeykey_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tema nesnesinin id değeri | 
 **key** | **String**| Tema Dosyası nesnesi anahtar değeri. | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **themes_id_assetskeykey_get**
> Asset themes_id_assetskeykey_get(id, key)

Tema Dosyası Alma

İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ThemeApi.new

id = 56 # Integer | Tema nesnesinin id değeri

key = "key_example" # String | Tema Dosyası nesnesi anahtar değeri.


begin
  #Tema Dosyası Alma
  result = api_instance.themes_id_assetskeykey_get(id, key)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ThemeApi->themes_id_assetskeykey_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tema nesnesinin id değeri | 
 **key** | **String**| Tema Dosyası nesnesi anahtar değeri. | 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **themes_id_assetskeykey_put**
> Asset themes_id_assetskeykey_put(id, theme, asset)

Tema Dosyası Güncelleme

Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ThemeApi.new

id = 56 # Integer | Tema nesnesinin id değeri

theme = SwaggerClient::Theme.new # Theme | Theme nesnesi

asset = SwaggerClient::Asset.new # Asset | Asset nesnesi


begin
  #Tema Dosyası Güncelleme
  result = api_instance.themes_id_assetskeykey_put(id, theme, asset)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ThemeApi->themes_id_assetskeykey_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tema nesnesinin id değeri | 
 **theme** | [**Theme**](Theme.md)| Theme nesnesi | 
 **asset** | [**Asset**](Asset.md)| Asset nesnesi | 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **themes_id_delete**
> themes_id_delete(id)

Tema Silme

Kalıcı olarak ilgili Temayı siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ThemeApi.new

id = 56 # Integer | Tema nesnesinin id değeri


begin
  #Tema Silme
  api_instance.themes_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ThemeApi->themes_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tema nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **themes_id_get**
> Theme themes_id_get(id)

Tema Alma

İlgili Temayı getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ThemeApi.new

id = 56 # Integer | Tema nesnesinin id değeri


begin
  #Tema Alma
  result = api_instance.themes_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ThemeApi->themes_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tema nesnesinin id değeri | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **themes_id_put**
> Theme themes_id_put(id, theme)

Tema Güncelleme

İlgili Temayı günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ThemeApi.new

id = 56 # Integer | Tema nesnesinin id değeri

theme = SwaggerClient::Theme.new # Theme | Theme nesnesi


begin
  #Tema Güncelleme
  result = api_instance.themes_id_put(id, theme)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ThemeApi->themes_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tema nesnesinin id değeri | 
 **theme** | [**Theme**](Theme.md)| Theme nesnesi | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **themes_post**
> Theme themes_post(theme)

Tema Oluşturma

Yeni bir tema oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ThemeApi.new

theme = SwaggerClient::Theme.new # Theme | Theme nesnesi


begin
  #Tema Oluşturma
  result = api_instance.themes_post(theme)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ThemeApi->themes_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **theme** | [**Theme**](Theme.md)| Theme nesnesi | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



