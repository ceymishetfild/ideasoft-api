# SwaggerClient::ShippingProviderSetting

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Teslimat hizmeti sağlayıcısı ayarı nesnesi kimlik değeri. | [optional] 
**var_key** | **String** | Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken anahtarı. | 
**var_value** | **String** | Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken değeri. | 
**shipping_provider** | [**ShippingProvider**](ShippingProvider.md) |  | [optional] 


