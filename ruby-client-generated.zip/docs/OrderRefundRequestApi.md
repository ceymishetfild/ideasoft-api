# SwaggerClient::OrderRefundRequestApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**order_refund_requests_get**](OrderRefundRequestApi.md#order_refund_requests_get) | **GET** /order_refund_requests | Sipariş İptal Talebi Listesi Alma
[**order_refund_requests_id_delete**](OrderRefundRequestApi.md#order_refund_requests_id_delete) | **DELETE** /order_refund_requests/{id} | Sipariş İptal Talebi Silme
[**order_refund_requests_id_get**](OrderRefundRequestApi.md#order_refund_requests_id_get) | **GET** /order_refund_requests/{id} | Sipariş İptal Talebi Alma
[**order_refund_requests_id_put**](OrderRefundRequestApi.md#order_refund_requests_id_put) | **PUT** /order_refund_requests/{id} | Sipariş İptal Talebi Güncelleme
[**order_refund_requests_post**](OrderRefundRequestApi.md#order_refund_requests_post) | **POST** /order_refund_requests | Sipariş İptal Talebi Oluşturma


# **order_refund_requests_get**
> OrderRefundRequest order_refund_requests_get(opts)

Sipariş İptal Talebi Listesi Alma

Sipariş İptal Talebi listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderRefundRequestApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  order: 56, # Integer | Sipariş id
  member: 56, # Integer | Üye id
  code: "code_example", # String | Sipariş İptal Talebi kodu
  status: "status_example", # String | Status şu değerleri alabilir: <br><code>waiting_for_approval</code> : Onay bekliyor<br><code>approved</code> : Onaylandı<br><code>cancelled</code> : İptal edildi
  start_date: Date.parse("2013-10-20"), # Date | createdAt değeri için başlangıç tarihi
  end_date: "end_date_example", # String | createdAt değeri için bitiş tarihi
  start_updated_at: Date.parse("2013-10-20"), # Date | updatedAt değeri için başlangıç tarihi
  end_updated_at: "end_updated_at_example" # String | updatedAt değeri için bitiş tarihi
}

begin
  #Sipariş İptal Talebi Listesi Alma
  result = api_instance.order_refund_requests_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderRefundRequestApi->order_refund_requests_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **Integer**| Sipariş id | [optional] 
 **member** | **Integer**| Üye id | [optional] 
 **code** | **String**| Sipariş İptal Talebi kodu | [optional] 
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi | [optional] 
 **start_date** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **order_refund_requests_id_delete**
> order_refund_requests_id_delete(id)

Sipariş İptal Talebi Silme

Kalıcı olarak ilgili Sipariş İptal Talebini siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderRefundRequestApi.new

id = 56 # Integer | Sipariş İptal Talebi nesnesinin id değeri


begin
  #Sipariş İptal Talebi Silme
  api_instance.order_refund_requests_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderRefundRequestApi->order_refund_requests_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş İptal Talebi nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **order_refund_requests_id_get**
> OrderRefundRequest order_refund_requests_id_get(id)

Sipariş İptal Talebi Alma

İlgili Sipariş İptal Talebini getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderRefundRequestApi.new

id = 56 # Integer | Sipariş İptal Talebi nesnesinin id değeri


begin
  #Sipariş İptal Talebi Alma
  result = api_instance.order_refund_requests_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderRefundRequestApi->order_refund_requests_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş İptal Talebi nesnesinin id değeri | 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **order_refund_requests_id_put**
> OrderRefundRequest order_refund_requests_id_put(id, order_refund_request)

Sipariş İptal Talebi Güncelleme

İlgili Sipariş İptal Talebini günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderRefundRequestApi.new

id = 56 # Integer | Sipariş İptal Talebi nesnesinin id değeri

order_refund_request = SwaggerClient::OrderRefundRequest.new # OrderRefundRequest | OrderRefundRequest nesnesi


begin
  #Sipariş İptal Talebi Güncelleme
  result = api_instance.order_refund_requests_id_put(id, order_refund_request)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderRefundRequestApi->order_refund_requests_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş İptal Talebi nesnesinin id değeri | 
 **order_refund_request** | [**OrderRefundRequest**](OrderRefundRequest.md)| OrderRefundRequest nesnesi | 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **order_refund_requests_post**
> OrderRefundRequest order_refund_requests_post(order_refund_request)

Sipariş İptal Talebi Oluşturma

Yeni bir Sipariş İptal Talebi oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderRefundRequestApi.new

order_refund_request = SwaggerClient::OrderRefundRequest.new # OrderRefundRequest | OrderRefundRequest nesnesi


begin
  #Sipariş İptal Talebi Oluşturma
  result = api_instance.order_refund_requests_post(order_refund_request)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderRefundRequestApi->order_refund_requests_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_refund_request** | [**OrderRefundRequest**](OrderRefundRequest.md)| OrderRefundRequest nesnesi | 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



