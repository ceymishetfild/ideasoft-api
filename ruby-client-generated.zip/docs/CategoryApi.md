# SwaggerClient::CategoryApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**categories_get**](CategoryApi.md#categories_get) | **GET** /categories | Kategori Listesi Alma
[**categories_id_delete**](CategoryApi.md#categories_id_delete) | **DELETE** /categories/{id} | Kategori Silme
[**categories_id_get**](CategoryApi.md#categories_id_get) | **GET** /categories/{id} | Kategori Alma
[**categories_id_put**](CategoryApi.md#categories_id_put) | **PUT** /categories/{id} | Kategori Güncelleme
[**categories_post**](CategoryApi.md#categories_post) | **POST** /categories | Kategori Oluşturma


# **categories_get**
> Category categories_get(opts)

Kategori Listesi Alma

Kategori listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CategoryApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  name: "name_example", # String | Kategori adı
  status: "status_example", # String | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
  distributor: "distributor_example", # String | Kategori Distribütör
  parent: 56, # Integer | Üst kategori id
  start_date: Date.parse("2013-10-20"), # Date | createdAt değeri için başlangıç tarihi
  end_date: "end_date_example", # String | createdAt değeri için bitiş tarihi
  start_updated_at: Date.parse("2013-10-20"), # Date | updatedAt değeri için başlangıç tarihi
  end_updated_at: "end_updated_at_example" # String | updatedAt değeri için bitiş tarihi
}

begin
  #Kategori Listesi Alma
  result = api_instance.categories_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CategoryApi->categories_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **String**| Kategori adı | [optional] 
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **distributor** | **String**| Kategori Distribütör | [optional] 
 **parent** | **Integer**| Üst kategori id | [optional] 
 **start_date** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Category**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **categories_id_delete**
> categories_id_delete(id)

Kategori Silme

Kalıcı olarak ilgili Kategoriyi siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CategoryApi.new

id = 56 # Integer | Kategori nesnesinin id değeri


begin
  #Kategori Silme
  api_instance.categories_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CategoryApi->categories_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kategori nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **categories_id_get**
> Category categories_id_get(id)

Kategori Alma

İlgili Kategoriyi getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CategoryApi.new

id = 56 # Integer | Kategori nesnesinin id değeri


begin
  #Kategori Alma
  result = api_instance.categories_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CategoryApi->categories_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kategori nesnesinin id değeri | 

### Return type

[**Category**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **categories_id_put**
> Category categories_id_put(id, category)

Kategori Güncelleme

İlgili Kategoriyi günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CategoryApi.new

id = 56 # Integer | Kategori nesnesinin id değeri

category = SwaggerClient::Category.new # Category |  nesnesi


begin
  #Kategori Güncelleme
  result = api_instance.categories_id_put(id, category)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CategoryApi->categories_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kategori nesnesinin id değeri | 
 **category** | [**Category**](Category.md)|  nesnesi | 

### Return type

[**Category**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **categories_post**
> Category categories_post(category)

Kategori Oluşturma

Yeni bir Kategori oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CategoryApi.new

category = SwaggerClient::Category.new # Category |  nesnesi


begin
  #Kategori Oluşturma
  result = api_instance.categories_post(category)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CategoryApi->categories_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **category** | [**Category**](Category.md)|  nesnesi | 

### Return type

[**Category**](Category.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



