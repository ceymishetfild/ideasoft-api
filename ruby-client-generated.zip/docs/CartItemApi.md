# SwaggerClient::CartItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cart_items_id_delete**](CartItemApi.md#cart_items_id_delete) | **DELETE** /cart_items/{id} | Sepet Kalemi Silme
[**cart_items_id_put**](CartItemApi.md#cart_items_id_put) | **PUT** /cart_items/{id} | Sepet Kalemi Güncelleme
[**cart_items_post**](CartItemApi.md#cart_items_post) | **POST** /cart_items | Sepet Kalemi Oluşturma


# **cart_items_id_delete**
> cart_items_id_delete(id)

Sepet Kalemi Silme

Kalıcı olarak ilgili Sepet Kalemini siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CartItemApi.new

id = 56 # Integer | Sepet Kalemi nesnesinin id değeri


begin
  #Sepet Kalemi Silme
  api_instance.cart_items_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CartItemApi->cart_items_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sepet Kalemi nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **cart_items_id_put**
> CartItem cart_items_id_put(id)

Sepet Kalemi Güncelleme

İlgili Sepet Kalemini günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CartItemApi.new

id = 56 # Integer | Sepet Kalemi nesnesinin id değeri


begin
  #Sepet Kalemi Güncelleme
  result = api_instance.cart_items_id_put(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CartItemApi->cart_items_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sepet Kalemi nesnesinin id değeri | 

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **cart_items_post**
> CartItem cart_items_post(cart_item)

Sepet Kalemi Oluşturma

Yeni bir Sepet Kalemi oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CartItemApi.new

cart_item = SwaggerClient::CartItem.new # CartItem | CartItem nesnesi


begin
  #Sepet Kalemi Oluşturma
  result = api_instance.cart_items_post(cart_item)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CartItemApi->cart_items_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_item** | [**CartItem**](CartItem.md)| CartItem nesnesi | 

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



