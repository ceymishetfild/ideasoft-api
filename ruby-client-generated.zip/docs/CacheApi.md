# SwaggerClient::CacheApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cache_delete**](CacheApi.md#cache_delete) | **DELETE** /cache | Önbellek Silme


# **cache_delete**
> cache_delete

Önbellek Silme

Kalıcı olarak Önbelleği siler.

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::CacheApi.new

begin
  #Önbellek Silme
  api_instance.cache_delete
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CacheApi->cache_delete: #{e}"
end
```

### Parameters
This endpoint does not need any parameter.

### Return type

nil (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



