# SwaggerClient::ProductButtonApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_buttons_get**](ProductButtonApi.md#product_buttons_get) | **GET** /product_buttons | Ürün ve Stok Butonu Listesi Alma
[**product_buttons_id_delete**](ProductButtonApi.md#product_buttons_id_delete) | **DELETE** /product_buttons/{id} | Ürün ve Stok Butonu Silme
[**product_buttons_id_get**](ProductButtonApi.md#product_buttons_id_get) | **GET** /product_buttons/{id} | Ürün ve Stok Butonu Alma
[**product_buttons_id_put**](ProductButtonApi.md#product_buttons_id_put) | **PUT** /product_buttons/{id} | Ürün ve Stok Butonu Güncelleme
[**product_buttons_post**](ProductButtonApi.md#product_buttons_post) | **POST** /product_buttons | Ürün ve Stok Butonu Oluşturma


# **product_buttons_get**
> ProductButton product_buttons_get(opts)

Ürün ve Stok Butonu Listesi Alma

Ürün ve Stok Butonu listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductButtonApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  fast_shipping: 56, # Integer | Hızlı Gönderi butonuna sahip ürünler<code>0</code><br><code>1</code>
  same_day_shipping: 56, # Integer | Aynı Gün Kargo butonuna sahip ürünler<code>0</code><br><code>1</code>
  three_days_delivery: 56, # Integer | 3 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
  five_days_delivery: 56, # Integer | 5 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
  seven_days_delivery: 56, # Integer | 7 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code>
  free_shipping: 56, # Integer | Kargo Bedava butonuna sahip ürünler<code>0</code><br><code>1</code>
  delivery_from_stock: 56, # Integer | Stoktan Teslim butonuna sahip ürünler<code>0</code><br><code>1</code>
  pre_ordered_product: 56, # Integer | Ön Siparişli Ürün butonuna sahip ürünler<code>0</code><br><code>1</code>
  ask_stock: 56, # Integer | Stok Sorunuz butonuna sahip ürünler<code>0</code><br><code>1</code>
  campaigned_product: 56, # Integer | Kampanyalı Ürün butonuna sahip ürünler<code>0</code><br><code>1</code>
  product: 56 # Integer | Ürün id
}

begin
  #Ürün ve Stok Butonu Listesi Alma
  result = api_instance.product_buttons_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductButtonApi->product_buttons_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **fast_shipping** | **Integer**| Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **same_day_shipping** | **Integer**| Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **three_days_delivery** | **Integer**| 3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **five_days_delivery** | **Integer**| 5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **seven_days_delivery** | **Integer**| 7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **free_shipping** | **Integer**| Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **delivery_from_stock** | **Integer**| Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **pre_ordered_product** | **Integer**| Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **ask_stock** | **Integer**| Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **campaigned_product** | **Integer**| Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **product** | **Integer**| Ürün id | [optional] 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_buttons_id_delete**
> product_buttons_id_delete(id)

Ürün ve Stok Butonu Silme

Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductButtonApi.new

id = 56 # Integer | Ürün ve Stok Butonu nesnesinin id değeri


begin
  #Ürün ve Stok Butonu Silme
  api_instance.product_buttons_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductButtonApi->product_buttons_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_buttons_id_get**
> ProductButton product_buttons_id_get(id)

Ürün ve Stok Butonu Alma

İlgili Ürün ve Stok Butonunu getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductButtonApi.new

id = 56 # Integer | Ürün ve Stok Butonu nesnesinin id değeri


begin
  #Ürün ve Stok Butonu Alma
  result = api_instance.product_buttons_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductButtonApi->product_buttons_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_buttons_id_put**
> ProductButton product_buttons_id_put(id, product_button)

Ürün ve Stok Butonu Güncelleme

İlgili Ürün ve Stok Butonunu günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductButtonApi.new

id = 56 # Integer | Ürün ve Stok Butonu nesnesinin id değeri

product_button = SwaggerClient::ProductButton.new # ProductButton | ProductButton nesnesi


begin
  #Ürün ve Stok Butonu Güncelleme
  result = api_instance.product_buttons_id_put(id, product_button)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductButtonApi->product_buttons_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün ve Stok Butonu nesnesinin id değeri | 
 **product_button** | [**ProductButton**](ProductButton.md)| ProductButton nesnesi | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_buttons_post**
> ProductButton product_buttons_post(product_button)

Ürün ve Stok Butonu Oluşturma

Yeni bir Ürün ve Stok Butonu oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductButtonApi.new

product_button = SwaggerClient::ProductButton.new # ProductButton | ProductButton nesnesi


begin
  #Ürün ve Stok Butonu Oluşturma
  result = api_instance.product_buttons_post(product_button)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductButtonApi->product_buttons_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_button** | [**ProductButton**](ProductButton.md)| ProductButton nesnesi | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



