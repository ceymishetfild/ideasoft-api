# SwaggerClient::SelectionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selection_groups_get**](SelectionGroupApi.md#selection_groups_get) | **GET** /selection_groups | Ek Özellik Grubu Listesi Alma
[**selection_groups_id_delete**](SelectionGroupApi.md#selection_groups_id_delete) | **DELETE** /selection_groups/{id} | Ek Özellik Grubu Silme
[**selection_groups_id_get**](SelectionGroupApi.md#selection_groups_id_get) | **GET** /selection_groups/{id} | Ek Özellik Grubu Alma
[**selection_groups_id_put**](SelectionGroupApi.md#selection_groups_id_put) | **PUT** /selection_groups/{id} | Ek Özellik Grubu Güncelleme
[**selection_groups_post**](SelectionGroupApi.md#selection_groups_post) | **POST** /selection_groups | Ek Özellik Grubu Oluşturma


# **selection_groups_get**
> SelectionGroup selection_groups_get(opts)

Ek Özellik Grubu Listesi Alma

Ek Özellik Grubu listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SelectionGroupApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  title: "title_example" # String | Ek Özellik Grubu başlığı
}

begin
  #Ek Özellik Grubu Listesi Alma
  result = api_instance.selection_groups_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SelectionGroupApi->selection_groups_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **title** | **String**| Ek Özellik Grubu başlığı | [optional] 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **selection_groups_id_delete**
> selection_groups_id_delete(id)

Ek Özellik Grubu Silme

Kalıcı olarak ilgili Ek Özellik Grubunu siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SelectionGroupApi.new

id = 56 # Integer | Ek Özellik Grubu nesnesinin id değeri


begin
  #Ek Özellik Grubu Silme
  api_instance.selection_groups_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SelectionGroupApi->selection_groups_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Özellik Grubu nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **selection_groups_id_get**
> SelectionGroup selection_groups_id_get(id)

Ek Özellik Grubu Alma

İlgili Ek Özellik Grubunu getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SelectionGroupApi.new

id = 56 # Integer | Ek Özellik Grubu nesnesinin id değeri


begin
  #Ek Özellik Grubu Alma
  result = api_instance.selection_groups_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SelectionGroupApi->selection_groups_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Özellik Grubu nesnesinin id değeri | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **selection_groups_id_put**
> SelectionGroup selection_groups_id_put(id, selection_group)

Ek Özellik Grubu Güncelleme

İlgili Ek Özellik Grubunu günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SelectionGroupApi.new

id = 56 # Integer | Ek Özellik Grubu nesnesinin id değeri

selection_group = SwaggerClient::SelectionGroup.new # SelectionGroup | SelectionGroup nesnesi


begin
  #Ek Özellik Grubu Güncelleme
  result = api_instance.selection_groups_id_put(id, selection_group)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SelectionGroupApi->selection_groups_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Özellik Grubu nesnesinin id değeri | 
 **selection_group** | [**SelectionGroup**](SelectionGroup.md)| SelectionGroup nesnesi | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **selection_groups_post**
> SelectionGroup selection_groups_post(selection_group)

Ek Özellik Grubu Oluşturma

Yeni bir Ek Özellik Grubu oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SelectionGroupApi.new

selection_group = SwaggerClient::SelectionGroup.new # SelectionGroup | SelectionGroup nesnesi


begin
  #Ek Özellik Grubu Oluşturma
  result = api_instance.selection_groups_post(selection_group)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SelectionGroupApi->selection_groups_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selection_group** | [**SelectionGroup**](SelectionGroup.md)| SelectionGroup nesnesi | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



