# SwaggerClient::OrderDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sipariş detayı nesnesi kimlik değeri. | [optional] 
**var_key** | **String** | Sipariş detayı nesnesi için değişken anahtarı. | 
**var_value** | **String** | Sipariş detayı nesnesi için değişken değeri. | 
**order** | [**Order**](Order.md) |  | [optional] 


