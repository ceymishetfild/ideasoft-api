# SwaggerClient::Distributor

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Distributor nesnesi kimlik değeri. | [optional] 
**name** | **String** | Distributor nesnesi için isim değeri. | 
**email** | **String** | E-mail adresi. | [optional] 
**phone** | **String** | Telefon numarası. | [optional] 
**contact_person** | **String** | İletişim kişisi. | [optional] 


