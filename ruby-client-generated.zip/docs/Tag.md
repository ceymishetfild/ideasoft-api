# SwaggerClient::Tag

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | SEO+ etiketi nesnesi kimlik değeri. | [optional] 
**name** | **String** | SEO+ etiketi nesnesi için isim değeri. | 
**count** | **Integer** | SEO+ etiketinin kaç kez kullanıldığı bilgisi. | [optional] 
**page_title** | **String** | SEO+ etiketi nesnesinin etiket başlığı. | [optional] 
**meta_description** | **String** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] 
**meta_keywords** | **String** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] 


