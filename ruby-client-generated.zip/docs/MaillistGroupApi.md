# SwaggerClient::MaillistGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**maillist_groups_get**](MaillistGroupApi.md#maillist_groups_get) | **GET** /maillist_groups | Mail Listesi Grubu Listesi Alma
[**maillist_groups_id_delete**](MaillistGroupApi.md#maillist_groups_id_delete) | **DELETE** /maillist_groups/{id} | Mail Listesi Grubu Silme
[**maillist_groups_id_get**](MaillistGroupApi.md#maillist_groups_id_get) | **GET** /maillist_groups/{id} | Mail Listesi Grubu Alma
[**maillist_groups_id_put**](MaillistGroupApi.md#maillist_groups_id_put) | **PUT** /maillist_groups/{id} | Mail Listesi Grubu Güncelleme
[**maillist_groups_post**](MaillistGroupApi.md#maillist_groups_post) | **POST** /maillist_groups | Mail Listesi Grubu Oluşturma


# **maillist_groups_get**
> MaillistGroup maillist_groups_get(opts)

Mail Listesi Grubu Listesi Alma

Mail Listesi Grubu listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MaillistGroupApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  name: "name_example" # String | Mail Listesi Grubu adı
}

begin
  #Mail Listesi Grubu Listesi Alma
  result = api_instance.maillist_groups_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MaillistGroupApi->maillist_groups_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **String**| Mail Listesi Grubu adı | [optional] 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **maillist_groups_id_delete**
> maillist_groups_id_delete(id)

Mail Listesi Grubu Silme

Kalıcı olarak ilgili Mail Listesi Grubunu siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MaillistGroupApi.new

id = 56 # Integer | Mail Listesi Grubu nesnesinin id değeri


begin
  #Mail Listesi Grubu Silme
  api_instance.maillist_groups_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MaillistGroupApi->maillist_groups_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Mail Listesi Grubu nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **maillist_groups_id_get**
> MaillistGroup maillist_groups_id_get(id)

Mail Listesi Grubu Alma

İlgili Mail Listesi Grubunu getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MaillistGroupApi.new

id = 56 # Integer | Mail Listesi Grubu nesnesinin id değeri


begin
  #Mail Listesi Grubu Alma
  result = api_instance.maillist_groups_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MaillistGroupApi->maillist_groups_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Mail Listesi Grubu nesnesinin id değeri | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **maillist_groups_id_put**
> MaillistGroup maillist_groups_id_put(id, maillist_group)

Mail Listesi Grubu Güncelleme

İlgili Mail Listesi Grubunu günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MaillistGroupApi.new

id = 56 # Integer | Mail Listesi Grubu nesnesinin id değeri

maillist_group = SwaggerClient::MaillistGroup.new # MaillistGroup |  nesnesi


begin
  #Mail Listesi Grubu Güncelleme
  result = api_instance.maillist_groups_id_put(id, maillist_group)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MaillistGroupApi->maillist_groups_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Mail Listesi Grubu nesnesinin id değeri | 
 **maillist_group** | [**MaillistGroup**](MaillistGroup.md)|  nesnesi | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **maillist_groups_post**
> MaillistGroup maillist_groups_post(maillist_group)

Mail Listesi Grubu Oluşturma

Yeni bir Mail Listesi Grubu oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MaillistGroupApi.new

maillist_group = SwaggerClient::MaillistGroup.new # MaillistGroup |  nesnesi


begin
  #Mail Listesi Grubu Oluşturma
  result = api_instance.maillist_groups_post(maillist_group)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MaillistGroupApi->maillist_groups_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **maillist_group** | [**MaillistGroup**](MaillistGroup.md)|  nesnesi | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



