# SwaggerClient::ExtraInfoToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ek bilgi ürün bağı nesnesi kimlik değeri. | [optional] 
**value** | **String** | Ek bilgi ürün bağı değeridir. Ek bilgi renk ise bu değer kırmızı olabilir. | 
**extra_info** | [**ExtraInfo**](ExtraInfo.md) |  | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 


