# SwaggerClient::MemberAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Üye adresi nesnesinin benzersiz rakamsal kimlik değeri. | [optional] 
**name** | **String** | Üye Adresi adı. | [optional] 
**type** | **String** | Üye Adresi tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;shipping&lt;/code&gt; : Teslimat adresi.&lt;br&gt;&lt;code&gt;billing&lt;/code&gt; : Fatura adresi.&lt;br&gt;&lt;/div&gt; | [optional] 
**firstname** | **String** | Üyenin ismi. | [optional] 
**surname** | **String** | Üyenin soy ismi. | [optional] 
**address** | **String** | Üyenin adres bilgileri. | [optional] 
**sub_location_name** | **String** | İlçe adı. | [optional] 
**phone_number** | **String** | Üyenin telefon numarası. | [optional] 
**mobile_phone_number** | **String** | Üyenin mobil telefon numarası. | [optional] 
**tc_id** | **String** | Üyenin TC kimlik numarası. | [optional] 
**tax_number** | **String** | Üyenin vergi numarası. | [optional] 
**tax_office** | **String** | Üyenin vergi dairesi. | [optional] 
**invoice_type** | **String** | Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt; | [optional] 
**is_einvoice_user** | **BOOLEAN** | Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] 
**created_at** | **DateTime** | Tema nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Tema nesnesinin güncellenme zamanı. | [optional] 
**member** | [**Member**](Member.md) | Üye nesnesi | [optional] 
**country** | [**Country**](Country.md) | Ülke nesnesi. | [optional] 
**location** | [**Location**](Location.md) | Şehir nesnesi. | [optional] 
**sub_location** | [**Town**](Town.md) | İlçe nesnesi. | [optional] 


