# SwaggerClient::Region

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Bölge nesnesi kimlik değeri. | [optional] 
**name** | **String** | Bölge nesnesi için isim değeri. | 


