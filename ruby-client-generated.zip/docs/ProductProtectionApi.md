# SwaggerClient::ProductProtectionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_protections_get**](ProductProtectionApi.md#product_protections_get) | **GET** /product_protections | Entegrasyon Seçeneği Listesi Alma
[**product_protections_id_delete**](ProductProtectionApi.md#product_protections_id_delete) | **DELETE** /product_protections/{id} | Entegrasyon Seçeneği Silme
[**product_protections_id_get**](ProductProtectionApi.md#product_protections_id_get) | **GET** /product_protections/{id} | Entegrasyon Seçeneği Alma
[**product_protections_id_put**](ProductProtectionApi.md#product_protections_id_put) | **PUT** /product_protections/{id} | Entegrasyon Seçeneği Güncelleme
[**product_protections_post**](ProductProtectionApi.md#product_protections_post) | **POST** /product_protections | Entegrasyon Seçeneği Oluşturma


# **product_protections_get**
> ProductProtection product_protections_get(opts)

Entegrasyon Seçeneği Listesi Alma

Entegrasyon Seçeneği listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductProtectionApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  is_price_protected: "is_price_protected_example", # String | Fiyat korumalı ürünleri listeler<code>0</code><br><code>1</code>
  is_stock_protected: "is_stock_protected_example", # String | Stok korumalı ürünleri listeler<code>0</code><br><code>1</code>
  product: 56 # Integer | Ürün id
}

begin
  #Entegrasyon Seçeneği Listesi Alma
  result = api_instance.product_protections_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductProtectionApi->product_protections_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **is_price_protected** | **String**| Fiyat korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **is_stock_protected** | **String**| Stok korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **product** | **Integer**| Ürün id | [optional] 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_protections_id_delete**
> product_protections_id_delete(id)

Entegrasyon Seçeneği Silme

Kalıcı olarak ilgili Entegrasyon Seçeneğini siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductProtectionApi.new

id = 56 # Integer | Entegrasyon Seçeneği nesnesinin id değeri


begin
  #Entegrasyon Seçeneği Silme
  api_instance.product_protections_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductProtectionApi->product_protections_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Entegrasyon Seçeneği nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_protections_id_get**
> ProductProtection product_protections_id_get(id)

Entegrasyon Seçeneği Alma

İlgili Entegrasyon Seçeneğini getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductProtectionApi.new

id = 56 # Integer | Entegrasyon Seçeneği nesnesinin id değeri


begin
  #Entegrasyon Seçeneği Alma
  result = api_instance.product_protections_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductProtectionApi->product_protections_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Entegrasyon Seçeneği nesnesinin id değeri | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_protections_id_put**
> ProductProtection product_protections_id_put(id, product_protection)

Entegrasyon Seçeneği Güncelleme

İlgili Entegrasyon Seçeneğini günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductProtectionApi.new

id = 56 # Integer | Entegrasyon Seçeneği nesnesinin id değeri

product_protection = SwaggerClient::ProductProtection.new # ProductProtection |  nesnesi


begin
  #Entegrasyon Seçeneği Güncelleme
  result = api_instance.product_protections_id_put(id, product_protection)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductProtectionApi->product_protections_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Entegrasyon Seçeneği nesnesinin id değeri | 
 **product_protection** | [**ProductProtection**](ProductProtection.md)|  nesnesi | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_protections_post**
> ProductProtection product_protections_post(product_protection)

Entegrasyon Seçeneği Oluşturma

Yeni bir Entegrasyon Seçeneği oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductProtectionApi.new

product_protection = SwaggerClient::ProductProtection.new # ProductProtection |  nesnesi


begin
  #Entegrasyon Seçeneği Oluşturma
  result = api_instance.product_protections_post(product_protection)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductProtectionApi->product_protections_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_protection** | [**ProductProtection**](ProductProtection.md)|  nesnesi | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



