# SwaggerClient::ShopPreferenceApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**preferences_get**](ShopPreferenceApi.md#preferences_get) | **GET** /preferences | Tanımlamalar Listesi Alma
[**preferences_id_get**](ShopPreferenceApi.md#preferences_id_get) | **GET** /preferences/{id} | Tanımlamalar Alma
[**preferences_id_put**](ShopPreferenceApi.md#preferences_id_put) | **PUT** /preferences/{id} | Tanımlamalar Güncelleme


# **preferences_get**
> ShopPreference preferences_get(opts)

Tanımlamalar Listesi Alma

Tanımlamalar listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShopPreferenceApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 100, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  var_key: "var_key_example" # String | Tanımlama varKey değeri
}

begin
  #Tanımlamalar Listesi Alma
  result = api_instance.preferences_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShopPreferenceApi->preferences_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 100]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **var_key** | **String**| Tanımlama varKey değeri | [optional] 

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **preferences_id_get**
> ShopPreference preferences_id_get(id)

Tanımlamalar Alma

İlgili Tanımlamayı getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShopPreferenceApi.new

id = 56 # Integer | Tanımlama nesnesinin id değeri


begin
  #Tanımlamalar Alma
  result = api_instance.preferences_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShopPreferenceApi->preferences_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tanımlama nesnesinin id değeri | 

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **preferences_id_put**
> ShopPreference preferences_id_put(id, shop_preference)

Tanımlamalar Güncelleme

İlgili Tanımlamayı günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShopPreferenceApi.new

id = 56 # Integer | Tanımlama nesnesinin id değeri

shop_preference = SwaggerClient::ShopPreference.new # ShopPreference | ShopPreference nesnesi


begin
  #Tanımlamalar Güncelleme
  result = api_instance.preferences_id_put(id, shop_preference)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShopPreferenceApi->preferences_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Tanımlama nesnesinin id değeri | 
 **shop_preference** | [**ShopPreference**](ShopPreference.md)| ShopPreference nesnesi | 

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



