# SwaggerClient::Cart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sepet nesnesi kimlik değeri. | [optional] 
**session_id** | **String** | Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri. | 
**locked** | **String** | Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz. | [optional] 
**created_at** | **DateTime** | Sepet nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Sepet nesnesinin güncellenme zamanı. | [optional] 
**chosen_promotion** | [**ShopCampaigns**](ShopCampaigns.md) |  | [optional] 
**member** | [**Member**](Member.md) |  | [optional] 
**chosen_token** | [**ShopTokens**](ShopTokens.md) |  | [optional] 
**items** | [**Array&lt;CartItem&gt;**](CartItem.md) | Sepet kalemi nesnelerini barındıran liste. | [optional] 


