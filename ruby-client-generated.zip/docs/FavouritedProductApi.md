# SwaggerClient::FavouritedProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**favourited_products_get**](FavouritedProductApi.md#favourited_products_get) | **GET** /favourited_products | Favori Ürün Listesi Alma
[**favourited_products_id_delete**](FavouritedProductApi.md#favourited_products_id_delete) | **DELETE** /favourited_products/{id} | Favori Ürün Silme
[**favourited_products_id_get**](FavouritedProductApi.md#favourited_products_id_get) | **GET** /favourited_products/{id} | Favori Ürün Alma
[**favourited_products_id_put**](FavouritedProductApi.md#favourited_products_id_put) | **PUT** /favourited_products/{id} | Favori Ürün Güncelleme
[**favourited_products_post**](FavouritedProductApi.md#favourited_products_post) | **POST** /favourited_products | Favori Ürün Oluşturma


# **favourited_products_get**
> FavouritedProduct favourited_products_get(opts)

Favori Ürün Listesi Alma

Favori Ürün listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::FavouritedProductApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  product: 56 # Integer | Ürün id
}

begin
  #Favori Ürün Listesi Alma
  result = api_instance.favourited_products_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling FavouritedProductApi->favourited_products_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **product** | **Integer**| Ürün id | [optional] 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **favourited_products_id_delete**
> favourited_products_id_delete(id)

Favori Ürün Silme

Kalıcı olarak ilgili Favori Ürünü siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::FavouritedProductApi.new

id = 56 # Integer | Favori Ürün nesnesinin id değeri


begin
  #Favori Ürün Silme
  api_instance.favourited_products_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling FavouritedProductApi->favourited_products_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Favori Ürün nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **favourited_products_id_get**
> FavouritedProduct favourited_products_id_get(id)

Favori Ürün Alma

İlgili Favori Ürünü getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::FavouritedProductApi.new

id = 56 # Integer | Favori Ürün nesnesinin id değeri


begin
  #Favori Ürün Alma
  result = api_instance.favourited_products_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling FavouritedProductApi->favourited_products_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Favori Ürün nesnesinin id değeri | 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **favourited_products_id_put**
> FavouritedProduct favourited_products_id_put(id, favourited_product)

Favori Ürün Güncelleme

İlgili Favori Ürünü günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::FavouritedProductApi.new

id = 56 # Integer | Favori Ürün nesnesinin id değeri

favourited_product = SwaggerClient::FavouritedProduct.new # FavouritedProduct | FavouritedProduct nesnesi


begin
  #Favori Ürün Güncelleme
  result = api_instance.favourited_products_id_put(id, favourited_product)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling FavouritedProductApi->favourited_products_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Favori Ürün nesnesinin id değeri | 
 **favourited_product** | [**FavouritedProduct**](FavouritedProduct.md)| FavouritedProduct nesnesi | 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **favourited_products_post**
> FavouritedProduct favourited_products_post(favourited_product)

Favori Ürün Oluşturma

Yeni bir Favori Ürün oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::FavouritedProductApi.new

favourited_product = SwaggerClient::FavouritedProduct.new # FavouritedProduct | FavouritedProduct nesnesi


begin
  #Favori Ürün Oluşturma
  result = api_instance.favourited_products_post(favourited_product)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling FavouritedProductApi->favourited_products_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **favourited_product** | [**FavouritedProduct**](FavouritedProduct.md)| FavouritedProduct nesnesi | 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



