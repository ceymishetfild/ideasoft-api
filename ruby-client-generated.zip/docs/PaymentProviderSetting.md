# SwaggerClient::PaymentProviderSetting

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ödeme altyapısı sağlayıcısı ayarı nesnesi kimlik değeri. | [optional] 
**var_key** | **String** | Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken anahtarı. | 
**var_value** | **String** | Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken değeri. | 


