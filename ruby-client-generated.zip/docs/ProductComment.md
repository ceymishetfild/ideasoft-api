# SwaggerClient::ProductComment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ürün yorumu nesnesi kimlik değeri. | [optional] 
**title** | **String** | Ürün yorumu başlığı. | 
**content** | **String** | Ürün yorumu içeriği. | 
**status** | **BOOLEAN** | Ürün yorumu durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**rank** | **Integer** | Ürün yorumunda ürüne verilen puan.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 1 puan.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : 2 puan.&lt;br&gt;&lt;code&gt;3&lt;/code&gt; : 3 puan.&lt;br&gt;&lt;code&gt;4&lt;/code&gt; : 4 puan.&lt;br&gt;&lt;code&gt;5&lt;/code&gt; : 5 puan.&lt;br&gt;&lt;/div&gt; | 
**is_anonymous** | **BOOLEAN** | Ürün yorumu yapan kişinin anonim olup olmadığı bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Anonim.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Anonim değil.&lt;br&gt;&lt;/div&gt; | 
**created_at** | **DateTime** | Ürün yorumu nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Ürün yorumu nesnesinin güncellenme zamanı. | [optional] 
**member** | [**Member**](Member.md) | Yorumu yapan üye. | [optional] 
**product** | [**Product**](Product.md) | Yorum yapılan ürün. | [optional] 


