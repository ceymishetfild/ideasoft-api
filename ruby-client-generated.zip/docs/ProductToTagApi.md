# SwaggerClient::ProductToTagApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_to_tags_get**](ProductToTagApi.md#product_to_tags_get) | **GET** /product_to_tags | Ürün SEO+ Bağı Listesi Alma
[**product_to_tags_id_delete**](ProductToTagApi.md#product_to_tags_id_delete) | **DELETE** /product_to_tags/{id} | Ürün SEO+ Bağı Silme
[**product_to_tags_id_get**](ProductToTagApi.md#product_to_tags_id_get) | **GET** /product_to_tags/{id} | Ürün SEO+ Bağı Alma
[**product_to_tags_id_put**](ProductToTagApi.md#product_to_tags_id_put) | **PUT** /product_to_tags/{id} | Ürün SEO+ Bağı Güncelleme
[**product_to_tags_post**](ProductToTagApi.md#product_to_tags_post) | **POST** /product_to_tags | Ürün SEO+ Bağı Oluşturma


# **product_to_tags_get**
> ProductToTag product_to_tags_get(opts)

Ürün SEO+ Bağı Listesi Alma

Ürün SEO+ Bağı listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductToTagApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  product: 56, # Integer | Ürün id
  tag: 56 # Integer | Etiket id
}

begin
  #Ürün SEO+ Bağı Listesi Alma
  result = api_instance.product_to_tags_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductToTagApi->product_to_tags_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **product** | **Integer**| Ürün id | [optional] 
 **tag** | **Integer**| Etiket id | [optional] 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_to_tags_id_delete**
> product_to_tags_id_delete(id)

Ürün SEO+ Bağı Silme

Kalıcı olarak ilgili Ürün SEO+ Bağını siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductToTagApi.new

id = 56 # Integer | Ürün SEO+ nesnesinin id değeri


begin
  #Ürün SEO+ Bağı Silme
  api_instance.product_to_tags_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductToTagApi->product_to_tags_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün SEO+ nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_to_tags_id_get**
> ProductToTag product_to_tags_id_get(id)

Ürün SEO+ Bağı Alma

İlgili Ürün SEO+ Bağını getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductToTagApi.new

id = 56 # Integer | Ürün SEO+ nesnesinin id değeri


begin
  #Ürün SEO+ Bağı Alma
  result = api_instance.product_to_tags_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductToTagApi->product_to_tags_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün SEO+ nesnesinin id değeri | 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_to_tags_id_put**
> ProductToTag product_to_tags_id_put(id, product_to_tag)

Ürün SEO+ Bağı Güncelleme

İlgili Ürün SEO+ Bağını günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductToTagApi.new

id = 56 # Integer | Ürün SEO+ nesnesinin id değeri

product_to_tag = SwaggerClient::ProductToTag.new # ProductToTag | ProductToTag nesnesi


begin
  #Ürün SEO+ Bağı Güncelleme
  result = api_instance.product_to_tags_id_put(id, product_to_tag)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductToTagApi->product_to_tags_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün SEO+ nesnesinin id değeri | 
 **product_to_tag** | [**ProductToTag**](ProductToTag.md)| ProductToTag nesnesi | 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_to_tags_post**
> ProductToTag product_to_tags_post(product_to_tag)

Ürün SEO+ Bağı Oluşturma

Yeni bir Ürün SEO+ Bağı oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductToTagApi.new

product_to_tag = SwaggerClient::ProductToTag.new # ProductToTag | ProductToTag nesnesi


begin
  #Ürün SEO+ Bağı Oluşturma
  result = api_instance.product_to_tags_post(product_to_tag)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductToTagApi->product_to_tags_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_to_tag** | [**ProductToTag**](ProductToTag.md)| ProductToTag nesnesi | 

### Return type

[**ProductToTag**](ProductToTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



