# SwaggerClient::SpecToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**spec_to_products_get**](SpecToProductApi.md#spec_to_products_get) | **GET** /spec_to_products | Ürün Özellik Ürün Bağı Listesi Alma
[**spec_to_products_id_delete**](SpecToProductApi.md#spec_to_products_id_delete) | **DELETE** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Silme
[**spec_to_products_id_get**](SpecToProductApi.md#spec_to_products_id_get) | **GET** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Alma
[**spec_to_products_id_put**](SpecToProductApi.md#spec_to_products_id_put) | **PUT** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Güncelleme
[**spec_to_products_post**](SpecToProductApi.md#spec_to_products_post) | **POST** /spec_to_products | Ürün Özellik Ürün Bağı Oluşturma


# **spec_to_products_get**
> SpecToProduct spec_to_products_get(opts)

Ürün Özellik Ürün Bağı Listesi Alma

Ürün Özellik Ürün Bağı listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SpecToProductApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  product: 56, # Integer | Ürün id
  spec_group: 56, # Integer | Ürün özellik grubu id
  spec_name: 56, # Integer | Ürün özellik id
  spec_value: 56 # Integer | Ürün özellik değeri id
}

begin
  #Ürün Özellik Ürün Bağı Listesi Alma
  result = api_instance.spec_to_products_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SpecToProductApi->spec_to_products_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **product** | **Integer**| Ürün id | [optional] 
 **spec_group** | **Integer**| Ürün özellik grubu id | [optional] 
 **spec_name** | **Integer**| Ürün özellik id | [optional] 
 **spec_value** | **Integer**| Ürün özellik değeri id | [optional] 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **spec_to_products_id_delete**
> spec_to_products_id_delete(id)

Ürün Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SpecToProductApi.new

id = 56 # Integer | Ürün Özellik Ürün Bağı nesnesinin id değeri


begin
  #Ürün Özellik Ürün Bağı Silme
  api_instance.spec_to_products_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SpecToProductApi->spec_to_products_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **spec_to_products_id_get**
> SpecToProduct spec_to_products_id_get(id)

Ürün Özellik Ürün Bağı Alma

İlgili Ürün Özellik Ürün Bağını getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SpecToProductApi.new

id = 56 # Integer | Ürün Özellik Ürün Bağı nesnesinin id değeri


begin
  #Ürün Özellik Ürün Bağı Alma
  result = api_instance.spec_to_products_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SpecToProductApi->spec_to_products_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **spec_to_products_id_put**
> SpecToProduct spec_to_products_id_put(id, spec_to_product)

Ürün Özellik Ürün Bağı Güncelleme

İlgili Ürün Özellik Ürün Bağını günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SpecToProductApi.new

id = 56 # Integer | Ürün Özellik Ürün Bağı nesnesinin id değeri

spec_to_product = SwaggerClient::SpecToProduct.new # SpecToProduct |  nesnesi


begin
  #Ürün Özellik Ürün Bağı Güncelleme
  result = api_instance.spec_to_products_id_put(id, spec_to_product)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SpecToProductApi->spec_to_products_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 
 **spec_to_product** | [**SpecToProduct**](SpecToProduct.md)|  nesnesi | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **spec_to_products_post**
> SpecToProduct spec_to_products_post(spec_to_product)

Ürün Özellik Ürün Bağı Oluşturma

Yeni bir Ürün Özellik Ürün Bağı oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SpecToProductApi.new

spec_to_product = SwaggerClient::SpecToProduct.new # SpecToProduct |  nesnesi


begin
  #Ürün Özellik Ürün Bağı Oluşturma
  result = api_instance.spec_to_products_post(spec_to_product)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SpecToProductApi->spec_to_products_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **spec_to_product** | [**SpecToProduct**](SpecToProduct.md)|  nesnesi | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



