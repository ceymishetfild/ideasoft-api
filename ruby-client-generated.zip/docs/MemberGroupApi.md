# SwaggerClient::MemberGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**member_groups_get**](MemberGroupApi.md#member_groups_get) | **GET** /member_groups | Üye Grubu Listesi Alma
[**member_groups_id_delete**](MemberGroupApi.md#member_groups_id_delete) | **DELETE** /member_groups/{id} | Üye Grubu Silme
[**member_groups_id_get**](MemberGroupApi.md#member_groups_id_get) | **GET** /member_groups/{id} | Üye Grubu Alma
[**member_groups_id_put**](MemberGroupApi.md#member_groups_id_put) | **PUT** /member_groups/{id} | Üye Grubu Güncelleme
[**member_groups_post**](MemberGroupApi.md#member_groups_post) | **POST** /member_groups | Üye Grubu Oluşturma


# **member_groups_get**
> MemberGroup member_groups_get(opts)

Üye Grubu Listesi Alma

Üye Grubu listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberGroupApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  name: "name_example" # String | Üye Grubu adı
}

begin
  #Üye Grubu Listesi Alma
  result = api_instance.member_groups_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberGroupApi->member_groups_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **String**| Üye Grubu adı | [optional] 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **member_groups_id_delete**
> member_groups_id_delete(id)

Üye Grubu Silme

Kalıcı olarak ilgili Üye Grubunu siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberGroupApi.new

id = 56 # Integer | Üye Grubu nesnesinin id değeri


begin
  #Üye Grubu Silme
  api_instance.member_groups_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberGroupApi->member_groups_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye Grubu nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **member_groups_id_get**
> MemberGroup member_groups_id_get(id)

Üye Grubu Alma

İlgili Üye Grubunu getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberGroupApi.new

id = 56 # Integer | Üye Grubu nesnesinin id değeri


begin
  #Üye Grubu Alma
  result = api_instance.member_groups_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberGroupApi->member_groups_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye Grubu nesnesinin id değeri | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **member_groups_id_put**
> MemberGroup member_groups_id_put(id, member_group)

Üye Grubu Güncelleme

İlgili Üye Grubunu günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberGroupApi.new

id = 56 # Integer | Üye Grubu nesnesinin id değeri

member_group = SwaggerClient::MemberGroup.new # MemberGroup |  nesnesi


begin
  #Üye Grubu Güncelleme
  result = api_instance.member_groups_id_put(id, member_group)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberGroupApi->member_groups_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Üye Grubu nesnesinin id değeri | 
 **member_group** | [**MemberGroup**](MemberGroup.md)|  nesnesi | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **member_groups_post**
> MemberGroup member_groups_post(member_group)

Üye Grubu Oluşturma

Yeni bir Üye Grubu oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MemberGroupApi.new

member_group = SwaggerClient::MemberGroup.new # MemberGroup |  nesnesi


begin
  #Üye Grubu Oluşturma
  result = api_instance.member_groups_post(member_group)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MemberGroupApi->member_groups_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member_group** | [**MemberGroup**](MemberGroup.md)|  nesnesi | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



