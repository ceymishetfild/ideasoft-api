# SwaggerClient::TagApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**tags_get**](TagApi.md#tags_get) | **GET** /tags | SEO+ Etiketi Listesi Alma
[**tags_id_delete**](TagApi.md#tags_id_delete) | **DELETE** /tags/{id} | SEO+ Etiketi Silme
[**tags_id_get**](TagApi.md#tags_id_get) | **GET** /tags/{id} | SEO+ Etiketi Alma
[**tags_id_put**](TagApi.md#tags_id_put) | **PUT** /tags/{id} | SEO+ Etiketi Güncelleme
[**tags_post**](TagApi.md#tags_post) | **POST** /tags | SEO+ Etiketi Oluşturma


# **tags_get**
> Tag tags_get(opts)

SEO+ Etiketi Listesi Alma

SEO+ Etiketi listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::TagApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir
  name: "name_example" # String | SEO+ Etiketi adı
}

begin
  #SEO+ Etiketi Listesi Alma
  result = api_instance.tags_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TagApi->tags_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional] 
 **name** | **String**| SEO+ Etiketi adı | [optional] 

### Return type

[**Tag**](Tag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **tags_id_delete**
> tags_id_delete(id)

SEO+ Etiketi Silme

Kalıcı olarak ilgili SEO+ Etiketini siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::TagApi.new

id = 56 # Integer | SEO+ Etiketi nesnesinin id değeri


begin
  #SEO+ Etiketi Silme
  api_instance.tags_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TagApi->tags_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| SEO+ Etiketi nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **tags_id_get**
> Tag tags_id_get(id)

SEO+ Etiketi Alma

İlgili SEO+ Etiketini getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::TagApi.new

id = 56 # Integer | SEO+ Etiketi nesnesinin id değeri


begin
  #SEO+ Etiketi Alma
  result = api_instance.tags_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TagApi->tags_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| SEO+ Etiketi nesnesinin id değeri | 

### Return type

[**Tag**](Tag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **tags_id_put**
> Tag tags_id_put(id, tag)

SEO+ Etiketi Güncelleme

İlgili SEO+ Etiketini günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::TagApi.new

id = 56 # Integer | SEO+ Etiketi nesnesinin id değeri

tag = SwaggerClient::Tag.new # Tag | Tag nesnesi


begin
  #SEO+ Etiketi Güncelleme
  result = api_instance.tags_id_put(id, tag)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TagApi->tags_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| SEO+ Etiketi nesnesinin id değeri | 
 **tag** | [**Tag**](Tag.md)| Tag nesnesi | 

### Return type

[**Tag**](Tag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **tags_post**
> Tag tags_post(tag)

SEO+ Etiketi Oluşturma

Yeni bir SEO+ Etiketi oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::TagApi.new

tag = SwaggerClient::Tag.new # Tag | Tag nesnesi


begin
  #SEO+ Etiketi Oluşturma
  result = api_instance.tags_post(tag)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TagApi->tags_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tag** | [**Tag**](Tag.md)| Tag nesnesi | 

### Return type

[**Tag**](Tag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



