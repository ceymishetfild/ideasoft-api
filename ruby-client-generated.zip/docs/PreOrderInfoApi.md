# SwaggerClient::PreOrderInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**pre_order_infos_get**](PreOrderInfoApi.md#pre_order_infos_get) | **GET** /pre_order_infos | Sipariş Öncesi Bilgisi Listesi Alma
[**pre_order_infos_id_delete**](PreOrderInfoApi.md#pre_order_infos_id_delete) | **DELETE** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Silme
[**pre_order_infos_id_get**](PreOrderInfoApi.md#pre_order_infos_id_get) | **GET** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Alma
[**pre_order_infos_id_put**](PreOrderInfoApi.md#pre_order_infos_id_put) | **PUT** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Güncelleme
[**pre_order_infos_post**](PreOrderInfoApi.md#pre_order_infos_post) | **POST** /pre_order_infos | Sipariş Öncesi Bilgisi Oluşturma


# **pre_order_infos_get**
> PreOrderInfo pre_order_infos_get(opts)

Sipariş Öncesi Bilgisi Listesi Alma

Sipariş Öncesi Bilgisi listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::PreOrderInfoApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  session_id: "session_id_example", # String | Sipariş Öncesi Bilgisi session id.
  start_date: Date.parse("2013-10-20"), # Date | createdAt değeri için başlangıç tarihi
  end_date: "end_date_example", # String | createdAt değeri için bitiş tarihi
  start_updated_at: Date.parse("2013-10-20"), # Date | updatedAt değeri için başlangıç tarihi
  end_updated_at: "end_updated_at_example" # String | updatedAt değeri için bitiş tarihi
}

begin
  #Sipariş Öncesi Bilgisi Listesi Alma
  result = api_instance.pre_order_infos_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling PreOrderInfoApi->pre_order_infos_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **session_id** | **String**| Sipariş Öncesi Bilgisi session id. | [optional] 
 **start_date** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **pre_order_infos_id_delete**
> pre_order_infos_id_delete(id)

Sipariş Öncesi Bilgisi Silme

Kalıcı olarak ilgili Sipariş Öncesi Bilgisini siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::PreOrderInfoApi.new

id = 56 # Integer | Sipariş Öncesi Bilgisi nesnesinin id değeri


begin
  #Sipariş Öncesi Bilgisi Silme
  api_instance.pre_order_infos_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling PreOrderInfoApi->pre_order_infos_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **pre_order_infos_id_get**
> PreOrderInfo pre_order_infos_id_get(id)

Sipariş Öncesi Bilgisi Alma

İlgili Sipariş Öncesi Bilgisini getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::PreOrderInfoApi.new

id = 56 # Integer | Sipariş Öncesi Bilgisi nesnesinin id değeri


begin
  #Sipariş Öncesi Bilgisi Alma
  result = api_instance.pre_order_infos_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling PreOrderInfoApi->pre_order_infos_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **pre_order_infos_id_put**
> PreOrderInfo pre_order_infos_id_put(id, pre_order_info)

Sipariş Öncesi Bilgisi Güncelleme

İlgili Sipariş Öncesi Bilgisini günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::PreOrderInfoApi.new

id = 56 # Integer | Sipariş Öncesi Bilgisi nesnesinin id değeri

pre_order_info = SwaggerClient::PreOrderInfo.new # PreOrderInfo | PreOrderInfo nesnesi


begin
  #Sipariş Öncesi Bilgisi Güncelleme
  result = api_instance.pre_order_infos_id_put(id, pre_order_info)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling PreOrderInfoApi->pre_order_infos_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 
 **pre_order_info** | [**PreOrderInfo**](PreOrderInfo.md)| PreOrderInfo nesnesi | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **pre_order_infos_post**
> PreOrderInfo pre_order_infos_post(pre_order_info)

Sipariş Öncesi Bilgisi Oluşturma

Yeni bir Sipariş Öncesi Bilgisi oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::PreOrderInfoApi.new

pre_order_info = SwaggerClient::PreOrderInfo.new # PreOrderInfo | PreOrderInfo nesnesi


begin
  #Sipariş Öncesi Bilgisi Oluşturma
  result = api_instance.pre_order_infos_post(pre_order_info)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling PreOrderInfoApi->pre_order_infos_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pre_order_info** | [**PreOrderInfo**](PreOrderInfo.md)| PreOrderInfo nesnesi | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



