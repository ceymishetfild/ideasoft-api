# SwaggerClient::Theme

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Tema nesnesi kimlik değeri. | [optional] 
**platform** | **String** | Temanın kullanılacağı platform.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü.&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil.&lt;br&gt;&lt;/div&gt; | 
**type** | **String** | Tema tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;self&lt;/code&gt; : Kişisel Tema.&lt;br&gt;&lt;code&gt;standard&lt;/code&gt; : Standart Tema.&lt;br&gt;&lt;/div&gt; | [optional] 
**name** | **String** | Tema adı. | 
**preset** | **String** | Temanın rengi. | [optional] 
**directory_name** | **String** | Temanın dizini. | [optional] 
**status** | **String** | Temanın durumu. | 
**revision** | **Integer** | Temanın revisionı. | [optional] 
**created_at** | **DateTime** | Tema nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Tema nesnesinin güncellenme zamanı. | [optional] 
**attachment** | **String** |  | [optional] 


