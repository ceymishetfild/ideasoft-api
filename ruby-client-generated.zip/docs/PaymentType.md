# SwaggerClient::PaymentType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ödeme tipi nesnesi kimlik değeri. | [optional] 
**name** | **String** | Ödeme tipi nesnesi için isim değeri. | 


