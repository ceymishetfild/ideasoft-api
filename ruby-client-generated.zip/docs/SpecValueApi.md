# SwaggerClient::SpecValueApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**spec_values_get**](SpecValueApi.md#spec_values_get) | **GET** /spec_values | Ürün Özellik Değeri Listesi Alma
[**spec_values_id_delete**](SpecValueApi.md#spec_values_id_delete) | **DELETE** /spec_values/{id} | Ürün Özellik Değeri Silme
[**spec_values_id_get**](SpecValueApi.md#spec_values_id_get) | **GET** /spec_values/{id} | Ürün Özellik Değeri Alma
[**spec_values_id_put**](SpecValueApi.md#spec_values_id_put) | **PUT** /spec_values/{id} | Ürün Özellik Değeri Güncelleme
[**spec_values_post**](SpecValueApi.md#spec_values_post) | **POST** /spec_values | Ürün Özellik Değeri Oluşturma


# **spec_values_get**
> SpecValue spec_values_get(opts)

Ürün Özellik Değeri Listesi Alma

Ürün Özellik Değeri listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SpecValueApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  name: "name_example", # String | Ürün özellik adı
  spec_name: 56, # Integer | Ürün özellik id
  spec_value: 56 # Integer | Ürün özellik değeri id
}

begin
  #Ürün Özellik Değeri Listesi Alma
  result = api_instance.spec_values_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SpecValueApi->spec_values_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **String**| Ürün özellik adı | [optional] 
 **spec_name** | **Integer**| Ürün özellik id | [optional] 
 **spec_value** | **Integer**| Ürün özellik değeri id | [optional] 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **spec_values_id_delete**
> spec_values_id_delete(id)

Ürün Özellik Değeri Silme

Kalıcı olarak ilgili Ürün Özellik Değerini siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SpecValueApi.new

id = 56 # Integer | Ürün Özellik Değeri nesnesinin id değeri


begin
  #Ürün Özellik Değeri Silme
  api_instance.spec_values_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SpecValueApi->spec_values_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Değeri nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **spec_values_id_get**
> SpecValue spec_values_id_get(id)

Ürün Özellik Değeri Alma

İlgili Ürün Özellik Değerini getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SpecValueApi.new

id = 56 # Integer | Ürün Özellik Değeri nesnesinin id değeri


begin
  #Ürün Özellik Değeri Alma
  result = api_instance.spec_values_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SpecValueApi->spec_values_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Değeri nesnesinin id değeri | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **spec_values_id_put**
> SpecValue spec_values_id_put(id, spec_value)

Ürün Özellik Değeri Güncelleme

İlgili Ürün Özellik Değerini günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SpecValueApi.new

id = 56 # Integer | Ürün Özellik Değeri nesnesinin id değeri

spec_value = SwaggerClient::SpecValue.new # SpecValue |  nesnesi


begin
  #Ürün Özellik Değeri Güncelleme
  result = api_instance.spec_values_id_put(id, spec_value)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SpecValueApi->spec_values_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özellik Değeri nesnesinin id değeri | 
 **spec_value** | [**SpecValue**](SpecValue.md)|  nesnesi | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **spec_values_post**
> SpecValue spec_values_post(spec_value)

Ürün Özellik Değeri Oluşturma

Yeni bir Ürün Özellik Değeri oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::SpecValueApi.new

spec_value = SwaggerClient::SpecValue.new # SpecValue |  nesnesi


begin
  #Ürün Özellik Değeri Oluşturma
  result = api_instance.spec_values_post(spec_value)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SpecValueApi->spec_values_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **spec_value** | [**SpecValue**](SpecValue.md)|  nesnesi | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



