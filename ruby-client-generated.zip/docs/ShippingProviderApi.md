# SwaggerClient::ShippingProviderApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipping_providers_get**](ShippingProviderApi.md#shipping_providers_get) | **GET** /shipping_providers | Teslimat Hizmeti Sağlayıcısı Listesi Alma
[**shipping_providers_id_get**](ShippingProviderApi.md#shipping_providers_id_get) | **GET** /shipping_providers/{id} | Teslimat Hizmeti Sağlayıcısı Alma


# **shipping_providers_get**
> ShippingProvider shipping_providers_get(opts)

Teslimat Hizmeti Sağlayıcısı Listesi Alma

Teslimat Hizmeti Sağlayıcısı listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingProviderApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  code: "code_example", # String | Kargo firması kodu
  name: "name_example" # String | Kargo firması adı
}

begin
  #Teslimat Hizmeti Sağlayıcısı Listesi Alma
  result = api_instance.shipping_providers_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingProviderApi->shipping_providers_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **code** | **String**| Kargo firması kodu | [optional] 
 **name** | **String**| Kargo firması adı | [optional] 

### Return type

[**ShippingProvider**](ShippingProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipping_providers_id_get**
> ShippingProvider shipping_providers_id_get(id)

Teslimat Hizmeti Sağlayıcısı Alma

İlgili Teslimat Hizmeti Sağlayıcısını getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingProviderApi.new

id = 56 # Integer | Teslimat Hizmeti Sağlayıcısı nesnesinin id değeri


begin
  #Teslimat Hizmeti Sağlayıcısı Alma
  result = api_instance.shipping_providers_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingProviderApi->shipping_providers_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Teslimat Hizmeti Sağlayıcısı nesnesinin id değeri | 

### Return type

[**ShippingProvider**](ShippingProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



