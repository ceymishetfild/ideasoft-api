# SwaggerClient::TownApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**towns_get**](TownApi.md#towns_get) | **GET** /towns | İlçe Listesi Alma
[**towns_id_delete**](TownApi.md#towns_id_delete) | **DELETE** /towns/{id} | İlçe Silme
[**towns_id_get**](TownApi.md#towns_id_get) | **GET** /towns/{id} | İlçe Alma
[**towns_id_put**](TownApi.md#towns_id_put) | **PUT** /towns/{id} | İlçe Güncelleme
[**towns_post**](TownApi.md#towns_post) | **POST** /towns | İlçe Oluşturma


# **towns_get**
> Town towns_get(opts)

İlçe Listesi Alma

İlçe listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::TownApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  location: 56, # Integer | Şehir id
  town_group: 56, # Integer | İlçe grubu id
  name: "name_example", # String | İlçe adı.
  status: "status_example" # String | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
}

begin
  #İlçe Listesi Alma
  result = api_instance.towns_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TownApi->towns_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **location** | **Integer**| Şehir id | [optional] 
 **town_group** | **Integer**| İlçe grubu id | [optional] 
 **name** | **String**| İlçe adı. | [optional] 
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **towns_id_delete**
> towns_id_delete(id)

İlçe Silme

Kalıcı olarak ilgili İlçeyi siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::TownApi.new

id = 56 # Integer | İlçe nesnesinin id değeri


begin
  #İlçe Silme
  api_instance.towns_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TownApi->towns_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| İlçe nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **towns_id_get**
> Town towns_id_get(id)

İlçe Alma

İlgili İlçeyi getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::TownApi.new

id = 56 # Integer | İlçe nesnesinin id değeri


begin
  #İlçe Alma
  result = api_instance.towns_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TownApi->towns_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| İlçe nesnesinin id değeri | 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **towns_id_put**
> Town towns_id_put(id, town)

İlçe Güncelleme

İlgili İlçeyi günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::TownApi.new

id = 56 # Integer | İlçe nesnesinin id değeri

town = SwaggerClient::Town.new # Town | Town nesnesi


begin
  #İlçe Güncelleme
  result = api_instance.towns_id_put(id, town)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TownApi->towns_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| İlçe nesnesinin id değeri | 
 **town** | [**Town**](Town.md)| Town nesnesi | 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **towns_post**
> Town towns_post(town)

İlçe Oluşturma

Yeni bir İlçe oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::TownApi.new

town = SwaggerClient::Town.new # Town | Town nesnesi


begin
  #İlçe Oluşturma
  result = api_instance.towns_post(town)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TownApi->towns_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **town** | [**Town**](Town.md)| Town nesnesi | 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



