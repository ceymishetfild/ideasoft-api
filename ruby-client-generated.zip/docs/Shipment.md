# SwaggerClient::Shipment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Teslimat nesnesi kimlik değeri. | [optional] 
**barcode** | **String** | Teslimat barkodu. | [optional] 
**waybill_no** | **String** | Teslimat fatura numarası. | [optional] 
**invoice_key** | **String** | Teslimat irsaliye makbuzu numarası. | [optional] 
**cargo_office** | **String** | Teslimatın kargo şubesi | [optional] 
**code** | **String** | Teslimat kodu. Kargo takip kodu. | [optional] 
**delivery_type** | **String** | Teslimat tipi | [optional] 
**invoice_included** | **String** | Faturanın pakete dahillik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Dahil.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Dahil değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**pay_at_door_amount** | **Float** | Kapıda ödeme hizmeti bedeli. | [optional] 
**created_at** | **DateTime** | Teslimat nesnesinin oluşturulma zamanı. | [optional] 
**status** | **Integer** | Teslimat nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**order** | [**Order**](Order.md) |  | [optional] 


