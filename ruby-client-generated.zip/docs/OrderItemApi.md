# SwaggerClient::OrderItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**order_items_get**](OrderItemApi.md#order_items_get) | **GET** /order_items | Sipariş Kalemi Listesi Alma
[**order_items_id_get**](OrderItemApi.md#order_items_id_get) | **GET** /order_items/{id} | Sipariş Kalemi Alma


# **order_items_get**
> OrderItem order_items_get(opts)

Sipariş Kalemi Listesi Alma

Sipariş Kalemi listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderItemApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  order: 56, # Integer | Sipariş id
  product_name: "product_name_example", # String | Ürün adı
  product_sku: "product_sku_example", # String | Ürün stok kodu
  product_barcode: "product_barcode_example", # String | Ürün barkodu
  start_date: Date.parse("2013-10-20"), # Date | createdAt değeri için başlangıç tarihi
  end_date: "end_date_example", # String | createdAt değeri için bitiş tarihi
  start_updated_at: Date.parse("2013-10-20"), # Date | updatedAt değeri için başlangıç tarihi
  end_updated_at: "end_updated_at_example" # String | updatedAt değeri için bitiş tarihi
}

begin
  #Sipariş Kalemi Listesi Alma
  result = api_instance.order_items_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderItemApi->order_items_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **order** | **Integer**| Sipariş id | [optional] 
 **product_name** | **String**| Ürün adı | [optional] 
 **product_sku** | **String**| Ürün stok kodu | [optional] 
 **product_barcode** | **String**| Ürün barkodu | [optional] 
 **start_date** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**OrderItem**](OrderItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **order_items_id_get**
> OrderItem order_items_id_get(id)

Sipariş Kalemi Alma

İlgili Sipariş Kalemini getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderItemApi.new

id = 56 # Integer | Sipariş Kalemi nesnesinin id değeri


begin
  #Sipariş Kalemi Alma
  result = api_instance.order_items_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderItemApi->order_items_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Kalemi nesnesinin id değeri | 

### Return type

[**OrderItem**](OrderItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



