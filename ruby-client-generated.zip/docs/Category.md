# SwaggerClient::Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Kategori nesnesi kimlik değeri. | [optional] 
**name** | **String** | Kategori nesnesi için isim değeri. | 
**slug** | **String** | Slug değeri ilgili nesnenin Url değeridir. | [optional] 
**sort_order** | **Integer** | Kategori nesnesi için sıralama değeri. | [optional] 
**status** | **String** | Kategori nesnesinin aktiflik durumunu belirten değer. | 
**percent** | **Float** | Kategori nesnesinin fiyat katsayısı. | [optional] 
**image_file** | **String** | Kategori nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF | [optional] 
**distributor** | **String** | Her zaman null değer alır. Pratikte kullanımı yoktur. | [optional] 
**display_showcase_content** | **Integer** | Kategori nesnesinin üst içerik metninin gösterim durumu. | [optional] 
**showcase_content** | **String** | Kategori nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir. | [optional] 
**showcase_content_display_type** | **Integer** | Kategori nesnesinin üst içerik metninin gösterim tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kategori içeriği.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Kategori ve üst kategori içeriği.&lt;br&gt;&lt;code&gt;3&lt;/code&gt; : Kategori ve tüm üst kategoriler.&lt;br&gt;&lt;/div&gt; | 
**has_children** | **String** | Kategori nesnesinin alt kategori barındırma durumu. Bu değer otomatik oluşturulur. | [optional] 
**meta_keywords** | **String** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] 
**meta_description** | **String** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] 
**page_title** | **String** | Kategori nesnesinin etiket başlığı. | [optional] 
**parent** | [**Category**](Category.md) |  | [optional] 
**attachment** | **String** | Kategori nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. | [optional] 
**created_at** | **DateTime** | Kategori nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Kategori nesnesinin güncellenme zamanı. | [optional] 


