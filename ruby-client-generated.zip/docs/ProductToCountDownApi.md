# SwaggerClient::ProductToCountDownApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_to_count_downs_get**](ProductToCountDownApi.md#product_to_count_downs_get) | **GET** /product_to_count_downs | Ürün Geri Sayım Bağı Listesi Alma
[**product_to_count_downs_id_delete**](ProductToCountDownApi.md#product_to_count_downs_id_delete) | **DELETE** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Silme
[**product_to_count_downs_id_get**](ProductToCountDownApi.md#product_to_count_downs_id_get) | **GET** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Alma
[**product_to_count_downs_id_put**](ProductToCountDownApi.md#product_to_count_downs_id_put) | **PUT** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Güncelleme
[**product_to_count_downs_post**](ProductToCountDownApi.md#product_to_count_downs_post) | **POST** /product_to_count_downs | Ürün Geri Sayım Bağı Oluşturma


# **product_to_count_downs_get**
> ProductToCountDown product_to_count_downs_get(opts)

Ürün Geri Sayım Bağı Listesi Alma

Ürün Geri Sayım Bağı listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductToCountDownApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  product: 56 # Integer | Ürün id
}

begin
  #Ürün Geri Sayım Bağı Listesi Alma
  result = api_instance.product_to_count_downs_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductToCountDownApi->product_to_count_downs_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **product** | **Integer**| Ürün id | [optional] 

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_to_count_downs_id_delete**
> product_to_count_downs_id_delete(id)

Ürün Geri Sayım Bağı Silme

Kalıcı olarak ilgili Ürün Geri Sayım Bağını siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductToCountDownApi.new

id = 56 # Integer | Ürün Geri Sayım Bağı nesnesinin id değeri


begin
  #Ürün Geri Sayım Bağı Silme
  api_instance.product_to_count_downs_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductToCountDownApi->product_to_count_downs_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Geri Sayım Bağı nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_to_count_downs_id_get**
> ProductToCountDown product_to_count_downs_id_get(id)

Ürün Geri Sayım Bağı Alma

İlgili Ürün Geri Sayım Bağını getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductToCountDownApi.new

id = 56 # Integer | Ürün Geri Sayım Bağı nesnesinin id değeri


begin
  #Ürün Geri Sayım Bağı Alma
  result = api_instance.product_to_count_downs_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductToCountDownApi->product_to_count_downs_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Geri Sayım Bağı nesnesinin id değeri | 

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_to_count_downs_id_put**
> ProductToCountDown product_to_count_downs_id_put(id, product_to_count_down)

Ürün Geri Sayım Bağı Güncelleme

İlgili Ürün Geri Sayım Bağını günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductToCountDownApi.new

id = 56 # Integer | Ürün Geri Sayım Bağı nesnesinin id değeri

product_to_count_down = SwaggerClient::ProductToCountDown.new # ProductToCountDown |  nesnesi


begin
  #Ürün Geri Sayım Bağı Güncelleme
  result = api_instance.product_to_count_downs_id_put(id, product_to_count_down)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductToCountDownApi->product_to_count_downs_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Geri Sayım Bağı nesnesinin id değeri | 
 **product_to_count_down** | [**ProductToCountDown**](ProductToCountDown.md)|  nesnesi | 

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_to_count_downs_post**
> ProductToCountDown product_to_count_downs_post(product_to_count_down)

Ürün Geri Sayım Bağı Oluşturma

Yeni bir Ürün Geri Sayım Bağı oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductToCountDownApi.new

product_to_count_down = SwaggerClient::ProductToCountDown.new # ProductToCountDown |  nesnesi


begin
  #Ürün Geri Sayım Bağı Oluşturma
  result = api_instance.product_to_count_downs_post(product_to_count_down)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductToCountDownApi->product_to_count_downs_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_to_count_down** | [**ProductToCountDown**](ProductToCountDown.md)|  nesnesi | 

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



