# SwaggerClient::BrandApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**brands_get**](BrandApi.md#brands_get) | **GET** /brands | Marka Listesi Alma
[**brands_id_delete**](BrandApi.md#brands_id_delete) | **DELETE** /brands/{id} | Marka Silme
[**brands_id_get**](BrandApi.md#brands_id_get) | **GET** /brands/{id} | Marka Alma
[**brands_id_put**](BrandApi.md#brands_id_put) | **PUT** /brands/{id} | Marka Güncelleme
[**brands_post**](BrandApi.md#brands_post) | **POST** /brands | Marka Oluşturma


# **brands_get**
> Brand brands_get(opts)

Marka Listesi Alma

Marka listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::BrandApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  name: "name_example", # String | Marka adı.
  status: 56, # Integer | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
  distributor: "distributor_example", # String | Marka distribörü
  start_date: Date.parse("2013-10-20"), # Date | createdAt değeri için başlangıç tarihi
  end_date: "end_date_example", # String | createdAt değeri için bitiş tarihi
  start_updated_at: Date.parse("2013-10-20"), # Date | updatedAt değeri için başlangıç tarihi
  end_updated_at: "end_updated_at_example", # String | updatedAt değeri için bitiş tarihi
  q: ["q_example"] # Array<String> | Marka arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;]
}

begin
  #Marka Listesi Alma
  result = api_instance.brands_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling BrandApi->brands_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **String**| Marka adı. | [optional] 
 **status** | **Integer**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **distributor** | **String**| Marka distribörü | [optional] 
 **start_date** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **String**| updatedAt değeri için bitiş tarihi | [optional] 
 **q** | [**Array&lt;String&gt;**](String.md)| Marka arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **brands_id_delete**
> brands_id_delete(id)

Marka Silme

Kalıcı olarak ilgili Markayı siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::BrandApi.new

id = 56 # Integer | Marka nesnesinin id değeri


begin
  #Marka Silme
  api_instance.brands_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling BrandApi->brands_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Marka nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **brands_id_get**
> Brand brands_id_get(id)

Marka Alma

İlgili Markayı getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::BrandApi.new

id = 56 # Integer | Marka nesnesinin id değeri


begin
  #Marka Alma
  result = api_instance.brands_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling BrandApi->brands_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Marka nesnesinin id değeri | 

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **brands_id_put**
> Brand brands_id_put(id, brand)

Marka Güncelleme

İlgili Markayı günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::BrandApi.new

id = 56 # Integer | Marka nesnesinin id değeri

brand = SwaggerClient::Brand.new # Brand | Brand nesnesi


begin
  #Marka Güncelleme
  result = api_instance.brands_id_put(id, brand)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling BrandApi->brands_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Marka nesnesinin id değeri | 
 **brand** | [**Brand**](Brand.md)| Brand nesnesi | 

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **brands_post**
> Brand brands_post(brand)

Marka Oluşturma

Yeni bir Marka oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::BrandApi.new

brand = SwaggerClient::Brand.new # Brand | Brand nesnesi


begin
  #Marka Oluşturma
  result = api_instance.brands_post(brand)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling BrandApi->brands_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **brand** | [**Brand**](Brand.md)| Brand nesnesi | 

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



