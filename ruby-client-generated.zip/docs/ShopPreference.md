# SwaggerClient::ShopPreference

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Tanımlama nesnesi kimlik değeri. | [optional] 
**var_key** | **String** | Tanımlama nesnesi için değişken anahtarı. | [optional] 
**var_value** | **String** | Tanımlama nesnesi için değişken değeri. | [optional] 


