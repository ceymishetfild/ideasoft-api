# SwaggerClient::Asset

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** | Tema Dosyası nesnesi anahtar değeri. | [optional] 
**content_type** | **String** | Tema Dosyası içerik tipi. Geçerli bir MIME Content-Type verilmelidir. | [optional] 
**attachment** | **String** | Tema Dosyası içeriği. | [optional] 
**created_at** | **DateTime** | Tema Dosyası nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Tema Dosyası nesnesinin güncellenme zamanı. | [optional] 


