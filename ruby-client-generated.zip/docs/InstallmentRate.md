# SwaggerClient::InstallmentRate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Taksit oranı nesnesi kimlik değeri. | [optional] 
**installment** | **Integer** | Taksit adeti. | 
**rate** | **Float** | Taksit adeti için oran bilgisi. | 
**payment_gateway** | [**PaymentGateway**](PaymentGateway.md) |  | [optional] 


