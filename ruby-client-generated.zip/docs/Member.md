# SwaggerClient::Member

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Üye nesnesi kimlik değeri. | [optional] 
**firstname** | **String** | Üyenin ismi. | 
**surname** | **String** | Üyenin soy ismi. | 
**email** | **String** | Üyenin e-mail adresi. | 
**gender** | **String** | Üyenin cinsiyet bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın&lt;br&gt;&lt;/div&gt; | [optional] 
**birth_date** | **DateTime** | Üyenin doğum tarihi. | [optional] 
**phone_number** | **String** | Üyenin telefon numarası. | [optional] 
**mobile_phone_number** | **String** | Üyenin mobil telefon numarası. | [optional] 
**other_location** | **String** | Üyenin diğer şehir bilgileri. | [optional] 
**address** | **String** | Üyenin adres bilgileri. | [optional] 
**tax_number** | **String** | Üyenin vergi numarası. | [optional] 
**tc_id** | **String** | Üyenin TC kimlik numarası. | [optional] 
**status** | **String** | Üyenin durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;queue&lt;/code&gt; : Sırada&lt;br&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;suspended&lt;/code&gt; : Askıda&lt;br&gt;&lt;/div&gt; | 
**last_login_date** | **DateTime** | Üyenin son giriş yaptığı tarih. | [optional] 
**created_at** | **DateTime** | Üye nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Üye nesnesinin güncellenme zamanı. | [optional] 
**zip_code** | **String** | Üyenin posta kodu. | [optional] 
**commercial_name** | **String** | Üyenin kurumsal adı. | [optional] 
**tax_office** | **String** | Üyenin vergi dairesi. | [optional] 
**last_mail_sent_date** | **DateTime** | Üyeye gönderilen son e-mail tarihi. | [optional] 
**last_ip** | **String** | Üyenin en son giriş yaptığı IP adresi. | [optional] 
**gained_point_amount** | **Float** | Üyenin kazandığı puan tutarı. | [optional] 
**spent_point_amount** | **Float** | Üyenin harcadığı puan tutarı. | [optional] 
**allowed_to_campaigns** | **String** | Üyenin kampanyalara katılım için izin durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalar için izinli.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalar için izinsiz.&lt;br&gt;&lt;/div&gt; | [optional] 
**referred_member_gained_point_amount** | **Float** | Üyenin tavsiye ettiği kişilerden dolayı kazandığı puan. | [optional] 
**district** | **String** | Üyenin ilçesi. | [optional] 
**device_type** | **String** | Üyenin kullandığı cihaz tipi. | 
**device_info** | **String** | Üyenin kullandığı cihaz bilgisi. | [optional] 
**country** | [**Country**](Country.md) |  | [optional] 
**location** | [**Location**](Location.md) |  | [optional] 
**member_group** | [**MemberGroup**](MemberGroup.md) |  | [optional] 
**referred_member** | [**Member**](Member.md) |  | [optional] 


