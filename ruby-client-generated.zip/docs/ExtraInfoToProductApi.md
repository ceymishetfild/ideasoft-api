# SwaggerClient::ExtraInfoToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extra_info_to_products_get**](ExtraInfoToProductApi.md#extra_info_to_products_get) | **GET** /extra_info_to_products | Ek Bilgi Ürün Bağı Listesi Alma
[**extra_info_to_products_id_delete**](ExtraInfoToProductApi.md#extra_info_to_products_id_delete) | **DELETE** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Silme
[**extra_info_to_products_id_get**](ExtraInfoToProductApi.md#extra_info_to_products_id_get) | **GET** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Alma
[**extra_info_to_products_id_put**](ExtraInfoToProductApi.md#extra_info_to_products_id_put) | **PUT** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Güncelleme
[**extra_info_to_products_post**](ExtraInfoToProductApi.md#extra_info_to_products_post) | **POST** /extra_info_to_products | Ek Bilgi Ürün Bağı Oluşturma


# **extra_info_to_products_get**
> ExtraInfoToProduct extra_info_to_products_get(opts)

Ek Bilgi Ürün Bağı Listesi Alma

Ek Bilgi Ürün Bağı listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ExtraInfoToProductApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  extra_info: 56, # Integer | Ek bilgi id
  product: 56 # Integer | Ürün id
}

begin
  #Ek Bilgi Ürün Bağı Listesi Alma
  result = api_instance.extra_info_to_products_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ExtraInfoToProductApi->extra_info_to_products_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **extra_info** | **Integer**| Ek bilgi id | [optional] 
 **product** | **Integer**| Ürün id | [optional] 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **extra_info_to_products_id_delete**
> extra_info_to_products_id_delete(id)

Ek Bilgi Ürün Bağı Silme

Kalıcı olarak ilgili Ek Bilgi Ürün Bağını siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ExtraInfoToProductApi.new

id = 56 # Integer | Ek Bilgi Ürün Bağı nesnesinin id değeri


begin
  #Ek Bilgi Ürün Bağı Silme
  api_instance.extra_info_to_products_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ExtraInfoToProductApi->extra_info_to_products_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **extra_info_to_products_id_get**
> ExtraInfoToProduct extra_info_to_products_id_get(id)

Ek Bilgi Ürün Bağı Alma

İlgili Ek Bilgi Ürün Bağını getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ExtraInfoToProductApi.new

id = 56 # Integer | Ek Bilgi Ürün Bağı nesnesinin id değeri


begin
  #Ek Bilgi Ürün Bağı Alma
  result = api_instance.extra_info_to_products_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ExtraInfoToProductApi->extra_info_to_products_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **extra_info_to_products_id_put**
> ExtraInfoToProduct extra_info_to_products_id_put(id, extra_info_to_product)

Ek Bilgi Ürün Bağı Güncelleme

İlgili Ek Bilgi Ürün Bağını günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ExtraInfoToProductApi.new

id = 56 # Integer | Ek Bilgi Ürün Bağı nesnesinin id değeri

extra_info_to_product = SwaggerClient::ExtraInfoToProduct.new # ExtraInfoToProduct |  nesnesi


begin
  #Ek Bilgi Ürün Bağı Güncelleme
  result = api_instance.extra_info_to_products_id_put(id, extra_info_to_product)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ExtraInfoToProductApi->extra_info_to_products_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 
 **extra_info_to_product** | [**ExtraInfoToProduct**](ExtraInfoToProduct.md)|  nesnesi | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **extra_info_to_products_post**
> ExtraInfoToProduct extra_info_to_products_post(extra_info_to_product)

Ek Bilgi Ürün Bağı Oluşturma

Yeni bir Ek Bilgi Ürün Bağı oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ExtraInfoToProductApi.new

extra_info_to_product = SwaggerClient::ExtraInfoToProduct.new # ExtraInfoToProduct |  nesnesi


begin
  #Ek Bilgi Ürün Bağı Oluşturma
  result = api_instance.extra_info_to_products_post(extra_info_to_product)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ExtraInfoToProductApi->extra_info_to_products_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extra_info_to_product** | [**ExtraInfoToProduct**](ExtraInfoToProduct.md)|  nesnesi | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



