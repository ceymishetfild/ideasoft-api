# SwaggerClient::MaillistApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**maillists_get**](MaillistApi.md#maillists_get) | **GET** /maillists | Mail Listesi Listesi Alma
[**maillists_id_delete**](MaillistApi.md#maillists_id_delete) | **DELETE** /maillists/{id} | Mail Listesi Silme
[**maillists_id_get**](MaillistApi.md#maillists_id_get) | **GET** /maillists/{id} | Mail Listesi Alma
[**maillists_id_put**](MaillistApi.md#maillists_id_put) | **PUT** /maillists/{id} | Mail Listesi Güncelleme
[**maillists_post**](MaillistApi.md#maillists_post) | **POST** /maillists | Mail Listesi Oluşturma


# **maillists_get**
> Maillist maillists_get(opts)

Mail Listesi Listesi Alma

Mail Listesi listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MaillistApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  name: "name_example", # String | Mail Listesi adı.
  email: "email_example", # String | Mail Listesi e-mail.
  maillist_group: 56, # Integer | Mail Listesi Grubu id
  start_date: Date.parse("2013-10-20"), # Date | createdAt değeri için başlangıç tarihi
  end_date: "end_date_example", # String | createdAt değeri için bitiş tarihi
  start_updated_at: Date.parse("2013-10-20"), # Date | updatedAt değeri için başlangıç tarihi
  end_updated_at: "end_updated_at_example" # String | updatedAt değeri için bitiş tarihi
}

begin
  #Mail Listesi Listesi Alma
  result = api_instance.maillists_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MaillistApi->maillists_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **String**| Mail Listesi adı. | [optional] 
 **email** | **String**| Mail Listesi e-mail. | [optional] 
 **maillist_group** | **Integer**| Mail Listesi Grubu id | [optional] 
 **start_date** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **maillists_id_delete**
> maillists_id_delete(id)

Mail Listesi Silme

Kalıcı olarak ilgili Mail Listesini siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MaillistApi.new

id = 56 # Integer | Mail Listesi nesnesinin id değeri


begin
  #Mail Listesi Silme
  api_instance.maillists_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MaillistApi->maillists_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Mail Listesi nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **maillists_id_get**
> Maillist maillists_id_get(id)

Mail Listesi Alma

İlgili Mail Listesini getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MaillistApi.new

id = 56 # Integer | Mail Listesi nesnesinin id değeri


begin
  #Mail Listesi Alma
  result = api_instance.maillists_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MaillistApi->maillists_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Mail Listesi nesnesinin id değeri | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **maillists_id_put**
> Maillist maillists_id_put(id, maillist)

Mail Listesi Güncelleme

İlgili Mail Listesini günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MaillistApi.new

id = 56 # Integer | Mail Listesi nesnesinin id değeri

maillist = SwaggerClient::Maillist.new # Maillist | Maillist nesnesi


begin
  #Mail Listesi Güncelleme
  result = api_instance.maillists_id_put(id, maillist)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MaillistApi->maillists_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Mail Listesi nesnesinin id değeri | 
 **maillist** | [**Maillist**](Maillist.md)| Maillist nesnesi | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **maillists_post**
> Maillist maillists_post(maillist)

Mail Listesi Oluşturma

Yeni bir Mail Listesini oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::MaillistApi.new

maillist = SwaggerClient::Maillist.new # Maillist | Maillist nesnesi


begin
  #Mail Listesi Oluşturma
  result = api_instance.maillists_post(maillist)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling MaillistApi->maillists_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **maillist** | [**Maillist**](Maillist.md)| Maillist nesnesi | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



