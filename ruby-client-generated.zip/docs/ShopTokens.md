# SwaggerClient::ShopTokens

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Hediye çeki nesnesi kimlik değeri. | [optional] 
**code** | **String** | Hediye çekinin benzersiz kodu. Admin panelinden düzenlenebilir. | [optional] 


