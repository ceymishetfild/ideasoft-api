# SwaggerClient::CartApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**carts_id_delete**](CartApi.md#carts_id_delete) | **DELETE** /carts/{id} | Sepet Silme
[**carts_id_get**](CartApi.md#carts_id_get) | **GET** /carts/{id} | Sepet Alma
[**carts_post**](CartApi.md#carts_post) | **POST** /carts | Sepet Oluşturma


# **carts_id_delete**
> carts_id_delete(id)

Sepet Silme

Kalıcı olarak ilgili Sepeti siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CartApi.new

id = 56 # Integer | Sepet nesnesinin id değeri


begin
  #Sepet Silme
  api_instance.carts_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CartApi->carts_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sepet nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **carts_id_get**
> Cart carts_id_get(id)

Sepet Alma

İlgili Sepet getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CartApi.new

id = 56 # Integer | Sepet nesnesinin id değeri


begin
  #Sepet Alma
  result = api_instance.carts_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CartApi->carts_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sepet nesnesinin id değeri | 

### Return type

[**Cart**](Cart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **carts_post**
> Cart carts_post(cart)

Sepet Oluşturma

Yeni bir Sepet oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CartApi.new

cart = SwaggerClient::Cart.new # Cart |  nesnesi


begin
  #Sepet Oluşturma
  result = api_instance.carts_post(cart)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CartApi->carts_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart** | [**Cart**](Cart.md)|  nesnesi | 

### Return type

[**Cart**](Cart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



