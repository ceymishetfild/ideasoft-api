# SwaggerClient::OrderItemCustomization

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sipariş kalemi özelleştirme kimlik değeri. | [optional] 
**product_customization_group_id** | **Integer** | Ürün özelleştirme grubu nesnesi kimlik değeri. | [optional] 
**product_customization_group_name** | **String** | Ürün özelleştirme grubu nesnesinin grup adı. | [optional] 
**product_customization_group_sort_order** | **Integer** | Ürün özelleştirme grubu nesnesinin sıralaması. | [optional] 
**product_customization_field_id** | **Integer** | Ürün özelleştirme nesnesi kimlik değeri.. | [optional] 
**product_customization_field_type** | **String** | Ürün özelleştirme nesnesinin alan tipi. | [optional] 
**product_customization_field_name** | **String** | Ürün özelleştirme nesnesinin alan adı. | [optional] 
**product_customization_field_value** | **String** | Ürün özelleştirme nesnesinin değeri. | [optional] 
**cart_item_attribute_id** | **Integer** | Sepet kalemi özelliği nesnesi kimlik değeri. | [optional] 


