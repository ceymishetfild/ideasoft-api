# SwaggerClient::ProductSpecialInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_special_infos_get**](ProductSpecialInfoApi.md#product_special_infos_get) | **GET** /product_special_infos | Ürün Özel Bilgi Alanı Listesi Alma
[**product_special_infos_id_delete**](ProductSpecialInfoApi.md#product_special_infos_id_delete) | **DELETE** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**product_special_infos_id_get**](ProductSpecialInfoApi.md#product_special_infos_id_get) | **GET** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**product_special_infos_id_put**](ProductSpecialInfoApi.md#product_special_infos_id_put) | **PUT** /product_special_infos/{id} | Ürün Özel Bilgi Alanı Güncelleme
[**product_special_infos_post**](ProductSpecialInfoApi.md#product_special_infos_post) | **POST** /product_special_infos | Ürün Özel Bilgi Alanı Oluşturma


# **product_special_infos_get**
> ProductSpecialInfo product_special_infos_get(opts)

Ürün Özel Bilgi Alanı Listesi Alma

Ürün Özel Bilgi Alanı listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductSpecialInfoApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  title: "title_example", # String | Ürün Özel Bilgi Alanı başlığı
  status: "status_example", # String | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
  product: 56 # Integer | Ürün id
}

begin
  #Ürün Özel Bilgi Alanı Listesi Alma
  result = api_instance.product_special_infos_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductSpecialInfoApi->product_special_infos_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **title** | **String**| Ürün Özel Bilgi Alanı başlığı | [optional] 
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **product** | **Integer**| Ürün id | [optional] 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_special_infos_id_delete**
> product_special_infos_id_delete(id)

Ürün Özel Bilgi Alanı

Kalıcı olarak ilgili Ürün Özel Bilgi Alanını siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductSpecialInfoApi.new

id = 56 # Integer | Ürün Özel Bilgi Alanı nesnesinin id değeri


begin
  #Ürün Özel Bilgi Alanı
  api_instance.product_special_infos_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductSpecialInfoApi->product_special_infos_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_special_infos_id_get**
> ProductSpecialInfo product_special_infos_id_get(id)

Ürün Özel Bilgi Alanı

İlgili Ürün Özel Bilgi Alanını getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductSpecialInfoApi.new

id = 56 # Integer | Ürün Özel Bilgi Alanı nesnesinin id değeri


begin
  #Ürün Özel Bilgi Alanı
  result = api_instance.product_special_infos_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductSpecialInfoApi->product_special_infos_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_special_infos_id_put**
> ProductSpecialInfo product_special_infos_id_put(id, product_special_info)

Ürün Özel Bilgi Alanı Güncelleme

İlgili Ürün Özel Bilgi Alanını günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductSpecialInfoApi.new

id = 56 # Integer | Ürün Özel Bilgi Alanı nesnesinin id değeri

product_special_info = SwaggerClient::ProductSpecialInfo.new # ProductSpecialInfo |  nesnesi


begin
  #Ürün Özel Bilgi Alanı Güncelleme
  result = api_instance.product_special_infos_id_put(id, product_special_info)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductSpecialInfoApi->product_special_infos_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 
 **product_special_info** | [**ProductSpecialInfo**](ProductSpecialInfo.md)|  nesnesi | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_special_infos_post**
> ProductSpecialInfo product_special_infos_post(product_special_info)

Ürün Özel Bilgi Alanı Oluşturma

Yeni bir Ürün Özel Bilgi Alanı oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductSpecialInfoApi.new

product_special_info = SwaggerClient::ProductSpecialInfo.new # ProductSpecialInfo |  nesnesi


begin
  #Ürün Özel Bilgi Alanı Oluşturma
  result = api_instance.product_special_infos_post(product_special_info)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductSpecialInfoApi->product_special_infos_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_special_info** | [**ProductSpecialInfo**](ProductSpecialInfo.md)|  nesnesi | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



