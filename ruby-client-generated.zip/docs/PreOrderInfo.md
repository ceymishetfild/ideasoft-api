# SwaggerClient::PreOrderInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sipariş öncesi bilgisi nesnesi kimlik değeri. | [optional] 
**session_id** | **String** | Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri. | 
**customer_firstname** | **String** | Müşterinin ismi. | [optional] 
**customer_surname** | **String** | Müşterinin soy ismi. | [optional] 
**customer_email** | **String** | Müşterinin e-mail adresi. | [optional] 
**shipping_firstname** | **String** | Teslimat yapılacak kişinin ismi. | 
**shipping_surname** | **String** | Teslimat yapılacak kişinin soy ismi. | 
**shipping_address** | **String** | Teslimat adresi bilgileri. | 
**shipping_phone_number** | **String** | Teslimat yapılacak kişinin telefon numarası. | 
**shipping_mobile_phone_number** | **String** | Teslimat yapılacak kişinin mobil telefon numarası. | 
**shipping_location_name** | **String** | Teslimat şehri. | 
**shipping_town** | **String** | Teslimat ilçesi. | 
**different_billing_address** | **String** | Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yok&lt;br&gt;&lt;/div&gt; | [optional] 
**billing_firstname** | **String** | Fatura kesilen kişinin ismi. | 
**billing_surname** | **String** | Fatura kesilen kişinin soy ismi. | 
**billing_address** | **String** | Fatura adresi bilgileri. | 
**billing_phone_number** | **String** | Fatura kesilen kişinin telefon numarası. | 
**billing_mobile_phone_number** | **String** | Fatura kesilen kişinin mobil telefon numarası. | 
**billing_location_name** | **String** | Fatura adresi şehri | 
**billing_town** | **String** | Fatura adresi ilçesi. | 
**billing_invoice_type** | **String** | Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt; | 
**billing_identity_registration_number** | **String** | Fatura kesilen kişinin TC kimlik numarası. | [optional] 
**billing_tax_office** | **String** | Fatura kesilen kişi/kurumun vergi dairesi. | [optional] 
**billing_tax_no** | **String** | Fatura kesilen kişi/kurum vergi numarası. | [optional] 
**is_einvoice_user** | **String** | Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] 
**use_gift_package** | **String** | Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] 
**gift_note** | **String** | Hediye notu bilgisi. | [optional] 
**image_file** | **String** | Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif | [optional] 
**delivery_date** | **Date** | Müşterinin teslimatın gerçekleşmisini istediği tarih. | [optional] 
**delivery_time** | **String** | API bu değeri otomatik oluşturur. | [optional] 
**created_at** | **DateTime** | Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **DateTime** | Sipariş öncesi bilgisi nesnesinin güncellenme zamanı. | [optional] 
**billing_country** | [**Country**](Country.md) | Ülke nesnesi. | 
**billing_location** | [**Location**](Location.md) | Şehir nesnesi. | 
**shipping_company** | [**ShippingCompany**](ShippingCompany.md) | Kargo firması nesnesi. | 
**shipping_country** | [**Country**](Country.md) | Ülke nesnesi. | 
**shipping_location** | [**Location**](Location.md) | Şehir nesnesi. | 
**member_shipping_address** | [**MemberAddress**](MemberAddress.md) | Üye adresi nesnesi. | [optional] 
**member_billing_address** | [**MemberAddress**](MemberAddress.md) | Üye adresi nesnesi. | [optional] 


