# SwaggerClient::PaymentGatewayApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**payment_gateways_get**](PaymentGatewayApi.md#payment_gateways_get) | **GET** /payment_gateways | Ödeme Kanalı Listesi Alma
[**payment_gateways_id_get**](PaymentGatewayApi.md#payment_gateways_id_get) | **GET** /payment_gateways/{id} | Ödeme Kanalı Alma


# **payment_gateways_get**
> PaymentGateway payment_gateways_get(opts)

Ödeme Kanalı Listesi Alma

Ödeme Kanalı listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::PaymentGatewayApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  code: "code_example", # String | Ödeme kanalı notu
  name: "name_example" # String | Ödeme kanalı adı
}

begin
  #Ödeme Kanalı Listesi Alma
  result = api_instance.payment_gateways_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling PaymentGatewayApi->payment_gateways_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **code** | **String**| Ödeme kanalı notu | [optional] 
 **name** | **String**| Ödeme kanalı adı | [optional] 

### Return type

[**PaymentGateway**](PaymentGateway.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **payment_gateways_id_get**
> PaymentGateway payment_gateways_id_get(id)

Ödeme Kanalı Alma

İlgili Ödeme Kanalını getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::PaymentGatewayApi.new

id = 56 # Integer | Ödeme Kanalı nesnesinin id değeri


begin
  #Ödeme Kanalı Alma
  result = api_instance.payment_gateways_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling PaymentGatewayApi->payment_gateways_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ödeme Kanalı nesnesinin id değeri | 

### Return type

[**PaymentGateway**](PaymentGateway.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



