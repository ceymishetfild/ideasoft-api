# SwaggerClient::OptionToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**option_to_products_get**](OptionToProductApi.md#option_to_products_get) | **GET** /option_to_products | Varyant Ürün Bağı Listesi Alma
[**option_to_products_id_delete**](OptionToProductApi.md#option_to_products_id_delete) | **DELETE** /option_to_products/{id} | Varyant Ürün Bağı Silme
[**option_to_products_id_get**](OptionToProductApi.md#option_to_products_id_get) | **GET** /option_to_products/{id} | Varyant Ürün Bağı Alma
[**option_to_products_id_put**](OptionToProductApi.md#option_to_products_id_put) | **PUT** /option_to_products/{id} | Varyant Ürün Bağı Güncelleme
[**option_to_products_post**](OptionToProductApi.md#option_to_products_post) | **POST** /option_to_products | Varyant Ürün Bağı Oluşturma


# **option_to_products_get**
> OptionToProduct option_to_products_get(opts)

Varyant Ürün Bağı Listesi Alma

Varyant Ürün Bağı listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OptionToProductApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  product: 56, # Integer | Ürün id
  option_group: 56, # Integer | Varyant Grubu id
  option: 56, # Integer | Varyant id
  parent_product_id: 56 # Integer | Ana Ürün id
}

begin
  #Varyant Ürün Bağı Listesi Alma
  result = api_instance.option_to_products_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OptionToProductApi->option_to_products_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **product** | **Integer**| Ürün id | [optional] 
 **option_group** | **Integer**| Varyant Grubu id | [optional] 
 **option** | **Integer**| Varyant id | [optional] 
 **parent_product_id** | **Integer**| Ana Ürün id | [optional] 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **option_to_products_id_delete**
> option_to_products_id_delete(id)

Varyant Ürün Bağı Silme

Kalıcı olarak ilgili Varyant Ürün Bağını siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OptionToProductApi.new

id = 56 # Integer | Varyant Ürün Bağı nesnesinin id değeri


begin
  #Varyant Ürün Bağı Silme
  api_instance.option_to_products_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OptionToProductApi->option_to_products_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant Ürün Bağı nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **option_to_products_id_get**
> OptionToProduct option_to_products_id_get(id)

Varyant Ürün Bağı Alma

İlgili Varyant Ürün Bağını getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OptionToProductApi.new

id = 56 # Integer | Varyant Ürün Bağı nesnesinin id değeri


begin
  #Varyant Ürün Bağı Alma
  result = api_instance.option_to_products_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OptionToProductApi->option_to_products_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant Ürün Bağı nesnesinin id değeri | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **option_to_products_id_put**
> OptionToProduct option_to_products_id_put(id, option_to_product)

Varyant Ürün Bağı Güncelleme

İlgili Varyant Ürün Bağını günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OptionToProductApi.new

id = 56 # Integer | Varyant Ürün Bağı nesnesinin id değeri

option_to_product = SwaggerClient::OptionToProduct.new # OptionToProduct |  nesnesi


begin
  #Varyant Ürün Bağı Güncelleme
  result = api_instance.option_to_products_id_put(id, option_to_product)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OptionToProductApi->option_to_products_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant Ürün Bağı nesnesinin id değeri | 
 **option_to_product** | [**OptionToProduct**](OptionToProduct.md)|  nesnesi | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **option_to_products_post**
> OptionToProduct option_to_products_post(option_to_product)

Varyant Ürün Bağı Oluşturma

Yeni bir Varyant Ürün Bağı oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OptionToProductApi.new

option_to_product = SwaggerClient::OptionToProduct.new # OptionToProduct |  nesnesi


begin
  #Varyant Ürün Bağı Oluşturma
  result = api_instance.option_to_products_post(option_to_product)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OptionToProductApi->option_to_products_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **option_to_product** | [**OptionToProduct**](OptionToProduct.md)|  nesnesi | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



