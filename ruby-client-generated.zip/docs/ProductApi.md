# SwaggerClient::ProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**products_get**](ProductApi.md#products_get) | **GET** /products | Ürün Listesi Alma
[**products_id_delete**](ProductApi.md#products_id_delete) | **DELETE** /products/{id} | Ürün Silme
[**products_id_get**](ProductApi.md#products_id_get) | **GET** /products/{id} | Ürün Alma
[**products_id_put**](ProductApi.md#products_id_put) | **PUT** /products/{id} | Ürün Güncelleme
[**products_post**](ProductApi.md#products_post) | **POST** /products | Ürün Oluşturma


# **products_get**
> Product products_get(opts)

Ürün Listesi Alma

Ürün listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  ids2: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  parent: "parent_example", # String | Ürün id
  brand: 56, # Integer | Marka id
  sku: "sku_example", # String | Ürün stok kodu.
  name: "name_example", # String | Ürün adı.
  distributor: "distributor_example", # String | Ürün distribütör.
  q: ["q_example"], # Array<String> | Ürün arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;]
  start_date: Date.parse("2013-10-20"), # Date | createdAt değeri için başlangıç tarihi
  end_date: "end_date_example", # String | createdAt değeri için bitiş tarihi
  start_updated_at: Date.parse("2013-10-20"), # Date | updatedAt değeri için başlangıç tarihi
  end_updated_at: "end_updated_at_example" # String | updatedAt değeri için bitiş tarihi
}

begin
  #Ürün Listesi Alma
  result = api_instance.products_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductApi->products_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **ids2** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **parent** | **String**| Ürün id | [optional] 
 **brand** | **Integer**| Marka id | [optional] 
 **sku** | **String**| Ürün stok kodu. | [optional] 
 **name** | **String**| Ürün adı. | [optional] 
 **distributor** | **String**| Ürün distribütör. | [optional] 
 **q** | [**Array&lt;String&gt;**](String.md)| Ürün arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 
 **start_date** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **products_id_delete**
> products_id_delete(id)

Ürün Silme

Kalıcı olarak ilgili Ürünü siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductApi.new

id = 56 # Integer | Ürün nesnesinin id değeri


begin
  #Ürün Silme
  api_instance.products_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductApi->products_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **products_id_get**
> Product products_id_get(id)

Ürün Alma

İlgili Ürünü getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductApi.new

id = 56 # Integer | Ürün nesnesinin id değeri


begin
  #Ürün Alma
  result = api_instance.products_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductApi->products_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün nesnesinin id değeri | 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **products_id_put**
> Product products_id_put(id, product)

Ürün Güncelleme

İlgili Ürünü günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductApi.new

id = 56 # Integer | Ürün nesnesinin id değeri

product = SwaggerClient::Product.new # Product |  nesnesi


begin
  #Ürün Güncelleme
  result = api_instance.products_id_put(id, product)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductApi->products_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün nesnesinin id değeri | 
 **product** | [**Product**](Product.md)|  nesnesi | 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **products_post**
> Product products_post(product)

Ürün Oluşturma

Yeni bir Ürün oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductApi.new

product = SwaggerClient::Product.new # Product |  nesnesi


begin
  #Ürün Oluşturma
  result = api_instance.products_post(product)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductApi->products_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product** | [**Product**](Product.md)|  nesnesi | 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



