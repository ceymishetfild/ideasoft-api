# SwaggerClient::PaymentProvider

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ödeme altyapısı sağlayıcısı nesnesi kimlik değeri. | [optional] 
**code** | **String** | Ödeme altyapısı sağlayıcısı için ön tanımlanmış kod değeri. | 
**name** | **String** | Ödeme altyapısı sağlayıcısı için isim değeri. | 
**status** | **String** | Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer. | 
**payment_type** | [**PaymentType**](PaymentType.md) |  | [optional] 
**settings** | [**Array&lt;PaymentProviderSetting&gt;**](PaymentProviderSetting.md) | Ödeme altyapısı sağlayıcısı ayarları | [optional] 


