# SwaggerClient::SpecToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Ürün özellik ürün bağı nesnesi kimlik değeri. | [optional] 
**product** | [**Product**](Product.md) | Ürün nesnesi. | [optional] 
**spec_group** | [**SpecGroup**](SpecGroup.md) | Ürün özelliği grubu nesnesi. | 
**spec_name** | [**SpecName**](SpecName.md) | Ürün özelliği nesnesi. | 
**spec_value** | [**SpecValue**](SpecValue.md) | Ürün özellik grubu nesnesi. | 


