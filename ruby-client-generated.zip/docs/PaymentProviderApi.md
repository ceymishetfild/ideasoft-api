# SwaggerClient::PaymentProviderApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**payment_providers_get**](PaymentProviderApi.md#payment_providers_get) | **GET** /payment_providers | Ödeme Altyapısı Sağlayıcısı Listesi Alma
[**payment_providers_id_get**](PaymentProviderApi.md#payment_providers_id_get) | **GET** /payment_providers/{id} | Ödeme Altyapısı Sağlayıcısı Alma


# **payment_providers_get**
> PaymentProvider payment_providers_get(opts)

Ödeme Altyapısı Sağlayıcısı Listesi Alma

Ödeme Altyapısı Sağlayıcısı listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::PaymentProviderApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  code: "code_example", # String | Ödeme Altyapısı kodu
  name: "name_example" # String | Ödeme Altyapısı adı
}

begin
  #Ödeme Altyapısı Sağlayıcısı Listesi Alma
  result = api_instance.payment_providers_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling PaymentProviderApi->payment_providers_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **code** | **String**| Ödeme Altyapısı kodu | [optional] 
 **name** | **String**| Ödeme Altyapısı adı | [optional] 

### Return type

[**PaymentProvider**](PaymentProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **payment_providers_id_get**
> PaymentProvider payment_providers_id_get(id)

Ödeme Altyapısı Sağlayıcısı Alma

İlgili Ödeme Altyapısı Sağlayıcısını getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::PaymentProviderApi.new

id = 56 # Integer | Ödeme Altyapııs Sağlayıcısı nesnesinin id değeri


begin
  #Ödeme Altyapısı Sağlayıcısı Alma
  result = api_instance.payment_providers_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling PaymentProviderApi->payment_providers_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ödeme Altyapııs Sağlayıcısı nesnesinin id değeri | 

### Return type

[**PaymentProvider**](PaymentProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



