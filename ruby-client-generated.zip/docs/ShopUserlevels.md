# SwaggerClient::ShopUserlevels

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Yönetici grubu nesnesinin benzersiz rakamsal kimlik değeri. | [optional] 
**label** | **String** | Yönetici grubu ismi. | [optional] 
**roles** | **String** | Yönetici grubunun sahip olduğu roller. | [optional] 


