# SwaggerClient::ProductPriceApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_prices_get**](ProductPriceApi.md#product_prices_get) | **GET** /product_prices | Ürün Fiyat Listesi Alma
[**product_prices_id_delete**](ProductPriceApi.md#product_prices_id_delete) | **DELETE** /product_prices/{id} | Ürün Fiyat Silme
[**product_prices_id_get**](ProductPriceApi.md#product_prices_id_get) | **GET** /product_prices/{id} | Ürün Fiyat Alma
[**product_prices_id_put**](ProductPriceApi.md#product_prices_id_put) | **PUT** /product_prices/{id} | Ürün Fiyat Güncelleme
[**product_prices_post**](ProductPriceApi.md#product_prices_post) | **POST** /product_prices | Ürün Fiyat Oluşturma


# **product_prices_get**
> ProductPrice product_prices_get(opts)

Ürün Fiyat Listesi Alma

Ürün Fiyat listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductPriceApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  type: 56, # Integer | Ürün fiyat tipi
  product: 56 # Integer | Ürün id
}

begin
  #Ürün Fiyat Listesi Alma
  result = api_instance.product_prices_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductPriceApi->product_prices_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **type** | **Integer**| Ürün fiyat tipi | [optional] 
 **product** | **Integer**| Ürün id | [optional] 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_prices_id_delete**
> product_prices_id_delete(id)

Ürün Fiyat Silme

Kalıcı olarak ilgili Ürün Fiyatını siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductPriceApi.new

id = 56 # Integer | Ürün Fiyat nesnesinin id değeri


begin
  #Ürün Fiyat Silme
  api_instance.product_prices_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductPriceApi->product_prices_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Fiyat nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_prices_id_get**
> ProductPrice product_prices_id_get(id)

Ürün Fiyat Alma

İlgili Ürün Fiyatını getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductPriceApi.new

id = 56 # Integer | Ürün Fiyat nesnesinin id değeri


begin
  #Ürün Fiyat Alma
  result = api_instance.product_prices_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductPriceApi->product_prices_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Fiyat nesnesinin id değeri | 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_prices_id_put**
> ProductPrice product_prices_id_put(id, product_price)

Ürün Fiyat Güncelleme

İlgili Ürün Fiyatını günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductPriceApi.new

id = 56 # Integer | Ürün Fiyat nesnesinin id değeri

product_price = SwaggerClient::ProductPrice.new # ProductPrice |  nesnesi


begin
  #Ürün Fiyat Güncelleme
  result = api_instance.product_prices_id_put(id, product_price)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductPriceApi->product_prices_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Ürün Fiyat nesnesinin id değeri | 
 **product_price** | [**ProductPrice**](ProductPrice.md)|  nesnesi | 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **product_prices_post**
> ProductPrice product_prices_post(product_price)

Ürün Fiyat Oluşturma

Yeni bir Ürün Fiyat oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ProductPriceApi.new

product_price = SwaggerClient::ProductPrice.new # ProductPrice |  nesnesi


begin
  #Ürün Fiyat Oluşturma
  result = api_instance.product_prices_post(product_price)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductPriceApi->product_prices_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_price** | [**ProductPrice**](ProductPrice.md)|  nesnesi | 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



