# SwaggerClient::ShippingCompanyApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipping_companies_get**](ShippingCompanyApi.md#shipping_companies_get) | **GET** /shipping_companies | Kargo Firması Listesi Alma
[**shipping_companies_id_delete**](ShippingCompanyApi.md#shipping_companies_id_delete) | **DELETE** /shipping_companies/{id} | Kargo Firması Silme
[**shipping_companies_id_get**](ShippingCompanyApi.md#shipping_companies_id_get) | **GET** /shipping_companies/{id} | Kargo Firması Alma
[**shipping_companies_id_put**](ShippingCompanyApi.md#shipping_companies_id_put) | **PUT** /shipping_companies/{id} | Kargo Firması Güncelleme
[**shipping_companies_post**](ShippingCompanyApi.md#shipping_companies_post) | **POST** /shipping_companies | Kargo Firması Oluşturma


# **shipping_companies_get**
> ShippingCompany shipping_companies_get(opts)

Kargo Firması Listesi Alma

Kargo Firması listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingCompanyApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  name: "name_example", # String | Kargo firması adı
  company_code: "company_code_example", # String | Kargo firması kodu
  payment_type: "payment_type_example", # String | Ödeme Tipi şu değerleri alabilir: <br><code>cash_on_delivery</code> : Alıcı ödemeli<br><code>standart_delivery</code> : Gönderici ödemeli<br><code>not_applicable</code> : Bu alan için uygulanabilir değil
  shipping_provider: 56 # Integer | Teslimat Hizmeti Sağlayıcısı id
}

begin
  #Kargo Firması Listesi Alma
  result = api_instance.shipping_companies_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingCompanyApi->shipping_companies_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **String**| Kargo firması adı | [optional] 
 **company_code** | **String**| Kargo firması kodu | [optional] 
 **payment_type** | **String**| Ödeme Tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil | [optional] 
 **shipping_provider** | **Integer**| Teslimat Hizmeti Sağlayıcısı id | [optional] 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipping_companies_id_delete**
> shipping_companies_id_delete(id)

Kargo Firması Silme

Kalıcı olarak ilgili Kargo Firmasını siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingCompanyApi.new

id = 56 # Integer | Kargo Firması nesnesinin id değeri


begin
  #Kargo Firması Silme
  api_instance.shipping_companies_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingCompanyApi->shipping_companies_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kargo Firması nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipping_companies_id_get**
> ShippingCompany shipping_companies_id_get(id)

Kargo Firması Alma

İlgili Kargo Firmasını getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingCompanyApi.new

id = 56 # Integer | Kargo Firması nesnesinin id değeri


begin
  #Kargo Firması Alma
  result = api_instance.shipping_companies_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingCompanyApi->shipping_companies_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kargo Firması nesnesinin id değeri | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipping_companies_id_put**
> ShippingCompany shipping_companies_id_put(id, shipping_company)

Kargo Firması Güncelleme

İlgili Kargo Firmasını günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingCompanyApi.new

id = 56 # Integer | Kargo Firması nesnesinin id değeri

shipping_company = SwaggerClient::ShippingCompany.new # ShippingCompany |  nesnesi


begin
  #Kargo Firması Güncelleme
  result = api_instance.shipping_companies_id_put(id, shipping_company)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingCompanyApi->shipping_companies_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kargo Firması nesnesinin id değeri | 
 **shipping_company** | [**ShippingCompany**](ShippingCompany.md)|  nesnesi | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipping_companies_post**
> ShippingCompany shipping_companies_post(shipping_company)

Kargo Firması Oluşturma

Yeni bir Kargo Firması oluşturur relationship.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShippingCompanyApi.new

shipping_company = SwaggerClient::ShippingCompany.new # ShippingCompany |  nesnesi


begin
  #Kargo Firması Oluşturma
  result = api_instance.shipping_companies_post(shipping_company)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShippingCompanyApi->shipping_companies_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipping_company** | [**ShippingCompany**](ShippingCompany.md)|  nesnesi | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



