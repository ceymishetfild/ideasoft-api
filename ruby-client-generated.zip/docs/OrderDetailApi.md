# SwaggerClient::OrderDetailApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**order_details_get**](OrderDetailApi.md#order_details_get) | **GET** /order_details | Sipariş Detayı Listesi Alma
[**order_details_id_delete**](OrderDetailApi.md#order_details_id_delete) | **DELETE** /order_details/{id} | Sipariş Detayı Silme
[**order_details_id_get**](OrderDetailApi.md#order_details_id_get) | **GET** /order_details/{id} | Sipariş Detayı Alma
[**order_details_id_put**](OrderDetailApi.md#order_details_id_put) | **PUT** /order_details/{id} | Sipariş Detayı Güncelleme
[**order_details_post**](OrderDetailApi.md#order_details_post) | **POST** /order_details | Sipariş Detayı Oluşturma


# **order_details_get**
> OrderDetail order_details_get(opts)

Sipariş Detayı Listesi Alma

Sipariş Detayı listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderDetailApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  order: 56 # Integer | Sipariş id
}

begin
  #Sipariş Detayı Listesi Alma
  result = api_instance.order_details_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderDetailApi->order_details_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **order** | **Integer**| Sipariş id | [optional] 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **order_details_id_delete**
> order_details_id_delete(id)

Sipariş Detayı Silme

Kalıcı olarak ilgili Sipariş Detayı siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderDetailApi.new

id = 56 # Integer | Sipariş Detayı nesnesinin id değeri


begin
  #Sipariş Detayı Silme
  api_instance.order_details_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderDetailApi->order_details_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Detayı nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **order_details_id_get**
> OrderDetail order_details_id_get(id)

Sipariş Detayı Alma

İlgili Sipariş Detayı getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderDetailApi.new

id = 56 # Integer | Sipariş Detayı nesnesinin id değeri


begin
  #Sipariş Detayı Alma
  result = api_instance.order_details_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderDetailApi->order_details_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Detayı nesnesinin id değeri | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **order_details_id_put**
> OrderDetail order_details_id_put(id, order_detail)

Sipariş Detayı Güncelleme

İlgili Sipariş Detayı günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderDetailApi.new

id = 56 # Integer | Sipariş Detayı nesnesinin id değeri

order_detail = SwaggerClient::OrderDetail.new # OrderDetail |  nesnesi


begin
  #Sipariş Detayı Güncelleme
  result = api_instance.order_details_id_put(id, order_detail)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderDetailApi->order_details_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Sipariş Detayı nesnesinin id değeri | 
 **order_detail** | [**OrderDetail**](OrderDetail.md)|  nesnesi | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **order_details_post**
> OrderDetail order_details_post(order_detail)

Sipariş Detayı Oluşturma

Yeni bir Sipariş Detayı oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OrderDetailApi.new

order_detail = SwaggerClient::OrderDetail.new # OrderDetail |  nesnesi


begin
  #Sipariş Detayı Oluşturma
  result = api_instance.order_details_post(order_detail)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OrderDetailApi->order_details_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_detail** | [**OrderDetail**](OrderDetail.md)|  nesnesi | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



