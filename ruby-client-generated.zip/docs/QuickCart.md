# SwaggerClient::QuickCart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Hızlı satın al bağlantısı nesnesi kimlik değeri. | [optional] 
**name** | **String** | Hızlı satın al bağlantısı nesnesi için isim değeri. | 
**url** | **String** | Hızlı satın al bağlantısı url&#39;si. | 
**short_url** | **String** | Hızlı satın al bağlantısı için kısaltılmış url. | [optional] 


