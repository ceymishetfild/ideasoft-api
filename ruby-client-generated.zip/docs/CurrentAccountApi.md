# SwaggerClient::CurrentAccountApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**current_accounts_get**](CurrentAccountApi.md#current_accounts_get) | **GET** /current_accounts | Cari Hesap Listesi Alma
[**current_accounts_id_delete**](CurrentAccountApi.md#current_accounts_id_delete) | **DELETE** /current_accounts/{id} | Cari Hesap Silme
[**current_accounts_id_get**](CurrentAccountApi.md#current_accounts_id_get) | **GET** /current_accounts/{id} | Cari Hesap Alma
[**current_accounts_id_put**](CurrentAccountApi.md#current_accounts_id_put) | **PUT** /current_accounts/{id} | Cari Hesap Güncelleme
[**current_accounts_post**](CurrentAccountApi.md#current_accounts_post) | **POST** /current_accounts | Cari Hesap Oluşturma


# **current_accounts_get**
> CurrentAccount current_accounts_get(opts)

Cari Hesap Listesi Alma

Cari Hesap listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CurrentAccountApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  code: "code_example", # String | Cari Hesap kodu
  title: "title_example", # String | Cari Hesap başlığı
  start_date: Date.parse("2013-10-20"), # Date | createdAt değeri için başlangıç tarihi
  end_date: "end_date_example", # String | createdAt değeri için bitiş tarihi
  start_updated_at: Date.parse("2013-10-20"), # Date | updatedAt değeri için başlangıç tarihi
  end_updated_at: "end_updated_at_example", # String | updatedAt değeri için bitiş tarihi
  member: "member_example" # String | İlgili üye
}

begin
  #Cari Hesap Listesi Alma
  result = api_instance.current_accounts_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CurrentAccountApi->current_accounts_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **code** | **String**| Cari Hesap kodu | [optional] 
 **title** | **String**| Cari Hesap başlığı | [optional] 
 **start_date** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **String**| updatedAt değeri için bitiş tarihi | [optional] 
 **member** | **String**| İlgili üye | [optional] 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **current_accounts_id_delete**
> current_accounts_id_delete(id)

Cari Hesap Silme

Kalıcı olarak ilgili Cari Hesabı siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CurrentAccountApi.new

id = 56 # Integer | Cari Hesap nesnesinin id değeri


begin
  #Cari Hesap Silme
  api_instance.current_accounts_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CurrentAccountApi->current_accounts_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Cari Hesap nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **current_accounts_id_get**
> CurrentAccount current_accounts_id_get(id)

Cari Hesap Alma

İlgili Cari Hesabı getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CurrentAccountApi.new

id = 56 # Integer | Cari Hesap nesnesinin id değeri


begin
  #Cari Hesap Alma
  result = api_instance.current_accounts_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CurrentAccountApi->current_accounts_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Cari Hesap nesnesinin id değeri | 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **current_accounts_id_put**
> CurrentAccount current_accounts_id_put(id, current_account)

Cari Hesap Güncelleme

İlgili Cari Hesabı günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CurrentAccountApi.new

id = 56 # Integer | Cari Hesap nesnesinin id değeri

current_account = SwaggerClient::CurrentAccount.new # CurrentAccount |  nesnesi


begin
  #Cari Hesap Güncelleme
  result = api_instance.current_accounts_id_put(id, current_account)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CurrentAccountApi->current_accounts_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Cari Hesap nesnesinin id değeri | 
 **current_account** | [**CurrentAccount**](CurrentAccount.md)|  nesnesi | 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **current_accounts_post**
> CurrentAccount current_accounts_post(current_account)

Cari Hesap Oluşturma

Yeni bir Cari Hesap oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CurrentAccountApi.new

current_account = SwaggerClient::CurrentAccount.new # CurrentAccount |  nesnesi


begin
  #Cari Hesap Oluşturma
  result = api_instance.current_accounts_post(current_account)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CurrentAccountApi->current_accounts_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **current_account** | [**CurrentAccount**](CurrentAccount.md)|  nesnesi | 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



