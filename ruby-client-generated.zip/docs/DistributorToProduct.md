# SwaggerClient::DistributorToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Distribütor ürün bağı nesnesi kimlik değeri. | [optional] 
**distributor** | [**Distributor**](Distributor.md) |  | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 


