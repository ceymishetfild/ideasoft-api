# SwaggerClient::OptionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**option_groups_get**](OptionGroupApi.md#option_groups_get) | **GET** /option_groups | Varyant Grubu Listesi Alma
[**option_groups_id_delete**](OptionGroupApi.md#option_groups_id_delete) | **DELETE** /option_groups/{id} | Varyant Grubu Silme
[**option_groups_id_get**](OptionGroupApi.md#option_groups_id_get) | **GET** /option_groups/{id} | Varyant Grubu Alma
[**option_groups_id_put**](OptionGroupApi.md#option_groups_id_put) | **PUT** /option_groups/{id} | Varyant Grubu Güncelleme
[**option_groups_post**](OptionGroupApi.md#option_groups_post) | **POST** /option_groups | Varyant Grubu Oluşturma


# **option_groups_get**
> OptionGroup option_groups_get(opts)

Varyant Grubu Listesi Alma

Varyant Grubu listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OptionGroupApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  title: "title_example" # String | Varyant Grubu başlığı.
}

begin
  #Varyant Grubu Listesi Alma
  result = api_instance.option_groups_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OptionGroupApi->option_groups_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **title** | **String**| Varyant Grubu başlığı. | [optional] 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **option_groups_id_delete**
> option_groups_id_delete(id)

Varyant Grubu Silme

Kalıcı olarak ilgili Varyant Grubunu siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OptionGroupApi.new

id = 56 # Integer | Varyant Grubu nesnesinin id değeri


begin
  #Varyant Grubu Silme
  api_instance.option_groups_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OptionGroupApi->option_groups_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant Grubu nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **option_groups_id_get**
> OptionGroup option_groups_id_get(id)

Varyant Grubu Alma

İlgili Varyant Grubunu getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OptionGroupApi.new

id = 56 # Integer | Varyant Grubu nesnesinin id değeri


begin
  #Varyant Grubu Alma
  result = api_instance.option_groups_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OptionGroupApi->option_groups_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant Grubu nesnesinin id değeri | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **option_groups_id_put**
> OptionGroup option_groups_id_put(id, option_group)

Varyant Grubu Güncelleme

İlgili Varyant Grubunu günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OptionGroupApi.new

id = 56 # Integer | Varyant Grubu nesnesinin id değeri

option_group = SwaggerClient::OptionGroup.new # OptionGroup |  nesnesi


begin
  #Varyant Grubu Güncelleme
  result = api_instance.option_groups_id_put(id, option_group)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OptionGroupApi->option_groups_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Varyant Grubu nesnesinin id değeri | 
 **option_group** | [**OptionGroup**](OptionGroup.md)|  nesnesi | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **option_groups_post**
> OptionGroup option_groups_post(option_group)

Varyant Grubu Oluşturma

Yeni bir Varyant Grubu oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::OptionGroupApi.new

option_group = SwaggerClient::OptionGroup.new # OptionGroup |  nesnesi


begin
  #Varyant Grubu Oluşturma
  result = api_instance.option_groups_post(option_group)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling OptionGroupApi->option_groups_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **option_group** | [**OptionGroup**](OptionGroup.md)|  nesnesi | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



