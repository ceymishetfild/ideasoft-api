# SwaggerClient::CurrencyApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**currencies_get**](CurrencyApi.md#currencies_get) | **GET** /currencies | Kur Listesi Alma
[**currencies_id_get**](CurrencyApi.md#currencies_id_get) | **GET** /currencies/{id} | Kur Alma
[**currencies_id_put**](CurrencyApi.md#currencies_id_put) | **PUT** /currencies/{id} | Kur Güncelleme


# **currencies_get**
> Currency currencies_get(opts)

Kur Listesi Alma

Kur listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CurrencyApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  ids: "ids_example", # String | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code> 
  label: "label_example", # String | Kur etiketi
  abbr: "abbr_example", # String | Kur kısaltması
  status: "status_example" # String | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif
}

begin
  #Kur Listesi Alma
  result = api_instance.currencies_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CurrencyApi->currencies_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **String**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **label** | **String**| Kur etiketi | [optional] 
 **abbr** | **String**| Kur kısaltması | [optional] 
 **status** | **String**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 

### Return type

[**Currency**](Currency.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **currencies_id_get**
> Currency currencies_id_get(id)

Kur Alma

İlgili Kur getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CurrencyApi.new

id = 56 # Integer | Kur nesnesinin id değeri


begin
  #Kur Alma
  result = api_instance.currencies_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CurrencyApi->currencies_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kur nesnesinin id değeri | 

### Return type

[**Currency**](Currency.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **currencies_id_put**
> Currency currencies_id_put(id, currency)

Kur Güncelleme

İlgili Kur günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::CurrencyApi.new

id = 56 # Integer | Kur nesnesinin id değeri

currency = SwaggerClient::Currency.new # Currency |  nesnesi


begin
  #Kur Güncelleme
  result = api_instance.currencies_id_put(id, currency)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CurrencyApi->currencies_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Kur nesnesinin id değeri | 
 **currency** | [**Currency**](Currency.md)|  nesnesi | 

### Return type

[**Currency**](Currency.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



