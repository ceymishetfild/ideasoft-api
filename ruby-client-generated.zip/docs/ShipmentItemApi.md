# SwaggerClient::ShipmentItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipment_items_get**](ShipmentItemApi.md#shipment_items_get) | **GET** /shipment_items | Teslimat Kalemi Listesi Alma
[**shipment_items_id_delete**](ShipmentItemApi.md#shipment_items_id_delete) | **DELETE** /shipment_items/{id} | Teslimat Kalemi Silme
[**shipment_items_id_get**](ShipmentItemApi.md#shipment_items_id_get) | **GET** /shipment_items/{id} | Teslimat Kalemi Alma
[**shipment_items_id_put**](ShipmentItemApi.md#shipment_items_id_put) | **PUT** /shipment_items/{id} | Teslimat Kalemi Güncelleme
[**shipment_items_post**](ShipmentItemApi.md#shipment_items_post) | **POST** /shipment_items | Teslimat Kalemi Oluşturma


# **shipment_items_get**
> ShipmentItem shipment_items_get(opts)

Teslimat Kalemi Listesi Alma

Teslimat Kalemi listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShipmentItemApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  product: 56, # Integer | Ürün id
  shipment: 56, # Integer | Teslimat id
  order_item: 56, # Integer | Sipariş kalemi id
  start_date: Date.parse("2013-10-20"), # Date | createdAt değeri için başlangıç tarihi
  end_date: "end_date_example", # String | createdAt değeri için bitiş tarihi
  start_updated_at: Date.parse("2013-10-20"), # Date | updatedAt değeri için başlangıç tarihi
  end_updated_at: "end_updated_at_example" # String | updatedAt değeri için bitiş tarihi
}

begin
  #Teslimat Kalemi Listesi Alma
  result = api_instance.shipment_items_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShipmentItemApi->shipment_items_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **product** | **Integer**| Ürün id | [optional] 
 **shipment** | **Integer**| Teslimat id | [optional] 
 **order_item** | **Integer**| Sipariş kalemi id | [optional] 
 **start_date** | **Date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **String**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **Date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **String**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipment_items_id_delete**
> shipment_items_id_delete(id)

Teslimat Kalemi Silme

Kalıcı olarak ilgili Teslimat Kalemini siler.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShipmentItemApi.new

id = 56 # Integer | Teslimat Kalemi nesnesinin id değeri


begin
  #Teslimat Kalemi Silme
  api_instance.shipment_items_id_delete(id)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShipmentItemApi->shipment_items_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Teslimat Kalemi nesnesinin id değeri | 

### Return type

nil (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipment_items_id_get**
> ShipmentItem shipment_items_id_get(id)

Teslimat Kalemi Alma

İlgili Teslimat Kalemini getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShipmentItemApi.new

id = 56 # Integer | Teslimat Kalemi nesnesinin id değeri


begin
  #Teslimat Kalemi Alma
  result = api_instance.shipment_items_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShipmentItemApi->shipment_items_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Teslimat Kalemi nesnesinin id değeri | 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipment_items_id_put**
> ShipmentItem shipment_items_id_put(id, shipment_item)

Teslimat Kalemi Güncelleme

İlgili Teslimat Kalemini günceller.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShipmentItemApi.new

id = 56 # Integer | Teslimat Kalemi nesnesinin id değeri

shipment_item = SwaggerClient::ShipmentItem.new # ShipmentItem | ShipmentItem nesnesi


begin
  #Teslimat Kalemi Güncelleme
  result = api_instance.shipment_items_id_put(id, shipment_item)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShipmentItemApi->shipment_items_id_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Teslimat Kalemi nesnesinin id değeri | 
 **shipment_item** | [**ShipmentItem**](ShipmentItem.md)| ShipmentItem nesnesi | 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **shipment_items_post**
> ShipmentItem shipment_items_post(shipment_item)

Teslimat Kalemi Oluşturma

Yeni bir Teslimat Kalemi oluşturur.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::ShipmentItemApi.new

shipment_item = SwaggerClient::ShipmentItem.new # ShipmentItem | ShipmentItem nesnesi


begin
  #Teslimat Kalemi Oluşturma
  result = api_instance.shipment_items_post(shipment_item)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ShipmentItemApi->shipment_items_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipment_item** | [**ShipmentItem**](ShipmentItem.md)| ShipmentItem nesnesi | 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



