# SwaggerClient::InstallmentRateApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**installment_rates_get**](InstallmentRateApi.md#installment_rates_get) | **GET** /installment_rates | Taksit Oranı Listesi Alma
[**installment_rates_id_get**](InstallmentRateApi.md#installment_rates_id_get) | **GET** /installment_rates/{id} | Taksit Oranı Alma


# **installment_rates_get**
> InstallmentRate installment_rates_get(opts)

Taksit Oranı Listesi Alma

Taksit Oranı listesini verir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::InstallmentRateApi.new

opts = { 
  sort: "sort_example", # String | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> 
  limit: 20, # Integer | Bir sayfada gelecek sonuç adedi
  page: 1, # Integer | Hangi sayfadan başlanacağı
  since_id: 56, # Integer | Yalnızca belirtilen id değerinden sonraki kayıtları getirir 
  payment_gateway: 56 # Integer | Ödeme Kanalı id
}

begin
  #Taksit Oranı Listesi Alma
  result = api_instance.installment_rates_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling InstallmentRateApi->installment_rates_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **String**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **Integer**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **Integer**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **Integer**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **payment_gateway** | **Integer**| Ödeme Kanalı id | [optional] 

### Return type

[**InstallmentRate**](InstallmentRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **installment_rates_id_get**
> InstallmentRate installment_rates_id_get(id)

Taksit Oranı Alma

İlgili Taksit Oranını getirir.

### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure OAuth2 access token for authorization: OAuth2
  config.access_token = 'YOUR ACCESS TOKEN'
end

api_instance = SwaggerClient::InstallmentRateApi.new

id = 56 # Integer | Taksit Oranı nesnesinin id değeri


begin
  #Taksit Oranı Alma
  result = api_instance.installment_rates_id_get(id)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling InstallmentRateApi->installment_rates_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**| Taksit Oranı nesnesinin id değeri | 

### Return type

[**InstallmentRate**](InstallmentRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



