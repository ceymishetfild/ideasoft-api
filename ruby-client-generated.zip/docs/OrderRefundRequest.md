# SwaggerClient::OrderRefundRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Sipariş iptal talebi nesnesi kimlik değeri. | [optional] 
**code** | **String** | Sipariş iptal talebi için oluşturulan benzersiz kod değeri. | 
**status** | **String** | Sipariş iptal talebi için durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı.&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor.&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi.&lt;br&gt;&lt;/div&gt; | 
**fee** | **Float** | Müşteriye ödenecek miktar bilgisi. | 
**cancellation_reason** | **String** | Sipariş iptal talebinin oluşturulması sebebinin detaylı açıklaması. | [optional] 
**created_at** | **DateTime** | Sipariş iptal talebi nesnesinin oluşturulma zamanı. | 
**updated_at** | **DateTime** | Sipariş iptal talebi nesnesinin güncellenme zamanı. | 
**member** | [**Member**](Member.md) |  | [optional] 
**order** | [**Order**](Order.md) |  | [optional] 


