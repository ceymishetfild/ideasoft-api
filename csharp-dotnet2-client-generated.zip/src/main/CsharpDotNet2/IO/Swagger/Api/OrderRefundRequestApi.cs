using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IOrderRefundRequestApi
    {
        /// <summary>
        /// Sipariş İptal Talebi Listesi Alma Sipariş İptal Talebi listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="order">Sipariş id</param>
        /// <param name="member">Üye id</param>
        /// <param name="code">Sipariş İptal Talebi kodu</param>
        /// <param name="status">Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi</param>
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param>
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param>
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param>
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param>
        /// <returns>OrderRefundRequest</returns>
        OrderRefundRequest OrderRefundRequestsGet (string sort, int? limit, int? page, int? sinceId, int? order, int? member, string code, string status, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt);
        /// <summary>
        /// Sipariş İptal Talebi Silme Kalıcı olarak ilgili Sipariş İptal Talebini siler.
        /// </summary>
        /// <param name="id">Sipariş İptal Talebi nesnesinin id değeri</param>
        /// <returns></returns>
        void OrderRefundRequestsIdDelete (int? id);
        /// <summary>
        /// Sipariş İptal Talebi Alma İlgili Sipariş İptal Talebini getirir.
        /// </summary>
        /// <param name="id">Sipariş İptal Talebi nesnesinin id değeri</param>
        /// <returns>OrderRefundRequest</returns>
        OrderRefundRequest OrderRefundRequestsIdGet (int? id);
        /// <summary>
        /// Sipariş İptal Talebi Güncelleme İlgili Sipariş İptal Talebini günceller.
        /// </summary>
        /// <param name="id">Sipariş İptal Talebi nesnesinin id değeri</param>
        /// <param name="orderRefundRequest">OrderRefundRequest nesnesi</param>
        /// <returns>OrderRefundRequest</returns>
        OrderRefundRequest OrderRefundRequestsIdPut (int? id, OrderRefundRequest orderRefundRequest);
        /// <summary>
        /// Sipariş İptal Talebi Oluşturma Yeni bir Sipariş İptal Talebi oluşturur.
        /// </summary>
        /// <param name="orderRefundRequest">OrderRefundRequest nesnesi</param>
        /// <returns>OrderRefundRequest</returns>
        OrderRefundRequest OrderRefundRequestsPost (OrderRefundRequest orderRefundRequest);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class OrderRefundRequestApi : IOrderRefundRequestApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OrderRefundRequestApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public OrderRefundRequestApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="OrderRefundRequestApi"/> class.
        /// </summary>
        /// <returns></returns>
        public OrderRefundRequestApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Sipariş İptal Talebi Listesi Alma Sipariş İptal Talebi listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="order">Sipariş id</param> 
        /// <param name="member">Üye id</param> 
        /// <param name="code">Sipariş İptal Talebi kodu</param> 
        /// <param name="status">Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi</param> 
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param> 
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param> 
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param> 
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param> 
        /// <returns>OrderRefundRequest</returns>            
        public OrderRefundRequest OrderRefundRequestsGet (string sort, int? limit, int? page, int? sinceId, int? order, int? member, string code, string status, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)
        {
            
    
            var path = "/order_refund_requests";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (order != null) queryParams.Add("order", ApiClient.ParameterToString(order)); // query parameter
 if (member != null) queryParams.Add("member", ApiClient.ParameterToString(member)); // query parameter
 if (code != null) queryParams.Add("code", ApiClient.ParameterToString(code)); // query parameter
 if (status != null) queryParams.Add("status", ApiClient.ParameterToString(status)); // query parameter
 if (startDate != null) queryParams.Add("startDate", ApiClient.ParameterToString(startDate)); // query parameter
 if (endDate != null) queryParams.Add("endDate", ApiClient.ParameterToString(endDate)); // query parameter
 if (startUpdatedAt != null) queryParams.Add("startUpdatedAt", ApiClient.ParameterToString(startUpdatedAt)); // query parameter
 if (endUpdatedAt != null) queryParams.Add("endUpdatedAt", ApiClient.ParameterToString(endUpdatedAt)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OrderRefundRequest) ApiClient.Deserialize(response.Content, typeof(OrderRefundRequest), response.Headers);
        }
    
        /// <summary>
        /// Sipariş İptal Talebi Silme Kalıcı olarak ilgili Sipariş İptal Talebini siler.
        /// </summary>
        /// <param name="id">Sipariş İptal Talebi nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void OrderRefundRequestsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OrderRefundRequestsIdDelete");
            
    
            var path = "/order_refund_requests/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Sipariş İptal Talebi Alma İlgili Sipariş İptal Talebini getirir.
        /// </summary>
        /// <param name="id">Sipariş İptal Talebi nesnesinin id değeri</param> 
        /// <returns>OrderRefundRequest</returns>            
        public OrderRefundRequest OrderRefundRequestsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OrderRefundRequestsIdGet");
            
    
            var path = "/order_refund_requests/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OrderRefundRequest) ApiClient.Deserialize(response.Content, typeof(OrderRefundRequest), response.Headers);
        }
    
        /// <summary>
        /// Sipariş İptal Talebi Güncelleme İlgili Sipariş İptal Talebini günceller.
        /// </summary>
        /// <param name="id">Sipariş İptal Talebi nesnesinin id değeri</param> 
        /// <param name="orderRefundRequest">OrderRefundRequest nesnesi</param> 
        /// <returns>OrderRefundRequest</returns>            
        public OrderRefundRequest OrderRefundRequestsIdPut (int? id, OrderRefundRequest orderRefundRequest)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OrderRefundRequestsIdPut");
            
            // verify the required parameter 'orderRefundRequest' is set
            if (orderRefundRequest == null) throw new ApiException(400, "Missing required parameter 'orderRefundRequest' when calling OrderRefundRequestsIdPut");
            
    
            var path = "/order_refund_requests/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(orderRefundRequest); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OrderRefundRequest) ApiClient.Deserialize(response.Content, typeof(OrderRefundRequest), response.Headers);
        }
    
        /// <summary>
        /// Sipariş İptal Talebi Oluşturma Yeni bir Sipariş İptal Talebi oluşturur.
        /// </summary>
        /// <param name="orderRefundRequest">OrderRefundRequest nesnesi</param> 
        /// <returns>OrderRefundRequest</returns>            
        public OrderRefundRequest OrderRefundRequestsPost (OrderRefundRequest orderRefundRequest)
        {
            
            // verify the required parameter 'orderRefundRequest' is set
            if (orderRefundRequest == null) throw new ApiException(400, "Missing required parameter 'orderRefundRequest' when calling OrderRefundRequestsPost");
            
    
            var path = "/order_refund_requests";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(orderRefundRequest); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OrderRefundRequest) ApiClient.Deserialize(response.Content, typeof(OrderRefundRequest), response.Headers);
        }
    
    }
}
