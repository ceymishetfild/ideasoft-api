using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IFavouritedProductApi
    {
        /// <summary>
        /// Favori Ürün Listesi Alma Favori Ürün listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="product">Ürün id</param>
        /// <returns>FavouritedProduct</returns>
        FavouritedProduct FavouritedProductsGet (string sort, int? limit, int? page, int? sinceId, int? product);
        /// <summary>
        /// Favori Ürün Silme Kalıcı olarak ilgili Favori Ürünü siler.
        /// </summary>
        /// <param name="id">Favori Ürün nesnesinin id değeri</param>
        /// <returns></returns>
        void FavouritedProductsIdDelete (int? id);
        /// <summary>
        /// Favori Ürün Alma İlgili Favori Ürünü getirir.
        /// </summary>
        /// <param name="id">Favori Ürün nesnesinin id değeri</param>
        /// <returns>FavouritedProduct</returns>
        FavouritedProduct FavouritedProductsIdGet (int? id);
        /// <summary>
        /// Favori Ürün Güncelleme İlgili Favori Ürünü günceller.
        /// </summary>
        /// <param name="id">Favori Ürün nesnesinin id değeri</param>
        /// <param name="favouritedProduct">FavouritedProduct nesnesi</param>
        /// <returns>FavouritedProduct</returns>
        FavouritedProduct FavouritedProductsIdPut (int? id, FavouritedProduct favouritedProduct);
        /// <summary>
        /// Favori Ürün Oluşturma Yeni bir Favori Ürün oluşturur.
        /// </summary>
        /// <param name="favouritedProduct">FavouritedProduct nesnesi</param>
        /// <returns>FavouritedProduct</returns>
        FavouritedProduct FavouritedProductsPost (FavouritedProduct favouritedProduct);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class FavouritedProductApi : IFavouritedProductApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FavouritedProductApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public FavouritedProductApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="FavouritedProductApi"/> class.
        /// </summary>
        /// <returns></returns>
        public FavouritedProductApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Favori Ürün Listesi Alma Favori Ürün listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="product">Ürün id</param> 
        /// <returns>FavouritedProduct</returns>            
        public FavouritedProduct FavouritedProductsGet (string sort, int? limit, int? page, int? sinceId, int? product)
        {
            
    
            var path = "/favourited_products";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (product != null) queryParams.Add("product", ApiClient.ParameterToString(product)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling FavouritedProductsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling FavouritedProductsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (FavouritedProduct) ApiClient.Deserialize(response.Content, typeof(FavouritedProduct), response.Headers);
        }
    
        /// <summary>
        /// Favori Ürün Silme Kalıcı olarak ilgili Favori Ürünü siler.
        /// </summary>
        /// <param name="id">Favori Ürün nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void FavouritedProductsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling FavouritedProductsIdDelete");
            
    
            var path = "/favourited_products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling FavouritedProductsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling FavouritedProductsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Favori Ürün Alma İlgili Favori Ürünü getirir.
        /// </summary>
        /// <param name="id">Favori Ürün nesnesinin id değeri</param> 
        /// <returns>FavouritedProduct</returns>            
        public FavouritedProduct FavouritedProductsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling FavouritedProductsIdGet");
            
    
            var path = "/favourited_products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling FavouritedProductsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling FavouritedProductsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (FavouritedProduct) ApiClient.Deserialize(response.Content, typeof(FavouritedProduct), response.Headers);
        }
    
        /// <summary>
        /// Favori Ürün Güncelleme İlgili Favori Ürünü günceller.
        /// </summary>
        /// <param name="id">Favori Ürün nesnesinin id değeri</param> 
        /// <param name="favouritedProduct">FavouritedProduct nesnesi</param> 
        /// <returns>FavouritedProduct</returns>            
        public FavouritedProduct FavouritedProductsIdPut (int? id, FavouritedProduct favouritedProduct)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling FavouritedProductsIdPut");
            
            // verify the required parameter 'favouritedProduct' is set
            if (favouritedProduct == null) throw new ApiException(400, "Missing required parameter 'favouritedProduct' when calling FavouritedProductsIdPut");
            
    
            var path = "/favourited_products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(favouritedProduct); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling FavouritedProductsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling FavouritedProductsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (FavouritedProduct) ApiClient.Deserialize(response.Content, typeof(FavouritedProduct), response.Headers);
        }
    
        /// <summary>
        /// Favori Ürün Oluşturma Yeni bir Favori Ürün oluşturur.
        /// </summary>
        /// <param name="favouritedProduct">FavouritedProduct nesnesi</param> 
        /// <returns>FavouritedProduct</returns>            
        public FavouritedProduct FavouritedProductsPost (FavouritedProduct favouritedProduct)
        {
            
            // verify the required parameter 'favouritedProduct' is set
            if (favouritedProduct == null) throw new ApiException(400, "Missing required parameter 'favouritedProduct' when calling FavouritedProductsPost");
            
    
            var path = "/favourited_products";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(favouritedProduct); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling FavouritedProductsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling FavouritedProductsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (FavouritedProduct) ApiClient.Deserialize(response.Content, typeof(FavouritedProduct), response.Headers);
        }
    
    }
}
