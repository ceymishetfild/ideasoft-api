using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IThemeApi
    {
        /// <summary>
        /// Tema Listesi Alma Tema listesi verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;</param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir</param>
        /// <param name="status">Tema durumu</param>
        /// <param name="platform">Tema platformu</param>
        /// <param name="type">Tema tipi</param>
        /// <returns>Theme</returns>
        Theme ThemesGet (string sort, int? limit, int? page, int? sinceId, int? status, string platform, string type);
        /// <summary>
        /// Tema Dosyası Listesi Alma Tema Dosyası listesi verir.
        /// </summary>
        /// <param name="id">Tema nesnesinin id değeri</param>
        /// <param name="key">Tema Dosyası nesnesi anahtar değeri.</param>
        /// <returns>Asset</returns>
        Asset ThemesIdAssetsGet (int? id, string key);
        /// <summary>
        /// Tema Dosyası Silme Kalıcı olarak ilgili Tema Dosyasını siler.
        /// </summary>
        /// <param name="id">Tema nesnesinin id değeri</param>
        /// <param name="key">Tema Dosyası nesnesi anahtar değeri.</param>
        /// <returns></returns>
        void ThemesIdAssetskeykeyDelete (int? id, string key);
        /// <summary>
        /// Tema Dosyası Alma İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur.
        /// </summary>
        /// <param name="id">Tema nesnesinin id değeri</param>
        /// <param name="key">Tema Dosyası nesnesi anahtar değeri.</param>
        /// <returns>Asset</returns>
        Asset ThemesIdAssetskeykeyGet (int? id, string key);
        /// <summary>
        /// Tema Dosyası Güncelleme Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller.
        /// </summary>
        /// <param name="id">Tema nesnesinin id değeri</param>
        /// <param name="theme">Theme nesnesi</param>
        /// <param name="asset">Asset nesnesi</param>
        /// <returns>Asset</returns>
        Asset ThemesIdAssetskeykeyPut (int? id, Theme theme, Asset asset);
        /// <summary>
        /// Tema Silme Kalıcı olarak ilgili Temayı siler.
        /// </summary>
        /// <param name="id">Tema nesnesinin id değeri</param>
        /// <returns></returns>
        void ThemesIdDelete (int? id);
        /// <summary>
        /// Tema Alma İlgili Temayı getirir.
        /// </summary>
        /// <param name="id">Tema nesnesinin id değeri</param>
        /// <returns>Theme</returns>
        Theme ThemesIdGet (int? id);
        /// <summary>
        /// Tema Güncelleme İlgili Temayı günceller.
        /// </summary>
        /// <param name="id">Tema nesnesinin id değeri</param>
        /// <param name="theme">Theme nesnesi</param>
        /// <returns>Theme</returns>
        Theme ThemesIdPut (int? id, Theme theme);
        /// <summary>
        /// Tema Oluşturma Yeni bir tema oluşturur.
        /// </summary>
        /// <param name="theme">Theme nesnesi</param>
        /// <returns>Theme</returns>
        Theme ThemesPost (Theme theme);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class ThemeApi : IThemeApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ThemeApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public ThemeApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="ThemeApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ThemeApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Tema Listesi Alma Tema listesi verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;</param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir</param> 
        /// <param name="status">Tema durumu</param> 
        /// <param name="platform">Tema platformu</param> 
        /// <param name="type">Tema tipi</param> 
        /// <returns>Theme</returns>            
        public Theme ThemesGet (string sort, int? limit, int? page, int? sinceId, int? status, string platform, string type)
        {
            
    
            var path = "/themes";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (status != null) queryParams.Add("status", ApiClient.ParameterToString(status)); // query parameter
 if (platform != null) queryParams.Add("platform", ApiClient.ParameterToString(platform)); // query parameter
 if (type != null) queryParams.Add("type", ApiClient.ParameterToString(type)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Theme) ApiClient.Deserialize(response.Content, typeof(Theme), response.Headers);
        }
    
        /// <summary>
        /// Tema Dosyası Listesi Alma Tema Dosyası listesi verir.
        /// </summary>
        /// <param name="id">Tema nesnesinin id değeri</param> 
        /// <param name="key">Tema Dosyası nesnesi anahtar değeri.</param> 
        /// <returns>Asset</returns>            
        public Asset ThemesIdAssetsGet (int? id, string key)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ThemesIdAssetsGet");
            
    
            var path = "/themes/{id}/assets";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (key != null) queryParams.Add("key", ApiClient.ParameterToString(key)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesIdAssetsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesIdAssetsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Asset) ApiClient.Deserialize(response.Content, typeof(Asset), response.Headers);
        }
    
        /// <summary>
        /// Tema Dosyası Silme Kalıcı olarak ilgili Tema Dosyasını siler.
        /// </summary>
        /// <param name="id">Tema nesnesinin id değeri</param> 
        /// <param name="key">Tema Dosyası nesnesi anahtar değeri.</param> 
        /// <returns></returns>            
        public void ThemesIdAssetskeykeyDelete (int? id, string key)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ThemesIdAssetskeykeyDelete");
            
            // verify the required parameter 'key' is set
            if (key == null) throw new ApiException(400, "Missing required parameter 'key' when calling ThemesIdAssetskeykeyDelete");
            
    
            var path = "/themes/{id}/assets?key={key}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (key != null) queryParams.Add("key", ApiClient.ParameterToString(key)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesIdAssetskeykeyDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesIdAssetskeykeyDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Tema Dosyası Alma İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur.
        /// </summary>
        /// <param name="id">Tema nesnesinin id değeri</param> 
        /// <param name="key">Tema Dosyası nesnesi anahtar değeri.</param> 
        /// <returns>Asset</returns>            
        public Asset ThemesIdAssetskeykeyGet (int? id, string key)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ThemesIdAssetskeykeyGet");
            
            // verify the required parameter 'key' is set
            if (key == null) throw new ApiException(400, "Missing required parameter 'key' when calling ThemesIdAssetskeykeyGet");
            
    
            var path = "/themes/{id}/assets?key={key}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (key != null) queryParams.Add("key", ApiClient.ParameterToString(key)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesIdAssetskeykeyGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesIdAssetskeykeyGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Asset) ApiClient.Deserialize(response.Content, typeof(Asset), response.Headers);
        }
    
        /// <summary>
        /// Tema Dosyası Güncelleme Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller.
        /// </summary>
        /// <param name="id">Tema nesnesinin id değeri</param> 
        /// <param name="theme">Theme nesnesi</param> 
        /// <param name="asset">Asset nesnesi</param> 
        /// <returns>Asset</returns>            
        public Asset ThemesIdAssetskeykeyPut (int? id, Theme theme, Asset asset)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ThemesIdAssetskeykeyPut");
            
            // verify the required parameter 'theme' is set
            if (theme == null) throw new ApiException(400, "Missing required parameter 'theme' when calling ThemesIdAssetskeykeyPut");
            
            // verify the required parameter 'asset' is set
            if (asset == null) throw new ApiException(400, "Missing required parameter 'asset' when calling ThemesIdAssetskeykeyPut");
            
    
            var path = "/themes/{id}/assets?key={key}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(asset); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesIdAssetskeykeyPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesIdAssetskeykeyPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Asset) ApiClient.Deserialize(response.Content, typeof(Asset), response.Headers);
        }
    
        /// <summary>
        /// Tema Silme Kalıcı olarak ilgili Temayı siler.
        /// </summary>
        /// <param name="id">Tema nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void ThemesIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ThemesIdDelete");
            
    
            var path = "/themes/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Tema Alma İlgili Temayı getirir.
        /// </summary>
        /// <param name="id">Tema nesnesinin id değeri</param> 
        /// <returns>Theme</returns>            
        public Theme ThemesIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ThemesIdGet");
            
    
            var path = "/themes/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Theme) ApiClient.Deserialize(response.Content, typeof(Theme), response.Headers);
        }
    
        /// <summary>
        /// Tema Güncelleme İlgili Temayı günceller.
        /// </summary>
        /// <param name="id">Tema nesnesinin id değeri</param> 
        /// <param name="theme">Theme nesnesi</param> 
        /// <returns>Theme</returns>            
        public Theme ThemesIdPut (int? id, Theme theme)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ThemesIdPut");
            
            // verify the required parameter 'theme' is set
            if (theme == null) throw new ApiException(400, "Missing required parameter 'theme' when calling ThemesIdPut");
            
    
            var path = "/themes/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(theme); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Theme) ApiClient.Deserialize(response.Content, typeof(Theme), response.Headers);
        }
    
        /// <summary>
        /// Tema Oluşturma Yeni bir tema oluşturur.
        /// </summary>
        /// <param name="theme">Theme nesnesi</param> 
        /// <returns>Theme</returns>            
        public Theme ThemesPost (Theme theme)
        {
            
            // verify the required parameter 'theme' is set
            if (theme == null) throw new ApiException(400, "Missing required parameter 'theme' when calling ThemesPost");
            
    
            var path = "/themes";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(theme); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ThemesPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Theme) ApiClient.Deserialize(response.Content, typeof(Theme), response.Headers);
        }
    
    }
}
