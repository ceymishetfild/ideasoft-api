using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ISpecToProductApi
    {
        /// <summary>
        /// Ürün Özellik Ürün Bağı Listesi Alma Ürün Özellik Ürün Bağı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param>
        /// <param name="product">Ürün id</param>
        /// <param name="specGroup">Ürün özellik grubu id</param>
        /// <param name="specName">Ürün özellik id</param>
        /// <param name="specValue">Ürün özellik değeri id</param>
        /// <returns>SpecToProduct</returns>
        SpecToProduct SpecToProductsGet (string sort, int? limit, int? page, int? sinceId, string ids, int? product, int? specGroup, int? specName, int? specValue);
        /// <summary>
        /// Ürün Özellik Ürün Bağı Silme Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler.
        /// </summary>
        /// <param name="id">Ürün Özellik Ürün Bağı nesnesinin id değeri</param>
        /// <returns></returns>
        void SpecToProductsIdDelete (int? id);
        /// <summary>
        /// Ürün Özellik Ürün Bağı Alma İlgili Ürün Özellik Ürün Bağını getirir.
        /// </summary>
        /// <param name="id">Ürün Özellik Ürün Bağı nesnesinin id değeri</param>
        /// <returns>SpecToProduct</returns>
        SpecToProduct SpecToProductsIdGet (int? id);
        /// <summary>
        /// Ürün Özellik Ürün Bağı Güncelleme İlgili Ürün Özellik Ürün Bağını günceller.
        /// </summary>
        /// <param name="id">Ürün Özellik Ürün Bağı nesnesinin id değeri</param>
        /// <param name="specToProduct"> nesnesi</param>
        /// <returns>SpecToProduct</returns>
        SpecToProduct SpecToProductsIdPut (int? id, SpecToProduct specToProduct);
        /// <summary>
        /// Ürün Özellik Ürün Bağı Oluşturma Yeni bir Ürün Özellik Ürün Bağı oluşturur.
        /// </summary>
        /// <param name="specToProduct"> nesnesi</param>
        /// <returns>SpecToProduct</returns>
        SpecToProduct SpecToProductsPost (SpecToProduct specToProduct);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class SpecToProductApi : ISpecToProductApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SpecToProductApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public SpecToProductApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="SpecToProductApi"/> class.
        /// </summary>
        /// <returns></returns>
        public SpecToProductApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ürün Özellik Ürün Bağı Listesi Alma Ürün Özellik Ürün Bağı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param> 
        /// <param name="product">Ürün id</param> 
        /// <param name="specGroup">Ürün özellik grubu id</param> 
        /// <param name="specName">Ürün özellik id</param> 
        /// <param name="specValue">Ürün özellik değeri id</param> 
        /// <returns>SpecToProduct</returns>            
        public SpecToProduct SpecToProductsGet (string sort, int? limit, int? page, int? sinceId, string ids, int? product, int? specGroup, int? specName, int? specValue)
        {
            
    
            var path = "/spec_to_products";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (ids != null) queryParams.Add("ids", ApiClient.ParameterToString(ids)); // query parameter
 if (product != null) queryParams.Add("product", ApiClient.ParameterToString(product)); // query parameter
 if (specGroup != null) queryParams.Add("specGroup", ApiClient.ParameterToString(specGroup)); // query parameter
 if (specName != null) queryParams.Add("specName", ApiClient.ParameterToString(specName)); // query parameter
 if (specValue != null) queryParams.Add("specValue", ApiClient.ParameterToString(specValue)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecToProductsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecToProductsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecToProduct) ApiClient.Deserialize(response.Content, typeof(SpecToProduct), response.Headers);
        }
    
        /// <summary>
        /// Ürün Özellik Ürün Bağı Silme Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler.
        /// </summary>
        /// <param name="id">Ürün Özellik Ürün Bağı nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void SpecToProductsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SpecToProductsIdDelete");
            
    
            var path = "/spec_to_products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecToProductsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecToProductsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Ürün Özellik Ürün Bağı Alma İlgili Ürün Özellik Ürün Bağını getirir.
        /// </summary>
        /// <param name="id">Ürün Özellik Ürün Bağı nesnesinin id değeri</param> 
        /// <returns>SpecToProduct</returns>            
        public SpecToProduct SpecToProductsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SpecToProductsIdGet");
            
    
            var path = "/spec_to_products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecToProductsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecToProductsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecToProduct) ApiClient.Deserialize(response.Content, typeof(SpecToProduct), response.Headers);
        }
    
        /// <summary>
        /// Ürün Özellik Ürün Bağı Güncelleme İlgili Ürün Özellik Ürün Bağını günceller.
        /// </summary>
        /// <param name="id">Ürün Özellik Ürün Bağı nesnesinin id değeri</param> 
        /// <param name="specToProduct"> nesnesi</param> 
        /// <returns>SpecToProduct</returns>            
        public SpecToProduct SpecToProductsIdPut (int? id, SpecToProduct specToProduct)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SpecToProductsIdPut");
            
            // verify the required parameter 'specToProduct' is set
            if (specToProduct == null) throw new ApiException(400, "Missing required parameter 'specToProduct' when calling SpecToProductsIdPut");
            
    
            var path = "/spec_to_products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(specToProduct); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecToProductsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecToProductsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecToProduct) ApiClient.Deserialize(response.Content, typeof(SpecToProduct), response.Headers);
        }
    
        /// <summary>
        /// Ürün Özellik Ürün Bağı Oluşturma Yeni bir Ürün Özellik Ürün Bağı oluşturur.
        /// </summary>
        /// <param name="specToProduct"> nesnesi</param> 
        /// <returns>SpecToProduct</returns>            
        public SpecToProduct SpecToProductsPost (SpecToProduct specToProduct)
        {
            
            // verify the required parameter 'specToProduct' is set
            if (specToProduct == null) throw new ApiException(400, "Missing required parameter 'specToProduct' when calling SpecToProductsPost");
            
    
            var path = "/spec_to_products";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(specToProduct); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecToProductsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecToProductsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecToProduct) ApiClient.Deserialize(response.Content, typeof(SpecToProduct), response.Headers);
        }
    
    }
}
