using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IMemberApi
    {
        /// <summary>
        /// Üye Grafik Aksiyonu Zaman bazında üye genel istatistiklerini getirir.
        /// </summary>
        /// <param name="timeFrame">Şu değerleri olabilir: full, year, month or week</param>
        /// <param name="startDate">Zaman aralığının başlangıcı</param>
        /// <returns>Member</returns>
        Member MembersChartsGet (string timeFrame, string startDate);
        /// <summary>
        /// Üye Birleşik Aksiyonu Bugün, aylık, yıllık ve toplam üye oturum açma istatistiklerini totalCount cinsinden getirir.
        /// </summary>
        /// <returns>Member</returns>
        Member MembersCombinedGet ();
        /// <summary>
        /// Üye Listesi Alma Üye listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="firstname">Adı</param>
        /// <param name="surname">Soyadı</param>
        /// <param name="email">e-mail adresi</param>
        /// <param name="password">Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri</param>
        /// <param name="gender">Cinsiyet şu değerleri alabilir: &lt;br&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın</param>
        /// <param name="mobilePhoneNumber">Üye mobil telefon numarası</param>
        /// <param name="phoneNumber">Üye telefon numarası</param>
        /// <param name="memberGroup">Üye Grubu id</param>
        /// <param name="location">Şehir id</param>
        /// <param name="country">Ülke id</param>
        /// <param name="referredMember">Tavsiye Üye id</param>
        /// <param name="q">Üye arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;]</param>
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param>
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param>
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param>
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param>
        /// <returns>Member</returns>
        Member MembersGet (string sort, int? limit, int? page, int? sinceId, string firstname, string surname, string email, string password, string gender, string mobilePhoneNumber, string phoneNumber, int? memberGroup, int? location, int? country, int? referredMember, List<string> q, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt);
        /// <summary>
        /// Üye Silme Kalıcı olarak ilgili Üyeyi siler.
        /// </summary>
        /// <param name="id">Üye nesnesinin id değeri</param>
        /// <returns></returns>
        void MembersIdDelete (int? id);
        /// <summary>
        /// Üye Alma İlgili Üyeyi getirir.
        /// </summary>
        /// <param name="id">Üye nesnesinin id değeri</param>
        /// <returns>Member</returns>
        Member MembersIdGet (int? id);
        /// <summary>
        /// Üye Güncelleme İlgili Üyeyi günceller.
        /// </summary>
        /// <param name="id">Üye nesnesinin id değeri</param>
        /// <param name="member">Member nesnesi</param>
        /// <returns>Member</returns>
        Member MembersIdPut (int? id, Member member);
        /// <summary>
        /// Üye Oluşturma Yeni bir Üye oluşturur.
        /// </summary>
        /// <param name="member">Member nesnesi</param>
        /// <returns>Member</returns>
        Member MembersPost (Member member);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class MemberApi : IMemberApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MemberApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public MemberApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="MemberApi"/> class.
        /// </summary>
        /// <returns></returns>
        public MemberApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Üye Grafik Aksiyonu Zaman bazında üye genel istatistiklerini getirir.
        /// </summary>
        /// <param name="timeFrame">Şu değerleri olabilir: full, year, month or week</param> 
        /// <param name="startDate">Zaman aralığının başlangıcı</param> 
        /// <returns>Member</returns>            
        public Member MembersChartsGet (string timeFrame, string startDate)
        {
            
            // verify the required parameter 'timeFrame' is set
            if (timeFrame == null) throw new ApiException(400, "Missing required parameter 'timeFrame' when calling MembersChartsGet");
            
            // verify the required parameter 'startDate' is set
            if (startDate == null) throw new ApiException(400, "Missing required parameter 'startDate' when calling MembersChartsGet");
            
    
            var path = "/members/charts";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (timeFrame != null) queryParams.Add("timeFrame", ApiClient.ParameterToString(timeFrame)); // query parameter
 if (startDate != null) queryParams.Add("startDate", ApiClient.ParameterToString(startDate)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MembersChartsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MembersChartsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Member) ApiClient.Deserialize(response.Content, typeof(Member), response.Headers);
        }
    
        /// <summary>
        /// Üye Birleşik Aksiyonu Bugün, aylık, yıllık ve toplam üye oturum açma istatistiklerini totalCount cinsinden getirir.
        /// </summary>
        /// <returns>Member</returns>            
        public Member MembersCombinedGet ()
        {
            
    
            var path = "/members/combined";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MembersCombinedGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MembersCombinedGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Member) ApiClient.Deserialize(response.Content, typeof(Member), response.Headers);
        }
    
        /// <summary>
        /// Üye Listesi Alma Üye listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="firstname">Adı</param> 
        /// <param name="surname">Soyadı</param> 
        /// <param name="email">e-mail adresi</param> 
        /// <param name="password">Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri</param> 
        /// <param name="gender">Cinsiyet şu değerleri alabilir: &lt;br&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın</param> 
        /// <param name="mobilePhoneNumber">Üye mobil telefon numarası</param> 
        /// <param name="phoneNumber">Üye telefon numarası</param> 
        /// <param name="memberGroup">Üye Grubu id</param> 
        /// <param name="location">Şehir id</param> 
        /// <param name="country">Ülke id</param> 
        /// <param name="referredMember">Tavsiye Üye id</param> 
        /// <param name="q">Üye arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;]</param> 
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param> 
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param> 
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param> 
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param> 
        /// <returns>Member</returns>            
        public Member MembersGet (string sort, int? limit, int? page, int? sinceId, string firstname, string surname, string email, string password, string gender, string mobilePhoneNumber, string phoneNumber, int? memberGroup, int? location, int? country, int? referredMember, List<string> q, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)
        {
            
    
            var path = "/members";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (firstname != null) queryParams.Add("firstname", ApiClient.ParameterToString(firstname)); // query parameter
 if (surname != null) queryParams.Add("surname", ApiClient.ParameterToString(surname)); // query parameter
 if (email != null) queryParams.Add("email", ApiClient.ParameterToString(email)); // query parameter
 if (password != null) queryParams.Add("password", ApiClient.ParameterToString(password)); // query parameter
 if (gender != null) queryParams.Add("gender", ApiClient.ParameterToString(gender)); // query parameter
 if (mobilePhoneNumber != null) queryParams.Add("mobilePhoneNumber", ApiClient.ParameterToString(mobilePhoneNumber)); // query parameter
 if (phoneNumber != null) queryParams.Add("phoneNumber", ApiClient.ParameterToString(phoneNumber)); // query parameter
 if (memberGroup != null) queryParams.Add("memberGroup", ApiClient.ParameterToString(memberGroup)); // query parameter
 if (location != null) queryParams.Add("location", ApiClient.ParameterToString(location)); // query parameter
 if (country != null) queryParams.Add("country", ApiClient.ParameterToString(country)); // query parameter
 if (referredMember != null) queryParams.Add("referredMember", ApiClient.ParameterToString(referredMember)); // query parameter
 if (q != null) queryParams.Add("q", ApiClient.ParameterToString(q)); // query parameter
 if (startDate != null) queryParams.Add("startDate", ApiClient.ParameterToString(startDate)); // query parameter
 if (endDate != null) queryParams.Add("endDate", ApiClient.ParameterToString(endDate)); // query parameter
 if (startUpdatedAt != null) queryParams.Add("startUpdatedAt", ApiClient.ParameterToString(startUpdatedAt)); // query parameter
 if (endUpdatedAt != null) queryParams.Add("endUpdatedAt", ApiClient.ParameterToString(endUpdatedAt)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MembersGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MembersGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Member) ApiClient.Deserialize(response.Content, typeof(Member), response.Headers);
        }
    
        /// <summary>
        /// Üye Silme Kalıcı olarak ilgili Üyeyi siler.
        /// </summary>
        /// <param name="id">Üye nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void MembersIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling MembersIdDelete");
            
    
            var path = "/members/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MembersIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MembersIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Üye Alma İlgili Üyeyi getirir.
        /// </summary>
        /// <param name="id">Üye nesnesinin id değeri</param> 
        /// <returns>Member</returns>            
        public Member MembersIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling MembersIdGet");
            
    
            var path = "/members/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MembersIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MembersIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Member) ApiClient.Deserialize(response.Content, typeof(Member), response.Headers);
        }
    
        /// <summary>
        /// Üye Güncelleme İlgili Üyeyi günceller.
        /// </summary>
        /// <param name="id">Üye nesnesinin id değeri</param> 
        /// <param name="member">Member nesnesi</param> 
        /// <returns>Member</returns>            
        public Member MembersIdPut (int? id, Member member)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling MembersIdPut");
            
            // verify the required parameter 'member' is set
            if (member == null) throw new ApiException(400, "Missing required parameter 'member' when calling MembersIdPut");
            
    
            var path = "/members/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(member); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MembersIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MembersIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Member) ApiClient.Deserialize(response.Content, typeof(Member), response.Headers);
        }
    
        /// <summary>
        /// Üye Oluşturma Yeni bir Üye oluşturur.
        /// </summary>
        /// <param name="member">Member nesnesi</param> 
        /// <returns>Member</returns>            
        public Member MembersPost (Member member)
        {
            
            // verify the required parameter 'member' is set
            if (member == null) throw new ApiException(400, "Missing required parameter 'member' when calling MembersPost");
            
    
            var path = "/members";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(member); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MembersPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MembersPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Member) ApiClient.Deserialize(response.Content, typeof(Member), response.Headers);
        }
    
    }
}
