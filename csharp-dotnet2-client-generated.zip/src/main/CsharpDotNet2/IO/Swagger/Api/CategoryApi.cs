using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ICategoryApi
    {
        /// <summary>
        /// Kategori Listesi Alma Kategori listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="name">Kategori adı</param>
        /// <param name="status">Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif</param>
        /// <param name="distributor">Kategori Distribütör</param>
        /// <param name="parent">Üst kategori id</param>
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param>
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param>
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param>
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param>
        /// <returns>Category</returns>
        Category CategoriesGet (string sort, int? limit, int? page, int? sinceId, string name, int? status, string distributor, int? parent, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt);
        /// <summary>
        /// Kategori Silme Kalıcı olarak ilgili Kategoriyi siler.
        /// </summary>
        /// <param name="id">Kategori nesnesinin id değeri</param>
        /// <returns></returns>
        void CategoriesIdDelete (int? id);
        /// <summary>
        /// Kategori Alma İlgili Kategoriyi getirir.
        /// </summary>
        /// <param name="id">Kategori nesnesinin id değeri</param>
        /// <returns>Category</returns>
        Category CategoriesIdGet (int? id);
        /// <summary>
        /// Kategori Güncelleme İlgili Kategoriyi günceller.
        /// </summary>
        /// <param name="id">Kategori nesnesinin id değeri</param>
        /// <param name="category">Category nesnesi</param>
        /// <returns>Category</returns>
        Category CategoriesIdPut (int? id, Category category);
        /// <summary>
        /// Kategori Oluşturma Yeni bir Kategori oluşturur.
        /// </summary>
        /// <param name="category">Category nesnesi</param>
        /// <returns>Category</returns>
        Category CategoriesPost (Category category);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class CategoryApi : ICategoryApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CategoryApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public CategoryApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="CategoryApi"/> class.
        /// </summary>
        /// <returns></returns>
        public CategoryApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Kategori Listesi Alma Kategori listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="name">Kategori adı</param> 
        /// <param name="status">Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif</param> 
        /// <param name="distributor">Kategori Distribütör</param> 
        /// <param name="parent">Üst kategori id</param> 
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param> 
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param> 
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param> 
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param> 
        /// <returns>Category</returns>            
        public Category CategoriesGet (string sort, int? limit, int? page, int? sinceId, string name, int? status, string distributor, int? parent, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)
        {
            
    
            var path = "/categories";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (name != null) queryParams.Add("name", ApiClient.ParameterToString(name)); // query parameter
 if (status != null) queryParams.Add("status", ApiClient.ParameterToString(status)); // query parameter
 if (distributor != null) queryParams.Add("distributor", ApiClient.ParameterToString(distributor)); // query parameter
 if (parent != null) queryParams.Add("parent", ApiClient.ParameterToString(parent)); // query parameter
 if (startDate != null) queryParams.Add("startDate", ApiClient.ParameterToString(startDate)); // query parameter
 if (endDate != null) queryParams.Add("endDate", ApiClient.ParameterToString(endDate)); // query parameter
 if (startUpdatedAt != null) queryParams.Add("startUpdatedAt", ApiClient.ParameterToString(startUpdatedAt)); // query parameter
 if (endUpdatedAt != null) queryParams.Add("endUpdatedAt", ApiClient.ParameterToString(endUpdatedAt)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling CategoriesGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling CategoriesGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Category) ApiClient.Deserialize(response.Content, typeof(Category), response.Headers);
        }
    
        /// <summary>
        /// Kategori Silme Kalıcı olarak ilgili Kategoriyi siler.
        /// </summary>
        /// <param name="id">Kategori nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void CategoriesIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling CategoriesIdDelete");
            
    
            var path = "/categories/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling CategoriesIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling CategoriesIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Kategori Alma İlgili Kategoriyi getirir.
        /// </summary>
        /// <param name="id">Kategori nesnesinin id değeri</param> 
        /// <returns>Category</returns>            
        public Category CategoriesIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling CategoriesIdGet");
            
    
            var path = "/categories/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling CategoriesIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling CategoriesIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Category) ApiClient.Deserialize(response.Content, typeof(Category), response.Headers);
        }
    
        /// <summary>
        /// Kategori Güncelleme İlgili Kategoriyi günceller.
        /// </summary>
        /// <param name="id">Kategori nesnesinin id değeri</param> 
        /// <param name="category">Category nesnesi</param> 
        /// <returns>Category</returns>            
        public Category CategoriesIdPut (int? id, Category category)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling CategoriesIdPut");
            
            // verify the required parameter 'category' is set
            if (category == null) throw new ApiException(400, "Missing required parameter 'category' when calling CategoriesIdPut");
            
    
            var path = "/categories/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(category); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling CategoriesIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling CategoriesIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Category) ApiClient.Deserialize(response.Content, typeof(Category), response.Headers);
        }
    
        /// <summary>
        /// Kategori Oluşturma Yeni bir Kategori oluşturur.
        /// </summary>
        /// <param name="category">Category nesnesi</param> 
        /// <returns>Category</returns>            
        public Category CategoriesPost (Category category)
        {
            
            // verify the required parameter 'category' is set
            if (category == null) throw new ApiException(400, "Missing required parameter 'category' when calling CategoriesPost");
            
    
            var path = "/categories";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(category); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling CategoriesPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling CategoriesPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Category) ApiClient.Deserialize(response.Content, typeof(Category), response.Headers);
        }
    
    }
}
