using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IProductToCountDownApi
    {
        /// <summary>
        /// Ürün Geri Sayım Bağı Listesi Alma Ürün Geri Sayım Bağı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param>
        /// <param name="product">Ürün id</param>
        /// <returns>ProductToCountDown</returns>
        ProductToCountDown ProductToCountDownsGet (string sort, int? limit, int? page, int? sinceId, string ids, int? product);
        /// <summary>
        /// Ürün Geri Sayım Bağı Silme Kalıcı olarak ilgili Ürün Geri Sayım Bağını siler.
        /// </summary>
        /// <param name="id">Ürün Geri Sayım Bağı nesnesinin id değeri</param>
        /// <returns></returns>
        void ProductToCountDownsIdDelete (int? id);
        /// <summary>
        /// Ürün Geri Sayım Bağı Alma İlgili Ürün Geri Sayım Bağını getirir.
        /// </summary>
        /// <param name="id">Ürün Geri Sayım Bağı nesnesinin id değeri</param>
        /// <returns>ProductToCountDown</returns>
        ProductToCountDown ProductToCountDownsIdGet (int? id);
        /// <summary>
        /// Ürün Geri Sayım Bağı Güncelleme İlgili Ürün Geri Sayım Bağını günceller.
        /// </summary>
        /// <param name="id">Ürün Geri Sayım Bağı nesnesinin id değeri</param>
        /// <param name="productToCountDown"> nesnesi</param>
        /// <returns>ProductToCountDown</returns>
        ProductToCountDown ProductToCountDownsIdPut (int? id, ProductToCountDown productToCountDown);
        /// <summary>
        /// Ürün Geri Sayım Bağı Oluşturma Yeni bir Ürün Geri Sayım Bağı oluşturur.
        /// </summary>
        /// <param name="productToCountDown"> nesnesi</param>
        /// <returns>ProductToCountDown</returns>
        ProductToCountDown ProductToCountDownsPost (ProductToCountDown productToCountDown);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class ProductToCountDownApi : IProductToCountDownApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductToCountDownApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public ProductToCountDownApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductToCountDownApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ProductToCountDownApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ürün Geri Sayım Bağı Listesi Alma Ürün Geri Sayım Bağı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param> 
        /// <param name="product">Ürün id</param> 
        /// <returns>ProductToCountDown</returns>            
        public ProductToCountDown ProductToCountDownsGet (string sort, int? limit, int? page, int? sinceId, string ids, int? product)
        {
            
    
            var path = "/product_to_count_downs";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (ids != null) queryParams.Add("ids", ApiClient.ParameterToString(ids)); // query parameter
 if (product != null) queryParams.Add("product", ApiClient.ParameterToString(product)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCountDownsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCountDownsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductToCountDown) ApiClient.Deserialize(response.Content, typeof(ProductToCountDown), response.Headers);
        }
    
        /// <summary>
        /// Ürün Geri Sayım Bağı Silme Kalıcı olarak ilgili Ürün Geri Sayım Bağını siler.
        /// </summary>
        /// <param name="id">Ürün Geri Sayım Bağı nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void ProductToCountDownsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductToCountDownsIdDelete");
            
    
            var path = "/product_to_count_downs/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCountDownsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCountDownsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Ürün Geri Sayım Bağı Alma İlgili Ürün Geri Sayım Bağını getirir.
        /// </summary>
        /// <param name="id">Ürün Geri Sayım Bağı nesnesinin id değeri</param> 
        /// <returns>ProductToCountDown</returns>            
        public ProductToCountDown ProductToCountDownsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductToCountDownsIdGet");
            
    
            var path = "/product_to_count_downs/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCountDownsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCountDownsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductToCountDown) ApiClient.Deserialize(response.Content, typeof(ProductToCountDown), response.Headers);
        }
    
        /// <summary>
        /// Ürün Geri Sayım Bağı Güncelleme İlgili Ürün Geri Sayım Bağını günceller.
        /// </summary>
        /// <param name="id">Ürün Geri Sayım Bağı nesnesinin id değeri</param> 
        /// <param name="productToCountDown"> nesnesi</param> 
        /// <returns>ProductToCountDown</returns>            
        public ProductToCountDown ProductToCountDownsIdPut (int? id, ProductToCountDown productToCountDown)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductToCountDownsIdPut");
            
            // verify the required parameter 'productToCountDown' is set
            if (productToCountDown == null) throw new ApiException(400, "Missing required parameter 'productToCountDown' when calling ProductToCountDownsIdPut");
            
    
            var path = "/product_to_count_downs/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(productToCountDown); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCountDownsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCountDownsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductToCountDown) ApiClient.Deserialize(response.Content, typeof(ProductToCountDown), response.Headers);
        }
    
        /// <summary>
        /// Ürün Geri Sayım Bağı Oluşturma Yeni bir Ürün Geri Sayım Bağı oluşturur.
        /// </summary>
        /// <param name="productToCountDown"> nesnesi</param> 
        /// <returns>ProductToCountDown</returns>            
        public ProductToCountDown ProductToCountDownsPost (ProductToCountDown productToCountDown)
        {
            
            // verify the required parameter 'productToCountDown' is set
            if (productToCountDown == null) throw new ApiException(400, "Missing required parameter 'productToCountDown' when calling ProductToCountDownsPost");
            
    
            var path = "/product_to_count_downs";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(productToCountDown); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCountDownsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCountDownsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductToCountDown) ApiClient.Deserialize(response.Content, typeof(ProductToCountDown), response.Headers);
        }
    
    }
}
