using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IExtraInfoToProductApi
    {
        /// <summary>
        /// Ek Bilgi Ürün Bağı Listesi Alma Ek Bilgi Ürün Bağı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param>
        /// <param name="extraInfo">Ek bilgi id</param>
        /// <param name="product">Ürün id</param>
        /// <returns>ExtraInfoToProduct</returns>
        ExtraInfoToProduct ExtraInfoToProductsGet (string sort, int? limit, int? page, int? sinceId, string ids, int? extraInfo, int? product);
        /// <summary>
        /// Ek Bilgi Ürün Bağı Silme Kalıcı olarak ilgili Ek Bilgi Ürün Bağını siler.
        /// </summary>
        /// <param name="id">Ek Bilgi Ürün Bağı nesnesinin id değeri</param>
        /// <returns></returns>
        void ExtraInfoToProductsIdDelete (int? id);
        /// <summary>
        /// Ek Bilgi Ürün Bağı Alma İlgili Ek Bilgi Ürün Bağını getirir.
        /// </summary>
        /// <param name="id">Ek Bilgi Ürün Bağı nesnesinin id değeri</param>
        /// <returns>ExtraInfoToProduct</returns>
        ExtraInfoToProduct ExtraInfoToProductsIdGet (int? id);
        /// <summary>
        /// Ek Bilgi Ürün Bağı Güncelleme İlgili Ek Bilgi Ürün Bağını günceller.
        /// </summary>
        /// <param name="id">Ek Bilgi Ürün Bağı nesnesinin id değeri</param>
        /// <param name="extraInfoToProduct"> nesnesi</param>
        /// <returns>ExtraInfoToProduct</returns>
        ExtraInfoToProduct ExtraInfoToProductsIdPut (int? id, ExtraInfoToProduct extraInfoToProduct);
        /// <summary>
        /// Ek Bilgi Ürün Bağı Oluşturma Yeni bir Ek Bilgi Ürün Bağı oluşturur.
        /// </summary>
        /// <param name="extraInfoToProduct"> nesnesi</param>
        /// <returns>ExtraInfoToProduct</returns>
        ExtraInfoToProduct ExtraInfoToProductsPost (ExtraInfoToProduct extraInfoToProduct);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class ExtraInfoToProductApi : IExtraInfoToProductApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ExtraInfoToProductApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public ExtraInfoToProductApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="ExtraInfoToProductApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ExtraInfoToProductApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ek Bilgi Ürün Bağı Listesi Alma Ek Bilgi Ürün Bağı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param> 
        /// <param name="extraInfo">Ek bilgi id</param> 
        /// <param name="product">Ürün id</param> 
        /// <returns>ExtraInfoToProduct</returns>            
        public ExtraInfoToProduct ExtraInfoToProductsGet (string sort, int? limit, int? page, int? sinceId, string ids, int? extraInfo, int? product)
        {
            
    
            var path = "/extra_info_to_products";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (ids != null) queryParams.Add("ids", ApiClient.ParameterToString(ids)); // query parameter
 if (extraInfo != null) queryParams.Add("extraInfo", ApiClient.ParameterToString(extraInfo)); // query parameter
 if (product != null) queryParams.Add("product", ApiClient.ParameterToString(product)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfoToProductsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfoToProductsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ExtraInfoToProduct) ApiClient.Deserialize(response.Content, typeof(ExtraInfoToProduct), response.Headers);
        }
    
        /// <summary>
        /// Ek Bilgi Ürün Bağı Silme Kalıcı olarak ilgili Ek Bilgi Ürün Bağını siler.
        /// </summary>
        /// <param name="id">Ek Bilgi Ürün Bağı nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void ExtraInfoToProductsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ExtraInfoToProductsIdDelete");
            
    
            var path = "/extra_info_to_products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfoToProductsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfoToProductsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Ek Bilgi Ürün Bağı Alma İlgili Ek Bilgi Ürün Bağını getirir.
        /// </summary>
        /// <param name="id">Ek Bilgi Ürün Bağı nesnesinin id değeri</param> 
        /// <returns>ExtraInfoToProduct</returns>            
        public ExtraInfoToProduct ExtraInfoToProductsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ExtraInfoToProductsIdGet");
            
    
            var path = "/extra_info_to_products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfoToProductsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfoToProductsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ExtraInfoToProduct) ApiClient.Deserialize(response.Content, typeof(ExtraInfoToProduct), response.Headers);
        }
    
        /// <summary>
        /// Ek Bilgi Ürün Bağı Güncelleme İlgili Ek Bilgi Ürün Bağını günceller.
        /// </summary>
        /// <param name="id">Ek Bilgi Ürün Bağı nesnesinin id değeri</param> 
        /// <param name="extraInfoToProduct"> nesnesi</param> 
        /// <returns>ExtraInfoToProduct</returns>            
        public ExtraInfoToProduct ExtraInfoToProductsIdPut (int? id, ExtraInfoToProduct extraInfoToProduct)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ExtraInfoToProductsIdPut");
            
            // verify the required parameter 'extraInfoToProduct' is set
            if (extraInfoToProduct == null) throw new ApiException(400, "Missing required parameter 'extraInfoToProduct' when calling ExtraInfoToProductsIdPut");
            
    
            var path = "/extra_info_to_products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(extraInfoToProduct); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfoToProductsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfoToProductsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ExtraInfoToProduct) ApiClient.Deserialize(response.Content, typeof(ExtraInfoToProduct), response.Headers);
        }
    
        /// <summary>
        /// Ek Bilgi Ürün Bağı Oluşturma Yeni bir Ek Bilgi Ürün Bağı oluşturur.
        /// </summary>
        /// <param name="extraInfoToProduct"> nesnesi</param> 
        /// <returns>ExtraInfoToProduct</returns>            
        public ExtraInfoToProduct ExtraInfoToProductsPost (ExtraInfoToProduct extraInfoToProduct)
        {
            
            // verify the required parameter 'extraInfoToProduct' is set
            if (extraInfoToProduct == null) throw new ApiException(400, "Missing required parameter 'extraInfoToProduct' when calling ExtraInfoToProductsPost");
            
    
            var path = "/extra_info_to_products";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(extraInfoToProduct); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfoToProductsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfoToProductsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ExtraInfoToProduct) ApiClient.Deserialize(response.Content, typeof(ExtraInfoToProduct), response.Headers);
        }
    
    }
}
