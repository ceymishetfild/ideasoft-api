using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IOrderDetailApi
    {
        /// <summary>
        /// Sipariş Detayı Listesi Alma Sipariş Detayı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="order">Sipariş id</param>
        /// <returns>OrderDetail</returns>
        OrderDetail OrderDetailsGet (string sort, int? limit, int? page, int? sinceId, int? order);
        /// <summary>
        /// Sipariş Detayı Silme Kalıcı olarak ilgili Sipariş Detayı siler.
        /// </summary>
        /// <param name="id">Sipariş Detayı nesnesinin id değeri</param>
        /// <returns></returns>
        void OrderDetailsIdDelete (int? id);
        /// <summary>
        /// Sipariş Detayı Alma İlgili Sipariş Detayı getirir.
        /// </summary>
        /// <param name="id">Sipariş Detayı nesnesinin id değeri</param>
        /// <returns>OrderDetail</returns>
        OrderDetail OrderDetailsIdGet (int? id);
        /// <summary>
        /// Sipariş Detayı Güncelleme İlgili Sipariş Detayı günceller.
        /// </summary>
        /// <param name="id">Sipariş Detayı nesnesinin id değeri</param>
        /// <param name="orderDetail">OrderDetail nesnesi</param>
        /// <returns>OrderDetail</returns>
        OrderDetail OrderDetailsIdPut (int? id, OrderDetail orderDetail);
        /// <summary>
        /// Sipariş Detayı Oluşturma Yeni bir Sipariş Detayı oluşturur.
        /// </summary>
        /// <param name="orderDetail">OrderDetail nesnesi</param>
        /// <returns>OrderDetail</returns>
        OrderDetail OrderDetailsPost (OrderDetail orderDetail);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class OrderDetailApi : IOrderDetailApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OrderDetailApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public OrderDetailApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="OrderDetailApi"/> class.
        /// </summary>
        /// <returns></returns>
        public OrderDetailApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Sipariş Detayı Listesi Alma Sipariş Detayı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="order">Sipariş id</param> 
        /// <returns>OrderDetail</returns>            
        public OrderDetail OrderDetailsGet (string sort, int? limit, int? page, int? sinceId, int? order)
        {
            
    
            var path = "/order_details";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (order != null) queryParams.Add("order", ApiClient.ParameterToString(order)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderDetailsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderDetailsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OrderDetail) ApiClient.Deserialize(response.Content, typeof(OrderDetail), response.Headers);
        }
    
        /// <summary>
        /// Sipariş Detayı Silme Kalıcı olarak ilgili Sipariş Detayı siler.
        /// </summary>
        /// <param name="id">Sipariş Detayı nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void OrderDetailsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OrderDetailsIdDelete");
            
    
            var path = "/order_details/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderDetailsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderDetailsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Sipariş Detayı Alma İlgili Sipariş Detayı getirir.
        /// </summary>
        /// <param name="id">Sipariş Detayı nesnesinin id değeri</param> 
        /// <returns>OrderDetail</returns>            
        public OrderDetail OrderDetailsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OrderDetailsIdGet");
            
    
            var path = "/order_details/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderDetailsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderDetailsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OrderDetail) ApiClient.Deserialize(response.Content, typeof(OrderDetail), response.Headers);
        }
    
        /// <summary>
        /// Sipariş Detayı Güncelleme İlgili Sipariş Detayı günceller.
        /// </summary>
        /// <param name="id">Sipariş Detayı nesnesinin id değeri</param> 
        /// <param name="orderDetail">OrderDetail nesnesi</param> 
        /// <returns>OrderDetail</returns>            
        public OrderDetail OrderDetailsIdPut (int? id, OrderDetail orderDetail)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OrderDetailsIdPut");
            
            // verify the required parameter 'orderDetail' is set
            if (orderDetail == null) throw new ApiException(400, "Missing required parameter 'orderDetail' when calling OrderDetailsIdPut");
            
    
            var path = "/order_details/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(orderDetail); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderDetailsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderDetailsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OrderDetail) ApiClient.Deserialize(response.Content, typeof(OrderDetail), response.Headers);
        }
    
        /// <summary>
        /// Sipariş Detayı Oluşturma Yeni bir Sipariş Detayı oluşturur.
        /// </summary>
        /// <param name="orderDetail">OrderDetail nesnesi</param> 
        /// <returns>OrderDetail</returns>            
        public OrderDetail OrderDetailsPost (OrderDetail orderDetail)
        {
            
            // verify the required parameter 'orderDetail' is set
            if (orderDetail == null) throw new ApiException(400, "Missing required parameter 'orderDetail' when calling OrderDetailsPost");
            
    
            var path = "/order_details";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(orderDetail); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderDetailsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderDetailsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OrderDetail) ApiClient.Deserialize(response.Content, typeof(OrderDetail), response.Headers);
        }
    
    }
}
