using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IShipmentApi
    {
        /// <summary>
        /// Teslimat Listesi Alma Teslimat listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="code">Teslimat kodu</param>
        /// <param name="invoiceKey">Teslimat fatura anahtarı</param>
        /// <param name="barcode">Teslimat barkodu</param>
        /// <param name="order">Sipariş id</param>
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param>
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param>
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param>
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param>
        /// <returns>Shipment</returns>
        Shipment ShipmentsGet (string sort, int? limit, int? page, int? sinceId, string code, string invoiceKey, string barcode, int? order, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt);
        /// <summary>
        /// Teslimat Silme Kalıcı olarak ilgili Teslimatı siler.
        /// </summary>
        /// <param name="id">Teslimat nesnesinin id değeri</param>
        /// <returns></returns>
        void ShipmentsIdDelete (int? id);
        /// <summary>
        /// Teslimat Alma İlgili Teslimatı getirir.
        /// </summary>
        /// <param name="id">Teslimat nesnesinin id değeri</param>
        /// <returns>Shipment</returns>
        Shipment ShipmentsIdGet (int? id);
        /// <summary>
        /// Teslimat Güncelleme İlgili Teslimatı günceller.
        /// </summary>
        /// <param name="id">Teslimat nesnesinin id değeri</param>
        /// <param name="shipment">Shipment nesnesi</param>
        /// <returns>Shipment</returns>
        Shipment ShipmentsIdPut (int? id, Shipment shipment);
        /// <summary>
        /// Teslimat Oluşturma Yeni bir Teslimat oluşturur.
        /// </summary>
        /// <param name="shipment">Shipment nesnesi</param>
        /// <returns>Shipment</returns>
        Shipment ShipmentsPost (Shipment shipment);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class ShipmentApi : IShipmentApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public ShipmentApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="ShipmentApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ShipmentApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Teslimat Listesi Alma Teslimat listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="code">Teslimat kodu</param> 
        /// <param name="invoiceKey">Teslimat fatura anahtarı</param> 
        /// <param name="barcode">Teslimat barkodu</param> 
        /// <param name="order">Sipariş id</param> 
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param> 
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param> 
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param> 
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param> 
        /// <returns>Shipment</returns>            
        public Shipment ShipmentsGet (string sort, int? limit, int? page, int? sinceId, string code, string invoiceKey, string barcode, int? order, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)
        {
            
    
            var path = "/shipments";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (code != null) queryParams.Add("code", ApiClient.ParameterToString(code)); // query parameter
 if (invoiceKey != null) queryParams.Add("invoiceKey", ApiClient.ParameterToString(invoiceKey)); // query parameter
 if (barcode != null) queryParams.Add("barcode", ApiClient.ParameterToString(barcode)); // query parameter
 if (order != null) queryParams.Add("order", ApiClient.ParameterToString(order)); // query parameter
 if (startDate != null) queryParams.Add("startDate", ApiClient.ParameterToString(startDate)); // query parameter
 if (endDate != null) queryParams.Add("endDate", ApiClient.ParameterToString(endDate)); // query parameter
 if (startUpdatedAt != null) queryParams.Add("startUpdatedAt", ApiClient.ParameterToString(startUpdatedAt)); // query parameter
 if (endUpdatedAt != null) queryParams.Add("endUpdatedAt", ApiClient.ParameterToString(endUpdatedAt)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ShipmentsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ShipmentsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Shipment) ApiClient.Deserialize(response.Content, typeof(Shipment), response.Headers);
        }
    
        /// <summary>
        /// Teslimat Silme Kalıcı olarak ilgili Teslimatı siler.
        /// </summary>
        /// <param name="id">Teslimat nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void ShipmentsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ShipmentsIdDelete");
            
    
            var path = "/shipments/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ShipmentsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ShipmentsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Teslimat Alma İlgili Teslimatı getirir.
        /// </summary>
        /// <param name="id">Teslimat nesnesinin id değeri</param> 
        /// <returns>Shipment</returns>            
        public Shipment ShipmentsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ShipmentsIdGet");
            
    
            var path = "/shipments/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ShipmentsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ShipmentsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Shipment) ApiClient.Deserialize(response.Content, typeof(Shipment), response.Headers);
        }
    
        /// <summary>
        /// Teslimat Güncelleme İlgili Teslimatı günceller.
        /// </summary>
        /// <param name="id">Teslimat nesnesinin id değeri</param> 
        /// <param name="shipment">Shipment nesnesi</param> 
        /// <returns>Shipment</returns>            
        public Shipment ShipmentsIdPut (int? id, Shipment shipment)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ShipmentsIdPut");
            
            // verify the required parameter 'shipment' is set
            if (shipment == null) throw new ApiException(400, "Missing required parameter 'shipment' when calling ShipmentsIdPut");
            
    
            var path = "/shipments/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(shipment); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ShipmentsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ShipmentsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Shipment) ApiClient.Deserialize(response.Content, typeof(Shipment), response.Headers);
        }
    
        /// <summary>
        /// Teslimat Oluşturma Yeni bir Teslimat oluşturur.
        /// </summary>
        /// <param name="shipment">Shipment nesnesi</param> 
        /// <returns>Shipment</returns>            
        public Shipment ShipmentsPost (Shipment shipment)
        {
            
            // verify the required parameter 'shipment' is set
            if (shipment == null) throw new ApiException(400, "Missing required parameter 'shipment' when calling ShipmentsPost");
            
    
            var path = "/shipments";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(shipment); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ShipmentsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ShipmentsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Shipment) ApiClient.Deserialize(response.Content, typeof(Shipment), response.Headers);
        }
    
    }
}
