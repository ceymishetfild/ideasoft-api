using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ISpecNameApi
    {
        /// <summary>
        /// Ürün Özelliği Listesi Alma Ürün Özelliği listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param>
        /// <param name="name">Ürün Özelliği adı</param>
        /// <param name="specGroup">Ürün özellik grubu id</param>
        /// <param name="choiceType">Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul</param>
        /// <returns>SpecName</returns>
        SpecName SpecNamesGet (string sort, int? limit, int? page, int? sinceId, string ids, string name, int? specGroup, string choiceType);
        /// <summary>
        /// Ürün Özelliği Silme Kalıcı olarak ilgili Ürün Özelliğini siler.
        /// </summary>
        /// <param name="id">Ürün Özellik nesnesinin id değeri</param>
        /// <returns></returns>
        void SpecNamesIdDelete (int? id);
        /// <summary>
        /// Ürün Özelliği Alma İlgili Ürün Özelliğini getirir.
        /// </summary>
        /// <param name="id">Ürün Özellik nesnesinin id değeri</param>
        /// <returns>SpecName</returns>
        SpecName SpecNamesIdGet (int? id);
        /// <summary>
        /// Ürün Özelliği Güncelleme İlgili Ürün Özelliğini günceller.
        /// </summary>
        /// <param name="id">Ürün Özellik nesnesinin id değeri</param>
        /// <param name="specName"> nesnesi</param>
        /// <returns>SpecName</returns>
        SpecName SpecNamesIdPut (int? id, SpecName specName);
        /// <summary>
        /// Ürün Özelliği Oluşturma Yeni bir Ürün Özelliği oluşturur.
        /// </summary>
        /// <param name="specName"> nesnesi</param>
        /// <returns>SpecName</returns>
        SpecName SpecNamesPost (SpecName specName);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class SpecNameApi : ISpecNameApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SpecNameApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public SpecNameApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="SpecNameApi"/> class.
        /// </summary>
        /// <returns></returns>
        public SpecNameApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ürün Özelliği Listesi Alma Ürün Özelliği listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param> 
        /// <param name="name">Ürün Özelliği adı</param> 
        /// <param name="specGroup">Ürün özellik grubu id</param> 
        /// <param name="choiceType">Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul</param> 
        /// <returns>SpecName</returns>            
        public SpecName SpecNamesGet (string sort, int? limit, int? page, int? sinceId, string ids, string name, int? specGroup, string choiceType)
        {
            
    
            var path = "/spec_names";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (ids != null) queryParams.Add("ids", ApiClient.ParameterToString(ids)); // query parameter
 if (name != null) queryParams.Add("name", ApiClient.ParameterToString(name)); // query parameter
 if (specGroup != null) queryParams.Add("specGroup", ApiClient.ParameterToString(specGroup)); // query parameter
 if (choiceType != null) queryParams.Add("choiceType", ApiClient.ParameterToString(choiceType)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecNamesGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecNamesGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecName) ApiClient.Deserialize(response.Content, typeof(SpecName), response.Headers);
        }
    
        /// <summary>
        /// Ürün Özelliği Silme Kalıcı olarak ilgili Ürün Özelliğini siler.
        /// </summary>
        /// <param name="id">Ürün Özellik nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void SpecNamesIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SpecNamesIdDelete");
            
    
            var path = "/spec_names/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecNamesIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecNamesIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Ürün Özelliği Alma İlgili Ürün Özelliğini getirir.
        /// </summary>
        /// <param name="id">Ürün Özellik nesnesinin id değeri</param> 
        /// <returns>SpecName</returns>            
        public SpecName SpecNamesIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SpecNamesIdGet");
            
    
            var path = "/spec_names/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecNamesIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecNamesIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecName) ApiClient.Deserialize(response.Content, typeof(SpecName), response.Headers);
        }
    
        /// <summary>
        /// Ürün Özelliği Güncelleme İlgili Ürün Özelliğini günceller.
        /// </summary>
        /// <param name="id">Ürün Özellik nesnesinin id değeri</param> 
        /// <param name="specName"> nesnesi</param> 
        /// <returns>SpecName</returns>            
        public SpecName SpecNamesIdPut (int? id, SpecName specName)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SpecNamesIdPut");
            
            // verify the required parameter 'specName' is set
            if (specName == null) throw new ApiException(400, "Missing required parameter 'specName' when calling SpecNamesIdPut");
            
    
            var path = "/spec_names/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(specName); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecNamesIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecNamesIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecName) ApiClient.Deserialize(response.Content, typeof(SpecName), response.Headers);
        }
    
        /// <summary>
        /// Ürün Özelliği Oluşturma Yeni bir Ürün Özelliği oluşturur.
        /// </summary>
        /// <param name="specName"> nesnesi</param> 
        /// <returns>SpecName</returns>            
        public SpecName SpecNamesPost (SpecName specName)
        {
            
            // verify the required parameter 'specName' is set
            if (specName == null) throw new ApiException(400, "Missing required parameter 'specName' when calling SpecNamesPost");
            
    
            var path = "/spec_names";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(specName); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecNamesPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecNamesPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecName) ApiClient.Deserialize(response.Content, typeof(SpecName), response.Headers);
        }
    
    }
}
