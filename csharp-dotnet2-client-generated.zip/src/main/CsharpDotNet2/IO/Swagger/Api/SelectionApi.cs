using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ISelectionApi
    {
        /// <summary>
        /// Ek Özellik Listesi Alma Ek Özellik listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="title">Ek Özellik başlığı</param>
        /// <param name="selectionGroup">Ek Özellik Grubu id</param>
        /// <returns>Selection</returns>
        Selection SelectionsGet (string sort, int? limit, int? page, int? sinceId, string title, int? selectionGroup);
        /// <summary>
        /// Ek Özellik Silme Kalıcı olarak ilgili Ek Özelliği siler.
        /// </summary>
        /// <param name="id">Ek Özellik nesnesinin id değeri</param>
        /// <returns></returns>
        void SelectionsIdDelete (int? id);
        /// <summary>
        /// Ek Özellik Alma İlgili Ek Özelliği getirir.
        /// </summary>
        /// <param name="id">Ek Özellik nesnesinin id değeri</param>
        /// <returns>Selection</returns>
        Selection SelectionsIdGet (int? id);
        /// <summary>
        /// Ek Özellik Güncelleme İlgili Ek Özelliği günceller.
        /// </summary>
        /// <param name="id">Ek Özellik nesnesinin id değeri</param>
        /// <param name="selection">Selection nesnesi</param>
        /// <returns>Selection</returns>
        Selection SelectionsIdPut (int? id, Selection selection);
        /// <summary>
        /// Ek Özellik Oluşturma Yeni bir Ek Özellik oluşturur.
        /// </summary>
        /// <param name="selection">Selection nesnesi</param>
        /// <returns>Selection</returns>
        Selection SelectionsPost (Selection selection);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class SelectionApi : ISelectionApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SelectionApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public SelectionApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="SelectionApi"/> class.
        /// </summary>
        /// <returns></returns>
        public SelectionApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ek Özellik Listesi Alma Ek Özellik listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="title">Ek Özellik başlığı</param> 
        /// <param name="selectionGroup">Ek Özellik Grubu id</param> 
        /// <returns>Selection</returns>            
        public Selection SelectionsGet (string sort, int? limit, int? page, int? sinceId, string title, int? selectionGroup)
        {
            
    
            var path = "/selections";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (title != null) queryParams.Add("title", ApiClient.ParameterToString(title)); // query parameter
 if (selectionGroup != null) queryParams.Add("selectionGroup", ApiClient.ParameterToString(selectionGroup)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Selection) ApiClient.Deserialize(response.Content, typeof(Selection), response.Headers);
        }
    
        /// <summary>
        /// Ek Özellik Silme Kalıcı olarak ilgili Ek Özelliği siler.
        /// </summary>
        /// <param name="id">Ek Özellik nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void SelectionsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SelectionsIdDelete");
            
    
            var path = "/selections/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Ek Özellik Alma İlgili Ek Özelliği getirir.
        /// </summary>
        /// <param name="id">Ek Özellik nesnesinin id değeri</param> 
        /// <returns>Selection</returns>            
        public Selection SelectionsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SelectionsIdGet");
            
    
            var path = "/selections/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Selection) ApiClient.Deserialize(response.Content, typeof(Selection), response.Headers);
        }
    
        /// <summary>
        /// Ek Özellik Güncelleme İlgili Ek Özelliği günceller.
        /// </summary>
        /// <param name="id">Ek Özellik nesnesinin id değeri</param> 
        /// <param name="selection">Selection nesnesi</param> 
        /// <returns>Selection</returns>            
        public Selection SelectionsIdPut (int? id, Selection selection)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SelectionsIdPut");
            
            // verify the required parameter 'selection' is set
            if (selection == null) throw new ApiException(400, "Missing required parameter 'selection' when calling SelectionsIdPut");
            
    
            var path = "/selections/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(selection); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Selection) ApiClient.Deserialize(response.Content, typeof(Selection), response.Headers);
        }
    
        /// <summary>
        /// Ek Özellik Oluşturma Yeni bir Ek Özellik oluşturur.
        /// </summary>
        /// <param name="selection">Selection nesnesi</param> 
        /// <returns>Selection</returns>            
        public Selection SelectionsPost (Selection selection)
        {
            
            // verify the required parameter 'selection' is set
            if (selection == null) throw new ApiException(400, "Missing required parameter 'selection' when calling SelectionsPost");
            
    
            var path = "/selections";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(selection); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Selection) ApiClient.Deserialize(response.Content, typeof(Selection), response.Headers);
        }
    
    }
}
