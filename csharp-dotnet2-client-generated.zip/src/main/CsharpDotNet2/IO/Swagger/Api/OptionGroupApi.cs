using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IOptionGroupApi
    {
        /// <summary>
        /// Varyant Grubu Listesi Alma Varyant Grubu listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param>
        /// <param name="title">Varyant Grubu başlığı.</param>
        /// <returns>OptionGroup</returns>
        OptionGroup OptionGroupsGet (string sort, int? limit, int? page, int? sinceId, string ids, string title);
        /// <summary>
        /// Varyant Grubu Silme Kalıcı olarak ilgili Varyant Grubunu siler.
        /// </summary>
        /// <param name="id">Varyant Grubu nesnesinin id değeri</param>
        /// <returns></returns>
        void OptionGroupsIdDelete (int? id);
        /// <summary>
        /// Varyant Grubu Alma İlgili Varyant Grubunu getirir.
        /// </summary>
        /// <param name="id">Varyant Grubu nesnesinin id değeri</param>
        /// <returns>OptionGroup</returns>
        OptionGroup OptionGroupsIdGet (int? id);
        /// <summary>
        /// Varyant Grubu Güncelleme İlgili Varyant Grubunu günceller.
        /// </summary>
        /// <param name="id">Varyant Grubu nesnesinin id değeri</param>
        /// <param name="optionGroup"> nesnesi</param>
        /// <returns>OptionGroup</returns>
        OptionGroup OptionGroupsIdPut (int? id, OptionGroup optionGroup);
        /// <summary>
        /// Varyant Grubu Oluşturma Yeni bir Varyant Grubu oluşturur.
        /// </summary>
        /// <param name="optionGroup"> nesnesi</param>
        /// <returns>OptionGroup</returns>
        OptionGroup OptionGroupsPost (OptionGroup optionGroup);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class OptionGroupApi : IOptionGroupApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OptionGroupApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public OptionGroupApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="OptionGroupApi"/> class.
        /// </summary>
        /// <returns></returns>
        public OptionGroupApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Varyant Grubu Listesi Alma Varyant Grubu listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param> 
        /// <param name="title">Varyant Grubu başlığı.</param> 
        /// <returns>OptionGroup</returns>            
        public OptionGroup OptionGroupsGet (string sort, int? limit, int? page, int? sinceId, string ids, string title)
        {
            
    
            var path = "/option_groups";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (ids != null) queryParams.Add("ids", ApiClient.ParameterToString(ids)); // query parameter
 if (title != null) queryParams.Add("title", ApiClient.ParameterToString(title)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionGroupsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionGroupsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OptionGroup) ApiClient.Deserialize(response.Content, typeof(OptionGroup), response.Headers);
        }
    
        /// <summary>
        /// Varyant Grubu Silme Kalıcı olarak ilgili Varyant Grubunu siler.
        /// </summary>
        /// <param name="id">Varyant Grubu nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void OptionGroupsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OptionGroupsIdDelete");
            
    
            var path = "/option_groups/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionGroupsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionGroupsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Varyant Grubu Alma İlgili Varyant Grubunu getirir.
        /// </summary>
        /// <param name="id">Varyant Grubu nesnesinin id değeri</param> 
        /// <returns>OptionGroup</returns>            
        public OptionGroup OptionGroupsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OptionGroupsIdGet");
            
    
            var path = "/option_groups/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionGroupsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionGroupsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OptionGroup) ApiClient.Deserialize(response.Content, typeof(OptionGroup), response.Headers);
        }
    
        /// <summary>
        /// Varyant Grubu Güncelleme İlgili Varyant Grubunu günceller.
        /// </summary>
        /// <param name="id">Varyant Grubu nesnesinin id değeri</param> 
        /// <param name="optionGroup"> nesnesi</param> 
        /// <returns>OptionGroup</returns>            
        public OptionGroup OptionGroupsIdPut (int? id, OptionGroup optionGroup)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OptionGroupsIdPut");
            
            // verify the required parameter 'optionGroup' is set
            if (optionGroup == null) throw new ApiException(400, "Missing required parameter 'optionGroup' when calling OptionGroupsIdPut");
            
    
            var path = "/option_groups/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(optionGroup); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionGroupsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionGroupsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OptionGroup) ApiClient.Deserialize(response.Content, typeof(OptionGroup), response.Headers);
        }
    
        /// <summary>
        /// Varyant Grubu Oluşturma Yeni bir Varyant Grubu oluşturur.
        /// </summary>
        /// <param name="optionGroup"> nesnesi</param> 
        /// <returns>OptionGroup</returns>            
        public OptionGroup OptionGroupsPost (OptionGroup optionGroup)
        {
            
            // verify the required parameter 'optionGroup' is set
            if (optionGroup == null) throw new ApiException(400, "Missing required parameter 'optionGroup' when calling OptionGroupsPost");
            
    
            var path = "/option_groups";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(optionGroup); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionGroupsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionGroupsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OptionGroup) ApiClient.Deserialize(response.Content, typeof(OptionGroup), response.Headers);
        }
    
    }
}
