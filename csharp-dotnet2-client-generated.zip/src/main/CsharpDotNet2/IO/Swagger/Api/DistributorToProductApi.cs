using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IDistributorToProductApi
    {
        /// <summary>
        /// Distribütör Ürün Bağı Listesi Alma Distribütör Ürün Bağı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="distributor">Distribütör id</param>
        /// <param name="product">Ürün id</param>
        /// <returns>DistributorToProduct</returns>
        DistributorToProduct DistributorToProductsGet (string sort, int? limit, int? page, int? sinceId, int? distributor, int? product);
        /// <summary>
        /// Distribütör Ürün Bağı Silme Kalıcı olarak ilgili Distribütör Ürün Bağını siler
        /// </summary>
        /// <param name="id">Distribütör Ürün Bağı nesnesinin id değeri</param>
        /// <returns></returns>
        void DistributorToProductsIdDelete (int? id);
        /// <summary>
        /// Distribütör Ürün Bağı Alma İlgili Distribütör Ürün Bağını getirir.
        /// </summary>
        /// <param name="id">Distribütör Ürün Bağı nesnesinin id değeri</param>
        /// <returns>DistributorToProduct</returns>
        DistributorToProduct DistributorToProductsIdGet (int? id);
        /// <summary>
        /// Distribütör Ürün Bağı Güncelleme İlgili Distribütör Ürün Bağını günceller.
        /// </summary>
        /// <param name="id">Distribütör Ürün Bağı nesnesinin id değeri</param>
        /// <param name="distributorToProduct">DistributorToProduct nesnesi</param>
        /// <returns>DistributorToProduct</returns>
        DistributorToProduct DistributorToProductsIdPut (int? id, DistributorToProduct distributorToProduct);
        /// <summary>
        /// Distribütör Ürün Bağı Oluşturma Yeni bir Distribütör Ürün Bağı oluşturur.
        /// </summary>
        /// <param name="distributorToProduct">DistributorToProduct nesnesi</param>
        /// <returns>DistributorToProduct</returns>
        DistributorToProduct DistributorToProductsPost (DistributorToProduct distributorToProduct);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class DistributorToProductApi : IDistributorToProductApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DistributorToProductApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public DistributorToProductApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="DistributorToProductApi"/> class.
        /// </summary>
        /// <returns></returns>
        public DistributorToProductApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Distribütör Ürün Bağı Listesi Alma Distribütör Ürün Bağı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="distributor">Distribütör id</param> 
        /// <param name="product">Ürün id</param> 
        /// <returns>DistributorToProduct</returns>            
        public DistributorToProduct DistributorToProductsGet (string sort, int? limit, int? page, int? sinceId, int? distributor, int? product)
        {
            
    
            var path = "/distributor_to_products";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (distributor != null) queryParams.Add("distributor", ApiClient.ParameterToString(distributor)); // query parameter
 if (product != null) queryParams.Add("product", ApiClient.ParameterToString(product)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling DistributorToProductsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling DistributorToProductsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (DistributorToProduct) ApiClient.Deserialize(response.Content, typeof(DistributorToProduct), response.Headers);
        }
    
        /// <summary>
        /// Distribütör Ürün Bağı Silme Kalıcı olarak ilgili Distribütör Ürün Bağını siler
        /// </summary>
        /// <param name="id">Distribütör Ürün Bağı nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void DistributorToProductsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling DistributorToProductsIdDelete");
            
    
            var path = "/distributor_to_products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling DistributorToProductsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling DistributorToProductsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Distribütör Ürün Bağı Alma İlgili Distribütör Ürün Bağını getirir.
        /// </summary>
        /// <param name="id">Distribütör Ürün Bağı nesnesinin id değeri</param> 
        /// <returns>DistributorToProduct</returns>            
        public DistributorToProduct DistributorToProductsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling DistributorToProductsIdGet");
            
    
            var path = "/distributor_to_products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling DistributorToProductsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling DistributorToProductsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (DistributorToProduct) ApiClient.Deserialize(response.Content, typeof(DistributorToProduct), response.Headers);
        }
    
        /// <summary>
        /// Distribütör Ürün Bağı Güncelleme İlgili Distribütör Ürün Bağını günceller.
        /// </summary>
        /// <param name="id">Distribütör Ürün Bağı nesnesinin id değeri</param> 
        /// <param name="distributorToProduct">DistributorToProduct nesnesi</param> 
        /// <returns>DistributorToProduct</returns>            
        public DistributorToProduct DistributorToProductsIdPut (int? id, DistributorToProduct distributorToProduct)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling DistributorToProductsIdPut");
            
            // verify the required parameter 'distributorToProduct' is set
            if (distributorToProduct == null) throw new ApiException(400, "Missing required parameter 'distributorToProduct' when calling DistributorToProductsIdPut");
            
    
            var path = "/distributor_to_products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(distributorToProduct); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling DistributorToProductsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling DistributorToProductsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (DistributorToProduct) ApiClient.Deserialize(response.Content, typeof(DistributorToProduct), response.Headers);
        }
    
        /// <summary>
        /// Distribütör Ürün Bağı Oluşturma Yeni bir Distribütör Ürün Bağı oluşturur.
        /// </summary>
        /// <param name="distributorToProduct">DistributorToProduct nesnesi</param> 
        /// <returns>DistributorToProduct</returns>            
        public DistributorToProduct DistributorToProductsPost (DistributorToProduct distributorToProduct)
        {
            
            // verify the required parameter 'distributorToProduct' is set
            if (distributorToProduct == null) throw new ApiException(400, "Missing required parameter 'distributorToProduct' when calling DistributorToProductsPost");
            
    
            var path = "/distributor_to_products";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(distributorToProduct); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling DistributorToProductsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling DistributorToProductsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (DistributorToProduct) ApiClient.Deserialize(response.Content, typeof(DistributorToProduct), response.Headers);
        }
    
    }
}
