using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IMaillistApi
    {
        /// <summary>
        /// Mail Listesi Listesi Alma Mail Listesi listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="name">Mail Listesi adı.</param>
        /// <param name="email">Mail Listesi e-mail.</param>
        /// <param name="maillistGroup">Mail Listesi Grubu id</param>
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param>
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param>
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param>
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param>
        /// <returns>Maillist</returns>
        Maillist MaillistsGet (string sort, int? limit, int? page, int? sinceId, string name, string email, int? maillistGroup, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt);
        /// <summary>
        /// Mail Listesi Silme Kalıcı olarak ilgili Mail Listesini siler.
        /// </summary>
        /// <param name="id">Mail Listesi nesnesinin id değeri</param>
        /// <returns></returns>
        void MaillistsIdDelete (int? id);
        /// <summary>
        /// Mail Listesi Alma İlgili Mail Listesini getirir.
        /// </summary>
        /// <param name="id">Mail Listesi nesnesinin id değeri</param>
        /// <returns>Maillist</returns>
        Maillist MaillistsIdGet (int? id);
        /// <summary>
        /// Mail Listesi Güncelleme İlgili Mail Listesini günceller.
        /// </summary>
        /// <param name="id">Mail Listesi nesnesinin id değeri</param>
        /// <param name="maillist">Maillist nesnesi</param>
        /// <returns>Maillist</returns>
        Maillist MaillistsIdPut (int? id, Maillist maillist);
        /// <summary>
        /// Mail Listesi Oluşturma Yeni bir Mail Listesini oluşturur.
        /// </summary>
        /// <param name="maillist">Maillist nesnesi</param>
        /// <returns>Maillist</returns>
        Maillist MaillistsPost (Maillist maillist);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class MaillistApi : IMaillistApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MaillistApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public MaillistApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="MaillistApi"/> class.
        /// </summary>
        /// <returns></returns>
        public MaillistApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Mail Listesi Listesi Alma Mail Listesi listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="name">Mail Listesi adı.</param> 
        /// <param name="email">Mail Listesi e-mail.</param> 
        /// <param name="maillistGroup">Mail Listesi Grubu id</param> 
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param> 
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param> 
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param> 
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param> 
        /// <returns>Maillist</returns>            
        public Maillist MaillistsGet (string sort, int? limit, int? page, int? sinceId, string name, string email, int? maillistGroup, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)
        {
            
    
            var path = "/maillists";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (name != null) queryParams.Add("name", ApiClient.ParameterToString(name)); // query parameter
 if (email != null) queryParams.Add("email", ApiClient.ParameterToString(email)); // query parameter
 if (maillistGroup != null) queryParams.Add("maillistGroup", ApiClient.ParameterToString(maillistGroup)); // query parameter
 if (startDate != null) queryParams.Add("startDate", ApiClient.ParameterToString(startDate)); // query parameter
 if (endDate != null) queryParams.Add("endDate", ApiClient.ParameterToString(endDate)); // query parameter
 if (startUpdatedAt != null) queryParams.Add("startUpdatedAt", ApiClient.ParameterToString(startUpdatedAt)); // query parameter
 if (endUpdatedAt != null) queryParams.Add("endUpdatedAt", ApiClient.ParameterToString(endUpdatedAt)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Maillist) ApiClient.Deserialize(response.Content, typeof(Maillist), response.Headers);
        }
    
        /// <summary>
        /// Mail Listesi Silme Kalıcı olarak ilgili Mail Listesini siler.
        /// </summary>
        /// <param name="id">Mail Listesi nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void MaillistsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling MaillistsIdDelete");
            
    
            var path = "/maillists/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Mail Listesi Alma İlgili Mail Listesini getirir.
        /// </summary>
        /// <param name="id">Mail Listesi nesnesinin id değeri</param> 
        /// <returns>Maillist</returns>            
        public Maillist MaillistsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling MaillistsIdGet");
            
    
            var path = "/maillists/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Maillist) ApiClient.Deserialize(response.Content, typeof(Maillist), response.Headers);
        }
    
        /// <summary>
        /// Mail Listesi Güncelleme İlgili Mail Listesini günceller.
        /// </summary>
        /// <param name="id">Mail Listesi nesnesinin id değeri</param> 
        /// <param name="maillist">Maillist nesnesi</param> 
        /// <returns>Maillist</returns>            
        public Maillist MaillistsIdPut (int? id, Maillist maillist)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling MaillistsIdPut");
            
            // verify the required parameter 'maillist' is set
            if (maillist == null) throw new ApiException(400, "Missing required parameter 'maillist' when calling MaillistsIdPut");
            
    
            var path = "/maillists/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(maillist); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Maillist) ApiClient.Deserialize(response.Content, typeof(Maillist), response.Headers);
        }
    
        /// <summary>
        /// Mail Listesi Oluşturma Yeni bir Mail Listesini oluşturur.
        /// </summary>
        /// <param name="maillist">Maillist nesnesi</param> 
        /// <returns>Maillist</returns>            
        public Maillist MaillistsPost (Maillist maillist)
        {
            
            // verify the required parameter 'maillist' is set
            if (maillist == null) throw new ApiException(400, "Missing required parameter 'maillist' when calling MaillistsPost");
            
    
            var path = "/maillists";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(maillist); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Maillist) ApiClient.Deserialize(response.Content, typeof(Maillist), response.Headers);
        }
    
    }
}
