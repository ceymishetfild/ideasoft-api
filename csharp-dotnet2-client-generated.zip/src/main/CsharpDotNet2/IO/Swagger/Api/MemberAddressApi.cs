using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IMemberAddressApi
    {
        /// <summary>
        /// Üye Adresi Listeleme Üye Adresi listesi verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;</param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param>
        /// <param name="member">Üye id</param>
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param>
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param>
        /// <returns>MemberAddress</returns>
        MemberAddress MemberAddressesGet (string sort, int? limit, int? page, int? sinceId, string ids, int? member, DateTime? startDate, string endDate);
        /// <summary>
        /// Üye Adresi Silme Kalıcı olarak ilgili Üye Adresini siler.
        /// </summary>
        /// <param name="id">Üye Adresi nesnesinin id değeri</param>
        /// <returns></returns>
        void MemberAddressesIdDelete (int? id);
        /// <summary>
        /// Üye Adresi Alma İlgili Üye Adresini getirir.
        /// </summary>
        /// <param name="id">Üye Adresi nesnesinin id değeri</param>
        /// <returns>MemberAddress</returns>
        MemberAddress MemberAddressesIdGet (int? id);
        /// <summary>
        /// Üye Adresi Güncelleme İlgili Üye Adresini günceller.
        /// </summary>
        /// <param name="id">Üye Adresi nesnesinin id değeri</param>
        /// <param name="memberAddress"> nesnesi</param>
        /// <returns>MemberAddress</returns>
        MemberAddress MemberAddressesIdPut (int? id, MemberAddress memberAddress);
        /// <summary>
        /// Üye Adresi Oluşturma Yeni bir Üye Adresi oluşturur.
        /// </summary>
        /// <param name="memberAddress"> nesnesi</param>
        /// <returns>MemberAddress</returns>
        MemberAddress MemberAddressesPost (MemberAddress memberAddress);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class MemberAddressApi : IMemberAddressApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MemberAddressApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public MemberAddressApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="MemberAddressApi"/> class.
        /// </summary>
        /// <returns></returns>
        public MemberAddressApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Üye Adresi Listeleme Üye Adresi listesi verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;</param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param> 
        /// <param name="member">Üye id</param> 
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param> 
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param> 
        /// <returns>MemberAddress</returns>            
        public MemberAddress MemberAddressesGet (string sort, int? limit, int? page, int? sinceId, string ids, int? member, DateTime? startDate, string endDate)
        {
            
    
            var path = "/member_addresses";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (ids != null) queryParams.Add("ids", ApiClient.ParameterToString(ids)); // query parameter
 if (member != null) queryParams.Add("member", ApiClient.ParameterToString(member)); // query parameter
 if (startDate != null) queryParams.Add("startDate", ApiClient.ParameterToString(startDate)); // query parameter
 if (endDate != null) queryParams.Add("endDate", ApiClient.ParameterToString(endDate)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberAddressesGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberAddressesGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (MemberAddress) ApiClient.Deserialize(response.Content, typeof(MemberAddress), response.Headers);
        }
    
        /// <summary>
        /// Üye Adresi Silme Kalıcı olarak ilgili Üye Adresini siler.
        /// </summary>
        /// <param name="id">Üye Adresi nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void MemberAddressesIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling MemberAddressesIdDelete");
            
    
            var path = "/member_addresses/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberAddressesIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberAddressesIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Üye Adresi Alma İlgili Üye Adresini getirir.
        /// </summary>
        /// <param name="id">Üye Adresi nesnesinin id değeri</param> 
        /// <returns>MemberAddress</returns>            
        public MemberAddress MemberAddressesIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling MemberAddressesIdGet");
            
    
            var path = "/member_addresses/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberAddressesIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberAddressesIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (MemberAddress) ApiClient.Deserialize(response.Content, typeof(MemberAddress), response.Headers);
        }
    
        /// <summary>
        /// Üye Adresi Güncelleme İlgili Üye Adresini günceller.
        /// </summary>
        /// <param name="id">Üye Adresi nesnesinin id değeri</param> 
        /// <param name="memberAddress"> nesnesi</param> 
        /// <returns>MemberAddress</returns>            
        public MemberAddress MemberAddressesIdPut (int? id, MemberAddress memberAddress)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling MemberAddressesIdPut");
            
            // verify the required parameter 'memberAddress' is set
            if (memberAddress == null) throw new ApiException(400, "Missing required parameter 'memberAddress' when calling MemberAddressesIdPut");
            
    
            var path = "/member_addresses/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(memberAddress); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberAddressesIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberAddressesIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (MemberAddress) ApiClient.Deserialize(response.Content, typeof(MemberAddress), response.Headers);
        }
    
        /// <summary>
        /// Üye Adresi Oluşturma Yeni bir Üye Adresi oluşturur.
        /// </summary>
        /// <param name="memberAddress"> nesnesi</param> 
        /// <returns>MemberAddress</returns>            
        public MemberAddress MemberAddressesPost (MemberAddress memberAddress)
        {
            
            // verify the required parameter 'memberAddress' is set
            if (memberAddress == null) throw new ApiException(400, "Missing required parameter 'memberAddress' when calling MemberAddressesPost");
            
    
            var path = "/member_addresses";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(memberAddress); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberAddressesPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberAddressesPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (MemberAddress) ApiClient.Deserialize(response.Content, typeof(MemberAddress), response.Headers);
        }
    
    }
}
