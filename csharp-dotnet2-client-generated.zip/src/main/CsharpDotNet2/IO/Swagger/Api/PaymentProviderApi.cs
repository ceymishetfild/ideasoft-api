using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IPaymentProviderApi
    {
        /// <summary>
        /// Ödeme Altyapısı Sağlayıcısı Listesi Alma Ödeme Altyapısı Sağlayıcısı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="code">Ödeme Altyapısı kodu</param>
        /// <param name="name">Ödeme Altyapısı adı</param>
        /// <returns>PaymentProvider</returns>
        PaymentProvider PaymentProvidersGet (string sort, int? limit, int? page, int? sinceId, string code, string name);
        /// <summary>
        /// Ödeme Altyapısı Sağlayıcısı Alma İlgili Ödeme Altyapısı Sağlayıcısını getirir.
        /// </summary>
        /// <param name="id">Ödeme Altyapııs Sağlayıcısı nesnesinin id değeri</param>
        /// <returns>PaymentProvider</returns>
        PaymentProvider PaymentProvidersIdGet (int? id);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class PaymentProviderApi : IPaymentProviderApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentProviderApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public PaymentProviderApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentProviderApi"/> class.
        /// </summary>
        /// <returns></returns>
        public PaymentProviderApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ödeme Altyapısı Sağlayıcısı Listesi Alma Ödeme Altyapısı Sağlayıcısı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="code">Ödeme Altyapısı kodu</param> 
        /// <param name="name">Ödeme Altyapısı adı</param> 
        /// <returns>PaymentProvider</returns>            
        public PaymentProvider PaymentProvidersGet (string sort, int? limit, int? page, int? sinceId, string code, string name)
        {
            
    
            var path = "/payment_providers";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (code != null) queryParams.Add("code", ApiClient.ParameterToString(code)); // query parameter
 if (name != null) queryParams.Add("name", ApiClient.ParameterToString(name)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PaymentProvidersGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PaymentProvidersGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (PaymentProvider) ApiClient.Deserialize(response.Content, typeof(PaymentProvider), response.Headers);
        }
    
        /// <summary>
        /// Ödeme Altyapısı Sağlayıcısı Alma İlgili Ödeme Altyapısı Sağlayıcısını getirir.
        /// </summary>
        /// <param name="id">Ödeme Altyapııs Sağlayıcısı nesnesinin id değeri</param> 
        /// <returns>PaymentProvider</returns>            
        public PaymentProvider PaymentProvidersIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling PaymentProvidersIdGet");
            
    
            var path = "/payment_providers/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PaymentProvidersIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PaymentProvidersIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (PaymentProvider) ApiClient.Deserialize(response.Content, typeof(PaymentProvider), response.Headers);
        }
    
    }
}
