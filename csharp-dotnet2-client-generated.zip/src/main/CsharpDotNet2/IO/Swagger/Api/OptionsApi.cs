using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IOptionsApi
    {
        /// <summary>
        /// Varyant Listesi Alma Varyant listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param>
        /// <param name="title">Varyant başlığı</param>
        /// <param name="optionGroup">Varyant Grubu id</param>
        /// <returns>Options</returns>
        Options OptionsGet (string sort, int? limit, int? page, int? sinceId, string ids, string title, int? optionGroup);
        /// <summary>
        /// Varyant Silme Kalıcı olarak ilgili Varyantı siler.
        /// </summary>
        /// <param name="id">Varyant nesnesinin id değeri</param>
        /// <returns></returns>
        void OptionsIdDelete (int? id);
        /// <summary>
        /// Varyant Alma İlgili Varyantı getirir.
        /// </summary>
        /// <param name="id">Varyant nesnesinin id değeri</param>
        /// <returns>Options</returns>
        Options OptionsIdGet (int? id);
        /// <summary>
        /// Varyant Güncelleme İlgili Varyantı günceller.
        /// </summary>
        /// <param name="id">Varyant nesnesinin id değeri</param>
        /// <param name="options"> nesnesi</param>
        /// <returns>Options</returns>
        Options OptionsIdPut (int? id, Options options);
        /// <summary>
        /// Varyant Oluşturma Yeni bir Varyant oluşturur.
        /// </summary>
        /// <param name="options"> nesnesi</param>
        /// <returns>Options</returns>
        Options OptionsPost (Options options);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class OptionsApi : IOptionsApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OptionsApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public OptionsApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="OptionsApi"/> class.
        /// </summary>
        /// <returns></returns>
        public OptionsApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Varyant Listesi Alma Varyant listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param> 
        /// <param name="title">Varyant başlığı</param> 
        /// <param name="optionGroup">Varyant Grubu id</param> 
        /// <returns>Options</returns>            
        public Options OptionsGet (string sort, int? limit, int? page, int? sinceId, string ids, string title, int? optionGroup)
        {
            
    
            var path = "/options";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (ids != null) queryParams.Add("ids", ApiClient.ParameterToString(ids)); // query parameter
 if (title != null) queryParams.Add("title", ApiClient.ParameterToString(title)); // query parameter
 if (optionGroup != null) queryParams.Add("optionGroup", ApiClient.ParameterToString(optionGroup)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Options) ApiClient.Deserialize(response.Content, typeof(Options), response.Headers);
        }
    
        /// <summary>
        /// Varyant Silme Kalıcı olarak ilgili Varyantı siler.
        /// </summary>
        /// <param name="id">Varyant nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void OptionsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OptionsIdDelete");
            
    
            var path = "/options/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Varyant Alma İlgili Varyantı getirir.
        /// </summary>
        /// <param name="id">Varyant nesnesinin id değeri</param> 
        /// <returns>Options</returns>            
        public Options OptionsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OptionsIdGet");
            
    
            var path = "/options/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Options) ApiClient.Deserialize(response.Content, typeof(Options), response.Headers);
        }
    
        /// <summary>
        /// Varyant Güncelleme İlgili Varyantı günceller.
        /// </summary>
        /// <param name="id">Varyant nesnesinin id değeri</param> 
        /// <param name="options"> nesnesi</param> 
        /// <returns>Options</returns>            
        public Options OptionsIdPut (int? id, Options options)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OptionsIdPut");
            
            // verify the required parameter 'options' is set
            if (options == null) throw new ApiException(400, "Missing required parameter 'options' when calling OptionsIdPut");
            
    
            var path = "/options/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(options); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Options) ApiClient.Deserialize(response.Content, typeof(Options), response.Headers);
        }
    
        /// <summary>
        /// Varyant Oluşturma Yeni bir Varyant oluşturur.
        /// </summary>
        /// <param name="options"> nesnesi</param> 
        /// <returns>Options</returns>            
        public Options OptionsPost (Options options)
        {
            
            // verify the required parameter 'options' is set
            if (options == null) throw new ApiException(400, "Missing required parameter 'options' when calling OptionsPost");
            
    
            var path = "/options";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(options); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Options) ApiClient.Deserialize(response.Content, typeof(Options), response.Headers);
        }
    
    }
}
