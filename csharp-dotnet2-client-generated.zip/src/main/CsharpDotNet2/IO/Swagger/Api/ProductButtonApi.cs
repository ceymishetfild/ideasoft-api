using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IProductButtonApi
    {
        /// <summary>
        /// Ürün ve Stok Butonu Listesi Alma Ürün ve Stok Butonu listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="fastShipping">Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param>
        /// <param name="sameDayShipping">Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param>
        /// <param name="threeDaysDelivery">3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param>
        /// <param name="fiveDaysDelivery">5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param>
        /// <param name="sevenDaysDelivery">7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param>
        /// <param name="freeShipping">Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param>
        /// <param name="deliveryFromStock">Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param>
        /// <param name="preOrderedProduct">Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param>
        /// <param name="askStock">Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param>
        /// <param name="campaignedProduct">Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param>
        /// <param name="product">Ürün id</param>
        /// <returns>ProductButton</returns>
        ProductButton ProductButtonsGet (string sort, int? limit, int? page, int? sinceId, int? fastShipping, int? sameDayShipping, int? threeDaysDelivery, int? fiveDaysDelivery, int? sevenDaysDelivery, int? freeShipping, int? deliveryFromStock, int? preOrderedProduct, int? askStock, int? campaignedProduct, int? product);
        /// <summary>
        /// Ürün ve Stok Butonu Silme Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.
        /// </summary>
        /// <param name="id">Ürün ve Stok Butonu nesnesinin id değeri</param>
        /// <returns></returns>
        void ProductButtonsIdDelete (int? id);
        /// <summary>
        /// Ürün ve Stok Butonu Alma İlgili Ürün ve Stok Butonunu getirir.
        /// </summary>
        /// <param name="id">Ürün ve Stok Butonu nesnesinin id değeri</param>
        /// <returns>ProductButton</returns>
        ProductButton ProductButtonsIdGet (int? id);
        /// <summary>
        /// Ürün ve Stok Butonu Güncelleme İlgili Ürün ve Stok Butonunu günceller.
        /// </summary>
        /// <param name="id">Ürün ve Stok Butonu nesnesinin id değeri</param>
        /// <param name="productButton">ProductButton nesnesi</param>
        /// <returns>ProductButton</returns>
        ProductButton ProductButtonsIdPut (int? id, ProductButton productButton);
        /// <summary>
        /// Ürün ve Stok Butonu Oluşturma Yeni bir Ürün ve Stok Butonu oluşturur.
        /// </summary>
        /// <param name="productButton">ProductButton nesnesi</param>
        /// <returns>ProductButton</returns>
        ProductButton ProductButtonsPost (ProductButton productButton);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class ProductButtonApi : IProductButtonApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductButtonApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public ProductButtonApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductButtonApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ProductButtonApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ürün ve Stok Butonu Listesi Alma Ürün ve Stok Butonu listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="fastShipping">Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param> 
        /// <param name="sameDayShipping">Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param> 
        /// <param name="threeDaysDelivery">3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param> 
        /// <param name="fiveDaysDelivery">5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param> 
        /// <param name="sevenDaysDelivery">7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param> 
        /// <param name="freeShipping">Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param> 
        /// <param name="deliveryFromStock">Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param> 
        /// <param name="preOrderedProduct">Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param> 
        /// <param name="askStock">Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param> 
        /// <param name="campaignedProduct">Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param> 
        /// <param name="product">Ürün id</param> 
        /// <returns>ProductButton</returns>            
        public ProductButton ProductButtonsGet (string sort, int? limit, int? page, int? sinceId, int? fastShipping, int? sameDayShipping, int? threeDaysDelivery, int? fiveDaysDelivery, int? sevenDaysDelivery, int? freeShipping, int? deliveryFromStock, int? preOrderedProduct, int? askStock, int? campaignedProduct, int? product)
        {
            
    
            var path = "/product_buttons";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (fastShipping != null) queryParams.Add("fastShipping", ApiClient.ParameterToString(fastShipping)); // query parameter
 if (sameDayShipping != null) queryParams.Add("sameDayShipping", ApiClient.ParameterToString(sameDayShipping)); // query parameter
 if (threeDaysDelivery != null) queryParams.Add("threeDaysDelivery", ApiClient.ParameterToString(threeDaysDelivery)); // query parameter
 if (fiveDaysDelivery != null) queryParams.Add("fiveDaysDelivery", ApiClient.ParameterToString(fiveDaysDelivery)); // query parameter
 if (sevenDaysDelivery != null) queryParams.Add("sevenDaysDelivery", ApiClient.ParameterToString(sevenDaysDelivery)); // query parameter
 if (freeShipping != null) queryParams.Add("freeShipping", ApiClient.ParameterToString(freeShipping)); // query parameter
 if (deliveryFromStock != null) queryParams.Add("deliveryFromStock", ApiClient.ParameterToString(deliveryFromStock)); // query parameter
 if (preOrderedProduct != null) queryParams.Add("preOrderedProduct", ApiClient.ParameterToString(preOrderedProduct)); // query parameter
 if (askStock != null) queryParams.Add("askStock", ApiClient.ParameterToString(askStock)); // query parameter
 if (campaignedProduct != null) queryParams.Add("campaignedProduct", ApiClient.ParameterToString(campaignedProduct)); // query parameter
 if (product != null) queryParams.Add("product", ApiClient.ParameterToString(product)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductButtonsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductButtonsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductButton) ApiClient.Deserialize(response.Content, typeof(ProductButton), response.Headers);
        }
    
        /// <summary>
        /// Ürün ve Stok Butonu Silme Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.
        /// </summary>
        /// <param name="id">Ürün ve Stok Butonu nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void ProductButtonsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductButtonsIdDelete");
            
    
            var path = "/product_buttons/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductButtonsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductButtonsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Ürün ve Stok Butonu Alma İlgili Ürün ve Stok Butonunu getirir.
        /// </summary>
        /// <param name="id">Ürün ve Stok Butonu nesnesinin id değeri</param> 
        /// <returns>ProductButton</returns>            
        public ProductButton ProductButtonsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductButtonsIdGet");
            
    
            var path = "/product_buttons/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductButtonsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductButtonsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductButton) ApiClient.Deserialize(response.Content, typeof(ProductButton), response.Headers);
        }
    
        /// <summary>
        /// Ürün ve Stok Butonu Güncelleme İlgili Ürün ve Stok Butonunu günceller.
        /// </summary>
        /// <param name="id">Ürün ve Stok Butonu nesnesinin id değeri</param> 
        /// <param name="productButton">ProductButton nesnesi</param> 
        /// <returns>ProductButton</returns>            
        public ProductButton ProductButtonsIdPut (int? id, ProductButton productButton)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductButtonsIdPut");
            
            // verify the required parameter 'productButton' is set
            if (productButton == null) throw new ApiException(400, "Missing required parameter 'productButton' when calling ProductButtonsIdPut");
            
    
            var path = "/product_buttons/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(productButton); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductButtonsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductButtonsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductButton) ApiClient.Deserialize(response.Content, typeof(ProductButton), response.Headers);
        }
    
        /// <summary>
        /// Ürün ve Stok Butonu Oluşturma Yeni bir Ürün ve Stok Butonu oluşturur.
        /// </summary>
        /// <param name="productButton">ProductButton nesnesi</param> 
        /// <returns>ProductButton</returns>            
        public ProductButton ProductButtonsPost (ProductButton productButton)
        {
            
            // verify the required parameter 'productButton' is set
            if (productButton == null) throw new ApiException(400, "Missing required parameter 'productButton' when calling ProductButtonsPost");
            
    
            var path = "/product_buttons";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(productButton); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductButtonsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductButtonsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductButton) ApiClient.Deserialize(response.Content, typeof(ProductButton), response.Headers);
        }
    
    }
}
