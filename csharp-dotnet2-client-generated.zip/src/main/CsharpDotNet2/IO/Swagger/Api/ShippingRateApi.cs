using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IShippingRateApi
    {
        /// <summary>
        /// Kargo Oranı Listesi Alma Kargo Oranı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param>
        /// <param name="shippingCompany">Kargo firması id</param>
        /// <param name="region">Bölge id</param>
        /// <returns>ShippingRate</returns>
        ShippingRate ShippingRatesGet (string sort, int? limit, int? page, int? sinceId, string ids, int? shippingCompany, int? region);
        /// <summary>
        /// Kargo Oranı Silme Kalıcı olarak ilgili Kargo Oranını siler.
        /// </summary>
        /// <param name="id">Kargo Oranı nesnesinin id değeri</param>
        /// <returns></returns>
        void ShippingRatesIdDelete (int? id);
        /// <summary>
        /// Kargo Oranı Alma İlgili Kargo Oranını getirir.
        /// </summary>
        /// <param name="id">Kargo Oranı nesnesinin id değeri</param>
        /// <returns>ShippingRate</returns>
        ShippingRate ShippingRatesIdGet (int? id);
        /// <summary>
        /// Kargo Oranı Güncelleme İlgili Kargo Oranını günceller.
        /// </summary>
        /// <param name="id">Kargo Oranı nesnesinin id değeri</param>
        /// <param name="shippingRate"> nesnesi</param>
        /// <returns>ShippingRate</returns>
        ShippingRate ShippingRatesIdPut (int? id, ShippingRate shippingRate);
        /// <summary>
        /// Kargo Oranı Oluşturma Yeni bir Kargo Oranı oluşturur.
        /// </summary>
        /// <param name="shippingRate"> nesnesi</param>
        /// <returns>ShippingRate</returns>
        ShippingRate ShippingRatesPost (ShippingRate shippingRate);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class ShippingRateApi : IShippingRateApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShippingRateApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public ShippingRateApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="ShippingRateApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ShippingRateApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Kargo Oranı Listesi Alma Kargo Oranı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param> 
        /// <param name="shippingCompany">Kargo firması id</param> 
        /// <param name="region">Bölge id</param> 
        /// <returns>ShippingRate</returns>            
        public ShippingRate ShippingRatesGet (string sort, int? limit, int? page, int? sinceId, string ids, int? shippingCompany, int? region)
        {
            
    
            var path = "/shipping_rates";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (ids != null) queryParams.Add("ids", ApiClient.ParameterToString(ids)); // query parameter
 if (shippingCompany != null) queryParams.Add("shippingCompany", ApiClient.ParameterToString(shippingCompany)); // query parameter
 if (region != null) queryParams.Add("region", ApiClient.ParameterToString(region)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingRatesGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingRatesGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ShippingRate) ApiClient.Deserialize(response.Content, typeof(ShippingRate), response.Headers);
        }
    
        /// <summary>
        /// Kargo Oranı Silme Kalıcı olarak ilgili Kargo Oranını siler.
        /// </summary>
        /// <param name="id">Kargo Oranı nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void ShippingRatesIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ShippingRatesIdDelete");
            
    
            var path = "/shipping_rates/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingRatesIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingRatesIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Kargo Oranı Alma İlgili Kargo Oranını getirir.
        /// </summary>
        /// <param name="id">Kargo Oranı nesnesinin id değeri</param> 
        /// <returns>ShippingRate</returns>            
        public ShippingRate ShippingRatesIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ShippingRatesIdGet");
            
    
            var path = "/shipping_rates/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingRatesIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingRatesIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ShippingRate) ApiClient.Deserialize(response.Content, typeof(ShippingRate), response.Headers);
        }
    
        /// <summary>
        /// Kargo Oranı Güncelleme İlgili Kargo Oranını günceller.
        /// </summary>
        /// <param name="id">Kargo Oranı nesnesinin id değeri</param> 
        /// <param name="shippingRate"> nesnesi</param> 
        /// <returns>ShippingRate</returns>            
        public ShippingRate ShippingRatesIdPut (int? id, ShippingRate shippingRate)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ShippingRatesIdPut");
            
            // verify the required parameter 'shippingRate' is set
            if (shippingRate == null) throw new ApiException(400, "Missing required parameter 'shippingRate' when calling ShippingRatesIdPut");
            
    
            var path = "/shipping_rates/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(shippingRate); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingRatesIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingRatesIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ShippingRate) ApiClient.Deserialize(response.Content, typeof(ShippingRate), response.Headers);
        }
    
        /// <summary>
        /// Kargo Oranı Oluşturma Yeni bir Kargo Oranı oluşturur.
        /// </summary>
        /// <param name="shippingRate"> nesnesi</param> 
        /// <returns>ShippingRate</returns>            
        public ShippingRate ShippingRatesPost (ShippingRate shippingRate)
        {
            
            // verify the required parameter 'shippingRate' is set
            if (shippingRate == null) throw new ApiException(400, "Missing required parameter 'shippingRate' when calling ShippingRatesPost");
            
    
            var path = "/shipping_rates";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(shippingRate); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingRatesPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingRatesPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ShippingRate) ApiClient.Deserialize(response.Content, typeof(ShippingRate), response.Headers);
        }
    
    }
}
