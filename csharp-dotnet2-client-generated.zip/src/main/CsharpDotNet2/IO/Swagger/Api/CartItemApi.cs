using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ICartItemApi
    {
        /// <summary>
        /// Sepet Kalemi Silme Kalıcı olarak ilgili Sepet Kalemini siler.
        /// </summary>
        /// <param name="id">Sepet Kalemi nesnesinin id değeri</param>
        /// <returns></returns>
        void CartItemsIdDelete (int? id);
        /// <summary>
        /// Sepet Kalemi Güncelleme İlgili Sepet Kalemini günceller.
        /// </summary>
        /// <param name="id">Sepet Kalemi nesnesinin id değeri</param>
        /// <returns>CartItem</returns>
        CartItem CartItemsIdPut (int? id);
        /// <summary>
        /// Sepet Kalemi Oluşturma Yeni bir Sepet Kalemi oluşturur.
        /// </summary>
        /// <param name="cartItem"> nesnesi</param>
        /// <returns>CartItem</returns>
        CartItem CartItemsPost (CartItem cartItem);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class CartItemApi : ICartItemApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CartItemApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public CartItemApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="CartItemApi"/> class.
        /// </summary>
        /// <returns></returns>
        public CartItemApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Sepet Kalemi Silme Kalıcı olarak ilgili Sepet Kalemini siler.
        /// </summary>
        /// <param name="id">Sepet Kalemi nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void CartItemsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling CartItemsIdDelete");
            
    
            var path = "/cart_items/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling CartItemsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling CartItemsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Sepet Kalemi Güncelleme İlgili Sepet Kalemini günceller.
        /// </summary>
        /// <param name="id">Sepet Kalemi nesnesinin id değeri</param> 
        /// <returns>CartItem</returns>            
        public CartItem CartItemsIdPut (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling CartItemsIdPut");
            
    
            var path = "/cart_items/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling CartItemsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling CartItemsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (CartItem) ApiClient.Deserialize(response.Content, typeof(CartItem), response.Headers);
        }
    
        /// <summary>
        /// Sepet Kalemi Oluşturma Yeni bir Sepet Kalemi oluşturur.
        /// </summary>
        /// <param name="cartItem"> nesnesi</param> 
        /// <returns>CartItem</returns>            
        public CartItem CartItemsPost (CartItem cartItem)
        {
            
            // verify the required parameter 'cartItem' is set
            if (cartItem == null) throw new ApiException(400, "Missing required parameter 'cartItem' when calling CartItemsPost");
            
    
            var path = "/cart_items";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(cartItem); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling CartItemsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling CartItemsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (CartItem) ApiClient.Deserialize(response.Content, typeof(CartItem), response.Headers);
        }
    
    }
}
