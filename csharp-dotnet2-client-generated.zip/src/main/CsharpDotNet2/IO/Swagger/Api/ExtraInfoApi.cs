using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IExtraInfoApi
    {
        /// <summary>
        /// Ek Bilgi Listesi Alma Ek Bilgi listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param>
        /// <param name="name">Ek Bilgi adı</param>
        /// <returns>ExtraInfo</returns>
        ExtraInfo ExtraInfosGet (string sort, int? limit, int? page, int? sinceId, string ids, string name);
        /// <summary>
        /// Ek Bilgi Silme Kalıcı olarak ilgili Ek Bilgiyi siler.
        /// </summary>
        /// <param name="id">Ek Bilgi nesnesinin id değeri</param>
        /// <returns></returns>
        void ExtraInfosIdDelete (int? id);
        /// <summary>
        /// Ek Bilgi Alma İlgili Ek Bilgiyi getirir.
        /// </summary>
        /// <param name="id">Ek Bilgi nesnesinin id değeri</param>
        /// <returns>ExtraInfo</returns>
        ExtraInfo ExtraInfosIdGet (int? id);
        /// <summary>
        /// Ek Bilgi Güncelleme İlgili Ek Bilgiyi günceller.
        /// </summary>
        /// <param name="id">Ek Bilgi nesnesinin id değeri</param>
        /// <param name="extraInfo"> nesnesi</param>
        /// <returns>ExtraInfo</returns>
        ExtraInfo ExtraInfosIdPut (int? id, ExtraInfo extraInfo);
        /// <summary>
        /// Ek Bilgi Oluşturma Yeni bir Ek Bilgi oluşturur.
        /// </summary>
        /// <param name="extraInfo"> nesnesi</param>
        /// <returns>ExtraInfo</returns>
        ExtraInfo ExtraInfosPost (ExtraInfo extraInfo);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class ExtraInfoApi : IExtraInfoApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ExtraInfoApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public ExtraInfoApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="ExtraInfoApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ExtraInfoApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ek Bilgi Listesi Alma Ek Bilgi listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param> 
        /// <param name="name">Ek Bilgi adı</param> 
        /// <returns>ExtraInfo</returns>            
        public ExtraInfo ExtraInfosGet (string sort, int? limit, int? page, int? sinceId, string ids, string name)
        {
            
    
            var path = "/extra_infos";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (ids != null) queryParams.Add("ids", ApiClient.ParameterToString(ids)); // query parameter
 if (name != null) queryParams.Add("name", ApiClient.ParameterToString(name)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfosGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfosGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ExtraInfo) ApiClient.Deserialize(response.Content, typeof(ExtraInfo), response.Headers);
        }
    
        /// <summary>
        /// Ek Bilgi Silme Kalıcı olarak ilgili Ek Bilgiyi siler.
        /// </summary>
        /// <param name="id">Ek Bilgi nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void ExtraInfosIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ExtraInfosIdDelete");
            
    
            var path = "/extra_infos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfosIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfosIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Ek Bilgi Alma İlgili Ek Bilgiyi getirir.
        /// </summary>
        /// <param name="id">Ek Bilgi nesnesinin id değeri</param> 
        /// <returns>ExtraInfo</returns>            
        public ExtraInfo ExtraInfosIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ExtraInfosIdGet");
            
    
            var path = "/extra_infos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfosIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfosIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ExtraInfo) ApiClient.Deserialize(response.Content, typeof(ExtraInfo), response.Headers);
        }
    
        /// <summary>
        /// Ek Bilgi Güncelleme İlgili Ek Bilgiyi günceller.
        /// </summary>
        /// <param name="id">Ek Bilgi nesnesinin id değeri</param> 
        /// <param name="extraInfo"> nesnesi</param> 
        /// <returns>ExtraInfo</returns>            
        public ExtraInfo ExtraInfosIdPut (int? id, ExtraInfo extraInfo)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ExtraInfosIdPut");
            
            // verify the required parameter 'extraInfo' is set
            if (extraInfo == null) throw new ApiException(400, "Missing required parameter 'extraInfo' when calling ExtraInfosIdPut");
            
    
            var path = "/extra_infos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(extraInfo); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfosIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfosIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ExtraInfo) ApiClient.Deserialize(response.Content, typeof(ExtraInfo), response.Headers);
        }
    
        /// <summary>
        /// Ek Bilgi Oluşturma Yeni bir Ek Bilgi oluşturur.
        /// </summary>
        /// <param name="extraInfo"> nesnesi</param> 
        /// <returns>ExtraInfo</returns>            
        public ExtraInfo ExtraInfosPost (ExtraInfo extraInfo)
        {
            
            // verify the required parameter 'extraInfo' is set
            if (extraInfo == null) throw new ApiException(400, "Missing required parameter 'extraInfo' when calling ExtraInfosPost");
            
    
            var path = "/extra_infos";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(extraInfo); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfosPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ExtraInfosPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ExtraInfo) ApiClient.Deserialize(response.Content, typeof(ExtraInfo), response.Headers);
        }
    
    }
}
