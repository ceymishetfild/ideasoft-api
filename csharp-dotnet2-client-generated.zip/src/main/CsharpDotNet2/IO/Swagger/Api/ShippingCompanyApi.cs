using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IShippingCompanyApi
    {
        /// <summary>
        /// Kargo Firması Listesi Alma Kargo Firması listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param>
        /// <param name="name">Kargo firması adı</param>
        /// <param name="companyCode">Kargo firması kodu</param>
        /// <param name="paymentType">Ödeme Tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil</param>
        /// <param name="shippingProvider">Teslimat Hizmeti Sağlayıcısı id</param>
        /// <returns>ShippingCompany</returns>
        ShippingCompany ShippingCompaniesGet (string sort, int? limit, int? page, int? sinceId, string ids, string name, string companyCode, string paymentType, int? shippingProvider);
        /// <summary>
        /// Kargo Firması Silme Kalıcı olarak ilgili Kargo Firmasını siler.
        /// </summary>
        /// <param name="id">Kargo Firması nesnesinin id değeri</param>
        /// <returns></returns>
        void ShippingCompaniesIdDelete (int? id);
        /// <summary>
        /// Kargo Firması Alma İlgili Kargo Firmasını getirir.
        /// </summary>
        /// <param name="id">Kargo Firması nesnesinin id değeri</param>
        /// <returns>ShippingCompany</returns>
        ShippingCompany ShippingCompaniesIdGet (int? id);
        /// <summary>
        /// Kargo Firması Güncelleme İlgili Kargo Firmasını günceller.
        /// </summary>
        /// <param name="id">Kargo Firması nesnesinin id değeri</param>
        /// <param name="shippingCompany"> nesnesi</param>
        /// <returns>ShippingCompany</returns>
        ShippingCompany ShippingCompaniesIdPut (int? id, ShippingCompany shippingCompany);
        /// <summary>
        /// Kargo Firması Oluşturma Yeni bir Kargo Firması oluşturur relationship.
        /// </summary>
        /// <param name="shippingCompany"> nesnesi</param>
        /// <returns>ShippingCompany</returns>
        ShippingCompany ShippingCompaniesPost (ShippingCompany shippingCompany);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class ShippingCompanyApi : IShippingCompanyApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ShippingCompanyApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public ShippingCompanyApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="ShippingCompanyApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ShippingCompanyApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Kargo Firması Listesi Alma Kargo Firması listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param> 
        /// <param name="name">Kargo firması adı</param> 
        /// <param name="companyCode">Kargo firması kodu</param> 
        /// <param name="paymentType">Ödeme Tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil</param> 
        /// <param name="shippingProvider">Teslimat Hizmeti Sağlayıcısı id</param> 
        /// <returns>ShippingCompany</returns>            
        public ShippingCompany ShippingCompaniesGet (string sort, int? limit, int? page, int? sinceId, string ids, string name, string companyCode, string paymentType, int? shippingProvider)
        {
            
    
            var path = "/shipping_companies";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (ids != null) queryParams.Add("ids", ApiClient.ParameterToString(ids)); // query parameter
 if (name != null) queryParams.Add("name", ApiClient.ParameterToString(name)); // query parameter
 if (companyCode != null) queryParams.Add("companyCode", ApiClient.ParameterToString(companyCode)); // query parameter
 if (paymentType != null) queryParams.Add("paymentType", ApiClient.ParameterToString(paymentType)); // query parameter
 if (shippingProvider != null) queryParams.Add("shippingProvider", ApiClient.ParameterToString(shippingProvider)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingCompaniesGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingCompaniesGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ShippingCompany) ApiClient.Deserialize(response.Content, typeof(ShippingCompany), response.Headers);
        }
    
        /// <summary>
        /// Kargo Firması Silme Kalıcı olarak ilgili Kargo Firmasını siler.
        /// </summary>
        /// <param name="id">Kargo Firması nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void ShippingCompaniesIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ShippingCompaniesIdDelete");
            
    
            var path = "/shipping_companies/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingCompaniesIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingCompaniesIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Kargo Firması Alma İlgili Kargo Firmasını getirir.
        /// </summary>
        /// <param name="id">Kargo Firması nesnesinin id değeri</param> 
        /// <returns>ShippingCompany</returns>            
        public ShippingCompany ShippingCompaniesIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ShippingCompaniesIdGet");
            
    
            var path = "/shipping_companies/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingCompaniesIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingCompaniesIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ShippingCompany) ApiClient.Deserialize(response.Content, typeof(ShippingCompany), response.Headers);
        }
    
        /// <summary>
        /// Kargo Firması Güncelleme İlgili Kargo Firmasını günceller.
        /// </summary>
        /// <param name="id">Kargo Firması nesnesinin id değeri</param> 
        /// <param name="shippingCompany"> nesnesi</param> 
        /// <returns>ShippingCompany</returns>            
        public ShippingCompany ShippingCompaniesIdPut (int? id, ShippingCompany shippingCompany)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ShippingCompaniesIdPut");
            
            // verify the required parameter 'shippingCompany' is set
            if (shippingCompany == null) throw new ApiException(400, "Missing required parameter 'shippingCompany' when calling ShippingCompaniesIdPut");
            
    
            var path = "/shipping_companies/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(shippingCompany); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingCompaniesIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingCompaniesIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ShippingCompany) ApiClient.Deserialize(response.Content, typeof(ShippingCompany), response.Headers);
        }
    
        /// <summary>
        /// Kargo Firması Oluşturma Yeni bir Kargo Firması oluşturur relationship.
        /// </summary>
        /// <param name="shippingCompany"> nesnesi</param> 
        /// <returns>ShippingCompany</returns>            
        public ShippingCompany ShippingCompaniesPost (ShippingCompany shippingCompany)
        {
            
            // verify the required parameter 'shippingCompany' is set
            if (shippingCompany == null) throw new ApiException(400, "Missing required parameter 'shippingCompany' when calling ShippingCompaniesPost");
            
    
            var path = "/shipping_companies";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(shippingCompany); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingCompaniesPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ShippingCompaniesPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ShippingCompany) ApiClient.Deserialize(response.Content, typeof(ShippingCompany), response.Headers);
        }
    
    }
}
