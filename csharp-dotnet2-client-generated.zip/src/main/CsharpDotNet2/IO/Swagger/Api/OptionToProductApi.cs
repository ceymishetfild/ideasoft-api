using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IOptionToProductApi
    {
        /// <summary>
        /// Varyant Ürün Bağı Listesi Alma Varyant Ürün Bağı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="product">Ürün id</param>
        /// <param name="optionGroup">Varyant Grubu id</param>
        /// <param name="option">Varyant id</param>
        /// <param name="parentProductId">Ana Ürün id</param>
        /// <returns>OptionToProduct</returns>
        OptionToProduct OptionToProductsGet (string sort, int? limit, int? page, int? sinceId, int? product, int? optionGroup, int? option, int? parentProductId);
        /// <summary>
        /// Varyant Ürün Bağı Silme Kalıcı olarak ilgili Varyant Ürün Bağını siler.
        /// </summary>
        /// <param name="id">Varyant Ürün Bağı nesnesinin id değeri</param>
        /// <returns></returns>
        void OptionToProductsIdDelete (int? id);
        /// <summary>
        /// Varyant Ürün Bağı Alma İlgili Varyant Ürün Bağını getirir.
        /// </summary>
        /// <param name="id">Varyant Ürün Bağı nesnesinin id değeri</param>
        /// <returns>OptionToProduct</returns>
        OptionToProduct OptionToProductsIdGet (int? id);
        /// <summary>
        /// Varyant Ürün Bağı Güncelleme İlgili Varyant Ürün Bağını günceller.
        /// </summary>
        /// <param name="id">Varyant Ürün Bağı nesnesinin id değeri</param>
        /// <param name="optionToProduct">OptionToProduct nesnesi</param>
        /// <returns>OptionToProduct</returns>
        OptionToProduct OptionToProductsIdPut (int? id, OptionToProduct optionToProduct);
        /// <summary>
        /// Varyant Ürün Bağı Oluşturma Yeni bir Varyant Ürün Bağı oluşturur.
        /// </summary>
        /// <param name="optionToProduct">OptionToProduct nesnesi</param>
        /// <returns>OptionToProduct</returns>
        OptionToProduct OptionToProductsPost (OptionToProduct optionToProduct);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class OptionToProductApi : IOptionToProductApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OptionToProductApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public OptionToProductApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="OptionToProductApi"/> class.
        /// </summary>
        /// <returns></returns>
        public OptionToProductApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Varyant Ürün Bağı Listesi Alma Varyant Ürün Bağı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="product">Ürün id</param> 
        /// <param name="optionGroup">Varyant Grubu id</param> 
        /// <param name="option">Varyant id</param> 
        /// <param name="parentProductId">Ana Ürün id</param> 
        /// <returns>OptionToProduct</returns>            
        public OptionToProduct OptionToProductsGet (string sort, int? limit, int? page, int? sinceId, int? product, int? optionGroup, int? option, int? parentProductId)
        {
            
    
            var path = "/option_to_products";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (product != null) queryParams.Add("product", ApiClient.ParameterToString(product)); // query parameter
 if (optionGroup != null) queryParams.Add("optionGroup", ApiClient.ParameterToString(optionGroup)); // query parameter
 if (option != null) queryParams.Add("option", ApiClient.ParameterToString(option)); // query parameter
 if (parentProductId != null) queryParams.Add("parentProductId", ApiClient.ParameterToString(parentProductId)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionToProductsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionToProductsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OptionToProduct) ApiClient.Deserialize(response.Content, typeof(OptionToProduct), response.Headers);
        }
    
        /// <summary>
        /// Varyant Ürün Bağı Silme Kalıcı olarak ilgili Varyant Ürün Bağını siler.
        /// </summary>
        /// <param name="id">Varyant Ürün Bağı nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void OptionToProductsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OptionToProductsIdDelete");
            
    
            var path = "/option_to_products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionToProductsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionToProductsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Varyant Ürün Bağı Alma İlgili Varyant Ürün Bağını getirir.
        /// </summary>
        /// <param name="id">Varyant Ürün Bağı nesnesinin id değeri</param> 
        /// <returns>OptionToProduct</returns>            
        public OptionToProduct OptionToProductsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OptionToProductsIdGet");
            
    
            var path = "/option_to_products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionToProductsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionToProductsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OptionToProduct) ApiClient.Deserialize(response.Content, typeof(OptionToProduct), response.Headers);
        }
    
        /// <summary>
        /// Varyant Ürün Bağı Güncelleme İlgili Varyant Ürün Bağını günceller.
        /// </summary>
        /// <param name="id">Varyant Ürün Bağı nesnesinin id değeri</param> 
        /// <param name="optionToProduct">OptionToProduct nesnesi</param> 
        /// <returns>OptionToProduct</returns>            
        public OptionToProduct OptionToProductsIdPut (int? id, OptionToProduct optionToProduct)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OptionToProductsIdPut");
            
            // verify the required parameter 'optionToProduct' is set
            if (optionToProduct == null) throw new ApiException(400, "Missing required parameter 'optionToProduct' when calling OptionToProductsIdPut");
            
    
            var path = "/option_to_products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(optionToProduct); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionToProductsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionToProductsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OptionToProduct) ApiClient.Deserialize(response.Content, typeof(OptionToProduct), response.Headers);
        }
    
        /// <summary>
        /// Varyant Ürün Bağı Oluşturma Yeni bir Varyant Ürün Bağı oluşturur.
        /// </summary>
        /// <param name="optionToProduct">OptionToProduct nesnesi</param> 
        /// <returns>OptionToProduct</returns>            
        public OptionToProduct OptionToProductsPost (OptionToProduct optionToProduct)
        {
            
            // verify the required parameter 'optionToProduct' is set
            if (optionToProduct == null) throw new ApiException(400, "Missing required parameter 'optionToProduct' when calling OptionToProductsPost");
            
    
            var path = "/option_to_products";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(optionToProduct); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionToProductsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OptionToProductsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OptionToProduct) ApiClient.Deserialize(response.Content, typeof(OptionToProduct), response.Headers);
        }
    
    }
}
