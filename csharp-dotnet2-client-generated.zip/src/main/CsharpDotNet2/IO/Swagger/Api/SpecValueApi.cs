using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ISpecValueApi
    {
        /// <summary>
        /// Ürün Özellik Değeri Listesi Alma Ürün Özellik Değeri listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param>
        /// <param name="name">Ürün özellik adı</param>
        /// <param name="specName">Ürün özellik id</param>
        /// <param name="specValue">Ürün özellik değeri id</param>
        /// <returns>SpecValue</returns>
        SpecValue SpecValuesGet (string sort, int? limit, int? page, int? sinceId, string ids, string name, int? specName, int? specValue);
        /// <summary>
        /// Ürün Özellik Değeri Silme Kalıcı olarak ilgili Ürün Özellik Değerini siler.
        /// </summary>
        /// <param name="id">Ürün Özellik Değeri nesnesinin id değeri</param>
        /// <returns></returns>
        void SpecValuesIdDelete (int? id);
        /// <summary>
        /// Ürün Özellik Değeri Alma İlgili Ürün Özellik Değerini getirir.
        /// </summary>
        /// <param name="id">Ürün Özellik Değeri nesnesinin id değeri</param>
        /// <returns>SpecValue</returns>
        SpecValue SpecValuesIdGet (int? id);
        /// <summary>
        /// Ürün Özellik Değeri Güncelleme İlgili Ürün Özellik Değerini günceller.
        /// </summary>
        /// <param name="id">Ürün Özellik Değeri nesnesinin id değeri</param>
        /// <param name="specValue"> nesnesi</param>
        /// <returns>SpecValue</returns>
        SpecValue SpecValuesIdPut (int? id, SpecValue specValue);
        /// <summary>
        /// Ürün Özellik Değeri Oluşturma Yeni bir Ürün Özellik Değeri oluşturur.
        /// </summary>
        /// <param name="specValue"> nesnesi</param>
        /// <returns>SpecValue</returns>
        SpecValue SpecValuesPost (SpecValue specValue);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class SpecValueApi : ISpecValueApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SpecValueApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public SpecValueApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="SpecValueApi"/> class.
        /// </summary>
        /// <returns></returns>
        public SpecValueApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ürün Özellik Değeri Listesi Alma Ürün Özellik Değeri listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param> 
        /// <param name="name">Ürün özellik adı</param> 
        /// <param name="specName">Ürün özellik id</param> 
        /// <param name="specValue">Ürün özellik değeri id</param> 
        /// <returns>SpecValue</returns>            
        public SpecValue SpecValuesGet (string sort, int? limit, int? page, int? sinceId, string ids, string name, int? specName, int? specValue)
        {
            
    
            var path = "/spec_values";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (ids != null) queryParams.Add("ids", ApiClient.ParameterToString(ids)); // query parameter
 if (name != null) queryParams.Add("name", ApiClient.ParameterToString(name)); // query parameter
 if (specName != null) queryParams.Add("specName", ApiClient.ParameterToString(specName)); // query parameter
 if (specValue != null) queryParams.Add("specValue", ApiClient.ParameterToString(specValue)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecValuesGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecValuesGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecValue) ApiClient.Deserialize(response.Content, typeof(SpecValue), response.Headers);
        }
    
        /// <summary>
        /// Ürün Özellik Değeri Silme Kalıcı olarak ilgili Ürün Özellik Değerini siler.
        /// </summary>
        /// <param name="id">Ürün Özellik Değeri nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void SpecValuesIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SpecValuesIdDelete");
            
    
            var path = "/spec_values/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecValuesIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecValuesIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Ürün Özellik Değeri Alma İlgili Ürün Özellik Değerini getirir.
        /// </summary>
        /// <param name="id">Ürün Özellik Değeri nesnesinin id değeri</param> 
        /// <returns>SpecValue</returns>            
        public SpecValue SpecValuesIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SpecValuesIdGet");
            
    
            var path = "/spec_values/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecValuesIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecValuesIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecValue) ApiClient.Deserialize(response.Content, typeof(SpecValue), response.Headers);
        }
    
        /// <summary>
        /// Ürün Özellik Değeri Güncelleme İlgili Ürün Özellik Değerini günceller.
        /// </summary>
        /// <param name="id">Ürün Özellik Değeri nesnesinin id değeri</param> 
        /// <param name="specValue"> nesnesi</param> 
        /// <returns>SpecValue</returns>            
        public SpecValue SpecValuesIdPut (int? id, SpecValue specValue)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SpecValuesIdPut");
            
            // verify the required parameter 'specValue' is set
            if (specValue == null) throw new ApiException(400, "Missing required parameter 'specValue' when calling SpecValuesIdPut");
            
    
            var path = "/spec_values/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(specValue); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecValuesIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecValuesIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecValue) ApiClient.Deserialize(response.Content, typeof(SpecValue), response.Headers);
        }
    
        /// <summary>
        /// Ürün Özellik Değeri Oluşturma Yeni bir Ürün Özellik Değeri oluşturur.
        /// </summary>
        /// <param name="specValue"> nesnesi</param> 
        /// <returns>SpecValue</returns>            
        public SpecValue SpecValuesPost (SpecValue specValue)
        {
            
            // verify the required parameter 'specValue' is set
            if (specValue == null) throw new ApiException(400, "Missing required parameter 'specValue' when calling SpecValuesPost");
            
    
            var path = "/spec_values";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(specValue); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecValuesPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecValuesPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecValue) ApiClient.Deserialize(response.Content, typeof(SpecValue), response.Headers);
        }
    
    }
}
