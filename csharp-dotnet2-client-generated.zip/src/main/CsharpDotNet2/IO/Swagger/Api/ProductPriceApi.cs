using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IProductPriceApi
    {
        /// <summary>
        /// Ürün Fiyat Listesi Alma Ürün Fiyat listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="type">Ürün fiyat tipi</param>
        /// <param name="product">Ürün id</param>
        /// <returns>ProductPrice</returns>
        ProductPrice ProductPricesGet (string sort, int? limit, int? page, int? sinceId, int? type, int? product);
        /// <summary>
        /// Ürün Fiyat Silme Kalıcı olarak ilgili Ürün Fiyatını siler.
        /// </summary>
        /// <param name="id">Ürün Fiyat nesnesinin id değeri</param>
        /// <returns></returns>
        void ProductPricesIdDelete (int? id);
        /// <summary>
        /// Ürün Fiyat Alma İlgili Ürün Fiyatını getirir.
        /// </summary>
        /// <param name="id">Ürün Fiyat nesnesinin id değeri</param>
        /// <returns>ProductPrice</returns>
        ProductPrice ProductPricesIdGet (int? id);
        /// <summary>
        /// Ürün Fiyat Güncelleme İlgili Ürün Fiyatını günceller.
        /// </summary>
        /// <param name="id">Ürün Fiyat nesnesinin id değeri</param>
        /// <param name="productPrice">ProductPrice nesnesi</param>
        /// <returns>ProductPrice</returns>
        ProductPrice ProductPricesIdPut (int? id, ProductPrice productPrice);
        /// <summary>
        /// Ürün Fiyat Oluşturma Yeni bir Ürün Fiyat oluşturur.
        /// </summary>
        /// <param name="productPrice">ProductPrice nesnesi</param>
        /// <returns>ProductPrice</returns>
        ProductPrice ProductPricesPost (ProductPrice productPrice);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class ProductPriceApi : IProductPriceApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductPriceApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public ProductPriceApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductPriceApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ProductPriceApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ürün Fiyat Listesi Alma Ürün Fiyat listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="type">Ürün fiyat tipi</param> 
        /// <param name="product">Ürün id</param> 
        /// <returns>ProductPrice</returns>            
        public ProductPrice ProductPricesGet (string sort, int? limit, int? page, int? sinceId, int? type, int? product)
        {
            
    
            var path = "/product_prices";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (type != null) queryParams.Add("type", ApiClient.ParameterToString(type)); // query parameter
 if (product != null) queryParams.Add("product", ApiClient.ParameterToString(product)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductPricesGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductPricesGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductPrice) ApiClient.Deserialize(response.Content, typeof(ProductPrice), response.Headers);
        }
    
        /// <summary>
        /// Ürün Fiyat Silme Kalıcı olarak ilgili Ürün Fiyatını siler.
        /// </summary>
        /// <param name="id">Ürün Fiyat nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void ProductPricesIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductPricesIdDelete");
            
    
            var path = "/product_prices/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductPricesIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductPricesIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Ürün Fiyat Alma İlgili Ürün Fiyatını getirir.
        /// </summary>
        /// <param name="id">Ürün Fiyat nesnesinin id değeri</param> 
        /// <returns>ProductPrice</returns>            
        public ProductPrice ProductPricesIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductPricesIdGet");
            
    
            var path = "/product_prices/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductPricesIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductPricesIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductPrice) ApiClient.Deserialize(response.Content, typeof(ProductPrice), response.Headers);
        }
    
        /// <summary>
        /// Ürün Fiyat Güncelleme İlgili Ürün Fiyatını günceller.
        /// </summary>
        /// <param name="id">Ürün Fiyat nesnesinin id değeri</param> 
        /// <param name="productPrice">ProductPrice nesnesi</param> 
        /// <returns>ProductPrice</returns>            
        public ProductPrice ProductPricesIdPut (int? id, ProductPrice productPrice)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductPricesIdPut");
            
            // verify the required parameter 'productPrice' is set
            if (productPrice == null) throw new ApiException(400, "Missing required parameter 'productPrice' when calling ProductPricesIdPut");
            
    
            var path = "/product_prices/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(productPrice); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductPricesIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductPricesIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductPrice) ApiClient.Deserialize(response.Content, typeof(ProductPrice), response.Headers);
        }
    
        /// <summary>
        /// Ürün Fiyat Oluşturma Yeni bir Ürün Fiyat oluşturur.
        /// </summary>
        /// <param name="productPrice">ProductPrice nesnesi</param> 
        /// <returns>ProductPrice</returns>            
        public ProductPrice ProductPricesPost (ProductPrice productPrice)
        {
            
            // verify the required parameter 'productPrice' is set
            if (productPrice == null) throw new ApiException(400, "Missing required parameter 'productPrice' when calling ProductPricesPost");
            
    
            var path = "/product_prices";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(productPrice); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductPricesPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductPricesPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductPrice) ApiClient.Deserialize(response.Content, typeof(ProductPrice), response.Headers);
        }
    
    }
}
