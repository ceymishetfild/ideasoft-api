using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IPreOrderInfoApi
    {
        /// <summary>
        /// Sipariş Öncesi Bilgisi Listesi Alma Sipariş Öncesi Bilgisi listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="sessionId">Sipariş Öncesi Bilgisi session id.</param>
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param>
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param>
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param>
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param>
        /// <returns>PreOrderInfo</returns>
        PreOrderInfo PreOrderInfosGet (string sort, int? limit, int? page, int? sinceId, string sessionId, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt);
        /// <summary>
        /// Sipariş Öncesi Bilgisi Silme Kalıcı olarak ilgili Sipariş Öncesi Bilgisini siler.
        /// </summary>
        /// <param name="id">Sipariş Öncesi Bilgisi nesnesinin id değeri</param>
        /// <returns></returns>
        void PreOrderInfosIdDelete (int? id);
        /// <summary>
        /// Sipariş Öncesi Bilgisi Alma İlgili Sipariş Öncesi Bilgisini getirir.
        /// </summary>
        /// <param name="id">Sipariş Öncesi Bilgisi nesnesinin id değeri</param>
        /// <returns>PreOrderInfo</returns>
        PreOrderInfo PreOrderInfosIdGet (int? id);
        /// <summary>
        /// Sipariş Öncesi Bilgisi Güncelleme İlgili Sipariş Öncesi Bilgisini günceller.
        /// </summary>
        /// <param name="id">Sipariş Öncesi Bilgisi nesnesinin id değeri</param>
        /// <param name="preOrderInfo">PreOrderInfo nesnesi</param>
        /// <returns>PreOrderInfo</returns>
        PreOrderInfo PreOrderInfosIdPut (int? id, PreOrderInfo preOrderInfo);
        /// <summary>
        /// Sipariş Öncesi Bilgisi Oluşturma Yeni bir Sipariş Öncesi Bilgisi oluşturur.
        /// </summary>
        /// <param name="preOrderInfo">PreOrderInfo nesnesi</param>
        /// <returns>PreOrderInfo</returns>
        PreOrderInfo PreOrderInfosPost (PreOrderInfo preOrderInfo);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class PreOrderInfoApi : IPreOrderInfoApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PreOrderInfoApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public PreOrderInfoApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="PreOrderInfoApi"/> class.
        /// </summary>
        /// <returns></returns>
        public PreOrderInfoApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Sipariş Öncesi Bilgisi Listesi Alma Sipariş Öncesi Bilgisi listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="sessionId">Sipariş Öncesi Bilgisi session id.</param> 
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param> 
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param> 
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param> 
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param> 
        /// <returns>PreOrderInfo</returns>            
        public PreOrderInfo PreOrderInfosGet (string sort, int? limit, int? page, int? sinceId, string sessionId, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)
        {
            
    
            var path = "/pre_order_infos";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (sessionId != null) queryParams.Add("sessionId", ApiClient.ParameterToString(sessionId)); // query parameter
 if (startDate != null) queryParams.Add("startDate", ApiClient.ParameterToString(startDate)); // query parameter
 if (endDate != null) queryParams.Add("endDate", ApiClient.ParameterToString(endDate)); // query parameter
 if (startUpdatedAt != null) queryParams.Add("startUpdatedAt", ApiClient.ParameterToString(startUpdatedAt)); // query parameter
 if (endUpdatedAt != null) queryParams.Add("endUpdatedAt", ApiClient.ParameterToString(endUpdatedAt)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PreOrderInfosGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PreOrderInfosGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (PreOrderInfo) ApiClient.Deserialize(response.Content, typeof(PreOrderInfo), response.Headers);
        }
    
        /// <summary>
        /// Sipariş Öncesi Bilgisi Silme Kalıcı olarak ilgili Sipariş Öncesi Bilgisini siler.
        /// </summary>
        /// <param name="id">Sipariş Öncesi Bilgisi nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void PreOrderInfosIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling PreOrderInfosIdDelete");
            
    
            var path = "/pre_order_infos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PreOrderInfosIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PreOrderInfosIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Sipariş Öncesi Bilgisi Alma İlgili Sipariş Öncesi Bilgisini getirir.
        /// </summary>
        /// <param name="id">Sipariş Öncesi Bilgisi nesnesinin id değeri</param> 
        /// <returns>PreOrderInfo</returns>            
        public PreOrderInfo PreOrderInfosIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling PreOrderInfosIdGet");
            
    
            var path = "/pre_order_infos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PreOrderInfosIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PreOrderInfosIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (PreOrderInfo) ApiClient.Deserialize(response.Content, typeof(PreOrderInfo), response.Headers);
        }
    
        /// <summary>
        /// Sipariş Öncesi Bilgisi Güncelleme İlgili Sipariş Öncesi Bilgisini günceller.
        /// </summary>
        /// <param name="id">Sipariş Öncesi Bilgisi nesnesinin id değeri</param> 
        /// <param name="preOrderInfo">PreOrderInfo nesnesi</param> 
        /// <returns>PreOrderInfo</returns>            
        public PreOrderInfo PreOrderInfosIdPut (int? id, PreOrderInfo preOrderInfo)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling PreOrderInfosIdPut");
            
            // verify the required parameter 'preOrderInfo' is set
            if (preOrderInfo == null) throw new ApiException(400, "Missing required parameter 'preOrderInfo' when calling PreOrderInfosIdPut");
            
    
            var path = "/pre_order_infos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(preOrderInfo); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PreOrderInfosIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PreOrderInfosIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (PreOrderInfo) ApiClient.Deserialize(response.Content, typeof(PreOrderInfo), response.Headers);
        }
    
        /// <summary>
        /// Sipariş Öncesi Bilgisi Oluşturma Yeni bir Sipariş Öncesi Bilgisi oluşturur.
        /// </summary>
        /// <param name="preOrderInfo">PreOrderInfo nesnesi</param> 
        /// <returns>PreOrderInfo</returns>            
        public PreOrderInfo PreOrderInfosPost (PreOrderInfo preOrderInfo)
        {
            
            // verify the required parameter 'preOrderInfo' is set
            if (preOrderInfo == null) throw new ApiException(400, "Missing required parameter 'preOrderInfo' when calling PreOrderInfosPost");
            
    
            var path = "/pre_order_infos";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(preOrderInfo); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PreOrderInfosPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PreOrderInfosPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (PreOrderInfo) ApiClient.Deserialize(response.Content, typeof(PreOrderInfo), response.Headers);
        }
    
    }
}
