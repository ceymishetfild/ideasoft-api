using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IProductToCategoryApi
    {
        /// <summary>
        /// Ürün Kategori Bağı Listesi Alma Ürün Kategori Bağı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="product">Ürün id</param>
        /// <param name="category">Kategori id</param>
        /// <returns>ProductToCategory</returns>
        ProductToCategory ProductToCategoriesGet (string sort, int? limit, int? page, int? sinceId, int? product, int? category);
        /// <summary>
        /// Ürün Kategori Bağı Silme Kalıcı olarak ilgili Ürün Kategori Bağını siler.
        /// </summary>
        /// <param name="id">Ürün Kategori Bağı nesnesinin id değeri</param>
        /// <returns></returns>
        void ProductToCategoriesIdDelete (int? id);
        /// <summary>
        /// Ürün Kategori Bağı Alma İlgili Ürün Kategori Bağını getirir.
        /// </summary>
        /// <param name="id">Ürün Kategori Bağı nesnesinin id değeri</param>
        /// <returns>ProductToCategory</returns>
        ProductToCategory ProductToCategoriesIdGet (int? id);
        /// <summary>
        /// Ürün Kategori Bağı Güncelleme İlgili Ürün Kategori Bağını günceller.
        /// </summary>
        /// <param name="id">Ürün Kategori Bağı nesnesinin id değeri</param>
        /// <param name="productToCategory">ProductToCategory nesnesi</param>
        /// <returns>ProductToCategory</returns>
        ProductToCategory ProductToCategoriesIdPut (int? id, ProductToCategory productToCategory);
        /// <summary>
        /// Ürün Kategori Bağı Oluşturma Yeni bir Ürün Kategori Bağı oluşturur.
        /// </summary>
        /// <param name="productToCategory">ProductToCategory nesnesi</param>
        /// <returns>ProductToCategory</returns>
        ProductToCategory ProductToCategoriesPost (ProductToCategory productToCategory);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class ProductToCategoryApi : IProductToCategoryApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductToCategoryApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public ProductToCategoryApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductToCategoryApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ProductToCategoryApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ürün Kategori Bağı Listesi Alma Ürün Kategori Bağı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="product">Ürün id</param> 
        /// <param name="category">Kategori id</param> 
        /// <returns>ProductToCategory</returns>            
        public ProductToCategory ProductToCategoriesGet (string sort, int? limit, int? page, int? sinceId, int? product, int? category)
        {
            
    
            var path = "/product_to_categories";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (product != null) queryParams.Add("product", ApiClient.ParameterToString(product)); // query parameter
 if (category != null) queryParams.Add("category", ApiClient.ParameterToString(category)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCategoriesGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCategoriesGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductToCategory) ApiClient.Deserialize(response.Content, typeof(ProductToCategory), response.Headers);
        }
    
        /// <summary>
        /// Ürün Kategori Bağı Silme Kalıcı olarak ilgili Ürün Kategori Bağını siler.
        /// </summary>
        /// <param name="id">Ürün Kategori Bağı nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void ProductToCategoriesIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductToCategoriesIdDelete");
            
    
            var path = "/product_to_categories/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCategoriesIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCategoriesIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Ürün Kategori Bağı Alma İlgili Ürün Kategori Bağını getirir.
        /// </summary>
        /// <param name="id">Ürün Kategori Bağı nesnesinin id değeri</param> 
        /// <returns>ProductToCategory</returns>            
        public ProductToCategory ProductToCategoriesIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductToCategoriesIdGet");
            
    
            var path = "/product_to_categories/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCategoriesIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCategoriesIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductToCategory) ApiClient.Deserialize(response.Content, typeof(ProductToCategory), response.Headers);
        }
    
        /// <summary>
        /// Ürün Kategori Bağı Güncelleme İlgili Ürün Kategori Bağını günceller.
        /// </summary>
        /// <param name="id">Ürün Kategori Bağı nesnesinin id değeri</param> 
        /// <param name="productToCategory">ProductToCategory nesnesi</param> 
        /// <returns>ProductToCategory</returns>            
        public ProductToCategory ProductToCategoriesIdPut (int? id, ProductToCategory productToCategory)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductToCategoriesIdPut");
            
            // verify the required parameter 'productToCategory' is set
            if (productToCategory == null) throw new ApiException(400, "Missing required parameter 'productToCategory' when calling ProductToCategoriesIdPut");
            
    
            var path = "/product_to_categories/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(productToCategory); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCategoriesIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCategoriesIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductToCategory) ApiClient.Deserialize(response.Content, typeof(ProductToCategory), response.Headers);
        }
    
        /// <summary>
        /// Ürün Kategori Bağı Oluşturma Yeni bir Ürün Kategori Bağı oluşturur.
        /// </summary>
        /// <param name="productToCategory">ProductToCategory nesnesi</param> 
        /// <returns>ProductToCategory</returns>            
        public ProductToCategory ProductToCategoriesPost (ProductToCategory productToCategory)
        {
            
            // verify the required parameter 'productToCategory' is set
            if (productToCategory == null) throw new ApiException(400, "Missing required parameter 'productToCategory' when calling ProductToCategoriesPost");
            
    
            var path = "/product_to_categories";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(productToCategory); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCategoriesPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductToCategoriesPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductToCategory) ApiClient.Deserialize(response.Content, typeof(ProductToCategory), response.Headers);
        }
    
    }
}
