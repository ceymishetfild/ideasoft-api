using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IProductProtectionApi
    {
        /// <summary>
        /// Entegrasyon Seçeneği Listesi Alma Entegrasyon Seçeneği listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="isPriceProtected">Fiyat korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param>
        /// <param name="isStockProtected">Stok korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param>
        /// <param name="product">Ürün id</param>
        /// <returns>ProductProtection</returns>
        ProductProtection ProductProtectionsGet (string sort, int? limit, int? page, int? sinceId, int? isPriceProtected, int? isStockProtected, int? product);
        /// <summary>
        /// Entegrasyon Seçeneği Silme Kalıcı olarak ilgili Entegrasyon Seçeneğini siler.
        /// </summary>
        /// <param name="id">Entegrasyon Seçeneği nesnesinin id değeri</param>
        /// <returns></returns>
        void ProductProtectionsIdDelete (int? id);
        /// <summary>
        /// Entegrasyon Seçeneği Alma İlgili Entegrasyon Seçeneğini getirir.
        /// </summary>
        /// <param name="id">Entegrasyon Seçeneği nesnesinin id değeri</param>
        /// <returns>ProductProtection</returns>
        ProductProtection ProductProtectionsIdGet (int? id);
        /// <summary>
        /// Entegrasyon Seçeneği Güncelleme İlgili Entegrasyon Seçeneğini günceller.
        /// </summary>
        /// <param name="id">Entegrasyon Seçeneği nesnesinin id değeri</param>
        /// <param name="productProtection">ProductProtection nesnesi</param>
        /// <returns>ProductProtection</returns>
        ProductProtection ProductProtectionsIdPut (int? id, ProductProtection productProtection);
        /// <summary>
        /// Entegrasyon Seçeneği Oluşturma Yeni bir Entegrasyon Seçeneği oluşturur.
        /// </summary>
        /// <param name="productProtection">ProductProtection nesnesi</param>
        /// <returns>ProductProtection</returns>
        ProductProtection ProductProtectionsPost (ProductProtection productProtection);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class ProductProtectionApi : IProductProtectionApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductProtectionApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public ProductProtectionApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductProtectionApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ProductProtectionApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Entegrasyon Seçeneği Listesi Alma Entegrasyon Seçeneği listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="isPriceProtected">Fiyat korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param> 
        /// <param name="isStockProtected">Stok korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt;</param> 
        /// <param name="product">Ürün id</param> 
        /// <returns>ProductProtection</returns>            
        public ProductProtection ProductProtectionsGet (string sort, int? limit, int? page, int? sinceId, int? isPriceProtected, int? isStockProtected, int? product)
        {
            
    
            var path = "/product_protections";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (isPriceProtected != null) queryParams.Add("isPriceProtected", ApiClient.ParameterToString(isPriceProtected)); // query parameter
 if (isStockProtected != null) queryParams.Add("isStockProtected", ApiClient.ParameterToString(isStockProtected)); // query parameter
 if (product != null) queryParams.Add("product", ApiClient.ParameterToString(product)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductProtectionsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductProtectionsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductProtection) ApiClient.Deserialize(response.Content, typeof(ProductProtection), response.Headers);
        }
    
        /// <summary>
        /// Entegrasyon Seçeneği Silme Kalıcı olarak ilgili Entegrasyon Seçeneğini siler.
        /// </summary>
        /// <param name="id">Entegrasyon Seçeneği nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void ProductProtectionsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductProtectionsIdDelete");
            
    
            var path = "/product_protections/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductProtectionsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductProtectionsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Entegrasyon Seçeneği Alma İlgili Entegrasyon Seçeneğini getirir.
        /// </summary>
        /// <param name="id">Entegrasyon Seçeneği nesnesinin id değeri</param> 
        /// <returns>ProductProtection</returns>            
        public ProductProtection ProductProtectionsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductProtectionsIdGet");
            
    
            var path = "/product_protections/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductProtectionsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductProtectionsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductProtection) ApiClient.Deserialize(response.Content, typeof(ProductProtection), response.Headers);
        }
    
        /// <summary>
        /// Entegrasyon Seçeneği Güncelleme İlgili Entegrasyon Seçeneğini günceller.
        /// </summary>
        /// <param name="id">Entegrasyon Seçeneği nesnesinin id değeri</param> 
        /// <param name="productProtection">ProductProtection nesnesi</param> 
        /// <returns>ProductProtection</returns>            
        public ProductProtection ProductProtectionsIdPut (int? id, ProductProtection productProtection)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductProtectionsIdPut");
            
            // verify the required parameter 'productProtection' is set
            if (productProtection == null) throw new ApiException(400, "Missing required parameter 'productProtection' when calling ProductProtectionsIdPut");
            
    
            var path = "/product_protections/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(productProtection); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductProtectionsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductProtectionsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductProtection) ApiClient.Deserialize(response.Content, typeof(ProductProtection), response.Headers);
        }
    
        /// <summary>
        /// Entegrasyon Seçeneği Oluşturma Yeni bir Entegrasyon Seçeneği oluşturur.
        /// </summary>
        /// <param name="productProtection">ProductProtection nesnesi</param> 
        /// <returns>ProductProtection</returns>            
        public ProductProtection ProductProtectionsPost (ProductProtection productProtection)
        {
            
            // verify the required parameter 'productProtection' is set
            if (productProtection == null) throw new ApiException(400, "Missing required parameter 'productProtection' when calling ProductProtectionsPost");
            
    
            var path = "/product_protections";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(productProtection); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductProtectionsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductProtectionsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductProtection) ApiClient.Deserialize(response.Content, typeof(ProductProtection), response.Headers);
        }
    
    }
}
