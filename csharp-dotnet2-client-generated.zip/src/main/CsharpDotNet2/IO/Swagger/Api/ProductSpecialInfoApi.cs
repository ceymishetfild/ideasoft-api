using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IProductSpecialInfoApi
    {
        /// <summary>
        /// Ürün Özel Bilgi Alanı Listesi Alma Ürün Özel Bilgi Alanı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param>
        /// <param name="title">Ürün Özel Bilgi Alanı başlığı</param>
        /// <param name="status">Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif</param>
        /// <param name="product">Ürün id</param>
        /// <returns>ProductSpecialInfo</returns>
        ProductSpecialInfo ProductSpecialInfosGet (string sort, int? limit, int? page, int? sinceId, string ids, string title, string status, int? product);
        /// <summary>
        /// Ürün Özel Bilgi Alanı Kalıcı olarak ilgili Ürün Özel Bilgi Alanını siler.
        /// </summary>
        /// <param name="id">Ürün Özel Bilgi Alanı nesnesinin id değeri</param>
        /// <returns></returns>
        void ProductSpecialInfosIdDelete (int? id);
        /// <summary>
        /// Ürün Özel Bilgi Alanı İlgili Ürün Özel Bilgi Alanını getirir.
        /// </summary>
        /// <param name="id">Ürün Özel Bilgi Alanı nesnesinin id değeri</param>
        /// <returns>ProductSpecialInfo</returns>
        ProductSpecialInfo ProductSpecialInfosIdGet (int? id);
        /// <summary>
        /// Ürün Özel Bilgi Alanı Güncelleme İlgili Ürün Özel Bilgi Alanını günceller.
        /// </summary>
        /// <param name="id">Ürün Özel Bilgi Alanı nesnesinin id değeri</param>
        /// <param name="productSpecialInfo"> nesnesi</param>
        /// <returns>ProductSpecialInfo</returns>
        ProductSpecialInfo ProductSpecialInfosIdPut (int? id, ProductSpecialInfo productSpecialInfo);
        /// <summary>
        /// Ürün Özel Bilgi Alanı Oluşturma Yeni bir Ürün Özel Bilgi Alanı oluşturur.
        /// </summary>
        /// <param name="productSpecialInfo"> nesnesi</param>
        /// <returns>ProductSpecialInfo</returns>
        ProductSpecialInfo ProductSpecialInfosPost (ProductSpecialInfo productSpecialInfo);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class ProductSpecialInfoApi : IProductSpecialInfoApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductSpecialInfoApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public ProductSpecialInfoApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductSpecialInfoApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ProductSpecialInfoApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ürün Özel Bilgi Alanı Listesi Alma Ürün Özel Bilgi Alanı listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param> 
        /// <param name="title">Ürün Özel Bilgi Alanı başlığı</param> 
        /// <param name="status">Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif</param> 
        /// <param name="product">Ürün id</param> 
        /// <returns>ProductSpecialInfo</returns>            
        public ProductSpecialInfo ProductSpecialInfosGet (string sort, int? limit, int? page, int? sinceId, string ids, string title, string status, int? product)
        {
            
    
            var path = "/product_special_infos";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (ids != null) queryParams.Add("ids", ApiClient.ParameterToString(ids)); // query parameter
 if (title != null) queryParams.Add("title", ApiClient.ParameterToString(title)); // query parameter
 if (status != null) queryParams.Add("status", ApiClient.ParameterToString(status)); // query parameter
 if (product != null) queryParams.Add("product", ApiClient.ParameterToString(product)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductSpecialInfosGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductSpecialInfosGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductSpecialInfo) ApiClient.Deserialize(response.Content, typeof(ProductSpecialInfo), response.Headers);
        }
    
        /// <summary>
        /// Ürün Özel Bilgi Alanı Kalıcı olarak ilgili Ürün Özel Bilgi Alanını siler.
        /// </summary>
        /// <param name="id">Ürün Özel Bilgi Alanı nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void ProductSpecialInfosIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductSpecialInfosIdDelete");
            
    
            var path = "/product_special_infos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductSpecialInfosIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductSpecialInfosIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Ürün Özel Bilgi Alanı İlgili Ürün Özel Bilgi Alanını getirir.
        /// </summary>
        /// <param name="id">Ürün Özel Bilgi Alanı nesnesinin id değeri</param> 
        /// <returns>ProductSpecialInfo</returns>            
        public ProductSpecialInfo ProductSpecialInfosIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductSpecialInfosIdGet");
            
    
            var path = "/product_special_infos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductSpecialInfosIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductSpecialInfosIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductSpecialInfo) ApiClient.Deserialize(response.Content, typeof(ProductSpecialInfo), response.Headers);
        }
    
        /// <summary>
        /// Ürün Özel Bilgi Alanı Güncelleme İlgili Ürün Özel Bilgi Alanını günceller.
        /// </summary>
        /// <param name="id">Ürün Özel Bilgi Alanı nesnesinin id değeri</param> 
        /// <param name="productSpecialInfo"> nesnesi</param> 
        /// <returns>ProductSpecialInfo</returns>            
        public ProductSpecialInfo ProductSpecialInfosIdPut (int? id, ProductSpecialInfo productSpecialInfo)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductSpecialInfosIdPut");
            
            // verify the required parameter 'productSpecialInfo' is set
            if (productSpecialInfo == null) throw new ApiException(400, "Missing required parameter 'productSpecialInfo' when calling ProductSpecialInfosIdPut");
            
    
            var path = "/product_special_infos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(productSpecialInfo); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductSpecialInfosIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductSpecialInfosIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductSpecialInfo) ApiClient.Deserialize(response.Content, typeof(ProductSpecialInfo), response.Headers);
        }
    
        /// <summary>
        /// Ürün Özel Bilgi Alanı Oluşturma Yeni bir Ürün Özel Bilgi Alanı oluşturur.
        /// </summary>
        /// <param name="productSpecialInfo"> nesnesi</param> 
        /// <returns>ProductSpecialInfo</returns>            
        public ProductSpecialInfo ProductSpecialInfosPost (ProductSpecialInfo productSpecialInfo)
        {
            
            // verify the required parameter 'productSpecialInfo' is set
            if (productSpecialInfo == null) throw new ApiException(400, "Missing required parameter 'productSpecialInfo' when calling ProductSpecialInfosPost");
            
    
            var path = "/product_special_infos";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(productSpecialInfo); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductSpecialInfosPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductSpecialInfosPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductSpecialInfo) ApiClient.Deserialize(response.Content, typeof(ProductSpecialInfo), response.Headers);
        }
    
    }
}
