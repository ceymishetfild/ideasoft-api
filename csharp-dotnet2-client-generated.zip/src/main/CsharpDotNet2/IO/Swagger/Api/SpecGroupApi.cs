using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ISpecGroupApi
    {
        /// <summary>
        /// Ürün Özellik Grubu Listesi Alma Ürün Özellik Grubu listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="name">Ürün Özellik Grubu adı</param>
        /// <returns>SpecGroup</returns>
        SpecGroup SpecGroupsGet (string sort, int? limit, int? page, int? sinceId, string name);
        /// <summary>
        /// Ürün Özellik Grubu Silme Kalıcı olarak ilgili Ürün Özellik Grubunu siler.
        /// </summary>
        /// <param name="id">Ürün Özellik Grubu nesnesinin id değeri</param>
        /// <returns></returns>
        void SpecGroupsIdDelete (int? id);
        /// <summary>
        /// Ürün Özellik Grubu Alma İlgili Ürün Özellik Grubunu getirir.
        /// </summary>
        /// <param name="id">Ürün Özellik Grubu nesnesinin id değeri</param>
        /// <returns>SpecGroup</returns>
        SpecGroup SpecGroupsIdGet (int? id);
        /// <summary>
        /// Ürün Özellik Grubu Güncelleme İlgili Ürün Özellik Grubunu günceller.
        /// </summary>
        /// <param name="id">Ürün Özellik Grubu nesnesinin id değeri</param>
        /// <param name="specGroup">SpecGroup nesnesi</param>
        /// <returns>SpecGroup</returns>
        SpecGroup SpecGroupsIdPut (int? id, SpecGroup specGroup);
        /// <summary>
        /// Ürün Özellik Grubu Oluşturma Yeni bir Ürün Özellik Grubu oluşturur.
        /// </summary>
        /// <param name="specGroup">SpecGroup nesnesi</param>
        /// <returns>SpecGroup</returns>
        SpecGroup SpecGroupsPost (SpecGroup specGroup);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class SpecGroupApi : ISpecGroupApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SpecGroupApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public SpecGroupApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="SpecGroupApi"/> class.
        /// </summary>
        /// <returns></returns>
        public SpecGroupApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ürün Özellik Grubu Listesi Alma Ürün Özellik Grubu listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="name">Ürün Özellik Grubu adı</param> 
        /// <returns>SpecGroup</returns>            
        public SpecGroup SpecGroupsGet (string sort, int? limit, int? page, int? sinceId, string name)
        {
            
    
            var path = "/spec_groups";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (name != null) queryParams.Add("name", ApiClient.ParameterToString(name)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecGroupsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecGroupsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecGroup) ApiClient.Deserialize(response.Content, typeof(SpecGroup), response.Headers);
        }
    
        /// <summary>
        /// Ürün Özellik Grubu Silme Kalıcı olarak ilgili Ürün Özellik Grubunu siler.
        /// </summary>
        /// <param name="id">Ürün Özellik Grubu nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void SpecGroupsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SpecGroupsIdDelete");
            
    
            var path = "/spec_groups/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecGroupsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecGroupsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Ürün Özellik Grubu Alma İlgili Ürün Özellik Grubunu getirir.
        /// </summary>
        /// <param name="id">Ürün Özellik Grubu nesnesinin id değeri</param> 
        /// <returns>SpecGroup</returns>            
        public SpecGroup SpecGroupsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SpecGroupsIdGet");
            
    
            var path = "/spec_groups/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecGroupsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecGroupsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecGroup) ApiClient.Deserialize(response.Content, typeof(SpecGroup), response.Headers);
        }
    
        /// <summary>
        /// Ürün Özellik Grubu Güncelleme İlgili Ürün Özellik Grubunu günceller.
        /// </summary>
        /// <param name="id">Ürün Özellik Grubu nesnesinin id değeri</param> 
        /// <param name="specGroup">SpecGroup nesnesi</param> 
        /// <returns>SpecGroup</returns>            
        public SpecGroup SpecGroupsIdPut (int? id, SpecGroup specGroup)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SpecGroupsIdPut");
            
            // verify the required parameter 'specGroup' is set
            if (specGroup == null) throw new ApiException(400, "Missing required parameter 'specGroup' when calling SpecGroupsIdPut");
            
    
            var path = "/spec_groups/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(specGroup); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecGroupsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecGroupsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecGroup) ApiClient.Deserialize(response.Content, typeof(SpecGroup), response.Headers);
        }
    
        /// <summary>
        /// Ürün Özellik Grubu Oluşturma Yeni bir Ürün Özellik Grubu oluşturur.
        /// </summary>
        /// <param name="specGroup">SpecGroup nesnesi</param> 
        /// <returns>SpecGroup</returns>            
        public SpecGroup SpecGroupsPost (SpecGroup specGroup)
        {
            
            // verify the required parameter 'specGroup' is set
            if (specGroup == null) throw new ApiException(400, "Missing required parameter 'specGroup' when calling SpecGroupsPost");
            
    
            var path = "/spec_groups";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(specGroup); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecGroupsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SpecGroupsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SpecGroup) ApiClient.Deserialize(response.Content, typeof(SpecGroup), response.Headers);
        }
    
    }
}
