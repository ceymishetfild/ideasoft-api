using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IOrderRefundRequestItemApi
    {
        /// <summary>
        /// Sipariş İptal Talebi Kalemi Listesi Alma Sipariş İptal Talebi Kalemi listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="orderRefundRequest">Sipariş iptal talebi id</param>
        /// <param name="orderItem">Sipariş ürünü id</param>
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param>
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param>
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param>
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param>
        /// <returns>OrderRefundRequestItem</returns>
        OrderRefundRequestItem OrderRefundRequestItemsGet (string sort, int? limit, int? page, int? sinceId, int? orderRefundRequest, int? orderItem, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt);
        /// <summary>
        /// Sipariş İptal Talebi Kalemi Silme Kalıcı olarak ilgili Sipariş İptal Talebi Kalemini siler.
        /// </summary>
        /// <param name="id">Sipariş İptal Talebi Kalemi nesnesinin id değeri</param>
        /// <returns></returns>
        void OrderRefundRequestItemsIdDelete (int? id);
        /// <summary>
        /// Sipariş İptal Talebi Kalemi Alma İlgili Sipariş İptal Talebi Kalemini getirir.
        /// </summary>
        /// <param name="id">Sipariş İptal Talebi Kalemi nesnesinin id değeri</param>
        /// <returns>OrderRefundRequestItem</returns>
        OrderRefundRequestItem OrderRefundRequestItemsIdGet (int? id);
        /// <summary>
        /// Sipariş İptal Talebi Kalemi Güncelleme İlgili Sipariş İptal Talebi Kalemini günceller.
        /// </summary>
        /// <param name="id">Sipariş İptal Talebi Kalemi nesnesinin id değeri</param>
        /// <param name="orderRefundRequestItem">OrderRefundRequestItem nesnesi</param>
        /// <returns>OrderRefundRequestItem</returns>
        OrderRefundRequestItem OrderRefundRequestItemsIdPut (int? id, OrderRefundRequestItem orderRefundRequestItem);
        /// <summary>
        /// Sipariş İptal Talebi Kalemi Oluşturma Yeni bir Sipariş İptal Talebi Kalemi oluşturur.
        /// </summary>
        /// <param name="orderRefundRequestItem">OrderRefundRequestItem nesnesi</param>
        /// <returns>OrderRefundRequestItem</returns>
        OrderRefundRequestItem OrderRefundRequestItemsPost (OrderRefundRequestItem orderRefundRequestItem);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class OrderRefundRequestItemApi : IOrderRefundRequestItemApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OrderRefundRequestItemApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public OrderRefundRequestItemApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="OrderRefundRequestItemApi"/> class.
        /// </summary>
        /// <returns></returns>
        public OrderRefundRequestItemApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Sipariş İptal Talebi Kalemi Listesi Alma Sipariş İptal Talebi Kalemi listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="orderRefundRequest">Sipariş iptal talebi id</param> 
        /// <param name="orderItem">Sipariş ürünü id</param> 
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param> 
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param> 
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param> 
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param> 
        /// <returns>OrderRefundRequestItem</returns>            
        public OrderRefundRequestItem OrderRefundRequestItemsGet (string sort, int? limit, int? page, int? sinceId, int? orderRefundRequest, int? orderItem, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)
        {
            
    
            var path = "/order_refund_request_items";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (orderRefundRequest != null) queryParams.Add("orderRefundRequest", ApiClient.ParameterToString(orderRefundRequest)); // query parameter
 if (orderItem != null) queryParams.Add("orderItem", ApiClient.ParameterToString(orderItem)); // query parameter
 if (startDate != null) queryParams.Add("startDate", ApiClient.ParameterToString(startDate)); // query parameter
 if (endDate != null) queryParams.Add("endDate", ApiClient.ParameterToString(endDate)); // query parameter
 if (startUpdatedAt != null) queryParams.Add("startUpdatedAt", ApiClient.ParameterToString(startUpdatedAt)); // query parameter
 if (endUpdatedAt != null) queryParams.Add("endUpdatedAt", ApiClient.ParameterToString(endUpdatedAt)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestItemsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestItemsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OrderRefundRequestItem) ApiClient.Deserialize(response.Content, typeof(OrderRefundRequestItem), response.Headers);
        }
    
        /// <summary>
        /// Sipariş İptal Talebi Kalemi Silme Kalıcı olarak ilgili Sipariş İptal Talebi Kalemini siler.
        /// </summary>
        /// <param name="id">Sipariş İptal Talebi Kalemi nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void OrderRefundRequestItemsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OrderRefundRequestItemsIdDelete");
            
    
            var path = "/order_refund_request_items/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestItemsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestItemsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Sipariş İptal Talebi Kalemi Alma İlgili Sipariş İptal Talebi Kalemini getirir.
        /// </summary>
        /// <param name="id">Sipariş İptal Talebi Kalemi nesnesinin id değeri</param> 
        /// <returns>OrderRefundRequestItem</returns>            
        public OrderRefundRequestItem OrderRefundRequestItemsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OrderRefundRequestItemsIdGet");
            
    
            var path = "/order_refund_request_items/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestItemsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestItemsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OrderRefundRequestItem) ApiClient.Deserialize(response.Content, typeof(OrderRefundRequestItem), response.Headers);
        }
    
        /// <summary>
        /// Sipariş İptal Talebi Kalemi Güncelleme İlgili Sipariş İptal Talebi Kalemini günceller.
        /// </summary>
        /// <param name="id">Sipariş İptal Talebi Kalemi nesnesinin id değeri</param> 
        /// <param name="orderRefundRequestItem">OrderRefundRequestItem nesnesi</param> 
        /// <returns>OrderRefundRequestItem</returns>            
        public OrderRefundRequestItem OrderRefundRequestItemsIdPut (int? id, OrderRefundRequestItem orderRefundRequestItem)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling OrderRefundRequestItemsIdPut");
            
            // verify the required parameter 'orderRefundRequestItem' is set
            if (orderRefundRequestItem == null) throw new ApiException(400, "Missing required parameter 'orderRefundRequestItem' when calling OrderRefundRequestItemsIdPut");
            
    
            var path = "/order_refund_request_items/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(orderRefundRequestItem); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestItemsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestItemsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OrderRefundRequestItem) ApiClient.Deserialize(response.Content, typeof(OrderRefundRequestItem), response.Headers);
        }
    
        /// <summary>
        /// Sipariş İptal Talebi Kalemi Oluşturma Yeni bir Sipariş İptal Talebi Kalemi oluşturur.
        /// </summary>
        /// <param name="orderRefundRequestItem">OrderRefundRequestItem nesnesi</param> 
        /// <returns>OrderRefundRequestItem</returns>            
        public OrderRefundRequestItem OrderRefundRequestItemsPost (OrderRefundRequestItem orderRefundRequestItem)
        {
            
            // verify the required parameter 'orderRefundRequestItem' is set
            if (orderRefundRequestItem == null) throw new ApiException(400, "Missing required parameter 'orderRefundRequestItem' when calling OrderRefundRequestItemsPost");
            
    
            var path = "/order_refund_request_items";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(orderRefundRequestItem); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestItemsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling OrderRefundRequestItemsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (OrderRefundRequestItem) ApiClient.Deserialize(response.Content, typeof(OrderRefundRequestItem), response.Headers);
        }
    
    }
}
