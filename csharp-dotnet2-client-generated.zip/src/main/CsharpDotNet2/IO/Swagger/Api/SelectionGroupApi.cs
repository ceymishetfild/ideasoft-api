using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ISelectionGroupApi
    {
        /// <summary>
        /// Ek Özellik Grubu Listesi Alma Ek Özellik Grubu listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param>
        /// <param name="title">Ek Özellik Grubu başlığı</param>
        /// <returns>SelectionGroup</returns>
        SelectionGroup SelectionGroupsGet (string sort, int? limit, int? page, int? sinceId, string ids, string title);
        /// <summary>
        /// Ek Özellik Grubu Silme Kalıcı olarak ilgili Ek Özellik Grubunu siler.
        /// </summary>
        /// <param name="id">Ek Özellik Grubu nesnesinin id değeri</param>
        /// <returns></returns>
        void SelectionGroupsIdDelete (int? id);
        /// <summary>
        /// Ek Özellik Grubu Alma İlgili Ek Özellik Grubunu getirir.
        /// </summary>
        /// <param name="id">Ek Özellik Grubu nesnesinin id değeri</param>
        /// <returns>SelectionGroup</returns>
        SelectionGroup SelectionGroupsIdGet (int? id);
        /// <summary>
        /// Ek Özellik Grubu Güncelleme İlgili Ek Özellik Grubunu günceller.
        /// </summary>
        /// <param name="id">Ek Özellik Grubu nesnesinin id değeri</param>
        /// <param name="selectionGroup"> nesnesi</param>
        /// <returns>SelectionGroup</returns>
        SelectionGroup SelectionGroupsIdPut (int? id, SelectionGroup selectionGroup);
        /// <summary>
        /// Ek Özellik Grubu Oluşturma Yeni bir Ek Özellik Grubu oluşturur.
        /// </summary>
        /// <param name="selectionGroup"> nesnesi</param>
        /// <returns>SelectionGroup</returns>
        SelectionGroup SelectionGroupsPost (SelectionGroup selectionGroup);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class SelectionGroupApi : ISelectionGroupApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SelectionGroupApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public SelectionGroupApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="SelectionGroupApi"/> class.
        /// </summary>
        /// <returns></returns>
        public SelectionGroupApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ek Özellik Grubu Listesi Alma Ek Özellik Grubu listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="ids">Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt; </param> 
        /// <param name="title">Ek Özellik Grubu başlığı</param> 
        /// <returns>SelectionGroup</returns>            
        public SelectionGroup SelectionGroupsGet (string sort, int? limit, int? page, int? sinceId, string ids, string title)
        {
            
    
            var path = "/selection_groups";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (ids != null) queryParams.Add("ids", ApiClient.ParameterToString(ids)); // query parameter
 if (title != null) queryParams.Add("title", ApiClient.ParameterToString(title)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionGroupsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionGroupsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SelectionGroup) ApiClient.Deserialize(response.Content, typeof(SelectionGroup), response.Headers);
        }
    
        /// <summary>
        /// Ek Özellik Grubu Silme Kalıcı olarak ilgili Ek Özellik Grubunu siler.
        /// </summary>
        /// <param name="id">Ek Özellik Grubu nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void SelectionGroupsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SelectionGroupsIdDelete");
            
    
            var path = "/selection_groups/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionGroupsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionGroupsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Ek Özellik Grubu Alma İlgili Ek Özellik Grubunu getirir.
        /// </summary>
        /// <param name="id">Ek Özellik Grubu nesnesinin id değeri</param> 
        /// <returns>SelectionGroup</returns>            
        public SelectionGroup SelectionGroupsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SelectionGroupsIdGet");
            
    
            var path = "/selection_groups/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionGroupsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionGroupsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SelectionGroup) ApiClient.Deserialize(response.Content, typeof(SelectionGroup), response.Headers);
        }
    
        /// <summary>
        /// Ek Özellik Grubu Güncelleme İlgili Ek Özellik Grubunu günceller.
        /// </summary>
        /// <param name="id">Ek Özellik Grubu nesnesinin id değeri</param> 
        /// <param name="selectionGroup"> nesnesi</param> 
        /// <returns>SelectionGroup</returns>            
        public SelectionGroup SelectionGroupsIdPut (int? id, SelectionGroup selectionGroup)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling SelectionGroupsIdPut");
            
            // verify the required parameter 'selectionGroup' is set
            if (selectionGroup == null) throw new ApiException(400, "Missing required parameter 'selectionGroup' when calling SelectionGroupsIdPut");
            
    
            var path = "/selection_groups/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(selectionGroup); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionGroupsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionGroupsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SelectionGroup) ApiClient.Deserialize(response.Content, typeof(SelectionGroup), response.Headers);
        }
    
        /// <summary>
        /// Ek Özellik Grubu Oluşturma Yeni bir Ek Özellik Grubu oluşturur.
        /// </summary>
        /// <param name="selectionGroup"> nesnesi</param> 
        /// <returns>SelectionGroup</returns>            
        public SelectionGroup SelectionGroupsPost (SelectionGroup selectionGroup)
        {
            
            // verify the required parameter 'selectionGroup' is set
            if (selectionGroup == null) throw new ApiException(400, "Missing required parameter 'selectionGroup' when calling SelectionGroupsPost");
            
    
            var path = "/selection_groups";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(selectionGroup); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionGroupsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling SelectionGroupsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (SelectionGroup) ApiClient.Deserialize(response.Content, typeof(SelectionGroup), response.Headers);
        }
    
    }
}
