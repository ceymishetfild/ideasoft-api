using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IMemberGroupApi
    {
        /// <summary>
        /// Üye Grubu Listesi Alma Üye Grubu listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="name">Üye Grubu adı</param>
        /// <returns>MemberGroup</returns>
        MemberGroup MemberGroupsGet (string sort, int? limit, int? page, int? sinceId, string name);
        /// <summary>
        /// Üye Grubu Silme Kalıcı olarak ilgili Üye Grubunu siler.
        /// </summary>
        /// <param name="id">Üye Grubu nesnesinin id değeri</param>
        /// <returns></returns>
        void MemberGroupsIdDelete (int? id);
        /// <summary>
        /// Üye Grubu Alma İlgili Üye Grubunu getirir.
        /// </summary>
        /// <param name="id">Üye Grubu nesnesinin id değeri</param>
        /// <returns>MemberGroup</returns>
        MemberGroup MemberGroupsIdGet (int? id);
        /// <summary>
        /// Üye Grubu Güncelleme İlgili Üye Grubunu günceller.
        /// </summary>
        /// <param name="id">Üye Grubu nesnesinin id değeri</param>
        /// <param name="memberGroup">MemberGroup nesnesi</param>
        /// <returns>MemberGroup</returns>
        MemberGroup MemberGroupsIdPut (int? id, MemberGroup memberGroup);
        /// <summary>
        /// Üye Grubu Oluşturma Yeni bir Üye Grubu oluşturur.
        /// </summary>
        /// <param name="memberGroup">MemberGroup nesnesi</param>
        /// <returns>MemberGroup</returns>
        MemberGroup MemberGroupsPost (MemberGroup memberGroup);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class MemberGroupApi : IMemberGroupApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MemberGroupApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public MemberGroupApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="MemberGroupApi"/> class.
        /// </summary>
        /// <returns></returns>
        public MemberGroupApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Üye Grubu Listesi Alma Üye Grubu listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="name">Üye Grubu adı</param> 
        /// <returns>MemberGroup</returns>            
        public MemberGroup MemberGroupsGet (string sort, int? limit, int? page, int? sinceId, string name)
        {
            
    
            var path = "/member_groups";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (name != null) queryParams.Add("name", ApiClient.ParameterToString(name)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberGroupsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberGroupsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (MemberGroup) ApiClient.Deserialize(response.Content, typeof(MemberGroup), response.Headers);
        }
    
        /// <summary>
        /// Üye Grubu Silme Kalıcı olarak ilgili Üye Grubunu siler.
        /// </summary>
        /// <param name="id">Üye Grubu nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void MemberGroupsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling MemberGroupsIdDelete");
            
    
            var path = "/member_groups/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberGroupsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberGroupsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Üye Grubu Alma İlgili Üye Grubunu getirir.
        /// </summary>
        /// <param name="id">Üye Grubu nesnesinin id değeri</param> 
        /// <returns>MemberGroup</returns>            
        public MemberGroup MemberGroupsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling MemberGroupsIdGet");
            
    
            var path = "/member_groups/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberGroupsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberGroupsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (MemberGroup) ApiClient.Deserialize(response.Content, typeof(MemberGroup), response.Headers);
        }
    
        /// <summary>
        /// Üye Grubu Güncelleme İlgili Üye Grubunu günceller.
        /// </summary>
        /// <param name="id">Üye Grubu nesnesinin id değeri</param> 
        /// <param name="memberGroup">MemberGroup nesnesi</param> 
        /// <returns>MemberGroup</returns>            
        public MemberGroup MemberGroupsIdPut (int? id, MemberGroup memberGroup)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling MemberGroupsIdPut");
            
            // verify the required parameter 'memberGroup' is set
            if (memberGroup == null) throw new ApiException(400, "Missing required parameter 'memberGroup' when calling MemberGroupsIdPut");
            
    
            var path = "/member_groups/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(memberGroup); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberGroupsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberGroupsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (MemberGroup) ApiClient.Deserialize(response.Content, typeof(MemberGroup), response.Headers);
        }
    
        /// <summary>
        /// Üye Grubu Oluşturma Yeni bir Üye Grubu oluşturur.
        /// </summary>
        /// <param name="memberGroup">MemberGroup nesnesi</param> 
        /// <returns>MemberGroup</returns>            
        public MemberGroup MemberGroupsPost (MemberGroup memberGroup)
        {
            
            // verify the required parameter 'memberGroup' is set
            if (memberGroup == null) throw new ApiException(400, "Missing required parameter 'memberGroup' when calling MemberGroupsPost");
            
    
            var path = "/member_groups";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(memberGroup); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberGroupsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MemberGroupsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (MemberGroup) ApiClient.Deserialize(response.Content, typeof(MemberGroup), response.Headers);
        }
    
    }
}
