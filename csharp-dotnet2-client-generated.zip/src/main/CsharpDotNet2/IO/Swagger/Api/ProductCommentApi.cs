using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IProductCommentApi
    {
        /// <summary>
        /// Ürün Yorumları Listesi Alma Ürün Yorumları listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;</param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir</param>
        /// <param name="status">Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif</param>
        /// <param name="isAnonymous">IsAnonymous şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Anonim değil&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Anonim</param>
        /// <param name="member">Üye id</param>
        /// <param name="product">Ürün id</param>
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param>
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param>
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param>
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param>
        /// <returns>ProductComment</returns>
        ProductComment ProductCommentsGet (string sort, int? limit, int? page, int? sinceId, string status, string isAnonymous, int? member, int? product, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt);
        /// <summary>
        /// Ürün Yorumu Silme Kalıcı olarak ilgili Ürün Yorumunu siler.
        /// </summary>
        /// <param name="id">Ürün Yorumu nesnesinin id değeri</param>
        /// <returns></returns>
        void ProductCommentsIdDelete (int? id);
        /// <summary>
        /// Ürün Yorumu Alma İlgili Ürün Yorumunu getirir.
        /// </summary>
        /// <param name="id">Ürün Yorumu nesnesinin id değeri</param>
        /// <returns>ProductComment</returns>
        ProductComment ProductCommentsIdGet (int? id);
        /// <summary>
        /// Ürün Yorumu Güncelleme İlgili Ürün Yorumunu günceller.
        /// </summary>
        /// <param name="id">Ürün Yorumu nesnesinin id değeri</param>
        /// <param name="productComment"> nesnesi</param>
        /// <returns>ProductComment</returns>
        ProductComment ProductCommentsIdPut (int? id, ProductComment productComment);
        /// <summary>
        /// Ürün Yorumu Oluşturma Yeni bir Ürün Yorumu oluşturur.
        /// </summary>
        /// <param name="productComment"> nesnesi</param>
        /// <returns>ProductComment</returns>
        ProductComment ProductCommentsPost (ProductComment productComment);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class ProductCommentApi : IProductCommentApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductCommentApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public ProductCommentApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductCommentApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ProductCommentApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ürün Yorumları Listesi Alma Ürün Yorumları listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;</param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir</param> 
        /// <param name="status">Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif</param> 
        /// <param name="isAnonymous">IsAnonymous şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Anonim değil&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Anonim</param> 
        /// <param name="member">Üye id</param> 
        /// <param name="product">Ürün id</param> 
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param> 
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param> 
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param> 
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param> 
        /// <returns>ProductComment</returns>            
        public ProductComment ProductCommentsGet (string sort, int? limit, int? page, int? sinceId, string status, string isAnonymous, int? member, int? product, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)
        {
            
    
            var path = "/product_comments";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (status != null) queryParams.Add("status", ApiClient.ParameterToString(status)); // query parameter
 if (isAnonymous != null) queryParams.Add("isAnonymous", ApiClient.ParameterToString(isAnonymous)); // query parameter
 if (member != null) queryParams.Add("member", ApiClient.ParameterToString(member)); // query parameter
 if (product != null) queryParams.Add("product", ApiClient.ParameterToString(product)); // query parameter
 if (startDate != null) queryParams.Add("startDate", ApiClient.ParameterToString(startDate)); // query parameter
 if (endDate != null) queryParams.Add("endDate", ApiClient.ParameterToString(endDate)); // query parameter
 if (startUpdatedAt != null) queryParams.Add("startUpdatedAt", ApiClient.ParameterToString(startUpdatedAt)); // query parameter
 if (endUpdatedAt != null) queryParams.Add("endUpdatedAt", ApiClient.ParameterToString(endUpdatedAt)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductCommentsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductCommentsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductComment) ApiClient.Deserialize(response.Content, typeof(ProductComment), response.Headers);
        }
    
        /// <summary>
        /// Ürün Yorumu Silme Kalıcı olarak ilgili Ürün Yorumunu siler.
        /// </summary>
        /// <param name="id">Ürün Yorumu nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void ProductCommentsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductCommentsIdDelete");
            
    
            var path = "/product_comments/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductCommentsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductCommentsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Ürün Yorumu Alma İlgili Ürün Yorumunu getirir.
        /// </summary>
        /// <param name="id">Ürün Yorumu nesnesinin id değeri</param> 
        /// <returns>ProductComment</returns>            
        public ProductComment ProductCommentsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductCommentsIdGet");
            
    
            var path = "/product_comments/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductCommentsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductCommentsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductComment) ApiClient.Deserialize(response.Content, typeof(ProductComment), response.Headers);
        }
    
        /// <summary>
        /// Ürün Yorumu Güncelleme İlgili Ürün Yorumunu günceller.
        /// </summary>
        /// <param name="id">Ürün Yorumu nesnesinin id değeri</param> 
        /// <param name="productComment"> nesnesi</param> 
        /// <returns>ProductComment</returns>            
        public ProductComment ProductCommentsIdPut (int? id, ProductComment productComment)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductCommentsIdPut");
            
            // verify the required parameter 'productComment' is set
            if (productComment == null) throw new ApiException(400, "Missing required parameter 'productComment' when calling ProductCommentsIdPut");
            
    
            var path = "/product_comments/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(productComment); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductCommentsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductCommentsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductComment) ApiClient.Deserialize(response.Content, typeof(ProductComment), response.Headers);
        }
    
        /// <summary>
        /// Ürün Yorumu Oluşturma Yeni bir Ürün Yorumu oluşturur.
        /// </summary>
        /// <param name="productComment"> nesnesi</param> 
        /// <returns>ProductComment</returns>            
        public ProductComment ProductCommentsPost (ProductComment productComment)
        {
            
            // verify the required parameter 'productComment' is set
            if (productComment == null) throw new ApiException(400, "Missing required parameter 'productComment' when calling ProductCommentsPost");
            
    
            var path = "/product_comments";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(productComment); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductCommentsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductCommentsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ProductComment) ApiClient.Deserialize(response.Content, typeof(ProductComment), response.Headers);
        }
    
    }
}
