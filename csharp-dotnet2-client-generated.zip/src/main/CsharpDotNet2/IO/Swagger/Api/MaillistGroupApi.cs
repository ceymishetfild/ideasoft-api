using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IMaillistGroupApi
    {
        /// <summary>
        /// Mail Listesi Grubu Listesi Alma Mail Listesi Grubu listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="name">Mail Listesi Grubu adı</param>
        /// <returns>MaillistGroup</returns>
        MaillistGroup MaillistGroupsGet (string sort, int? limit, int? page, int? sinceId, string name);
        /// <summary>
        /// Mail Listesi Grubu Silme Kalıcı olarak ilgili Mail Listesi Grubunu siler.
        /// </summary>
        /// <param name="id">Mail Listesi Grubu nesnesinin id değeri</param>
        /// <returns></returns>
        void MaillistGroupsIdDelete (int? id);
        /// <summary>
        /// Mail Listesi Grubu Alma İlgili Mail Listesi Grubunu getirir.
        /// </summary>
        /// <param name="id">Mail Listesi Grubu nesnesinin id değeri</param>
        /// <returns>MaillistGroup</returns>
        MaillistGroup MaillistGroupsIdGet (int? id);
        /// <summary>
        /// Mail Listesi Grubu Güncelleme İlgili Mail Listesi Grubunu günceller.
        /// </summary>
        /// <param name="id">Mail Listesi Grubu nesnesinin id değeri</param>
        /// <param name="maillistGroup">MaillistGroup nesnesi</param>
        /// <returns>MaillistGroup</returns>
        MaillistGroup MaillistGroupsIdPut (int? id, MaillistGroup maillistGroup);
        /// <summary>
        /// Mail Listesi Grubu Oluşturma Yeni bir Mail Listesi Grubu oluşturur.
        /// </summary>
        /// <param name="maillistGroup">MaillistGroup nesnesi</param>
        /// <returns>MaillistGroup</returns>
        MaillistGroup MaillistGroupsPost (MaillistGroup maillistGroup);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class MaillistGroupApi : IMaillistGroupApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MaillistGroupApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public MaillistGroupApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="MaillistGroupApi"/> class.
        /// </summary>
        /// <returns></returns>
        public MaillistGroupApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Mail Listesi Grubu Listesi Alma Mail Listesi Grubu listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="name">Mail Listesi Grubu adı</param> 
        /// <returns>MaillistGroup</returns>            
        public MaillistGroup MaillistGroupsGet (string sort, int? limit, int? page, int? sinceId, string name)
        {
            
    
            var path = "/maillist_groups";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (name != null) queryParams.Add("name", ApiClient.ParameterToString(name)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistGroupsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistGroupsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (MaillistGroup) ApiClient.Deserialize(response.Content, typeof(MaillistGroup), response.Headers);
        }
    
        /// <summary>
        /// Mail Listesi Grubu Silme Kalıcı olarak ilgili Mail Listesi Grubunu siler.
        /// </summary>
        /// <param name="id">Mail Listesi Grubu nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void MaillistGroupsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling MaillistGroupsIdDelete");
            
    
            var path = "/maillist_groups/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistGroupsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistGroupsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Mail Listesi Grubu Alma İlgili Mail Listesi Grubunu getirir.
        /// </summary>
        /// <param name="id">Mail Listesi Grubu nesnesinin id değeri</param> 
        /// <returns>MaillistGroup</returns>            
        public MaillistGroup MaillistGroupsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling MaillistGroupsIdGet");
            
    
            var path = "/maillist_groups/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistGroupsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistGroupsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (MaillistGroup) ApiClient.Deserialize(response.Content, typeof(MaillistGroup), response.Headers);
        }
    
        /// <summary>
        /// Mail Listesi Grubu Güncelleme İlgili Mail Listesi Grubunu günceller.
        /// </summary>
        /// <param name="id">Mail Listesi Grubu nesnesinin id değeri</param> 
        /// <param name="maillistGroup">MaillistGroup nesnesi</param> 
        /// <returns>MaillistGroup</returns>            
        public MaillistGroup MaillistGroupsIdPut (int? id, MaillistGroup maillistGroup)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling MaillistGroupsIdPut");
            
            // verify the required parameter 'maillistGroup' is set
            if (maillistGroup == null) throw new ApiException(400, "Missing required parameter 'maillistGroup' when calling MaillistGroupsIdPut");
            
    
            var path = "/maillist_groups/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(maillistGroup); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistGroupsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistGroupsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (MaillistGroup) ApiClient.Deserialize(response.Content, typeof(MaillistGroup), response.Headers);
        }
    
        /// <summary>
        /// Mail Listesi Grubu Oluşturma Yeni bir Mail Listesi Grubu oluşturur.
        /// </summary>
        /// <param name="maillistGroup">MaillistGroup nesnesi</param> 
        /// <returns>MaillistGroup</returns>            
        public MaillistGroup MaillistGroupsPost (MaillistGroup maillistGroup)
        {
            
            // verify the required parameter 'maillistGroup' is set
            if (maillistGroup == null) throw new ApiException(400, "Missing required parameter 'maillistGroup' when calling MaillistGroupsPost");
            
    
            var path = "/maillist_groups";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(maillistGroup); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistGroupsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling MaillistGroupsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (MaillistGroup) ApiClient.Deserialize(response.Content, typeof(MaillistGroup), response.Headers);
        }
    
    }
}
