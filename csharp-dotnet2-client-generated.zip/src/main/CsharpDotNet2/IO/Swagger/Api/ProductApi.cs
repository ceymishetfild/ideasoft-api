using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IProductApi
    {
        /// <summary>
        /// Ürün Listesi Alma Ürün listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param>
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param>
        /// <param name="page">Hangi sayfadan başlanacağı</param>
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param>
        /// <param name="parent">Ürün id</param>
        /// <param name="brand">Marka id</param>
        /// <param name="sku">Ürün stok kodu.</param>
        /// <param name="name">Ürün adı.</param>
        /// <param name="distributor">Ürün distribütör.</param>
        /// <param name="q">Ürün arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;]</param>
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param>
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param>
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param>
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param>
        /// <returns>Product</returns>
        Product ProductsGet (string sort, int? limit, int? page, int? sinceId, string parent, int? brand, string sku, string name, string distributor, List<string> q, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt);
        /// <summary>
        /// Ürün Silme Kalıcı olarak ilgili Ürünü siler.
        /// </summary>
        /// <param name="id">Ürün nesnesinin id değeri</param>
        /// <returns></returns>
        void ProductsIdDelete (int? id);
        /// <summary>
        /// Ürün Alma İlgili Ürünü getirir.
        /// </summary>
        /// <param name="id">Ürün nesnesinin id değeri</param>
        /// <returns>Product</returns>
        Product ProductsIdGet (int? id);
        /// <summary>
        /// Ürün Güncelleme İlgili Ürünü günceller.
        /// </summary>
        /// <param name="id">Ürün nesnesinin id değeri</param>
        /// <param name="product">Product nesnesi</param>
        /// <returns>Product</returns>
        Product ProductsIdPut (int? id, Product product);
        /// <summary>
        /// Ürün Oluşturma Yeni bir Ürün oluşturur.
        /// </summary>
        /// <param name="product">Product nesnesi</param>
        /// <returns>Product</returns>
        Product ProductsPost (Product product);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class ProductApi : IProductApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public ProductApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ProductApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Ürün Listesi Alma Ürün listesini verir.
        /// </summary>
        /// <param name="sort">Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; </param> 
        /// <param name="limit">Bir sayfada gelecek sonuç adedi</param> 
        /// <param name="page">Hangi sayfadan başlanacağı</param> 
        /// <param name="sinceId">Yalnızca belirtilen id değerinden sonraki kayıtları getirir </param> 
        /// <param name="parent">Ürün id</param> 
        /// <param name="brand">Marka id</param> 
        /// <param name="sku">Ürün stok kodu.</param> 
        /// <param name="name">Ürün adı.</param> 
        /// <param name="distributor">Ürün distribütör.</param> 
        /// <param name="q">Ürün arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;]</param> 
        /// <param name="startDate">createdAt değeri için başlangıç tarihi</param> 
        /// <param name="endDate">createdAt değeri için bitiş tarihi</param> 
        /// <param name="startUpdatedAt">updatedAt değeri için başlangıç tarihi</param> 
        /// <param name="endUpdatedAt">updatedAt değeri için bitiş tarihi</param> 
        /// <returns>Product</returns>            
        public Product ProductsGet (string sort, int? limit, int? page, int? sinceId, string parent, int? brand, string sku, string name, string distributor, List<string> q, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)
        {
            
    
            var path = "/products";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (sort != null) queryParams.Add("sort", ApiClient.ParameterToString(sort)); // query parameter
 if (limit != null) queryParams.Add("limit", ApiClient.ParameterToString(limit)); // query parameter
 if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
 if (sinceId != null) queryParams.Add("sinceId", ApiClient.ParameterToString(sinceId)); // query parameter
 if (parent != null) queryParams.Add("parent", ApiClient.ParameterToString(parent)); // query parameter
 if (brand != null) queryParams.Add("brand", ApiClient.ParameterToString(brand)); // query parameter
 if (sku != null) queryParams.Add("sku", ApiClient.ParameterToString(sku)); // query parameter
 if (name != null) queryParams.Add("name", ApiClient.ParameterToString(name)); // query parameter
 if (distributor != null) queryParams.Add("distributor", ApiClient.ParameterToString(distributor)); // query parameter
 if (q != null) queryParams.Add("q", ApiClient.ParameterToString(q)); // query parameter
 if (startDate != null) queryParams.Add("startDate", ApiClient.ParameterToString(startDate)); // query parameter
 if (endDate != null) queryParams.Add("endDate", ApiClient.ParameterToString(endDate)); // query parameter
 if (startUpdatedAt != null) queryParams.Add("startUpdatedAt", ApiClient.ParameterToString(startUpdatedAt)); // query parameter
 if (endUpdatedAt != null) queryParams.Add("endUpdatedAt", ApiClient.ParameterToString(endUpdatedAt)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductsGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductsGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Product) ApiClient.Deserialize(response.Content, typeof(Product), response.Headers);
        }
    
        /// <summary>
        /// Ürün Silme Kalıcı olarak ilgili Ürünü siler.
        /// </summary>
        /// <param name="id">Ürün nesnesinin id değeri</param> 
        /// <returns></returns>            
        public void ProductsIdDelete (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductsIdDelete");
            
    
            var path = "/products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductsIdDelete: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductsIdDelete: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Ürün Alma İlgili Ürünü getirir.
        /// </summary>
        /// <param name="id">Ürün nesnesinin id değeri</param> 
        /// <returns>Product</returns>            
        public Product ProductsIdGet (int? id)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductsIdGet");
            
    
            var path = "/products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductsIdGet: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductsIdGet: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Product) ApiClient.Deserialize(response.Content, typeof(Product), response.Headers);
        }
    
        /// <summary>
        /// Ürün Güncelleme İlgili Ürünü günceller.
        /// </summary>
        /// <param name="id">Ürün nesnesinin id değeri</param> 
        /// <param name="product">Product nesnesi</param> 
        /// <returns>Product</returns>            
        public Product ProductsIdPut (int? id, Product product)
        {
            
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling ProductsIdPut");
            
            // verify the required parameter 'product' is set
            if (product == null) throw new ApiException(400, "Missing required parameter 'product' when calling ProductsIdPut");
            
    
            var path = "/products/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(product); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductsIdPut: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductsIdPut: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Product) ApiClient.Deserialize(response.Content, typeof(Product), response.Headers);
        }
    
        /// <summary>
        /// Ürün Oluşturma Yeni bir Ürün oluşturur.
        /// </summary>
        /// <param name="product">Product nesnesi</param> 
        /// <returns>Product</returns>            
        public Product ProductsPost (Product product)
        {
            
            // verify the required parameter 'product' is set
            if (product == null) throw new ApiException(400, "Missing required parameter 'product' when calling ProductsPost");
            
    
            var path = "/products";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(product); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] { "OAuth2" };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductsPost: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling ProductsPost: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Product) ApiClient.Deserialize(response.Content, typeof(Product), response.Headers);
        }
    
    }
}
