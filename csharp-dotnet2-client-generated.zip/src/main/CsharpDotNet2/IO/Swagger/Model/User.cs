using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class User {
    /// <summary>
    /// Yönetici nesnesi kimlik değeri.
    /// </summary>
    /// <value>Yönetici nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Yöneticinin ismi.
    /// </summary>
    /// <value>Yöneticinin ismi.</value>
    [DataMember(Name="firstname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "firstname")]
    public string Firstname { get; set; }

    /// <summary>
    /// Yöneticinin soy ismi.
    /// </summary>
    /// <value>Yöneticinin soy ismi.</value>
    [DataMember(Name="surname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "surname")]
    public string Surname { get; set; }

    /// <summary>
    /// Yöneticinin e-mail adresi.
    /// </summary>
    /// <value>Yöneticinin e-mail adresi.</value>
    [DataMember(Name="email", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "email")]
    public string Email { get; set; }

    /// <summary>
    /// Yöneticinin kullanıcı adı.
    /// </summary>
    /// <value>Yöneticinin kullanıcı adı.</value>
    [DataMember(Name="username", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "username")]
    public string Username { get; set; }

    /// <summary>
    /// Yöneticinin telefon numarası.
    /// </summary>
    /// <value>Yöneticinin telefon numarası.</value>
    [DataMember(Name="phoneNumber", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "phoneNumber")]
    public string PhoneNumber { get; set; }

    /// <summary>
    /// Yöneticinin aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br><code>2</code> : Askıya alınmış.<br></div>
    /// </summary>
    /// <value>Yöneticinin aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br><code>2</code> : Askıya alınmış.<br></div></value>
    [DataMember(Name="status", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "status")]
    public int? Status { get; set; }

    /// <summary>
    /// Yöneticinin site sahibi olma durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Site sahibi.<br><code>0</code> : Site sahibi değil.<br></div>
    /// </summary>
    /// <value>Yöneticinin site sahibi olma durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Site sahibi.<br><code>0</code> : Site sahibi değil.<br></div></value>
    [DataMember(Name="isOwner", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "isOwner")]
    public string IsOwner { get; set; }

    /// <summary>
    /// İlgili üye grubu.
    /// </summary>
    /// <value>İlgili üye grubu.</value>
    [DataMember(Name="membergroups", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "membergroups")]
    public List<MemberGroup> Membergroups { get; set; }

    /// <summary>
    /// Yöneticinin SMS verifikasyonu yapılma bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : SMS verifikasyon yapılmış.<br><code>0</code> : SMS verifikasyon yapılmamış.<br></div>
    /// </summary>
    /// <value>Yöneticinin SMS verifikasyonu yapılma bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : SMS verifikasyon yapılmış.<br><code>0</code> : SMS verifikasyon yapılmamış.<br></div></value>
    [DataMember(Name="smsApproved", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "smsApproved")]
    public string SmsApproved { get; set; }

    /// <summary>
    /// Gets or Sets Userlevel
    /// </summary>
    [DataMember(Name="userlevel", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "userlevel")]
    public ShopUserlevels Userlevel { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class User {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Firstname: ").Append(Firstname).Append("\n");
      sb.Append("  Surname: ").Append(Surname).Append("\n");
      sb.Append("  Email: ").Append(Email).Append("\n");
      sb.Append("  Username: ").Append(Username).Append("\n");
      sb.Append("  PhoneNumber: ").Append(PhoneNumber).Append("\n");
      sb.Append("  Status: ").Append(Status).Append("\n");
      sb.Append("  IsOwner: ").Append(IsOwner).Append("\n");
      sb.Append("  Membergroups: ").Append(Membergroups).Append("\n");
      sb.Append("  SmsApproved: ").Append(SmsApproved).Append("\n");
      sb.Append("  Userlevel: ").Append(Userlevel).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
