using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class Tag {
    /// <summary>
    /// SEO+ etiketi nesnesi kimlik değeri.
    /// </summary>
    /// <value>SEO+ etiketi nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// SEO+ etiketi nesnesi için isim değeri.
    /// </summary>
    /// <value>SEO+ etiketi nesnesi için isim değeri.</value>
    [DataMember(Name="name", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "name")]
    public string Name { get; set; }

    /// <summary>
    /// SEO+ etiketinin kaç kez kullanıldığı bilgisi.
    /// </summary>
    /// <value>SEO+ etiketinin kaç kez kullanıldığı bilgisi.</value>
    [DataMember(Name="count", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "count")]
    public int? Count { get; set; }

    /// <summary>
    /// SEO+ etiketi nesnesinin etiket başlığı.
    /// </summary>
    /// <value>SEO+ etiketi nesnesinin etiket başlığı.</value>
    [DataMember(Name="pageTitle", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "pageTitle")]
    public string PageTitle { get; set; }

    /// <summary>
    /// Arama motorları tarafından tespit edilebilecek açıklama yazısı.
    /// </summary>
    /// <value>Arama motorları tarafından tespit edilebilecek açıklama yazısı.</value>
    [DataMember(Name="metaDescription", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "metaDescription")]
    public string MetaDescription { get; set; }

    /// <summary>
    /// Arama motorları tarafından tespit edilebilecek anahtar kelimeler.
    /// </summary>
    /// <value>Arama motorları tarafından tespit edilebilecek anahtar kelimeler.</value>
    [DataMember(Name="metaKeywords", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "metaKeywords")]
    public string MetaKeywords { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Tag {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Name: ").Append(Name).Append("\n");
      sb.Append("  Count: ").Append(Count).Append("\n");
      sb.Append("  PageTitle: ").Append(PageTitle).Append("\n");
      sb.Append("  MetaDescription: ").Append(MetaDescription).Append("\n");
      sb.Append("  MetaKeywords: ").Append(MetaKeywords).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
