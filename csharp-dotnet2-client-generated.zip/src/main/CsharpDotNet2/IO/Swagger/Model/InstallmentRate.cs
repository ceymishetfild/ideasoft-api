using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InstallmentRate {
    /// <summary>
    /// Taksit oranı nesnesi kimlik değeri.
    /// </summary>
    /// <value>Taksit oranı nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Taksit adeti.
    /// </summary>
    /// <value>Taksit adeti.</value>
    [DataMember(Name="installment", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "installment")]
    public int? Installment { get; set; }

    /// <summary>
    /// Taksit adeti için oran bilgisi.
    /// </summary>
    /// <value>Taksit adeti için oran bilgisi.</value>
    [DataMember(Name="rate", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "rate")]
    public float? Rate { get; set; }

    /// <summary>
    /// Ödeme kanalı nesnesi.
    /// </summary>
    /// <value>Ödeme kanalı nesnesi.</value>
    [DataMember(Name="paymentGateway", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "paymentGateway")]
    public PaymentGateway PaymentGateway { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InstallmentRate {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Installment: ").Append(Installment).Append("\n");
      sb.Append("  Rate: ").Append(Rate).Append("\n");
      sb.Append("  PaymentGateway: ").Append(PaymentGateway).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
