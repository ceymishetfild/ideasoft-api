using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class PaymentGatewaySetting {
    /// <summary>
    /// Ödeme kanalı ayarı nesnesi kimlik değeri.
    /// </summary>
    /// <value>Ödeme kanalı ayarı nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Ödeme kanalı ayarı nesnesi için değişken anahtarı.
    /// </summary>
    /// <value>Ödeme kanalı ayarı nesnesi için değişken anahtarı.</value>
    [DataMember(Name="varKey", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "varKey")]
    public string VarKey { get; set; }

    /// <summary>
    /// Ödeme kanalı ayarı nesnesi için değişken değeri.
    /// </summary>
    /// <value>Ödeme kanalı ayarı nesnesi için değişken değeri.</value>
    [DataMember(Name="varValue", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "varValue")]
    public string VarValue { get; set; }

    /// <summary>
    /// Ödeme kanalı nesnesi.
    /// </summary>
    /// <value>Ödeme kanalı nesnesi.</value>
    [DataMember(Name="paymentGateway", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "paymentGateway")]
    public PaymentGateway PaymentGateway { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class PaymentGatewaySetting {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  VarKey: ").Append(VarKey).Append("\n");
      sb.Append("  VarValue: ").Append(VarValue).Append("\n");
      sb.Append("  PaymentGateway: ").Append(PaymentGateway).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
