using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class PaymentGateway {
    /// <summary>
    /// Ödeme kanalı nesnesi kimlik değeri.
    /// </summary>
    /// <value>Ödeme kanalı nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Ödeme kanalı için ön tanımlanmış kod değeri.
    /// </summary>
    /// <value>Ödeme kanalı için ön tanımlanmış kod değeri.</value>
    [DataMember(Name="code", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "code")]
    public string Code { get; set; }

    /// <summary>
    /// Ödeme kanalı nesnesi için isim değeri.
    /// </summary>
    /// <value>Ödeme kanalı nesnesi için isim değeri.</value>
    [DataMember(Name="name", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "name")]
    public string Name { get; set; }

    /// <summary>
    /// Ödeme kanalının aktiflik durumu.<div class='idea_choice_list'><code>active</code> : Aktif<br><code>passive</code> : Pasif<br></div>
    /// </summary>
    /// <value>Ödeme kanalının aktiflik durumu.<div class='idea_choice_list'><code>active</code> : Aktif<br><code>passive</code> : Pasif<br></div></value>
    [DataMember(Name="status", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "status")]
    public string Status { get; set; }

    /// <summary>
    /// Ödeme kanalı nesnesi için sıralama değeri.
    /// </summary>
    /// <value>Ödeme kanalı nesnesi için sıralama değeri.</value>
    [DataMember(Name="sortOrder", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "sortOrder")]
    public int? SortOrder { get; set; }

    /// <summary>
    /// Gets or Sets PaymentProvider
    /// </summary>
    [DataMember(Name="paymentProvider", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "paymentProvider")]
    public PaymentProvider PaymentProvider { get; set; }

    /// <summary>
    /// Ödeme kanalı ayarları.
    /// </summary>
    /// <value>Ödeme kanalı ayarları.</value>
    [DataMember(Name="settings", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "settings")]
    public List<PaymentGatewaySetting> Settings { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class PaymentGateway {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Code: ").Append(Code).Append("\n");
      sb.Append("  Name: ").Append(Name).Append("\n");
      sb.Append("  Status: ").Append(Status).Append("\n");
      sb.Append("  SortOrder: ").Append(SortOrder).Append("\n");
      sb.Append("  PaymentProvider: ").Append(PaymentProvider).Append("\n");
      sb.Append("  Settings: ").Append(Settings).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
