using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class OrderItem {
    /// <summary>
    /// Sipariş kalemi nesnesi kimlik değeri.
    /// </summary>
    /// <value>Sipariş kalemi nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Ürünün adı.
    /// </summary>
    /// <value>Ürünün adı.</value>
    [DataMember(Name="productName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productName")]
    public string ProductName { get; set; }

    /// <summary>
    /// Ürünün stok kodu.
    /// </summary>
    /// <value>Ürünün stok kodu.</value>
    [DataMember(Name="productSku", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productSku")]
    public string ProductSku { get; set; }

    /// <summary>
    /// Ürünün barkodu.
    /// </summary>
    /// <value>Ürünün barkodu.</value>
    [DataMember(Name="productBarcode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productBarcode")]
    public string ProductBarcode { get; set; }

    /// <summary>
    /// Ürünün fiyatı.
    /// </summary>
    /// <value>Ürünün fiyatı.</value>
    [DataMember(Name="productPrice", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productPrice")]
    public float? ProductPrice { get; set; }

    /// <summary>
    /// Ürünün kuru.
    /// </summary>
    /// <value>Ürünün kuru.</value>
    [DataMember(Name="productCurrency", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productCurrency")]
    public string ProductCurrency { get; set; }

    /// <summary>
    /// Ürünün stok tipi cinsinden miktarı.
    /// </summary>
    /// <value>Ürünün stok tipi cinsinden miktarı.</value>
    [DataMember(Name="productQuantity", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productQuantity")]
    public float? ProductQuantity { get; set; }

    /// <summary>
    /// Ürünün vergisi
    /// </summary>
    /// <value>Ürünün vergisi</value>
    [DataMember(Name="productTax", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productTax")]
    public int? ProductTax { get; set; }

    /// <summary>
    /// Ürünün standart indirim değeri.
    /// </summary>
    /// <value>Ürünün standart indirim değeri.</value>
    [DataMember(Name="productDiscount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productDiscount")]
    public float? ProductDiscount { get; set; }

    /// <summary>
    /// Ürünün havale indirim değeri.
    /// </summary>
    /// <value>Ürünün havale indirim değeri.</value>
    [DataMember(Name="productMoneyOrderDiscount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productMoneyOrderDiscount")]
    public float? ProductMoneyOrderDiscount { get; set; }

    /// <summary>
    /// Ürünün ağırlığı.
    /// </summary>
    /// <value>Ürünün ağırlığı.</value>
    [DataMember(Name="productWeight", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productWeight")]
    public float? ProductWeight { get; set; }

    /// <summary>
    /// Ürünün stok tipi.<div class='idea_choice_list'><code>Adet</code> : Stok tipi birimi Adet<br><code>cm</code> : Stok tipi birimi Santimetre<br><code>Düzine</code> : Stok tipi birimi Düzine<br><code>gram</code> : Stok tipi birimi Gram<br><code>kg</code> : Stok tipi birimi Kilogram<br><code>Kişi</code> : Stok tipi birimi Kişi<br><code>Paket</code> : Stok tipi birimi Paket<br><code>metre</code> : Stok tipi birimi Metre<br><code>m2</code> : Stok tipi birimi Metre kare<br><code>Çift</code> : Stok tipi birimi Çift<br></div>
    /// </summary>
    /// <value>Ürünün stok tipi.<div class='idea_choice_list'><code>Adet</code> : Stok tipi birimi Adet<br><code>cm</code> : Stok tipi birimi Santimetre<br><code>Düzine</code> : Stok tipi birimi Düzine<br><code>gram</code> : Stok tipi birimi Gram<br><code>kg</code> : Stok tipi birimi Kilogram<br><code>Kişi</code> : Stok tipi birimi Kişi<br><code>Paket</code> : Stok tipi birimi Paket<br><code>metre</code> : Stok tipi birimi Metre<br><code>m2</code> : Stok tipi birimi Metre kare<br><code>Çift</code> : Stok tipi birimi Çift<br></div></value>
    [DataMember(Name="productStockTypeLabel", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productStockTypeLabel")]
    public string ProductStockTypeLabel { get; set; }

    /// <summary>
    /// Ürünün promosyon olup olmadığını belirten değer.<div class='idea_choice_list'><code>0</code> : Ürün promosyon değil.<br><code>1</code> : Ürün promosyon.<br></div>
    /// </summary>
    /// <value>Ürünün promosyon olup olmadığını belirten değer.<div class='idea_choice_list'><code>0</code> : Ürün promosyon değil.<br><code>1</code> : Ürün promosyon.<br></div></value>
    [DataMember(Name="isProductPromotioned", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "isProductPromotioned")]
    public string IsProductPromotioned { get; set; }

    /// <summary>
    /// Ürünün hediye çeki indirim değeri.
    /// </summary>
    /// <value>Ürünün hediye çeki indirim değeri.</value>
    [DataMember(Name="discount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "discount")]
    public float? Discount { get; set; }

    /// <summary>
    /// Sipariş nesnesi.
    /// </summary>
    /// <value>Sipariş nesnesi.</value>
    [DataMember(Name="order", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "order")]
    public Order Order { get; set; }

    /// <summary>
    /// Ürün nesnesi.
    /// </summary>
    /// <value>Ürün nesnesi.</value>
    [DataMember(Name="product", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "product")]
    public Product Product { get; set; }

    /// <summary>
    /// Gets or Sets OrderItemSubscription
    /// </summary>
    [DataMember(Name="orderItemSubscription", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "orderItemSubscription")]
    public OrderItemSubscription OrderItemSubscription { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class OrderItem {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  ProductName: ").Append(ProductName).Append("\n");
      sb.Append("  ProductSku: ").Append(ProductSku).Append("\n");
      sb.Append("  ProductBarcode: ").Append(ProductBarcode).Append("\n");
      sb.Append("  ProductPrice: ").Append(ProductPrice).Append("\n");
      sb.Append("  ProductCurrency: ").Append(ProductCurrency).Append("\n");
      sb.Append("  ProductQuantity: ").Append(ProductQuantity).Append("\n");
      sb.Append("  ProductTax: ").Append(ProductTax).Append("\n");
      sb.Append("  ProductDiscount: ").Append(ProductDiscount).Append("\n");
      sb.Append("  ProductMoneyOrderDiscount: ").Append(ProductMoneyOrderDiscount).Append("\n");
      sb.Append("  ProductWeight: ").Append(ProductWeight).Append("\n");
      sb.Append("  ProductStockTypeLabel: ").Append(ProductStockTypeLabel).Append("\n");
      sb.Append("  IsProductPromotioned: ").Append(IsProductPromotioned).Append("\n");
      sb.Append("  Discount: ").Append(Discount).Append("\n");
      sb.Append("  Order: ").Append(Order).Append("\n");
      sb.Append("  Product: ").Append(Product).Append("\n");
      sb.Append("  OrderItemSubscription: ").Append(OrderItemSubscription).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
