using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class Maillist {
    /// <summary>
    /// Mail listesi nesnesi kimlik değeri.
    /// </summary>
    /// <value>Mail listesi nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Mail listesi nesnesi için isim değeri.
    /// </summary>
    /// <value>Mail listesi nesnesi için isim değeri.</value>
    [DataMember(Name="name", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "name")]
    public string Name { get; set; }

    /// <summary>
    /// Ziyaretçi veya üyenin mail adresi.
    /// </summary>
    /// <value>Ziyaretçi veya üyenin mail adresi.</value>
    [DataMember(Name="email", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "email")]
    public string Email { get; set; }

    /// <summary>
    /// En son e-mail gönderilen zaman.
    /// </summary>
    /// <value>En son e-mail gönderilen zaman.</value>
    [DataMember(Name="lastMailSentDate", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "lastMailSentDate")]
    public DateTime? LastMailSentDate { get; set; }

    /// <summary>
    /// Mail listesi nesnesini oluşturan kişinin IP adresi.
    /// </summary>
    /// <value>Mail listesi nesnesini oluşturan kişinin IP adresi.</value>
    [DataMember(Name="creatorIpAddress", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "creatorIpAddress")]
    public string CreatorIpAddress { get; set; }

    /// <summary>
    /// Mail listesi nesnesinin oluşturulma zamanı.
    /// </summary>
    /// <value>Mail listesi nesnesinin oluşturulma zamanı.</value>
    [DataMember(Name="createdAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "createdAt")]
    public DateTime? CreatedAt { get; set; }

    /// <summary>
    /// Mail listesi nesnesinin güncellenme zamanı.
    /// </summary>
    /// <value>Mail listesi nesnesinin güncellenme zamanı.</value>
    [DataMember(Name="updatedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "updatedAt")]
    public DateTime? UpdatedAt { get; set; }

    /// <summary>
    /// Mail listesi grubu nesnesi.
    /// </summary>
    /// <value>Mail listesi grubu nesnesi.</value>
    [DataMember(Name="maillistGroup", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "maillistGroup")]
    public MaillistGroup MaillistGroup { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Maillist {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Name: ").Append(Name).Append("\n");
      sb.Append("  Email: ").Append(Email).Append("\n");
      sb.Append("  LastMailSentDate: ").Append(LastMailSentDate).Append("\n");
      sb.Append("  CreatorIpAddress: ").Append(CreatorIpAddress).Append("\n");
      sb.Append("  CreatedAt: ").Append(CreatedAt).Append("\n");
      sb.Append("  UpdatedAt: ").Append(UpdatedAt).Append("\n");
      sb.Append("  MaillistGroup: ").Append(MaillistGroup).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
