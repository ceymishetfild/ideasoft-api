using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class OrderAddress {
    /// <summary>
    /// Sipariş adresi nesnesi kimlik değeri.
    /// </summary>
    /// <value>Sipariş adresi nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Müşterinin ismi.
    /// </summary>
    /// <value>Müşterinin ismi.</value>
    [DataMember(Name="firstname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "firstname")]
    public string Firstname { get; set; }

    /// <summary>
    /// Müşterinin soy ismi.
    /// </summary>
    /// <value>Müşterinin soy ismi.</value>
    [DataMember(Name="surname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "surname")]
    public string Surname { get; set; }

    /// <summary>
    /// Müşterinin ülke bilgisi.
    /// </summary>
    /// <value>Müşterinin ülke bilgisi.</value>
    [DataMember(Name="country", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "country")]
    public string Country { get; set; }

    /// <summary>
    /// Müşterinin şehir bilgisi.
    /// </summary>
    /// <value>Müşterinin şehir bilgisi.</value>
    [DataMember(Name="location", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "location")]
    public string Location { get; set; }

    /// <summary>
    /// Müşterinin ilçe bilgisi.
    /// </summary>
    /// <value>Müşterinin ilçe bilgisi.</value>
    [DataMember(Name="subLocation", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "subLocation")]
    public string SubLocation { get; set; }

    /// <summary>
    /// Müşterinin adres bilgisi.
    /// </summary>
    /// <value>Müşterinin adres bilgisi.</value>
    [DataMember(Name="address", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "address")]
    public string Address { get; set; }

    /// <summary>
    /// Müşterinin telefon numarası.
    /// </summary>
    /// <value>Müşterinin telefon numarası.</value>
    [DataMember(Name="phoneNumber", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "phoneNumber")]
    public string PhoneNumber { get; set; }

    /// <summary>
    /// Müşterinin mobil telefon numarası.
    /// </summary>
    /// <value>Müşterinin mobil telefon numarası.</value>
    [DataMember(Name="mobilePhoneNumber", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "mobilePhoneNumber")]
    public string MobilePhoneNumber { get; set; }

    /// <summary>
    /// Sipariş nesnesi.
    /// </summary>
    /// <value>Sipariş nesnesi.</value>
    [DataMember(Name="order", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "order")]
    public Order Order { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class OrderAddress {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Firstname: ").Append(Firstname).Append("\n");
      sb.Append("  Surname: ").Append(Surname).Append("\n");
      sb.Append("  Country: ").Append(Country).Append("\n");
      sb.Append("  Location: ").Append(Location).Append("\n");
      sb.Append("  SubLocation: ").Append(SubLocation).Append("\n");
      sb.Append("  Address: ").Append(Address).Append("\n");
      sb.Append("  PhoneNumber: ").Append(PhoneNumber).Append("\n");
      sb.Append("  MobilePhoneNumber: ").Append(MobilePhoneNumber).Append("\n");
      sb.Append("  Order: ").Append(Order).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
