using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class OrderItemCustomization {
    /// <summary>
    /// Sipariş kalemi özelleştirme kimlik değeri.
    /// </summary>
    /// <value>Sipariş kalemi özelleştirme kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Ürün özelleştirme grubu nesnesi kimlik değeri.
    /// </summary>
    /// <value>Ürün özelleştirme grubu nesnesi kimlik değeri.</value>
    [DataMember(Name="productCustomizationGroupId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productCustomizationGroupId")]
    public int? ProductCustomizationGroupId { get; set; }

    /// <summary>
    /// Ürün özelleştirme grubu nesnesinin grup adı.
    /// </summary>
    /// <value>Ürün özelleştirme grubu nesnesinin grup adı.</value>
    [DataMember(Name="productCustomizationGroupName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productCustomizationGroupName")]
    public string ProductCustomizationGroupName { get; set; }

    /// <summary>
    /// Ürün özelleştirme grubu nesnesinin sıralaması.
    /// </summary>
    /// <value>Ürün özelleştirme grubu nesnesinin sıralaması.</value>
    [DataMember(Name="productCustomizationGroupSortOrder", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productCustomizationGroupSortOrder")]
    public int? ProductCustomizationGroupSortOrder { get; set; }

    /// <summary>
    /// Ürün özelleştirme nesnesi kimlik değeri..
    /// </summary>
    /// <value>Ürün özelleştirme nesnesi kimlik değeri..</value>
    [DataMember(Name="productCustomizationFieldId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productCustomizationFieldId")]
    public int? ProductCustomizationFieldId { get; set; }

    /// <summary>
    /// Ürün özelleştirme nesnesinin alan tipi.
    /// </summary>
    /// <value>Ürün özelleştirme nesnesinin alan tipi.</value>
    [DataMember(Name="productCustomizationFieldType", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productCustomizationFieldType")]
    public string ProductCustomizationFieldType { get; set; }

    /// <summary>
    /// Ürün özelleştirme nesnesinin alan adı.
    /// </summary>
    /// <value>Ürün özelleştirme nesnesinin alan adı.</value>
    [DataMember(Name="productCustomizationFieldName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productCustomizationFieldName")]
    public string ProductCustomizationFieldName { get; set; }

    /// <summary>
    /// Ürün özelleştirme nesnesinin değeri.
    /// </summary>
    /// <value>Ürün özelleştirme nesnesinin değeri.</value>
    [DataMember(Name="productCustomizationFieldValue", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productCustomizationFieldValue")]
    public string ProductCustomizationFieldValue { get; set; }

    /// <summary>
    /// Sepet kalemi özelliği nesnesi kimlik değeri.
    /// </summary>
    /// <value>Sepet kalemi özelliği nesnesi kimlik değeri.</value>
    [DataMember(Name="cartItemAttributeId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "cartItemAttributeId")]
    public int? CartItemAttributeId { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class OrderItemCustomization {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  ProductCustomizationGroupId: ").Append(ProductCustomizationGroupId).Append("\n");
      sb.Append("  ProductCustomizationGroupName: ").Append(ProductCustomizationGroupName).Append("\n");
      sb.Append("  ProductCustomizationGroupSortOrder: ").Append(ProductCustomizationGroupSortOrder).Append("\n");
      sb.Append("  ProductCustomizationFieldId: ").Append(ProductCustomizationFieldId).Append("\n");
      sb.Append("  ProductCustomizationFieldType: ").Append(ProductCustomizationFieldType).Append("\n");
      sb.Append("  ProductCustomizationFieldName: ").Append(ProductCustomizationFieldName).Append("\n");
      sb.Append("  ProductCustomizationFieldValue: ").Append(ProductCustomizationFieldValue).Append("\n");
      sb.Append("  CartItemAttributeId: ").Append(CartItemAttributeId).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
