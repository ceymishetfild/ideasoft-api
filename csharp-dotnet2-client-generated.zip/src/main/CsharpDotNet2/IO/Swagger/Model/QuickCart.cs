using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class QuickCart {
    /// <summary>
    /// Hızlı satın al bağlantısı nesnesi kimlik değeri.
    /// </summary>
    /// <value>Hızlı satın al bağlantısı nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Hızlı satın al bağlantısı nesnesi için isim değeri.
    /// </summary>
    /// <value>Hızlı satın al bağlantısı nesnesi için isim değeri.</value>
    [DataMember(Name="name", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "name")]
    public string Name { get; set; }

    /// <summary>
    /// Hızlı satın al bağlantısı url'si.
    /// </summary>
    /// <value>Hızlı satın al bağlantısı url'si.</value>
    [DataMember(Name="url", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "url")]
    public string Url { get; set; }

    /// <summary>
    /// Hızlı satın al bağlantısı için kısaltılmış url.
    /// </summary>
    /// <value>Hızlı satın al bağlantısı için kısaltılmış url.</value>
    [DataMember(Name="shortUrl", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shortUrl")]
    public string ShortUrl { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class QuickCart {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Name: ").Append(Name).Append("\n");
      sb.Append("  Url: ").Append(Url).Append("\n");
      sb.Append("  ShortUrl: ").Append(ShortUrl).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
