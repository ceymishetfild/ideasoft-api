using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class PreOrderInfo {
    /// <summary>
    /// Sipariş öncesi bilgisi nesnesi kimlik değeri.
    /// </summary>
    /// <value>Sipariş öncesi bilgisi nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri.
    /// </summary>
    /// <value>Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri.</value>
    [DataMember(Name="sessionId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "sessionId")]
    public string SessionId { get; set; }

    /// <summary>
    /// Müşterinin ismi.
    /// </summary>
    /// <value>Müşterinin ismi.</value>
    [DataMember(Name="customerFirstname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "customerFirstname")]
    public string CustomerFirstname { get; set; }

    /// <summary>
    /// Müşterinin soy ismi.
    /// </summary>
    /// <value>Müşterinin soy ismi.</value>
    [DataMember(Name="customerSurname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "customerSurname")]
    public string CustomerSurname { get; set; }

    /// <summary>
    /// Müşterinin e-mail adresi.
    /// </summary>
    /// <value>Müşterinin e-mail adresi.</value>
    [DataMember(Name="customerEmail", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "customerEmail")]
    public string CustomerEmail { get; set; }

    /// <summary>
    /// Teslimat yapılacak kişinin ismi.
    /// </summary>
    /// <value>Teslimat yapılacak kişinin ismi.</value>
    [DataMember(Name="shippingFirstname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingFirstname")]
    public string ShippingFirstname { get; set; }

    /// <summary>
    /// Teslimat yapılacak kişinin soy ismi.
    /// </summary>
    /// <value>Teslimat yapılacak kişinin soy ismi.</value>
    [DataMember(Name="shippingSurname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingSurname")]
    public string ShippingSurname { get; set; }

    /// <summary>
    /// Teslimat adresi bilgileri.
    /// </summary>
    /// <value>Teslimat adresi bilgileri.</value>
    [DataMember(Name="shippingAddress", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingAddress")]
    public string ShippingAddress { get; set; }

    /// <summary>
    /// Teslimat yapılacak kişinin telefon numarası.
    /// </summary>
    /// <value>Teslimat yapılacak kişinin telefon numarası.</value>
    [DataMember(Name="shippingPhoneNumber", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingPhoneNumber")]
    public string ShippingPhoneNumber { get; set; }

    /// <summary>
    /// Teslimat yapılacak kişinin mobil telefon numarası.
    /// </summary>
    /// <value>Teslimat yapılacak kişinin mobil telefon numarası.</value>
    [DataMember(Name="shippingMobilePhoneNumber", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingMobilePhoneNumber")]
    public string ShippingMobilePhoneNumber { get; set; }

    /// <summary>
    /// Teslimat şehri.
    /// </summary>
    /// <value>Teslimat şehri.</value>
    [DataMember(Name="shippingLocationName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingLocationName")]
    public string ShippingLocationName { get; set; }

    /// <summary>
    /// Teslimat ilçesi.
    /// </summary>
    /// <value>Teslimat ilçesi.</value>
    [DataMember(Name="shippingTown", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingTown")]
    public string ShippingTown { get; set; }

    /// <summary>
    /// Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.<div class='idea_choice_list'><code>1</code> : Var<br><code>0</code> : Yok<br></div>
    /// </summary>
    /// <value>Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.<div class='idea_choice_list'><code>1</code> : Var<br><code>0</code> : Yok<br></div></value>
    [DataMember(Name="differentBillingAddress", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "differentBillingAddress")]
    public string DifferentBillingAddress { get; set; }

    /// <summary>
    /// Fatura kesilen kişinin ismi.
    /// </summary>
    /// <value>Fatura kesilen kişinin ismi.</value>
    [DataMember(Name="billingFirstname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "billingFirstname")]
    public string BillingFirstname { get; set; }

    /// <summary>
    /// Fatura kesilen kişinin soy ismi.
    /// </summary>
    /// <value>Fatura kesilen kişinin soy ismi.</value>
    [DataMember(Name="billingSurname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "billingSurname")]
    public string BillingSurname { get; set; }

    /// <summary>
    /// Fatura adresi bilgileri.
    /// </summary>
    /// <value>Fatura adresi bilgileri.</value>
    [DataMember(Name="billingAddress", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "billingAddress")]
    public string BillingAddress { get; set; }

    /// <summary>
    /// Fatura kesilen kişinin telefon numarası.
    /// </summary>
    /// <value>Fatura kesilen kişinin telefon numarası.</value>
    [DataMember(Name="billingPhoneNumber", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "billingPhoneNumber")]
    public string BillingPhoneNumber { get; set; }

    /// <summary>
    /// Fatura kesilen kişinin mobil telefon numarası.
    /// </summary>
    /// <value>Fatura kesilen kişinin mobil telefon numarası.</value>
    [DataMember(Name="billingMobilePhoneNumber", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "billingMobilePhoneNumber")]
    public string BillingMobilePhoneNumber { get; set; }

    /// <summary>
    /// Fatura adresi şehri
    /// </summary>
    /// <value>Fatura adresi şehri</value>
    [DataMember(Name="billingLocationName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "billingLocationName")]
    public string BillingLocationName { get; set; }

    /// <summary>
    /// Fatura adresi ilçesi.
    /// </summary>
    /// <value>Fatura adresi ilçesi.</value>
    [DataMember(Name="billingTown", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "billingTown")]
    public string BillingTown { get; set; }

    /// <summary>
    /// Fatura tipini belirtir.<div class='idea_choice_list'><code>individual</code> : Bireysel<br><code>corporate</code> : Kurumsal<br></div>
    /// </summary>
    /// <value>Fatura tipini belirtir.<div class='idea_choice_list'><code>individual</code> : Bireysel<br><code>corporate</code> : Kurumsal<br></div></value>
    [DataMember(Name="billingInvoiceType", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "billingInvoiceType")]
    public string BillingInvoiceType { get; set; }

    /// <summary>
    /// Fatura kesilen kişinin TC kimlik numarası.
    /// </summary>
    /// <value>Fatura kesilen kişinin TC kimlik numarası.</value>
    [DataMember(Name="billingIdentityRegistrationNumber", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "billingIdentityRegistrationNumber")]
    public string BillingIdentityRegistrationNumber { get; set; }

    /// <summary>
    /// Fatura kesilen kişi/kurumun vergi dairesi.
    /// </summary>
    /// <value>Fatura kesilen kişi/kurumun vergi dairesi.</value>
    [DataMember(Name="billingTaxOffice", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "billingTaxOffice")]
    public string BillingTaxOffice { get; set; }

    /// <summary>
    /// Fatura kesilen kişi/kurum vergi numarası.
    /// </summary>
    /// <value>Fatura kesilen kişi/kurum vergi numarası.</value>
    [DataMember(Name="billingTaxNo", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "billingTaxNo")]
    public string BillingTaxNo { get; set; }

    /// <summary>
    /// Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div>
    /// </summary>
    /// <value>Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div></value>
    [DataMember(Name="isEinvoiceUser", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "isEinvoiceUser")]
    public string IsEinvoiceUser { get; set; }

    /// <summary>
    /// Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div>
    /// </summary>
    /// <value>Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div></value>
    [DataMember(Name="useGiftPackage", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "useGiftPackage")]
    public string UseGiftPackage { get; set; }

    /// <summary>
    /// Hediye notu bilgisi.
    /// </summary>
    /// <value>Hediye notu bilgisi.</value>
    [DataMember(Name="giftNote", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "giftNote")]
    public string GiftNote { get; set; }

    /// <summary>
    /// Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif
    /// </summary>
    /// <value>Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif</value>
    [DataMember(Name="imageFile", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "imageFile")]
    public string ImageFile { get; set; }

    /// <summary>
    /// Müşterinin teslimatın gerçekleşmisini istediği tarih.
    /// </summary>
    /// <value>Müşterinin teslimatın gerçekleşmisini istediği tarih.</value>
    [DataMember(Name="deliveryDate", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "deliveryDate")]
    public DateTime? DeliveryDate { get; set; }

    /// <summary>
    /// API bu değeri otomatik oluşturur.
    /// </summary>
    /// <value>API bu değeri otomatik oluşturur.</value>
    [DataMember(Name="deliveryTime", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "deliveryTime")]
    public string DeliveryTime { get; set; }

    /// <summary>
    /// Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı.
    /// </summary>
    /// <value>Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı.</value>
    [DataMember(Name="createdAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "createdAt")]
    public DateTime? CreatedAt { get; set; }

    /// <summary>
    /// Sipariş öncesi bilgisi nesnesinin güncellenme zamanı.
    /// </summary>
    /// <value>Sipariş öncesi bilgisi nesnesinin güncellenme zamanı.</value>
    [DataMember(Name="updatedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "updatedAt")]
    public DateTime? UpdatedAt { get; set; }

    /// <summary>
    /// Ülke nesnesi.
    /// </summary>
    /// <value>Ülke nesnesi.</value>
    [DataMember(Name="billingCountry", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "billingCountry")]
    public Country BillingCountry { get; set; }

    /// <summary>
    /// Şehir nesnesi.
    /// </summary>
    /// <value>Şehir nesnesi.</value>
    [DataMember(Name="billingLocation", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "billingLocation")]
    public Location BillingLocation { get; set; }

    /// <summary>
    /// Kargo firması nesnesi.
    /// </summary>
    /// <value>Kargo firması nesnesi.</value>
    [DataMember(Name="shippingCompany", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingCompany")]
    public ShippingCompany ShippingCompany { get; set; }

    /// <summary>
    /// Ülke nesnesi.
    /// </summary>
    /// <value>Ülke nesnesi.</value>
    [DataMember(Name="shippingCountry", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingCountry")]
    public Country ShippingCountry { get; set; }

    /// <summary>
    /// Şehir nesnesi.
    /// </summary>
    /// <value>Şehir nesnesi.</value>
    [DataMember(Name="shippingLocation", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingLocation")]
    public Location ShippingLocation { get; set; }

    /// <summary>
    /// Üye adresi nesnesi.
    /// </summary>
    /// <value>Üye adresi nesnesi.</value>
    [DataMember(Name="memberShippingAddress", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "memberShippingAddress")]
    public MemberAddress MemberShippingAddress { get; set; }

    /// <summary>
    /// Üye adresi nesnesi.
    /// </summary>
    /// <value>Üye adresi nesnesi.</value>
    [DataMember(Name="memberBillingAddress", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "memberBillingAddress")]
    public MemberAddress MemberBillingAddress { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class PreOrderInfo {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  SessionId: ").Append(SessionId).Append("\n");
      sb.Append("  CustomerFirstname: ").Append(CustomerFirstname).Append("\n");
      sb.Append("  CustomerSurname: ").Append(CustomerSurname).Append("\n");
      sb.Append("  CustomerEmail: ").Append(CustomerEmail).Append("\n");
      sb.Append("  ShippingFirstname: ").Append(ShippingFirstname).Append("\n");
      sb.Append("  ShippingSurname: ").Append(ShippingSurname).Append("\n");
      sb.Append("  ShippingAddress: ").Append(ShippingAddress).Append("\n");
      sb.Append("  ShippingPhoneNumber: ").Append(ShippingPhoneNumber).Append("\n");
      sb.Append("  ShippingMobilePhoneNumber: ").Append(ShippingMobilePhoneNumber).Append("\n");
      sb.Append("  ShippingLocationName: ").Append(ShippingLocationName).Append("\n");
      sb.Append("  ShippingTown: ").Append(ShippingTown).Append("\n");
      sb.Append("  DifferentBillingAddress: ").Append(DifferentBillingAddress).Append("\n");
      sb.Append("  BillingFirstname: ").Append(BillingFirstname).Append("\n");
      sb.Append("  BillingSurname: ").Append(BillingSurname).Append("\n");
      sb.Append("  BillingAddress: ").Append(BillingAddress).Append("\n");
      sb.Append("  BillingPhoneNumber: ").Append(BillingPhoneNumber).Append("\n");
      sb.Append("  BillingMobilePhoneNumber: ").Append(BillingMobilePhoneNumber).Append("\n");
      sb.Append("  BillingLocationName: ").Append(BillingLocationName).Append("\n");
      sb.Append("  BillingTown: ").Append(BillingTown).Append("\n");
      sb.Append("  BillingInvoiceType: ").Append(BillingInvoiceType).Append("\n");
      sb.Append("  BillingIdentityRegistrationNumber: ").Append(BillingIdentityRegistrationNumber).Append("\n");
      sb.Append("  BillingTaxOffice: ").Append(BillingTaxOffice).Append("\n");
      sb.Append("  BillingTaxNo: ").Append(BillingTaxNo).Append("\n");
      sb.Append("  IsEinvoiceUser: ").Append(IsEinvoiceUser).Append("\n");
      sb.Append("  UseGiftPackage: ").Append(UseGiftPackage).Append("\n");
      sb.Append("  GiftNote: ").Append(GiftNote).Append("\n");
      sb.Append("  ImageFile: ").Append(ImageFile).Append("\n");
      sb.Append("  DeliveryDate: ").Append(DeliveryDate).Append("\n");
      sb.Append("  DeliveryTime: ").Append(DeliveryTime).Append("\n");
      sb.Append("  CreatedAt: ").Append(CreatedAt).Append("\n");
      sb.Append("  UpdatedAt: ").Append(UpdatedAt).Append("\n");
      sb.Append("  BillingCountry: ").Append(BillingCountry).Append("\n");
      sb.Append("  BillingLocation: ").Append(BillingLocation).Append("\n");
      sb.Append("  ShippingCompany: ").Append(ShippingCompany).Append("\n");
      sb.Append("  ShippingCountry: ").Append(ShippingCountry).Append("\n");
      sb.Append("  ShippingLocation: ").Append(ShippingLocation).Append("\n");
      sb.Append("  MemberShippingAddress: ").Append(MemberShippingAddress).Append("\n");
      sb.Append("  MemberBillingAddress: ").Append(MemberBillingAddress).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
