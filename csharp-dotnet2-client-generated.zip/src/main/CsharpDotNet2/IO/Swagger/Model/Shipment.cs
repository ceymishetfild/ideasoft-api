using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class Shipment {
    /// <summary>
    /// Teslimat nesnesi kimlik değeri.
    /// </summary>
    /// <value>Teslimat nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Teslimat barkodu.
    /// </summary>
    /// <value>Teslimat barkodu.</value>
    [DataMember(Name="barcode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "barcode")]
    public string Barcode { get; set; }

    /// <summary>
    /// Teslimat fatura numarası.
    /// </summary>
    /// <value>Teslimat fatura numarası.</value>
    [DataMember(Name="waybillNo", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "waybillNo")]
    public string WaybillNo { get; set; }

    /// <summary>
    /// Teslimat irsaliye makbuzu numarası.
    /// </summary>
    /// <value>Teslimat irsaliye makbuzu numarası.</value>
    [DataMember(Name="invoiceKey", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "invoiceKey")]
    public string InvoiceKey { get; set; }

    /// <summary>
    /// Teslimatın kargo şubesi
    /// </summary>
    /// <value>Teslimatın kargo şubesi</value>
    [DataMember(Name="cargoOffice", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "cargoOffice")]
    public string CargoOffice { get; set; }

    /// <summary>
    /// Teslimat kodu. Kargo takip kodu.
    /// </summary>
    /// <value>Teslimat kodu. Kargo takip kodu.</value>
    [DataMember(Name="code", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "code")]
    public string Code { get; set; }

    /// <summary>
    /// Teslimat tipi
    /// </summary>
    /// <value>Teslimat tipi</value>
    [DataMember(Name="deliveryType", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "deliveryType")]
    public string DeliveryType { get; set; }

    /// <summary>
    /// Faturanın pakete dahillik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Dahil.<br><code>0</code> : Dahil değil.<br></div>
    /// </summary>
    /// <value>Faturanın pakete dahillik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Dahil.<br><code>0</code> : Dahil değil.<br></div></value>
    [DataMember(Name="invoiceIncluded", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "invoiceIncluded")]
    public string InvoiceIncluded { get; set; }

    /// <summary>
    /// Kapıda ödeme hizmeti bedeli.
    /// </summary>
    /// <value>Kapıda ödeme hizmeti bedeli.</value>
    [DataMember(Name="payAtDoorAmount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "payAtDoorAmount")]
    public float? PayAtDoorAmount { get; set; }

    /// <summary>
    /// Teslimat nesnesinin oluşturulma zamanı.
    /// </summary>
    /// <value>Teslimat nesnesinin oluşturulma zamanı.</value>
    [DataMember(Name="createdAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "createdAt")]
    public DateTime? CreatedAt { get; set; }

    /// <summary>
    /// Teslimat nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
    /// </summary>
    /// <value>Teslimat nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div></value>
    [DataMember(Name="status", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "status")]
    public int? Status { get; set; }

    /// <summary>
    /// Sipariş nesnesi.
    /// </summary>
    /// <value>Sipariş nesnesi.</value>
    [DataMember(Name="order", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "order")]
    public Order Order { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Shipment {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Barcode: ").Append(Barcode).Append("\n");
      sb.Append("  WaybillNo: ").Append(WaybillNo).Append("\n");
      sb.Append("  InvoiceKey: ").Append(InvoiceKey).Append("\n");
      sb.Append("  CargoOffice: ").Append(CargoOffice).Append("\n");
      sb.Append("  Code: ").Append(Code).Append("\n");
      sb.Append("  DeliveryType: ").Append(DeliveryType).Append("\n");
      sb.Append("  InvoiceIncluded: ").Append(InvoiceIncluded).Append("\n");
      sb.Append("  PayAtDoorAmount: ").Append(PayAtDoorAmount).Append("\n");
      sb.Append("  CreatedAt: ").Append(CreatedAt).Append("\n");
      sb.Append("  Status: ").Append(Status).Append("\n");
      sb.Append("  Order: ").Append(Order).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
