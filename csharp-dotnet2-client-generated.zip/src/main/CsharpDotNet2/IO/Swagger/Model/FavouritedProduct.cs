using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class FavouritedProduct {
    /// <summary>
    /// Favori ürün nesnesi kimlik değeri.
    /// </summary>
    /// <value>Favori ürün nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Üye nesnesi.
    /// </summary>
    /// <value>Üye nesnesi.</value>
    [DataMember(Name="member", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "member")]
    public Member Member { get; set; }

    /// <summary>
    /// Ürün nesnesi.
    /// </summary>
    /// <value>Ürün nesnesi.</value>
    [DataMember(Name="product", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "product")]
    public Product Product { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class FavouritedProduct {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Member: ").Append(Member).Append("\n");
      sb.Append("  Product: ").Append(Product).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
