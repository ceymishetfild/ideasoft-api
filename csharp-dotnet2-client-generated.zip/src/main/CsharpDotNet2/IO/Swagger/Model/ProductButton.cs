using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class ProductButton {
    /// <summary>
    /// Ürün ve stok butonu nesnesi kimlik değeri.
    /// </summary>
    /// <value>Ürün ve stok butonu nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Hızlı gönderi butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Hızlı kargo butonu aktif.<br><code>0</code> : Hızlı kargo butonu pasif.<br></div>
    /// </summary>
    /// <value>Hızlı gönderi butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Hızlı kargo butonu aktif.<br><code>0</code> : Hızlı kargo butonu pasif.<br></div></value>
    [DataMember(Name="fastShipping", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "fastShipping")]
    public string FastShipping { get; set; }

    /// <summary>
    /// Aynı gün kargo butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aynı gün kargo butonu aktif.<br><code>0</code> : Aynı gün kargo butonu pasif.<br></div>
    /// </summary>
    /// <value>Aynı gün kargo butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Aynı gün kargo butonu aktif.<br><code>0</code> : Aynı gün kargo butonu pasif.<br></div></value>
    [DataMember(Name="sameDayShipping", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "sameDayShipping")]
    public string SameDayShipping { get; set; }

    /// <summary>
    /// 3 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 3 günde teslimat butonu aktif.<br><code>0</code> : 3 günde teslimat butonu pasif.<br></div>
    /// </summary>
    /// <value>3 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 3 günde teslimat butonu aktif.<br><code>0</code> : 3 günde teslimat butonu pasif.<br></div></value>
    [DataMember(Name="threeDaysDelivery", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "threeDaysDelivery")]
    public string ThreeDaysDelivery { get; set; }

    /// <summary>
    /// 5 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 5 günde teslimat butonu aktif.<br><code>0</code> : 5 günde teslimat butonu pasif.<br></div>
    /// </summary>
    /// <value>5 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 5 günde teslimat butonu aktif.<br><code>0</code> : 5 günde teslimat butonu pasif.<br></div></value>
    [DataMember(Name="fiveDaysDelivery", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "fiveDaysDelivery")]
    public string FiveDaysDelivery { get; set; }

    /// <summary>
    /// 7 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 7 günde teslimat butonu aktif.<br><code>0</code> : 7 günde teslimat butonu pasif.<br></div>
    /// </summary>
    /// <value>7 günde teslimat butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : 7 günde teslimat butonu aktif.<br><code>0</code> : 7 günde teslimat butonu pasif.<br></div></value>
    [DataMember(Name="sevenDaysDelivery", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "sevenDaysDelivery")]
    public string SevenDaysDelivery { get; set; }

    /// <summary>
    /// Kargo bedava butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Kargo bedava butonu aktif.<br><code>0</code> : Kargo bedava butonu pasif.<br></div>
    /// </summary>
    /// <value>Kargo bedava butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Kargo bedava butonu aktif.<br><code>0</code> : Kargo bedava butonu pasif.<br></div></value>
    [DataMember(Name="freeShipping", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "freeShipping")]
    public string FreeShipping { get; set; }

    /// <summary>
    /// Stoktan teslim butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Stoktan teslim butonu aktif.<br><code>0</code> : Stoktan teslim butonu pasif.<br></div>
    /// </summary>
    /// <value>Stoktan teslim butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Stoktan teslim butonu aktif.<br><code>0</code> : Stoktan teslim butonu pasif.<br></div></value>
    [DataMember(Name="deliveryFromStock", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "deliveryFromStock")]
    public string DeliveryFromStock { get; set; }

    /// <summary>
    /// Ön siparişli stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Ön siparişli ürün butonu aktif.<br><code>0</code> : Ön siparişli ürün butonu pasif.<br></div>
    /// </summary>
    /// <value>Ön siparişli stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Ön siparişli ürün butonu aktif.<br><code>0</code> : Ön siparişli ürün butonu pasif.<br></div></value>
    [DataMember(Name="preOrderedProduct", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "preOrderedProduct")]
    public string PreOrderedProduct { get; set; }

    /// <summary>
    /// Sınırlı stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Sınırlı stok butonu aktif.<br><code>0</code> : Sınırlı stok butonu pasif.<br></div>
    /// </summary>
    /// <value>Sınırlı stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Sınırlı stok butonu aktif.<br><code>0</code> : Sınırlı stok butonu pasif.<br></div></value>
    [DataMember(Name="limitedStock", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "limitedStock")]
    public string LimitedStock { get; set; }

    /// <summary>
    /// Stok sorunuz butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Stok sorunuz butonu aktif.<br><code>0</code> : Stok sorunuz butonu pasif.<br></div>
    /// </summary>
    /// <value>Stok sorunuz butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Stok sorunuz butonu aktif.<br><code>0</code> : Stok sorunuz butonu pasif.<br></div></value>
    [DataMember(Name="askStock", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "askStock")]
    public string AskStock { get; set; }

    /// <summary>
    /// Kampanyalı stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Kampanyalı ürün butonu aktif.<br><code>0</code> : Kampanyalı ürün butonu pasif.<br></div>
    /// </summary>
    /// <value>Kampanyalı stok butonu aktiflik durumunu belirtir.<div class='idea_choice_list'><code>1</code> : Kampanyalı ürün butonu aktif.<br><code>0</code> : Kampanyalı ürün butonu pasif.<br></div></value>
    [DataMember(Name="campaignedProduct", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "campaignedProduct")]
    public string CampaignedProduct { get; set; }

    /// <summary>
    /// Gets or Sets Product
    /// </summary>
    [DataMember(Name="product", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "product")]
    public Product Product { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class ProductButton {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  FastShipping: ").Append(FastShipping).Append("\n");
      sb.Append("  SameDayShipping: ").Append(SameDayShipping).Append("\n");
      sb.Append("  ThreeDaysDelivery: ").Append(ThreeDaysDelivery).Append("\n");
      sb.Append("  FiveDaysDelivery: ").Append(FiveDaysDelivery).Append("\n");
      sb.Append("  SevenDaysDelivery: ").Append(SevenDaysDelivery).Append("\n");
      sb.Append("  FreeShipping: ").Append(FreeShipping).Append("\n");
      sb.Append("  DeliveryFromStock: ").Append(DeliveryFromStock).Append("\n");
      sb.Append("  PreOrderedProduct: ").Append(PreOrderedProduct).Append("\n");
      sb.Append("  LimitedStock: ").Append(LimitedStock).Append("\n");
      sb.Append("  AskStock: ").Append(AskStock).Append("\n");
      sb.Append("  CampaignedProduct: ").Append(CampaignedProduct).Append("\n");
      sb.Append("  Product: ").Append(Product).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
