using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class Theme {
    /// <summary>
    /// Tema nesnesi kimlik değeri.
    /// </summary>
    /// <value>Tema nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Temanın kullanılacağı platform.<div class='idea_choice_list'><code>desktop</code> : Masaüstü.<br><code>mobile</code> : Mobil.<br></div>
    /// </summary>
    /// <value>Temanın kullanılacağı platform.<div class='idea_choice_list'><code>desktop</code> : Masaüstü.<br><code>mobile</code> : Mobil.<br></div></value>
    [DataMember(Name="platform", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "platform")]
    public string Platform { get; set; }

    /// <summary>
    /// Tema tipi.<div class='idea_choice_list'><code>self</code> : Kişisel Tema.<br><code>standard</code> : Standart Tema.<br></div>
    /// </summary>
    /// <value>Tema tipi.<div class='idea_choice_list'><code>self</code> : Kişisel Tema.<br><code>standard</code> : Standart Tema.<br></div></value>
    [DataMember(Name="type", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "type")]
    public string Type { get; set; }

    /// <summary>
    /// Tema adı.
    /// </summary>
    /// <value>Tema adı.</value>
    [DataMember(Name="name", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "name")]
    public string Name { get; set; }

    /// <summary>
    /// Temanın rengi.
    /// </summary>
    /// <value>Temanın rengi.</value>
    [DataMember(Name="preset", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "preset")]
    public string Preset { get; set; }

    /// <summary>
    /// Temanın dizini.
    /// </summary>
    /// <value>Temanın dizini.</value>
    [DataMember(Name="directoryName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "directoryName")]
    public string DirectoryName { get; set; }

    /// <summary>
    /// Temanın durumu.
    /// </summary>
    /// <value>Temanın durumu.</value>
    [DataMember(Name="status", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "status")]
    public string Status { get; set; }

    /// <summary>
    /// Temanın revisionı.
    /// </summary>
    /// <value>Temanın revisionı.</value>
    [DataMember(Name="revision", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "revision")]
    public int? Revision { get; set; }

    /// <summary>
    /// Tema nesnesinin oluşturulma zamanı.
    /// </summary>
    /// <value>Tema nesnesinin oluşturulma zamanı.</value>
    [DataMember(Name="createdAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "createdAt")]
    public DateTime? CreatedAt { get; set; }

    /// <summary>
    /// Tema nesnesinin güncellenme zamanı.
    /// </summary>
    /// <value>Tema nesnesinin güncellenme zamanı.</value>
    [DataMember(Name="updatedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "updatedAt")]
    public DateTime? UpdatedAt { get; set; }

    /// <summary>
    /// Gets or Sets Attachment
    /// </summary>
    [DataMember(Name="attachment", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "attachment")]
    public string Attachment { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Theme {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Platform: ").Append(Platform).Append("\n");
      sb.Append("  Type: ").Append(Type).Append("\n");
      sb.Append("  Name: ").Append(Name).Append("\n");
      sb.Append("  Preset: ").Append(Preset).Append("\n");
      sb.Append("  DirectoryName: ").Append(DirectoryName).Append("\n");
      sb.Append("  Status: ").Append(Status).Append("\n");
      sb.Append("  Revision: ").Append(Revision).Append("\n");
      sb.Append("  CreatedAt: ").Append(CreatedAt).Append("\n");
      sb.Append("  UpdatedAt: ").Append(UpdatedAt).Append("\n");
      sb.Append("  Attachment: ").Append(Attachment).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
