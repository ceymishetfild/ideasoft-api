using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class ShippingProvider {
    /// <summary>
    /// Teslimat hizmeti sağlayıcısı nesnesi kimlik değeri.
    /// </summary>
    /// <value>Teslimat hizmeti sağlayıcısı nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Teslimat hizmeti sağlayıcısı kodu. Benzersiz olmalıdır.
    /// </summary>
    /// <value>Teslimat hizmeti sağlayıcısı kodu. Benzersiz olmalıdır.</value>
    [DataMember(Name="code", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "code")]
    public string Code { get; set; }

    /// <summary>
    /// Teslimat hizmeti sağlayıcısı nesnesi için isim değeri.
    /// </summary>
    /// <value>Teslimat hizmeti sağlayıcısı nesnesi için isim değeri.</value>
    [DataMember(Name="name", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "name")]
    public string Name { get; set; }

    /// <summary>
    /// Kargo takip url.
    /// </summary>
    /// <value>Kargo takip url.</value>
    [DataMember(Name="trackingUrl", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "trackingUrl")]
    public string TrackingUrl { get; set; }

    /// <summary>
    /// Kargo takip formu almak için kullanılacak method.<div class='idea_choice_list'><code>get</code> : GET methodu.<br><code>post</code> : POST methodu.<br></div>
    /// </summary>
    /// <value>Kargo takip formu almak için kullanılacak method.<div class='idea_choice_list'><code>get</code> : GET methodu.<br><code>post</code> : POST methodu.<br></div></value>
    [DataMember(Name="trackingFormMethod", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "trackingFormMethod")]
    public string TrackingFormMethod { get; set; }

    /// <summary>
    /// İlgili kargo takip formu almak için kullanılacak yük.
    /// </summary>
    /// <value>İlgili kargo takip formu almak için kullanılacak yük.</value>
    [DataMember(Name="payload", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "payload")]
    public string Payload { get; set; }

    /// <summary>
    /// Teslimat hizmeti sağlayıcısı için ayarlar.
    /// </summary>
    /// <value>Teslimat hizmeti sağlayıcısı için ayarlar.</value>
    [DataMember(Name="settings", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "settings")]
    public List<ShippingProviderSetting> Settings { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class ShippingProvider {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Code: ").Append(Code).Append("\n");
      sb.Append("  Name: ").Append(Name).Append("\n");
      sb.Append("  TrackingUrl: ").Append(TrackingUrl).Append("\n");
      sb.Append("  TrackingFormMethod: ").Append(TrackingFormMethod).Append("\n");
      sb.Append("  Payload: ").Append(Payload).Append("\n");
      sb.Append("  Settings: ").Append(Settings).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
