using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class MemberAddress {
    /// <summary>
    /// Üye adresi nesnesinin benzersiz rakamsal kimlik değeri.
    /// </summary>
    /// <value>Üye adresi nesnesinin benzersiz rakamsal kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Üye Adresi adı.
    /// </summary>
    /// <value>Üye Adresi adı.</value>
    [DataMember(Name="name", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "name")]
    public string Name { get; set; }

    /// <summary>
    /// Üye Adresi tipi.<div class='idea_choice_list'><code>shipping</code> : Teslimat adresi.<br><code>billing</code> : Fatura adresi.<br></div>
    /// </summary>
    /// <value>Üye Adresi tipi.<div class='idea_choice_list'><code>shipping</code> : Teslimat adresi.<br><code>billing</code> : Fatura adresi.<br></div></value>
    [DataMember(Name="type", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "type")]
    public string Type { get; set; }

    /// <summary>
    /// Üyenin ismi.
    /// </summary>
    /// <value>Üyenin ismi.</value>
    [DataMember(Name="firstname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "firstname")]
    public string Firstname { get; set; }

    /// <summary>
    /// Üyenin soy ismi.
    /// </summary>
    /// <value>Üyenin soy ismi.</value>
    [DataMember(Name="surname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "surname")]
    public string Surname { get; set; }

    /// <summary>
    /// Üyenin adres bilgileri.
    /// </summary>
    /// <value>Üyenin adres bilgileri.</value>
    [DataMember(Name="address", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "address")]
    public string Address { get; set; }

    /// <summary>
    /// İlçe adı.
    /// </summary>
    /// <value>İlçe adı.</value>
    [DataMember(Name="subLocationName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "subLocationName")]
    public string SubLocationName { get; set; }

    /// <summary>
    /// Üyenin telefon numarası.
    /// </summary>
    /// <value>Üyenin telefon numarası.</value>
    [DataMember(Name="phoneNumber", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "phoneNumber")]
    public string PhoneNumber { get; set; }

    /// <summary>
    /// Üyenin mobil telefon numarası.
    /// </summary>
    /// <value>Üyenin mobil telefon numarası.</value>
    [DataMember(Name="mobilePhoneNumber", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "mobilePhoneNumber")]
    public string MobilePhoneNumber { get; set; }

    /// <summary>
    /// Üyenin TC kimlik numarası.
    /// </summary>
    /// <value>Üyenin TC kimlik numarası.</value>
    [DataMember(Name="tcId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "tcId")]
    public string TcId { get; set; }

    /// <summary>
    /// Üyenin vergi numarası.
    /// </summary>
    /// <value>Üyenin vergi numarası.</value>
    [DataMember(Name="taxNumber", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "taxNumber")]
    public string TaxNumber { get; set; }

    /// <summary>
    /// Üyenin vergi dairesi.
    /// </summary>
    /// <value>Üyenin vergi dairesi.</value>
    [DataMember(Name="taxOffice", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "taxOffice")]
    public string TaxOffice { get; set; }

    /// <summary>
    /// Fatura tipini belirtir.<div class='idea_choice_list'><code>individual</code> : Bireysel<br><code>corporate</code> : Kurumsal<br></div>
    /// </summary>
    /// <value>Fatura tipini belirtir.<div class='idea_choice_list'><code>individual</code> : Bireysel<br><code>corporate</code> : Kurumsal<br></div></value>
    [DataMember(Name="invoiceType", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "invoiceType")]
    public string InvoiceType { get; set; }

    /// <summary>
    /// Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div>
    /// </summary>
    /// <value>Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.<div class='idea_choice_list'><code>1</code> : Evet<br><code>0</code> : Hayır<br></div></value>
    [DataMember(Name="isEinvoiceUser", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "isEinvoiceUser")]
    public bool? IsEinvoiceUser { get; set; }

    /// <summary>
    /// Tema nesnesinin oluşturulma zamanı.
    /// </summary>
    /// <value>Tema nesnesinin oluşturulma zamanı.</value>
    [DataMember(Name="createdAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "createdAt")]
    public DateTime? CreatedAt { get; set; }

    /// <summary>
    /// Tema nesnesinin güncellenme zamanı.
    /// </summary>
    /// <value>Tema nesnesinin güncellenme zamanı.</value>
    [DataMember(Name="updatedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "updatedAt")]
    public DateTime? UpdatedAt { get; set; }

    /// <summary>
    /// Üye nesnesi
    /// </summary>
    /// <value>Üye nesnesi</value>
    [DataMember(Name="member", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "member")]
    public Member Member { get; set; }

    /// <summary>
    /// Ülke nesnesi.
    /// </summary>
    /// <value>Ülke nesnesi.</value>
    [DataMember(Name="country", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "country")]
    public Country Country { get; set; }

    /// <summary>
    /// Şehir nesnesi.
    /// </summary>
    /// <value>Şehir nesnesi.</value>
    [DataMember(Name="location", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "location")]
    public Location Location { get; set; }

    /// <summary>
    /// İlçe nesnesi.
    /// </summary>
    /// <value>İlçe nesnesi.</value>
    [DataMember(Name="subLocation", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "subLocation")]
    public Town SubLocation { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class MemberAddress {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Name: ").Append(Name).Append("\n");
      sb.Append("  Type: ").Append(Type).Append("\n");
      sb.Append("  Firstname: ").Append(Firstname).Append("\n");
      sb.Append("  Surname: ").Append(Surname).Append("\n");
      sb.Append("  Address: ").Append(Address).Append("\n");
      sb.Append("  SubLocationName: ").Append(SubLocationName).Append("\n");
      sb.Append("  PhoneNumber: ").Append(PhoneNumber).Append("\n");
      sb.Append("  MobilePhoneNumber: ").Append(MobilePhoneNumber).Append("\n");
      sb.Append("  TcId: ").Append(TcId).Append("\n");
      sb.Append("  TaxNumber: ").Append(TaxNumber).Append("\n");
      sb.Append("  TaxOffice: ").Append(TaxOffice).Append("\n");
      sb.Append("  InvoiceType: ").Append(InvoiceType).Append("\n");
      sb.Append("  IsEinvoiceUser: ").Append(IsEinvoiceUser).Append("\n");
      sb.Append("  CreatedAt: ").Append(CreatedAt).Append("\n");
      sb.Append("  UpdatedAt: ").Append(UpdatedAt).Append("\n");
      sb.Append("  Member: ").Append(Member).Append("\n");
      sb.Append("  Country: ").Append(Country).Append("\n");
      sb.Append("  Location: ").Append(Location).Append("\n");
      sb.Append("  SubLocation: ").Append(SubLocation).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
