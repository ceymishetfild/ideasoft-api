using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class OrderRefundRequestItem {
    /// <summary>
    /// Sipariş iptal talebi kalemi nesnesi kimlik değeri.
    /// </summary>
    /// <value>Sipariş iptal talebi kalemi nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Sipariş iptal talebi istenen ürün miktarı.
    /// </summary>
    /// <value>Sipariş iptal talebi istenen ürün miktarı.</value>
    [DataMember(Name="amount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "amount")]
    public float? Amount { get; set; }

    /// <summary>
    /// Sipariş iptal talebi sebebi. Tanımlı dört seçenekten biri seçilmelidir.<div class='idea_choice_list'><code>Ürünü iade etmek istiyorum.</code> : <br><code>Ürünü değiştirmek istiyorum.</code> : <br><code>Faturadaki ürünler ile bana gelen ürünler farklı.</code> : <br><code>Diğer</code> : <br></div>
    /// </summary>
    /// <value>Sipariş iptal talebi sebebi. Tanımlı dört seçenekten biri seçilmelidir.<div class='idea_choice_list'><code>Ürünü iade etmek istiyorum.</code> : <br><code>Ürünü değiştirmek istiyorum.</code> : <br><code>Faturadaki ürünler ile bana gelen ürünler farklı.</code> : <br><code>Diğer</code> : <br></div></value>
    [DataMember(Name="reason", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "reason")]
    public string Reason { get; set; }

    /// <summary>
    /// Sipariş iptal talebinin detaylı açıklaması.
    /// </summary>
    /// <value>Sipariş iptal talebinin detaylı açıklaması.</value>
    [DataMember(Name="details", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "details")]
    public string Details { get; set; }

    /// <summary>
    /// Sipariş iptal talebi kalemi nesnesinin oluşturulma zamanı.
    /// </summary>
    /// <value>Sipariş iptal talebi kalemi nesnesinin oluşturulma zamanı.</value>
    [DataMember(Name="createdAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "createdAt")]
    public DateTime? CreatedAt { get; set; }

    /// <summary>
    /// Sipariş iptal talebi kalemi nesnesinin güncellenme zamanı.
    /// </summary>
    /// <value>Sipariş iptal talebi kalemi nesnesinin güncellenme zamanı.</value>
    [DataMember(Name="updatedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "updatedAt")]
    public DateTime? UpdatedAt { get; set; }

    /// <summary>
    /// Sipariş kalemi nesnesi.
    /// </summary>
    /// <value>Sipariş kalemi nesnesi.</value>
    [DataMember(Name="orderItem", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "orderItem")]
    public OrderItem OrderItem { get; set; }

    /// <summary>
    /// Sipariş iptal talebi nesnesi.
    /// </summary>
    /// <value>Sipariş iptal talebi nesnesi.</value>
    [DataMember(Name="orderRefundRequest", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "orderRefundRequest")]
    public OrderRefundRequest OrderRefundRequest { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class OrderRefundRequestItem {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Amount: ").Append(Amount).Append("\n");
      sb.Append("  Reason: ").Append(Reason).Append("\n");
      sb.Append("  Details: ").Append(Details).Append("\n");
      sb.Append("  CreatedAt: ").Append(CreatedAt).Append("\n");
      sb.Append("  UpdatedAt: ").Append(UpdatedAt).Append("\n");
      sb.Append("  OrderItem: ").Append(OrderItem).Append("\n");
      sb.Append("  OrderRefundRequest: ").Append(OrderRefundRequest).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
