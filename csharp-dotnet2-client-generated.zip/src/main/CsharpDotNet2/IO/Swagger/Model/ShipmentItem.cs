using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class ShipmentItem {
    /// <summary>
    /// Teslimat Kalemi nesnesi kimlik değeri.
    /// </summary>
    /// <value>Teslimat Kalemi nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Ana ürünün id değeri.
    /// </summary>
    /// <value>Ana ürünün id değeri.</value>
    [DataMember(Name="rootProductId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "rootProductId")]
    public int? RootProductId { get; set; }

    /// <summary>
    /// Ürünün stok tipi cinsinden miktarı.
    /// </summary>
    /// <value>Ürünün stok tipi cinsinden miktarı.</value>
    [DataMember(Name="amount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "amount")]
    public int? Amount { get; set; }

    /// <summary>
    /// Ürünün fiyatı.
    /// </summary>
    /// <value>Ürünün fiyatı.</value>
    [DataMember(Name="price", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "price")]
    public float? Price { get; set; }

    /// <summary>
    /// Ürün başlığı.
    /// </summary>
    /// <value>Ürün başlığı.</value>
    [DataMember(Name="productLabel", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "productLabel")]
    public string ProductLabel { get; set; }

    /// <summary>
    /// Ürünün kur bilgisi.<div class='idea_choice_list'><code>USD</code> : Amerikan Doları<br><code>EUR</code> : Euro<br><code>TL</code> : Türk Lirası<br><code>GBP</code> : İngiliz Sterlini<br><code>JPY</code> : Japon Yeni<br><code>CNY</code> : Çin Yuanı<br><code>GR</code> : Gram Altın<br><code>CHF</code> : İsviçre Frangı<br></div>
    /// </summary>
    /// <value>Ürünün kur bilgisi.<div class='idea_choice_list'><code>USD</code> : Amerikan Doları<br><code>EUR</code> : Euro<br><code>TL</code> : Türk Lirası<br><code>GBP</code> : İngiliz Sterlini<br><code>JPY</code> : Japon Yeni<br><code>CNY</code> : Çin Yuanı<br><code>GR</code> : Gram Altın<br><code>CHF</code> : İsviçre Frangı<br></div></value>
    [DataMember(Name="currency", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "currency")]
    public string Currency { get; set; }

    /// <summary>
    /// Ürünün vergi değeri.
    /// </summary>
    /// <value>Ürünün vergi değeri.</value>
    [DataMember(Name="tax", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "tax")]
    public int? Tax { get; set; }

    /// <summary>
    /// Ürünün desi bilgisi.
    /// </summary>
    /// <value>Ürünün desi bilgisi.</value>
    [DataMember(Name="dm3", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "dm3")]
    public float? Dm3 { get; set; }

    /// <summary>
    /// Teslimat Kalemi nesnesinin oluşturulma zamanı.
    /// </summary>
    /// <value>Teslimat Kalemi nesnesinin oluşturulma zamanı.</value>
    [DataMember(Name="createdAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "createdAt")]
    public DateTime? CreatedAt { get; set; }

    /// <summary>
    /// Teslimat Kalemi nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
    /// </summary>
    /// <value>Teslimat Kalemi nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div></value>
    [DataMember(Name="status", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "status")]
    public int? Status { get; set; }

    /// <summary>
    /// Teslimat Kalemi nesnesinin güncellenme zamanı.
    /// </summary>
    /// <value>Teslimat Kalemi nesnesinin güncellenme zamanı.</value>
    [DataMember(Name="updatedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "updatedAt")]
    public DateTime? UpdatedAt { get; set; }

    /// <summary>
    /// Gets or Sets OrderItem
    /// </summary>
    [DataMember(Name="orderItem", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "orderItem")]
    public OrderItem OrderItem { get; set; }

    /// <summary>
    /// Gets or Sets Product
    /// </summary>
    [DataMember(Name="product", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "product")]
    public Product Product { get; set; }

    /// <summary>
    /// Gets or Sets Shipment
    /// </summary>
    [DataMember(Name="shipment", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shipment")]
    public Shipment Shipment { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class ShipmentItem {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  RootProductId: ").Append(RootProductId).Append("\n");
      sb.Append("  Amount: ").Append(Amount).Append("\n");
      sb.Append("  Price: ").Append(Price).Append("\n");
      sb.Append("  ProductLabel: ").Append(ProductLabel).Append("\n");
      sb.Append("  Currency: ").Append(Currency).Append("\n");
      sb.Append("  Tax: ").Append(Tax).Append("\n");
      sb.Append("  Dm3: ").Append(Dm3).Append("\n");
      sb.Append("  CreatedAt: ").Append(CreatedAt).Append("\n");
      sb.Append("  Status: ").Append(Status).Append("\n");
      sb.Append("  UpdatedAt: ").Append(UpdatedAt).Append("\n");
      sb.Append("  OrderItem: ").Append(OrderItem).Append("\n");
      sb.Append("  Product: ").Append(Product).Append("\n");
      sb.Append("  Shipment: ").Append(Shipment).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
