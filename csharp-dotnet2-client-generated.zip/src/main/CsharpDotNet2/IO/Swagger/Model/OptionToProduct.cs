using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class OptionToProduct {
    /// <summary>
    /// Varyant ürün bağı nesnesi kimlik değeri.
    /// </summary>
    /// <value>Varyant ürün bağı nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Ana ürünün benzersiz kimlik değeri.
    /// </summary>
    /// <value>Ana ürünün benzersiz kimlik değeri.</value>
    [DataMember(Name="parentProductId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "parentProductId")]
    public int? ParentProductId { get; set; }

    /// <summary>
    /// Varyant grubu nesnesi.
    /// </summary>
    /// <value>Varyant grubu nesnesi.</value>
    [DataMember(Name="optionGroup", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "optionGroup")]
    public OptionGroup OptionGroup { get; set; }

    /// <summary>
    /// Varyant nesnesi.
    /// </summary>
    /// <value>Varyant nesnesi.</value>
    [DataMember(Name="option", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "option")]
    public Options Option { get; set; }

    /// <summary>
    /// Ürün nesnesi.
    /// </summary>
    /// <value>Ürün nesnesi.</value>
    [DataMember(Name="product", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "product")]
    public Product Product { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class OptionToProduct {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  ParentProductId: ").Append(ParentProductId).Append("\n");
      sb.Append("  OptionGroup: ").Append(OptionGroup).Append("\n");
      sb.Append("  Option: ").Append(Option).Append("\n");
      sb.Append("  Product: ").Append(Product).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
