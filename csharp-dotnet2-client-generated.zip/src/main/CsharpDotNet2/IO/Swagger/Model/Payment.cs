using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class Payment {
    /// <summary>
    /// Ödeme nesnesi kimlik değeri.
    /// </summary>
    /// <value>Ödeme nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Üyenin ismi.
    /// </summary>
    /// <value>Üyenin ismi.</value>
    [DataMember(Name="memberFirstname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "memberFirstname")]
    public string MemberFirstname { get; set; }

    /// <summary>
    /// Üyenin soy ismi.
    /// </summary>
    /// <value>Üyenin soy ismi.</value>
    [DataMember(Name="memberSurname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "memberSurname")]
    public string MemberSurname { get; set; }

    /// <summary>
    /// Üyenin e-mail adresi.
    /// </summary>
    /// <value>Üyenin e-mail adresi.</value>
    [DataMember(Name="memberEmail", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "memberEmail")]
    public string MemberEmail { get; set; }

    /// <summary>
    /// Üyenin telefon numarası.
    /// </summary>
    /// <value>Üyenin telefon numarası.</value>
    [DataMember(Name="memberPhone", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "memberPhone")]
    public string MemberPhone { get; set; }

    /// <summary>
    /// Ödeme tipi
    /// </summary>
    /// <value>Ödeme tipi</value>
    [DataMember(Name="paymentTypeName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "paymentTypeName")]
    public string PaymentTypeName { get; set; }

    /// <summary>
    /// Ödeme hizmeti sağlayıcısı kodu. Bu değer ön tanımlıdır.
    /// </summary>
    /// <value>Ödeme hizmeti sağlayıcısı kodu. Bu değer ön tanımlıdır.</value>
    [DataMember(Name="paymentProviderCode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "paymentProviderCode")]
    public string PaymentProviderCode { get; set; }

    /// <summary>
    /// Ödeme hizmeti sağlayıcısı adı. Bu değer ön tanımlıdır.
    /// </summary>
    /// <value>Ödeme hizmeti sağlayıcısı adı. Bu değer ön tanımlıdır.</value>
    [DataMember(Name="paymentProviderName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "paymentProviderName")]
    public string PaymentProviderName { get; set; }

    /// <summary>
    /// Ödeme kanalı adı. Bu değer ön tanımlıdır.
    /// </summary>
    /// <value>Ödeme kanalı adı. Bu değer ön tanımlıdır.</value>
    [DataMember(Name="paymentGatewayName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "paymentGatewayName")]
    public string PaymentGatewayName { get; set; }

    /// <summary>
    /// Ödeme kanalı kodu. Bu değer ön tanımlıdır.
    /// </summary>
    /// <value>Ödeme kanalı kodu. Bu değer ön tanımlıdır.</value>
    [DataMember(Name="paymentGatewayCode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "paymentGatewayCode")]
    public string PaymentGatewayCode { get; set; }

    /// <summary>
    /// Ödeme yapılan banka. Bu değer ön tanımlıdır.
    /// </summary>
    /// <value>Ödeme yapılan banka. Bu değer ön tanımlıdır.</value>
    [DataMember(Name="bankName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "bankName")]
    public string BankName { get; set; }

    /// <summary>
    /// Ödemenin gerçekleştiği cihaz bilgisi.<div class='idea_choice_list'><code>desktop</code> : Masaüstü<br><code>mobile</code> : Mobil<br><code>tablet</code> : Tablet<br></div>
    /// </summary>
    /// <value>Ödemenin gerçekleştiği cihaz bilgisi.<div class='idea_choice_list'><code>desktop</code> : Masaüstü<br><code>mobile</code> : Mobil<br><code>tablet</code> : Tablet<br></div></value>
    [DataMember(Name="deviceType", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "deviceType")]
    public string DeviceType { get; set; }

    /// <summary>
    /// Müşterinin IP adresi.
    /// </summary>
    /// <value>Müşterinin IP adresi.</value>
    [DataMember(Name="clientIp", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "clientIp")]
    public string ClientIp { get; set; }

    /// <summary>
    /// Kur oranları.
    /// </summary>
    /// <value>Kur oranları.</value>
    [DataMember(Name="currencyRates", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "currencyRates")]
    public string CurrencyRates { get; set; }

    /// <summary>
    /// Ödemenin saf fiyatı.
    /// </summary>
    /// <value>Ödemenin saf fiyatı.</value>
    [DataMember(Name="amount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "amount")]
    public float? Amount { get; set; }

    /// <summary>
    /// Ödemenin son fiyatı.
    /// </summary>
    /// <value>Ödemenin son fiyatı.</value>
    [DataMember(Name="finalAmount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "finalAmount")]
    public float? FinalAmount { get; set; }

    /// <summary>
    /// Ödemeden kazanılan toplam puan.
    /// </summary>
    /// <value>Ödemeden kazanılan toplam puan.</value>
    [DataMember(Name="sumOfGainedPoints", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "sumOfGainedPoints")]
    public float? SumOfGainedPoints { get; set; }

    /// <summary>
    /// Ödemenin standart taksit sayısı.
    /// </summary>
    /// <value>Ödemenin standart taksit sayısı.</value>
    [DataMember(Name="installment", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "installment")]
    public int? Installment { get; set; }

    /// <summary>
    /// Ödemenin taksit oranı.
    /// </summary>
    /// <value>Ödemenin taksit oranı.</value>
    [DataMember(Name="installmentRate", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "installmentRate")]
    public float? InstallmentRate { get; set; }

    /// <summary>
    /// Ödemenin ekstra taksit sayısı.
    /// </summary>
    /// <value>Ödemenin ekstra taksit sayısı.</value>
    [DataMember(Name="extraInstallment", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "extraInstallment")]
    public int? ExtraInstallment { get; set; }

    /// <summary>
    /// Kur bilgisi.
    /// </summary>
    /// <value>Kur bilgisi.</value>
    [DataMember(Name="currency", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "currency")]
    public string Currency { get; set; }

    /// <summary>
    /// Siparişin numarası.
    /// </summary>
    /// <value>Siparişin numarası.</value>
    [DataMember(Name="transactionId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "transactionId")]
    public string TransactionId { get; set; }

    /// <summary>
    /// Müşterinin ödeme notu.
    /// </summary>
    /// <value>Müşterinin ödeme notu.</value>
    [DataMember(Name="memberNote", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "memberNote")]
    public string MemberNote { get; set; }

    /// <summary>
    /// Yönetici(admin) ödeme notu.
    /// </summary>
    /// <value>Yönetici(admin) ödeme notu.</value>
    [DataMember(Name="userNote", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "userNote")]
    public string UserNote { get; set; }

    /// <summary>
    /// Ödeme durumu.<div class='idea_choice_list'><code>deleted</code> : Silindi<br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br><code>failed</code> : Hatalı Ödemeler<br><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br></div>
    /// </summary>
    /// <value>Ödeme durumu.<div class='idea_choice_list'><code>deleted</code> : Silindi<br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br><code>failed</code> : Hatalı Ödemeler<br><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br></div></value>
    [DataMember(Name="status", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "status")]
    public string Status { get; set; }

    /// <summary>
    /// Ödemenin hata mesajı.
    /// </summary>
    /// <value>Ödemenin hata mesajı.</value>
    [DataMember(Name="errorMessage", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "errorMessage")]
    public string ErrorMessage { get; set; }

    /// <summary>
    /// Kart saklama sistemi.
    /// </summary>
    /// <value>Kart saklama sistemi.</value>
    [DataMember(Name="cardSavingSystem", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "cardSavingSystem")]
    public string CardSavingSystem { get; set; }

    /// <summary>
    /// Ödeme nesnesinin oluşturulma zamanı.
    /// </summary>
    /// <value>Ödeme nesnesinin oluşturulma zamanı.</value>
    [DataMember(Name="createdAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "createdAt")]
    public DateTime? CreatedAt { get; set; }

    /// <summary>
    /// Üye nesnesi.
    /// </summary>
    /// <value>Üye nesnesi.</value>
    [DataMember(Name="member", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "member")]
    public Member Member { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Payment {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  MemberFirstname: ").Append(MemberFirstname).Append("\n");
      sb.Append("  MemberSurname: ").Append(MemberSurname).Append("\n");
      sb.Append("  MemberEmail: ").Append(MemberEmail).Append("\n");
      sb.Append("  MemberPhone: ").Append(MemberPhone).Append("\n");
      sb.Append("  PaymentTypeName: ").Append(PaymentTypeName).Append("\n");
      sb.Append("  PaymentProviderCode: ").Append(PaymentProviderCode).Append("\n");
      sb.Append("  PaymentProviderName: ").Append(PaymentProviderName).Append("\n");
      sb.Append("  PaymentGatewayName: ").Append(PaymentGatewayName).Append("\n");
      sb.Append("  PaymentGatewayCode: ").Append(PaymentGatewayCode).Append("\n");
      sb.Append("  BankName: ").Append(BankName).Append("\n");
      sb.Append("  DeviceType: ").Append(DeviceType).Append("\n");
      sb.Append("  ClientIp: ").Append(ClientIp).Append("\n");
      sb.Append("  CurrencyRates: ").Append(CurrencyRates).Append("\n");
      sb.Append("  Amount: ").Append(Amount).Append("\n");
      sb.Append("  FinalAmount: ").Append(FinalAmount).Append("\n");
      sb.Append("  SumOfGainedPoints: ").Append(SumOfGainedPoints).Append("\n");
      sb.Append("  Installment: ").Append(Installment).Append("\n");
      sb.Append("  InstallmentRate: ").Append(InstallmentRate).Append("\n");
      sb.Append("  ExtraInstallment: ").Append(ExtraInstallment).Append("\n");
      sb.Append("  Currency: ").Append(Currency).Append("\n");
      sb.Append("  TransactionId: ").Append(TransactionId).Append("\n");
      sb.Append("  MemberNote: ").Append(MemberNote).Append("\n");
      sb.Append("  UserNote: ").Append(UserNote).Append("\n");
      sb.Append("  Status: ").Append(Status).Append("\n");
      sb.Append("  ErrorMessage: ").Append(ErrorMessage).Append("\n");
      sb.Append("  CardSavingSystem: ").Append(CardSavingSystem).Append("\n");
      sb.Append("  CreatedAt: ").Append(CreatedAt).Append("\n");
      sb.Append("  Member: ").Append(Member).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
