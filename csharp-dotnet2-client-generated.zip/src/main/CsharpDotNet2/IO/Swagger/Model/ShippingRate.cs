using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class ShippingRate {
    /// <summary>
    /// Kargo oranı nesnesi kimlik değeri.
    /// </summary>
    /// <value>Kargo oranı nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// İlgili kargo firması, ilgili bölge ve ilgili orana ait minimum desi değeri.
    /// </summary>
    /// <value>İlgili kargo firması, ilgili bölge ve ilgili orana ait minimum desi değeri.</value>
    [DataMember(Name="volumetricWeightStart", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "volumetricWeightStart")]
    public int? VolumetricWeightStart { get; set; }

    /// <summary>
    /// İlgili kargo firması, ilgili bölge ve ilgili orana ait maximum desi değeri.
    /// </summary>
    /// <value>İlgili kargo firması, ilgili bölge ve ilgili orana ait maximum desi değeri.</value>
    [DataMember(Name="volumetricWeightEnd", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "volumetricWeightEnd")]
    public int? VolumetricWeightEnd { get; set; }

    /// <summary>
    /// Seçili bölge ve kargo firması için kargo oranı.
    /// </summary>
    /// <value>Seçili bölge ve kargo firması için kargo oranı.</value>
    [DataMember(Name="rate", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "rate")]
    public float? Rate { get; set; }

    /// <summary>
    /// Bölge nesnesi.
    /// </summary>
    /// <value>Bölge nesnesi.</value>
    [DataMember(Name="region", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "region")]
    public Region Region { get; set; }

    /// <summary>
    /// Kargo firması nesnesi.
    /// </summary>
    /// <value>Kargo firması nesnesi.</value>
    [DataMember(Name="shippingCompany", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingCompany")]
    public ShippingCompany ShippingCompany { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class ShippingRate {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  VolumetricWeightStart: ").Append(VolumetricWeightStart).Append("\n");
      sb.Append("  VolumetricWeightEnd: ").Append(VolumetricWeightEnd).Append("\n");
      sb.Append("  Rate: ").Append(Rate).Append("\n");
      sb.Append("  Region: ").Append(Region).Append("\n");
      sb.Append("  ShippingCompany: ").Append(ShippingCompany).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
