using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class OrderRefundRequest {
    /// <summary>
    /// Sipariş iptal talebi nesnesi kimlik değeri.
    /// </summary>
    /// <value>Sipariş iptal talebi nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Sipariş iptal talebi için oluşturulan benzersiz kod değeri.
    /// </summary>
    /// <value>Sipariş iptal talebi için oluşturulan benzersiz kod değeri.</value>
    [DataMember(Name="code", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "code")]
    public string Code { get; set; }

    /// <summary>
    /// Sipariş iptal talebi için durum bilgisi.<div class='idea_choice_list'><code>approved</code> : Onaylandı.<br><code>waiting_for_approval</code> : Onay bekliyor.<br><code>cancelled</code> : İptal edildi.<br></div>
    /// </summary>
    /// <value>Sipariş iptal talebi için durum bilgisi.<div class='idea_choice_list'><code>approved</code> : Onaylandı.<br><code>waiting_for_approval</code> : Onay bekliyor.<br><code>cancelled</code> : İptal edildi.<br></div></value>
    [DataMember(Name="status", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "status")]
    public string Status { get; set; }

    /// <summary>
    /// Müşteriye ödenecek miktar bilgisi.
    /// </summary>
    /// <value>Müşteriye ödenecek miktar bilgisi.</value>
    [DataMember(Name="fee", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "fee")]
    public float? Fee { get; set; }

    /// <summary>
    /// Sipariş iptal talebinin oluşturulması sebebinin detaylı açıklaması.
    /// </summary>
    /// <value>Sipariş iptal talebinin oluşturulması sebebinin detaylı açıklaması.</value>
    [DataMember(Name="cancellationReason", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "cancellationReason")]
    public string CancellationReason { get; set; }

    /// <summary>
    /// Sipariş iptal talebi nesnesinin oluşturulma zamanı.
    /// </summary>
    /// <value>Sipariş iptal talebi nesnesinin oluşturulma zamanı.</value>
    [DataMember(Name="createdAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "createdAt")]
    public DateTime? CreatedAt { get; set; }

    /// <summary>
    /// Sipariş iptal talebi nesnesinin güncellenme zamanı.
    /// </summary>
    /// <value>Sipariş iptal talebi nesnesinin güncellenme zamanı.</value>
    [DataMember(Name="updatedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "updatedAt")]
    public DateTime? UpdatedAt { get; set; }

    /// <summary>
    /// Üye nesnesi.
    /// </summary>
    /// <value>Üye nesnesi.</value>
    [DataMember(Name="member", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "member")]
    public Member Member { get; set; }

    /// <summary>
    /// Sipariş nesnesi.
    /// </summary>
    /// <value>Sipariş nesnesi.</value>
    [DataMember(Name="order", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "order")]
    public Order Order { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class OrderRefundRequest {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Code: ").Append(Code).Append("\n");
      sb.Append("  Status: ").Append(Status).Append("\n");
      sb.Append("  Fee: ").Append(Fee).Append("\n");
      sb.Append("  CancellationReason: ").Append(CancellationReason).Append("\n");
      sb.Append("  CreatedAt: ").Append(CreatedAt).Append("\n");
      sb.Append("  UpdatedAt: ").Append(UpdatedAt).Append("\n");
      sb.Append("  Member: ").Append(Member).Append("\n");
      sb.Append("  Order: ").Append(Order).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
