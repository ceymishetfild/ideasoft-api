using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class Options {
    /// <summary>
    /// Varyant nesnesi kimlik değeri.
    /// </summary>
    /// <value>Varyant nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Varyant başlığı. Varyant Grubu renk is bu değer kırmızı olabilir.
    /// </summary>
    /// <value>Varyant başlığı. Varyant Grubu renk is bu değer kırmızı olabilir.</value>
    [DataMember(Name="title", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "title")]
    public string Title { get; set; }

    /// <summary>
    /// Varyant nesnesi için sıralama değeri.
    /// </summary>
    /// <value>Varyant nesnesi için sıralama değeri.</value>
    [DataMember(Name="sortOrder", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "sortOrder")]
    public int? SortOrder { get; set; }

    /// <summary>
    /// Logo görselinin adı.<div class='idea_choice_list'><code>jpg</code> : jpg dosyası için geçerli uzantı.<br><code>png</code> : png dosyası için geçerli uzantı.<br><code>gif</code> : gif dosyası için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyası için geçerli uzantı.<br></div>
    /// </summary>
    /// <value>Logo görselinin adı.<div class='idea_choice_list'><code>jpg</code> : jpg dosyası için geçerli uzantı.<br><code>png</code> : png dosyası için geçerli uzantı.<br><code>gif</code> : gif dosyası için geçerli uzantı.<br><code>jpeg</code> : jpeg dosyası için geçerli uzantı.<br></div></value>
    [DataMember(Name="logo", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "logo")]
    public string Logo { get; set; }

    /// <summary>
    /// Gets or Sets OptionGroup
    /// </summary>
    [DataMember(Name="optionGroup", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "optionGroup")]
    public OptionGroup OptionGroup { get; set; }

    /// <summary>
    /// Varyant nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.
    /// </summary>
    /// <value>Varyant nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir.</value>
    [DataMember(Name="attachment", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "attachment")]
    public string Attachment { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Options {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Title: ").Append(Title).Append("\n");
      sb.Append("  SortOrder: ").Append(SortOrder).Append("\n");
      sb.Append("  Logo: ").Append(Logo).Append("\n");
      sb.Append("  OptionGroup: ").Append(OptionGroup).Append("\n");
      sb.Append("  Attachment: ").Append(Attachment).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
