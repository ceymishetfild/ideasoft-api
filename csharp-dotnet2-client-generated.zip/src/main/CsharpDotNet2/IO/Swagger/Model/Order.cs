using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class Order {
    /// <summary>
    /// Sipariş nesnesi kimlik değeri.
    /// </summary>
    /// <value>Sipariş nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Müşterinin ismi.
    /// </summary>
    /// <value>Müşterinin ismi.</value>
    [DataMember(Name="customerFirstname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "customerFirstname")]
    public string CustomerFirstname { get; set; }

    /// <summary>
    /// Müşterinin soy ismi.
    /// </summary>
    /// <value>Müşterinin soy ismi.</value>
    [DataMember(Name="customerSurname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "customerSurname")]
    public string CustomerSurname { get; set; }

    /// <summary>
    /// Müşterinin e-mail adresi.
    /// </summary>
    /// <value>Müşterinin e-mail adresi.</value>
    [DataMember(Name="customerEmail", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "customerEmail")]
    public string CustomerEmail { get; set; }

    /// <summary>
    /// Müşterinin telefon numarası.
    /// </summary>
    /// <value>Müşterinin telefon numarası.</value>
    [DataMember(Name="customerPhone", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "customerPhone")]
    public string CustomerPhone { get; set; }

    /// <summary>
    /// Siparişin ödeme tipi.
    /// </summary>
    /// <value>Siparişin ödeme tipi.</value>
    [DataMember(Name="paymentTypeName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "paymentTypeName")]
    public string PaymentTypeName { get; set; }

    /// <summary>
    /// Siparişin ödeme altyapısı sağlayıcısının kodu. Ön tanımlıdır. API otomatik oluşturur.
    /// </summary>
    /// <value>Siparişin ödeme altyapısı sağlayıcısının kodu. Ön tanımlıdır. API otomatik oluşturur.</value>
    [DataMember(Name="paymentProviderCode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "paymentProviderCode")]
    public string PaymentProviderCode { get; set; }

    /// <summary>
    /// Siparişin ödeme altyapısı sağlayıcısının adı. Ön tanımlıdır. API otomatik oluşturur.
    /// </summary>
    /// <value>Siparişin ödeme altyapısı sağlayıcısının adı. Ön tanımlıdır. API otomatik oluşturur.</value>
    [DataMember(Name="paymentProviderName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "paymentProviderName")]
    public string PaymentProviderName { get; set; }

    /// <summary>
    /// Siparişin ödeme kanalının kodu. Ön tanımlıdır. API otomatik oluşturur.
    /// </summary>
    /// <value>Siparişin ödeme kanalının kodu. Ön tanımlıdır. API otomatik oluşturur.</value>
    [DataMember(Name="paymentGatewayCode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "paymentGatewayCode")]
    public string PaymentGatewayCode { get; set; }

    /// <summary>
    /// Siparişin ödeme kanalının adı. Ön tanımlıdır. API otomatik oluşturur.
    /// </summary>
    /// <value>Siparişin ödeme kanalının adı. Ön tanımlıdır. API otomatik oluşturur.</value>
    [DataMember(Name="paymentGatewayName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "paymentGatewayName")]
    public string PaymentGatewayName { get; set; }

    /// <summary>
    /// Siparişin banka adı. Ön tanımlıdır. API otomatik oluşturur.
    /// </summary>
    /// <value>Siparişin banka adı. Ön tanımlıdır. API otomatik oluşturur.</value>
    [DataMember(Name="bankName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "bankName")]
    public string BankName { get; set; }

    /// <summary>
    /// Müşterinin IP adresi.
    /// </summary>
    /// <value>Müşterinin IP adresi.</value>
    [DataMember(Name="clientIp", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "clientIp")]
    public string ClientIp { get; set; }

    /// <summary>
    /// Siparişin gerçekleştiği tarayıcı bilgisi.
    /// </summary>
    /// <value>Siparişin gerçekleştiği tarayıcı bilgisi.</value>
    [DataMember(Name="userAgent", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "userAgent")]
    public string UserAgent { get; set; }

    /// <summary>
    /// Kur bilgisi.
    /// </summary>
    /// <value>Kur bilgisi.</value>
    [DataMember(Name="currency", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "currency")]
    public string Currency { get; set; }

    /// <summary>
    /// Kur oranları.
    /// </summary>
    /// <value>Kur oranları.</value>
    [DataMember(Name="currencyRates", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "currencyRates")]
    public string CurrencyRates { get; set; }

    /// <summary>
    /// Siparişin vergi hariç fiyatı.
    /// </summary>
    /// <value>Siparişin vergi hariç fiyatı.</value>
    [DataMember(Name="amount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "amount")]
    public float? Amount { get; set; }

    /// <summary>
    /// Siparişte kullanılan hediye çeki indirimi tutarı.
    /// </summary>
    /// <value>Siparişte kullanılan hediye çeki indirimi tutarı.</value>
    [DataMember(Name="couponDiscount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "couponDiscount")]
    public float? CouponDiscount { get; set; }

    /// <summary>
    /// Siparişin vergi tutarı.
    /// </summary>
    /// <value>Siparişin vergi tutarı.</value>
    [DataMember(Name="taxAmount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "taxAmount")]
    public float? TaxAmount { get; set; }

    /// <summary>
    /// Siparişte kullanılan promosyon indirimi tutarı.
    /// </summary>
    /// <value>Siparişte kullanılan promosyon indirimi tutarı.</value>
    [DataMember(Name="promotionDiscount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "promotionDiscount")]
    public float? PromotionDiscount { get; set; }

    /// <summary>
    /// Siparişin genel fiyat tutarı. orderAmount, couponDiscount, taxAmount, promotionDiscount, shippingAmount, additionalServiceAmount tutarlarının toplamı.
    /// </summary>
    /// <value>Siparişin genel fiyat tutarı. orderAmount, couponDiscount, taxAmount, promotionDiscount, shippingAmount, additionalServiceAmount tutarlarının toplamı.</value>
    [DataMember(Name="generalAmount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "generalAmount")]
    public float? GeneralAmount { get; set; }

    /// <summary>
    /// Siparişin teslimat ücreti.
    /// </summary>
    /// <value>Siparişin teslimat ücreti.</value>
    [DataMember(Name="shippingAmount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingAmount")]
    public float? ShippingAmount { get; set; }

    /// <summary>
    /// Siparişin ek hizmet bedeli ücreti.
    /// </summary>
    /// <value>Siparişin ek hizmet bedeli ücreti.</value>
    [DataMember(Name="additionalServiceAmount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "additionalServiceAmount")]
    public float? AdditionalServiceAmount { get; set; }

    /// <summary>
    /// Siparişin son ödeme tutarı. generalAmount değerinin üzerine taksitten kaynaklı vade farkı bedeli eklenmiş hali.
    /// </summary>
    /// <value>Siparişin son ödeme tutarı. generalAmount değerinin üzerine taksitten kaynaklı vade farkı bedeli eklenmiş hali.</value>
    [DataMember(Name="finalAmount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "finalAmount")]
    public float? FinalAmount { get; set; }

    /// <summary>
    /// Siparişten kazanılan puan tutarı.
    /// </summary>
    /// <value>Siparişten kazanılan puan tutarı.</value>
    [DataMember(Name="sumOfGainedPoints", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "sumOfGainedPoints")]
    public float? SumOfGainedPoints { get; set; }

    /// <summary>
    /// Siparişin taksit adeti.
    /// </summary>
    /// <value>Siparişin taksit adeti.</value>
    [DataMember(Name="installment", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "installment")]
    public int? Installment { get; set; }

    /// <summary>
    /// Siparişin taksit oranı.
    /// </summary>
    /// <value>Siparişin taksit oranı.</value>
    [DataMember(Name="installmentRate", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "installmentRate")]
    public float? InstallmentRate { get; set; }

    /// <summary>
    /// Siparişin ek taksit adeti.
    /// </summary>
    /// <value>Siparişin ek taksit adeti.</value>
    [DataMember(Name="extraInstallment", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "extraInstallment")]
    public int? ExtraInstallment { get; set; }

    /// <summary>
    /// Siparişin numarası.
    /// </summary>
    /// <value>Siparişin numarası.</value>
    [DataMember(Name="transactionId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "transactionId")]
    public string TransactionId { get; set; }

    /// <summary>
    /// Siparişin müşteri notuna sahiplik durumu.<div class='idea_choice_list'><code>1</code> : Sipariş müşteri notuna sahip.<br><code>0</code> : Sipariş müşteri notuna sahip değil.<br></div>
    /// </summary>
    /// <value>Siparişin müşteri notuna sahiplik durumu.<div class='idea_choice_list'><code>1</code> : Sipariş müşteri notuna sahip.<br><code>0</code> : Sipariş müşteri notuna sahip değil.<br></div></value>
    [DataMember(Name="hasUserNote", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "hasUserNote")]
    public string HasUserNote { get; set; }

    /// <summary>
    /// Sipariş durumu.<div class='idea_choice_list'><code>deleted</code> : Silindi<br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br></div>
    /// </summary>
    /// <value>Sipariş durumu.<div class='idea_choice_list'><code>deleted</code> : Silindi<br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br></div></value>
    [DataMember(Name="status", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "status")]
    public string Status { get; set; }

    /// <summary>
    /// Ödeme durumu bilgisi.<div class='idea_choice_list'><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br><code>failed</code> : Hatalı Ödemeler<br><code>success</code> : Başarılı<br></div>
    /// </summary>
    /// <value>Ödeme durumu bilgisi.<div class='idea_choice_list'><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br><code>failed</code> : Hatalı Ödemeler<br><code>success</code> : Başarılı<br></div></value>
    [DataMember(Name="paymentStatus", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "paymentStatus")]
    public string PaymentStatus { get; set; }

    /// <summary>
    /// Siparişin hata mesajı.
    /// </summary>
    /// <value>Siparişin hata mesajı.</value>
    [DataMember(Name="errorMessage", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "errorMessage")]
    public string ErrorMessage { get; set; }

    /// <summary>
    /// Siparişin gerçekleştiği cihaz bilgisi.<div class='idea_choice_list'><code>desktop</code> : Masaüstü<br><code>mobile</code> : Mobil<br><code>tablet</code> : Tablet<br></div>
    /// </summary>
    /// <value>Siparişin gerçekleştiği cihaz bilgisi.<div class='idea_choice_list'><code>desktop</code> : Masaüstü<br><code>mobile</code> : Mobil<br><code>tablet</code> : Tablet<br></div></value>
    [DataMember(Name="deviceType", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "deviceType")]
    public string DeviceType { get; set; }

    /// <summary>
    /// Siparişe yönlendiren web-sitesi adresi. Yönlendirmeyi yapan web-sitesinin tam URL bilgisini de içerir. API otomatik oluşturur.
    /// </summary>
    /// <value>Siparişe yönlendiren web-sitesi adresi. Yönlendirmeyi yapan web-sitesinin tam URL bilgisini de içerir. API otomatik oluşturur.</value>
    [DataMember(Name="referrer", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "referrer")]
    public string Referrer { get; set; }

    /// <summary>
    /// Sipariş için alınan fatura çıktısı adedi.
    /// </summary>
    /// <value>Sipariş için alınan fatura çıktısı adedi.</value>
    [DataMember(Name="invoicePrintCount", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "invoicePrintCount")]
    public int? InvoicePrintCount { get; set; }

    /// <summary>
    /// Hediye paketi istenilmesi durumu.<div class='idea_choice_list'><code>1</code> : Hediye paketi istiyorum<br><code>0</code> : Hediye paketi istemiyorum<br></div>
    /// </summary>
    /// <value>Hediye paketi istenilmesi durumu.<div class='idea_choice_list'><code>1</code> : Hediye paketi istiyorum<br><code>0</code> : Hediye paketi istemiyorum<br></div></value>
    [DataMember(Name="useGiftPackage", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "useGiftPackage")]
    public string UseGiftPackage { get; set; }

    /// <summary>
    /// Hediye notu.
    /// </summary>
    /// <value>Hediye notu.</value>
    [DataMember(Name="giftNote", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "giftNote")]
    public string GiftNote { get; set; }

    /// <summary>
    /// Üye grubu adı.
    /// </summary>
    /// <value>Üye grubu adı.</value>
    [DataMember(Name="memberGroupName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "memberGroupName")]
    public string MemberGroupName { get; set; }

    /// <summary>
    /// Promosyon kullanılma durumu.<div class='idea_choice_list'><code>1</code> : Promosyon kullan<br><code>0</code> : Promosyon kullanma<br></div>
    /// </summary>
    /// <value>Promosyon kullanılma durumu.<div class='idea_choice_list'><code>1</code> : Promosyon kullan<br><code>0</code> : Promosyon kullanma<br></div></value>
    [DataMember(Name="usePromotion", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "usePromotion")]
    public string UsePromotion { get; set; }

    /// <summary>
    /// Siparişin teslimat hizmeti sağlayıcısı kodu. Ön tanımlıdır. API otomatik oluşturur.
    /// </summary>
    /// <value>Siparişin teslimat hizmeti sağlayıcısı kodu. Ön tanımlıdır. API otomatik oluşturur.</value>
    [DataMember(Name="shippingProviderCode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingProviderCode")]
    public string ShippingProviderCode { get; set; }

    /// <summary>
    /// Siparişin teslimat hizmeti sağlayıcısı adı. Ön tanımlıdır.
    /// </summary>
    /// <value>Siparişin teslimat hizmeti sağlayıcısı adı. Ön tanımlıdır.</value>
    [DataMember(Name="shippingProviderName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingProviderName")]
    public string ShippingProviderName { get; set; }

    /// <summary>
    /// Siparişin kargo firması adı. Ön tanımlıdır.
    /// </summary>
    /// <value>Siparişin kargo firması adı. Ön tanımlıdır.</value>
    [DataMember(Name="shippingCompanyName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingCompanyName")]
    public string ShippingCompanyName { get; set; }

    /// <summary>
    /// Siparişin kargo ödeme tipi.<div class='idea_choice_list'><code>cash_on_delivery</code> : Alıcı Ödemeli<br><code>standart_delivery</code> : Gönderici Ödemeli<br><code>not_applicable</code> : Bu alan için geçerli değil.<br></div>
    /// </summary>
    /// <value>Siparişin kargo ödeme tipi.<div class='idea_choice_list'><code>cash_on_delivery</code> : Alıcı Ödemeli<br><code>standart_delivery</code> : Gönderici Ödemeli<br><code>not_applicable</code> : Bu alan için geçerli değil.<br></div></value>
    [DataMember(Name="shippingPaymentType", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingPaymentType")]
    public string ShippingPaymentType { get; set; }

    /// <summary>
    /// Siparişin kargo takip kodu.
    /// </summary>
    /// <value>Siparişin kargo takip kodu.</value>
    [DataMember(Name="shippingTrackingCode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingTrackingCode")]
    public string ShippingTrackingCode { get; set; }

    /// <summary>
    /// Siparişin kaynak bilgisi. Siparişin kaynak yazılımını belirtir.
    /// </summary>
    /// <value>Siparişin kaynak bilgisi. Siparişin kaynak yazılımını belirtir.</value>
    [DataMember(Name="source", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "source")]
    public string Source { get; set; }

    /// <summary>
    /// Sipariş nesnesinin oluşturulma zamanı.
    /// </summary>
    /// <value>Sipariş nesnesinin oluşturulma zamanı.</value>
    [DataMember(Name="createdAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "createdAt")]
    public DateTime? CreatedAt { get; set; }

    /// <summary>
    /// Sipariş nesnesinin güncellenme zamanı.
    /// </summary>
    /// <value>Sipariş nesnesinin güncellenme zamanı.</value>
    [DataMember(Name="updatedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "updatedAt")]
    public DateTime? UpdatedAt { get; set; }

    /// <summary>
    /// Gets or Sets Maillist
    /// </summary>
    [DataMember(Name="maillist", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "maillist")]
    public Maillist Maillist { get; set; }

    /// <summary>
    /// Gets or Sets Member
    /// </summary>
    [DataMember(Name="member", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "member")]
    public Member Member { get; set; }

    /// <summary>
    /// Sipariş detayları.
    /// </summary>
    /// <value>Sipariş detayları.</value>
    [DataMember(Name="orderDetails", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "orderDetails")]
    public List<OrderDetail> OrderDetails { get; set; }

    /// <summary>
    /// Sipariş kalemleri.
    /// </summary>
    /// <value>Sipariş kalemleri.</value>
    [DataMember(Name="orderItems", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "orderItems")]
    public List<OrderItem> OrderItems { get; set; }

    /// <summary>
    /// Gets or Sets ShippingAddress
    /// </summary>
    [DataMember(Name="shippingAddress", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingAddress")]
    public ShippingAddress ShippingAddress { get; set; }

    /// <summary>
    /// Gets or Sets BillingAddress
    /// </summary>
    [DataMember(Name="billingAddress", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "billingAddress")]
    public BillingAddress BillingAddress { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Order {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  CustomerFirstname: ").Append(CustomerFirstname).Append("\n");
      sb.Append("  CustomerSurname: ").Append(CustomerSurname).Append("\n");
      sb.Append("  CustomerEmail: ").Append(CustomerEmail).Append("\n");
      sb.Append("  CustomerPhone: ").Append(CustomerPhone).Append("\n");
      sb.Append("  PaymentTypeName: ").Append(PaymentTypeName).Append("\n");
      sb.Append("  PaymentProviderCode: ").Append(PaymentProviderCode).Append("\n");
      sb.Append("  PaymentProviderName: ").Append(PaymentProviderName).Append("\n");
      sb.Append("  PaymentGatewayCode: ").Append(PaymentGatewayCode).Append("\n");
      sb.Append("  PaymentGatewayName: ").Append(PaymentGatewayName).Append("\n");
      sb.Append("  BankName: ").Append(BankName).Append("\n");
      sb.Append("  ClientIp: ").Append(ClientIp).Append("\n");
      sb.Append("  UserAgent: ").Append(UserAgent).Append("\n");
      sb.Append("  Currency: ").Append(Currency).Append("\n");
      sb.Append("  CurrencyRates: ").Append(CurrencyRates).Append("\n");
      sb.Append("  Amount: ").Append(Amount).Append("\n");
      sb.Append("  CouponDiscount: ").Append(CouponDiscount).Append("\n");
      sb.Append("  TaxAmount: ").Append(TaxAmount).Append("\n");
      sb.Append("  PromotionDiscount: ").Append(PromotionDiscount).Append("\n");
      sb.Append("  GeneralAmount: ").Append(GeneralAmount).Append("\n");
      sb.Append("  ShippingAmount: ").Append(ShippingAmount).Append("\n");
      sb.Append("  AdditionalServiceAmount: ").Append(AdditionalServiceAmount).Append("\n");
      sb.Append("  FinalAmount: ").Append(FinalAmount).Append("\n");
      sb.Append("  SumOfGainedPoints: ").Append(SumOfGainedPoints).Append("\n");
      sb.Append("  Installment: ").Append(Installment).Append("\n");
      sb.Append("  InstallmentRate: ").Append(InstallmentRate).Append("\n");
      sb.Append("  ExtraInstallment: ").Append(ExtraInstallment).Append("\n");
      sb.Append("  TransactionId: ").Append(TransactionId).Append("\n");
      sb.Append("  HasUserNote: ").Append(HasUserNote).Append("\n");
      sb.Append("  Status: ").Append(Status).Append("\n");
      sb.Append("  PaymentStatus: ").Append(PaymentStatus).Append("\n");
      sb.Append("  ErrorMessage: ").Append(ErrorMessage).Append("\n");
      sb.Append("  DeviceType: ").Append(DeviceType).Append("\n");
      sb.Append("  Referrer: ").Append(Referrer).Append("\n");
      sb.Append("  InvoicePrintCount: ").Append(InvoicePrintCount).Append("\n");
      sb.Append("  UseGiftPackage: ").Append(UseGiftPackage).Append("\n");
      sb.Append("  GiftNote: ").Append(GiftNote).Append("\n");
      sb.Append("  MemberGroupName: ").Append(MemberGroupName).Append("\n");
      sb.Append("  UsePromotion: ").Append(UsePromotion).Append("\n");
      sb.Append("  ShippingProviderCode: ").Append(ShippingProviderCode).Append("\n");
      sb.Append("  ShippingProviderName: ").Append(ShippingProviderName).Append("\n");
      sb.Append("  ShippingCompanyName: ").Append(ShippingCompanyName).Append("\n");
      sb.Append("  ShippingPaymentType: ").Append(ShippingPaymentType).Append("\n");
      sb.Append("  ShippingTrackingCode: ").Append(ShippingTrackingCode).Append("\n");
      sb.Append("  Source: ").Append(Source).Append("\n");
      sb.Append("  CreatedAt: ").Append(CreatedAt).Append("\n");
      sb.Append("  UpdatedAt: ").Append(UpdatedAt).Append("\n");
      sb.Append("  Maillist: ").Append(Maillist).Append("\n");
      sb.Append("  Member: ").Append(Member).Append("\n");
      sb.Append("  OrderDetails: ").Append(OrderDetails).Append("\n");
      sb.Append("  OrderItems: ").Append(OrderItems).Append("\n");
      sb.Append("  ShippingAddress: ").Append(ShippingAddress).Append("\n");
      sb.Append("  BillingAddress: ").Append(BillingAddress).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
