using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class CurrentAccount {
    /// <summary>
    /// Cari hesap nesnesi kimlik değeri.
    /// </summary>
    /// <value>Cari hesap nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Cari hesap için düzenlenebilir bir kod değeri.
    /// </summary>
    /// <value>Cari hesap için düzenlenebilir bir kod değeri.</value>
    [DataMember(Name="code", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "code")]
    public string Code { get; set; }

    /// <summary>
    /// Cari hesap nesnesinin başlığı.
    /// </summary>
    /// <value>Cari hesap nesnesinin başlığı.</value>
    [DataMember(Name="title", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "title")]
    public string Title { get; set; }

    /// <summary>
    /// Cari hesabın bakiyesi.
    /// </summary>
    /// <value>Cari hesabın bakiyesi.</value>
    [DataMember(Name="balance", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "balance")]
    public float? Balance { get; set; }

    /// <summary>
    /// Cari hesap için belirlenmiş risk limiti.
    /// </summary>
    /// <value>Cari hesap için belirlenmiş risk limiti.</value>
    [DataMember(Name="riskLimit", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "riskLimit")]
    public float? RiskLimit { get; set; }

    /// <summary>
    /// Cari hesap nesnesinin oluşturulma zamanı.
    /// </summary>
    /// <value>Cari hesap nesnesinin oluşturulma zamanı.</value>
    [DataMember(Name="createdAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "createdAt")]
    public DateTime? CreatedAt { get; set; }

    /// <summary>
    /// Cari hesap nesnesinin güncellenme zamanı.
    /// </summary>
    /// <value>Cari hesap nesnesinin güncellenme zamanı.</value>
    [DataMember(Name="updatedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "updatedAt")]
    public DateTime? UpdatedAt { get; set; }

    /// <summary>
    /// Gets or Sets Member
    /// </summary>
    [DataMember(Name="member", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "member")]
    public Member Member { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class CurrentAccount {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Code: ").Append(Code).Append("\n");
      sb.Append("  Title: ").Append(Title).Append("\n");
      sb.Append("  Balance: ").Append(Balance).Append("\n");
      sb.Append("  RiskLimit: ").Append(RiskLimit).Append("\n");
      sb.Append("  CreatedAt: ").Append(CreatedAt).Append("\n");
      sb.Append("  UpdatedAt: ").Append(UpdatedAt).Append("\n");
      sb.Append("  Member: ").Append(Member).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
