using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class ShippingCompany {
    /// <summary>
    /// Kargo firması nesnesi kimlik değeri.
    /// </summary>
    /// <value>Kargo firması nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Kargo firması nesnesi için isim değeri.
    /// </summary>
    /// <value>Kargo firması nesnesi için isim değeri.</value>
    [DataMember(Name="name", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "name")]
    public string Name { get; set; }

    /// <summary>
    /// Kargo firması nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>active</code> : Aktif.<br><code>passive</code> : Pasif.<br></div>
    /// </summary>
    /// <value>Kargo firması nesnesinin aktiflik durumunu belirten değer.<div class='idea_choice_list'><code>active</code> : Aktif.<br><code>passive</code> : Pasif.<br></div></value>
    [DataMember(Name="status", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "status")]
    public string Status { get; set; }

    /// <summary>
    /// Kargo firması için sabit ücret. Sabit bir kargo ücreti uygulayacaksanız her sipariş için sabit kargo ücreti girebilirsiniz. Desi bilgilerini kaydetmeniz durumunda desi toplamlarının üzerine sabit ücret eklenecektir.
    /// </summary>
    /// <value>Kargo firması için sabit ücret. Sabit bir kargo ücreti uygulayacaksanız her sipariş için sabit kargo ücreti girebilirsiniz. Desi bilgilerini kaydetmeniz durumunda desi toplamlarının üzerine sabit ücret eklenecektir.</value>
    [DataMember(Name="extraPrice", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "extraPrice")]
    public float? ExtraPrice { get; set; }

    /// <summary>
    /// Kargo firması için girmiş olduğunuz desi bilgileri 50 Desiye kadar girilebilmektedir. 50'nin üzeri veya girmiş olduğunuz desi miktarının üzerine her +1 desi için eklenecek olan kargo ücreti.
    /// </summary>
    /// <value>Kargo firması için girmiş olduğunuz desi bilgileri 50 Desiye kadar girilebilmektedir. 50'nin üzeri veya girmiş olduğunuz desi miktarının üzerine her +1 desi için eklenecek olan kargo ücreti.</value>
    [DataMember(Name="extraVolumetricWeightPrice", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "extraVolumetricWeightPrice")]
    public float? ExtraVolumetricWeightPrice { get; set; }

    /// <summary>
    /// Alışveriş sepeti toplamı belirlediğiniz Ücretsiz kargo limitini geçtiğinde müşterileriniz ücretsiz kargo hizmetinden faydalanabilirler.(Örn: X Lira üzeri ücretsiz Kargo!)
    /// </summary>
    /// <value>Alışveriş sepeti toplamı belirlediğiniz Ücretsiz kargo limitini geçtiğinde müşterileriniz ücretsiz kargo hizmetinden faydalanabilirler.(Örn: X Lira üzeri ücretsiz Kargo!)</value>
    [DataMember(Name="freeShipmentOrderPrice", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "freeShipmentOrderPrice")]
    public float? FreeShipmentOrderPrice { get; set; }

    /// <summary>
    /// Ücretsiz kargo miktarı için maksimum ücretsiz desi miktarıdır. Alışveriş sırasındaki desi miktarı ücretsiz desi miktarından fazlaysa, + Desi miktarını sipariş sırasında sistem müşteriden tahsil eder.(Örn: X TL üzeri ücretsiz kargo! Fakat X desiye kadar)Üzeri müşteriden tahsil edilir.
    /// </summary>
    /// <value>Ücretsiz kargo miktarı için maksimum ücretsiz desi miktarıdır. Alışveriş sırasındaki desi miktarı ücretsiz desi miktarından fazlaysa, + Desi miktarını sipariş sırasında sistem müşteriden tahsil eder.(Örn: X TL üzeri ücretsiz kargo! Fakat X desiye kadar)Üzeri müşteriden tahsil edilir.</value>
    [DataMember(Name="freeShipmentVolumetricWeightLimit", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "freeShipmentVolumetricWeightLimit")]
    public float? FreeShipmentVolumetricWeightLimit { get; set; }

    /// <summary>
    /// Kargo firması nesnesi için sıralama değeri.
    /// </summary>
    /// <value>Kargo firması nesnesi için sıralama değeri.</value>
    [DataMember(Name="sortOrder", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "sortOrder")]
    public int? SortOrder { get; set; }

    /// <summary>
    /// API tarafından otomatik oluşturulan kargo firması kodu.
    /// </summary>
    /// <value>API tarafından otomatik oluşturulan kargo firması kodu.</value>
    [DataMember(Name="companyCode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "companyCode")]
    public string CompanyCode { get; set; }

    /// <summary>
    /// Kargo firması için ödeme tipi.<div class='idea_choice_list'><code>cash_on_delivery</code> : Alıcı ödemeli.<br><code>standart_delivery</code> : Gönderici ödemeli.<br><code>not_applicable</code> : Bu alan için uygulanabilir değil.<br></div>
    /// </summary>
    /// <value>Kargo firması için ödeme tipi.<div class='idea_choice_list'><code>cash_on_delivery</code> : Alıcı ödemeli.<br><code>standart_delivery</code> : Gönderici ödemeli.<br><code>not_applicable</code> : Bu alan için uygulanabilir değil.<br></div></value>
    [DataMember(Name="paymentType", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "paymentType")]
    public string PaymentType { get; set; }

    /// <summary>
    /// Gets or Sets ShippingProvider
    /// </summary>
    [DataMember(Name="shippingProvider", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "shippingProvider")]
    public ShippingProvider ShippingProvider { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class ShippingCompany {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Name: ").Append(Name).Append("\n");
      sb.Append("  Status: ").Append(Status).Append("\n");
      sb.Append("  ExtraPrice: ").Append(ExtraPrice).Append("\n");
      sb.Append("  ExtraVolumetricWeightPrice: ").Append(ExtraVolumetricWeightPrice).Append("\n");
      sb.Append("  FreeShipmentOrderPrice: ").Append(FreeShipmentOrderPrice).Append("\n");
      sb.Append("  FreeShipmentVolumetricWeightLimit: ").Append(FreeShipmentVolumetricWeightLimit).Append("\n");
      sb.Append("  SortOrder: ").Append(SortOrder).Append("\n");
      sb.Append("  CompanyCode: ").Append(CompanyCode).Append("\n");
      sb.Append("  PaymentType: ").Append(PaymentType).Append("\n");
      sb.Append("  ShippingProvider: ").Append(ShippingProvider).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
