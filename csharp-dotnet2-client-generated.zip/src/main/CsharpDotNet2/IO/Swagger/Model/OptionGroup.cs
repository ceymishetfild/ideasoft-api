using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class OptionGroup {
    /// <summary>
    /// Varyant grubu nesnesi kimlik değeri.
    /// </summary>
    /// <value>Varyant grubu nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Varyant grubunun başlığı. Varyant değeri kırmızı ise bu değer renk olabilir.
    /// </summary>
    /// <value>Varyant grubunun başlığı. Varyant değeri kırmızı ise bu değer renk olabilir.</value>
    [DataMember(Name="title", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "title")]
    public string Title { get; set; }

    /// <summary>
    /// Varyant grubunun sıralama değeri.
    /// </summary>
    /// <value>Varyant grubunun sıralama değeri.</value>
    [DataMember(Name="sortOrder", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "sortOrder")]
    public int? SortOrder { get; set; }

    /// <summary>
    /// Varyant grubunun filtre menüsündeki gösterim durumu.<div class='idea_choice_list'><code>1</code> : Gösterilsin.<br><code>0</code> : Gösterilmesin.<br></div>
    /// </summary>
    /// <value>Varyant grubunun filtre menüsündeki gösterim durumu.<div class='idea_choice_list'><code>1</code> : Gösterilsin.<br><code>0</code> : Gösterilmesin.<br></div></value>
    [DataMember(Name="filterStatus", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "filterStatus")]
    public string FilterStatus { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class OptionGroup {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Title: ").Append(Title).Append("\n");
      sb.Append("  SortOrder: ").Append(SortOrder).Append("\n");
      sb.Append("  FilterStatus: ").Append(FilterStatus).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
