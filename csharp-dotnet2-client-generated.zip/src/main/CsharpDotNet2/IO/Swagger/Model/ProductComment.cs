using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class ProductComment {
    /// <summary>
    /// Ürün yorumu nesnesi kimlik değeri.
    /// </summary>
    /// <value>Ürün yorumu nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Ürün yorumu başlığı.
    /// </summary>
    /// <value>Ürün yorumu başlığı.</value>
    [DataMember(Name="title", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "title")]
    public string Title { get; set; }

    /// <summary>
    /// Ürün yorumu içeriği.
    /// </summary>
    /// <value>Ürün yorumu içeriği.</value>
    [DataMember(Name="content", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "content")]
    public string Content { get; set; }

    /// <summary>
    /// Ürün yorumu durumu.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div>
    /// </summary>
    /// <value>Ürün yorumu durumu.<div class='idea_choice_list'><code>1</code> : Aktif.<br><code>0</code> : Pasif.<br></div></value>
    [DataMember(Name="status", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "status")]
    public bool? Status { get; set; }

    /// <summary>
    /// Ürün yorumunda ürüne verilen puan.<div class='idea_choice_list'><code>1</code> : 1 puan.<br><code>2</code> : 2 puan.<br><code>3</code> : 3 puan.<br><code>4</code> : 4 puan.<br><code>5</code> : 5 puan.<br></div>
    /// </summary>
    /// <value>Ürün yorumunda ürüne verilen puan.<div class='idea_choice_list'><code>1</code> : 1 puan.<br><code>2</code> : 2 puan.<br><code>3</code> : 3 puan.<br><code>4</code> : 4 puan.<br><code>5</code> : 5 puan.<br></div></value>
    [DataMember(Name="rank", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "rank")]
    public int? Rank { get; set; }

    /// <summary>
    /// Ürün yorumu yapan kişinin anonim olup olmadığı bilgisi.<div class='idea_choice_list'><code>1</code> : Anonim.<br><code>0</code> : Anonim değil.<br></div>
    /// </summary>
    /// <value>Ürün yorumu yapan kişinin anonim olup olmadığı bilgisi.<div class='idea_choice_list'><code>1</code> : Anonim.<br><code>0</code> : Anonim değil.<br></div></value>
    [DataMember(Name="isAnonymous", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "isAnonymous")]
    public bool? IsAnonymous { get; set; }

    /// <summary>
    /// Ürün yorumu nesnesinin oluşturulma zamanı.
    /// </summary>
    /// <value>Ürün yorumu nesnesinin oluşturulma zamanı.</value>
    [DataMember(Name="createdAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "createdAt")]
    public DateTime? CreatedAt { get; set; }

    /// <summary>
    /// Ürün yorumu nesnesinin güncellenme zamanı.
    /// </summary>
    /// <value>Ürün yorumu nesnesinin güncellenme zamanı.</value>
    [DataMember(Name="updatedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "updatedAt")]
    public DateTime? UpdatedAt { get; set; }

    /// <summary>
    /// Yorumu yapan üye.
    /// </summary>
    /// <value>Yorumu yapan üye.</value>
    [DataMember(Name="member", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "member")]
    public Member Member { get; set; }

    /// <summary>
    /// Yorum yapılan ürün.
    /// </summary>
    /// <value>Yorum yapılan ürün.</value>
    [DataMember(Name="product", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "product")]
    public Product Product { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class ProductComment {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Title: ").Append(Title).Append("\n");
      sb.Append("  Content: ").Append(Content).Append("\n");
      sb.Append("  Status: ").Append(Status).Append("\n");
      sb.Append("  Rank: ").Append(Rank).Append("\n");
      sb.Append("  IsAnonymous: ").Append(IsAnonymous).Append("\n");
      sb.Append("  CreatedAt: ").Append(CreatedAt).Append("\n");
      sb.Append("  UpdatedAt: ").Append(UpdatedAt).Append("\n");
      sb.Append("  Member: ").Append(Member).Append("\n");
      sb.Append("  Product: ").Append(Product).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
