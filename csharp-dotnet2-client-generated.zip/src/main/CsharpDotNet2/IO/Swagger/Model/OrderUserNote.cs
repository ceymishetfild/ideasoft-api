using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class OrderUserNote {
    /// <summary>
    /// Sipariş yönetici notu nesnesi kimlik değeri.
    /// </summary>
    /// <value>Sipariş yönetici notu nesnesi kimlik değeri.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public int? Id { get; set; }

    /// <summary>
    /// Yöneticinin(admin) e-mail adresi.
    /// </summary>
    /// <value>Yöneticinin(admin) e-mail adresi.</value>
    [DataMember(Name="userEmail", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "userEmail")]
    public string UserEmail { get; set; }

    /// <summary>
    /// Yöneticinin(admin) ismi.
    /// </summary>
    /// <value>Yöneticinin(admin) ismi.</value>
    [DataMember(Name="userFirstname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "userFirstname")]
    public string UserFirstname { get; set; }

    /// <summary>
    /// Yöneticinin(admin) soy ismi.
    /// </summary>
    /// <value>Yöneticinin(admin) soy ismi.</value>
    [DataMember(Name="userSurname", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "userSurname")]
    public string UserSurname { get; set; }

    /// <summary>
    /// Yöneticinin(admin) sipariş için girdiği not.
    /// </summary>
    /// <value>Yöneticinin(admin) sipariş için girdiği not.</value>
    [DataMember(Name="note", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "note")]
    public string Note { get; set; }

    /// <summary>
    /// Sipariş yönetici notu nesnesinin oluşturulma zamanı.
    /// </summary>
    /// <value>Sipariş yönetici notu nesnesinin oluşturulma zamanı.</value>
    [DataMember(Name="createdAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "createdAt")]
    public DateTime? CreatedAt { get; set; }

    /// <summary>
    /// Sipariş yönetici notu nesnesinin güncellenme zamanı.
    /// </summary>
    /// <value>Sipariş yönetici notu nesnesinin güncellenme zamanı.</value>
    [DataMember(Name="updatedAt", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "updatedAt")]
    public DateTime? UpdatedAt { get; set; }

    /// <summary>
    /// Sipariş nesnesi.
    /// </summary>
    /// <value>Sipariş nesnesi.</value>
    [DataMember(Name="order", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "order")]
    public Order Order { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class OrderUserNote {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  UserEmail: ").Append(UserEmail).Append("\n");
      sb.Append("  UserFirstname: ").Append(UserFirstname).Append("\n");
      sb.Append("  UserSurname: ").Append(UserSurname).Append("\n");
      sb.Append("  Note: ").Append(Note).Append("\n");
      sb.Append("  CreatedAt: ").Append(CreatedAt).Append("\n");
      sb.Append("  UpdatedAt: ").Append(UpdatedAt).Append("\n");
      sb.Append("  Order: ").Append(Order).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
