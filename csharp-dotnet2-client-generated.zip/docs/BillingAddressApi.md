# IO.Swagger.Api.BillingAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**BillingAddressesGet**](BillingAddressApi.md#billingaddressesget) | **GET** /billing_addresses | Fatura Adresi Listesi Alma
[**BillingAddressesIdGet**](BillingAddressApi.md#billingaddressesidget) | **GET** /billing_addresses/{id} | Fatura Adresi Alma
[**BillingAddressesIdPut**](BillingAddressApi.md#billingaddressesidput) | **PUT** /billing_addresses/{id} | Fatura Adresi Güncelleme
[**BillingAddressesPost**](BillingAddressApi.md#billingaddressespost) | **POST** /billing_addresses | Fatura Adresi Oluşturma


<a name="billingaddressesget"></a>
# **BillingAddressesGet**
> BillingAddress BillingAddressesGet (string sort, int? limit, int? page, int? sinceId, string ids, int? order, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)

Fatura Adresi Listesi Alma

Fatura Adresi listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BillingAddressesGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BillingAddressApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var order = 56;  // int? | Sipariş id (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 

            try
            {
                // Fatura Adresi Listesi Alma
                BillingAddress result = apiInstance.BillingAddressesGet(sort, limit, page, sinceId, ids, order, startDate, endDate, startUpdatedAt, endUpdatedAt);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BillingAddressApi.BillingAddressesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **order** | **int?**| Sipariş id | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="billingaddressesidget"></a>
# **BillingAddressesIdGet**
> BillingAddress BillingAddressesIdGet (int? id)

Fatura Adresi Alma

İlgili Fatura Adresini getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BillingAddressesIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BillingAddressApi();
            var id = 56;  // int? | Fatura Adresi nesnesinin id değeri

            try
            {
                // Fatura Adresi Alma
                BillingAddress result = apiInstance.BillingAddressesIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BillingAddressApi.BillingAddressesIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Fatura Adresi nesnesinin id değeri | 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="billingaddressesidput"></a>
# **BillingAddressesIdPut**
> BillingAddress BillingAddressesIdPut (int? id, BillingAddress billingAddress)

Fatura Adresi Güncelleme

İlgili Fatura Adresini günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BillingAddressesIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BillingAddressApi();
            var id = 56;  // int? | Fatura Adresi nesnesinin id değeri
            var billingAddress = new BillingAddress(); // BillingAddress |  nesnesi

            try
            {
                // Fatura Adresi Güncelleme
                BillingAddress result = apiInstance.BillingAddressesIdPut(id, billingAddress);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BillingAddressApi.BillingAddressesIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Fatura Adresi nesnesinin id değeri | 
 **billingAddress** | [**BillingAddress**](BillingAddress.md)|  nesnesi | 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="billingaddressespost"></a>
# **BillingAddressesPost**
> BillingAddress BillingAddressesPost (BillingAddress billingAddress)

Fatura Adresi Oluşturma

Yeni bir Fatura Adresi oluşturur. Fatura Adresi oluşturabilmek için geçerli bir önceden tanımlanmış Sipariş id değerine ihtiyaç vardır.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class BillingAddressesPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new BillingAddressApi();
            var billingAddress = new BillingAddress(); // BillingAddress |  nesnesi

            try
            {
                // Fatura Adresi Oluşturma
                BillingAddress result = apiInstance.BillingAddressesPost(billingAddress);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling BillingAddressApi.BillingAddressesPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **billingAddress** | [**BillingAddress**](BillingAddress.md)|  nesnesi | 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

