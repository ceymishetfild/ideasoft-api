# IO.Swagger.Model.ShippingProviderSetting
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Teslimat hizmeti sağlayıcısı ayarı nesnesi kimlik değeri. | [optional] 
**VarKey** | **string** | Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken anahtarı. | 
**VarValue** | **string** | Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken değeri. | 
**ShippingProvider** | [**ShippingProvider**](ShippingProvider.md) | Teslimat hizmeti sağlayıcısı nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

