# IO.Swagger.Api.SpecValueApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SpecValuesGet**](SpecValueApi.md#specvaluesget) | **GET** /spec_values | Ürün Özellik Değeri Listesi Alma
[**SpecValuesIdDelete**](SpecValueApi.md#specvaluesiddelete) | **DELETE** /spec_values/{id} | Ürün Özellik Değeri Silme
[**SpecValuesIdGet**](SpecValueApi.md#specvaluesidget) | **GET** /spec_values/{id} | Ürün Özellik Değeri Alma
[**SpecValuesIdPut**](SpecValueApi.md#specvaluesidput) | **PUT** /spec_values/{id} | Ürün Özellik Değeri Güncelleme
[**SpecValuesPost**](SpecValueApi.md#specvaluespost) | **POST** /spec_values | Ürün Özellik Değeri Oluşturma


<a name="specvaluesget"></a>
# **SpecValuesGet**
> SpecValue SpecValuesGet (string sort, int? limit, int? page, int? sinceId, string name, int? specName, int? specValue)

Ürün Özellik Değeri Listesi Alma

Ürün Özellik Değeri listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecValuesGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecValueApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var name = name_example;  // string | Ürün özellik adı (optional) 
            var specName = 56;  // int? | Ürün özellik id (optional) 
            var specValue = 56;  // int? | Ürün özellik değeri id (optional) 

            try
            {
                // Ürün Özellik Değeri Listesi Alma
                SpecValue result = apiInstance.SpecValuesGet(sort, limit, page, sinceId, name, specName, specValue);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecValueApi.SpecValuesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **string**| Ürün özellik adı | [optional] 
 **specName** | **int?**| Ürün özellik id | [optional] 
 **specValue** | **int?**| Ürün özellik değeri id | [optional] 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="specvaluesiddelete"></a>
# **SpecValuesIdDelete**
> void SpecValuesIdDelete (int? id)

Ürün Özellik Değeri Silme

Kalıcı olarak ilgili Ürün Özellik Değerini siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecValuesIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecValueApi();
            var id = 56;  // int? | Ürün Özellik Değeri nesnesinin id değeri

            try
            {
                // Ürün Özellik Değeri Silme
                apiInstance.SpecValuesIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecValueApi.SpecValuesIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Özellik Değeri nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="specvaluesidget"></a>
# **SpecValuesIdGet**
> SpecValue SpecValuesIdGet (int? id)

Ürün Özellik Değeri Alma

İlgili Ürün Özellik Değerini getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecValuesIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecValueApi();
            var id = 56;  // int? | Ürün Özellik Değeri nesnesinin id değeri

            try
            {
                // Ürün Özellik Değeri Alma
                SpecValue result = apiInstance.SpecValuesIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecValueApi.SpecValuesIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Özellik Değeri nesnesinin id değeri | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="specvaluesidput"></a>
# **SpecValuesIdPut**
> SpecValue SpecValuesIdPut (int? id, SpecValue specValue)

Ürün Özellik Değeri Güncelleme

İlgili Ürün Özellik Değerini günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecValuesIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecValueApi();
            var id = 56;  // int? | Ürün Özellik Değeri nesnesinin id değeri
            var specValue = new SpecValue(); // SpecValue | SpecValue nesnesi

            try
            {
                // Ürün Özellik Değeri Güncelleme
                SpecValue result = apiInstance.SpecValuesIdPut(id, specValue);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecValueApi.SpecValuesIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Özellik Değeri nesnesinin id değeri | 
 **specValue** | [**SpecValue**](SpecValue.md)| SpecValue nesnesi | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="specvaluespost"></a>
# **SpecValuesPost**
> SpecValue SpecValuesPost (SpecValue specValue)

Ürün Özellik Değeri Oluşturma

Yeni bir Ürün Özellik Değeri oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecValuesPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecValueApi();
            var specValue = new SpecValue(); // SpecValue | SpecValue nesnesi

            try
            {
                // Ürün Özellik Değeri Oluşturma
                SpecValue result = apiInstance.SpecValuesPost(specValue);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecValueApi.SpecValuesPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specValue** | [**SpecValue**](SpecValue.md)| SpecValue nesnesi | 

### Return type

[**SpecValue**](SpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

