# IO.Swagger.Api.TownGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**TownGroupsGet**](TownGroupApi.md#towngroupsget) | **GET** /town_groups | İlçe Grubu Listesi Alma
[**TownGroupsIdDelete**](TownGroupApi.md#towngroupsiddelete) | **DELETE** /town_groups/{id} | İlçe Grubu Silme
[**TownGroupsIdGet**](TownGroupApi.md#towngroupsidget) | **GET** /town_groups/{id} | İlçe Grubu Alma
[**TownGroupsIdPut**](TownGroupApi.md#towngroupsidput) | **PUT** /town_groups/{id} | İlçe Grubu Güncelleme
[**TownGroupsPost**](TownGroupApi.md#towngroupspost) | **POST** /town_groups | İlçe Grubu Oluşturma


<a name="towngroupsget"></a>
# **TownGroupsGet**
> TownGroup TownGroupsGet (string sort, int? limit, int? page, int? sinceId, string name)

İlçe Grubu Listesi Alma

İlçe Grubu listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TownGroupsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new TownGroupApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var name = name_example;  // string | İlçe Grubu adı (optional) 

            try
            {
                // İlçe Grubu Listesi Alma
                TownGroup result = apiInstance.TownGroupsGet(sort, limit, page, sinceId, name);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TownGroupApi.TownGroupsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **string**| İlçe Grubu adı | [optional] 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="towngroupsiddelete"></a>
# **TownGroupsIdDelete**
> void TownGroupsIdDelete (int? id)

İlçe Grubu Silme

Kalıcı olarak ilgili İlçe Grubunu siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TownGroupsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new TownGroupApi();
            var id = 56;  // int? | İlçe Grubu nesnesinin id değeri

            try
            {
                // İlçe Grubu Silme
                apiInstance.TownGroupsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TownGroupApi.TownGroupsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| İlçe Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="towngroupsidget"></a>
# **TownGroupsIdGet**
> TownGroup TownGroupsIdGet (int? id)

İlçe Grubu Alma

İlgili İlçe Grubunu getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TownGroupsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new TownGroupApi();
            var id = 56;  // int? | İlçe Grubu nesnesinin id değeri

            try
            {
                // İlçe Grubu Alma
                TownGroup result = apiInstance.TownGroupsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TownGroupApi.TownGroupsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| İlçe Grubu nesnesinin id değeri | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="towngroupsidput"></a>
# **TownGroupsIdPut**
> TownGroup TownGroupsIdPut (int? id, TownGroup townGroup)

İlçe Grubu Güncelleme

İlgili İlçe Grubunu günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TownGroupsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new TownGroupApi();
            var id = 56;  // int? | İlçe Grubu nesnesinin id değeri
            var townGroup = new TownGroup(); // TownGroup | TownGroup nesnesi

            try
            {
                // İlçe Grubu Güncelleme
                TownGroup result = apiInstance.TownGroupsIdPut(id, townGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TownGroupApi.TownGroupsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| İlçe Grubu nesnesinin id değeri | 
 **townGroup** | [**TownGroup**](TownGroup.md)| TownGroup nesnesi | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="towngroupspost"></a>
# **TownGroupsPost**
> TownGroup TownGroupsPost (TownGroup townGroup)

İlçe Grubu Oluşturma

Yeni bir İlçe Grubu oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TownGroupsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new TownGroupApi();
            var townGroup = new TownGroup(); // TownGroup | TownGroup nesnesi

            try
            {
                // İlçe Grubu Oluşturma
                TownGroup result = apiInstance.TownGroupsPost(townGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TownGroupApi.TownGroupsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **townGroup** | [**TownGroup**](TownGroup.md)| TownGroup nesnesi | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

