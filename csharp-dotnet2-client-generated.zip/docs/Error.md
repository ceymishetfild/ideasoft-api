# IO.Swagger.Model.Error
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Code** | **int?** | HTTP Hata kodu. | [optional] 
**ErrorMessage** | **string** | Hata mesajı. Hata mesajları İngilizce dilindedir. | [optional] 
**ErrorCode** | **int?** | Hata kodu. Eğer ek bir hata kodu varsa bu alanda belirtilir. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

