# IO.Swagger.Api.FavouritedProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**FavouritedProductsGet**](FavouritedProductApi.md#favouritedproductsget) | **GET** /favourited_products | Favori Ürün Listesi Alma
[**FavouritedProductsIdDelete**](FavouritedProductApi.md#favouritedproductsiddelete) | **DELETE** /favourited_products/{id} | Favori Ürün Silme
[**FavouritedProductsIdGet**](FavouritedProductApi.md#favouritedproductsidget) | **GET** /favourited_products/{id} | Favori Ürün Alma
[**FavouritedProductsIdPut**](FavouritedProductApi.md#favouritedproductsidput) | **PUT** /favourited_products/{id} | Favori Ürün Güncelleme
[**FavouritedProductsPost**](FavouritedProductApi.md#favouritedproductspost) | **POST** /favourited_products | Favori Ürün Oluşturma


<a name="favouritedproductsget"></a>
# **FavouritedProductsGet**
> FavouritedProduct FavouritedProductsGet (string sort, int? limit, int? page, int? sinceId, int? product)

Favori Ürün Listesi Alma

Favori Ürün listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FavouritedProductsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new FavouritedProductApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var product = 56;  // int? | Ürün id (optional) 

            try
            {
                // Favori Ürün Listesi Alma
                FavouritedProduct result = apiInstance.FavouritedProductsGet(sort, limit, page, sinceId, product);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling FavouritedProductApi.FavouritedProductsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **product** | **int?**| Ürün id | [optional] 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="favouritedproductsiddelete"></a>
# **FavouritedProductsIdDelete**
> void FavouritedProductsIdDelete (int? id)

Favori Ürün Silme

Kalıcı olarak ilgili Favori Ürünü siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FavouritedProductsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new FavouritedProductApi();
            var id = 56;  // int? | Favori Ürün nesnesinin id değeri

            try
            {
                // Favori Ürün Silme
                apiInstance.FavouritedProductsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling FavouritedProductApi.FavouritedProductsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Favori Ürün nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="favouritedproductsidget"></a>
# **FavouritedProductsIdGet**
> FavouritedProduct FavouritedProductsIdGet (int? id)

Favori Ürün Alma

İlgili Favori Ürünü getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FavouritedProductsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new FavouritedProductApi();
            var id = 56;  // int? | Favori Ürün nesnesinin id değeri

            try
            {
                // Favori Ürün Alma
                FavouritedProduct result = apiInstance.FavouritedProductsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling FavouritedProductApi.FavouritedProductsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Favori Ürün nesnesinin id değeri | 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="favouritedproductsidput"></a>
# **FavouritedProductsIdPut**
> FavouritedProduct FavouritedProductsIdPut (int? id, FavouritedProduct favouritedProduct)

Favori Ürün Güncelleme

İlgili Favori Ürünü günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FavouritedProductsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new FavouritedProductApi();
            var id = 56;  // int? | Favori Ürün nesnesinin id değeri
            var favouritedProduct = new FavouritedProduct(); // FavouritedProduct | FavouritedProduct nesnesi

            try
            {
                // Favori Ürün Güncelleme
                FavouritedProduct result = apiInstance.FavouritedProductsIdPut(id, favouritedProduct);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling FavouritedProductApi.FavouritedProductsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Favori Ürün nesnesinin id değeri | 
 **favouritedProduct** | [**FavouritedProduct**](FavouritedProduct.md)| FavouritedProduct nesnesi | 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="favouritedproductspost"></a>
# **FavouritedProductsPost**
> FavouritedProduct FavouritedProductsPost (FavouritedProduct favouritedProduct)

Favori Ürün Oluşturma

Yeni bir Favori Ürün oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FavouritedProductsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new FavouritedProductApi();
            var favouritedProduct = new FavouritedProduct(); // FavouritedProduct | FavouritedProduct nesnesi

            try
            {
                // Favori Ürün Oluşturma
                FavouritedProduct result = apiInstance.FavouritedProductsPost(favouritedProduct);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling FavouritedProductApi.FavouritedProductsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **favouritedProduct** | [**FavouritedProduct**](FavouritedProduct.md)| FavouritedProduct nesnesi | 

### Return type

[**FavouritedProduct**](FavouritedProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

