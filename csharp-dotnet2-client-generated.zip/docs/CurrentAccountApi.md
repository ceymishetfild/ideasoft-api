# IO.Swagger.Api.CurrentAccountApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CurrentAccountsGet**](CurrentAccountApi.md#currentaccountsget) | **GET** /current_accounts | Cari Hesap Listesi Alma
[**CurrentAccountsIdDelete**](CurrentAccountApi.md#currentaccountsiddelete) | **DELETE** /current_accounts/{id} | Cari Hesap Silme
[**CurrentAccountsIdGet**](CurrentAccountApi.md#currentaccountsidget) | **GET** /current_accounts/{id} | Cari Hesap Alma
[**CurrentAccountsIdPut**](CurrentAccountApi.md#currentaccountsidput) | **PUT** /current_accounts/{id} | Cari Hesap Güncelleme
[**CurrentAccountsPost**](CurrentAccountApi.md#currentaccountspost) | **POST** /current_accounts | Cari Hesap Oluşturma


<a name="currentaccountsget"></a>
# **CurrentAccountsGet**
> CurrentAccount CurrentAccountsGet (string sort, int? limit, int? page, int? sinceId, string code, string title, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt, string member)

Cari Hesap Listesi Alma

Cari Hesap listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CurrentAccountsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CurrentAccountApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var code = code_example;  // string | Cari Hesap kodu (optional) 
            var title = title_example;  // string | Cari Hesap başlığı (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 
            var member = member_example;  // string | İlgili üye (optional) 

            try
            {
                // Cari Hesap Listesi Alma
                CurrentAccount result = apiInstance.CurrentAccountsGet(sort, limit, page, sinceId, code, title, startDate, endDate, startUpdatedAt, endUpdatedAt, member);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CurrentAccountApi.CurrentAccountsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **code** | **string**| Cari Hesap kodu | [optional] 
 **title** | **string**| Cari Hesap başlığı | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 
 **member** | **string**| İlgili üye | [optional] 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="currentaccountsiddelete"></a>
# **CurrentAccountsIdDelete**
> void CurrentAccountsIdDelete (int? id)

Cari Hesap Silme

Kalıcı olarak ilgili Cari Hesabı siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CurrentAccountsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CurrentAccountApi();
            var id = 56;  // int? | Cari Hesap nesnesinin id değeri

            try
            {
                // Cari Hesap Silme
                apiInstance.CurrentAccountsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CurrentAccountApi.CurrentAccountsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Cari Hesap nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="currentaccountsidget"></a>
# **CurrentAccountsIdGet**
> CurrentAccount CurrentAccountsIdGet (int? id)

Cari Hesap Alma

İlgili Cari Hesabı getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CurrentAccountsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CurrentAccountApi();
            var id = 56;  // int? | Cari Hesap nesnesinin id değeri

            try
            {
                // Cari Hesap Alma
                CurrentAccount result = apiInstance.CurrentAccountsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CurrentAccountApi.CurrentAccountsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Cari Hesap nesnesinin id değeri | 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="currentaccountsidput"></a>
# **CurrentAccountsIdPut**
> CurrentAccount CurrentAccountsIdPut (int? id, CurrentAccount currentAccount)

Cari Hesap Güncelleme

İlgili Cari Hesabı günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CurrentAccountsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CurrentAccountApi();
            var id = 56;  // int? | Cari Hesap nesnesinin id değeri
            var currentAccount = new CurrentAccount(); // CurrentAccount | CurrentAccount nesnesi

            try
            {
                // Cari Hesap Güncelleme
                CurrentAccount result = apiInstance.CurrentAccountsIdPut(id, currentAccount);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CurrentAccountApi.CurrentAccountsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Cari Hesap nesnesinin id değeri | 
 **currentAccount** | [**CurrentAccount**](CurrentAccount.md)| CurrentAccount nesnesi | 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="currentaccountspost"></a>
# **CurrentAccountsPost**
> CurrentAccount CurrentAccountsPost (CurrentAccount currentAccount)

Cari Hesap Oluşturma

Yeni bir Cari Hesap oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CurrentAccountsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CurrentAccountApi();
            var currentAccount = new CurrentAccount(); // CurrentAccount | CurrentAccount nesnesi

            try
            {
                // Cari Hesap Oluşturma
                CurrentAccount result = apiInstance.CurrentAccountsPost(currentAccount);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CurrentAccountApi.CurrentAccountsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **currentAccount** | [**CurrentAccount**](CurrentAccount.md)| CurrentAccount nesnesi | 

### Return type

[**CurrentAccount**](CurrentAccount.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

