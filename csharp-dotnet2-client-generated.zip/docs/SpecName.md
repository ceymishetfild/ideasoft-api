# IO.Swagger.Model.SpecName
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ürün özelliği nesnesi kimlik değeri. | [optional] 
**Name** | **string** | Ürün özelliği nesnesi için isim değeri. | 
**ChoiceType** | **string** | Özellik tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul&lt;br&gt;&lt;/div&gt; | 
**SortOrder** | **int?** | Ürün özelliği sıralama değeri. | [optional] 
**Status** | **string** | Ürün özelliği aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**SpecGroup** | [**SpecGroup**](SpecGroup.md) | specGroup | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

