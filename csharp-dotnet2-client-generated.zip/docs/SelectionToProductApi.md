# IO.Swagger.Api.SelectionToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SelectionToProductsGet**](SelectionToProductApi.md#selectiontoproductsget) | **GET** /selection_to_products | Ek Özellik Ürün Bağı Listesi Alma
[**SelectionToProductsIdDelete**](SelectionToProductApi.md#selectiontoproductsiddelete) | **DELETE** /selection_to_products/{id} | Ek Özellik Ürün Bağı Silme
[**SelectionToProductsIdGet**](SelectionToProductApi.md#selectiontoproductsidget) | **GET** /selection_to_products/{id} | Ek Özellik Ürün Bağı Alma
[**SelectionToProductsIdPut**](SelectionToProductApi.md#selectiontoproductsidput) | **PUT** /selection_to_products/{id} | Ek Özellik Ürün Bağı Güncelleme
[**SelectionToProductsPost**](SelectionToProductApi.md#selectiontoproductspost) | **POST** /selection_to_products | Ek Özellik Ürün Bağı Oluşturma


<a name="selectiontoproductsget"></a>
# **SelectionToProductsGet**
> SelectionToProduct SelectionToProductsGet (string sort, int? limit, int? page, int? sinceId, string ids, int? selection, int? product)

Ek Özellik Ürün Bağı Listesi Alma

Ek Özellik Ürün Bağı listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SelectionToProductsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SelectionToProductApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var selection = 56;  // int? | Ek Özellik id (optional) 
            var product = 56;  // int? | Ürün id (optional) 

            try
            {
                // Ek Özellik Ürün Bağı Listesi Alma
                SelectionToProduct result = apiInstance.SelectionToProductsGet(sort, limit, page, sinceId, ids, selection, product);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SelectionToProductApi.SelectionToProductsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **selection** | **int?**| Ek Özellik id | [optional] 
 **product** | **int?**| Ürün id | [optional] 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="selectiontoproductsiddelete"></a>
# **SelectionToProductsIdDelete**
> void SelectionToProductsIdDelete (int? id)

Ek Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ek Özellik Ürün Bağını siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SelectionToProductsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SelectionToProductApi();
            var id = 56;  // int? | Ek Özellik Ürün Bağı nesnesinin id değeri

            try
            {
                // Ek Özellik Ürün Bağı Silme
                apiInstance.SelectionToProductsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SelectionToProductApi.SelectionToProductsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ek Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="selectiontoproductsidget"></a>
# **SelectionToProductsIdGet**
> SelectionToProduct SelectionToProductsIdGet (int? id)

Ek Özellik Ürün Bağı Alma

İlgili Ek Özellik Ürün Bağını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SelectionToProductsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SelectionToProductApi();
            var id = 56;  // int? | Ek Özellik Ürün Bağı nesnesinin id değeri

            try
            {
                // Ek Özellik Ürün Bağı Alma
                SelectionToProduct result = apiInstance.SelectionToProductsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SelectionToProductApi.SelectionToProductsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ek Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="selectiontoproductsidput"></a>
# **SelectionToProductsIdPut**
> SelectionToProduct SelectionToProductsIdPut (int? id, SelectionToProduct selectionToProduct)

Ek Özellik Ürün Bağı Güncelleme

İlgili Ek Özellik Ürün Bağını günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SelectionToProductsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SelectionToProductApi();
            var id = 56;  // int? | Ek Özellik Ürün Bağı nesnesinin id değeri
            var selectionToProduct = new SelectionToProduct(); // SelectionToProduct |  nesnesi

            try
            {
                // Ek Özellik Ürün Bağı Güncelleme
                SelectionToProduct result = apiInstance.SelectionToProductsIdPut(id, selectionToProduct);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SelectionToProductApi.SelectionToProductsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ek Özellik Ürün Bağı nesnesinin id değeri | 
 **selectionToProduct** | [**SelectionToProduct**](SelectionToProduct.md)|  nesnesi | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="selectiontoproductspost"></a>
# **SelectionToProductsPost**
> SelectionToProduct SelectionToProductsPost (SelectionToProduct selectionToProduct)

Ek Özellik Ürün Bağı Oluşturma

Yeni bir Ek Özellik Ürün Bağı oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SelectionToProductsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SelectionToProductApi();
            var selectionToProduct = new SelectionToProduct(); // SelectionToProduct |  nesnesi

            try
            {
                // Ek Özellik Ürün Bağı Oluşturma
                SelectionToProduct result = apiInstance.SelectionToProductsPost(selectionToProduct);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SelectionToProductApi.SelectionToProductsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selectionToProduct** | [**SelectionToProduct**](SelectionToProduct.md)|  nesnesi | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

