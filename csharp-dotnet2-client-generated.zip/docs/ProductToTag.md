# IO.Swagger.Model.ProductToTag
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ürün SEO+ etiketi bağı nesnesi kimlik değeri. | [optional] 
**Product** | [**Product**](Product.md) | Ürün nesnesi. | 
**Tag** | [**Tag**](Tag.md) | SEO+ etiketi nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

