# IO.Swagger.Api.ProductPriceApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductPricesGet**](ProductPriceApi.md#productpricesget) | **GET** /product_prices | Ürün Fiyat Listesi Alma
[**ProductPricesIdDelete**](ProductPriceApi.md#productpricesiddelete) | **DELETE** /product_prices/{id} | Ürün Fiyat Silme
[**ProductPricesIdGet**](ProductPriceApi.md#productpricesidget) | **GET** /product_prices/{id} | Ürün Fiyat Alma
[**ProductPricesIdPut**](ProductPriceApi.md#productpricesidput) | **PUT** /product_prices/{id} | Ürün Fiyat Güncelleme
[**ProductPricesPost**](ProductPriceApi.md#productpricespost) | **POST** /product_prices | Ürün Fiyat Oluşturma


<a name="productpricesget"></a>
# **ProductPricesGet**
> ProductPrice ProductPricesGet (string sort, int? limit, int? page, int? sinceId, int? type, int? product)

Ürün Fiyat Listesi Alma

Ürün Fiyat listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductPricesGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductPriceApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var type = 56;  // int? | Ürün fiyat tipi (optional) 
            var product = 56;  // int? | Ürün id (optional) 

            try
            {
                // Ürün Fiyat Listesi Alma
                ProductPrice result = apiInstance.ProductPricesGet(sort, limit, page, sinceId, type, product);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductPriceApi.ProductPricesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **type** | **int?**| Ürün fiyat tipi | [optional] 
 **product** | **int?**| Ürün id | [optional] 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productpricesiddelete"></a>
# **ProductPricesIdDelete**
> void ProductPricesIdDelete (int? id)

Ürün Fiyat Silme

Kalıcı olarak ilgili Ürün Fiyatını siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductPricesIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductPriceApi();
            var id = 56;  // int? | Ürün Fiyat nesnesinin id değeri

            try
            {
                // Ürün Fiyat Silme
                apiInstance.ProductPricesIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductPriceApi.ProductPricesIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Fiyat nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productpricesidget"></a>
# **ProductPricesIdGet**
> ProductPrice ProductPricesIdGet (int? id)

Ürün Fiyat Alma

İlgili Ürün Fiyatını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductPricesIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductPriceApi();
            var id = 56;  // int? | Ürün Fiyat nesnesinin id değeri

            try
            {
                // Ürün Fiyat Alma
                ProductPrice result = apiInstance.ProductPricesIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductPriceApi.ProductPricesIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Fiyat nesnesinin id değeri | 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productpricesidput"></a>
# **ProductPricesIdPut**
> ProductPrice ProductPricesIdPut (int? id, ProductPrice productPrice)

Ürün Fiyat Güncelleme

İlgili Ürün Fiyatını günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductPricesIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductPriceApi();
            var id = 56;  // int? | Ürün Fiyat nesnesinin id değeri
            var productPrice = new ProductPrice(); // ProductPrice | ProductPrice nesnesi

            try
            {
                // Ürün Fiyat Güncelleme
                ProductPrice result = apiInstance.ProductPricesIdPut(id, productPrice);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductPriceApi.ProductPricesIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Fiyat nesnesinin id değeri | 
 **productPrice** | [**ProductPrice**](ProductPrice.md)| ProductPrice nesnesi | 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productpricespost"></a>
# **ProductPricesPost**
> ProductPrice ProductPricesPost (ProductPrice productPrice)

Ürün Fiyat Oluşturma

Yeni bir Ürün Fiyat oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductPricesPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductPriceApi();
            var productPrice = new ProductPrice(); // ProductPrice | ProductPrice nesnesi

            try
            {
                // Ürün Fiyat Oluşturma
                ProductPrice result = apiInstance.ProductPricesPost(productPrice);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductPriceApi.ProductPricesPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productPrice** | [**ProductPrice**](ProductPrice.md)| ProductPrice nesnesi | 

### Return type

[**ProductPrice**](ProductPrice.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

