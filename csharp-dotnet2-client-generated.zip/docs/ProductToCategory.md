# IO.Swagger.Model.ProductToCategory
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ürün kategori bağı nesnesi kimlik değeri. | [optional] 
**SortOrder** | **int?** | Ürün kategori bağının sıralama değeri. Özel sıra belirtmek istemiyorsanız 9999 olarak iletebilirsiniz. | [optional] 
**Product** | [**Product**](Product.md) |  | [optional] 
**Category** | [**Category**](Category.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

