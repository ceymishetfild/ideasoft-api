# IO.Swagger.Model.ShopPreference
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Tanımlama nesnesi kimlik değeri. | [optional] 
**VarKey** | **string** | Tanımlama nesnesi için değişken anahtarı. | [optional] 
**VarValue** | **string** | Tanımlama nesnesi için değişken değeri. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

