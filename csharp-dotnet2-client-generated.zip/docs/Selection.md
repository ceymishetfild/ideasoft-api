# IO.Swagger.Model.Selection
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ek özellik nesnesi kimlik değeri. | [optional] 
**Title** | **string** | Ek özellik nesnesinin başlığı. | [optional] 
**SortOrder** | **int?** | Ek özellik nesnesi için sıralama değeri. | 
**SelectionGroup** | [**SelectionGroup**](SelectionGroup.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

