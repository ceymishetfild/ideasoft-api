# IO.Swagger.Model.FavouritedProduct
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Favori ürün nesnesi kimlik değeri. | [optional] 
**Member** | [**Member**](Member.md) | Üye nesnesi. | 
**Product** | [**Product**](Product.md) | Ürün nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

