# IO.Swagger.Model.Category
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Kategori nesnesi kimlik değeri. | [optional] 
**Name** | **string** | Kategori nesnesi için isim değeri. | 
**Slug** | **string** | Slug değeri ilgili nesnenin Url değeridir. | [optional] 
**SortOrder** | **int?** | Kategori nesnesi için sıralama değeri. | [optional] 
**Status** | **string** | Kategori nesnesinin aktiflik durumunu belirten değer. | 
**Percent** | **float?** | Kategori nesnesinin fiyat katsayısı. | [optional] 
**ImageFile** | **string** | Kategori nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF | [optional] 
**Distributor** | **string** | Her zaman null değer alır. Pratikte kullanımı yoktur. | [optional] 
**DisplayShowcaseContent** | **int?** | Kategori nesnesinin üst içerik metninin gösterim durumu. | [optional] 
**ShowcaseContent** | **string** | Kategori nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir. | [optional] 
**ShowcaseContentDisplayType** | **int?** | Kategori nesnesinin üst içerik metninin gösterim tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kategori içeriği.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Kategori ve üst kategori içeriği.&lt;br&gt;&lt;code&gt;3&lt;/code&gt; : Kategori ve tüm üst kategoriler.&lt;br&gt;&lt;/div&gt; | 
**HasChildren** | **string** | Kategori nesnesinin alt kategori barındırma durumu. Bu değer otomatik oluşturulur. | [optional] 
**MetaKeywords** | **string** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] 
**MetaDescription** | **string** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] 
**PageTitle** | **string** | Kategori nesnesinin etiket başlığı. | [optional] 
**Parent** | [**Category**](Category.md) | Üst kategori olan kategori nesnesi. | [optional] 
**Attachment** | **string** | Kategori nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. | [optional] 
**CreatedAt** | **DateTime?** | Kategori nesnesinin oluşturulma zamanı. | [optional] 
**UpdatedAt** | **DateTime?** | Kategori nesnesinin güncellenme zamanı. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

