# IO.Swagger.Model.SpecToProduct
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ürün özellik ürün bağı nesnesi kimlik değeri. | [optional] 
**Product** | [**Product**](Product.md) | Ürün nesnesi. | [optional] 
**SpecGroup** | [**SpecGroup**](SpecGroup.md) | Ürün özelliği grubu nesnesi. | 
**SpecName** | [**SpecName**](SpecName.md) | Ürün özelliği nesnesi. | 
**SpecValue** | [**SpecValue**](SpecValue.md) | Ürün özellik grubu nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

