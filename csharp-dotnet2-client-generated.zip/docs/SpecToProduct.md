# IO.Swagger.Model.SpecToProduct
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ürün özellik ürün bağı nesnesi kimlik değeri. | [optional] 
**Product** | [**Product**](Product.md) |  | [optional] 
**SpecGroup** | [**SpecGroup**](SpecGroup.md) |  | [optional] 
**SpecName** | [**SpecName**](SpecName.md) |  | [optional] 
**SpecValue** | [**SpecValue**](SpecValue.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

