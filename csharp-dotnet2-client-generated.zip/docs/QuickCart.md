# IO.Swagger.Model.QuickCart
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Hızlı satın al bağlantısı nesnesi kimlik değeri. | [optional] 
**Name** | **string** | Hızlı satın al bağlantısı nesnesi için isim değeri. | 
**Url** | **string** | Hızlı satın al bağlantısı url&#39;si. | 
**ShortUrl** | **string** | Hızlı satın al bağlantısı için kısaltılmış url. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

