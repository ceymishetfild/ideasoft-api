# IO.Swagger.Api.OrderApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**OrdersGet**](OrderApi.md#ordersget) | **GET** /orders | Sipariş Listesi Alma
[**OrdersIdDelete**](OrderApi.md#ordersiddelete) | **DELETE** /orders/{id} | Sipariş Silme
[**OrdersIdGet**](OrderApi.md#ordersidget) | **GET** /orders/{id} | Sipariş Alma
[**OrdersIdPut**](OrderApi.md#ordersidput) | **PUT** /orders/{id} | Sipariş Güncelleme
[**OrdersPost**](OrderApi.md#orderspost) | **POST** /orders | Sipariş Oluşturma


<a name="ordersget"></a>
# **OrdersGet**
> Order OrdersGet (string sort, int? limit, int? page, int? sinceId, string transactionId, string customerEmail, int? member, string status, string paymentStatus, string paymentTypeName, string shippingProviderCode, List<string> q, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)

Sipariş Listesi Alma

Sipariş listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrdersGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var transactionId = transactionId_example;  // string | İşlem id. (optional) 
            var customerEmail = customerEmail_example;  // string | Müşteri e-mail. (optional) 
            var member = 56;  // int? | Üye id (optional) 
            var status = status_example;  // string | Status şu değerleri alabilir: <br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br><code>deleted</code> : Silindi (optional) 
            var paymentStatus = paymentStatus_example;  // string | Ödeme durumu şu değerleri alabilir: <br><code>success</code> : Başarılı<br><code>in_transaction</code> : Sonuçlanmamış Ödemeler<br><code>failed</code> : Hatalı Ödemeler (optional) 
            var paymentTypeName = paymentTypeName_example;  // string | Ödeme tipi şu değerleri alabilir: <br><code>Havale</code><br><code>Özel Ödeme Sistemi</code><br><code>Kredi Kartı</code><br><code>Paypal</code><br><code>GarantiPay</code><br><code>Mail Order</code><br><code>BKM Express</code><br><code>Kapıda Ödeme Nakit</code><br><code>Kapıda Ödeme Kredi Kartı</code> (optional) 
            var shippingProviderCode = shippingProviderCode_example;  // string | Teslimat hizmeti sağlayıcıları kodu şu değerleri alabilir: <br><code>yurtici</code> : Yurtiçi Kargo<br><code>yurtici_self_service</code> : Yurtiçi Kargo (Self Service)<br><code>yurtici_api</code> : Yurtiçi Kargo (API)<br><code>ptt</code> : PTT Kargo<br><code>mng</code> : MNG Kargo<br><code>surat</code> : Sürat Kargo<br><code>ups</code> : UPS<br><code>aras</code> : Aras Kargo<br><code>other</code> : Diğer (optional) 
            var q = new List<string>(); // List<string> | Sipariş arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;] (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 

            try
            {
                // Sipariş Listesi Alma
                Order result = apiInstance.OrdersGet(sort, limit, page, sinceId, transactionId, customerEmail, member, status, paymentStatus, paymentTypeName, shippingProviderCode, q, startDate, endDate, startUpdatedAt, endUpdatedAt);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderApi.OrdersGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **transactionId** | **string**| İşlem id. | [optional] 
 **customerEmail** | **string**| Müşteri e-mail. | [optional] 
 **member** | **int?**| Üye id | [optional] 
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi | [optional] 
 **paymentStatus** | **string**| Ödeme durumu şu değerleri alabilir: &lt;br&gt;&lt;code&gt;success&lt;/code&gt; : Başarılı&lt;br&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler | [optional] 
 **paymentTypeName** | **string**| Ödeme tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;Havale&lt;/code&gt;&lt;br&gt;&lt;code&gt;Özel Ödeme Sistemi&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kredi Kartı&lt;/code&gt;&lt;br&gt;&lt;code&gt;Paypal&lt;/code&gt;&lt;br&gt;&lt;code&gt;GarantiPay&lt;/code&gt;&lt;br&gt;&lt;code&gt;Mail Order&lt;/code&gt;&lt;br&gt;&lt;code&gt;BKM Express&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kapıda Ödeme Nakit&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kapıda Ödeme Kredi Kartı&lt;/code&gt; | [optional] 
 **shippingProviderCode** | **string**| Teslimat hizmeti sağlayıcıları kodu şu değerleri alabilir: &lt;br&gt;&lt;code&gt;yurtici&lt;/code&gt; : Yurtiçi Kargo&lt;br&gt;&lt;code&gt;yurtici_self_service&lt;/code&gt; : Yurtiçi Kargo (Self Service)&lt;br&gt;&lt;code&gt;yurtici_api&lt;/code&gt; : Yurtiçi Kargo (API)&lt;br&gt;&lt;code&gt;ptt&lt;/code&gt; : PTT Kargo&lt;br&gt;&lt;code&gt;mng&lt;/code&gt; : MNG Kargo&lt;br&gt;&lt;code&gt;surat&lt;/code&gt; : Sürat Kargo&lt;br&gt;&lt;code&gt;ups&lt;/code&gt; : UPS&lt;br&gt;&lt;code&gt;aras&lt;/code&gt; : Aras Kargo&lt;br&gt;&lt;code&gt;other&lt;/code&gt; : Diğer | [optional] 
 **q** | [**List<string>**](string.md)| Sipariş arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="ordersiddelete"></a>
# **OrdersIdDelete**
> void OrdersIdDelete (int? id)

Sipariş Silme

Kalıcı olarak ilgili Siparişi siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrdersIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderApi();
            var id = 56;  // int? | Sipariş nesnesinin id değeri

            try
            {
                // Sipariş Silme
                apiInstance.OrdersIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderApi.OrdersIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="ordersidget"></a>
# **OrdersIdGet**
> Order OrdersIdGet (int? id)

Sipariş Alma

İlgili Siparişi getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrdersIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderApi();
            var id = 56;  // int? | Sipariş nesnesinin id değeri

            try
            {
                // Sipariş Alma
                Order result = apiInstance.OrdersIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderApi.OrdersIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş nesnesinin id değeri | 

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="ordersidput"></a>
# **OrdersIdPut**
> Order OrdersIdPut (int? id, Order order)

Sipariş Güncelleme

İlgili Siparişi günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrdersIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderApi();
            var id = 56;  // int? | Sipariş nesnesinin id değeri
            var order = new Order(); // Order | Order nesnesi

            try
            {
                // Sipariş Güncelleme
                Order result = apiInstance.OrdersIdPut(id, order);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderApi.OrdersIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş nesnesinin id değeri | 
 **order** | [**Order**](Order.md)| Order nesnesi | 

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderspost"></a>
# **OrdersPost**
> Order OrdersPost (Order order)

Sipariş Oluşturma

Yeni bir Sipariş oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrdersPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderApi();
            var order = new Order(); // Order | Order nesnesi

            try
            {
                // Sipariş Oluşturma
                Order result = apiInstance.OrdersPost(order);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderApi.OrdersPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order** | [**Order**](Order.md)| Order nesnesi | 

### Return type

[**Order**](Order.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

