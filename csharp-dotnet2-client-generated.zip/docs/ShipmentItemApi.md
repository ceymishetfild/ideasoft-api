# IO.Swagger.Api.ShipmentItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ShipmentItemsGet**](ShipmentItemApi.md#shipmentitemsget) | **GET** /shipment_items | Teslimat Kalemi Listesi Alma
[**ShipmentItemsIdDelete**](ShipmentItemApi.md#shipmentitemsiddelete) | **DELETE** /shipment_items/{id} | Teslimat Kalemi Silme
[**ShipmentItemsIdGet**](ShipmentItemApi.md#shipmentitemsidget) | **GET** /shipment_items/{id} | Teslimat Kalemi Alma
[**ShipmentItemsIdPut**](ShipmentItemApi.md#shipmentitemsidput) | **PUT** /shipment_items/{id} | Teslimat Kalemi Güncelleme
[**ShipmentItemsPost**](ShipmentItemApi.md#shipmentitemspost) | **POST** /shipment_items | Teslimat Kalemi Oluşturma


<a name="shipmentitemsget"></a>
# **ShipmentItemsGet**
> ShipmentItem ShipmentItemsGet (string sort, int? limit, int? page, int? sinceId, int? product, int? shipment, int? orderItem, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)

Teslimat Kalemi Listesi Alma

Teslimat Kalemi listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShipmentItemsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShipmentItemApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var product = 56;  // int? | Ürün id (optional) 
            var shipment = 56;  // int? | Teslimat id (optional) 
            var orderItem = 56;  // int? | Sipariş kalemi id (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 

            try
            {
                // Teslimat Kalemi Listesi Alma
                ShipmentItem result = apiInstance.ShipmentItemsGet(sort, limit, page, sinceId, product, shipment, orderItem, startDate, endDate, startUpdatedAt, endUpdatedAt);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShipmentItemApi.ShipmentItemsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **product** | **int?**| Ürün id | [optional] 
 **shipment** | **int?**| Teslimat id | [optional] 
 **orderItem** | **int?**| Sipariş kalemi id | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shipmentitemsiddelete"></a>
# **ShipmentItemsIdDelete**
> void ShipmentItemsIdDelete (int? id)

Teslimat Kalemi Silme

Kalıcı olarak ilgili Teslimat Kalemini siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShipmentItemsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShipmentItemApi();
            var id = 56;  // int? | Teslimat Kalemi nesnesinin id değeri

            try
            {
                // Teslimat Kalemi Silme
                apiInstance.ShipmentItemsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShipmentItemApi.ShipmentItemsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Teslimat Kalemi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shipmentitemsidget"></a>
# **ShipmentItemsIdGet**
> ShipmentItem ShipmentItemsIdGet (int? id)

Teslimat Kalemi Alma

İlgili Teslimat Kalemini getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShipmentItemsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShipmentItemApi();
            var id = 56;  // int? | Teslimat Kalemi nesnesinin id değeri

            try
            {
                // Teslimat Kalemi Alma
                ShipmentItem result = apiInstance.ShipmentItemsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShipmentItemApi.ShipmentItemsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Teslimat Kalemi nesnesinin id değeri | 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shipmentitemsidput"></a>
# **ShipmentItemsIdPut**
> ShipmentItem ShipmentItemsIdPut (int? id, ShipmentItem shipmentItem)

Teslimat Kalemi Güncelleme

İlgili Teslimat Kalemini günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShipmentItemsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShipmentItemApi();
            var id = 56;  // int? | Teslimat Kalemi nesnesinin id değeri
            var shipmentItem = new ShipmentItem(); // ShipmentItem | ShipmentItem nesnesi

            try
            {
                // Teslimat Kalemi Güncelleme
                ShipmentItem result = apiInstance.ShipmentItemsIdPut(id, shipmentItem);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShipmentItemApi.ShipmentItemsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Teslimat Kalemi nesnesinin id değeri | 
 **shipmentItem** | [**ShipmentItem**](ShipmentItem.md)| ShipmentItem nesnesi | 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shipmentitemspost"></a>
# **ShipmentItemsPost**
> ShipmentItem ShipmentItemsPost (ShipmentItem shipmentItem)

Teslimat Kalemi Oluşturma

Yeni bir Teslimat Kalemi oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShipmentItemsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShipmentItemApi();
            var shipmentItem = new ShipmentItem(); // ShipmentItem | ShipmentItem nesnesi

            try
            {
                // Teslimat Kalemi Oluşturma
                ShipmentItem result = apiInstance.ShipmentItemsPost(shipmentItem);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShipmentItemApi.ShipmentItemsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipmentItem** | [**ShipmentItem**](ShipmentItem.md)| ShipmentItem nesnesi | 

### Return type

[**ShipmentItem**](ShipmentItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

