# IO.Swagger.Model.CartItemAttribute
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Sepet kalemi özelliği nesnesi kimlik değeri. | [optional] 
**Name** | **string** | Sepet kalemi özelliği nesnesinin isim değeri. Örneğin, sepet kalemi kalem ise bu değer renk olabilir. | [optional] 
**Value** | **string** | Sepet kalemi özelliği nesnesinin değeri. Örneğin, sepet kalemi kalem, isim değeri renk ise bu değer kırmızı olabilir. | [optional] 
**CreatedAt** | **DateTime?** | Sepet kalemi özelliği nesnesinin oluşturulma zamanı. | [optional] 
**CartItem** | [**CartItem**](CartItem.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

