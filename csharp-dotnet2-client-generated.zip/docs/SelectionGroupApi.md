# IO.Swagger.Api.SelectionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SelectionGroupsGet**](SelectionGroupApi.md#selectiongroupsget) | **GET** /selection_groups | Ek Özellik Grubu Listesi Alma
[**SelectionGroupsIdDelete**](SelectionGroupApi.md#selectiongroupsiddelete) | **DELETE** /selection_groups/{id} | Ek Özellik Grubu Silme
[**SelectionGroupsIdGet**](SelectionGroupApi.md#selectiongroupsidget) | **GET** /selection_groups/{id} | Ek Özellik Grubu Alma
[**SelectionGroupsIdPut**](SelectionGroupApi.md#selectiongroupsidput) | **PUT** /selection_groups/{id} | Ek Özellik Grubu Güncelleme
[**SelectionGroupsPost**](SelectionGroupApi.md#selectiongroupspost) | **POST** /selection_groups | Ek Özellik Grubu Oluşturma


<a name="selectiongroupsget"></a>
# **SelectionGroupsGet**
> SelectionGroup SelectionGroupsGet (string sort, int? limit, int? page, int? sinceId, string ids, string title)

Ek Özellik Grubu Listesi Alma

Ek Özellik Grubu listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SelectionGroupsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SelectionGroupApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var title = title_example;  // string | Ek Özellik Grubu başlığı (optional) 

            try
            {
                // Ek Özellik Grubu Listesi Alma
                SelectionGroup result = apiInstance.SelectionGroupsGet(sort, limit, page, sinceId, ids, title);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SelectionGroupApi.SelectionGroupsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **title** | **string**| Ek Özellik Grubu başlığı | [optional] 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="selectiongroupsiddelete"></a>
# **SelectionGroupsIdDelete**
> void SelectionGroupsIdDelete (int? id)

Ek Özellik Grubu Silme

Kalıcı olarak ilgili Ek Özellik Grubunu siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SelectionGroupsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SelectionGroupApi();
            var id = 56;  // int? | Ek Özellik Grubu nesnesinin id değeri

            try
            {
                // Ek Özellik Grubu Silme
                apiInstance.SelectionGroupsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SelectionGroupApi.SelectionGroupsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ek Özellik Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="selectiongroupsidget"></a>
# **SelectionGroupsIdGet**
> SelectionGroup SelectionGroupsIdGet (int? id)

Ek Özellik Grubu Alma

İlgili Ek Özellik Grubunu getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SelectionGroupsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SelectionGroupApi();
            var id = 56;  // int? | Ek Özellik Grubu nesnesinin id değeri

            try
            {
                // Ek Özellik Grubu Alma
                SelectionGroup result = apiInstance.SelectionGroupsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SelectionGroupApi.SelectionGroupsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ek Özellik Grubu nesnesinin id değeri | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="selectiongroupsidput"></a>
# **SelectionGroupsIdPut**
> SelectionGroup SelectionGroupsIdPut (int? id, SelectionGroup selectionGroup)

Ek Özellik Grubu Güncelleme

İlgili Ek Özellik Grubunu günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SelectionGroupsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SelectionGroupApi();
            var id = 56;  // int? | Ek Özellik Grubu nesnesinin id değeri
            var selectionGroup = new SelectionGroup(); // SelectionGroup |  nesnesi

            try
            {
                // Ek Özellik Grubu Güncelleme
                SelectionGroup result = apiInstance.SelectionGroupsIdPut(id, selectionGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SelectionGroupApi.SelectionGroupsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ek Özellik Grubu nesnesinin id değeri | 
 **selectionGroup** | [**SelectionGroup**](SelectionGroup.md)|  nesnesi | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="selectiongroupspost"></a>
# **SelectionGroupsPost**
> SelectionGroup SelectionGroupsPost (SelectionGroup selectionGroup)

Ek Özellik Grubu Oluşturma

Yeni bir Ek Özellik Grubu oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SelectionGroupsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SelectionGroupApi();
            var selectionGroup = new SelectionGroup(); // SelectionGroup |  nesnesi

            try
            {
                // Ek Özellik Grubu Oluşturma
                SelectionGroup result = apiInstance.SelectionGroupsPost(selectionGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SelectionGroupApi.SelectionGroupsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selectionGroup** | [**SelectionGroup**](SelectionGroup.md)|  nesnesi | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

