# IO.Swagger.Api.ProductProtectionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductProtectionsGet**](ProductProtectionApi.md#productprotectionsget) | **GET** /product_protections | Entegrasyon Seçeneği Listesi Alma
[**ProductProtectionsIdDelete**](ProductProtectionApi.md#productprotectionsiddelete) | **DELETE** /product_protections/{id} | Entegrasyon Seçeneği Silme
[**ProductProtectionsIdGet**](ProductProtectionApi.md#productprotectionsidget) | **GET** /product_protections/{id} | Entegrasyon Seçeneği Alma
[**ProductProtectionsIdPut**](ProductProtectionApi.md#productprotectionsidput) | **PUT** /product_protections/{id} | Entegrasyon Seçeneği Güncelleme
[**ProductProtectionsPost**](ProductProtectionApi.md#productprotectionspost) | **POST** /product_protections | Entegrasyon Seçeneği Oluşturma


<a name="productprotectionsget"></a>
# **ProductProtectionsGet**
> ProductProtection ProductProtectionsGet (string sort, int? limit, int? page, int? sinceId, int? isPriceProtected, int? isStockProtected, int? product)

Entegrasyon Seçeneği Listesi Alma

Entegrasyon Seçeneği listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductProtectionsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductProtectionApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var isPriceProtected = 56;  // int? | Fiyat korumalı ürünleri listeler<code>0</code><br><code>1</code> (optional) 
            var isStockProtected = 56;  // int? | Stok korumalı ürünleri listeler<code>0</code><br><code>1</code> (optional) 
            var product = 56;  // int? | Ürün id (optional) 

            try
            {
                // Entegrasyon Seçeneği Listesi Alma
                ProductProtection result = apiInstance.ProductProtectionsGet(sort, limit, page, sinceId, isPriceProtected, isStockProtected, product);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductProtectionApi.ProductProtectionsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **isPriceProtected** | **int?**| Fiyat korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **isStockProtected** | **int?**| Stok korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **product** | **int?**| Ürün id | [optional] 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productprotectionsiddelete"></a>
# **ProductProtectionsIdDelete**
> void ProductProtectionsIdDelete (int? id)

Entegrasyon Seçeneği Silme

Kalıcı olarak ilgili Entegrasyon Seçeneğini siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductProtectionsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductProtectionApi();
            var id = 56;  // int? | Entegrasyon Seçeneği nesnesinin id değeri

            try
            {
                // Entegrasyon Seçeneği Silme
                apiInstance.ProductProtectionsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductProtectionApi.ProductProtectionsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Entegrasyon Seçeneği nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productprotectionsidget"></a>
# **ProductProtectionsIdGet**
> ProductProtection ProductProtectionsIdGet (int? id)

Entegrasyon Seçeneği Alma

İlgili Entegrasyon Seçeneğini getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductProtectionsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductProtectionApi();
            var id = 56;  // int? | Entegrasyon Seçeneği nesnesinin id değeri

            try
            {
                // Entegrasyon Seçeneği Alma
                ProductProtection result = apiInstance.ProductProtectionsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductProtectionApi.ProductProtectionsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Entegrasyon Seçeneği nesnesinin id değeri | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productprotectionsidput"></a>
# **ProductProtectionsIdPut**
> ProductProtection ProductProtectionsIdPut (int? id, ProductProtection productProtection)

Entegrasyon Seçeneği Güncelleme

İlgili Entegrasyon Seçeneğini günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductProtectionsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductProtectionApi();
            var id = 56;  // int? | Entegrasyon Seçeneği nesnesinin id değeri
            var productProtection = new ProductProtection(); // ProductProtection | ProductProtection nesnesi

            try
            {
                // Entegrasyon Seçeneği Güncelleme
                ProductProtection result = apiInstance.ProductProtectionsIdPut(id, productProtection);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductProtectionApi.ProductProtectionsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Entegrasyon Seçeneği nesnesinin id değeri | 
 **productProtection** | [**ProductProtection**](ProductProtection.md)| ProductProtection nesnesi | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productprotectionspost"></a>
# **ProductProtectionsPost**
> ProductProtection ProductProtectionsPost (ProductProtection productProtection)

Entegrasyon Seçeneği Oluşturma

Yeni bir Entegrasyon Seçeneği oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductProtectionsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductProtectionApi();
            var productProtection = new ProductProtection(); // ProductProtection | ProductProtection nesnesi

            try
            {
                // Entegrasyon Seçeneği Oluşturma
                ProductProtection result = apiInstance.ProductProtectionsPost(productProtection);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductProtectionApi.ProductProtectionsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productProtection** | [**ProductProtection**](ProductProtection.md)| ProductProtection nesnesi | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

