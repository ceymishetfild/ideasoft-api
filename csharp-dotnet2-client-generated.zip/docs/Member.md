# IO.Swagger.Model.Member
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Üye nesnesi kimlik değeri. | [optional] 
**Firstname** | **string** | Üyenin ismi. | 
**Surname** | **string** | Üyenin soy ismi. | 
**Email** | **string** | Üyenin e-mail adresi. | 
**Gender** | **string** | Üyenin cinsiyet bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın&lt;br&gt;&lt;/div&gt; | [optional] 
**BirthDate** | **DateTime?** | Üyenin doğum tarihi. | [optional] 
**PhoneNumber** | **string** | Üyenin telefon numarası. | [optional] 
**MobilePhoneNumber** | **string** | Üyenin mobil telefon numarası. | [optional] 
**OtherLocation** | **string** | Üyenin diğer şehir bilgileri. | [optional] 
**Address** | **string** | Üyenin adres bilgileri. | [optional] 
**TaxNumber** | **string** | Üyenin vergi numarası. | [optional] 
**TcId** | **string** | Üyenin TC kimlik numarası. | [optional] 
**Status** | **string** | Üyenin durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;queue&lt;/code&gt; : Sırada&lt;br&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;suspended&lt;/code&gt; : Askıda&lt;br&gt;&lt;/div&gt; | 
**LastLoginDate** | **DateTime?** | Üyenin son giriş yaptığı tarih. | [optional] 
**CreatedAt** | **DateTime?** | Üye nesnesinin oluşturulma zamanı. | [optional] 
**UpdatedAt** | **DateTime?** | Üye nesnesinin güncellenme zamanı. | [optional] 
**ZipCode** | **string** | Üyenin posta kodu. | [optional] 
**CommercialName** | **string** | Üyenin kurumsal adı. | [optional] 
**TaxOffice** | **string** | Üyenin vergi dairesi. | [optional] 
**LastMailSentDate** | **DateTime?** | Üyeye gönderilen son e-mail tarihi. | [optional] 
**LastIp** | **string** | Üyenin en son giriş yaptığı IP adresi. | [optional] 
**GainedPointAmount** | **float?** | Üyenin kazandığı puan tutarı. | [optional] 
**SpentPointAmount** | **float?** | Üyenin harcadığı puan tutarı. | [optional] 
**AllowedToCampaigns** | **string** | Üyenin kampanyalara katılım için izin durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalar için izinli.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalar için izinsiz.&lt;br&gt;&lt;/div&gt; | [optional] 
**ReferredMemberGainedPointAmount** | **float?** | Üyenin tavsiye ettiği kişilerden dolayı kazandığı puan. | [optional] 
**District** | **string** | Üyenin ilçesi. | [optional] 
**DeviceType** | **string** | Üyenin kullandığı cihaz tipi. | 
**DeviceInfo** | **string** | Üyenin kullandığı cihaz bilgisi. | [optional] 
**Country** | [**Country**](Country.md) | Ülke nesnesi. | [optional] 
**Location** | [**Location**](Location.md) | Şehir nesnesi. | [optional] 
**MemberGroup** | [**MemberGroup**](MemberGroup.md) | Üye grubu nesnesi. | [optional] 
**ReferredMember** | [**Member**](Member.md) | Üyeyi tavsiye eden üye nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

