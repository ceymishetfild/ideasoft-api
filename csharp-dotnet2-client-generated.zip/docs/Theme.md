# IO.Swagger.Model.Theme
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Tema nesnesi kimlik değeri. | [optional] 
**Platform** | **string** | Temanın kullanılacağı platform.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü.&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil.&lt;br&gt;&lt;/div&gt; | 
**Type** | **string** | Tema tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;self&lt;/code&gt; : Kişisel Tema.&lt;br&gt;&lt;code&gt;standard&lt;/code&gt; : Standart Tema.&lt;br&gt;&lt;/div&gt; | [optional] 
**Name** | **string** | Tema adı. | 
**Preset** | **string** | Temanın rengi. | [optional] 
**DirectoryName** | **string** | Temanın dizini. | [optional] 
**Status** | **string** | Temanın durumu. | 
**Revision** | **int?** | Temanın revisionı. | [optional] 
**CreatedAt** | **DateTime?** | Tema nesnesinin oluşturulma zamanı. | [optional] 
**UpdatedAt** | **DateTime?** | Tema nesnesinin güncellenme zamanı. | [optional] 
**Attachment** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

