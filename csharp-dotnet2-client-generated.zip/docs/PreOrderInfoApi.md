# IO.Swagger.Api.PreOrderInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**PreOrderInfosGet**](PreOrderInfoApi.md#preorderinfosget) | **GET** /pre_order_infos | Sipariş Öncesi Bilgisi Listesi Alma
[**PreOrderInfosIdDelete**](PreOrderInfoApi.md#preorderinfosiddelete) | **DELETE** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Silme
[**PreOrderInfosIdGet**](PreOrderInfoApi.md#preorderinfosidget) | **GET** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Alma
[**PreOrderInfosIdPut**](PreOrderInfoApi.md#preorderinfosidput) | **PUT** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Güncelleme
[**PreOrderInfosPost**](PreOrderInfoApi.md#preorderinfospost) | **POST** /pre_order_infos | Sipariş Öncesi Bilgisi Oluşturma


<a name="preorderinfosget"></a>
# **PreOrderInfosGet**
> PreOrderInfo PreOrderInfosGet (string sort, int? limit, int? page, int? sinceId, string sessionId, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)

Sipariş Öncesi Bilgisi Listesi Alma

Sipariş Öncesi Bilgisi listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PreOrderInfosGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new PreOrderInfoApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var sessionId = sessionId_example;  // string | Sipariş Öncesi Bilgisi session id. (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 

            try
            {
                // Sipariş Öncesi Bilgisi Listesi Alma
                PreOrderInfo result = apiInstance.PreOrderInfosGet(sort, limit, page, sinceId, sessionId, startDate, endDate, startUpdatedAt, endUpdatedAt);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PreOrderInfoApi.PreOrderInfosGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **sessionId** | **string**| Sipariş Öncesi Bilgisi session id. | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="preorderinfosiddelete"></a>
# **PreOrderInfosIdDelete**
> void PreOrderInfosIdDelete (int? id)

Sipariş Öncesi Bilgisi Silme

Kalıcı olarak ilgili Sipariş Öncesi Bilgisini siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PreOrderInfosIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new PreOrderInfoApi();
            var id = 56;  // int? | Sipariş Öncesi Bilgisi nesnesinin id değeri

            try
            {
                // Sipariş Öncesi Bilgisi Silme
                apiInstance.PreOrderInfosIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PreOrderInfoApi.PreOrderInfosIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="preorderinfosidget"></a>
# **PreOrderInfosIdGet**
> PreOrderInfo PreOrderInfosIdGet (int? id)

Sipariş Öncesi Bilgisi Alma

İlgili Sipariş Öncesi Bilgisini getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PreOrderInfosIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new PreOrderInfoApi();
            var id = 56;  // int? | Sipariş Öncesi Bilgisi nesnesinin id değeri

            try
            {
                // Sipariş Öncesi Bilgisi Alma
                PreOrderInfo result = apiInstance.PreOrderInfosIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PreOrderInfoApi.PreOrderInfosIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="preorderinfosidput"></a>
# **PreOrderInfosIdPut**
> PreOrderInfo PreOrderInfosIdPut (int? id, PreOrderInfo preOrderInfo)

Sipariş Öncesi Bilgisi Güncelleme

İlgili Sipariş Öncesi Bilgisini günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PreOrderInfosIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new PreOrderInfoApi();
            var id = 56;  // int? | Sipariş Öncesi Bilgisi nesnesinin id değeri
            var preOrderInfo = new PreOrderInfo(); // PreOrderInfo | PreOrderInfo nesnesi

            try
            {
                // Sipariş Öncesi Bilgisi Güncelleme
                PreOrderInfo result = apiInstance.PreOrderInfosIdPut(id, preOrderInfo);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PreOrderInfoApi.PreOrderInfosIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 
 **preOrderInfo** | [**PreOrderInfo**](PreOrderInfo.md)| PreOrderInfo nesnesi | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="preorderinfospost"></a>
# **PreOrderInfosPost**
> PreOrderInfo PreOrderInfosPost (PreOrderInfo preOrderInfo)

Sipariş Öncesi Bilgisi Oluşturma

Yeni bir Sipariş Öncesi Bilgisi oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PreOrderInfosPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new PreOrderInfoApi();
            var preOrderInfo = new PreOrderInfo(); // PreOrderInfo | PreOrderInfo nesnesi

            try
            {
                // Sipariş Öncesi Bilgisi Oluşturma
                PreOrderInfo result = apiInstance.PreOrderInfosPost(preOrderInfo);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PreOrderInfoApi.PreOrderInfosPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **preOrderInfo** | [**PreOrderInfo**](PreOrderInfo.md)| PreOrderInfo nesnesi | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

