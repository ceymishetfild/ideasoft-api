# IO.Swagger.Model.MemberAddress
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Üye adresi nesnesinin benzersiz rakamsal kimlik değeri. | [optional] 
**Name** | **string** | Üye Adresi adı. | [optional] 
**Type** | **string** | Üye Adresi tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;shipping&lt;/code&gt; : Teslimat adresi.&lt;br&gt;&lt;code&gt;billing&lt;/code&gt; : Fatura adresi.&lt;br&gt;&lt;/div&gt; | [optional] 
**Firstname** | **string** | Üyenin ismi. | [optional] 
**Surname** | **string** | Üyenin soy ismi. | [optional] 
**Address** | **string** | Üyenin adres bilgileri. | [optional] 
**SubLocationName** | **string** | İlçe adı. | [optional] 
**PhoneNumber** | **string** | Üyenin telefon numarası. | [optional] 
**MobilePhoneNumber** | **string** | Üyenin mobil telefon numarası. | [optional] 
**TcId** | **string** | Üyenin TC kimlik numarası. | [optional] 
**TaxNumber** | **string** | Üyenin vergi numarası. | [optional] 
**TaxOffice** | **string** | Üyenin vergi dairesi. | [optional] 
**InvoiceType** | **string** | Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt; | [optional] 
**IsEinvoiceUser** | **bool?** | Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] 
**CreatedAt** | **DateTime?** | Tema nesnesinin oluşturulma zamanı. | [optional] 
**UpdatedAt** | **DateTime?** | Tema nesnesinin güncellenme zamanı. | [optional] 
**Member** | [**Member**](Member.md) |  | [optional] 
**Country** | [**Country**](Country.md) |  | [optional] 
**Location** | [**Location**](Location.md) |  | [optional] 
**SubLocation** | [**Town**](Town.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

