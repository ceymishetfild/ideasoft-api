# IO.Swagger.Api.DistributorToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DistributorToProductsGet**](DistributorToProductApi.md#distributortoproductsget) | **GET** /distributor_to_products | Distribütör Ürün Bağı Listesi Alma
[**DistributorToProductsIdDelete**](DistributorToProductApi.md#distributortoproductsiddelete) | **DELETE** /distributor_to_products/{id} | Distribütör Ürün Bağı Silme
[**DistributorToProductsIdGet**](DistributorToProductApi.md#distributortoproductsidget) | **GET** /distributor_to_products/{id} | Distribütör Ürün Bağı Alma
[**DistributorToProductsIdPut**](DistributorToProductApi.md#distributortoproductsidput) | **PUT** /distributor_to_products/{id} | Distribütör Ürün Bağı Güncelleme
[**DistributorToProductsPost**](DistributorToProductApi.md#distributortoproductspost) | **POST** /distributor_to_products | Distribütör Ürün Bağı Oluşturma


<a name="distributortoproductsget"></a>
# **DistributorToProductsGet**
> DistributorToProduct DistributorToProductsGet (string sort, int? limit, int? page, int? sinceId, int? distributor, int? product)

Distribütör Ürün Bağı Listesi Alma

Distribütör Ürün Bağı listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DistributorToProductsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new DistributorToProductApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var distributor = 56;  // int? | Distribütör id (optional) 
            var product = 56;  // int? | Ürün id (optional) 

            try
            {
                // Distribütör Ürün Bağı Listesi Alma
                DistributorToProduct result = apiInstance.DistributorToProductsGet(sort, limit, page, sinceId, distributor, product);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DistributorToProductApi.DistributorToProductsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **distributor** | **int?**| Distribütör id | [optional] 
 **product** | **int?**| Ürün id | [optional] 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="distributortoproductsiddelete"></a>
# **DistributorToProductsIdDelete**
> void DistributorToProductsIdDelete (int? id)

Distribütör Ürün Bağı Silme

Kalıcı olarak ilgili Distribütör Ürün Bağını siler

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DistributorToProductsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new DistributorToProductApi();
            var id = 56;  // int? | Distribütör Ürün Bağı nesnesinin id değeri

            try
            {
                // Distribütör Ürün Bağı Silme
                apiInstance.DistributorToProductsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DistributorToProductApi.DistributorToProductsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Distribütör Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="distributortoproductsidget"></a>
# **DistributorToProductsIdGet**
> DistributorToProduct DistributorToProductsIdGet (int? id)

Distribütör Ürün Bağı Alma

İlgili Distribütör Ürün Bağını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DistributorToProductsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new DistributorToProductApi();
            var id = 56;  // int? | Distribütör Ürün Bağı nesnesinin id değeri

            try
            {
                // Distribütör Ürün Bağı Alma
                DistributorToProduct result = apiInstance.DistributorToProductsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DistributorToProductApi.DistributorToProductsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Distribütör Ürün Bağı nesnesinin id değeri | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="distributortoproductsidput"></a>
# **DistributorToProductsIdPut**
> DistributorToProduct DistributorToProductsIdPut (int? id, DistributorToProduct distributorToProduct)

Distribütör Ürün Bağı Güncelleme

İlgili Distribütör Ürün Bağını günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DistributorToProductsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new DistributorToProductApi();
            var id = 56;  // int? | Distribütör Ürün Bağı nesnesinin id değeri
            var distributorToProduct = new DistributorToProduct(); // DistributorToProduct | DistributorToProduct nesnesi

            try
            {
                // Distribütör Ürün Bağı Güncelleme
                DistributorToProduct result = apiInstance.DistributorToProductsIdPut(id, distributorToProduct);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DistributorToProductApi.DistributorToProductsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Distribütör Ürün Bağı nesnesinin id değeri | 
 **distributorToProduct** | [**DistributorToProduct**](DistributorToProduct.md)| DistributorToProduct nesnesi | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="distributortoproductspost"></a>
# **DistributorToProductsPost**
> DistributorToProduct DistributorToProductsPost (DistributorToProduct distributorToProduct)

Distribütör Ürün Bağı Oluşturma

Yeni bir Distribütör Ürün Bağı oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DistributorToProductsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new DistributorToProductApi();
            var distributorToProduct = new DistributorToProduct(); // DistributorToProduct | DistributorToProduct nesnesi

            try
            {
                // Distribütör Ürün Bağı Oluşturma
                DistributorToProduct result = apiInstance.DistributorToProductsPost(distributorToProduct);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DistributorToProductApi.DistributorToProductsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **distributorToProduct** | [**DistributorToProduct**](DistributorToProduct.md)| DistributorToProduct nesnesi | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

