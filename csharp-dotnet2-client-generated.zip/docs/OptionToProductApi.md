# IO.Swagger.Api.OptionToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**OptionToProductsGet**](OptionToProductApi.md#optiontoproductsget) | **GET** /option_to_products | Varyant Ürün Bağı Listesi Alma
[**OptionToProductsIdDelete**](OptionToProductApi.md#optiontoproductsiddelete) | **DELETE** /option_to_products/{id} | Varyant Ürün Bağı Silme
[**OptionToProductsIdGet**](OptionToProductApi.md#optiontoproductsidget) | **GET** /option_to_products/{id} | Varyant Ürün Bağı Alma
[**OptionToProductsIdPut**](OptionToProductApi.md#optiontoproductsidput) | **PUT** /option_to_products/{id} | Varyant Ürün Bağı Güncelleme
[**OptionToProductsPost**](OptionToProductApi.md#optiontoproductspost) | **POST** /option_to_products | Varyant Ürün Bağı Oluşturma


<a name="optiontoproductsget"></a>
# **OptionToProductsGet**
> OptionToProduct OptionToProductsGet (string sort, int? limit, int? page, int? sinceId, int? product, int? optionGroup, int? option, int? parentProductId)

Varyant Ürün Bağı Listesi Alma

Varyant Ürün Bağı listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OptionToProductsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OptionToProductApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var product = 56;  // int? | Ürün id (optional) 
            var optionGroup = 56;  // int? | Varyant Grubu id (optional) 
            var option = 56;  // int? | Varyant id (optional) 
            var parentProductId = 56;  // int? | Ana Ürün id (optional) 

            try
            {
                // Varyant Ürün Bağı Listesi Alma
                OptionToProduct result = apiInstance.OptionToProductsGet(sort, limit, page, sinceId, product, optionGroup, option, parentProductId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OptionToProductApi.OptionToProductsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **product** | **int?**| Ürün id | [optional] 
 **optionGroup** | **int?**| Varyant Grubu id | [optional] 
 **option** | **int?**| Varyant id | [optional] 
 **parentProductId** | **int?**| Ana Ürün id | [optional] 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="optiontoproductsiddelete"></a>
# **OptionToProductsIdDelete**
> void OptionToProductsIdDelete (int? id)

Varyant Ürün Bağı Silme

Kalıcı olarak ilgili Varyant Ürün Bağını siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OptionToProductsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OptionToProductApi();
            var id = 56;  // int? | Varyant Ürün Bağı nesnesinin id değeri

            try
            {
                // Varyant Ürün Bağı Silme
                apiInstance.OptionToProductsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OptionToProductApi.OptionToProductsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Varyant Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="optiontoproductsidget"></a>
# **OptionToProductsIdGet**
> OptionToProduct OptionToProductsIdGet (int? id)

Varyant Ürün Bağı Alma

İlgili Varyant Ürün Bağını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OptionToProductsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OptionToProductApi();
            var id = 56;  // int? | Varyant Ürün Bağı nesnesinin id değeri

            try
            {
                // Varyant Ürün Bağı Alma
                OptionToProduct result = apiInstance.OptionToProductsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OptionToProductApi.OptionToProductsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Varyant Ürün Bağı nesnesinin id değeri | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="optiontoproductsidput"></a>
# **OptionToProductsIdPut**
> OptionToProduct OptionToProductsIdPut (int? id, OptionToProduct optionToProduct)

Varyant Ürün Bağı Güncelleme

İlgili Varyant Ürün Bağını günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OptionToProductsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OptionToProductApi();
            var id = 56;  // int? | Varyant Ürün Bağı nesnesinin id değeri
            var optionToProduct = new OptionToProduct(); // OptionToProduct | OptionToProduct nesnesi

            try
            {
                // Varyant Ürün Bağı Güncelleme
                OptionToProduct result = apiInstance.OptionToProductsIdPut(id, optionToProduct);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OptionToProductApi.OptionToProductsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Varyant Ürün Bağı nesnesinin id değeri | 
 **optionToProduct** | [**OptionToProduct**](OptionToProduct.md)| OptionToProduct nesnesi | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="optiontoproductspost"></a>
# **OptionToProductsPost**
> OptionToProduct OptionToProductsPost (OptionToProduct optionToProduct)

Varyant Ürün Bağı Oluşturma

Yeni bir Varyant Ürün Bağı oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OptionToProductsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OptionToProductApi();
            var optionToProduct = new OptionToProduct(); // OptionToProduct | OptionToProduct nesnesi

            try
            {
                // Varyant Ürün Bağı Oluşturma
                OptionToProduct result = apiInstance.OptionToProductsPost(optionToProduct);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OptionToProductApi.OptionToProductsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **optionToProduct** | [**OptionToProduct**](OptionToProduct.md)| OptionToProduct nesnesi | 

### Return type

[**OptionToProduct**](OptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

