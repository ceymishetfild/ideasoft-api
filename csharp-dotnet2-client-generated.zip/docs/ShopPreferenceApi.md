# IO.Swagger.Api.ShopPreferenceApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**PreferencesGet**](ShopPreferenceApi.md#preferencesget) | **GET** /preferences | Tanımlamalar Listesi Alma
[**PreferencesIdGet**](ShopPreferenceApi.md#preferencesidget) | **GET** /preferences/{id} | Tanımlamalar Alma
[**PreferencesIdPut**](ShopPreferenceApi.md#preferencesidput) | **PUT** /preferences/{id} | Tanımlamalar Güncelleme


<a name="preferencesget"></a>
# **PreferencesGet**
> ShopPreference PreferencesGet (string sort, int? limit, int? page, int? sinceId, string varKey)

Tanımlamalar Listesi Alma

Tanımlamalar listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PreferencesGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShopPreferenceApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 100)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var varKey = varKey_example;  // string | Tanımlama varKey değeri (optional) 

            try
            {
                // Tanımlamalar Listesi Alma
                ShopPreference result = apiInstance.PreferencesGet(sort, limit, page, sinceId, varKey);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShopPreferenceApi.PreferencesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 100]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **varKey** | **string**| Tanımlama varKey değeri | [optional] 

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="preferencesidget"></a>
# **PreferencesIdGet**
> ShopPreference PreferencesIdGet (int? id)

Tanımlamalar Alma

İlgili Tanımlamayı getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PreferencesIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShopPreferenceApi();
            var id = 56;  // int? | Tanımlama nesnesinin id değeri

            try
            {
                // Tanımlamalar Alma
                ShopPreference result = apiInstance.PreferencesIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShopPreferenceApi.PreferencesIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Tanımlama nesnesinin id değeri | 

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="preferencesidput"></a>
# **PreferencesIdPut**
> ShopPreference PreferencesIdPut (int? id, ShopPreference shopPreference)

Tanımlamalar Güncelleme

İlgili Tanımlamayı günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PreferencesIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShopPreferenceApi();
            var id = 56;  // int? | Tanımlama nesnesinin id değeri
            var shopPreference = new ShopPreference(); // ShopPreference | ShopPreference nesnesi

            try
            {
                // Tanımlamalar Güncelleme
                ShopPreference result = apiInstance.PreferencesIdPut(id, shopPreference);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShopPreferenceApi.PreferencesIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Tanımlama nesnesinin id değeri | 
 **shopPreference** | [**ShopPreference**](ShopPreference.md)| ShopPreference nesnesi | 

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

