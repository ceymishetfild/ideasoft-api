# IO.Swagger.Api.MemberAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**MemberAddressesGet**](MemberAddressApi.md#memberaddressesget) | **GET** /member_addresses | Üye Adresi Listeleme
[**MemberAddressesIdDelete**](MemberAddressApi.md#memberaddressesiddelete) | **DELETE** /member_addresses/{id} | Üye Adresi Silme
[**MemberAddressesIdGet**](MemberAddressApi.md#memberaddressesidget) | **GET** /member_addresses/{id} | Üye Adresi Alma
[**MemberAddressesIdPut**](MemberAddressApi.md#memberaddressesidput) | **PUT** /member_addresses/{id} | Üye Adresi Güncelleme
[**MemberAddressesPost**](MemberAddressApi.md#memberaddressespost) | **POST** /member_addresses | Üye Adresi Oluşturma


<a name="memberaddressesget"></a>
# **MemberAddressesGet**
> MemberAddress MemberAddressesGet (string sort, int? limit, int? page, int? sinceId, int? member, DateTime? startDate, string endDate)

Üye Adresi Listeleme

Üye Adresi listesi verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MemberAddressesGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberAddressApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir (optional) 
            var member = 56;  // int? | Üye id (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 

            try
            {
                // Üye Adresi Listeleme
                MemberAddress result = apiInstance.MemberAddressesGet(sort, limit, page, sinceId, member, startDate, endDate);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberAddressApi.MemberAddressesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional] 
 **member** | **int?**| Üye id | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="memberaddressesiddelete"></a>
# **MemberAddressesIdDelete**
> void MemberAddressesIdDelete (int? id)

Üye Adresi Silme

Kalıcı olarak ilgili Üye Adresini siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MemberAddressesIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberAddressApi();
            var id = 56;  // int? | Üye Adresi nesnesinin id değeri

            try
            {
                // Üye Adresi Silme
                apiInstance.MemberAddressesIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberAddressApi.MemberAddressesIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Üye Adresi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="memberaddressesidget"></a>
# **MemberAddressesIdGet**
> MemberAddress MemberAddressesIdGet (int? id)

Üye Adresi Alma

İlgili Üye Adresini getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MemberAddressesIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberAddressApi();
            var id = 56;  // int? | Üye Adresi nesnesinin id değeri

            try
            {
                // Üye Adresi Alma
                MemberAddress result = apiInstance.MemberAddressesIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberAddressApi.MemberAddressesIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Üye Adresi nesnesinin id değeri | 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="memberaddressesidput"></a>
# **MemberAddressesIdPut**
> MemberAddress MemberAddressesIdPut (int? id, MemberAddress memberAddress)

Üye Adresi Güncelleme

İlgili Üye Adresini günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MemberAddressesIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberAddressApi();
            var id = 56;  // int? | Üye Adresi nesnesinin id değeri
            var memberAddress = new MemberAddress(); // MemberAddress | MemberAddress nesnesi

            try
            {
                // Üye Adresi Güncelleme
                MemberAddress result = apiInstance.MemberAddressesIdPut(id, memberAddress);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberAddressApi.MemberAddressesIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Üye Adresi nesnesinin id değeri | 
 **memberAddress** | [**MemberAddress**](MemberAddress.md)| MemberAddress nesnesi | 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="memberaddressespost"></a>
# **MemberAddressesPost**
> MemberAddress MemberAddressesPost (MemberAddress memberAddress)

Üye Adresi Oluşturma

Yeni bir Üye Adresi oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MemberAddressesPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MemberAddressApi();
            var memberAddress = new MemberAddress(); // MemberAddress | MemberAddress nesnesi

            try
            {
                // Üye Adresi Oluşturma
                MemberAddress result = apiInstance.MemberAddressesPost(memberAddress);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MemberAddressApi.MemberAddressesPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **memberAddress** | [**MemberAddress**](MemberAddress.md)| MemberAddress nesnesi | 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

