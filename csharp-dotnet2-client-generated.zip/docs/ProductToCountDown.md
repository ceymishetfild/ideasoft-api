# IO.Swagger.Model.ProductToCountDown
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ürün geri sayım bağı nesnesi kimlik değeri. | [optional] 
**StartDate** | **DateTime?** | Geri sayımın başlangıç tarihi. | [optional] 
**EndDate** | **DateTime?** | Geri sayımın bitiş tarihi. | [optional] 
**ExpireDate** | **DateTime?** | Geri sayımın ürün için geçersiz olma tarihi. | [optional] 
**UseCountDown** | **string** | Geri sayımın aktiflik durumu bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**Product** | [**Product**](Product.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

