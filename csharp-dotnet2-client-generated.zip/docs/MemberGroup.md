# IO.Swagger.Model.MemberGroup
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Üye Grubu nesnesi kimlik değeri. | [optional] 
**Name** | **string** | Üye Grubu nesnesi için isim değeri. | 
**PriceIndex** | **int?** | Üye Grubunun fiyat indisi. Örnek Fiyat 2. | 
**AllowedPaymentGateways** | **string** | Üye Grubunun izin verilmiş ödeme kanalları. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

