# IO.Swagger.Model.Tag
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | SEO+ etiketi nesnesi kimlik değeri. | [optional] 
**Name** | **string** | SEO+ etiketi nesnesi için isim değeri. | 
**Count** | **int?** | SEO+ etiketinin kaç kez kullanıldığı bilgisi. | [optional] 
**PageTitle** | **string** | SEO+ etiketi nesnesinin etiket başlığı. | [optional] 
**MetaDescription** | **string** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] 
**MetaKeywords** | **string** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

