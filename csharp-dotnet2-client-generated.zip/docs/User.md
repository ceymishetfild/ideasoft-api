# IO.Swagger.Model.User
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Yönetici nesnesi kimlik değeri. | [optional] 
**Firstname** | **string** | Yöneticinin ismi. | [optional] 
**Surname** | **string** | Yöneticinin soy ismi. | [optional] 
**Email** | **string** | Yöneticinin e-mail adresi. | 
**Username** | **string** | Yöneticinin kullanıcı adı. | 
**PhoneNumber** | **string** | Yöneticinin telefon numarası. | [optional] 
**Status** | **int?** | Yöneticinin aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Askıya alınmış.&lt;br&gt;&lt;/div&gt; | 
**IsOwner** | **string** | Yöneticinin site sahibi olma durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Site sahibi.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Site sahibi değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**Membergroups** | [**List&lt;MemberGroup&gt;**](MemberGroup.md) | İlgili üye grubu. | [optional] 
**SmsApproved** | **string** | Yöneticinin SMS verifikasyonu yapılma bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : SMS verifikasyon yapılmış.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : SMS verifikasyon yapılmamış.&lt;br&gt;&lt;/div&gt; | [optional] 
**Userlevel** | [**ShopUserlevels**](ShopUserlevels.md) | Yönetici grubu nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

