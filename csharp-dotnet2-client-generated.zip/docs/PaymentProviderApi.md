# IO.Swagger.Api.PaymentProviderApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**PaymentProvidersGet**](PaymentProviderApi.md#paymentprovidersget) | **GET** /payment_providers | Ödeme Altyapısı Sağlayıcısı Listesi Alma
[**PaymentProvidersIdGet**](PaymentProviderApi.md#paymentprovidersidget) | **GET** /payment_providers/{id} | Ödeme Altyapısı Sağlayıcısı Alma


<a name="paymentprovidersget"></a>
# **PaymentProvidersGet**
> PaymentProvider PaymentProvidersGet (string sort, int? limit, int? page, int? sinceId, string code, string name)

Ödeme Altyapısı Sağlayıcısı Listesi Alma

Ödeme Altyapısı Sağlayıcısı listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PaymentProvidersGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new PaymentProviderApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var code = code_example;  // string | Ödeme Altyapısı kodu (optional) 
            var name = name_example;  // string | Ödeme Altyapısı adı (optional) 

            try
            {
                // Ödeme Altyapısı Sağlayıcısı Listesi Alma
                PaymentProvider result = apiInstance.PaymentProvidersGet(sort, limit, page, sinceId, code, name);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PaymentProviderApi.PaymentProvidersGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **code** | **string**| Ödeme Altyapısı kodu | [optional] 
 **name** | **string**| Ödeme Altyapısı adı | [optional] 

### Return type

[**PaymentProvider**](PaymentProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="paymentprovidersidget"></a>
# **PaymentProvidersIdGet**
> PaymentProvider PaymentProvidersIdGet (int? id)

Ödeme Altyapısı Sağlayıcısı Alma

İlgili Ödeme Altyapısı Sağlayıcısını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PaymentProvidersIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new PaymentProviderApi();
            var id = 56;  // int? | Ödeme Altyapııs Sağlayıcısı nesnesinin id değeri

            try
            {
                // Ödeme Altyapısı Sağlayıcısı Alma
                PaymentProvider result = apiInstance.PaymentProvidersIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PaymentProviderApi.PaymentProvidersIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ödeme Altyapııs Sağlayıcısı nesnesinin id değeri | 

### Return type

[**PaymentProvider**](PaymentProvider.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

