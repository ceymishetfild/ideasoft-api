# IO.Swagger.Api.OrderRefundRequestApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**OrderRefundRequestsGet**](OrderRefundRequestApi.md#orderrefundrequestsget) | **GET** /order_refund_requests | Sipariş İptal Talebi Listesi Alma
[**OrderRefundRequestsIdDelete**](OrderRefundRequestApi.md#orderrefundrequestsiddelete) | **DELETE** /order_refund_requests/{id} | Sipariş İptal Talebi Silme
[**OrderRefundRequestsIdGet**](OrderRefundRequestApi.md#orderrefundrequestsidget) | **GET** /order_refund_requests/{id} | Sipariş İptal Talebi Alma
[**OrderRefundRequestsIdPut**](OrderRefundRequestApi.md#orderrefundrequestsidput) | **PUT** /order_refund_requests/{id} | Sipariş İptal Talebi Güncelleme
[**OrderRefundRequestsPost**](OrderRefundRequestApi.md#orderrefundrequestspost) | **POST** /order_refund_requests | Sipariş İptal Talebi Oluşturma


<a name="orderrefundrequestsget"></a>
# **OrderRefundRequestsGet**
> OrderRefundRequest OrderRefundRequestsGet (string sort, int? limit, int? page, int? sinceId, int? order, int? member, string code, string status, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)

Sipariş İptal Talebi Listesi Alma

Sipariş İptal Talebi listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderRefundRequestsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderRefundRequestApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var order = 56;  // int? | Sipariş id (optional) 
            var member = 56;  // int? | Üye id (optional) 
            var code = code_example;  // string | Sipariş İptal Talebi kodu (optional) 
            var status = status_example;  // string | Status şu değerleri alabilir: <br><code>waiting_for_approval</code> : Onay bekliyor<br><code>approved</code> : Onaylandı<br><code>cancelled</code> : İptal edildi (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 

            try
            {
                // Sipariş İptal Talebi Listesi Alma
                OrderRefundRequest result = apiInstance.OrderRefundRequestsGet(sort, limit, page, sinceId, order, member, code, status, startDate, endDate, startUpdatedAt, endUpdatedAt);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderRefundRequestApi.OrderRefundRequestsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **int?**| Sipariş id | [optional] 
 **member** | **int?**| Üye id | [optional] 
 **code** | **string**| Sipariş İptal Talebi kodu | [optional] 
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderrefundrequestsiddelete"></a>
# **OrderRefundRequestsIdDelete**
> void OrderRefundRequestsIdDelete (int? id)

Sipariş İptal Talebi Silme

Kalıcı olarak ilgili Sipariş İptal Talebini siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderRefundRequestsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderRefundRequestApi();
            var id = 56;  // int? | Sipariş İptal Talebi nesnesinin id değeri

            try
            {
                // Sipariş İptal Talebi Silme
                apiInstance.OrderRefundRequestsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderRefundRequestApi.OrderRefundRequestsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş İptal Talebi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderrefundrequestsidget"></a>
# **OrderRefundRequestsIdGet**
> OrderRefundRequest OrderRefundRequestsIdGet (int? id)

Sipariş İptal Talebi Alma

İlgili Sipariş İptal Talebini getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderRefundRequestsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderRefundRequestApi();
            var id = 56;  // int? | Sipariş İptal Talebi nesnesinin id değeri

            try
            {
                // Sipariş İptal Talebi Alma
                OrderRefundRequest result = apiInstance.OrderRefundRequestsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderRefundRequestApi.OrderRefundRequestsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş İptal Talebi nesnesinin id değeri | 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderrefundrequestsidput"></a>
# **OrderRefundRequestsIdPut**
> OrderRefundRequest OrderRefundRequestsIdPut (int? id, OrderRefundRequest orderRefundRequest)

Sipariş İptal Talebi Güncelleme

İlgili Sipariş İptal Talebini günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderRefundRequestsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderRefundRequestApi();
            var id = 56;  // int? | Sipariş İptal Talebi nesnesinin id değeri
            var orderRefundRequest = new OrderRefundRequest(); // OrderRefundRequest | OrderRefundRequest nesnesi

            try
            {
                // Sipariş İptal Talebi Güncelleme
                OrderRefundRequest result = apiInstance.OrderRefundRequestsIdPut(id, orderRefundRequest);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderRefundRequestApi.OrderRefundRequestsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş İptal Talebi nesnesinin id değeri | 
 **orderRefundRequest** | [**OrderRefundRequest**](OrderRefundRequest.md)| OrderRefundRequest nesnesi | 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderrefundrequestspost"></a>
# **OrderRefundRequestsPost**
> OrderRefundRequest OrderRefundRequestsPost (OrderRefundRequest orderRefundRequest)

Sipariş İptal Talebi Oluşturma

Yeni bir Sipariş İptal Talebi oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderRefundRequestsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderRefundRequestApi();
            var orderRefundRequest = new OrderRefundRequest(); // OrderRefundRequest | OrderRefundRequest nesnesi

            try
            {
                // Sipariş İptal Talebi Oluşturma
                OrderRefundRequest result = apiInstance.OrderRefundRequestsPost(orderRefundRequest);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderRefundRequestApi.OrderRefundRequestsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orderRefundRequest** | [**OrderRefundRequest**](OrderRefundRequest.md)| OrderRefundRequest nesnesi | 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

