# IO.Swagger.Api.ProductSpecialInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductSpecialInfosGet**](ProductSpecialInfoApi.md#productspecialinfosget) | **GET** /product_special_infos | Ürün Özel Bilgi Alanı Listesi Alma
[**ProductSpecialInfosIdDelete**](ProductSpecialInfoApi.md#productspecialinfosiddelete) | **DELETE** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**ProductSpecialInfosIdGet**](ProductSpecialInfoApi.md#productspecialinfosidget) | **GET** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**ProductSpecialInfosIdPut**](ProductSpecialInfoApi.md#productspecialinfosidput) | **PUT** /product_special_infos/{id} | Ürün Özel Bilgi Alanı Güncelleme
[**ProductSpecialInfosPost**](ProductSpecialInfoApi.md#productspecialinfospost) | **POST** /product_special_infos | Ürün Özel Bilgi Alanı Oluşturma


<a name="productspecialinfosget"></a>
# **ProductSpecialInfosGet**
> ProductSpecialInfo ProductSpecialInfosGet (string sort, int? limit, int? page, int? sinceId, string title, int? status, int? product)

Ürün Özel Bilgi Alanı Listesi Alma

Ürün Özel Bilgi Alanı listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductSpecialInfosGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductSpecialInfoApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var title = title_example;  // string | Ürün Özel Bilgi Alanı başlığı (optional) 
            var status = 56;  // int? | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif (optional) 
            var product = 56;  // int? | Ürün id (optional) 

            try
            {
                // Ürün Özel Bilgi Alanı Listesi Alma
                ProductSpecialInfo result = apiInstance.ProductSpecialInfosGet(sort, limit, page, sinceId, title, status, product);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductSpecialInfoApi.ProductSpecialInfosGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **title** | **string**| Ürün Özel Bilgi Alanı başlığı | [optional] 
 **status** | **int?**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **product** | **int?**| Ürün id | [optional] 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productspecialinfosiddelete"></a>
# **ProductSpecialInfosIdDelete**
> void ProductSpecialInfosIdDelete (int? id)

Ürün Özel Bilgi Alanı

Kalıcı olarak ilgili Ürün Özel Bilgi Alanını siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductSpecialInfosIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductSpecialInfoApi();
            var id = 56;  // int? | Ürün Özel Bilgi Alanı nesnesinin id değeri

            try
            {
                // Ürün Özel Bilgi Alanı
                apiInstance.ProductSpecialInfosIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductSpecialInfoApi.ProductSpecialInfosIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productspecialinfosidget"></a>
# **ProductSpecialInfosIdGet**
> ProductSpecialInfo ProductSpecialInfosIdGet (int? id)

Ürün Özel Bilgi Alanı

İlgili Ürün Özel Bilgi Alanını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductSpecialInfosIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductSpecialInfoApi();
            var id = 56;  // int? | Ürün Özel Bilgi Alanı nesnesinin id değeri

            try
            {
                // Ürün Özel Bilgi Alanı
                ProductSpecialInfo result = apiInstance.ProductSpecialInfosIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductSpecialInfoApi.ProductSpecialInfosIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productspecialinfosidput"></a>
# **ProductSpecialInfosIdPut**
> ProductSpecialInfo ProductSpecialInfosIdPut (int? id, ProductSpecialInfo productSpecialInfo)

Ürün Özel Bilgi Alanı Güncelleme

İlgili Ürün Özel Bilgi Alanını günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductSpecialInfosIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductSpecialInfoApi();
            var id = 56;  // int? | Ürün Özel Bilgi Alanı nesnesinin id değeri
            var productSpecialInfo = new ProductSpecialInfo(); // ProductSpecialInfo | ProductSpecialInfo nesnesi

            try
            {
                // Ürün Özel Bilgi Alanı Güncelleme
                ProductSpecialInfo result = apiInstance.ProductSpecialInfosIdPut(id, productSpecialInfo);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductSpecialInfoApi.ProductSpecialInfosIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 
 **productSpecialInfo** | [**ProductSpecialInfo**](ProductSpecialInfo.md)| ProductSpecialInfo nesnesi | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productspecialinfospost"></a>
# **ProductSpecialInfosPost**
> ProductSpecialInfo ProductSpecialInfosPost (ProductSpecialInfo productSpecialInfo)

Ürün Özel Bilgi Alanı Oluşturma

Yeni bir Ürün Özel Bilgi Alanı oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductSpecialInfosPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductSpecialInfoApi();
            var productSpecialInfo = new ProductSpecialInfo(); // ProductSpecialInfo | ProductSpecialInfo nesnesi

            try
            {
                // Ürün Özel Bilgi Alanı Oluşturma
                ProductSpecialInfo result = apiInstance.ProductSpecialInfosPost(productSpecialInfo);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductSpecialInfoApi.ProductSpecialInfosPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productSpecialInfo** | [**ProductSpecialInfo**](ProductSpecialInfo.md)| ProductSpecialInfo nesnesi | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

