# IO.Swagger.Api.MaillistGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**MaillistGroupsGet**](MaillistGroupApi.md#maillistgroupsget) | **GET** /maillist_groups | Mail Listesi Grubu Listesi Alma
[**MaillistGroupsIdDelete**](MaillistGroupApi.md#maillistgroupsiddelete) | **DELETE** /maillist_groups/{id} | Mail Listesi Grubu Silme
[**MaillistGroupsIdGet**](MaillistGroupApi.md#maillistgroupsidget) | **GET** /maillist_groups/{id} | Mail Listesi Grubu Alma
[**MaillistGroupsIdPut**](MaillistGroupApi.md#maillistgroupsidput) | **PUT** /maillist_groups/{id} | Mail Listesi Grubu Güncelleme
[**MaillistGroupsPost**](MaillistGroupApi.md#maillistgroupspost) | **POST** /maillist_groups | Mail Listesi Grubu Oluşturma


<a name="maillistgroupsget"></a>
# **MaillistGroupsGet**
> MaillistGroup MaillistGroupsGet (string sort, int? limit, int? page, int? sinceId, string ids, string name)

Mail Listesi Grubu Listesi Alma

Mail Listesi Grubu listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MaillistGroupsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MaillistGroupApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var name = name_example;  // string | Mail Listesi Grubu adı (optional) 

            try
            {
                // Mail Listesi Grubu Listesi Alma
                MaillistGroup result = apiInstance.MaillistGroupsGet(sort, limit, page, sinceId, ids, name);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MaillistGroupApi.MaillistGroupsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **string**| Mail Listesi Grubu adı | [optional] 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="maillistgroupsiddelete"></a>
# **MaillistGroupsIdDelete**
> void MaillistGroupsIdDelete (int? id)

Mail Listesi Grubu Silme

Kalıcı olarak ilgili Mail Listesi Grubunu siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MaillistGroupsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MaillistGroupApi();
            var id = 56;  // int? | Mail Listesi Grubu nesnesinin id değeri

            try
            {
                // Mail Listesi Grubu Silme
                apiInstance.MaillistGroupsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MaillistGroupApi.MaillistGroupsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Mail Listesi Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="maillistgroupsidget"></a>
# **MaillistGroupsIdGet**
> MaillistGroup MaillistGroupsIdGet (int? id)

Mail Listesi Grubu Alma

İlgili Mail Listesi Grubunu getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MaillistGroupsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MaillistGroupApi();
            var id = 56;  // int? | Mail Listesi Grubu nesnesinin id değeri

            try
            {
                // Mail Listesi Grubu Alma
                MaillistGroup result = apiInstance.MaillistGroupsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MaillistGroupApi.MaillistGroupsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Mail Listesi Grubu nesnesinin id değeri | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="maillistgroupsidput"></a>
# **MaillistGroupsIdPut**
> MaillistGroup MaillistGroupsIdPut (int? id, MaillistGroup maillistGroup)

Mail Listesi Grubu Güncelleme

İlgili Mail Listesi Grubunu günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MaillistGroupsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MaillistGroupApi();
            var id = 56;  // int? | Mail Listesi Grubu nesnesinin id değeri
            var maillistGroup = new MaillistGroup(); // MaillistGroup |  nesnesi

            try
            {
                // Mail Listesi Grubu Güncelleme
                MaillistGroup result = apiInstance.MaillistGroupsIdPut(id, maillistGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MaillistGroupApi.MaillistGroupsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Mail Listesi Grubu nesnesinin id değeri | 
 **maillistGroup** | [**MaillistGroup**](MaillistGroup.md)|  nesnesi | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="maillistgroupspost"></a>
# **MaillistGroupsPost**
> MaillistGroup MaillistGroupsPost (MaillistGroup maillistGroup)

Mail Listesi Grubu Oluşturma

Yeni bir Mail Listesi Grubu oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MaillistGroupsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new MaillistGroupApi();
            var maillistGroup = new MaillistGroup(); // MaillistGroup |  nesnesi

            try
            {
                // Mail Listesi Grubu Oluşturma
                MaillistGroup result = apiInstance.MaillistGroupsPost(maillistGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MaillistGroupApi.MaillistGroupsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **maillistGroup** | [**MaillistGroup**](MaillistGroup.md)|  nesnesi | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

