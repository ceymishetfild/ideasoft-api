# IO.Swagger.Model.ProductComment
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ürün yorumu nesnesi kimlik değeri. | [optional] 
**Title** | **string** | Ürün yorumu başlığı. | 
**Content** | **string** | Ürün yorumu içeriği. | 
**Status** | **bool?** | Ürün yorumu durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**Rank** | **int?** | Ürün yorumunda ürüne verilen puan.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 1 puan.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : 2 puan.&lt;br&gt;&lt;code&gt;3&lt;/code&gt; : 3 puan.&lt;br&gt;&lt;code&gt;4&lt;/code&gt; : 4 puan.&lt;br&gt;&lt;code&gt;5&lt;/code&gt; : 5 puan.&lt;br&gt;&lt;/div&gt; | 
**IsAnonymous** | **bool?** | Ürün yorumu yapan kişinin anonim olup olmadığı bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Anonim.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Anonim değil.&lt;br&gt;&lt;/div&gt; | 
**CreatedAt** | **DateTime?** | Ürün yorumu nesnesinin oluşturulma zamanı. | [optional] 
**UpdatedAt** | **DateTime?** | Ürün yorumu nesnesinin güncellenme zamanı. | [optional] 
**Member** | [**Member**](Member.md) | Yorumu yapan üye. | [optional] 
**Product** | [**Product**](Product.md) | Yorum yapılan ürün. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

