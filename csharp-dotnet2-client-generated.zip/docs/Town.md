# IO.Swagger.Model.Town
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | İlçe nesnesi kimlik değeri. | [optional] 
**Name** | **string** | İlçe nesnesi için isim değeri. | 
**Status** | **string** | İlçenin aktiflik bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**Location** | [**Location**](Location.md) | Şehir nesnesi. | [optional] 
**TownGroup** | [**TownGroup**](TownGroup.md) | İlçe grubu nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

