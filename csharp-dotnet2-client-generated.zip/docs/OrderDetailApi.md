# IO.Swagger.Api.OrderDetailApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**OrderDetailsGet**](OrderDetailApi.md#orderdetailsget) | **GET** /order_details | Sipariş Detayı Listesi Alma
[**OrderDetailsIdDelete**](OrderDetailApi.md#orderdetailsiddelete) | **DELETE** /order_details/{id} | Sipariş Detayı Silme
[**OrderDetailsIdGet**](OrderDetailApi.md#orderdetailsidget) | **GET** /order_details/{id} | Sipariş Detayı Alma
[**OrderDetailsIdPut**](OrderDetailApi.md#orderdetailsidput) | **PUT** /order_details/{id} | Sipariş Detayı Güncelleme
[**OrderDetailsPost**](OrderDetailApi.md#orderdetailspost) | **POST** /order_details | Sipariş Detayı Oluşturma


<a name="orderdetailsget"></a>
# **OrderDetailsGet**
> OrderDetail OrderDetailsGet (string sort, int? limit, int? page, int? sinceId, int? order)

Sipariş Detayı Listesi Alma

Sipariş Detayı listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderDetailsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderDetailApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var order = 56;  // int? | Sipariş id (optional) 

            try
            {
                // Sipariş Detayı Listesi Alma
                OrderDetail result = apiInstance.OrderDetailsGet(sort, limit, page, sinceId, order);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderDetailApi.OrderDetailsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **int?**| Sipariş id | [optional] 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderdetailsiddelete"></a>
# **OrderDetailsIdDelete**
> void OrderDetailsIdDelete (int? id)

Sipariş Detayı Silme

Kalıcı olarak ilgili Sipariş Detayı siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderDetailsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderDetailApi();
            var id = 56;  // int? | Sipariş Detayı nesnesinin id değeri

            try
            {
                // Sipariş Detayı Silme
                apiInstance.OrderDetailsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderDetailApi.OrderDetailsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş Detayı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderdetailsidget"></a>
# **OrderDetailsIdGet**
> OrderDetail OrderDetailsIdGet (int? id)

Sipariş Detayı Alma

İlgili Sipariş Detayı getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderDetailsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderDetailApi();
            var id = 56;  // int? | Sipariş Detayı nesnesinin id değeri

            try
            {
                // Sipariş Detayı Alma
                OrderDetail result = apiInstance.OrderDetailsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderDetailApi.OrderDetailsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş Detayı nesnesinin id değeri | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderdetailsidput"></a>
# **OrderDetailsIdPut**
> OrderDetail OrderDetailsIdPut (int? id, OrderDetail orderDetail)

Sipariş Detayı Güncelleme

İlgili Sipariş Detayı günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderDetailsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderDetailApi();
            var id = 56;  // int? | Sipariş Detayı nesnesinin id değeri
            var orderDetail = new OrderDetail(); // OrderDetail | OrderDetail nesnesi

            try
            {
                // Sipariş Detayı Güncelleme
                OrderDetail result = apiInstance.OrderDetailsIdPut(id, orderDetail);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderDetailApi.OrderDetailsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş Detayı nesnesinin id değeri | 
 **orderDetail** | [**OrderDetail**](OrderDetail.md)| OrderDetail nesnesi | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderdetailspost"></a>
# **OrderDetailsPost**
> OrderDetail OrderDetailsPost (OrderDetail orderDetail)

Sipariş Detayı Oluşturma

Yeni bir Sipariş Detayı oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderDetailsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderDetailApi();
            var orderDetail = new OrderDetail(); // OrderDetail | OrderDetail nesnesi

            try
            {
                // Sipariş Detayı Oluşturma
                OrderDetail result = apiInstance.OrderDetailsPost(orderDetail);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderDetailApi.OrderDetailsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orderDetail** | [**OrderDetail**](OrderDetail.md)| OrderDetail nesnesi | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

