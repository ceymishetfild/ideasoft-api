# IO.Swagger.Api.CartItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CartItemsIdDelete**](CartItemApi.md#cartitemsiddelete) | **DELETE** /cart_items/{id} | Sepet Kalemi Silme
[**CartItemsIdPut**](CartItemApi.md#cartitemsidput) | **PUT** /cart_items/{id} | Sepet Kalemi Güncelleme
[**CartItemsPost**](CartItemApi.md#cartitemspost) | **POST** /cart_items | Sepet Kalemi Oluşturma


<a name="cartitemsiddelete"></a>
# **CartItemsIdDelete**
> void CartItemsIdDelete (int? id)

Sepet Kalemi Silme

Kalıcı olarak ilgili Sepet Kalemini siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CartItemsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CartItemApi();
            var id = 56;  // int? | Sepet Kalemi nesnesinin id değeri

            try
            {
                // Sepet Kalemi Silme
                apiInstance.CartItemsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CartItemApi.CartItemsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sepet Kalemi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="cartitemsidput"></a>
# **CartItemsIdPut**
> CartItem CartItemsIdPut (int? id)

Sepet Kalemi Güncelleme

İlgili Sepet Kalemini günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CartItemsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CartItemApi();
            var id = 56;  // int? | Sepet Kalemi nesnesinin id değeri

            try
            {
                // Sepet Kalemi Güncelleme
                CartItem result = apiInstance.CartItemsIdPut(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CartItemApi.CartItemsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sepet Kalemi nesnesinin id değeri | 

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="cartitemspost"></a>
# **CartItemsPost**
> CartItem CartItemsPost (CartItem cartItem)

Sepet Kalemi Oluşturma

Yeni bir Sepet Kalemi oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CartItemsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CartItemApi();
            var cartItem = new CartItem(); // CartItem | CartItem nesnesi

            try
            {
                // Sepet Kalemi Oluşturma
                CartItem result = apiInstance.CartItemsPost(cartItem);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CartItemApi.CartItemsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartItem** | [**CartItem**](CartItem.md)| CartItem nesnesi | 

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

