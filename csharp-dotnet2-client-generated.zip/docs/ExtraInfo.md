# IO.Swagger.Model.ExtraInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ek bilgi nesnesi kimlik değeri. | [optional] 
**Name** | **string** | Ek bilgi nesnesi için isim değeri. | 
**SortOrder** | **int?** | Ek bilgi nesnesi için sıralama değeri. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

