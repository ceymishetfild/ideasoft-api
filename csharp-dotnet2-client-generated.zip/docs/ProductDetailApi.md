# IO.Swagger.Api.ProductDetailApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductDetailsGet**](ProductDetailApi.md#productdetailsget) | **GET** /product_details | Ürün Detay Listesi Alma
[**ProductDetailsIdDelete**](ProductDetailApi.md#productdetailsiddelete) | **DELETE** /product_details/{id} | Ürün Detay Silme
[**ProductDetailsIdGet**](ProductDetailApi.md#productdetailsidget) | **GET** /product_details/{id} | Ürün Detay Alma
[**ProductDetailsIdPut**](ProductDetailApi.md#productdetailsidput) | **PUT** /product_details/{id} | Ürün Detay Güncelleme
[**ProductDetailsPost**](ProductDetailApi.md#productdetailspost) | **POST** /product_details | Ürün Detay Oluşturma


<a name="productdetailsget"></a>
# **ProductDetailsGet**
> ProductDetail ProductDetailsGet (string sort, int? limit, int? page, int? sinceId, string ids, string sku)

Ürün Detay Listesi Alma

Ürün Detay listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductDetailsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductDetailApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var sku = sku_example;  // string | Ürün stok kodu (optional) 

            try
            {
                // Ürün Detay Listesi Alma
                ProductDetail result = apiInstance.ProductDetailsGet(sort, limit, page, sinceId, ids, sku);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductDetailApi.ProductDetailsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **sku** | **string**| Ürün stok kodu | [optional] 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productdetailsiddelete"></a>
# **ProductDetailsIdDelete**
> void ProductDetailsIdDelete (int? id)

Ürün Detay Silme

Kalıcı olarak ilgili Ürün Detayını siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductDetailsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductDetailApi();
            var id = 56;  // int? | Ürün Detay nesnesinin id değeri

            try
            {
                // Ürün Detay Silme
                apiInstance.ProductDetailsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductDetailApi.ProductDetailsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Detay nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productdetailsidget"></a>
# **ProductDetailsIdGet**
> ProductDetail ProductDetailsIdGet (int? id)

Ürün Detay Alma

İlgili Ürün Detayını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductDetailsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductDetailApi();
            var id = 56;  // int? | Ürün Detay nesnesinin id değeri

            try
            {
                // Ürün Detay Alma
                ProductDetail result = apiInstance.ProductDetailsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductDetailApi.ProductDetailsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Detay nesnesinin id değeri | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productdetailsidput"></a>
# **ProductDetailsIdPut**
> ProductDetail ProductDetailsIdPut (int? id, ProductDetail productDetail)

Ürün Detay Güncelleme

İlgili Ürün Detayını günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductDetailsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductDetailApi();
            var id = 56;  // int? | Ürün Detay nesnesinin id değeri
            var productDetail = new ProductDetail(); // ProductDetail |  nesnesi

            try
            {
                // Ürün Detay Güncelleme
                ProductDetail result = apiInstance.ProductDetailsIdPut(id, productDetail);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductDetailApi.ProductDetailsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Detay nesnesinin id değeri | 
 **productDetail** | [**ProductDetail**](ProductDetail.md)|  nesnesi | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="productdetailspost"></a>
# **ProductDetailsPost**
> ProductDetail ProductDetailsPost (ProductDetail productDetail)

Ürün Detay Oluşturma

Yeni bir Ürün Detay oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductDetailsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductDetailApi();
            var productDetail = new ProductDetail(); // ProductDetail |  nesnesi

            try
            {
                // Ürün Detay Oluşturma
                ProductDetail result = apiInstance.ProductDetailsPost(productDetail);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductDetailApi.ProductDetailsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productDetail** | [**ProductDetail**](ProductDetail.md)|  nesnesi | 

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

