# IO.Swagger.Api.ProductToCountDownApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ProductToCountDownsGet**](ProductToCountDownApi.md#producttocountdownsget) | **GET** /product_to_count_downs | Ürün Geri Sayım Bağı Listesi Alma
[**ProductToCountDownsIdDelete**](ProductToCountDownApi.md#producttocountdownsiddelete) | **DELETE** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Silme
[**ProductToCountDownsIdGet**](ProductToCountDownApi.md#producttocountdownsidget) | **GET** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Alma
[**ProductToCountDownsIdPut**](ProductToCountDownApi.md#producttocountdownsidput) | **PUT** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Güncelleme
[**ProductToCountDownsPost**](ProductToCountDownApi.md#producttocountdownspost) | **POST** /product_to_count_downs | Ürün Geri Sayım Bağı Oluşturma


<a name="producttocountdownsget"></a>
# **ProductToCountDownsGet**
> ProductToCountDown ProductToCountDownsGet (string sort, int? limit, int? page, int? sinceId, int? product)

Ürün Geri Sayım Bağı Listesi Alma

Ürün Geri Sayım Bağı listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductToCountDownsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductToCountDownApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var product = 56;  // int? | Ürün id (optional) 

            try
            {
                // Ürün Geri Sayım Bağı Listesi Alma
                ProductToCountDown result = apiInstance.ProductToCountDownsGet(sort, limit, page, sinceId, product);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductToCountDownApi.ProductToCountDownsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **product** | **int?**| Ürün id | [optional] 

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="producttocountdownsiddelete"></a>
# **ProductToCountDownsIdDelete**
> void ProductToCountDownsIdDelete (int? id)

Ürün Geri Sayım Bağı Silme

Kalıcı olarak ilgili Ürün Geri Sayım Bağını siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductToCountDownsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductToCountDownApi();
            var id = 56;  // int? | Ürün Geri Sayım Bağı nesnesinin id değeri

            try
            {
                // Ürün Geri Sayım Bağı Silme
                apiInstance.ProductToCountDownsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductToCountDownApi.ProductToCountDownsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Geri Sayım Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="producttocountdownsidget"></a>
# **ProductToCountDownsIdGet**
> ProductToCountDown ProductToCountDownsIdGet (int? id)

Ürün Geri Sayım Bağı Alma

İlgili Ürün Geri Sayım Bağını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductToCountDownsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductToCountDownApi();
            var id = 56;  // int? | Ürün Geri Sayım Bağı nesnesinin id değeri

            try
            {
                // Ürün Geri Sayım Bağı Alma
                ProductToCountDown result = apiInstance.ProductToCountDownsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductToCountDownApi.ProductToCountDownsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Geri Sayım Bağı nesnesinin id değeri | 

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="producttocountdownsidput"></a>
# **ProductToCountDownsIdPut**
> ProductToCountDown ProductToCountDownsIdPut (int? id, ProductToCountDown productToCountDown)

Ürün Geri Sayım Bağı Güncelleme

İlgili Ürün Geri Sayım Bağını günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductToCountDownsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductToCountDownApi();
            var id = 56;  // int? | Ürün Geri Sayım Bağı nesnesinin id değeri
            var productToCountDown = new ProductToCountDown(); // ProductToCountDown | ProductToCountDown nesnesi

            try
            {
                // Ürün Geri Sayım Bağı Güncelleme
                ProductToCountDown result = apiInstance.ProductToCountDownsIdPut(id, productToCountDown);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductToCountDownApi.ProductToCountDownsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Geri Sayım Bağı nesnesinin id değeri | 
 **productToCountDown** | [**ProductToCountDown**](ProductToCountDown.md)| ProductToCountDown nesnesi | 

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="producttocountdownspost"></a>
# **ProductToCountDownsPost**
> ProductToCountDown ProductToCountDownsPost (ProductToCountDown productToCountDown)

Ürün Geri Sayım Bağı Oluşturma

Yeni bir Ürün Geri Sayım Bağı oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ProductToCountDownsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ProductToCountDownApi();
            var productToCountDown = new ProductToCountDown(); // ProductToCountDown | ProductToCountDown nesnesi

            try
            {
                // Ürün Geri Sayım Bağı Oluşturma
                ProductToCountDown result = apiInstance.ProductToCountDownsPost(productToCountDown);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ProductToCountDownApi.ProductToCountDownsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productToCountDown** | [**ProductToCountDown**](ProductToCountDown.md)| ProductToCountDown nesnesi | 

### Return type

[**ProductToCountDown**](ProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

