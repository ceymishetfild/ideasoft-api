# IO.Swagger.Api.CartApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CartsIdDelete**](CartApi.md#cartsiddelete) | **DELETE** /carts/{id} | Sepet Silme
[**CartsIdGet**](CartApi.md#cartsidget) | **GET** /carts/{id} | Sepet Alma
[**CartsPost**](CartApi.md#cartspost) | **POST** /carts | Sepet Oluşturma


<a name="cartsiddelete"></a>
# **CartsIdDelete**
> void CartsIdDelete (int? id)

Sepet Silme

Kalıcı olarak ilgili Sepeti siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CartsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CartApi();
            var id = 56;  // int? | Sepet nesnesinin id değeri

            try
            {
                // Sepet Silme
                apiInstance.CartsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CartApi.CartsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sepet nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="cartsidget"></a>
# **CartsIdGet**
> Cart CartsIdGet (int? id)

Sepet Alma

İlgili Sepet getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CartsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CartApi();
            var id = 56;  // int? | Sepet nesnesinin id değeri

            try
            {
                // Sepet Alma
                Cart result = apiInstance.CartsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CartApi.CartsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sepet nesnesinin id değeri | 

### Return type

[**Cart**](Cart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="cartspost"></a>
# **CartsPost**
> Cart CartsPost (Cart cart)

Sepet Oluşturma

Yeni bir Sepet oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CartsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new CartApi();
            var cart = new Cart(); // Cart | Cart nesnesi

            try
            {
                // Sepet Oluşturma
                Cart result = apiInstance.CartsPost(cart);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CartApi.CartsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart** | [**Cart**](Cart.md)| Cart nesnesi | 

### Return type

[**Cart**](Cart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

