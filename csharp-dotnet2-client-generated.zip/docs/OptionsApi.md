# IO.Swagger.Api.OptionsApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**OptionsGet**](OptionsApi.md#optionsget) | **GET** /options | Varyant Listesi Alma
[**OptionsIdDelete**](OptionsApi.md#optionsiddelete) | **DELETE** /options/{id} | Varyant Silme
[**OptionsIdGet**](OptionsApi.md#optionsidget) | **GET** /options/{id} | Varyant Alma
[**OptionsIdPut**](OptionsApi.md#optionsidput) | **PUT** /options/{id} | Varyant Güncelleme
[**OptionsPost**](OptionsApi.md#optionspost) | **POST** /options | Varyant Oluşturma


<a name="optionsget"></a>
# **OptionsGet**
> Options OptionsGet (string sort, int? limit, int? page, int? sinceId, string ids, string title, int? optionGroup)

Varyant Listesi Alma

Varyant listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OptionsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OptionsApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var title = title_example;  // string | Varyant başlığı (optional) 
            var optionGroup = 56;  // int? | Varyant Grubu id (optional) 

            try
            {
                // Varyant Listesi Alma
                Options result = apiInstance.OptionsGet(sort, limit, page, sinceId, ids, title, optionGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OptionsApi.OptionsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **title** | **string**| Varyant başlığı | [optional] 
 **optionGroup** | **int?**| Varyant Grubu id | [optional] 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="optionsiddelete"></a>
# **OptionsIdDelete**
> void OptionsIdDelete (int? id)

Varyant Silme

Kalıcı olarak ilgili Varyantı siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OptionsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OptionsApi();
            var id = 56;  // int? | Varyant nesnesinin id değeri

            try
            {
                // Varyant Silme
                apiInstance.OptionsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OptionsApi.OptionsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Varyant nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="optionsidget"></a>
# **OptionsIdGet**
> Options OptionsIdGet (int? id)

Varyant Alma

İlgili Varyantı getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OptionsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OptionsApi();
            var id = 56;  // int? | Varyant nesnesinin id değeri

            try
            {
                // Varyant Alma
                Options result = apiInstance.OptionsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OptionsApi.OptionsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Varyant nesnesinin id değeri | 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="optionsidput"></a>
# **OptionsIdPut**
> Options OptionsIdPut (int? id, Options options)

Varyant Güncelleme

İlgili Varyantı günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OptionsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OptionsApi();
            var id = 56;  // int? | Varyant nesnesinin id değeri
            var options = new Options(); // Options |  nesnesi

            try
            {
                // Varyant Güncelleme
                Options result = apiInstance.OptionsIdPut(id, options);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OptionsApi.OptionsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Varyant nesnesinin id değeri | 
 **options** | [**Options**](Options.md)|  nesnesi | 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="optionspost"></a>
# **OptionsPost**
> Options OptionsPost (Options options)

Varyant Oluşturma

Yeni bir Varyant oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OptionsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OptionsApi();
            var options = new Options(); // Options |  nesnesi

            try
            {
                // Varyant Oluşturma
                Options result = apiInstance.OptionsPost(options);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OptionsApi.OptionsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **options** | [**Options**](Options.md)|  nesnesi | 

### Return type

[**Options**](Options.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

