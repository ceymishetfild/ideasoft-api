# IO.Swagger.Api.OrderItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**OrderItemsGet**](OrderItemApi.md#orderitemsget) | **GET** /order_items | Sipariş Kalemi Listesi Alma
[**OrderItemsIdGet**](OrderItemApi.md#orderitemsidget) | **GET** /order_items/{id} | Sipariş Kalemi Alma


<a name="orderitemsget"></a>
# **OrderItemsGet**
> OrderItem OrderItemsGet (string sort, int? limit, int? page, int? sinceId, int? order, string productName, string productSku, string productBarcode, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)

Sipariş Kalemi Listesi Alma

Sipariş Kalemi listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderItemsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderItemApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var order = 56;  // int? | Sipariş id (optional) 
            var productName = productName_example;  // string | Ürün adı (optional) 
            var productSku = productSku_example;  // string | Ürün stok kodu (optional) 
            var productBarcode = productBarcode_example;  // string | Ürün barkodu (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 

            try
            {
                // Sipariş Kalemi Listesi Alma
                OrderItem result = apiInstance.OrderItemsGet(sort, limit, page, sinceId, order, productName, productSku, productBarcode, startDate, endDate, startUpdatedAt, endUpdatedAt);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderItemApi.OrderItemsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **int?**| Sipariş id | [optional] 
 **productName** | **string**| Ürün adı | [optional] 
 **productSku** | **string**| Ürün stok kodu | [optional] 
 **productBarcode** | **string**| Ürün barkodu | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**OrderItem**](OrderItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderitemsidget"></a>
# **OrderItemsIdGet**
> OrderItem OrderItemsIdGet (int? id)

Sipariş Kalemi Alma

İlgili Sipariş Kalemini getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderItemsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderItemApi();
            var id = 56;  // int? | Sipariş Kalemi nesnesinin id değeri

            try
            {
                // Sipariş Kalemi Alma
                OrderItem result = apiInstance.OrderItemsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderItemApi.OrderItemsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş Kalemi nesnesinin id değeri | 

### Return type

[**OrderItem**](OrderItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

