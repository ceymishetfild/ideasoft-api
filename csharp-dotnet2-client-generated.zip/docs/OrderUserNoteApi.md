# IO.Swagger.Api.OrderUserNoteApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**OrderUserNotesGet**](OrderUserNoteApi.md#orderusernotesget) | **GET** /order_user_notes | Sipariş Yönetici Notu Listesi Alma
[**OrderUserNotesIdDelete**](OrderUserNoteApi.md#orderusernotesiddelete) | **DELETE** /order_user_notes/{id} | Sipariş Yönetici Notu Silme
[**OrderUserNotesIdGet**](OrderUserNoteApi.md#orderusernotesidget) | **GET** /order_user_notes/{id} | Sipariş Yönetici Notu Alma
[**OrderUserNotesIdPut**](OrderUserNoteApi.md#orderusernotesidput) | **PUT** /order_user_notes/{id} | Sipariş Yönetici Notu Güncelleme
[**OrderUserNotesPost**](OrderUserNoteApi.md#orderusernotespost) | **POST** /order_user_notes | Sipariş Yönetici Notu Oluşturma


<a name="orderusernotesget"></a>
# **OrderUserNotesGet**
> OrderUserNote OrderUserNotesGet (string sort, int? limit, int? page, int? sinceId, int? order, string userEmail, DateTime? startDate, string endDate, DateTime? startUpdatedAt, string endUpdatedAt)

Sipariş Yönetici Notu Listesi Alma

Sipariş Yönetici Notu listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderUserNotesGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderUserNoteApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var order = 56;  // int? | Sipariş id (optional) 
            var userEmail = userEmail_example;  // string | Yönetici e-mail (optional) 
            var startDate = 2013-10-20;  // DateTime? | createdAt değeri için başlangıç tarihi (optional) 
            var endDate = endDate_example;  // string | createdAt değeri için bitiş tarihi (optional) 
            var startUpdatedAt = 2013-10-20;  // DateTime? | updatedAt değeri için başlangıç tarihi (optional) 
            var endUpdatedAt = endUpdatedAt_example;  // string | updatedAt değeri için bitiş tarihi (optional) 

            try
            {
                // Sipariş Yönetici Notu Listesi Alma
                OrderUserNote result = apiInstance.OrderUserNotesGet(sort, limit, page, sinceId, order, userEmail, startDate, endDate, startUpdatedAt, endUpdatedAt);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderUserNoteApi.OrderUserNotesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **int?**| Sipariş id | [optional] 
 **userEmail** | **string**| Yönetici e-mail | [optional] 
 **startDate** | **DateTime?**| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **string**| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **DateTime?**| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **string**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderusernotesiddelete"></a>
# **OrderUserNotesIdDelete**
> void OrderUserNotesIdDelete (int? id)

Sipariş Yönetici Notu Silme

Kalıcı olarak ilgili Sipariş Yönetici Notunu siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderUserNotesIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderUserNoteApi();
            var id = 56;  // int? | Sipariş Yönetici Notu nesnesinin id değeri

            try
            {
                // Sipariş Yönetici Notu Silme
                apiInstance.OrderUserNotesIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderUserNoteApi.OrderUserNotesIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş Yönetici Notu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderusernotesidget"></a>
# **OrderUserNotesIdGet**
> OrderUserNote OrderUserNotesIdGet (int? id)

Sipariş Yönetici Notu Alma

İlgili Sipariş Yönetici Notunu getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderUserNotesIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderUserNoteApi();
            var id = 56;  // int? | Sipariş Yönetici Notu nesnesinin id değeri

            try
            {
                // Sipariş Yönetici Notu Alma
                OrderUserNote result = apiInstance.OrderUserNotesIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderUserNoteApi.OrderUserNotesIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş Yönetici Notu nesnesinin id değeri | 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderusernotesidput"></a>
# **OrderUserNotesIdPut**
> OrderUserNote OrderUserNotesIdPut (int? id, OrderUserNote orderUserNote)

Sipariş Yönetici Notu Güncelleme

İlgili Sipariş Yönetici Notunu günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderUserNotesIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderUserNoteApi();
            var id = 56;  // int? | Sipariş Yönetici Notu nesnesinin id değeri
            var orderUserNote = new OrderUserNote(); // OrderUserNote | OrderUserNote nesnesi

            try
            {
                // Sipariş Yönetici Notu Güncelleme
                OrderUserNote result = apiInstance.OrderUserNotesIdPut(id, orderUserNote);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderUserNoteApi.OrderUserNotesIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Sipariş Yönetici Notu nesnesinin id değeri | 
 **orderUserNote** | [**OrderUserNote**](OrderUserNote.md)| OrderUserNote nesnesi | 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="orderusernotespost"></a>
# **OrderUserNotesPost**
> OrderUserNote OrderUserNotesPost (OrderUserNote orderUserNote)

Sipariş Yönetici Notu Oluşturma

Yeni bir Sipariş Yönetici Notu oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderUserNotesPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OrderUserNoteApi();
            var orderUserNote = new OrderUserNote(); // OrderUserNote | OrderUserNote nesnesi

            try
            {
                // Sipariş Yönetici Notu Oluşturma
                OrderUserNote result = apiInstance.OrderUserNotesPost(orderUserNote);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OrderUserNoteApi.OrderUserNotesPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orderUserNote** | [**OrderUserNote**](OrderUserNote.md)| OrderUserNote nesnesi | 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

