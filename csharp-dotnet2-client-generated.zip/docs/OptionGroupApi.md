# IO.Swagger.Api.OptionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**OptionGroupsGet**](OptionGroupApi.md#optiongroupsget) | **GET** /option_groups | Varyant Grubu Listesi Alma
[**OptionGroupsIdDelete**](OptionGroupApi.md#optiongroupsiddelete) | **DELETE** /option_groups/{id} | Varyant Grubu Silme
[**OptionGroupsIdGet**](OptionGroupApi.md#optiongroupsidget) | **GET** /option_groups/{id} | Varyant Grubu Alma
[**OptionGroupsIdPut**](OptionGroupApi.md#optiongroupsidput) | **PUT** /option_groups/{id} | Varyant Grubu Güncelleme
[**OptionGroupsPost**](OptionGroupApi.md#optiongroupspost) | **POST** /option_groups | Varyant Grubu Oluşturma


<a name="optiongroupsget"></a>
# **OptionGroupsGet**
> OptionGroup OptionGroupsGet (string sort, int? limit, int? page, int? sinceId, string title)

Varyant Grubu Listesi Alma

Varyant Grubu listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OptionGroupsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OptionGroupApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var title = title_example;  // string | Varyant Grubu başlığı. (optional) 

            try
            {
                // Varyant Grubu Listesi Alma
                OptionGroup result = apiInstance.OptionGroupsGet(sort, limit, page, sinceId, title);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OptionGroupApi.OptionGroupsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **title** | **string**| Varyant Grubu başlığı. | [optional] 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="optiongroupsiddelete"></a>
# **OptionGroupsIdDelete**
> void OptionGroupsIdDelete (int? id)

Varyant Grubu Silme

Kalıcı olarak ilgili Varyant Grubunu siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OptionGroupsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OptionGroupApi();
            var id = 56;  // int? | Varyant Grubu nesnesinin id değeri

            try
            {
                // Varyant Grubu Silme
                apiInstance.OptionGroupsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OptionGroupApi.OptionGroupsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Varyant Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="optiongroupsidget"></a>
# **OptionGroupsIdGet**
> OptionGroup OptionGroupsIdGet (int? id)

Varyant Grubu Alma

İlgili Varyant Grubunu getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OptionGroupsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OptionGroupApi();
            var id = 56;  // int? | Varyant Grubu nesnesinin id değeri

            try
            {
                // Varyant Grubu Alma
                OptionGroup result = apiInstance.OptionGroupsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OptionGroupApi.OptionGroupsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Varyant Grubu nesnesinin id değeri | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="optiongroupsidput"></a>
# **OptionGroupsIdPut**
> OptionGroup OptionGroupsIdPut (int? id, OptionGroup optionGroup)

Varyant Grubu Güncelleme

İlgili Varyant Grubunu günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OptionGroupsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OptionGroupApi();
            var id = 56;  // int? | Varyant Grubu nesnesinin id değeri
            var optionGroup = new OptionGroup(); // OptionGroup | OptionGroup nesnesi

            try
            {
                // Varyant Grubu Güncelleme
                OptionGroup result = apiInstance.OptionGroupsIdPut(id, optionGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OptionGroupApi.OptionGroupsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Varyant Grubu nesnesinin id değeri | 
 **optionGroup** | [**OptionGroup**](OptionGroup.md)| OptionGroup nesnesi | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="optiongroupspost"></a>
# **OptionGroupsPost**
> OptionGroup OptionGroupsPost (OptionGroup optionGroup)

Varyant Grubu Oluşturma

Yeni bir Varyant Grubu oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OptionGroupsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new OptionGroupApi();
            var optionGroup = new OptionGroup(); // OptionGroup | OptionGroup nesnesi

            try
            {
                // Varyant Grubu Oluşturma
                OptionGroup result = apiInstance.OptionGroupsPost(optionGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling OptionGroupApi.OptionGroupsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **optionGroup** | [**OptionGroup**](OptionGroup.md)| OptionGroup nesnesi | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

