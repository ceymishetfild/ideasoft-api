# IO.Swagger.Model.Payment
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ödeme nesnesi kimlik değeri. | [optional] 
**MemberFirstname** | **string** | Üyenin ismi. | 
**MemberSurname** | **string** | Üyenin soy ismi. | 
**MemberEmail** | **string** | Üyenin e-mail adresi. | 
**MemberPhone** | **string** | Üyenin telefon numarası. | [optional] 
**PaymentTypeName** | **string** | Ödeme tipi | 
**PaymentProviderCode** | **string** | Ödeme hizmeti sağlayıcısı kodu. Bu değer ön tanımlıdır. | 
**PaymentProviderName** | **string** | Ödeme hizmeti sağlayıcısı adı. Bu değer ön tanımlıdır. | 
**PaymentGatewayName** | **string** | Ödeme kanalı adı. Bu değer ön tanımlıdır. | 
**PaymentGatewayCode** | **string** | Ödeme kanalı kodu. Bu değer ön tanımlıdır. | 
**BankName** | **string** | Ödeme yapılan banka. Bu değer ön tanımlıdır. | [optional] 
**DeviceType** | **string** | Ödemenin gerçekleştiği cihaz bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil&lt;br&gt;&lt;code&gt;tablet&lt;/code&gt; : Tablet&lt;br&gt;&lt;/div&gt; | 
**ClientIp** | **string** | Müşterinin IP adresi. | 
**CurrencyRates** | **string** | Kur oranları. | 
**Amount** | **float?** | Ödemenin saf fiyatı. | 
**FinalAmount** | **float?** | Ödemenin son fiyatı. | 
**SumOfGainedPoints** | **float?** | Ödemeden kazanılan toplam puan. | [optional] 
**Installment** | **int?** | Ödemenin standart taksit sayısı. | 
**InstallmentRate** | **float?** | Ödemenin taksit oranı. | 
**ExtraInstallment** | **int?** | Ödemenin ekstra taksit sayısı. | [optional] 
**Currency** | **string** | Kur bilgisi. | 
**TransactionId** | **string** | Siparişin numarası. | [optional] 
**MemberNote** | **string** | Müşterinin ödeme notu. | [optional] 
**UserNote** | **string** | Yönetici(admin) ödeme notu. | [optional] 
**Status** | **string** | Ödeme durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;/div&gt; | 
**ErrorMessage** | **string** | Ödemenin hata mesajı. | [optional] 
**CardSavingSystem** | **string** | Kart saklama sistemi. | [optional] 
**CreatedAt** | **DateTime?** | Ödeme nesnesinin oluşturulma zamanı. | [optional] 
**Member** | [**Member**](Member.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

