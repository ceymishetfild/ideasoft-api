# IO.Swagger.Api.SpecGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SpecGroupsGet**](SpecGroupApi.md#specgroupsget) | **GET** /spec_groups | Ürün Özellik Grubu Listesi Alma
[**SpecGroupsIdDelete**](SpecGroupApi.md#specgroupsiddelete) | **DELETE** /spec_groups/{id} | Ürün Özellik Grubu Silme
[**SpecGroupsIdGet**](SpecGroupApi.md#specgroupsidget) | **GET** /spec_groups/{id} | Ürün Özellik Grubu Alma
[**SpecGroupsIdPut**](SpecGroupApi.md#specgroupsidput) | **PUT** /spec_groups/{id} | Ürün Özellik Grubu Güncelleme
[**SpecGroupsPost**](SpecGroupApi.md#specgroupspost) | **POST** /spec_groups | Ürün Özellik Grubu Oluşturma


<a name="specgroupsget"></a>
# **SpecGroupsGet**
> SpecGroup SpecGroupsGet (string sort, int? limit, int? page, int? sinceId, string name)

Ürün Özellik Grubu Listesi Alma

Ürün Özellik Grubu listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecGroupsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecGroupApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var name = name_example;  // string | Ürün Özellik Grubu adı (optional) 

            try
            {
                // Ürün Özellik Grubu Listesi Alma
                SpecGroup result = apiInstance.SpecGroupsGet(sort, limit, page, sinceId, name);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecGroupApi.SpecGroupsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **string**| Ürün Özellik Grubu adı | [optional] 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="specgroupsiddelete"></a>
# **SpecGroupsIdDelete**
> void SpecGroupsIdDelete (int? id)

Ürün Özellik Grubu Silme

Kalıcı olarak ilgili Ürün Özellik Grubunu siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecGroupsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecGroupApi();
            var id = 56;  // int? | Ürün Özellik Grubu nesnesinin id değeri

            try
            {
                // Ürün Özellik Grubu Silme
                apiInstance.SpecGroupsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecGroupApi.SpecGroupsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Özellik Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="specgroupsidget"></a>
# **SpecGroupsIdGet**
> SpecGroup SpecGroupsIdGet (int? id)

Ürün Özellik Grubu Alma

İlgili Ürün Özellik Grubunu getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecGroupsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecGroupApi();
            var id = 56;  // int? | Ürün Özellik Grubu nesnesinin id değeri

            try
            {
                // Ürün Özellik Grubu Alma
                SpecGroup result = apiInstance.SpecGroupsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecGroupApi.SpecGroupsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Özellik Grubu nesnesinin id değeri | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="specgroupsidput"></a>
# **SpecGroupsIdPut**
> SpecGroup SpecGroupsIdPut (int? id, SpecGroup specGroup)

Ürün Özellik Grubu Güncelleme

İlgili Ürün Özellik Grubunu günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecGroupsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecGroupApi();
            var id = 56;  // int? | Ürün Özellik Grubu nesnesinin id değeri
            var specGroup = new SpecGroup(); // SpecGroup | SpecGroup nesnesi

            try
            {
                // Ürün Özellik Grubu Güncelleme
                SpecGroup result = apiInstance.SpecGroupsIdPut(id, specGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecGroupApi.SpecGroupsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Ürün Özellik Grubu nesnesinin id değeri | 
 **specGroup** | [**SpecGroup**](SpecGroup.md)| SpecGroup nesnesi | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="specgroupspost"></a>
# **SpecGroupsPost**
> SpecGroup SpecGroupsPost (SpecGroup specGroup)

Ürün Özellik Grubu Oluşturma

Yeni bir Ürün Özellik Grubu oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SpecGroupsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new SpecGroupApi();
            var specGroup = new SpecGroup(); // SpecGroup | SpecGroup nesnesi

            try
            {
                // Ürün Özellik Grubu Oluşturma
                SpecGroup result = apiInstance.SpecGroupsPost(specGroup);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SpecGroupApi.SpecGroupsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specGroup** | [**SpecGroup**](SpecGroup.md)| SpecGroup nesnesi | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

