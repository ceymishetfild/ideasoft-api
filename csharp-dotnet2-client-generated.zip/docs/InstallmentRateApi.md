# IO.Swagger.Api.InstallmentRateApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**InstallmentRatesGet**](InstallmentRateApi.md#installmentratesget) | **GET** /installment_rates | Taksit Oranı Listesi Alma
[**InstallmentRatesIdGet**](InstallmentRateApi.md#installmentratesidget) | **GET** /installment_rates/{id} | Taksit Oranı Alma


<a name="installmentratesget"></a>
# **InstallmentRatesGet**
> InstallmentRate InstallmentRatesGet (string sort, int? limit, int? page, int? sinceId, string ids, int? paymentGateway)

Taksit Oranı Listesi Alma

Taksit Oranı listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class InstallmentRatesGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstallmentRateApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var paymentGateway = 56;  // int? | Ödeme Kanalı id (optional) 

            try
            {
                // Taksit Oranı Listesi Alma
                InstallmentRate result = apiInstance.InstallmentRatesGet(sort, limit, page, sinceId, ids, paymentGateway);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstallmentRateApi.InstallmentRatesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **paymentGateway** | **int?**| Ödeme Kanalı id | [optional] 

### Return type

[**InstallmentRate**](InstallmentRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="installmentratesidget"></a>
# **InstallmentRatesIdGet**
> InstallmentRate InstallmentRatesIdGet (int? id)

Taksit Oranı Alma

İlgili Taksit Oranını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class InstallmentRatesIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new InstallmentRateApi();
            var id = 56;  // int? | Taksit Oranı nesnesinin id değeri

            try
            {
                // Taksit Oranı Alma
                InstallmentRate result = apiInstance.InstallmentRatesIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling InstallmentRateApi.InstallmentRatesIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Taksit Oranı nesnesinin id değeri | 

### Return type

[**InstallmentRate**](InstallmentRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

