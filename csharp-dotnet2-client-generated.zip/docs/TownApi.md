# IO.Swagger.Api.TownApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**TownsGet**](TownApi.md#townsget) | **GET** /towns | İlçe Listesi Alma
[**TownsIdDelete**](TownApi.md#townsiddelete) | **DELETE** /towns/{id} | İlçe Silme
[**TownsIdGet**](TownApi.md#townsidget) | **GET** /towns/{id} | İlçe Alma
[**TownsIdPut**](TownApi.md#townsidput) | **PUT** /towns/{id} | İlçe Güncelleme
[**TownsPost**](TownApi.md#townspost) | **POST** /towns | İlçe Oluşturma


<a name="townsget"></a>
# **TownsGet**
> Town TownsGet (string sort, int? limit, int? page, int? sinceId, string ids, int? location, int? townGroup, string name, string status)

İlçe Listesi Alma

İlçe listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TownsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new TownApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var location = 56;  // int? | Şehir id (optional) 
            var townGroup = 56;  // int? | İlçe grubu id (optional) 
            var name = name_example;  // string | İlçe adı. (optional) 
            var status = status_example;  // string | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif (optional) 

            try
            {
                // İlçe Listesi Alma
                Town result = apiInstance.TownsGet(sort, limit, page, sinceId, ids, location, townGroup, name, status);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TownApi.TownsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **location** | **int?**| Şehir id | [optional] 
 **townGroup** | **int?**| İlçe grubu id | [optional] 
 **name** | **string**| İlçe adı. | [optional] 
 **status** | **string**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="townsiddelete"></a>
# **TownsIdDelete**
> void TownsIdDelete (int? id)

İlçe Silme

Kalıcı olarak ilgili İlçeyi siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TownsIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new TownApi();
            var id = 56;  // int? | İlçe nesnesinin id değeri

            try
            {
                // İlçe Silme
                apiInstance.TownsIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TownApi.TownsIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| İlçe nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="townsidget"></a>
# **TownsIdGet**
> Town TownsIdGet (int? id)

İlçe Alma

İlgili İlçeyi getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TownsIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new TownApi();
            var id = 56;  // int? | İlçe nesnesinin id değeri

            try
            {
                // İlçe Alma
                Town result = apiInstance.TownsIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TownApi.TownsIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| İlçe nesnesinin id değeri | 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="townsidput"></a>
# **TownsIdPut**
> Town TownsIdPut (int? id, Town town)

İlçe Güncelleme

İlgili İlçeyi günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TownsIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new TownApi();
            var id = 56;  // int? | İlçe nesnesinin id değeri
            var town = new Town(); // Town |  nesnesi

            try
            {
                // İlçe Güncelleme
                Town result = apiInstance.TownsIdPut(id, town);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TownApi.TownsIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| İlçe nesnesinin id değeri | 
 **town** | [**Town**](Town.md)|  nesnesi | 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="townspost"></a>
# **TownsPost**
> Town TownsPost (Town town)

İlçe Oluşturma

Yeni bir İlçe oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TownsPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new TownApi();
            var town = new Town(); // Town |  nesnesi

            try
            {
                // İlçe Oluşturma
                Town result = apiInstance.TownsPost(town);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TownApi.TownsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **town** | [**Town**](Town.md)|  nesnesi | 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

