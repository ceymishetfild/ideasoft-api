# IO.Swagger.Api.ShippingCompanyApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ShippingCompaniesGet**](ShippingCompanyApi.md#shippingcompaniesget) | **GET** /shipping_companies | Kargo Firması Listesi Alma
[**ShippingCompaniesIdDelete**](ShippingCompanyApi.md#shippingcompaniesiddelete) | **DELETE** /shipping_companies/{id} | Kargo Firması Silme
[**ShippingCompaniesIdGet**](ShippingCompanyApi.md#shippingcompaniesidget) | **GET** /shipping_companies/{id} | Kargo Firması Alma
[**ShippingCompaniesIdPut**](ShippingCompanyApi.md#shippingcompaniesidput) | **PUT** /shipping_companies/{id} | Kargo Firması Güncelleme
[**ShippingCompaniesPost**](ShippingCompanyApi.md#shippingcompaniespost) | **POST** /shipping_companies | Kargo Firması Oluşturma


<a name="shippingcompaniesget"></a>
# **ShippingCompaniesGet**
> ShippingCompany ShippingCompaniesGet (string sort, int? limit, int? page, int? sinceId, string ids, string name, string companyCode, string paymentType, int? shippingProvider)

Kargo Firması Listesi Alma

Kargo Firması listesini verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShippingCompaniesGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShippingCompanyApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional) 
            var ids = ids_example;  // string | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional) 
            var name = name_example;  // string | Kargo firması adı (optional) 
            var companyCode = companyCode_example;  // string | Kargo firması kodu (optional) 
            var paymentType = paymentType_example;  // string | Ödeme Tipi şu değerleri alabilir: <br><code>cash_on_delivery</code> : Alıcı ödemeli<br><code>standart_delivery</code> : Gönderici ödemeli<br><code>not_applicable</code> : Bu alan için uygulanabilir değil (optional) 
            var shippingProvider = 56;  // int? | Teslimat Hizmeti Sağlayıcısı id (optional) 

            try
            {
                // Kargo Firması Listesi Alma
                ShippingCompany result = apiInstance.ShippingCompaniesGet(sort, limit, page, sinceId, ids, name, companyCode, paymentType, shippingProvider);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShippingCompanyApi.ShippingCompaniesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **string**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **string**| Kargo firması adı | [optional] 
 **companyCode** | **string**| Kargo firması kodu | [optional] 
 **paymentType** | **string**| Ödeme Tipi şu değerleri alabilir: &lt;br&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil | [optional] 
 **shippingProvider** | **int?**| Teslimat Hizmeti Sağlayıcısı id | [optional] 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shippingcompaniesiddelete"></a>
# **ShippingCompaniesIdDelete**
> void ShippingCompaniesIdDelete (int? id)

Kargo Firması Silme

Kalıcı olarak ilgili Kargo Firmasını siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShippingCompaniesIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShippingCompanyApi();
            var id = 56;  // int? | Kargo Firması nesnesinin id değeri

            try
            {
                // Kargo Firması Silme
                apiInstance.ShippingCompaniesIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShippingCompanyApi.ShippingCompaniesIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Kargo Firması nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shippingcompaniesidget"></a>
# **ShippingCompaniesIdGet**
> ShippingCompany ShippingCompaniesIdGet (int? id)

Kargo Firması Alma

İlgili Kargo Firmasını getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShippingCompaniesIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShippingCompanyApi();
            var id = 56;  // int? | Kargo Firması nesnesinin id değeri

            try
            {
                // Kargo Firması Alma
                ShippingCompany result = apiInstance.ShippingCompaniesIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShippingCompanyApi.ShippingCompaniesIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Kargo Firması nesnesinin id değeri | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shippingcompaniesidput"></a>
# **ShippingCompaniesIdPut**
> ShippingCompany ShippingCompaniesIdPut (int? id, ShippingCompany shippingCompany)

Kargo Firması Güncelleme

İlgili Kargo Firmasını günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShippingCompaniesIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShippingCompanyApi();
            var id = 56;  // int? | Kargo Firması nesnesinin id değeri
            var shippingCompany = new ShippingCompany(); // ShippingCompany |  nesnesi

            try
            {
                // Kargo Firması Güncelleme
                ShippingCompany result = apiInstance.ShippingCompaniesIdPut(id, shippingCompany);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShippingCompanyApi.ShippingCompaniesIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Kargo Firması nesnesinin id değeri | 
 **shippingCompany** | [**ShippingCompany**](ShippingCompany.md)|  nesnesi | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="shippingcompaniespost"></a>
# **ShippingCompaniesPost**
> ShippingCompany ShippingCompaniesPost (ShippingCompany shippingCompany)

Kargo Firması Oluşturma

Yeni bir Kargo Firması oluşturur relationship.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ShippingCompaniesPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ShippingCompanyApi();
            var shippingCompany = new ShippingCompany(); // ShippingCompany |  nesnesi

            try
            {
                // Kargo Firması Oluşturma
                ShippingCompany result = apiInstance.ShippingCompaniesPost(shippingCompany);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ShippingCompanyApi.ShippingCompaniesPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shippingCompany** | [**ShippingCompany**](ShippingCompany.md)|  nesnesi | 

### Return type

[**ShippingCompany**](ShippingCompany.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

