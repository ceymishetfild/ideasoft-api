# IO.Swagger.Model.Product
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Ürün nesnesi kimlik değeri. | [optional] 
**Name** | **string** | Ürünün adı | 
**Slug** | **string** | Slug değeri ilgili nesnenin Url değeridir. | [optional] 
**FullName** | **string** | Ürünün tam adı. Bu değer bir varyant için ana ürünün adı ve varyant adının birleşiminden oluşur. Örneğin Kırmızı varyantı için Kalem Kırmızı olur. | 
**Sku** | **string** | Ürünün stok kodu. ID değeri gibi eşsiz bir kimlik değeridir. | 
**Barcode** | **string** | Ürünün barkodu. | [optional] 
**Price1** | **float?** | Ürünün Fiyat 1 bilgisi. | 
**Warranty** | **int?** | Ürünün garanti süresi. | [optional] 
**Tax** | **int?** | Ürünün KDV oranı. | [optional] 
**StockAmount** | **float?** | Ürünün stok tipi cinsinden miktarı. | [optional] 
**VolumetricWeight** | **float?** | Ürünün desisi. | [optional] 
**BuyingPrice** | **float?** | Ürünün alış fiyatı. | [optional] 
**StockTypeLabel** | **string** | Ürünün stok tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Piece&lt;/code&gt; : Stok tipi birimi Adet&lt;br&gt;&lt;code&gt;cm&lt;/code&gt; : Stok tipi birimi Santimetre&lt;br&gt;&lt;code&gt;Dozen&lt;/code&gt; : Stok tipi birimi Düzine&lt;br&gt;&lt;code&gt;gram&lt;/code&gt; : Stok tipi birimi Gram&lt;br&gt;&lt;code&gt;kg&lt;/code&gt; : Stok tipi birimi Kilogram&lt;br&gt;&lt;code&gt;Person&lt;/code&gt; : Stok tipi birimi Kişi&lt;br&gt;&lt;code&gt;Package&lt;/code&gt; : Stok tipi birimi Paket&lt;br&gt;&lt;code&gt;metre&lt;/code&gt; : Stok tipi birimi Metre&lt;br&gt;&lt;code&gt;m2&lt;/code&gt; : Stok tipi birimi Metrekare&lt;br&gt;&lt;code&gt;pair&lt;/code&gt; : Stok tipi birimi Çift&lt;br&gt;&lt;/div&gt; | [optional] 
**Discount** | **float?** | Ürünün indirim değeri. Örneğin; discountType 1 olursa %5, 0 olursa 5 tl anlamına gelir. | [optional] 
**DiscountType** | **int?** | Ürünün indirim tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : İndirim yüzdesi&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : İndirimli fiyat&lt;br&gt;&lt;/div&gt; | [optional] 
**MoneyOrderDiscount** | **float?** | Havale indirimi yüzdesi. | [optional] 
**Status** | **int?** | Ürün nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;/div&gt; | 
**TaxIncluded** | **string** | Ürün fiyatlarına KDV dahil olup olmadığın belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : KDV Dahil&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : KDV Hariç&lt;br&gt;&lt;/div&gt; | [optional] 
**Distributor** | **string** | Ürünün distribütör bilgisi | [optional] 
**IsGifted** | **string** | Ürünün hediyeli olup olmadığını belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hediyeli&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hediyeli Değil&lt;br&gt;&lt;/div&gt; | [optional] 
**Gift** | **string** | Ürünün yanında hediye olarak vermek istediğiniz hediyeyi bu alanda metin ya da rakamla belirtebilirsiniz. | [optional] 
**CustomShippingDisabled** | **string** | Kargo ücreti için sistemin kullanılıp kullanılmama değerini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sistem seçeneği seçili&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sistem seçeneği seçili değil&lt;br&gt;&lt;/div&gt; | [optional] 
**CustomShippingCost** | **float?** | Sistem seçeneği seçilmemişse ürün için girilmesi gereken kargo ücreti. | [optional] 
**MarketPriceDetail** | **string** | Ürünün piyasa fiyatı | [optional] 
**CreatedAt** | **DateTime?** | Ürün nesnesinin oluşturulma zamanı. | [optional] 
**UpdatedAt** | **DateTime?** | Ürün nesnesinin güncellenme zamanı. | [optional] 
**MetaKeywords** | **string** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] 
**MetaDescription** | **string** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] 
**PageTitle** | **string** | Ürün nesnesinin etiket başlığı. | [optional] 
**HasOption** | **string** | Ürünün varyantının olup olmadığı değerini belirtir. (API otomatik olarak bu değeri atar.)&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Varyantı var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Varyantı yok&lt;br&gt;&lt;/div&gt; | [optional] 
**ShortDetails** | **string** | Ürünün kısa açıklaması. | [optional] 
**SearchKeywords** | **string** | Ziyaretçilerinizin site içindeki ürünlerinizin hangi anahtar kelimelerine göre bulacağını belirler.Kelimeler arasında virgül bırakılarak girilmelidir.(etiket1,etiket2) | [optional] 
**InstallmentThreshold** | **string** | Ürüne özel yasal veya isteğe bağlı belirleyebiliceğiniz taksit adedini belirtir. Ürüne özel bir belirleme yapmak istemiyorsanız &#39;-&#39; işareti kullanabilirsiniz. | [optional] 
**HomeSortOrder** | **int?** | Anasayfa vitrini sırası. | [optional] 
**PopularSortOrder** | **int?** | Popüler ürünler vitrini sırası. | [optional] 
**BrandSortOrder** | **int?** | Marka vitrini sırası. | [optional] 
**FeaturedSortOrder** | **int?** | Sponsor ürünler vitrini sırası | [optional] 
**CampaignedSortOrder** | **int?** | Kampanyalı ürünler vitrini sırası. | [optional] 
**NewSortOrder** | **int?** | Yeni ürünler vitrini sırası. | [optional] 
**DiscountedSortOrder** | **int?** | İndirimli ürünler vitrini sırası | [optional] 
**Brand** | [**Brand**](Brand.md) |  | [optional] 
**Currency** | [**Currency**](Currency.md) |  | [optional] 
**Parent** | [**Product**](Product.md) |  | [optional] 
**Countdown** | [**ProductToCountDown**](ProductToCountDown.md) |  | [optional] 
**Prices** | [**List&lt;ProductPrice&gt;**](ProductPrice.md) | Ürünün fiyatları. | [optional] 
**Images** | [**List&lt;ProductImage&gt;**](ProductImage.md) | Ürünün resimleri. | [optional] 
**ProductToCategories** | [**List&lt;ProductToCategory&gt;**](ProductToCategory.md) | Ürünün kategorileri. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

