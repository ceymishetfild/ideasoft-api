# IO.Swagger.Model.Order
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Sipariş nesnesi kimlik değeri. | [optional] 
**CustomerFirstname** | **string** | Müşterinin ismi. | 
**CustomerSurname** | **string** | Müşterinin soy ismi. | 
**CustomerEmail** | **string** | Müşterinin e-mail adresi. | 
**CustomerPhone** | **string** | Müşterinin telefon numarası. | 
**PaymentTypeName** | **string** | Siparişin ödeme tipi. | 
**PaymentProviderCode** | **string** | Siparişin ödeme altyapısı sağlayıcısının kodu. Ön tanımlıdır. API otomatik oluşturur. | 
**PaymentProviderName** | **string** | Siparişin ödeme altyapısı sağlayıcısının adı. Ön tanımlıdır. API otomatik oluşturur. | 
**PaymentGatewayCode** | **string** | Siparişin ödeme kanalının kodu. Ön tanımlıdır. API otomatik oluşturur. | 
**PaymentGatewayName** | **string** | Siparişin ödeme kanalının adı. Ön tanımlıdır. API otomatik oluşturur. | 
**BankName** | **string** | Siparişin banka adı. Ön tanımlıdır. API otomatik oluşturur. | [optional] 
**ClientIp** | **string** | Müşterinin IP adresi. | 
**UserAgent** | **string** | Siparişin gerçekleştiği tarayıcı bilgisi. | [optional] 
**Currency** | **string** | Kur bilgisi. | 
**CurrencyRates** | **string** | Kur oranları. | 
**Amount** | **float?** | Siparişin vergi hariç fiyatı. | 
**CouponDiscount** | **float?** | Siparişte kullanılan hediye çeki indirimi tutarı. | 
**TaxAmount** | **float?** | Siparişin vergi tutarı. | 
**PromotionDiscount** | **float?** | Siparişte kullanılan promosyon indirimi tutarı. | 
**GeneralAmount** | **float?** | Siparişin genel fiyat tutarı. orderAmount, couponDiscount, taxAmount, promotionDiscount, shippingAmount, additionalServiceAmount tutarlarının toplamı. | 
**ShippingAmount** | **float?** | Siparişin teslimat ücreti. | 
**AdditionalServiceAmount** | **float?** | Siparişin ek hizmet bedeli ücreti. | 
**FinalAmount** | **float?** | Siparişin son ödeme tutarı. generalAmount değerinin üzerine taksitten kaynaklı vade farkı bedeli eklenmiş hali. | 
**SumOfGainedPoints** | **float?** | Siparişten kazanılan puan tutarı. | [optional] 
**Installment** | **int?** | Siparişin taksit adeti. | [optional] 
**InstallmentRate** | **float?** | Siparişin taksit oranı. | [optional] 
**ExtraInstallment** | **int?** | Siparişin ek taksit adeti. | [optional] 
**TransactionId** | **string** | Siparişin numarası. | [optional] 
**HasUserNote** | **string** | Siparişin müşteri notuna sahiplik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sipariş müşteri notuna sahip.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sipariş müşteri notuna sahip değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**Status** | **string** | Sipariş durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;/div&gt; | 
**PaymentStatus** | **string** | Ödeme durumu bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;success&lt;/code&gt; : Başarılı&lt;br&gt;&lt;/div&gt; | 
**ErrorMessage** | **string** | Siparişin hata mesajı. | [optional] 
**DeviceType** | **string** | Siparişin gerçekleştiği cihaz bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil&lt;br&gt;&lt;code&gt;tablet&lt;/code&gt; : Tablet&lt;br&gt;&lt;/div&gt; | 
**Referrer** | **string** | Siparişe yönlendiren web-sitesi adresi. Yönlendirmeyi yapan web-sitesinin tam URL bilgisini de içerir. API otomatik oluşturur. | [optional] 
**InvoicePrintCount** | **int?** | Sipariş için alınan fatura çıktısı adedi. | [optional] 
**UseGiftPackage** | **string** | Hediye paketi istenilmesi durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hediye paketi istiyorum&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hediye paketi istemiyorum&lt;br&gt;&lt;/div&gt; | [optional] 
**GiftNote** | **string** | Hediye notu. | [optional] 
**MemberGroupName** | **string** | Üye grubu adı. | [optional] 
**UsePromotion** | **string** | Promosyon kullanılma durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Promosyon kullan&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Promosyon kullanma&lt;br&gt;&lt;/div&gt; | [optional] 
**ShippingProviderCode** | **string** | Siparişin teslimat hizmeti sağlayıcısı kodu. Ön tanımlıdır. API otomatik oluşturur. | [optional] 
**ShippingProviderName** | **string** | Siparişin teslimat hizmeti sağlayıcısı adı. Ön tanımlıdır. | [optional] 
**ShippingCompanyName** | **string** | Siparişin kargo firması adı. Ön tanımlıdır. | [optional] 
**ShippingPaymentType** | **string** | Siparişin kargo ödeme tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı Ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici Ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için geçerli değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**ShippingTrackingCode** | **string** | Siparişin kargo takip kodu. | [optional] 
**Source** | **string** | Siparişin kaynak bilgisi. Siparişin kaynak yazılımını belirtir. | 
**CreatedAt** | **DateTime?** | Sipariş nesnesinin oluşturulma zamanı. | [optional] 
**UpdatedAt** | **DateTime?** | Sipariş nesnesinin güncellenme zamanı. | [optional] 
**Maillist** | [**Maillist**](Maillist.md) |  | [optional] 
**Member** | [**Member**](Member.md) |  | [optional] 
**OrderDetails** | [**List&lt;OrderDetail&gt;**](OrderDetail.md) | Sipariş detayları. | [optional] 
**OrderItems** | [**List&lt;OrderItem&gt;**](OrderItem.md) | Sipariş kalemleri. | [optional] 
**ShippingAddress** | [**ShippingAddress**](ShippingAddress.md) |  | [optional] 
**BillingAddress** | [**BillingAddress**](BillingAddress.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

