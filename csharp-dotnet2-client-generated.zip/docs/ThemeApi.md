# IO.Swagger.Api.ThemeApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ThemesGet**](ThemeApi.md#themesget) | **GET** /themes | Tema Listesi Alma
[**ThemesIdAssetsGet**](ThemeApi.md#themesidassetsget) | **GET** /themes/{id}/assets | Tema Dosyası Listesi Alma
[**ThemesIdAssetskeykeyDelete**](ThemeApi.md#themesidassetskeykeydelete) | **DELETE** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Silme
[**ThemesIdAssetskeykeyGet**](ThemeApi.md#themesidassetskeykeyget) | **GET** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Alma
[**ThemesIdAssetskeykeyPut**](ThemeApi.md#themesidassetskeykeyput) | **PUT** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Güncelleme
[**ThemesIdDelete**](ThemeApi.md#themesiddelete) | **DELETE** /themes/{id} | Tema Silme
[**ThemesIdGet**](ThemeApi.md#themesidget) | **GET** /themes/{id} | Tema Alma
[**ThemesIdPut**](ThemeApi.md#themesidput) | **PUT** /themes/{id} | Tema Güncelleme
[**ThemesPost**](ThemeApi.md#themespost) | **POST** /themes | Tema Oluşturma


<a name="themesget"></a>
# **ThemesGet**
> Theme ThemesGet (string sort, int? limit, int? page, int? sinceId, int? status, string platform, string type)

Tema Listesi Alma

Tema listesi verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ThemesGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ThemeApi();
            var sort = sort_example;  // string | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> (optional) 
            var limit = 56;  // int? | Bir sayfada gelecek sonuç adedi (optional)  (default to 20)
            var page = 56;  // int? | Hangi sayfadan başlanacağı (optional)  (default to 1)
            var sinceId = 56;  // int? | Yalnızca belirtilen id değerinden sonraki kayıtları getirir (optional) 
            var status = 56;  // int? | Tema durumu (optional) 
            var platform = platform_example;  // string | Tema platformu (optional) 
            var type = type_example;  // string | Tema tipi (optional) 

            try
            {
                // Tema Listesi Alma
                Theme result = apiInstance.ThemesGet(sort, limit, page, sinceId, status, platform, type);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ThemeApi.ThemesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **int?**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int?**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **int?**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional] 
 **status** | **int?**| Tema durumu | [optional] 
 **platform** | **string**| Tema platformu | [optional] 
 **type** | **string**| Tema tipi | [optional] 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="themesidassetsget"></a>
# **ThemesIdAssetsGet**
> Asset ThemesIdAssetsGet (int? id, string key)

Tema Dosyası Listesi Alma

Tema Dosyası listesi verir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ThemesIdAssetsGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ThemeApi();
            var id = 56;  // int? | Tema nesnesinin id değeri
            var key = key_example;  // string | Tema Dosyası nesnesi anahtar değeri. (optional) 

            try
            {
                // Tema Dosyası Listesi Alma
                Asset result = apiInstance.ThemesIdAssetsGet(id, key);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ThemeApi.ThemesIdAssetsGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Tema nesnesinin id değeri | 
 **key** | **string**| Tema Dosyası nesnesi anahtar değeri. | [optional] 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="themesidassetskeykeydelete"></a>
# **ThemesIdAssetskeykeyDelete**
> void ThemesIdAssetskeykeyDelete (int? id, string key)

Tema Dosyası Silme

Kalıcı olarak ilgili Tema Dosyasını siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ThemesIdAssetskeykeyDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ThemeApi();
            var id = 56;  // int? | Tema nesnesinin id değeri
            var key = key_example;  // string | Tema Dosyası nesnesi anahtar değeri.

            try
            {
                // Tema Dosyası Silme
                apiInstance.ThemesIdAssetskeykeyDelete(id, key);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ThemeApi.ThemesIdAssetskeykeyDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Tema nesnesinin id değeri | 
 **key** | **string**| Tema Dosyası nesnesi anahtar değeri. | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="themesidassetskeykeyget"></a>
# **ThemesIdAssetskeykeyGet**
> Asset ThemesIdAssetskeykeyGet (int? id, string key)

Tema Dosyası Alma

İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ThemesIdAssetskeykeyGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ThemeApi();
            var id = 56;  // int? | Tema nesnesinin id değeri
            var key = key_example;  // string | Tema Dosyası nesnesi anahtar değeri.

            try
            {
                // Tema Dosyası Alma
                Asset result = apiInstance.ThemesIdAssetskeykeyGet(id, key);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ThemeApi.ThemesIdAssetskeykeyGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Tema nesnesinin id değeri | 
 **key** | **string**| Tema Dosyası nesnesi anahtar değeri. | 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="themesidassetskeykeyput"></a>
# **ThemesIdAssetskeykeyPut**
> Asset ThemesIdAssetskeykeyPut (int? id, Theme theme, Asset asset)

Tema Dosyası Güncelleme

Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ThemesIdAssetskeykeyPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ThemeApi();
            var id = 56;  // int? | Tema nesnesinin id değeri
            var theme = new Theme(); // Theme | Theme nesnesi
            var asset = new Asset(); // Asset | Asset nesnesi

            try
            {
                // Tema Dosyası Güncelleme
                Asset result = apiInstance.ThemesIdAssetskeykeyPut(id, theme, asset);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ThemeApi.ThemesIdAssetskeykeyPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Tema nesnesinin id değeri | 
 **theme** | [**Theme**](Theme.md)| Theme nesnesi | 
 **asset** | [**Asset**](Asset.md)| Asset nesnesi | 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="themesiddelete"></a>
# **ThemesIdDelete**
> void ThemesIdDelete (int? id)

Tema Silme

Kalıcı olarak ilgili Temayı siler.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ThemesIdDeleteExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ThemeApi();
            var id = 56;  // int? | Tema nesnesinin id değeri

            try
            {
                // Tema Silme
                apiInstance.ThemesIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ThemeApi.ThemesIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Tema nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="themesidget"></a>
# **ThemesIdGet**
> Theme ThemesIdGet (int? id)

Tema Alma

İlgili Temayı getirir.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ThemesIdGetExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ThemeApi();
            var id = 56;  // int? | Tema nesnesinin id değeri

            try
            {
                // Tema Alma
                Theme result = apiInstance.ThemesIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ThemeApi.ThemesIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Tema nesnesinin id değeri | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="themesidput"></a>
# **ThemesIdPut**
> Theme ThemesIdPut (int? id, Theme theme)

Tema Güncelleme

İlgili Temayı günceller.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ThemesIdPutExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ThemeApi();
            var id = 56;  // int? | Tema nesnesinin id değeri
            var theme = new Theme(); // Theme | Theme nesnesi

            try
            {
                // Tema Güncelleme
                Theme result = apiInstance.ThemesIdPut(id, theme);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ThemeApi.ThemesIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**| Tema nesnesinin id değeri | 
 **theme** | [**Theme**](Theme.md)| Theme nesnesi | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="themespost"></a>
# **ThemesPost**
> Theme ThemesPost (Theme theme)

Tema Oluşturma

Yeni bir tema oluşturur.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ThemesPostExample
    {
        public void main()
        {
            
            // Configure OAuth2 access token for authorization: OAuth2
            Configuration.Default.AccessToken = "YOUR_ACCESS_TOKEN";

            var apiInstance = new ThemeApi();
            var theme = new Theme(); // Theme | Theme nesnesi

            try
            {
                // Tema Oluşturma
                Theme result = apiInstance.ThemesPost(theme);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ThemeApi.ThemesPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **theme** | [**Theme**](Theme.md)| Theme nesnesi | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

