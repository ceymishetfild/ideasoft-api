#import "SWGPaymentApi.h"
#import "SWGQueryParamCollection.h"
#import "SWGApiClient.h"
#import "SWGError.h"
#import "SWGPayment.h"


@interface SWGPaymentApi ()

@property (nonatomic, strong, readwrite) NSMutableDictionary *mutableDefaultHeaders;

@end

@implementation SWGPaymentApi

NSString* kSWGPaymentApiErrorDomain = @"SWGPaymentApiErrorDomain";
NSInteger kSWGPaymentApiMissingParamErrorCode = 234513;

@synthesize apiClient = _apiClient;

#pragma mark - Initialize methods

- (instancetype) init {
    return [self initWithApiClient:[SWGApiClient sharedClient]];
}


-(instancetype) initWithApiClient:(SWGApiClient *)apiClient {
    self = [super init];
    if (self) {
        _apiClient = apiClient;
        _mutableDefaultHeaders = [NSMutableDictionary dictionary];
    }
    return self;
}

#pragma mark -

-(NSString*) defaultHeaderForKey:(NSString*)key {
    return self.mutableDefaultHeaders[key];
}

-(void) setDefaultHeaderValue:(NSString*) value forKey:(NSString*)key {
    [self.mutableDefaultHeaders setValue:value forKey:key];
}

-(NSDictionary *)defaultHeaders {
    return self.mutableDefaultHeaders;
}

#pragma mark - Api Methods

///
/// Ödeme Listesi Alma
/// Ödeme listesini verir.
///  @param sort Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
///
///  @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
///
///  @param page Hangi sayfadan başlanacağı (optional, default to 1)
///
///  @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
///
///  @param ids Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
///
///  @param transactionId İşlem id. (optional)
///
///  @param memberEmail Müşteri e-mail. (optional)
///
///  @param member Üye id (optional)
///
///  @param status Status şu değerleri alabilir: <br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br><code>deleted</code> : Silindi<br><code>failed</code> : Hatalı Ödemeler<br><code>in_transaction</code> : Sonuçlanmamış Ödemeler (optional)
///
///  @param paymentTypeName Ödeme tipi adı şu değerleri alabilir: <br><code>Havale</code><br><code>Özel Ödeme Sistemi</code><br><code>Kredi Kartı</code><br><code>Paypal</code><br><code>GarantiPay</code><br><code>Mail Order</code><br><code>BKM Express</code><br><code>Kapıda Ödeme Nakit</code><br><code>Kapıda Ödeme Kredi Kartı</code> (optional)
///
///  @param startDate createdAt değeri için başlangıç tarihi (optional)
///
///  @param endDate createdAt değeri için bitiş tarihi (optional)
///
///  @returns SWGPayment*
///
-(NSURLSessionTask*) paymentsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    transactionId: (NSString*) transactionId
    memberEmail: (NSString*) memberEmail
    member: (NSNumber*) member
    status: (NSString*) status
    paymentTypeName: (NSString*) paymentTypeName
    startDate: (NSDate*) startDate
    endDate: (NSString*) endDate
    completionHandler: (void (^)(SWGPayment* output, NSError* error)) handler {
    NSMutableString* resourcePath = [NSMutableString stringWithFormat:@"/payments"];

    NSMutableDictionary *pathParams = [[NSMutableDictionary alloc] init];

    NSMutableDictionary* queryParams = [[NSMutableDictionary alloc] init];
    if (sort != nil) {
        queryParams[@"sort"] = sort;
    }
    if (limit != nil) {
        queryParams[@"limit"] = limit;
    }
    if (page != nil) {
        queryParams[@"page"] = page;
    }
    if (sinceId != nil) {
        queryParams[@"sinceId"] = sinceId;
    }
    if (ids != nil) {
        queryParams[@"ids"] = ids;
    }
    if (transactionId != nil) {
        queryParams[@"transactionId"] = transactionId;
    }
    if (memberEmail != nil) {
        queryParams[@"memberEmail"] = memberEmail;
    }
    if (member != nil) {
        queryParams[@"member"] = member;
    }
    if (status != nil) {
        queryParams[@"status"] = status;
    }
    if (paymentTypeName != nil) {
        queryParams[@"paymentTypeName"] = paymentTypeName;
    }
    if (startDate != nil) {
        queryParams[@"startDate"] = startDate;
    }
    if (endDate != nil) {
        queryParams[@"endDate"] = endDate;
    }
    NSMutableDictionary* headerParams = [NSMutableDictionary dictionaryWithDictionary:self.apiClient.configuration.defaultHeaders];
    [headerParams addEntriesFromDictionary:self.defaultHeaders];
    // HTTP header `Accept`
    NSString *acceptHeader = [self.apiClient.sanitizer selectHeaderAccept:@[@"application/json"]];
    if(acceptHeader.length > 0) {
        headerParams[@"Accept"] = acceptHeader;
    }

    // response content type
    NSString *responseContentType = [[acceptHeader componentsSeparatedByString:@", "] firstObject] ?: @"";

    // request content type
    NSString *requestContentType = [self.apiClient.sanitizer selectHeaderContentType:@[@"application/json"]];

    // Authentication setting
    NSArray *authSettings = @[@"OAuth2"];

    id bodyParam = nil;
    NSMutableDictionary *formParams = [[NSMutableDictionary alloc] init];
    NSMutableDictionary *localVarFiles = [[NSMutableDictionary alloc] init];

    return [self.apiClient requestWithPath: resourcePath
                                    method: @"GET"
                                pathParams: pathParams
                               queryParams: queryParams
                                formParams: formParams
                                     files: localVarFiles
                                      body: bodyParam
                              headerParams: headerParams
                              authSettings: authSettings
                        requestContentType: requestContentType
                       responseContentType: responseContentType
                              responseType: @"SWGPayment*"
                           completionBlock: ^(id data, NSError *error) {
                                if(handler) {
                                    handler((SWGPayment*)data, error);
                                }
                            }];
}

///
/// Ödeme Silme
/// Kalıcı olarak ilgili Ödemeyi siler.
///  @param _id Ödeme nesnesinin id değeri 
///
///  @returns void
///
-(NSURLSessionTask*) paymentsIdDeleteWithId: (NSNumber*) _id
    completionHandler: (void (^)(NSError* error)) handler {
    // verify the required parameter '_id' is set
    if (_id == nil) {
        NSParameterAssert(_id);
        if(handler) {
            NSDictionary * userInfo = @{NSLocalizedDescriptionKey : [NSString stringWithFormat:NSLocalizedString(@"Missing required parameter '%@'", nil),@"_id"] };
            NSError* error = [NSError errorWithDomain:kSWGPaymentApiErrorDomain code:kSWGPaymentApiMissingParamErrorCode userInfo:userInfo];
            handler(error);
        }
        return nil;
    }

    NSMutableString* resourcePath = [NSMutableString stringWithFormat:@"/payments/{id}"];

    NSMutableDictionary *pathParams = [[NSMutableDictionary alloc] init];
    if (_id != nil) {
        pathParams[@"id"] = _id;
    }

    NSMutableDictionary* queryParams = [[NSMutableDictionary alloc] init];
    NSMutableDictionary* headerParams = [NSMutableDictionary dictionaryWithDictionary:self.apiClient.configuration.defaultHeaders];
    [headerParams addEntriesFromDictionary:self.defaultHeaders];
    // HTTP header `Accept`
    NSString *acceptHeader = [self.apiClient.sanitizer selectHeaderAccept:@[@"application/json"]];
    if(acceptHeader.length > 0) {
        headerParams[@"Accept"] = acceptHeader;
    }

    // response content type
    NSString *responseContentType = [[acceptHeader componentsSeparatedByString:@", "] firstObject] ?: @"";

    // request content type
    NSString *requestContentType = [self.apiClient.sanitizer selectHeaderContentType:@[@"application/json"]];

    // Authentication setting
    NSArray *authSettings = @[@"OAuth2"];

    id bodyParam = nil;
    NSMutableDictionary *formParams = [[NSMutableDictionary alloc] init];
    NSMutableDictionary *localVarFiles = [[NSMutableDictionary alloc] init];

    return [self.apiClient requestWithPath: resourcePath
                                    method: @"DELETE"
                                pathParams: pathParams
                               queryParams: queryParams
                                formParams: formParams
                                     files: localVarFiles
                                      body: bodyParam
                              headerParams: headerParams
                              authSettings: authSettings
                        requestContentType: requestContentType
                       responseContentType: responseContentType
                              responseType: nil
                           completionBlock: ^(id data, NSError *error) {
                                if(handler) {
                                    handler(error);
                                }
                            }];
}

///
/// Ödeme Alma
/// İlgili Ödemeyi getirir.
///  @param _id Ödeme nesnesinin id değeri 
///
///  @returns SWGPayment*
///
-(NSURLSessionTask*) paymentsIdGetWithId: (NSNumber*) _id
    completionHandler: (void (^)(SWGPayment* output, NSError* error)) handler {
    // verify the required parameter '_id' is set
    if (_id == nil) {
        NSParameterAssert(_id);
        if(handler) {
            NSDictionary * userInfo = @{NSLocalizedDescriptionKey : [NSString stringWithFormat:NSLocalizedString(@"Missing required parameter '%@'", nil),@"_id"] };
            NSError* error = [NSError errorWithDomain:kSWGPaymentApiErrorDomain code:kSWGPaymentApiMissingParamErrorCode userInfo:userInfo];
            handler(nil, error);
        }
        return nil;
    }

    NSMutableString* resourcePath = [NSMutableString stringWithFormat:@"/payments/{id}"];

    NSMutableDictionary *pathParams = [[NSMutableDictionary alloc] init];
    if (_id != nil) {
        pathParams[@"id"] = _id;
    }

    NSMutableDictionary* queryParams = [[NSMutableDictionary alloc] init];
    NSMutableDictionary* headerParams = [NSMutableDictionary dictionaryWithDictionary:self.apiClient.configuration.defaultHeaders];
    [headerParams addEntriesFromDictionary:self.defaultHeaders];
    // HTTP header `Accept`
    NSString *acceptHeader = [self.apiClient.sanitizer selectHeaderAccept:@[@"application/json"]];
    if(acceptHeader.length > 0) {
        headerParams[@"Accept"] = acceptHeader;
    }

    // response content type
    NSString *responseContentType = [[acceptHeader componentsSeparatedByString:@", "] firstObject] ?: @"";

    // request content type
    NSString *requestContentType = [self.apiClient.sanitizer selectHeaderContentType:@[@"application/json"]];

    // Authentication setting
    NSArray *authSettings = @[@"OAuth2"];

    id bodyParam = nil;
    NSMutableDictionary *formParams = [[NSMutableDictionary alloc] init];
    NSMutableDictionary *localVarFiles = [[NSMutableDictionary alloc] init];

    return [self.apiClient requestWithPath: resourcePath
                                    method: @"GET"
                                pathParams: pathParams
                               queryParams: queryParams
                                formParams: formParams
                                     files: localVarFiles
                                      body: bodyParam
                              headerParams: headerParams
                              authSettings: authSettings
                        requestContentType: requestContentType
                       responseContentType: responseContentType
                              responseType: @"SWGPayment*"
                           completionBlock: ^(id data, NSError *error) {
                                if(handler) {
                                    handler((SWGPayment*)data, error);
                                }
                            }];
}

///
/// Ödeme Güncelleme
/// İlgili Ödemeyi günceller.
///  @param _id Ödeme nesnesinin id değeri 
///
///  @param payment  nesnesi 
///
///  @returns SWGPayment*
///
-(NSURLSessionTask*) paymentsIdPutWithId: (NSNumber*) _id
    payment: (SWGPayment*) payment
    completionHandler: (void (^)(SWGPayment* output, NSError* error)) handler {
    // verify the required parameter '_id' is set
    if (_id == nil) {
        NSParameterAssert(_id);
        if(handler) {
            NSDictionary * userInfo = @{NSLocalizedDescriptionKey : [NSString stringWithFormat:NSLocalizedString(@"Missing required parameter '%@'", nil),@"_id"] };
            NSError* error = [NSError errorWithDomain:kSWGPaymentApiErrorDomain code:kSWGPaymentApiMissingParamErrorCode userInfo:userInfo];
            handler(nil, error);
        }
        return nil;
    }

    // verify the required parameter 'payment' is set
    if (payment == nil) {
        NSParameterAssert(payment);
        if(handler) {
            NSDictionary * userInfo = @{NSLocalizedDescriptionKey : [NSString stringWithFormat:NSLocalizedString(@"Missing required parameter '%@'", nil),@"payment"] };
            NSError* error = [NSError errorWithDomain:kSWGPaymentApiErrorDomain code:kSWGPaymentApiMissingParamErrorCode userInfo:userInfo];
            handler(nil, error);
        }
        return nil;
    }

    NSMutableString* resourcePath = [NSMutableString stringWithFormat:@"/payments/{id}"];

    NSMutableDictionary *pathParams = [[NSMutableDictionary alloc] init];
    if (_id != nil) {
        pathParams[@"id"] = _id;
    }

    NSMutableDictionary* queryParams = [[NSMutableDictionary alloc] init];
    NSMutableDictionary* headerParams = [NSMutableDictionary dictionaryWithDictionary:self.apiClient.configuration.defaultHeaders];
    [headerParams addEntriesFromDictionary:self.defaultHeaders];
    // HTTP header `Accept`
    NSString *acceptHeader = [self.apiClient.sanitizer selectHeaderAccept:@[@"application/json"]];
    if(acceptHeader.length > 0) {
        headerParams[@"Accept"] = acceptHeader;
    }

    // response content type
    NSString *responseContentType = [[acceptHeader componentsSeparatedByString:@", "] firstObject] ?: @"";

    // request content type
    NSString *requestContentType = [self.apiClient.sanitizer selectHeaderContentType:@[@"application/json"]];

    // Authentication setting
    NSArray *authSettings = @[@"OAuth2"];

    id bodyParam = nil;
    NSMutableDictionary *formParams = [[NSMutableDictionary alloc] init];
    NSMutableDictionary *localVarFiles = [[NSMutableDictionary alloc] init];
    bodyParam = payment;

    return [self.apiClient requestWithPath: resourcePath
                                    method: @"PUT"
                                pathParams: pathParams
                               queryParams: queryParams
                                formParams: formParams
                                     files: localVarFiles
                                      body: bodyParam
                              headerParams: headerParams
                              authSettings: authSettings
                        requestContentType: requestContentType
                       responseContentType: responseContentType
                              responseType: @"SWGPayment*"
                           completionBlock: ^(id data, NSError *error) {
                                if(handler) {
                                    handler((SWGPayment*)data, error);
                                }
                            }];
}

///
/// Ödeme Oluşturma
/// Yeni bir Ödeme oluşturur.
///  @param payment  nesnesi 
///
///  @returns SWGPayment*
///
-(NSURLSessionTask*) paymentsPostWithPayment: (SWGPayment*) payment
    completionHandler: (void (^)(SWGPayment* output, NSError* error)) handler {
    // verify the required parameter 'payment' is set
    if (payment == nil) {
        NSParameterAssert(payment);
        if(handler) {
            NSDictionary * userInfo = @{NSLocalizedDescriptionKey : [NSString stringWithFormat:NSLocalizedString(@"Missing required parameter '%@'", nil),@"payment"] };
            NSError* error = [NSError errorWithDomain:kSWGPaymentApiErrorDomain code:kSWGPaymentApiMissingParamErrorCode userInfo:userInfo];
            handler(nil, error);
        }
        return nil;
    }

    NSMutableString* resourcePath = [NSMutableString stringWithFormat:@"/payments"];

    NSMutableDictionary *pathParams = [[NSMutableDictionary alloc] init];

    NSMutableDictionary* queryParams = [[NSMutableDictionary alloc] init];
    NSMutableDictionary* headerParams = [NSMutableDictionary dictionaryWithDictionary:self.apiClient.configuration.defaultHeaders];
    [headerParams addEntriesFromDictionary:self.defaultHeaders];
    // HTTP header `Accept`
    NSString *acceptHeader = [self.apiClient.sanitizer selectHeaderAccept:@[@"application/json"]];
    if(acceptHeader.length > 0) {
        headerParams[@"Accept"] = acceptHeader;
    }

    // response content type
    NSString *responseContentType = [[acceptHeader componentsSeparatedByString:@", "] firstObject] ?: @"";

    // request content type
    NSString *requestContentType = [self.apiClient.sanitizer selectHeaderContentType:@[@"application/json"]];

    // Authentication setting
    NSArray *authSettings = @[@"OAuth2"];

    id bodyParam = nil;
    NSMutableDictionary *formParams = [[NSMutableDictionary alloc] init];
    NSMutableDictionary *localVarFiles = [[NSMutableDictionary alloc] init];
    bodyParam = payment;

    return [self.apiClient requestWithPath: resourcePath
                                    method: @"POST"
                                pathParams: pathParams
                               queryParams: queryParams
                                formParams: formParams
                                     files: localVarFiles
                                      body: bodyParam
                              headerParams: headerParams
                              authSettings: authSettings
                        requestContentType: requestContentType
                       responseContentType: responseContentType
                              responseType: @"SWGPayment*"
                           completionBlock: ^(id data, NSError *error) {
                                if(handler) {
                                    handler((SWGPayment*)data, error);
                                }
                            }];
}



@end
