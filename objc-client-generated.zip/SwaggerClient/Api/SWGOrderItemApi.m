#import "SWGOrderItemApi.h"
#import "SWGQueryParamCollection.h"
#import "SWGApiClient.h"
#import "SWGError.h"
#import "SWGOrderItem.h"


@interface SWGOrderItemApi ()

@property (nonatomic, strong, readwrite) NSMutableDictionary *mutableDefaultHeaders;

@end

@implementation SWGOrderItemApi

NSString* kSWGOrderItemApiErrorDomain = @"SWGOrderItemApiErrorDomain";
NSInteger kSWGOrderItemApiMissingParamErrorCode = 234513;

@synthesize apiClient = _apiClient;

#pragma mark - Initialize methods

- (instancetype) init {
    return [self initWithApiClient:[SWGApiClient sharedClient]];
}


-(instancetype) initWithApiClient:(SWGApiClient *)apiClient {
    self = [super init];
    if (self) {
        _apiClient = apiClient;
        _mutableDefaultHeaders = [NSMutableDictionary dictionary];
    }
    return self;
}

#pragma mark -

-(NSString*) defaultHeaderForKey:(NSString*)key {
    return self.mutableDefaultHeaders[key];
}

-(void) setDefaultHeaderValue:(NSString*) value forKey:(NSString*)key {
    [self.mutableDefaultHeaders setValue:value forKey:key];
}

-(NSDictionary *)defaultHeaders {
    return self.mutableDefaultHeaders;
}

#pragma mark - Api Methods

///
/// Sipariş Kalemi Listesi Alma
/// Sipariş Kalemi listesini verir.
///  @param sort Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
///
///  @param limit Bir sayfada gelecek sonuç adedi (optional, default to 20)
///
///  @param page Hangi sayfadan başlanacağı (optional, default to 1)
///
///  @param sinceId Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
///
///  @param ids Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
///
///  @param order Sipariş id (optional)
///
///  @param productName Ürün adı (optional)
///
///  @param productSku Ürün stok kodu (optional)
///
///  @param productBarcode Ürün barkodu (optional)
///
///  @param startDate createdAt değeri için başlangıç tarihi (optional)
///
///  @param endDate createdAt değeri için bitiş tarihi (optional)
///
///  @param startUpdatedAt updatedAt değeri için başlangıç tarihi (optional)
///
///  @param endUpdatedAt updatedAt değeri için bitiş tarihi (optional)
///
///  @returns SWGOrderItem*
///
-(NSURLSessionTask*) orderItemsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    order: (NSNumber*) order
    productName: (NSString*) productName
    productSku: (NSString*) productSku
    productBarcode: (NSString*) productBarcode
    startDate: (NSDate*) startDate
    endDate: (NSString*) endDate
    startUpdatedAt: (NSDate*) startUpdatedAt
    endUpdatedAt: (NSString*) endUpdatedAt
    completionHandler: (void (^)(SWGOrderItem* output, NSError* error)) handler {
    NSMutableString* resourcePath = [NSMutableString stringWithFormat:@"/order_items"];

    NSMutableDictionary *pathParams = [[NSMutableDictionary alloc] init];

    NSMutableDictionary* queryParams = [[NSMutableDictionary alloc] init];
    if (sort != nil) {
        queryParams[@"sort"] = sort;
    }
    if (limit != nil) {
        queryParams[@"limit"] = limit;
    }
    if (page != nil) {
        queryParams[@"page"] = page;
    }
    if (sinceId != nil) {
        queryParams[@"sinceId"] = sinceId;
    }
    if (ids != nil) {
        queryParams[@"ids"] = ids;
    }
    if (order != nil) {
        queryParams[@"order"] = order;
    }
    if (productName != nil) {
        queryParams[@"productName"] = productName;
    }
    if (productSku != nil) {
        queryParams[@"productSku"] = productSku;
    }
    if (productBarcode != nil) {
        queryParams[@"productBarcode"] = productBarcode;
    }
    if (startDate != nil) {
        queryParams[@"startDate"] = startDate;
    }
    if (endDate != nil) {
        queryParams[@"endDate"] = endDate;
    }
    if (startUpdatedAt != nil) {
        queryParams[@"startUpdatedAt"] = startUpdatedAt;
    }
    if (endUpdatedAt != nil) {
        queryParams[@"endUpdatedAt"] = endUpdatedAt;
    }
    NSMutableDictionary* headerParams = [NSMutableDictionary dictionaryWithDictionary:self.apiClient.configuration.defaultHeaders];
    [headerParams addEntriesFromDictionary:self.defaultHeaders];
    // HTTP header `Accept`
    NSString *acceptHeader = [self.apiClient.sanitizer selectHeaderAccept:@[@"application/json"]];
    if(acceptHeader.length > 0) {
        headerParams[@"Accept"] = acceptHeader;
    }

    // response content type
    NSString *responseContentType = [[acceptHeader componentsSeparatedByString:@", "] firstObject] ?: @"";

    // request content type
    NSString *requestContentType = [self.apiClient.sanitizer selectHeaderContentType:@[@"application/json"]];

    // Authentication setting
    NSArray *authSettings = @[@"OAuth2"];

    id bodyParam = nil;
    NSMutableDictionary *formParams = [[NSMutableDictionary alloc] init];
    NSMutableDictionary *localVarFiles = [[NSMutableDictionary alloc] init];

    return [self.apiClient requestWithPath: resourcePath
                                    method: @"GET"
                                pathParams: pathParams
                               queryParams: queryParams
                                formParams: formParams
                                     files: localVarFiles
                                      body: bodyParam
                              headerParams: headerParams
                              authSettings: authSettings
                        requestContentType: requestContentType
                       responseContentType: responseContentType
                              responseType: @"SWGOrderItem*"
                           completionBlock: ^(id data, NSError *error) {
                                if(handler) {
                                    handler((SWGOrderItem*)data, error);
                                }
                            }];
}

///
/// Sipariş Kalemi Alma
/// İlgili Sipariş Kalemini getirir.
///  @param _id Sipariş Kalemi nesnesinin id değeri 
///
///  @returns SWGOrderItem*
///
-(NSURLSessionTask*) orderItemsIdGetWithId: (NSNumber*) _id
    completionHandler: (void (^)(SWGOrderItem* output, NSError* error)) handler {
    // verify the required parameter '_id' is set
    if (_id == nil) {
        NSParameterAssert(_id);
        if(handler) {
            NSDictionary * userInfo = @{NSLocalizedDescriptionKey : [NSString stringWithFormat:NSLocalizedString(@"Missing required parameter '%@'", nil),@"_id"] };
            NSError* error = [NSError errorWithDomain:kSWGOrderItemApiErrorDomain code:kSWGOrderItemApiMissingParamErrorCode userInfo:userInfo];
            handler(nil, error);
        }
        return nil;
    }

    NSMutableString* resourcePath = [NSMutableString stringWithFormat:@"/order_items/{id}"];

    NSMutableDictionary *pathParams = [[NSMutableDictionary alloc] init];
    if (_id != nil) {
        pathParams[@"id"] = _id;
    }

    NSMutableDictionary* queryParams = [[NSMutableDictionary alloc] init];
    NSMutableDictionary* headerParams = [NSMutableDictionary dictionaryWithDictionary:self.apiClient.configuration.defaultHeaders];
    [headerParams addEntriesFromDictionary:self.defaultHeaders];
    // HTTP header `Accept`
    NSString *acceptHeader = [self.apiClient.sanitizer selectHeaderAccept:@[@"application/json"]];
    if(acceptHeader.length > 0) {
        headerParams[@"Accept"] = acceptHeader;
    }

    // response content type
    NSString *responseContentType = [[acceptHeader componentsSeparatedByString:@", "] firstObject] ?: @"";

    // request content type
    NSString *requestContentType = [self.apiClient.sanitizer selectHeaderContentType:@[@"application/json"]];

    // Authentication setting
    NSArray *authSettings = @[@"OAuth2"];

    id bodyParam = nil;
    NSMutableDictionary *formParams = [[NSMutableDictionary alloc] init];
    NSMutableDictionary *localVarFiles = [[NSMutableDictionary alloc] init];

    return [self.apiClient requestWithPath: resourcePath
                                    method: @"GET"
                                pathParams: pathParams
                               queryParams: queryParams
                                formParams: formParams
                                     files: localVarFiles
                                      body: bodyParam
                              headerParams: headerParams
                              authSettings: authSettings
                        requestContentType: requestContentType
                       responseContentType: responseContentType
                              responseType: @"SWGOrderItem*"
                           completionBlock: ^(id data, NSError *error) {
                                if(handler) {
                                    handler((SWGOrderItem*)data, error);
                                }
                            }];
}



@end
