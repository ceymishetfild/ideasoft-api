#import "SWGPayment.h"

@implementation SWGPayment

- (instancetype)init {
  self = [super init];
  if (self) {
    // initialize property's default value, if any
    
  }
  return self;
}


/**
 * Maps json key to property name.
 * This method is used by `JSONModel`.
 */
+ (JSONKeyMapper *)keyMapper {
  return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:@{ @"_id": @"id", @"memberFirstname": @"memberFirstname", @"memberSurname": @"memberSurname", @"memberEmail": @"memberEmail", @"memberPhone": @"memberPhone", @"paymentTypeName": @"paymentTypeName", @"paymentProviderCode": @"paymentProviderCode", @"paymentProviderName": @"paymentProviderName", @"paymentGatewayName": @"paymentGatewayName", @"paymentGatewayCode": @"paymentGatewayCode", @"bankName": @"bankName", @"deviceType": @"deviceType", @"clientIp": @"clientIp", @"currencyRates": @"currencyRates", @"amount": @"amount", @"finalAmount": @"finalAmount", @"sumOfGainedPoints": @"sumOfGainedPoints", @"installment": @"installment", @"installmentRate": @"installmentRate", @"extraInstallment": @"extraInstallment", @"currency": @"currency", @"transactionId": @"transactionId", @"memberNote": @"memberNote", @"userNote": @"userNote", @"status": @"status", @"errorMessage": @"errorMessage", @"cardSavingSystem": @"cardSavingSystem", @"createdAt": @"createdAt", @"member": @"member" }];
}

/**
 * Indicates whether the property with the given name is optional.
 * If `propertyName` is optional, then return `YES`, otherwise return `NO`.
 * This method is used by `JSONModel`.
 */
+ (BOOL)propertyIsOptional:(NSString *)propertyName {

  NSArray *optionalProperties = @[@"_id", @"memberPhone", @"bankName", @"sumOfGainedPoints", @"extraInstallment", @"transactionId", @"memberNote", @"userNote", @"errorMessage", @"cardSavingSystem", @"createdAt", @"member"];
  return [optionalProperties containsObject:propertyName];
}

@end
