#import "SWGProduct.h"

@implementation SWGProduct

- (instancetype)init {
  self = [super init];
  if (self) {
    // initialize property's default value, if any
    
  }
  return self;
}


/**
 * Maps json key to property name.
 * This method is used by `JSONModel`.
 */
+ (JSONKeyMapper *)keyMapper {
  return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:@{ @"_id": @"id", @"name": @"name", @"slug": @"slug", @"fullName": @"fullName", @"sku": @"sku", @"barcode": @"barcode", @"price1": @"price1", @"warranty": @"warranty", @"tax": @"tax", @"stockAmount": @"stockAmount", @"volumetricWeight": @"volumetricWeight", @"buyingPrice": @"buyingPrice", @"stockTypeLabel": @"stockTypeLabel", @"discount": @"discount", @"discountType": @"discountType", @"moneyOrderDiscount": @"moneyOrderDiscount", @"status": @"status", @"taxIncluded": @"taxIncluded", @"distributor": @"distributor", @"isGifted": @"isGifted", @"gift": @"gift", @"customShippingDisabled": @"customShippingDisabled", @"customShippingCost": @"customShippingCost", @"marketPriceDetail": @"marketPriceDetail", @"createdAt": @"createdAt", @"updatedAt": @"updatedAt", @"metaKeywords": @"metaKeywords", @"metaDescription": @"metaDescription", @"pageTitle": @"pageTitle", @"hasOption": @"hasOption", @"shortDetails": @"shortDetails", @"searchKeywords": @"searchKeywords", @"installmentThreshold": @"installmentThreshold", @"homeSortOrder": @"homeSortOrder", @"popularSortOrder": @"popularSortOrder", @"brandSortOrder": @"brandSortOrder", @"featuredSortOrder": @"featuredSortOrder", @"campaignedSortOrder": @"campaignedSortOrder", @"varNewSortOrder": @"newSortOrder", @"discountedSortOrder": @"discountedSortOrder", @"brand": @"brand", @"currency": @"currency", @"parent": @"parent", @"countdown": @"countdown", @"prices": @"prices", @"images": @"images", @"productToCategories": @"productToCategories" }];
}

/**
 * Indicates whether the property with the given name is optional.
 * If `propertyName` is optional, then return `YES`, otherwise return `NO`.
 * This method is used by `JSONModel`.
 */
+ (BOOL)propertyIsOptional:(NSString *)propertyName {

  NSArray *optionalProperties = @[@"_id", @"slug", @"barcode", @"warranty", @"tax", @"stockAmount", @"volumetricWeight", @"buyingPrice", @"stockTypeLabel", @"discount", @"discountType", @"moneyOrderDiscount", @"taxIncluded", @"distributor", @"isGifted", @"gift", @"customShippingDisabled", @"customShippingCost", @"marketPriceDetail", @"createdAt", @"updatedAt", @"metaKeywords", @"metaDescription", @"pageTitle", @"hasOption", @"shortDetails", @"searchKeywords", @"installmentThreshold", @"homeSortOrder", @"popularSortOrder", @"brandSortOrder", @"featuredSortOrder", @"campaignedSortOrder", @"varNewSortOrder", @"discountedSortOrder", @"brand", @"parent", @"countdown", @"prices", @"images", @"productToCategories"];
  return [optionalProperties containsObject:propertyName];
}

@end
