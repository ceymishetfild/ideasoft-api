#import "SWGOrder.h"

@implementation SWGOrder

- (instancetype)init {
  self = [super init];
  if (self) {
    // initialize property's default value, if any
    
  }
  return self;
}


/**
 * Maps json key to property name.
 * This method is used by `JSONModel`.
 */
+ (JSONKeyMapper *)keyMapper {
  return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:@{ @"_id": @"id", @"customerFirstname": @"customerFirstname", @"customerSurname": @"customerSurname", @"customerEmail": @"customerEmail", @"customerPhone": @"customerPhone", @"paymentTypeName": @"paymentTypeName", @"paymentProviderCode": @"paymentProviderCode", @"paymentProviderName": @"paymentProviderName", @"paymentGatewayCode": @"paymentGatewayCode", @"paymentGatewayName": @"paymentGatewayName", @"bankName": @"bankName", @"clientIp": @"clientIp", @"userAgent": @"userAgent", @"currency": @"currency", @"currencyRates": @"currencyRates", @"amount": @"amount", @"couponDiscount": @"couponDiscount", @"taxAmount": @"taxAmount", @"promotionDiscount": @"promotionDiscount", @"generalAmount": @"generalAmount", @"shippingAmount": @"shippingAmount", @"additionalServiceAmount": @"additionalServiceAmount", @"finalAmount": @"finalAmount", @"sumOfGainedPoints": @"sumOfGainedPoints", @"installment": @"installment", @"installmentRate": @"installmentRate", @"extraInstallment": @"extraInstallment", @"transactionId": @"transactionId", @"hasUserNote": @"hasUserNote", @"status": @"status", @"paymentStatus": @"paymentStatus", @"errorMessage": @"errorMessage", @"deviceType": @"deviceType", @"referrer": @"referrer", @"invoicePrintCount": @"invoicePrintCount", @"useGiftPackage": @"useGiftPackage", @"giftNote": @"giftNote", @"memberGroupName": @"memberGroupName", @"usePromotion": @"usePromotion", @"shippingProviderCode": @"shippingProviderCode", @"shippingProviderName": @"shippingProviderName", @"shippingCompanyName": @"shippingCompanyName", @"shippingPaymentType": @"shippingPaymentType", @"shippingTrackingCode": @"shippingTrackingCode", @"source": @"source", @"createdAt": @"createdAt", @"updatedAt": @"updatedAt", @"maillist": @"maillist", @"member": @"member", @"orderDetails": @"orderDetails", @"orderItems": @"orderItems", @"shippingAddress": @"shippingAddress", @"billingAddress": @"billingAddress" }];
}

/**
 * Indicates whether the property with the given name is optional.
 * If `propertyName` is optional, then return `YES`, otherwise return `NO`.
 * This method is used by `JSONModel`.
 */
+ (BOOL)propertyIsOptional:(NSString *)propertyName {

  NSArray *optionalProperties = @[@"_id", @"bankName", @"userAgent", @"sumOfGainedPoints", @"installment", @"installmentRate", @"extraInstallment", @"transactionId", @"hasUserNote", @"errorMessage", @"referrer", @"invoicePrintCount", @"useGiftPackage", @"giftNote", @"memberGroupName", @"usePromotion", @"shippingProviderCode", @"shippingProviderName", @"shippingCompanyName", @"shippingPaymentType", @"shippingTrackingCode", @"createdAt", @"updatedAt", @"maillist", @"member", @"orderDetails", @"orderItems", @"shippingAddress", @"billingAddress"];
  return [optionalProperties containsObject:propertyName];
}

@end
