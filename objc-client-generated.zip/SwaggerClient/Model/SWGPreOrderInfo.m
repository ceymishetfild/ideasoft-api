#import "SWGPreOrderInfo.h"

@implementation SWGPreOrderInfo

- (instancetype)init {
  self = [super init];
  if (self) {
    // initialize property's default value, if any
    
  }
  return self;
}


/**
 * Maps json key to property name.
 * This method is used by `JSONModel`.
 */
+ (JSONKeyMapper *)keyMapper {
  return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:@{ @"_id": @"id", @"sessionId": @"sessionId", @"customerFirstname": @"customerFirstname", @"customerSurname": @"customerSurname", @"customerEmail": @"customerEmail", @"shippingFirstname": @"shippingFirstname", @"shippingSurname": @"shippingSurname", @"shippingAddress": @"shippingAddress", @"shippingPhoneNumber": @"shippingPhoneNumber", @"shippingMobilePhoneNumber": @"shippingMobilePhoneNumber", @"shippingLocationName": @"shippingLocationName", @"shippingTown": @"shippingTown", @"differentBillingAddress": @"differentBillingAddress", @"billingFirstname": @"billingFirstname", @"billingSurname": @"billingSurname", @"billingAddress": @"billingAddress", @"billingPhoneNumber": @"billingPhoneNumber", @"billingMobilePhoneNumber": @"billingMobilePhoneNumber", @"billingLocationName": @"billingLocationName", @"billingTown": @"billingTown", @"billingInvoiceType": @"billingInvoiceType", @"billingIdentityRegistrationNumber": @"billingIdentityRegistrationNumber", @"billingTaxOffice": @"billingTaxOffice", @"billingTaxNo": @"billingTaxNo", @"isEinvoiceUser": @"isEinvoiceUser", @"useGiftPackage": @"useGiftPackage", @"giftNote": @"giftNote", @"imageFile": @"imageFile", @"deliveryDate": @"deliveryDate", @"deliveryTime": @"deliveryTime", @"createdAt": @"createdAt", @"updatedAt": @"updatedAt", @"billingCountry": @"billingCountry", @"billingLocation": @"billingLocation", @"shippingCompany": @"shippingCompany", @"shippingCountry": @"shippingCountry", @"shippingLocation": @"shippingLocation", @"memberShippingAddress": @"memberShippingAddress", @"memberBillingAddress": @"memberBillingAddress" }];
}

/**
 * Indicates whether the property with the given name is optional.
 * If `propertyName` is optional, then return `YES`, otherwise return `NO`.
 * This method is used by `JSONModel`.
 */
+ (BOOL)propertyIsOptional:(NSString *)propertyName {

  NSArray *optionalProperties = @[@"_id", @"customerFirstname", @"customerSurname", @"customerEmail", @"differentBillingAddress", @"billingIdentityRegistrationNumber", @"billingTaxOffice", @"billingTaxNo", @"isEinvoiceUser", @"useGiftPackage", @"giftNote", @"imageFile", @"deliveryDate", @"deliveryTime", @"createdAt", @"updatedAt", @"memberShippingAddress", @"memberBillingAddress"];
  return [optionalProperties containsObject:propertyName];
}

@end
