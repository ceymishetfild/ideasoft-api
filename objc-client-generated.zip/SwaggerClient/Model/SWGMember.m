#import "SWGMember.h"

@implementation SWGMember

- (instancetype)init {
  self = [super init];
  if (self) {
    // initialize property's default value, if any
    
  }
  return self;
}


/**
 * Maps json key to property name.
 * This method is used by `JSONModel`.
 */
+ (JSONKeyMapper *)keyMapper {
  return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:@{ @"_id": @"id", @"firstname": @"firstname", @"surname": @"surname", @"email": @"email", @"gender": @"gender", @"birthDate": @"birthDate", @"phoneNumber": @"phoneNumber", @"mobilePhoneNumber": @"mobilePhoneNumber", @"otherLocation": @"otherLocation", @"address": @"address", @"taxNumber": @"taxNumber", @"tcId": @"tcId", @"status": @"status", @"lastLoginDate": @"lastLoginDate", @"createdAt": @"createdAt", @"updatedAt": @"updatedAt", @"zipCode": @"zipCode", @"commercialName": @"commercialName", @"taxOffice": @"taxOffice", @"lastMailSentDate": @"lastMailSentDate", @"lastIp": @"lastIp", @"gainedPointAmount": @"gainedPointAmount", @"spentPointAmount": @"spentPointAmount", @"allowedToCampaigns": @"allowedToCampaigns", @"referredMemberGainedPointAmount": @"referredMemberGainedPointAmount", @"district": @"district", @"deviceType": @"deviceType", @"deviceInfo": @"deviceInfo", @"country": @"country", @"location": @"location", @"memberGroup": @"memberGroup", @"referredMember": @"referredMember" }];
}

/**
 * Indicates whether the property with the given name is optional.
 * If `propertyName` is optional, then return `YES`, otherwise return `NO`.
 * This method is used by `JSONModel`.
 */
+ (BOOL)propertyIsOptional:(NSString *)propertyName {

  NSArray *optionalProperties = @[@"_id", @"gender", @"birthDate", @"phoneNumber", @"mobilePhoneNumber", @"otherLocation", @"address", @"taxNumber", @"tcId", @"lastLoginDate", @"createdAt", @"updatedAt", @"zipCode", @"commercialName", @"taxOffice", @"lastMailSentDate", @"lastIp", @"gainedPointAmount", @"spentPointAmount", @"allowedToCampaigns", @"referredMemberGainedPointAmount", @"district", @"deviceInfo", @"country", @"location", @"memberGroup", @"referredMember"];
  return [optionalProperties containsObject:propertyName];
}

@end
