# SWGTownApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**townsGet**](SWGTownApi.md#townsget) | **GET** /towns | İlçe Listesi Alma
[**townsIdDelete**](SWGTownApi.md#townsiddelete) | **DELETE** /towns/{id} | İlçe Silme
[**townsIdGet**](SWGTownApi.md#townsidget) | **GET** /towns/{id} | İlçe Alma
[**townsIdPut**](SWGTownApi.md#townsidput) | **PUT** /towns/{id} | İlçe Güncelleme
[**townsPost**](SWGTownApi.md#townspost) | **POST** /towns | İlçe Oluşturma


# **townsGet**
```objc
-(NSURLSessionTask*) townsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    location: (NSNumber*) location
    townGroup: (NSNumber*) townGroup
    name: (NSString*) name
    status: (NSString*) status
        completionHandler: (void (^)(SWGTown* output, NSError* error)) handler;
```

İlçe Listesi Alma

İlçe listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSNumber* location = @56; // Şehir id (optional)
NSNumber* townGroup = @56; // İlçe grubu id (optional)
NSString* name = @"name_example"; // İlçe adı. (optional)
NSString* status = @"status_example"; // Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif (optional)

SWGTownApi*apiInstance = [[SWGTownApi alloc] init];

// İlçe Listesi Alma
[apiInstance townsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              location:location
              townGroup:townGroup
              name:name
              status:status
          completionHandler: ^(SWGTown* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGTownApi->townsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **location** | **NSNumber***| Şehir id | [optional] 
 **townGroup** | **NSNumber***| İlçe grubu id | [optional] 
 **name** | **NSString***| İlçe adı. | [optional] 
 **status** | **NSString***| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 

### Return type

[**SWGTown***](SWGTown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **townsIdDelete**
```objc
-(NSURLSessionTask*) townsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

İlçe Silme

Kalıcı olarak ilgili İlçeyi siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // İlçe nesnesinin id değeri

SWGTownApi*apiInstance = [[SWGTownApi alloc] init];

// İlçe Silme
[apiInstance townsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGTownApi->townsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| İlçe nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **townsIdGet**
```objc
-(NSURLSessionTask*) townsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGTown* output, NSError* error)) handler;
```

İlçe Alma

İlgili İlçeyi getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // İlçe nesnesinin id değeri

SWGTownApi*apiInstance = [[SWGTownApi alloc] init];

// İlçe Alma
[apiInstance townsIdGetWithId:_id
          completionHandler: ^(SWGTown* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGTownApi->townsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| İlçe nesnesinin id değeri | 

### Return type

[**SWGTown***](SWGTown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **townsIdPut**
```objc
-(NSURLSessionTask*) townsIdPutWithId: (NSNumber*) _id
    town: (SWGTown*) town
        completionHandler: (void (^)(SWGTown* output, NSError* error)) handler;
```

İlçe Güncelleme

İlgili İlçeyi günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // İlçe nesnesinin id değeri
SWGTown* town = [[SWGTown alloc] init]; //  nesnesi

SWGTownApi*apiInstance = [[SWGTownApi alloc] init];

// İlçe Güncelleme
[apiInstance townsIdPutWithId:_id
              town:town
          completionHandler: ^(SWGTown* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGTownApi->townsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| İlçe nesnesinin id değeri | 
 **town** | [**SWGTown***](SWGTown.md)|  nesnesi | 

### Return type

[**SWGTown***](SWGTown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **townsPost**
```objc
-(NSURLSessionTask*) townsPostWithTown: (SWGTown*) town
        completionHandler: (void (^)(SWGTown* output, NSError* error)) handler;
```

İlçe Oluşturma

Yeni bir İlçe oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGTown* town = [[SWGTown alloc] init]; //  nesnesi

SWGTownApi*apiInstance = [[SWGTownApi alloc] init];

// İlçe Oluşturma
[apiInstance townsPostWithTown:town
          completionHandler: ^(SWGTown* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGTownApi->townsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **town** | [**SWGTown***](SWGTown.md)|  nesnesi | 

### Return type

[**SWGTown***](SWGTown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

