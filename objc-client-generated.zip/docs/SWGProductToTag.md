# SWGProductToTag

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Ürün SEO+ etiketi bağı nesnesi kimlik değeri. | [optional] 
**product** | [**SWGProduct***](SWGProduct.md) | Ürün nesnesi. | 
**tag** | [**SWGTag***](SWGTag.md) | SEO+ etiketi nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


