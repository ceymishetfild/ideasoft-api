# SWGProductButton

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Ürün ve stok butonu nesnesi kimlik değeri. | [optional] 
**fastShipping** | **NSString*** | Hızlı gönderi butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hızlı kargo butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hızlı kargo butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**sameDayShipping** | **NSString*** | Aynı gün kargo butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aynı gün kargo butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Aynı gün kargo butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**threeDaysDelivery** | **NSString*** | 3 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 3 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 3 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**fiveDaysDelivery** | **NSString*** | 5 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 5 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 5 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**sevenDaysDelivery** | **NSString*** | 7 günde teslimat butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 7 günde teslimat butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : 7 günde teslimat butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**freeShipping** | **NSString*** | Kargo bedava butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kargo bedava butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kargo bedava butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**deliveryFromStock** | **NSString*** | Stoktan teslim butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Stoktan teslim butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Stoktan teslim butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**preOrderedProduct** | **NSString*** | Ön siparişli stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Ön siparişli ürün butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Ön siparişli ürün butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**limitedStock** | **NSString*** | Sınırlı stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sınırlı stok butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sınırlı stok butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**askStock** | **NSString*** | Stok sorunuz butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Stok sorunuz butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Stok sorunuz butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**campaignedProduct** | **NSString*** | Kampanyalı stok butonu aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalı ürün butonu aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalı ürün butonu pasif.&lt;br&gt;&lt;/div&gt; | [optional] 
**product** | [**SWGProduct***](SWGProduct.md) | Ürün nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


