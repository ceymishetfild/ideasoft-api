# SWGSelectionGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Ek özellik grubu nesnesi kimlik değeri. | [optional] 
**title** | **NSString*** | Ek özellik grubu nesnesinin başlığı. | 
**sortOrder** | **NSNumber*** | Ek özellik grubu nesnesi için sıralama değeri. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


