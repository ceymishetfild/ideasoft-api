# SWGOptionsApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**optionsGet**](SWGOptionsApi.md#optionsget) | **GET** /options | Varyant Listesi Alma
[**optionsIdDelete**](SWGOptionsApi.md#optionsiddelete) | **DELETE** /options/{id} | Varyant Silme
[**optionsIdGet**](SWGOptionsApi.md#optionsidget) | **GET** /options/{id} | Varyant Alma
[**optionsIdPut**](SWGOptionsApi.md#optionsidput) | **PUT** /options/{id} | Varyant Güncelleme
[**optionsPost**](SWGOptionsApi.md#optionspost) | **POST** /options | Varyant Oluşturma


# **optionsGet**
```objc
-(NSURLSessionTask*) optionsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    title: (NSString*) title
    optionGroup: (NSNumber*) optionGroup
        completionHandler: (void (^)(SWGOptions* output, NSError* error)) handler;
```

Varyant Listesi Alma

Varyant listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* title = @"title_example"; // Varyant başlığı (optional)
NSNumber* optionGroup = @56; // Varyant Grubu id (optional)

SWGOptionsApi*apiInstance = [[SWGOptionsApi alloc] init];

// Varyant Listesi Alma
[apiInstance optionsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              title:title
              optionGroup:optionGroup
          completionHandler: ^(SWGOptions* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOptionsApi->optionsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **title** | **NSString***| Varyant başlığı | [optional] 
 **optionGroup** | **NSNumber***| Varyant Grubu id | [optional] 

### Return type

[**SWGOptions***](SWGOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **optionsIdDelete**
```objc
-(NSURLSessionTask*) optionsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Varyant Silme

Kalıcı olarak ilgili Varyantı siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Varyant nesnesinin id değeri

SWGOptionsApi*apiInstance = [[SWGOptionsApi alloc] init];

// Varyant Silme
[apiInstance optionsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGOptionsApi->optionsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Varyant nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **optionsIdGet**
```objc
-(NSURLSessionTask*) optionsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGOptions* output, NSError* error)) handler;
```

Varyant Alma

İlgili Varyantı getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Varyant nesnesinin id değeri

SWGOptionsApi*apiInstance = [[SWGOptionsApi alloc] init];

// Varyant Alma
[apiInstance optionsIdGetWithId:_id
          completionHandler: ^(SWGOptions* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOptionsApi->optionsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Varyant nesnesinin id değeri | 

### Return type

[**SWGOptions***](SWGOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **optionsIdPut**
```objc
-(NSURLSessionTask*) optionsIdPutWithId: (NSNumber*) _id
    options: (SWGOptions*) options
        completionHandler: (void (^)(SWGOptions* output, NSError* error)) handler;
```

Varyant Güncelleme

İlgili Varyantı günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Varyant nesnesinin id değeri
SWGOptions* options = [[SWGOptions alloc] init]; //  nesnesi

SWGOptionsApi*apiInstance = [[SWGOptionsApi alloc] init];

// Varyant Güncelleme
[apiInstance optionsIdPutWithId:_id
              options:options
          completionHandler: ^(SWGOptions* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOptionsApi->optionsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Varyant nesnesinin id değeri | 
 **options** | [**SWGOptions***](SWGOptions.md)|  nesnesi | 

### Return type

[**SWGOptions***](SWGOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **optionsPost**
```objc
-(NSURLSessionTask*) optionsPostWithOptions: (SWGOptions*) options
        completionHandler: (void (^)(SWGOptions* output, NSError* error)) handler;
```

Varyant Oluşturma

Yeni bir Varyant oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGOptions* options = [[SWGOptions alloc] init]; //  nesnesi

SWGOptionsApi*apiInstance = [[SWGOptionsApi alloc] init];

// Varyant Oluşturma
[apiInstance optionsPostWithOptions:options
          completionHandler: ^(SWGOptions* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOptionsApi->optionsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **options** | [**SWGOptions***](SWGOptions.md)|  nesnesi | 

### Return type

[**SWGOptions***](SWGOptions.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

