# SWGProductPrice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Ürün fiyatı nesnesi kimlik değeri. | [optional] 
**value** | **NSNumber*** | Ürün fiyatı değeri. | 
**type** | **NSNumber*** | Ürün fiyatı indexi. Fiyat 2, Fiyat 3 gibi. | 
**product** | [**SWGProduct***](SWGProduct.md) | Ürün nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


