# SWGMemberAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Üye adresi nesnesinin benzersiz rakamsal kimlik değeri. | [optional] 
**name** | **NSString*** | Üye Adresi adı. | [optional] 
**type** | **NSString*** | Üye Adresi tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;shipping&lt;/code&gt; : Teslimat adresi.&lt;br&gt;&lt;code&gt;billing&lt;/code&gt; : Fatura adresi.&lt;br&gt;&lt;/div&gt; | [optional] 
**firstname** | **NSString*** | Üyenin ismi. | [optional] 
**surname** | **NSString*** | Üyenin soy ismi. | [optional] 
**address** | **NSString*** | Üyenin adres bilgileri. | [optional] 
**subLocationName** | **NSString*** | İlçe adı. | [optional] 
**phoneNumber** | **NSString*** | Üyenin telefon numarası. | [optional] 
**mobilePhoneNumber** | **NSString*** | Üyenin mobil telefon numarası. | [optional] 
**tcId** | **NSString*** | Üyenin TC kimlik numarası. | [optional] 
**taxNumber** | **NSString*** | Üyenin vergi numarası. | [optional] 
**taxOffice** | **NSString*** | Üyenin vergi dairesi. | [optional] 
**invoiceType** | **NSString*** | Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt; | [optional] 
**isEinvoiceUser** | **NSNumber*** | Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] 
**createdAt** | **NSDate*** | Tema nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **NSDate*** | Tema nesnesinin güncellenme zamanı. | [optional] 
**member** | [**SWGMember***](SWGMember.md) | Üye nesnesi | [optional] 
**country** | [**SWGCountry***](SWGCountry.md) | Ülke nesnesi. | [optional] 
**location** | [**SWGLocation***](SWGLocation.md) | Şehir nesnesi. | [optional] 
**subLocation** | [**SWGTown***](SWGTown.md) | İlçe nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


