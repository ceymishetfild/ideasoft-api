# SWGCartItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cartItemsIdDelete**](SWGCartItemApi.md#cartitemsiddelete) | **DELETE** /cart_items/{id} | Sepet Kalemi Silme
[**cartItemsIdPut**](SWGCartItemApi.md#cartitemsidput) | **PUT** /cart_items/{id} | Sepet Kalemi Güncelleme
[**cartItemsPost**](SWGCartItemApi.md#cartitemspost) | **POST** /cart_items | Sepet Kalemi Oluşturma


# **cartItemsIdDelete**
```objc
-(NSURLSessionTask*) cartItemsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Sepet Kalemi Silme

Kalıcı olarak ilgili Sepet Kalemini siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Sepet Kalemi nesnesinin id değeri

SWGCartItemApi*apiInstance = [[SWGCartItemApi alloc] init];

// Sepet Kalemi Silme
[apiInstance cartItemsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGCartItemApi->cartItemsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Sepet Kalemi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cartItemsIdPut**
```objc
-(NSURLSessionTask*) cartItemsIdPutWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGCartItem* output, NSError* error)) handler;
```

Sepet Kalemi Güncelleme

İlgili Sepet Kalemini günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Sepet Kalemi nesnesinin id değeri

SWGCartItemApi*apiInstance = [[SWGCartItemApi alloc] init];

// Sepet Kalemi Güncelleme
[apiInstance cartItemsIdPutWithId:_id
          completionHandler: ^(SWGCartItem* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGCartItemApi->cartItemsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Sepet Kalemi nesnesinin id değeri | 

### Return type

[**SWGCartItem***](SWGCartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cartItemsPost**
```objc
-(NSURLSessionTask*) cartItemsPostWithCartItem: (SWGCartItem*) cartItem
        completionHandler: (void (^)(SWGCartItem* output, NSError* error)) handler;
```

Sepet Kalemi Oluşturma

Yeni bir Sepet Kalemi oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGCartItem* cartItem = [[SWGCartItem alloc] init]; //  nesnesi

SWGCartItemApi*apiInstance = [[SWGCartItemApi alloc] init];

// Sepet Kalemi Oluşturma
[apiInstance cartItemsPostWithCartItem:cartItem
          completionHandler: ^(SWGCartItem* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGCartItemApi->cartItemsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartItem** | [**SWGCartItem***](SWGCartItem.md)|  nesnesi | 

### Return type

[**SWGCartItem***](SWGCartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

