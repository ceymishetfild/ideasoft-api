# SWGProductToCountDownApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productToCountDownsGet**](SWGProductToCountDownApi.md#producttocountdownsget) | **GET** /product_to_count_downs | Ürün Geri Sayım Bağı Listesi Alma
[**productToCountDownsIdDelete**](SWGProductToCountDownApi.md#producttocountdownsiddelete) | **DELETE** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Silme
[**productToCountDownsIdGet**](SWGProductToCountDownApi.md#producttocountdownsidget) | **GET** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Alma
[**productToCountDownsIdPut**](SWGProductToCountDownApi.md#producttocountdownsidput) | **PUT** /product_to_count_downs/{id} | Ürün Geri Sayım Bağı Güncelleme
[**productToCountDownsPost**](SWGProductToCountDownApi.md#producttocountdownspost) | **POST** /product_to_count_downs | Ürün Geri Sayım Bağı Oluşturma


# **productToCountDownsGet**
```objc
-(NSURLSessionTask*) productToCountDownsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    product: (NSNumber*) product
        completionHandler: (void (^)(SWGProductToCountDown* output, NSError* error)) handler;
```

Ürün Geri Sayım Bağı Listesi Alma

Ürün Geri Sayım Bağı listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSNumber* product = @56; // Ürün id (optional)

SWGProductToCountDownApi*apiInstance = [[SWGProductToCountDownApi alloc] init];

// Ürün Geri Sayım Bağı Listesi Alma
[apiInstance productToCountDownsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              product:product
          completionHandler: ^(SWGProductToCountDown* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductToCountDownApi->productToCountDownsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **product** | **NSNumber***| Ürün id | [optional] 

### Return type

[**SWGProductToCountDown***](SWGProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productToCountDownsIdDelete**
```objc
-(NSURLSessionTask*) productToCountDownsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Ürün Geri Sayım Bağı Silme

Kalıcı olarak ilgili Ürün Geri Sayım Bağını siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Geri Sayım Bağı nesnesinin id değeri

SWGProductToCountDownApi*apiInstance = [[SWGProductToCountDownApi alloc] init];

// Ürün Geri Sayım Bağı Silme
[apiInstance productToCountDownsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGProductToCountDownApi->productToCountDownsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Geri Sayım Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productToCountDownsIdGet**
```objc
-(NSURLSessionTask*) productToCountDownsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGProductToCountDown* output, NSError* error)) handler;
```

Ürün Geri Sayım Bağı Alma

İlgili Ürün Geri Sayım Bağını getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Geri Sayım Bağı nesnesinin id değeri

SWGProductToCountDownApi*apiInstance = [[SWGProductToCountDownApi alloc] init];

// Ürün Geri Sayım Bağı Alma
[apiInstance productToCountDownsIdGetWithId:_id
          completionHandler: ^(SWGProductToCountDown* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductToCountDownApi->productToCountDownsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Geri Sayım Bağı nesnesinin id değeri | 

### Return type

[**SWGProductToCountDown***](SWGProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productToCountDownsIdPut**
```objc
-(NSURLSessionTask*) productToCountDownsIdPutWithId: (NSNumber*) _id
    productToCountDown: (SWGProductToCountDown*) productToCountDown
        completionHandler: (void (^)(SWGProductToCountDown* output, NSError* error)) handler;
```

Ürün Geri Sayım Bağı Güncelleme

İlgili Ürün Geri Sayım Bağını günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Geri Sayım Bağı nesnesinin id değeri
SWGProductToCountDown* productToCountDown = [[SWGProductToCountDown alloc] init]; //  nesnesi

SWGProductToCountDownApi*apiInstance = [[SWGProductToCountDownApi alloc] init];

// Ürün Geri Sayım Bağı Güncelleme
[apiInstance productToCountDownsIdPutWithId:_id
              productToCountDown:productToCountDown
          completionHandler: ^(SWGProductToCountDown* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductToCountDownApi->productToCountDownsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Geri Sayım Bağı nesnesinin id değeri | 
 **productToCountDown** | [**SWGProductToCountDown***](SWGProductToCountDown.md)|  nesnesi | 

### Return type

[**SWGProductToCountDown***](SWGProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productToCountDownsPost**
```objc
-(NSURLSessionTask*) productToCountDownsPostWithProductToCountDown: (SWGProductToCountDown*) productToCountDown
        completionHandler: (void (^)(SWGProductToCountDown* output, NSError* error)) handler;
```

Ürün Geri Sayım Bağı Oluşturma

Yeni bir Ürün Geri Sayım Bağı oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGProductToCountDown* productToCountDown = [[SWGProductToCountDown alloc] init]; //  nesnesi

SWGProductToCountDownApi*apiInstance = [[SWGProductToCountDownApi alloc] init];

// Ürün Geri Sayım Bağı Oluşturma
[apiInstance productToCountDownsPostWithProductToCountDown:productToCountDown
          completionHandler: ^(SWGProductToCountDown* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductToCountDownApi->productToCountDownsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productToCountDown** | [**SWGProductToCountDown***](SWGProductToCountDown.md)|  nesnesi | 

### Return type

[**SWGProductToCountDown***](SWGProductToCountDown.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

