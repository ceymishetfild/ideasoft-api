# SWGShipmentApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipmentsGet**](SWGShipmentApi.md#shipmentsget) | **GET** /shipments | Teslimat Listesi Alma
[**shipmentsIdDelete**](SWGShipmentApi.md#shipmentsiddelete) | **DELETE** /shipments/{id} | Teslimat Silme
[**shipmentsIdGet**](SWGShipmentApi.md#shipmentsidget) | **GET** /shipments/{id} | Teslimat Alma
[**shipmentsIdPut**](SWGShipmentApi.md#shipmentsidput) | **PUT** /shipments/{id} | Teslimat Güncelleme
[**shipmentsPost**](SWGShipmentApi.md#shipmentspost) | **POST** /shipments | Teslimat Oluşturma


# **shipmentsGet**
```objc
-(NSURLSessionTask*) shipmentsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    code: (NSString*) code
    invoiceKey: (NSString*) invoiceKey
    barcode: (NSString*) barcode
    order: (NSNumber*) order
    startDate: (NSDate*) startDate
    endDate: (NSString*) endDate
    startUpdatedAt: (NSDate*) startUpdatedAt
    endUpdatedAt: (NSString*) endUpdatedAt
        completionHandler: (void (^)(SWGShipment* output, NSError* error)) handler;
```

Teslimat Listesi Alma

Teslimat listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* code = @"code_example"; // Teslimat kodu (optional)
NSString* invoiceKey = @"invoiceKey_example"; // Teslimat fatura anahtarı (optional)
NSString* barcode = @"barcode_example"; // Teslimat barkodu (optional)
NSNumber* order = @56; // Sipariş id (optional)
NSDate* startDate = @"2013-10-20"; // createdAt değeri için başlangıç tarihi (optional)
NSString* endDate = @"endDate_example"; // createdAt değeri için bitiş tarihi (optional)
NSDate* startUpdatedAt = @"2013-10-20"; // updatedAt değeri için başlangıç tarihi (optional)
NSString* endUpdatedAt = @"endUpdatedAt_example"; // updatedAt değeri için bitiş tarihi (optional)

SWGShipmentApi*apiInstance = [[SWGShipmentApi alloc] init];

// Teslimat Listesi Alma
[apiInstance shipmentsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              code:code
              invoiceKey:invoiceKey
              barcode:barcode
              order:order
              startDate:startDate
              endDate:endDate
              startUpdatedAt:startUpdatedAt
              endUpdatedAt:endUpdatedAt
          completionHandler: ^(SWGShipment* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGShipmentApi->shipmentsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **code** | **NSString***| Teslimat kodu | [optional] 
 **invoiceKey** | **NSString***| Teslimat fatura anahtarı | [optional] 
 **barcode** | **NSString***| Teslimat barkodu | [optional] 
 **order** | **NSNumber***| Sipariş id | [optional] 
 **startDate** | **NSDate***| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **NSString***| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **NSDate***| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **NSString***| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**SWGShipment***](SWGShipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipmentsIdDelete**
```objc
-(NSURLSessionTask*) shipmentsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Teslimat Silme

Kalıcı olarak ilgili Teslimatı siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Teslimat nesnesinin id değeri

SWGShipmentApi*apiInstance = [[SWGShipmentApi alloc] init];

// Teslimat Silme
[apiInstance shipmentsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGShipmentApi->shipmentsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Teslimat nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipmentsIdGet**
```objc
-(NSURLSessionTask*) shipmentsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGShipment* output, NSError* error)) handler;
```

Teslimat Alma

İlgili Teslimatı getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Teslimat nesnesinin id değeri

SWGShipmentApi*apiInstance = [[SWGShipmentApi alloc] init];

// Teslimat Alma
[apiInstance shipmentsIdGetWithId:_id
          completionHandler: ^(SWGShipment* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGShipmentApi->shipmentsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Teslimat nesnesinin id değeri | 

### Return type

[**SWGShipment***](SWGShipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipmentsIdPut**
```objc
-(NSURLSessionTask*) shipmentsIdPutWithId: (NSNumber*) _id
    shipment: (SWGShipment*) shipment
        completionHandler: (void (^)(SWGShipment* output, NSError* error)) handler;
```

Teslimat Güncelleme

İlgili Teslimatı günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Teslimat nesnesinin id değeri
SWGShipment* shipment = [[SWGShipment alloc] init]; //  nesnesi

SWGShipmentApi*apiInstance = [[SWGShipmentApi alloc] init];

// Teslimat Güncelleme
[apiInstance shipmentsIdPutWithId:_id
              shipment:shipment
          completionHandler: ^(SWGShipment* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGShipmentApi->shipmentsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Teslimat nesnesinin id değeri | 
 **shipment** | [**SWGShipment***](SWGShipment.md)|  nesnesi | 

### Return type

[**SWGShipment***](SWGShipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipmentsPost**
```objc
-(NSURLSessionTask*) shipmentsPostWithShipment: (SWGShipment*) shipment
        completionHandler: (void (^)(SWGShipment* output, NSError* error)) handler;
```

Teslimat Oluşturma

Yeni bir Teslimat oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGShipment* shipment = [[SWGShipment alloc] init]; //  nesnesi

SWGShipmentApi*apiInstance = [[SWGShipmentApi alloc] init];

// Teslimat Oluşturma
[apiInstance shipmentsPostWithShipment:shipment
          completionHandler: ^(SWGShipment* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGShipmentApi->shipmentsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipment** | [**SWGShipment***](SWGShipment.md)|  nesnesi | 

### Return type

[**SWGShipment***](SWGShipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

