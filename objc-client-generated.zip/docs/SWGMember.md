# SWGMember

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Üye nesnesi kimlik değeri. | [optional] 
**firstname** | **NSString*** | Üyenin ismi. | 
**surname** | **NSString*** | Üyenin soy ismi. | 
**email** | **NSString*** | Üyenin e-mail adresi. | 
**gender** | **NSString*** | Üyenin cinsiyet bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın&lt;br&gt;&lt;/div&gt; | [optional] 
**birthDate** | **NSDate*** | Üyenin doğum tarihi. | [optional] 
**phoneNumber** | **NSString*** | Üyenin telefon numarası. | [optional] 
**mobilePhoneNumber** | **NSString*** | Üyenin mobil telefon numarası. | [optional] 
**otherLocation** | **NSString*** | Üyenin diğer şehir bilgileri. | [optional] 
**address** | **NSString*** | Üyenin adres bilgileri. | [optional] 
**taxNumber** | **NSString*** | Üyenin vergi numarası. | [optional] 
**tcId** | **NSString*** | Üyenin TC kimlik numarası. | [optional] 
**status** | **NSString*** | Üyenin durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;queue&lt;/code&gt; : Sırada&lt;br&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;suspended&lt;/code&gt; : Askıda&lt;br&gt;&lt;/div&gt; | 
**lastLoginDate** | **NSDate*** | Üyenin son giriş yaptığı tarih. | [optional] 
**createdAt** | **NSDate*** | Üye nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **NSDate*** | Üye nesnesinin güncellenme zamanı. | [optional] 
**zipCode** | **NSString*** | Üyenin posta kodu. | [optional] 
**commercialName** | **NSString*** | Üyenin kurumsal adı. | [optional] 
**taxOffice** | **NSString*** | Üyenin vergi dairesi. | [optional] 
**lastMailSentDate** | **NSDate*** | Üyeye gönderilen son e-mail tarihi. | [optional] 
**lastIp** | **NSString*** | Üyenin en son giriş yaptığı IP adresi. | [optional] 
**gainedPointAmount** | **NSNumber*** | Üyenin kazandığı puan tutarı. | [optional] 
**spentPointAmount** | **NSNumber*** | Üyenin harcadığı puan tutarı. | [optional] 
**allowedToCampaigns** | **NSString*** | Üyenin kampanyalara katılım için izin durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalar için izinli.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalar için izinsiz.&lt;br&gt;&lt;/div&gt; | [optional] 
**referredMemberGainedPointAmount** | **NSNumber*** | Üyenin tavsiye ettiği kişilerden dolayı kazandığı puan. | [optional] 
**district** | **NSString*** | Üyenin ilçesi. | [optional] 
**deviceType** | **NSString*** | Üyenin kullandığı cihaz tipi. | 
**deviceInfo** | **NSString*** | Üyenin kullandığı cihaz bilgisi. | [optional] 
**country** | [**SWGCountry***](SWGCountry.md) | Ülke nesnesi. | [optional] 
**location** | [**SWGLocation***](SWGLocation.md) | Şehir nesnesi. | [optional] 
**memberGroup** | [**SWGMemberGroup***](SWGMemberGroup.md) | Üye grubu nesnesi. | [optional] 
**referredMember** | [**SWGMember***](SWGMember.md) | Üyeyi tavsiye eden üye nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


