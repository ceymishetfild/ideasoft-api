# SWGSelection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Ek özellik nesnesi kimlik değeri. | [optional] 
**title** | **NSString*** | Ek özellik nesnesinin başlığı. | [optional] 
**sortOrder** | **NSNumber*** | Ek özellik nesnesi için sıralama değeri. | 
**selectionGroup** | [**SWGSelectionGroup***](SWGSelectionGroup.md) | Ek özellik grubu nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


