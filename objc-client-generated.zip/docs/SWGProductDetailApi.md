# SWGProductDetailApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productDetailsGet**](SWGProductDetailApi.md#productdetailsget) | **GET** /product_details | Ürün Detay Listesi Alma
[**productDetailsIdDelete**](SWGProductDetailApi.md#productdetailsiddelete) | **DELETE** /product_details/{id} | Ürün Detay Silme
[**productDetailsIdGet**](SWGProductDetailApi.md#productdetailsidget) | **GET** /product_details/{id} | Ürün Detay Alma
[**productDetailsIdPut**](SWGProductDetailApi.md#productdetailsidput) | **PUT** /product_details/{id} | Ürün Detay Güncelleme
[**productDetailsPost**](SWGProductDetailApi.md#productdetailspost) | **POST** /product_details | Ürün Detay Oluşturma


# **productDetailsGet**
```objc
-(NSURLSessionTask*) productDetailsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    sku: (NSString*) sku
        completionHandler: (void (^)(SWGProductDetail* output, NSError* error)) handler;
```

Ürün Detay Listesi Alma

Ürün Detay listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* sku = @"sku_example"; // Ürün stok kodu (optional)

SWGProductDetailApi*apiInstance = [[SWGProductDetailApi alloc] init];

// Ürün Detay Listesi Alma
[apiInstance productDetailsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              sku:sku
          completionHandler: ^(SWGProductDetail* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductDetailApi->productDetailsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **sku** | **NSString***| Ürün stok kodu | [optional] 

### Return type

[**SWGProductDetail***](SWGProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productDetailsIdDelete**
```objc
-(NSURLSessionTask*) productDetailsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Ürün Detay Silme

Kalıcı olarak ilgili Ürün Detayını siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Detay nesnesinin id değeri

SWGProductDetailApi*apiInstance = [[SWGProductDetailApi alloc] init];

// Ürün Detay Silme
[apiInstance productDetailsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGProductDetailApi->productDetailsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Detay nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productDetailsIdGet**
```objc
-(NSURLSessionTask*) productDetailsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGProductDetail* output, NSError* error)) handler;
```

Ürün Detay Alma

İlgili Ürün Detayını getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Detay nesnesinin id değeri

SWGProductDetailApi*apiInstance = [[SWGProductDetailApi alloc] init];

// Ürün Detay Alma
[apiInstance productDetailsIdGetWithId:_id
          completionHandler: ^(SWGProductDetail* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductDetailApi->productDetailsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Detay nesnesinin id değeri | 

### Return type

[**SWGProductDetail***](SWGProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productDetailsIdPut**
```objc
-(NSURLSessionTask*) productDetailsIdPutWithId: (NSNumber*) _id
    productDetail: (SWGProductDetail*) productDetail
        completionHandler: (void (^)(SWGProductDetail* output, NSError* error)) handler;
```

Ürün Detay Güncelleme

İlgili Ürün Detayını günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Detay nesnesinin id değeri
SWGProductDetail* productDetail = [[SWGProductDetail alloc] init]; //  nesnesi

SWGProductDetailApi*apiInstance = [[SWGProductDetailApi alloc] init];

// Ürün Detay Güncelleme
[apiInstance productDetailsIdPutWithId:_id
              productDetail:productDetail
          completionHandler: ^(SWGProductDetail* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductDetailApi->productDetailsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Detay nesnesinin id değeri | 
 **productDetail** | [**SWGProductDetail***](SWGProductDetail.md)|  nesnesi | 

### Return type

[**SWGProductDetail***](SWGProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productDetailsPost**
```objc
-(NSURLSessionTask*) productDetailsPostWithProductDetail: (SWGProductDetail*) productDetail
        completionHandler: (void (^)(SWGProductDetail* output, NSError* error)) handler;
```

Ürün Detay Oluşturma

Yeni bir Ürün Detay oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGProductDetail* productDetail = [[SWGProductDetail alloc] init]; //  nesnesi

SWGProductDetailApi*apiInstance = [[SWGProductDetailApi alloc] init];

// Ürün Detay Oluşturma
[apiInstance productDetailsPostWithProductDetail:productDetail
          completionHandler: ^(SWGProductDetail* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductDetailApi->productDetailsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productDetail** | [**SWGProductDetail***](SWGProductDetail.md)|  nesnesi | 

### Return type

[**SWGProductDetail***](SWGProductDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

