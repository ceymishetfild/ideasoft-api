# SWGThemeApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**themesGet**](SWGThemeApi.md#themesget) | **GET** /themes | Tema Listesi Alma
[**themesIdAssetsGet**](SWGThemeApi.md#themesidassetsget) | **GET** /themes/{id}/assets | Tema Dosyası Listesi Alma
[**themesIdAssetskeykeyDelete**](SWGThemeApi.md#themesidassetskeykeydelete) | **DELETE** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Silme
[**themesIdAssetskeykeyGet**](SWGThemeApi.md#themesidassetskeykeyget) | **GET** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Alma
[**themesIdAssetskeykeyPut**](SWGThemeApi.md#themesidassetskeykeyput) | **PUT** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Güncelleme
[**themesIdDelete**](SWGThemeApi.md#themesiddelete) | **DELETE** /themes/{id} | Tema Silme
[**themesIdGet**](SWGThemeApi.md#themesidget) | **GET** /themes/{id} | Tema Alma
[**themesIdPut**](SWGThemeApi.md#themesidput) | **PUT** /themes/{id} | Tema Güncelleme
[**themesPost**](SWGThemeApi.md#themespost) | **POST** /themes | Tema Oluşturma


# **themesGet**
```objc
-(NSURLSessionTask*) themesGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    status: (NSNumber*) status
    platform: (NSString*) platform
    type: (NSString*) type
        completionHandler: (void (^)(SWGTheme* output, NSError* error)) handler;
```

Tema Listesi Alma

Tema listesi verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSNumber* status = @56; // Tema durumu (optional)
NSString* platform = @"platform_example"; // Tema platformu (optional)
NSString* type = @"type_example"; // Tema tipi (optional)

SWGThemeApi*apiInstance = [[SWGThemeApi alloc] init];

// Tema Listesi Alma
[apiInstance themesGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              status:status
              platform:platform
              type:type
          completionHandler: ^(SWGTheme* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGThemeApi->themesGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **status** | **NSNumber***| Tema durumu | [optional] 
 **platform** | **NSString***| Tema platformu | [optional] 
 **type** | **NSString***| Tema tipi | [optional] 

### Return type

[**SWGTheme***](SWGTheme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themesIdAssetsGet**
```objc
-(NSURLSessionTask*) themesIdAssetsGetWithId: (NSNumber*) _id
    key: (NSString*) key
        completionHandler: (void (^)(SWGAsset* output, NSError* error)) handler;
```

Tema Dosyası Listesi Alma

Tema Dosyası listesi verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Tema nesnesinin id değeri
NSString* key = @"key_example"; // Tema Dosyası nesnesi anahtar değeri. (optional)

SWGThemeApi*apiInstance = [[SWGThemeApi alloc] init];

// Tema Dosyası Listesi Alma
[apiInstance themesIdAssetsGetWithId:_id
              key:key
          completionHandler: ^(SWGAsset* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGThemeApi->themesIdAssetsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Tema nesnesinin id değeri | 
 **key** | **NSString***| Tema Dosyası nesnesi anahtar değeri. | [optional] 

### Return type

[**SWGAsset***](SWGAsset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themesIdAssetskeykeyDelete**
```objc
-(NSURLSessionTask*) themesIdAssetskeykeyDeleteWithId: (NSNumber*) _id
    key: (NSString*) key
        completionHandler: (void (^)(NSError* error)) handler;
```

Tema Dosyası Silme

Kalıcı olarak ilgili Tema Dosyasını siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Tema nesnesinin id değeri
NSString* key = @"key_example"; // Tema Dosyası nesnesi anahtar değeri.

SWGThemeApi*apiInstance = [[SWGThemeApi alloc] init];

// Tema Dosyası Silme
[apiInstance themesIdAssetskeykeyDeleteWithId:_id
              key:key
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGThemeApi->themesIdAssetskeykeyDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Tema nesnesinin id değeri | 
 **key** | **NSString***| Tema Dosyası nesnesi anahtar değeri. | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themesIdAssetskeykeyGet**
```objc
-(NSURLSessionTask*) themesIdAssetskeykeyGetWithId: (NSNumber*) _id
    key: (NSString*) key
        completionHandler: (void (^)(SWGAsset* output, NSError* error)) handler;
```

Tema Dosyası Alma

İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Tema nesnesinin id değeri
NSString* key = @"key_example"; // Tema Dosyası nesnesi anahtar değeri.

SWGThemeApi*apiInstance = [[SWGThemeApi alloc] init];

// Tema Dosyası Alma
[apiInstance themesIdAssetskeykeyGetWithId:_id
              key:key
          completionHandler: ^(SWGAsset* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGThemeApi->themesIdAssetskeykeyGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Tema nesnesinin id değeri | 
 **key** | **NSString***| Tema Dosyası nesnesi anahtar değeri. | 

### Return type

[**SWGAsset***](SWGAsset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themesIdAssetskeykeyPut**
```objc
-(NSURLSessionTask*) themesIdAssetskeykeyPutWithId: (NSNumber*) _id
    theme: (SWGTheme*) theme
    asset: (SWGAsset*) asset
        completionHandler: (void (^)(SWGAsset* output, NSError* error)) handler;
```

Tema Dosyası Güncelleme

Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Tema nesnesinin id değeri
SWGTheme* theme = [[SWGTheme alloc] init]; //  nesnesi
SWGAsset* asset = [[SWGAsset alloc] init]; //  nesnesi

SWGThemeApi*apiInstance = [[SWGThemeApi alloc] init];

// Tema Dosyası Güncelleme
[apiInstance themesIdAssetskeykeyPutWithId:_id
              theme:theme
              asset:asset
          completionHandler: ^(SWGAsset* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGThemeApi->themesIdAssetskeykeyPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Tema nesnesinin id değeri | 
 **theme** | [**SWGTheme***](SWGTheme.md)|  nesnesi | 
 **asset** | [**SWGAsset***](SWGAsset.md)|  nesnesi | 

### Return type

[**SWGAsset***](SWGAsset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themesIdDelete**
```objc
-(NSURLSessionTask*) themesIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Tema Silme

Kalıcı olarak ilgili Temayı siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Tema nesnesinin id değeri

SWGThemeApi*apiInstance = [[SWGThemeApi alloc] init];

// Tema Silme
[apiInstance themesIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGThemeApi->themesIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Tema nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themesIdGet**
```objc
-(NSURLSessionTask*) themesIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGTheme* output, NSError* error)) handler;
```

Tema Alma

İlgili Temayı getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Tema nesnesinin id değeri

SWGThemeApi*apiInstance = [[SWGThemeApi alloc] init];

// Tema Alma
[apiInstance themesIdGetWithId:_id
          completionHandler: ^(SWGTheme* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGThemeApi->themesIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Tema nesnesinin id değeri | 

### Return type

[**SWGTheme***](SWGTheme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themesIdPut**
```objc
-(NSURLSessionTask*) themesIdPutWithId: (NSNumber*) _id
    theme: (SWGTheme*) theme
        completionHandler: (void (^)(SWGTheme* output, NSError* error)) handler;
```

Tema Güncelleme

İlgili Temayı günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Tema nesnesinin id değeri
SWGTheme* theme = [[SWGTheme alloc] init]; //  nesnesi

SWGThemeApi*apiInstance = [[SWGThemeApi alloc] init];

// Tema Güncelleme
[apiInstance themesIdPutWithId:_id
              theme:theme
          completionHandler: ^(SWGTheme* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGThemeApi->themesIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Tema nesnesinin id değeri | 
 **theme** | [**SWGTheme***](SWGTheme.md)|  nesnesi | 

### Return type

[**SWGTheme***](SWGTheme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themesPost**
```objc
-(NSURLSessionTask*) themesPostWithTheme: (SWGTheme*) theme
        completionHandler: (void (^)(SWGTheme* output, NSError* error)) handler;
```

Tema Oluşturma

Yeni bir tema oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGTheme* theme = [[SWGTheme alloc] init]; //  nesnesi

SWGThemeApi*apiInstance = [[SWGThemeApi alloc] init];

// Tema Oluşturma
[apiInstance themesPostWithTheme:theme
          completionHandler: ^(SWGTheme* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGThemeApi->themesPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **theme** | [**SWGTheme***](SWGTheme.md)|  nesnesi | 

### Return type

[**SWGTheme***](SWGTheme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

