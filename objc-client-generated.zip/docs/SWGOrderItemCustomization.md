# SWGOrderItemCustomization

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Sipariş kalemi özelleştirme kimlik değeri. | [optional] 
**productCustomizationGroupId** | **NSNumber*** | Ürün özelleştirme grubu nesnesi kimlik değeri. | [optional] 
**productCustomizationGroupName** | **NSString*** | Ürün özelleştirme grubu nesnesinin grup adı. | [optional] 
**productCustomizationGroupSortOrder** | **NSNumber*** | Ürün özelleştirme grubu nesnesinin sıralaması. | [optional] 
**productCustomizationFieldId** | **NSNumber*** | Ürün özelleştirme nesnesi kimlik değeri.. | [optional] 
**productCustomizationFieldType** | **NSString*** | Ürün özelleştirme nesnesinin alan tipi. | [optional] 
**productCustomizationFieldName** | **NSString*** | Ürün özelleştirme nesnesinin alan adı. | [optional] 
**productCustomizationFieldValue** | **NSString*** | Ürün özelleştirme nesnesinin değeri. | [optional] 
**cartItemAttributeId** | **NSNumber*** | Sepet kalemi özelliği nesnesi kimlik değeri. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


