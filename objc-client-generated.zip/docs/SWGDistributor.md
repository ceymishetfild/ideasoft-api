# SWGDistributor

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Distributor nesnesi kimlik değeri. | [optional] 
**name** | **NSString*** | Distributor nesnesi için isim değeri. | 
**email** | **NSString*** | E-mail adresi. | [optional] 
**phone** | **NSString*** | Telefon numarası. | [optional] 
**contactPerson** | **NSString*** | İletişim kişisi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


