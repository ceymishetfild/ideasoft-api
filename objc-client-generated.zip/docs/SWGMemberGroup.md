# SWGMemberGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Üye Grubu nesnesi kimlik değeri. | [optional] 
**name** | **NSString*** | Üye Grubu nesnesi için isim değeri. | 
**priceIndex** | **NSNumber*** | Üye Grubunun fiyat indisi. Örnek Fiyat 2. | 
**allowedPaymentGateways** | **NSString*** | Üye Grubunun izin verilmiş ödeme kanalları. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


