# SWGDistributorToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**distributorToProductsGet**](SWGDistributorToProductApi.md#distributortoproductsget) | **GET** /distributor_to_products | Distribütör Ürün Bağı Listesi Alma
[**distributorToProductsIdDelete**](SWGDistributorToProductApi.md#distributortoproductsiddelete) | **DELETE** /distributor_to_products/{id} | Distribütör Ürün Bağı Silme
[**distributorToProductsIdGet**](SWGDistributorToProductApi.md#distributortoproductsidget) | **GET** /distributor_to_products/{id} | Distribütör Ürün Bağı Alma
[**distributorToProductsIdPut**](SWGDistributorToProductApi.md#distributortoproductsidput) | **PUT** /distributor_to_products/{id} | Distribütör Ürün Bağı Güncelleme
[**distributorToProductsPost**](SWGDistributorToProductApi.md#distributortoproductspost) | **POST** /distributor_to_products | Distribütör Ürün Bağı Oluşturma


# **distributorToProductsGet**
```objc
-(NSURLSessionTask*) distributorToProductsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    distributor: (NSNumber*) distributor
    product: (NSNumber*) product
        completionHandler: (void (^)(SWGDistributorToProduct* output, NSError* error)) handler;
```

Distribütör Ürün Bağı Listesi Alma

Distribütör Ürün Bağı listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSNumber* distributor = @56; // Distribütör id (optional)
NSNumber* product = @56; // Ürün id (optional)

SWGDistributorToProductApi*apiInstance = [[SWGDistributorToProductApi alloc] init];

// Distribütör Ürün Bağı Listesi Alma
[apiInstance distributorToProductsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              distributor:distributor
              product:product
          completionHandler: ^(SWGDistributorToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGDistributorToProductApi->distributorToProductsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **distributor** | **NSNumber***| Distribütör id | [optional] 
 **product** | **NSNumber***| Ürün id | [optional] 

### Return type

[**SWGDistributorToProduct***](SWGDistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributorToProductsIdDelete**
```objc
-(NSURLSessionTask*) distributorToProductsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Distribütör Ürün Bağı Silme

Kalıcı olarak ilgili Distribütör Ürün Bağını siler

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Distribütör Ürün Bağı nesnesinin id değeri

SWGDistributorToProductApi*apiInstance = [[SWGDistributorToProductApi alloc] init];

// Distribütör Ürün Bağı Silme
[apiInstance distributorToProductsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGDistributorToProductApi->distributorToProductsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Distribütör Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributorToProductsIdGet**
```objc
-(NSURLSessionTask*) distributorToProductsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGDistributorToProduct* output, NSError* error)) handler;
```

Distribütör Ürün Bağı Alma

İlgili Distribütör Ürün Bağını getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Distribütör Ürün Bağı nesnesinin id değeri

SWGDistributorToProductApi*apiInstance = [[SWGDistributorToProductApi alloc] init];

// Distribütör Ürün Bağı Alma
[apiInstance distributorToProductsIdGetWithId:_id
          completionHandler: ^(SWGDistributorToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGDistributorToProductApi->distributorToProductsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Distribütör Ürün Bağı nesnesinin id değeri | 

### Return type

[**SWGDistributorToProduct***](SWGDistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributorToProductsIdPut**
```objc
-(NSURLSessionTask*) distributorToProductsIdPutWithId: (NSNumber*) _id
    distributorToProduct: (SWGDistributorToProduct*) distributorToProduct
        completionHandler: (void (^)(SWGDistributorToProduct* output, NSError* error)) handler;
```

Distribütör Ürün Bağı Güncelleme

İlgili Distribütör Ürün Bağını günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Distribütör Ürün Bağı nesnesinin id değeri
SWGDistributorToProduct* distributorToProduct = [[SWGDistributorToProduct alloc] init]; //  nesnesi

SWGDistributorToProductApi*apiInstance = [[SWGDistributorToProductApi alloc] init];

// Distribütör Ürün Bağı Güncelleme
[apiInstance distributorToProductsIdPutWithId:_id
              distributorToProduct:distributorToProduct
          completionHandler: ^(SWGDistributorToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGDistributorToProductApi->distributorToProductsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Distribütör Ürün Bağı nesnesinin id değeri | 
 **distributorToProduct** | [**SWGDistributorToProduct***](SWGDistributorToProduct.md)|  nesnesi | 

### Return type

[**SWGDistributorToProduct***](SWGDistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributorToProductsPost**
```objc
-(NSURLSessionTask*) distributorToProductsPostWithDistributorToProduct: (SWGDistributorToProduct*) distributorToProduct
        completionHandler: (void (^)(SWGDistributorToProduct* output, NSError* error)) handler;
```

Distribütör Ürün Bağı Oluşturma

Yeni bir Distribütör Ürün Bağı oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGDistributorToProduct* distributorToProduct = [[SWGDistributorToProduct alloc] init]; //  nesnesi

SWGDistributorToProductApi*apiInstance = [[SWGDistributorToProductApi alloc] init];

// Distribütör Ürün Bağı Oluşturma
[apiInstance distributorToProductsPostWithDistributorToProduct:distributorToProduct
          completionHandler: ^(SWGDistributorToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGDistributorToProductApi->distributorToProductsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **distributorToProduct** | [**SWGDistributorToProduct***](SWGDistributorToProduct.md)|  nesnesi | 

### Return type

[**SWGDistributorToProduct***](SWGDistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

