# SWGMemberApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**membersChartsGet**](SWGMemberApi.md#memberschartsget) | **GET** /members/charts | Üye Grafik Aksiyonu
[**membersCombinedGet**](SWGMemberApi.md#memberscombinedget) | **GET** /members/combined | Üye Birleşik Aksiyonu
[**membersGet**](SWGMemberApi.md#membersget) | **GET** /members | Üye Listesi Alma
[**membersIdDelete**](SWGMemberApi.md#membersiddelete) | **DELETE** /members/{id} | Üye Silme
[**membersIdGet**](SWGMemberApi.md#membersidget) | **GET** /members/{id} | Üye Alma
[**membersIdPut**](SWGMemberApi.md#membersidput) | **PUT** /members/{id} | Üye Güncelleme
[**membersPost**](SWGMemberApi.md#memberspost) | **POST** /members | Üye Oluşturma


# **membersChartsGet**
```objc
-(NSURLSessionTask*) membersChartsGetWithTimeFrame: (NSString*) timeFrame
    startDate: (NSString*) startDate
        completionHandler: (void (^)(SWGMember* output, NSError* error)) handler;
```

Üye Grafik Aksiyonu

Zaman bazında üye genel istatistiklerini getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* timeFrame = @"timeFrame_example"; // Şu değerleri olabilir: full, year, month or week
NSString* startDate = @"startDate_example"; // Zaman aralığının başlangıcı

SWGMemberApi*apiInstance = [[SWGMemberApi alloc] init];

// Üye Grafik Aksiyonu
[apiInstance membersChartsGetWithTimeFrame:timeFrame
              startDate:startDate
          completionHandler: ^(SWGMember* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMemberApi->membersChartsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timeFrame** | **NSString***| Şu değerleri olabilir: full, year, month or week | 
 **startDate** | **NSString***| Zaman aralığının başlangıcı | 

### Return type

[**SWGMember***](SWGMember.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **membersCombinedGet**
```objc
-(NSURLSessionTask*) membersCombinedGetWithCompletionHandler: 
        (void (^)(SWGMember* output, NSError* error)) handler;
```

Üye Birleşik Aksiyonu

Bugün, aylık, yıllık ve toplam üye oturum açma istatistiklerini totalCount cinsinden getirir.

### Example 
```objc


SWGMemberApi*apiInstance = [[SWGMemberApi alloc] init];

// Üye Birleşik Aksiyonu
[apiInstance membersCombinedGetWithCompletionHandler: 
          ^(SWGMember* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMemberApi->membersCombinedGet: %@", error);
                        }
                    }];
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**SWGMember***](SWGMember.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **membersGet**
```objc
-(NSURLSessionTask*) membersGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    firstname: (NSString*) firstname
    surname: (NSString*) surname
    email: (NSString*) email
    password: (NSString*) password
    gender: (NSString*) gender
    mobilePhoneNumber: (NSString*) mobilePhoneNumber
    phoneNumber: (NSString*) phoneNumber
    memberGroup: (NSNumber*) memberGroup
    location: (NSNumber*) location
    country: (NSNumber*) country
    referredMember: (NSNumber*) referredMember
    q: (NSArray<NSString*>*) q
    startDate: (NSDate*) startDate
    endDate: (NSString*) endDate
    startUpdatedAt: (NSDate*) startUpdatedAt
    endUpdatedAt: (NSString*) endUpdatedAt
        completionHandler: (void (^)(SWGMember* output, NSError* error)) handler;
```

Üye Listesi Alma

Üye listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* firstname = @"firstname_example"; // Adı (optional)
NSString* surname = @"surname_example"; // Soyadı (optional)
NSString* email = @"email_example"; // e-mail adresi (optional)
NSString* password = @"password_example"; // Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri (optional)
NSString* gender = @"gender_example"; // Cinsiyet şu değerleri alabilir: <br><code>male</code> : Erkek<br><code>female</code> : Kadın (optional)
NSString* mobilePhoneNumber = @"mobilePhoneNumber_example"; // Üye mobil telefon numarası (optional)
NSString* phoneNumber = @"phoneNumber_example"; // Üye telefon numarası (optional)
NSNumber* memberGroup = @56; // Üye Grubu id (optional)
NSNumber* location = @56; // Şehir id (optional)
NSNumber* country = @56; // Ülke id (optional)
NSNumber* referredMember = @56; // Tavsiye Üye id (optional)
NSArray<NSString*>* q = @[@"q_example"]; // Üye arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;] (optional)
NSDate* startDate = @"2013-10-20"; // createdAt değeri için başlangıç tarihi (optional)
NSString* endDate = @"endDate_example"; // createdAt değeri için bitiş tarihi (optional)
NSDate* startUpdatedAt = @"2013-10-20"; // updatedAt değeri için başlangıç tarihi (optional)
NSString* endUpdatedAt = @"endUpdatedAt_example"; // updatedAt değeri için bitiş tarihi (optional)

SWGMemberApi*apiInstance = [[SWGMemberApi alloc] init];

// Üye Listesi Alma
[apiInstance membersGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              firstname:firstname
              surname:surname
              email:email
              password:password
              gender:gender
              mobilePhoneNumber:mobilePhoneNumber
              phoneNumber:phoneNumber
              memberGroup:memberGroup
              location:location
              country:country
              referredMember:referredMember
              q:q
              startDate:startDate
              endDate:endDate
              startUpdatedAt:startUpdatedAt
              endUpdatedAt:endUpdatedAt
          completionHandler: ^(SWGMember* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMemberApi->membersGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **firstname** | **NSString***| Adı | [optional] 
 **surname** | **NSString***| Soyadı | [optional] 
 **email** | **NSString***| e-mail adresi | [optional] 
 **password** | **NSString***| Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri | [optional] 
 **gender** | **NSString***| Cinsiyet şu değerleri alabilir: &lt;br&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın | [optional] 
 **mobilePhoneNumber** | **NSString***| Üye mobil telefon numarası | [optional] 
 **phoneNumber** | **NSString***| Üye telefon numarası | [optional] 
 **memberGroup** | **NSNumber***| Üye Grubu id | [optional] 
 **location** | **NSNumber***| Şehir id | [optional] 
 **country** | **NSNumber***| Ülke id | [optional] 
 **referredMember** | **NSNumber***| Tavsiye Üye id | [optional] 
 **q** | [**NSArray&lt;NSString*&gt;***](NSString*.md)| Üye arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 
 **startDate** | **NSDate***| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **NSString***| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **NSDate***| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **NSString***| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**SWGMember***](SWGMember.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **membersIdDelete**
```objc
-(NSURLSessionTask*) membersIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Üye Silme

Kalıcı olarak ilgili Üyeyi siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Üye nesnesinin id değeri

SWGMemberApi*apiInstance = [[SWGMemberApi alloc] init];

// Üye Silme
[apiInstance membersIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGMemberApi->membersIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Üye nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **membersIdGet**
```objc
-(NSURLSessionTask*) membersIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGMember* output, NSError* error)) handler;
```

Üye Alma

İlgili Üyeyi getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Üye nesnesinin id değeri

SWGMemberApi*apiInstance = [[SWGMemberApi alloc] init];

// Üye Alma
[apiInstance membersIdGetWithId:_id
          completionHandler: ^(SWGMember* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMemberApi->membersIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Üye nesnesinin id değeri | 

### Return type

[**SWGMember***](SWGMember.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **membersIdPut**
```objc
-(NSURLSessionTask*) membersIdPutWithId: (NSNumber*) _id
    member: (SWGMember*) member
        completionHandler: (void (^)(SWGMember* output, NSError* error)) handler;
```

Üye Güncelleme

İlgili Üyeyi günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Üye nesnesinin id değeri
SWGMember* member = [[SWGMember alloc] init]; //  nesnesi

SWGMemberApi*apiInstance = [[SWGMemberApi alloc] init];

// Üye Güncelleme
[apiInstance membersIdPutWithId:_id
              member:member
          completionHandler: ^(SWGMember* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMemberApi->membersIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Üye nesnesinin id değeri | 
 **member** | [**SWGMember***](SWGMember.md)|  nesnesi | 

### Return type

[**SWGMember***](SWGMember.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **membersPost**
```objc
-(NSURLSessionTask*) membersPostWithMember: (SWGMember*) member
        completionHandler: (void (^)(SWGMember* output, NSError* error)) handler;
```

Üye Oluşturma

Yeni bir Üye oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGMember* member = [[SWGMember alloc] init]; //  nesnesi

SWGMemberApi*apiInstance = [[SWGMemberApi alloc] init];

// Üye Oluşturma
[apiInstance membersPostWithMember:member
          completionHandler: ^(SWGMember* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMemberApi->membersPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member** | [**SWGMember***](SWGMember.md)|  nesnesi | 

### Return type

[**SWGMember***](SWGMember.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

