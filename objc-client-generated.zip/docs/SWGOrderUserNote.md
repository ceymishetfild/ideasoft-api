# SWGOrderUserNote

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Sipariş yönetici notu nesnesi kimlik değeri. | [optional] 
**userEmail** | **NSString*** | Yöneticinin(admin) e-mail adresi. | 
**userFirstname** | **NSString*** | Yöneticinin(admin) ismi. | [optional] 
**userSurname** | **NSString*** | Yöneticinin(admin) soy ismi. | [optional] 
**note** | **NSString*** | Yöneticinin(admin) sipariş için girdiği not. | 
**createdAt** | **NSDate*** | Sipariş yönetici notu nesnesinin oluşturulma zamanı. | 
**updatedAt** | **NSDate*** | Sipariş yönetici notu nesnesinin güncellenme zamanı. | 
**order** | [**SWGOrder***](SWGOrder.md) | Sipariş nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


