# SWGOptionGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Varyant grubu nesnesi kimlik değeri. | [optional] 
**title** | **NSString*** | Varyant grubunun başlığı. Varyant değeri kırmızı ise bu değer renk olabilir. | 
**sortOrder** | **NSNumber*** | Varyant grubunun sıralama değeri. | [optional] 
**filterStatus** | **NSString*** | Varyant grubunun filtre menüsündeki gösterim durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Gösterilsin.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Gösterilmesin.&lt;br&gt;&lt;/div&gt; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


