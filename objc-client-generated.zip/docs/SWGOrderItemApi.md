# SWGOrderItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**orderItemsGet**](SWGOrderItemApi.md#orderitemsget) | **GET** /order_items | Sipariş Kalemi Listesi Alma
[**orderItemsIdGet**](SWGOrderItemApi.md#orderitemsidget) | **GET** /order_items/{id} | Sipariş Kalemi Alma


# **orderItemsGet**
```objc
-(NSURLSessionTask*) orderItemsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    order: (NSNumber*) order
    productName: (NSString*) productName
    productSku: (NSString*) productSku
    productBarcode: (NSString*) productBarcode
    startDate: (NSDate*) startDate
    endDate: (NSString*) endDate
    startUpdatedAt: (NSDate*) startUpdatedAt
    endUpdatedAt: (NSString*) endUpdatedAt
        completionHandler: (void (^)(SWGOrderItem* output, NSError* error)) handler;
```

Sipariş Kalemi Listesi Alma

Sipariş Kalemi listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSNumber* order = @56; // Sipariş id (optional)
NSString* productName = @"productName_example"; // Ürün adı (optional)
NSString* productSku = @"productSku_example"; // Ürün stok kodu (optional)
NSString* productBarcode = @"productBarcode_example"; // Ürün barkodu (optional)
NSDate* startDate = @"2013-10-20"; // createdAt değeri için başlangıç tarihi (optional)
NSString* endDate = @"endDate_example"; // createdAt değeri için bitiş tarihi (optional)
NSDate* startUpdatedAt = @"2013-10-20"; // updatedAt değeri için başlangıç tarihi (optional)
NSString* endUpdatedAt = @"endUpdatedAt_example"; // updatedAt değeri için bitiş tarihi (optional)

SWGOrderItemApi*apiInstance = [[SWGOrderItemApi alloc] init];

// Sipariş Kalemi Listesi Alma
[apiInstance orderItemsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              order:order
              productName:productName
              productSku:productSku
              productBarcode:productBarcode
              startDate:startDate
              endDate:endDate
              startUpdatedAt:startUpdatedAt
              endUpdatedAt:endUpdatedAt
          completionHandler: ^(SWGOrderItem* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOrderItemApi->orderItemsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **order** | **NSNumber***| Sipariş id | [optional] 
 **productName** | **NSString***| Ürün adı | [optional] 
 **productSku** | **NSString***| Ürün stok kodu | [optional] 
 **productBarcode** | **NSString***| Ürün barkodu | [optional] 
 **startDate** | **NSDate***| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **NSString***| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **NSDate***| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **NSString***| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**SWGOrderItem***](SWGOrderItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **orderItemsIdGet**
```objc
-(NSURLSessionTask*) orderItemsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGOrderItem* output, NSError* error)) handler;
```

Sipariş Kalemi Alma

İlgili Sipariş Kalemini getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Sipariş Kalemi nesnesinin id değeri

SWGOrderItemApi*apiInstance = [[SWGOrderItemApi alloc] init];

// Sipariş Kalemi Alma
[apiInstance orderItemsIdGetWithId:_id
          completionHandler: ^(SWGOrderItem* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOrderItemApi->orderItemsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Sipariş Kalemi nesnesinin id değeri | 

### Return type

[**SWGOrderItem***](SWGOrderItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

