# SWGShopPreferenceApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**preferencesGet**](SWGShopPreferenceApi.md#preferencesget) | **GET** /preferences | Tanımlamalar Listesi Alma
[**preferencesIdGet**](SWGShopPreferenceApi.md#preferencesidget) | **GET** /preferences/{id} | Tanımlamalar Alma
[**preferencesIdPut**](SWGShopPreferenceApi.md#preferencesidput) | **PUT** /preferences/{id} | Tanımlamalar Güncelleme


# **preferencesGet**
```objc
-(NSURLSessionTask*) preferencesGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    varKey: (NSString*) varKey
        completionHandler: (void (^)(SWGShopPreference* output, NSError* error)) handler;
```

Tanımlamalar Listesi Alma

Tanımlamalar listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @100; // Bir sayfada gelecek sonuç adedi (optional) (default to 100)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* varKey = @"varKey_example"; // Tanımlama varKey değeri (optional)

SWGShopPreferenceApi*apiInstance = [[SWGShopPreferenceApi alloc] init];

// Tanımlamalar Listesi Alma
[apiInstance preferencesGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              varKey:varKey
          completionHandler: ^(SWGShopPreference* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGShopPreferenceApi->preferencesGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 100]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **varKey** | **NSString***| Tanımlama varKey değeri | [optional] 

### Return type

[**SWGShopPreference***](SWGShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **preferencesIdGet**
```objc
-(NSURLSessionTask*) preferencesIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGShopPreference* output, NSError* error)) handler;
```

Tanımlamalar Alma

İlgili Tanımlamayı getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Tanımlama nesnesinin id değeri

SWGShopPreferenceApi*apiInstance = [[SWGShopPreferenceApi alloc] init];

// Tanımlamalar Alma
[apiInstance preferencesIdGetWithId:_id
          completionHandler: ^(SWGShopPreference* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGShopPreferenceApi->preferencesIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Tanımlama nesnesinin id değeri | 

### Return type

[**SWGShopPreference***](SWGShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **preferencesIdPut**
```objc
-(NSURLSessionTask*) preferencesIdPutWithId: (NSNumber*) _id
    shopPreference: (SWGShopPreference*) shopPreference
        completionHandler: (void (^)(SWGShopPreference* output, NSError* error)) handler;
```

Tanımlamalar Güncelleme

İlgili Tanımlamayı günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Tanımlama nesnesinin id değeri
SWGShopPreference* shopPreference = [[SWGShopPreference alloc] init]; //  nesnesi

SWGShopPreferenceApi*apiInstance = [[SWGShopPreferenceApi alloc] init];

// Tanımlamalar Güncelleme
[apiInstance preferencesIdPutWithId:_id
              shopPreference:shopPreference
          completionHandler: ^(SWGShopPreference* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGShopPreferenceApi->preferencesIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Tanımlama nesnesinin id değeri | 
 **shopPreference** | [**SWGShopPreference***](SWGShopPreference.md)|  nesnesi | 

### Return type

[**SWGShopPreference***](SWGShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

