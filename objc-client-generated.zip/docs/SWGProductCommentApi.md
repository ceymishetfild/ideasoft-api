# SWGProductCommentApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productCommentsGet**](SWGProductCommentApi.md#productcommentsget) | **GET** /product_comments | Ürün Yorumları Listesi Alma
[**productCommentsIdDelete**](SWGProductCommentApi.md#productcommentsiddelete) | **DELETE** /product_comments/{id} | Ürün Yorumu Silme
[**productCommentsIdGet**](SWGProductCommentApi.md#productcommentsidget) | **GET** /product_comments/{id} | Ürün Yorumu Alma
[**productCommentsIdPut**](SWGProductCommentApi.md#productcommentsidput) | **PUT** /product_comments/{id} | Ürün Yorumu Güncelleme
[**productCommentsPost**](SWGProductCommentApi.md#productcommentspost) | **POST** /product_comments | Ürün Yorumu Oluşturma


# **productCommentsGet**
```objc
-(NSURLSessionTask*) productCommentsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    status: (NSString*) status
    isAnonymous: (NSString*) isAnonymous
    member: (NSNumber*) member
    product: (NSNumber*) product
    startDate: (NSDate*) startDate
    endDate: (NSString*) endDate
    startUpdatedAt: (NSDate*) startUpdatedAt
    endUpdatedAt: (NSString*) endUpdatedAt
        completionHandler: (void (^)(SWGProductComment* output, NSError* error)) handler;
```

Ürün Yorumları Listesi Alma

Ürün Yorumları listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir (optional)
NSString* status = @"status_example"; // Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif (optional)
NSString* isAnonymous = @"isAnonymous_example"; // IsAnonymous şu değerleri alabilir: <br><code>0</code> : Anonim değil<br><code>1</code> : Anonim (optional)
NSNumber* member = @56; // Üye id (optional)
NSNumber* product = @56; // Ürün id (optional)
NSDate* startDate = @"2013-10-20"; // createdAt değeri için başlangıç tarihi (optional)
NSString* endDate = @"endDate_example"; // createdAt değeri için bitiş tarihi (optional)
NSDate* startUpdatedAt = @"2013-10-20"; // updatedAt değeri için başlangıç tarihi (optional)
NSString* endUpdatedAt = @"endUpdatedAt_example"; // updatedAt değeri için bitiş tarihi (optional)

SWGProductCommentApi*apiInstance = [[SWGProductCommentApi alloc] init];

// Ürün Yorumları Listesi Alma
[apiInstance productCommentsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              status:status
              isAnonymous:isAnonymous
              member:member
              product:product
              startDate:startDate
              endDate:endDate
              startUpdatedAt:startUpdatedAt
              endUpdatedAt:endUpdatedAt
          completionHandler: ^(SWGProductComment* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductCommentApi->productCommentsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional] 
 **status** | **NSString***| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **isAnonymous** | **NSString***| IsAnonymous şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Anonim değil&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Anonim | [optional] 
 **member** | **NSNumber***| Üye id | [optional] 
 **product** | **NSNumber***| Ürün id | [optional] 
 **startDate** | **NSDate***| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **NSString***| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **NSDate***| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **NSString***| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**SWGProductComment***](SWGProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productCommentsIdDelete**
```objc
-(NSURLSessionTask*) productCommentsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Ürün Yorumu Silme

Kalıcı olarak ilgili Ürün Yorumunu siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Yorumu nesnesinin id değeri

SWGProductCommentApi*apiInstance = [[SWGProductCommentApi alloc] init];

// Ürün Yorumu Silme
[apiInstance productCommentsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGProductCommentApi->productCommentsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Yorumu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productCommentsIdGet**
```objc
-(NSURLSessionTask*) productCommentsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGProductComment* output, NSError* error)) handler;
```

Ürün Yorumu Alma

İlgili Ürün Yorumunu getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Yorumu nesnesinin id değeri

SWGProductCommentApi*apiInstance = [[SWGProductCommentApi alloc] init];

// Ürün Yorumu Alma
[apiInstance productCommentsIdGetWithId:_id
          completionHandler: ^(SWGProductComment* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductCommentApi->productCommentsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Yorumu nesnesinin id değeri | 

### Return type

[**SWGProductComment***](SWGProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productCommentsIdPut**
```objc
-(NSURLSessionTask*) productCommentsIdPutWithId: (NSNumber*) _id
    productComment: (SWGProductComment*) productComment
        completionHandler: (void (^)(SWGProductComment* output, NSError* error)) handler;
```

Ürün Yorumu Güncelleme

İlgili Ürün Yorumunu günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Yorumu nesnesinin id değeri
SWGProductComment* productComment = [[SWGProductComment alloc] init]; //  nesnesi

SWGProductCommentApi*apiInstance = [[SWGProductCommentApi alloc] init];

// Ürün Yorumu Güncelleme
[apiInstance productCommentsIdPutWithId:_id
              productComment:productComment
          completionHandler: ^(SWGProductComment* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductCommentApi->productCommentsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Yorumu nesnesinin id değeri | 
 **productComment** | [**SWGProductComment***](SWGProductComment.md)|  nesnesi | 

### Return type

[**SWGProductComment***](SWGProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productCommentsPost**
```objc
-(NSURLSessionTask*) productCommentsPostWithProductComment: (SWGProductComment*) productComment
        completionHandler: (void (^)(SWGProductComment* output, NSError* error)) handler;
```

Ürün Yorumu Oluşturma

Yeni bir Ürün Yorumu oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGProductComment* productComment = [[SWGProductComment alloc] init]; //  nesnesi

SWGProductCommentApi*apiInstance = [[SWGProductCommentApi alloc] init];

// Ürün Yorumu Oluşturma
[apiInstance productCommentsPostWithProductComment:productComment
          completionHandler: ^(SWGProductComment* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductCommentApi->productCommentsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productComment** | [**SWGProductComment***](SWGProductComment.md)|  nesnesi | 

### Return type

[**SWGProductComment***](SWGProductComment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

