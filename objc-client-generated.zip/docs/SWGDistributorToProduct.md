# SWGDistributorToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Distribütor ürün bağı nesnesi kimlik değeri. | [optional] 
**distributor** | [**SWGDistributor***](SWGDistributor.md) | The description of the Distributor. | 
**product** | [**SWGProduct***](SWGProduct.md) | The description of the Product. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


