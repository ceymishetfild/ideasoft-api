# SWGSpecToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Ürün özellik ürün bağı nesnesi kimlik değeri. | [optional] 
**product** | [**SWGProduct***](SWGProduct.md) | Ürün nesnesi. | [optional] 
**specGroup** | [**SWGSpecGroup***](SWGSpecGroup.md) | Ürün özelliği grubu nesnesi. | 
**specName** | [**SWGSpecName***](SWGSpecName.md) | Ürün özelliği nesnesi. | 
**specValue** | [**SWGSpecValue***](SWGSpecValue.md) | Ürün özellik grubu nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


