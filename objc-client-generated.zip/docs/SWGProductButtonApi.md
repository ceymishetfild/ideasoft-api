# SWGProductButtonApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productButtonsGet**](SWGProductButtonApi.md#productbuttonsget) | **GET** /product_buttons | Ürün ve Stok Butonu Listesi Alma
[**productButtonsIdDelete**](SWGProductButtonApi.md#productbuttonsiddelete) | **DELETE** /product_buttons/{id} | Ürün ve Stok Butonu Silme
[**productButtonsIdGet**](SWGProductButtonApi.md#productbuttonsidget) | **GET** /product_buttons/{id} | Ürün ve Stok Butonu Alma
[**productButtonsIdPut**](SWGProductButtonApi.md#productbuttonsidput) | **PUT** /product_buttons/{id} | Ürün ve Stok Butonu Güncelleme
[**productButtonsPost**](SWGProductButtonApi.md#productbuttonspost) | **POST** /product_buttons | Ürün ve Stok Butonu Oluşturma


# **productButtonsGet**
```objc
-(NSURLSessionTask*) productButtonsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    fastShipping: (NSString*) fastShipping
    sameDayShipping: (NSString*) sameDayShipping
    threeDaysDelivery: (NSString*) threeDaysDelivery
    fiveDaysDelivery: (NSString*) fiveDaysDelivery
    sevenDaysDelivery: (NSString*) sevenDaysDelivery
    freeShipping: (NSString*) freeShipping
    deliveryFromStock: (NSString*) deliveryFromStock
    preOrderedProduct: (NSString*) preOrderedProduct
    askStock: (NSString*) askStock
    campaignedProduct: (NSString*) campaignedProduct
    product: (NSNumber*) product
        completionHandler: (void (^)(SWGProductButton* output, NSError* error)) handler;
```

Ürün ve Stok Butonu Listesi Alma

Ürün ve Stok Butonu listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* fastShipping = @"fastShipping_example"; // Hızlı Gönderi butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
NSString* sameDayShipping = @"sameDayShipping_example"; // Aynı Gün Kargo butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
NSString* threeDaysDelivery = @"threeDaysDelivery_example"; // 3 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
NSString* fiveDaysDelivery = @"fiveDaysDelivery_example"; // 5 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
NSString* sevenDaysDelivery = @"sevenDaysDelivery_example"; // 7 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
NSString* freeShipping = @"freeShipping_example"; // Kargo Bedava butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
NSString* deliveryFromStock = @"deliveryFromStock_example"; // Stoktan Teslim butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
NSString* preOrderedProduct = @"preOrderedProduct_example"; // Ön Siparişli Ürün butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
NSString* askStock = @"askStock_example"; // Stok Sorunuz butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
NSString* campaignedProduct = @"campaignedProduct_example"; // Kampanyalı Ürün butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
NSNumber* product = @56; // Ürün id (optional)

SWGProductButtonApi*apiInstance = [[SWGProductButtonApi alloc] init];

// Ürün ve Stok Butonu Listesi Alma
[apiInstance productButtonsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              fastShipping:fastShipping
              sameDayShipping:sameDayShipping
              threeDaysDelivery:threeDaysDelivery
              fiveDaysDelivery:fiveDaysDelivery
              sevenDaysDelivery:sevenDaysDelivery
              freeShipping:freeShipping
              deliveryFromStock:deliveryFromStock
              preOrderedProduct:preOrderedProduct
              askStock:askStock
              campaignedProduct:campaignedProduct
              product:product
          completionHandler: ^(SWGProductButton* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductButtonApi->productButtonsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **fastShipping** | **NSString***| Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **sameDayShipping** | **NSString***| Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **threeDaysDelivery** | **NSString***| 3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **fiveDaysDelivery** | **NSString***| 5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **sevenDaysDelivery** | **NSString***| 7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **freeShipping** | **NSString***| Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **deliveryFromStock** | **NSString***| Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **preOrderedProduct** | **NSString***| Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **askStock** | **NSString***| Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **campaignedProduct** | **NSString***| Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **product** | **NSNumber***| Ürün id | [optional] 

### Return type

[**SWGProductButton***](SWGProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productButtonsIdDelete**
```objc
-(NSURLSessionTask*) productButtonsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Ürün ve Stok Butonu Silme

Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün ve Stok Butonu nesnesinin id değeri

SWGProductButtonApi*apiInstance = [[SWGProductButtonApi alloc] init];

// Ürün ve Stok Butonu Silme
[apiInstance productButtonsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGProductButtonApi->productButtonsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productButtonsIdGet**
```objc
-(NSURLSessionTask*) productButtonsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGProductButton* output, NSError* error)) handler;
```

Ürün ve Stok Butonu Alma

İlgili Ürün ve Stok Butonunu getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün ve Stok Butonu nesnesinin id değeri

SWGProductButtonApi*apiInstance = [[SWGProductButtonApi alloc] init];

// Ürün ve Stok Butonu Alma
[apiInstance productButtonsIdGetWithId:_id
          completionHandler: ^(SWGProductButton* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductButtonApi->productButtonsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

[**SWGProductButton***](SWGProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productButtonsIdPut**
```objc
-(NSURLSessionTask*) productButtonsIdPutWithId: (NSNumber*) _id
    productButton: (SWGProductButton*) productButton
        completionHandler: (void (^)(SWGProductButton* output, NSError* error)) handler;
```

Ürün ve Stok Butonu Güncelleme

İlgili Ürün ve Stok Butonunu günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün ve Stok Butonu nesnesinin id değeri
SWGProductButton* productButton = [[SWGProductButton alloc] init]; //  nesnesi

SWGProductButtonApi*apiInstance = [[SWGProductButtonApi alloc] init];

// Ürün ve Stok Butonu Güncelleme
[apiInstance productButtonsIdPutWithId:_id
              productButton:productButton
          completionHandler: ^(SWGProductButton* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductButtonApi->productButtonsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün ve Stok Butonu nesnesinin id değeri | 
 **productButton** | [**SWGProductButton***](SWGProductButton.md)|  nesnesi | 

### Return type

[**SWGProductButton***](SWGProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productButtonsPost**
```objc
-(NSURLSessionTask*) productButtonsPostWithProductButton: (SWGProductButton*) productButton
        completionHandler: (void (^)(SWGProductButton* output, NSError* error)) handler;
```

Ürün ve Stok Butonu Oluşturma

Yeni bir Ürün ve Stok Butonu oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGProductButton* productButton = [[SWGProductButton alloc] init]; //  nesnesi

SWGProductButtonApi*apiInstance = [[SWGProductButtonApi alloc] init];

// Ürün ve Stok Butonu Oluşturma
[apiInstance productButtonsPostWithProductButton:productButton
          completionHandler: ^(SWGProductButton* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductButtonApi->productButtonsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productButton** | [**SWGProductButton***](SWGProductButton.md)|  nesnesi | 

### Return type

[**SWGProductButton***](SWGProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

