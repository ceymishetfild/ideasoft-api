# SWGPaymentProviderSetting

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Ödeme altyapısı sağlayıcısı ayarı nesnesi kimlik değeri. | [optional] 
**varKey** | **NSString*** | Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken anahtarı. | 
**varValue** | **NSString*** | Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken değeri. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


