# SWGExtraInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Ek bilgi nesnesi kimlik değeri. | [optional] 
**name** | **NSString*** | Ek bilgi nesnesi için isim değeri. | 
**sortOrder** | **NSNumber*** | Ek bilgi nesnesi için sıralama değeri. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


