# SWGProductDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Ürün detayı nesnesi kimlik değeri. | [optional] 
**sku** | **NSString*** | Ürünün stok kodu. | [optional] 
**details** | **NSString*** | Detay bilgisi. | [optional] 
**extraDetails** | **NSString*** | Ürün ekstra detaylı bilgi. | [optional] 
**product** | [**SWGProduct***](SWGProduct.md) | Ürün nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


