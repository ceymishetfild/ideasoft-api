# SWGProductSpecialInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productSpecialInfosGet**](SWGProductSpecialInfoApi.md#productspecialinfosget) | **GET** /product_special_infos | Ürün Özel Bilgi Alanı Listesi Alma
[**productSpecialInfosIdDelete**](SWGProductSpecialInfoApi.md#productspecialinfosiddelete) | **DELETE** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**productSpecialInfosIdGet**](SWGProductSpecialInfoApi.md#productspecialinfosidget) | **GET** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**productSpecialInfosIdPut**](SWGProductSpecialInfoApi.md#productspecialinfosidput) | **PUT** /product_special_infos/{id} | Ürün Özel Bilgi Alanı Güncelleme
[**productSpecialInfosPost**](SWGProductSpecialInfoApi.md#productspecialinfospost) | **POST** /product_special_infos | Ürün Özel Bilgi Alanı Oluşturma


# **productSpecialInfosGet**
```objc
-(NSURLSessionTask*) productSpecialInfosGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    title: (NSString*) title
    status: (NSString*) status
    product: (NSNumber*) product
        completionHandler: (void (^)(SWGProductSpecialInfo* output, NSError* error)) handler;
```

Ürün Özel Bilgi Alanı Listesi Alma

Ürün Özel Bilgi Alanı listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* title = @"title_example"; // Ürün Özel Bilgi Alanı başlığı (optional)
NSString* status = @"status_example"; // Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif (optional)
NSNumber* product = @56; // Ürün id (optional)

SWGProductSpecialInfoApi*apiInstance = [[SWGProductSpecialInfoApi alloc] init];

// Ürün Özel Bilgi Alanı Listesi Alma
[apiInstance productSpecialInfosGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              title:title
              status:status
              product:product
          completionHandler: ^(SWGProductSpecialInfo* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductSpecialInfoApi->productSpecialInfosGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **title** | **NSString***| Ürün Özel Bilgi Alanı başlığı | [optional] 
 **status** | **NSString***| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **product** | **NSNumber***| Ürün id | [optional] 

### Return type

[**SWGProductSpecialInfo***](SWGProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productSpecialInfosIdDelete**
```objc
-(NSURLSessionTask*) productSpecialInfosIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Ürün Özel Bilgi Alanı

Kalıcı olarak ilgili Ürün Özel Bilgi Alanını siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Özel Bilgi Alanı nesnesinin id değeri

SWGProductSpecialInfoApi*apiInstance = [[SWGProductSpecialInfoApi alloc] init];

// Ürün Özel Bilgi Alanı
[apiInstance productSpecialInfosIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGProductSpecialInfoApi->productSpecialInfosIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Özel Bilgi Alanı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productSpecialInfosIdGet**
```objc
-(NSURLSessionTask*) productSpecialInfosIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGProductSpecialInfo* output, NSError* error)) handler;
```

Ürün Özel Bilgi Alanı

İlgili Ürün Özel Bilgi Alanını getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Özel Bilgi Alanı nesnesinin id değeri

SWGProductSpecialInfoApi*apiInstance = [[SWGProductSpecialInfoApi alloc] init];

// Ürün Özel Bilgi Alanı
[apiInstance productSpecialInfosIdGetWithId:_id
          completionHandler: ^(SWGProductSpecialInfo* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductSpecialInfoApi->productSpecialInfosIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Özel Bilgi Alanı nesnesinin id değeri | 

### Return type

[**SWGProductSpecialInfo***](SWGProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productSpecialInfosIdPut**
```objc
-(NSURLSessionTask*) productSpecialInfosIdPutWithId: (NSNumber*) _id
    productSpecialInfo: (SWGProductSpecialInfo*) productSpecialInfo
        completionHandler: (void (^)(SWGProductSpecialInfo* output, NSError* error)) handler;
```

Ürün Özel Bilgi Alanı Güncelleme

İlgili Ürün Özel Bilgi Alanını günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Özel Bilgi Alanı nesnesinin id değeri
SWGProductSpecialInfo* productSpecialInfo = [[SWGProductSpecialInfo alloc] init]; //  nesnesi

SWGProductSpecialInfoApi*apiInstance = [[SWGProductSpecialInfoApi alloc] init];

// Ürün Özel Bilgi Alanı Güncelleme
[apiInstance productSpecialInfosIdPutWithId:_id
              productSpecialInfo:productSpecialInfo
          completionHandler: ^(SWGProductSpecialInfo* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductSpecialInfoApi->productSpecialInfosIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Özel Bilgi Alanı nesnesinin id değeri | 
 **productSpecialInfo** | [**SWGProductSpecialInfo***](SWGProductSpecialInfo.md)|  nesnesi | 

### Return type

[**SWGProductSpecialInfo***](SWGProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productSpecialInfosPost**
```objc
-(NSURLSessionTask*) productSpecialInfosPostWithProductSpecialInfo: (SWGProductSpecialInfo*) productSpecialInfo
        completionHandler: (void (^)(SWGProductSpecialInfo* output, NSError* error)) handler;
```

Ürün Özel Bilgi Alanı Oluşturma

Yeni bir Ürün Özel Bilgi Alanı oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGProductSpecialInfo* productSpecialInfo = [[SWGProductSpecialInfo alloc] init]; //  nesnesi

SWGProductSpecialInfoApi*apiInstance = [[SWGProductSpecialInfoApi alloc] init];

// Ürün Özel Bilgi Alanı Oluşturma
[apiInstance productSpecialInfosPostWithProductSpecialInfo:productSpecialInfo
          completionHandler: ^(SWGProductSpecialInfo* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductSpecialInfoApi->productSpecialInfosPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productSpecialInfo** | [**SWGProductSpecialInfo***](SWGProductSpecialInfo.md)|  nesnesi | 

### Return type

[**SWGProductSpecialInfo***](SWGProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

