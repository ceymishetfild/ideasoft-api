# SWGOrderAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Sipariş adresi nesnesi kimlik değeri. | [optional] 
**firstname** | **NSString*** | Müşterinin ismi. | 
**surname** | **NSString*** | Müşterinin soy ismi. | 
**country** | **NSString*** | Müşterinin ülke bilgisi. | 
**location** | **NSString*** | Müşterinin şehir bilgisi. | 
**subLocation** | **NSString*** | Müşterinin ilçe bilgisi. | [optional] 
**address** | **NSString*** | Müşterinin adres bilgisi. | 
**phoneNumber** | **NSString*** | Müşterinin telefon numarası. | 
**mobilePhoneNumber** | **NSString*** | Müşterinin mobil telefon numarası. | [optional] 
**order** | [**SWGOrder***](SWGOrder.md) | Sipariş nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


