# SWGCacheApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cacheDelete**](SWGCacheApi.md#cachedelete) | **DELETE** /cache | Önbellek Silme


# **cacheDelete**
```objc
-(NSURLSessionTask*) cacheDeleteWithCompletionHandler: 
        (void (^)(NSError* error)) handler;
```

Önbellek Silme

Kalıcı olarak Önbelleği siler.

### Example 
```objc


SWGCacheApi*apiInstance = [[SWGCacheApi alloc] init];

// Önbellek Silme
[apiInstance cacheDeleteWithCompletionHandler: 
          ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGCacheApi->cacheDelete: %@", error);
                        }
                    }];
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

