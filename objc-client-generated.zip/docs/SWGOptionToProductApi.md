# SWGOptionToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**optionToProductsGet**](SWGOptionToProductApi.md#optiontoproductsget) | **GET** /option_to_products | Varyant Ürün Bağı Listesi Alma
[**optionToProductsIdDelete**](SWGOptionToProductApi.md#optiontoproductsiddelete) | **DELETE** /option_to_products/{id} | Varyant Ürün Bağı Silme
[**optionToProductsIdGet**](SWGOptionToProductApi.md#optiontoproductsidget) | **GET** /option_to_products/{id} | Varyant Ürün Bağı Alma
[**optionToProductsIdPut**](SWGOptionToProductApi.md#optiontoproductsidput) | **PUT** /option_to_products/{id} | Varyant Ürün Bağı Güncelleme
[**optionToProductsPost**](SWGOptionToProductApi.md#optiontoproductspost) | **POST** /option_to_products | Varyant Ürün Bağı Oluşturma


# **optionToProductsGet**
```objc
-(NSURLSessionTask*) optionToProductsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    product: (NSNumber*) product
    optionGroup: (NSNumber*) optionGroup
    option: (NSNumber*) option
    parentProductId: (NSNumber*) parentProductId
        completionHandler: (void (^)(SWGOptionToProduct* output, NSError* error)) handler;
```

Varyant Ürün Bağı Listesi Alma

Varyant Ürün Bağı listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSNumber* product = @56; // Ürün id (optional)
NSNumber* optionGroup = @56; // Varyant Grubu id (optional)
NSNumber* option = @56; // Varyant id (optional)
NSNumber* parentProductId = @56; // Ana Ürün id (optional)

SWGOptionToProductApi*apiInstance = [[SWGOptionToProductApi alloc] init];

// Varyant Ürün Bağı Listesi Alma
[apiInstance optionToProductsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              product:product
              optionGroup:optionGroup
              option:option
              parentProductId:parentProductId
          completionHandler: ^(SWGOptionToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOptionToProductApi->optionToProductsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **product** | **NSNumber***| Ürün id | [optional] 
 **optionGroup** | **NSNumber***| Varyant Grubu id | [optional] 
 **option** | **NSNumber***| Varyant id | [optional] 
 **parentProductId** | **NSNumber***| Ana Ürün id | [optional] 

### Return type

[**SWGOptionToProduct***](SWGOptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **optionToProductsIdDelete**
```objc
-(NSURLSessionTask*) optionToProductsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Varyant Ürün Bağı Silme

Kalıcı olarak ilgili Varyant Ürün Bağını siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Varyant Ürün Bağı nesnesinin id değeri

SWGOptionToProductApi*apiInstance = [[SWGOptionToProductApi alloc] init];

// Varyant Ürün Bağı Silme
[apiInstance optionToProductsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGOptionToProductApi->optionToProductsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Varyant Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **optionToProductsIdGet**
```objc
-(NSURLSessionTask*) optionToProductsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGOptionToProduct* output, NSError* error)) handler;
```

Varyant Ürün Bağı Alma

İlgili Varyant Ürün Bağını getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Varyant Ürün Bağı nesnesinin id değeri

SWGOptionToProductApi*apiInstance = [[SWGOptionToProductApi alloc] init];

// Varyant Ürün Bağı Alma
[apiInstance optionToProductsIdGetWithId:_id
          completionHandler: ^(SWGOptionToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOptionToProductApi->optionToProductsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Varyant Ürün Bağı nesnesinin id değeri | 

### Return type

[**SWGOptionToProduct***](SWGOptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **optionToProductsIdPut**
```objc
-(NSURLSessionTask*) optionToProductsIdPutWithId: (NSNumber*) _id
    optionToProduct: (SWGOptionToProduct*) optionToProduct
        completionHandler: (void (^)(SWGOptionToProduct* output, NSError* error)) handler;
```

Varyant Ürün Bağı Güncelleme

İlgili Varyant Ürün Bağını günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Varyant Ürün Bağı nesnesinin id değeri
SWGOptionToProduct* optionToProduct = [[SWGOptionToProduct alloc] init]; //  nesnesi

SWGOptionToProductApi*apiInstance = [[SWGOptionToProductApi alloc] init];

// Varyant Ürün Bağı Güncelleme
[apiInstance optionToProductsIdPutWithId:_id
              optionToProduct:optionToProduct
          completionHandler: ^(SWGOptionToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOptionToProductApi->optionToProductsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Varyant Ürün Bağı nesnesinin id değeri | 
 **optionToProduct** | [**SWGOptionToProduct***](SWGOptionToProduct.md)|  nesnesi | 

### Return type

[**SWGOptionToProduct***](SWGOptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **optionToProductsPost**
```objc
-(NSURLSessionTask*) optionToProductsPostWithOptionToProduct: (SWGOptionToProduct*) optionToProduct
        completionHandler: (void (^)(SWGOptionToProduct* output, NSError* error)) handler;
```

Varyant Ürün Bağı Oluşturma

Yeni bir Varyant Ürün Bağı oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGOptionToProduct* optionToProduct = [[SWGOptionToProduct alloc] init]; //  nesnesi

SWGOptionToProductApi*apiInstance = [[SWGOptionToProductApi alloc] init];

// Varyant Ürün Bağı Oluşturma
[apiInstance optionToProductsPostWithOptionToProduct:optionToProduct
          completionHandler: ^(SWGOptionToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOptionToProductApi->optionToProductsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **optionToProduct** | [**SWGOptionToProduct***](SWGOptionToProduct.md)|  nesnesi | 

### Return type

[**SWGOptionToProduct***](SWGOptionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

