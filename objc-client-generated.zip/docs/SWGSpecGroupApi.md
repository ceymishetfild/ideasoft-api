# SWGSpecGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specGroupsGet**](SWGSpecGroupApi.md#specgroupsget) | **GET** /spec_groups | Ürün Özellik Grubu Listesi Alma
[**specGroupsIdDelete**](SWGSpecGroupApi.md#specgroupsiddelete) | **DELETE** /spec_groups/{id} | Ürün Özellik Grubu Silme
[**specGroupsIdGet**](SWGSpecGroupApi.md#specgroupsidget) | **GET** /spec_groups/{id} | Ürün Özellik Grubu Alma
[**specGroupsIdPut**](SWGSpecGroupApi.md#specgroupsidput) | **PUT** /spec_groups/{id} | Ürün Özellik Grubu Güncelleme
[**specGroupsPost**](SWGSpecGroupApi.md#specgroupspost) | **POST** /spec_groups | Ürün Özellik Grubu Oluşturma


# **specGroupsGet**
```objc
-(NSURLSessionTask*) specGroupsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    name: (NSString*) name
        completionHandler: (void (^)(SWGSpecGroup* output, NSError* error)) handler;
```

Ürün Özellik Grubu Listesi Alma

Ürün Özellik Grubu listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* name = @"name_example"; // Ürün Özellik Grubu adı (optional)

SWGSpecGroupApi*apiInstance = [[SWGSpecGroupApi alloc] init];

// Ürün Özellik Grubu Listesi Alma
[apiInstance specGroupsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              name:name
          completionHandler: ^(SWGSpecGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecGroupApi->specGroupsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **NSString***| Ürün Özellik Grubu adı | [optional] 

### Return type

[**SWGSpecGroup***](SWGSpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specGroupsIdDelete**
```objc
-(NSURLSessionTask*) specGroupsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Ürün Özellik Grubu Silme

Kalıcı olarak ilgili Ürün Özellik Grubunu siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Özellik Grubu nesnesinin id değeri

SWGSpecGroupApi*apiInstance = [[SWGSpecGroupApi alloc] init];

// Ürün Özellik Grubu Silme
[apiInstance specGroupsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGSpecGroupApi->specGroupsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Özellik Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specGroupsIdGet**
```objc
-(NSURLSessionTask*) specGroupsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGSpecGroup* output, NSError* error)) handler;
```

Ürün Özellik Grubu Alma

İlgili Ürün Özellik Grubunu getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Özellik Grubu nesnesinin id değeri

SWGSpecGroupApi*apiInstance = [[SWGSpecGroupApi alloc] init];

// Ürün Özellik Grubu Alma
[apiInstance specGroupsIdGetWithId:_id
          completionHandler: ^(SWGSpecGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecGroupApi->specGroupsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Özellik Grubu nesnesinin id değeri | 

### Return type

[**SWGSpecGroup***](SWGSpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specGroupsIdPut**
```objc
-(NSURLSessionTask*) specGroupsIdPutWithId: (NSNumber*) _id
    specGroup: (SWGSpecGroup*) specGroup
        completionHandler: (void (^)(SWGSpecGroup* output, NSError* error)) handler;
```

Ürün Özellik Grubu Güncelleme

İlgili Ürün Özellik Grubunu günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Özellik Grubu nesnesinin id değeri
SWGSpecGroup* specGroup = [[SWGSpecGroup alloc] init]; //  nesnesi

SWGSpecGroupApi*apiInstance = [[SWGSpecGroupApi alloc] init];

// Ürün Özellik Grubu Güncelleme
[apiInstance specGroupsIdPutWithId:_id
              specGroup:specGroup
          completionHandler: ^(SWGSpecGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecGroupApi->specGroupsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Özellik Grubu nesnesinin id değeri | 
 **specGroup** | [**SWGSpecGroup***](SWGSpecGroup.md)|  nesnesi | 

### Return type

[**SWGSpecGroup***](SWGSpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specGroupsPost**
```objc
-(NSURLSessionTask*) specGroupsPostWithSpecGroup: (SWGSpecGroup*) specGroup
        completionHandler: (void (^)(SWGSpecGroup* output, NSError* error)) handler;
```

Ürün Özellik Grubu Oluşturma

Yeni bir Ürün Özellik Grubu oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGSpecGroup* specGroup = [[SWGSpecGroup alloc] init]; //  nesnesi

SWGSpecGroupApi*apiInstance = [[SWGSpecGroupApi alloc] init];

// Ürün Özellik Grubu Oluşturma
[apiInstance specGroupsPostWithSpecGroup:specGroup
          completionHandler: ^(SWGSpecGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecGroupApi->specGroupsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specGroup** | [**SWGSpecGroup***](SWGSpecGroup.md)|  nesnesi | 

### Return type

[**SWGSpecGroup***](SWGSpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

