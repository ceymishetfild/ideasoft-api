# SWGSelectionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selectionGroupsGet**](SWGSelectionGroupApi.md#selectiongroupsget) | **GET** /selection_groups | Ek Özellik Grubu Listesi Alma
[**selectionGroupsIdDelete**](SWGSelectionGroupApi.md#selectiongroupsiddelete) | **DELETE** /selection_groups/{id} | Ek Özellik Grubu Silme
[**selectionGroupsIdGet**](SWGSelectionGroupApi.md#selectiongroupsidget) | **GET** /selection_groups/{id} | Ek Özellik Grubu Alma
[**selectionGroupsIdPut**](SWGSelectionGroupApi.md#selectiongroupsidput) | **PUT** /selection_groups/{id} | Ek Özellik Grubu Güncelleme
[**selectionGroupsPost**](SWGSelectionGroupApi.md#selectiongroupspost) | **POST** /selection_groups | Ek Özellik Grubu Oluşturma


# **selectionGroupsGet**
```objc
-(NSURLSessionTask*) selectionGroupsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    title: (NSString*) title
        completionHandler: (void (^)(SWGSelectionGroup* output, NSError* error)) handler;
```

Ek Özellik Grubu Listesi Alma

Ek Özellik Grubu listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* title = @"title_example"; // Ek Özellik Grubu başlığı (optional)

SWGSelectionGroupApi*apiInstance = [[SWGSelectionGroupApi alloc] init];

// Ek Özellik Grubu Listesi Alma
[apiInstance selectionGroupsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              title:title
          completionHandler: ^(SWGSelectionGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSelectionGroupApi->selectionGroupsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **title** | **NSString***| Ek Özellik Grubu başlığı | [optional] 

### Return type

[**SWGSelectionGroup***](SWGSelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selectionGroupsIdDelete**
```objc
-(NSURLSessionTask*) selectionGroupsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Ek Özellik Grubu Silme

Kalıcı olarak ilgili Ek Özellik Grubunu siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ek Özellik Grubu nesnesinin id değeri

SWGSelectionGroupApi*apiInstance = [[SWGSelectionGroupApi alloc] init];

// Ek Özellik Grubu Silme
[apiInstance selectionGroupsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGSelectionGroupApi->selectionGroupsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ek Özellik Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selectionGroupsIdGet**
```objc
-(NSURLSessionTask*) selectionGroupsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGSelectionGroup* output, NSError* error)) handler;
```

Ek Özellik Grubu Alma

İlgili Ek Özellik Grubunu getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ek Özellik Grubu nesnesinin id değeri

SWGSelectionGroupApi*apiInstance = [[SWGSelectionGroupApi alloc] init];

// Ek Özellik Grubu Alma
[apiInstance selectionGroupsIdGetWithId:_id
          completionHandler: ^(SWGSelectionGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSelectionGroupApi->selectionGroupsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ek Özellik Grubu nesnesinin id değeri | 

### Return type

[**SWGSelectionGroup***](SWGSelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selectionGroupsIdPut**
```objc
-(NSURLSessionTask*) selectionGroupsIdPutWithId: (NSNumber*) _id
    selectionGroup: (SWGSelectionGroup*) selectionGroup
        completionHandler: (void (^)(SWGSelectionGroup* output, NSError* error)) handler;
```

Ek Özellik Grubu Güncelleme

İlgili Ek Özellik Grubunu günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ek Özellik Grubu nesnesinin id değeri
SWGSelectionGroup* selectionGroup = [[SWGSelectionGroup alloc] init]; //  nesnesi

SWGSelectionGroupApi*apiInstance = [[SWGSelectionGroupApi alloc] init];

// Ek Özellik Grubu Güncelleme
[apiInstance selectionGroupsIdPutWithId:_id
              selectionGroup:selectionGroup
          completionHandler: ^(SWGSelectionGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSelectionGroupApi->selectionGroupsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ek Özellik Grubu nesnesinin id değeri | 
 **selectionGroup** | [**SWGSelectionGroup***](SWGSelectionGroup.md)|  nesnesi | 

### Return type

[**SWGSelectionGroup***](SWGSelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selectionGroupsPost**
```objc
-(NSURLSessionTask*) selectionGroupsPostWithSelectionGroup: (SWGSelectionGroup*) selectionGroup
        completionHandler: (void (^)(SWGSelectionGroup* output, NSError* error)) handler;
```

Ek Özellik Grubu Oluşturma

Yeni bir Ek Özellik Grubu oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGSelectionGroup* selectionGroup = [[SWGSelectionGroup alloc] init]; //  nesnesi

SWGSelectionGroupApi*apiInstance = [[SWGSelectionGroupApi alloc] init];

// Ek Özellik Grubu Oluşturma
[apiInstance selectionGroupsPostWithSelectionGroup:selectionGroup
          completionHandler: ^(SWGSelectionGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSelectionGroupApi->selectionGroupsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selectionGroup** | [**SWGSelectionGroup***](SWGSelectionGroup.md)|  nesnesi | 

### Return type

[**SWGSelectionGroup***](SWGSelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

