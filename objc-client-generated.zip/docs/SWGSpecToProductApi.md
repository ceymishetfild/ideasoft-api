# SWGSpecToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specToProductsGet**](SWGSpecToProductApi.md#spectoproductsget) | **GET** /spec_to_products | Ürün Özellik Ürün Bağı Listesi Alma
[**specToProductsIdDelete**](SWGSpecToProductApi.md#spectoproductsiddelete) | **DELETE** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Silme
[**specToProductsIdGet**](SWGSpecToProductApi.md#spectoproductsidget) | **GET** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Alma
[**specToProductsIdPut**](SWGSpecToProductApi.md#spectoproductsidput) | **PUT** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Güncelleme
[**specToProductsPost**](SWGSpecToProductApi.md#spectoproductspost) | **POST** /spec_to_products | Ürün Özellik Ürün Bağı Oluşturma


# **specToProductsGet**
```objc
-(NSURLSessionTask*) specToProductsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    product: (NSNumber*) product
    specGroup: (NSNumber*) specGroup
    specName: (NSNumber*) specName
    specValue: (NSNumber*) specValue
        completionHandler: (void (^)(SWGSpecToProduct* output, NSError* error)) handler;
```

Ürün Özellik Ürün Bağı Listesi Alma

Ürün Özellik Ürün Bağı listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSNumber* product = @56; // Ürün id (optional)
NSNumber* specGroup = @56; // Ürün özellik grubu id (optional)
NSNumber* specName = @56; // Ürün özellik id (optional)
NSNumber* specValue = @56; // Ürün özellik değeri id (optional)

SWGSpecToProductApi*apiInstance = [[SWGSpecToProductApi alloc] init];

// Ürün Özellik Ürün Bağı Listesi Alma
[apiInstance specToProductsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              product:product
              specGroup:specGroup
              specName:specName
              specValue:specValue
          completionHandler: ^(SWGSpecToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecToProductApi->specToProductsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **product** | **NSNumber***| Ürün id | [optional] 
 **specGroup** | **NSNumber***| Ürün özellik grubu id | [optional] 
 **specName** | **NSNumber***| Ürün özellik id | [optional] 
 **specValue** | **NSNumber***| Ürün özellik değeri id | [optional] 

### Return type

[**SWGSpecToProduct***](SWGSpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specToProductsIdDelete**
```objc
-(NSURLSessionTask*) specToProductsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Ürün Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Özellik Ürün Bağı nesnesinin id değeri

SWGSpecToProductApi*apiInstance = [[SWGSpecToProductApi alloc] init];

// Ürün Özellik Ürün Bağı Silme
[apiInstance specToProductsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGSpecToProductApi->specToProductsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specToProductsIdGet**
```objc
-(NSURLSessionTask*) specToProductsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGSpecToProduct* output, NSError* error)) handler;
```

Ürün Özellik Ürün Bağı Alma

İlgili Ürün Özellik Ürün Bağını getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Özellik Ürün Bağı nesnesinin id değeri

SWGSpecToProductApi*apiInstance = [[SWGSpecToProductApi alloc] init];

// Ürün Özellik Ürün Bağı Alma
[apiInstance specToProductsIdGetWithId:_id
          completionHandler: ^(SWGSpecToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecToProductApi->specToProductsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

[**SWGSpecToProduct***](SWGSpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specToProductsIdPut**
```objc
-(NSURLSessionTask*) specToProductsIdPutWithId: (NSNumber*) _id
    specToProduct: (SWGSpecToProduct*) specToProduct
        completionHandler: (void (^)(SWGSpecToProduct* output, NSError* error)) handler;
```

Ürün Özellik Ürün Bağı Güncelleme

İlgili Ürün Özellik Ürün Bağını günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Özellik Ürün Bağı nesnesinin id değeri
SWGSpecToProduct* specToProduct = [[SWGSpecToProduct alloc] init]; //  nesnesi

SWGSpecToProductApi*apiInstance = [[SWGSpecToProductApi alloc] init];

// Ürün Özellik Ürün Bağı Güncelleme
[apiInstance specToProductsIdPutWithId:_id
              specToProduct:specToProduct
          completionHandler: ^(SWGSpecToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecToProductApi->specToProductsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Özellik Ürün Bağı nesnesinin id değeri | 
 **specToProduct** | [**SWGSpecToProduct***](SWGSpecToProduct.md)|  nesnesi | 

### Return type

[**SWGSpecToProduct***](SWGSpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specToProductsPost**
```objc
-(NSURLSessionTask*) specToProductsPostWithSpecToProduct: (SWGSpecToProduct*) specToProduct
        completionHandler: (void (^)(SWGSpecToProduct* output, NSError* error)) handler;
```

Ürün Özellik Ürün Bağı Oluşturma

Yeni bir Ürün Özellik Ürün Bağı oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGSpecToProduct* specToProduct = [[SWGSpecToProduct alloc] init]; //  nesnesi

SWGSpecToProductApi*apiInstance = [[SWGSpecToProductApi alloc] init];

// Ürün Özellik Ürün Bağı Oluşturma
[apiInstance specToProductsPostWithSpecToProduct:specToProduct
          completionHandler: ^(SWGSpecToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecToProductApi->specToProductsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specToProduct** | [**SWGSpecToProduct***](SWGSpecToProduct.md)|  nesnesi | 

### Return type

[**SWGSpecToProduct***](SWGSpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

