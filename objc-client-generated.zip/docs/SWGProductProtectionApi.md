# SWGProductProtectionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productProtectionsGet**](SWGProductProtectionApi.md#productprotectionsget) | **GET** /product_protections | Entegrasyon Seçeneği Listesi Alma
[**productProtectionsIdDelete**](SWGProductProtectionApi.md#productprotectionsiddelete) | **DELETE** /product_protections/{id} | Entegrasyon Seçeneği Silme
[**productProtectionsIdGet**](SWGProductProtectionApi.md#productprotectionsidget) | **GET** /product_protections/{id} | Entegrasyon Seçeneği Alma
[**productProtectionsIdPut**](SWGProductProtectionApi.md#productprotectionsidput) | **PUT** /product_protections/{id} | Entegrasyon Seçeneği Güncelleme
[**productProtectionsPost**](SWGProductProtectionApi.md#productprotectionspost) | **POST** /product_protections | Entegrasyon Seçeneği Oluşturma


# **productProtectionsGet**
```objc
-(NSURLSessionTask*) productProtectionsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    isPriceProtected: (NSString*) isPriceProtected
    isStockProtected: (NSString*) isStockProtected
    product: (NSNumber*) product
        completionHandler: (void (^)(SWGProductProtection* output, NSError* error)) handler;
```

Entegrasyon Seçeneği Listesi Alma

Entegrasyon Seçeneği listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* isPriceProtected = @"isPriceProtected_example"; // Fiyat korumalı ürünleri listeler<code>0</code><br><code>1</code> (optional)
NSString* isStockProtected = @"isStockProtected_example"; // Stok korumalı ürünleri listeler<code>0</code><br><code>1</code> (optional)
NSNumber* product = @56; // Ürün id (optional)

SWGProductProtectionApi*apiInstance = [[SWGProductProtectionApi alloc] init];

// Entegrasyon Seçeneği Listesi Alma
[apiInstance productProtectionsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              isPriceProtected:isPriceProtected
              isStockProtected:isStockProtected
              product:product
          completionHandler: ^(SWGProductProtection* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductProtectionApi->productProtectionsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **isPriceProtected** | **NSString***| Fiyat korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **isStockProtected** | **NSString***| Stok korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **product** | **NSNumber***| Ürün id | [optional] 

### Return type

[**SWGProductProtection***](SWGProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productProtectionsIdDelete**
```objc
-(NSURLSessionTask*) productProtectionsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Entegrasyon Seçeneği Silme

Kalıcı olarak ilgili Entegrasyon Seçeneğini siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Entegrasyon Seçeneği nesnesinin id değeri

SWGProductProtectionApi*apiInstance = [[SWGProductProtectionApi alloc] init];

// Entegrasyon Seçeneği Silme
[apiInstance productProtectionsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGProductProtectionApi->productProtectionsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Entegrasyon Seçeneği nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productProtectionsIdGet**
```objc
-(NSURLSessionTask*) productProtectionsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGProductProtection* output, NSError* error)) handler;
```

Entegrasyon Seçeneği Alma

İlgili Entegrasyon Seçeneğini getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Entegrasyon Seçeneği nesnesinin id değeri

SWGProductProtectionApi*apiInstance = [[SWGProductProtectionApi alloc] init];

// Entegrasyon Seçeneği Alma
[apiInstance productProtectionsIdGetWithId:_id
          completionHandler: ^(SWGProductProtection* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductProtectionApi->productProtectionsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Entegrasyon Seçeneği nesnesinin id değeri | 

### Return type

[**SWGProductProtection***](SWGProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productProtectionsIdPut**
```objc
-(NSURLSessionTask*) productProtectionsIdPutWithId: (NSNumber*) _id
    productProtection: (SWGProductProtection*) productProtection
        completionHandler: (void (^)(SWGProductProtection* output, NSError* error)) handler;
```

Entegrasyon Seçeneği Güncelleme

İlgili Entegrasyon Seçeneğini günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Entegrasyon Seçeneği nesnesinin id değeri
SWGProductProtection* productProtection = [[SWGProductProtection alloc] init]; //  nesnesi

SWGProductProtectionApi*apiInstance = [[SWGProductProtectionApi alloc] init];

// Entegrasyon Seçeneği Güncelleme
[apiInstance productProtectionsIdPutWithId:_id
              productProtection:productProtection
          completionHandler: ^(SWGProductProtection* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductProtectionApi->productProtectionsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Entegrasyon Seçeneği nesnesinin id değeri | 
 **productProtection** | [**SWGProductProtection***](SWGProductProtection.md)|  nesnesi | 

### Return type

[**SWGProductProtection***](SWGProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productProtectionsPost**
```objc
-(NSURLSessionTask*) productProtectionsPostWithProductProtection: (SWGProductProtection*) productProtection
        completionHandler: (void (^)(SWGProductProtection* output, NSError* error)) handler;
```

Entegrasyon Seçeneği Oluşturma

Yeni bir Entegrasyon Seçeneği oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGProductProtection* productProtection = [[SWGProductProtection alloc] init]; //  nesnesi

SWGProductProtectionApi*apiInstance = [[SWGProductProtectionApi alloc] init];

// Entegrasyon Seçeneği Oluşturma
[apiInstance productProtectionsPostWithProductProtection:productProtection
          completionHandler: ^(SWGProductProtection* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductProtectionApi->productProtectionsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productProtection** | [**SWGProductProtection***](SWGProductProtection.md)|  nesnesi | 

### Return type

[**SWGProductProtection***](SWGProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

