# SWGMaillist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Mail listesi nesnesi kimlik değeri. | [optional] 
**name** | **NSString*** | Mail listesi nesnesi için isim değeri. | 
**email** | **NSString*** | Ziyaretçi veya üyenin mail adresi. | 
**lastMailSentDate** | **NSDate*** | En son e-mail gönderilen zaman. | [optional] 
**creatorIpAddress** | **NSString*** | Mail listesi nesnesini oluşturan kişinin IP adresi. | [optional] 
**createdAt** | **NSDate*** | Mail listesi nesnesinin oluşturulma zamanı. | 
**updatedAt** | **NSDate*** | Mail listesi nesnesinin güncellenme zamanı. | 
**maillistGroup** | [**SWGMaillistGroup***](SWGMaillistGroup.md) | Mail listesi grubu nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


