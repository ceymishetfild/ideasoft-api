# SWGCategoryApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**categoriesGet**](SWGCategoryApi.md#categoriesget) | **GET** /categories | Kategori Listesi Alma
[**categoriesIdDelete**](SWGCategoryApi.md#categoriesiddelete) | **DELETE** /categories/{id} | Kategori Silme
[**categoriesIdGet**](SWGCategoryApi.md#categoriesidget) | **GET** /categories/{id} | Kategori Alma
[**categoriesIdPut**](SWGCategoryApi.md#categoriesidput) | **PUT** /categories/{id} | Kategori Güncelleme
[**categoriesPost**](SWGCategoryApi.md#categoriespost) | **POST** /categories | Kategori Oluşturma


# **categoriesGet**
```objc
-(NSURLSessionTask*) categoriesGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    name: (NSString*) name
    status: (NSString*) status
    distributor: (NSString*) distributor
    parent: (NSNumber*) parent
    startDate: (NSDate*) startDate
    endDate: (NSString*) endDate
    startUpdatedAt: (NSDate*) startUpdatedAt
    endUpdatedAt: (NSString*) endUpdatedAt
        completionHandler: (void (^)(SWGCategory* output, NSError* error)) handler;
```

Kategori Listesi Alma

Kategori listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* name = @"name_example"; // Kategori adı (optional)
NSString* status = @"status_example"; // Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif (optional)
NSString* distributor = @"distributor_example"; // Kategori Distribütör (optional)
NSNumber* parent = @56; // Üst kategori id (optional)
NSDate* startDate = @"2013-10-20"; // createdAt değeri için başlangıç tarihi (optional)
NSString* endDate = @"endDate_example"; // createdAt değeri için bitiş tarihi (optional)
NSDate* startUpdatedAt = @"2013-10-20"; // updatedAt değeri için başlangıç tarihi (optional)
NSString* endUpdatedAt = @"endUpdatedAt_example"; // updatedAt değeri için bitiş tarihi (optional)

SWGCategoryApi*apiInstance = [[SWGCategoryApi alloc] init];

// Kategori Listesi Alma
[apiInstance categoriesGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              name:name
              status:status
              distributor:distributor
              parent:parent
              startDate:startDate
              endDate:endDate
              startUpdatedAt:startUpdatedAt
              endUpdatedAt:endUpdatedAt
          completionHandler: ^(SWGCategory* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGCategoryApi->categoriesGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **NSString***| Kategori adı | [optional] 
 **status** | **NSString***| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **distributor** | **NSString***| Kategori Distribütör | [optional] 
 **parent** | **NSNumber***| Üst kategori id | [optional] 
 **startDate** | **NSDate***| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **NSString***| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **NSDate***| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **NSString***| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**SWGCategory***](SWGCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **categoriesIdDelete**
```objc
-(NSURLSessionTask*) categoriesIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Kategori Silme

Kalıcı olarak ilgili Kategoriyi siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Kategori nesnesinin id değeri

SWGCategoryApi*apiInstance = [[SWGCategoryApi alloc] init];

// Kategori Silme
[apiInstance categoriesIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGCategoryApi->categoriesIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Kategori nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **categoriesIdGet**
```objc
-(NSURLSessionTask*) categoriesIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGCategory* output, NSError* error)) handler;
```

Kategori Alma

İlgili Kategoriyi getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Kategori nesnesinin id değeri

SWGCategoryApi*apiInstance = [[SWGCategoryApi alloc] init];

// Kategori Alma
[apiInstance categoriesIdGetWithId:_id
          completionHandler: ^(SWGCategory* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGCategoryApi->categoriesIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Kategori nesnesinin id değeri | 

### Return type

[**SWGCategory***](SWGCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **categoriesIdPut**
```objc
-(NSURLSessionTask*) categoriesIdPutWithId: (NSNumber*) _id
    category: (SWGCategory*) category
        completionHandler: (void (^)(SWGCategory* output, NSError* error)) handler;
```

Kategori Güncelleme

İlgili Kategoriyi günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Kategori nesnesinin id değeri
SWGCategory* category = [[SWGCategory alloc] init]; //  nesnesi

SWGCategoryApi*apiInstance = [[SWGCategoryApi alloc] init];

// Kategori Güncelleme
[apiInstance categoriesIdPutWithId:_id
              category:category
          completionHandler: ^(SWGCategory* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGCategoryApi->categoriesIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Kategori nesnesinin id değeri | 
 **category** | [**SWGCategory***](SWGCategory.md)|  nesnesi | 

### Return type

[**SWGCategory***](SWGCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **categoriesPost**
```objc
-(NSURLSessionTask*) categoriesPostWithCategory: (SWGCategory*) category
        completionHandler: (void (^)(SWGCategory* output, NSError* error)) handler;
```

Kategori Oluşturma

Yeni bir Kategori oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGCategory* category = [[SWGCategory alloc] init]; //  nesnesi

SWGCategoryApi*apiInstance = [[SWGCategoryApi alloc] init];

// Kategori Oluşturma
[apiInstance categoriesPostWithCategory:category
          completionHandler: ^(SWGCategory* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGCategoryApi->categoriesPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **category** | [**SWGCategory***](SWGCategory.md)|  nesnesi | 

### Return type

[**SWGCategory***](SWGCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

