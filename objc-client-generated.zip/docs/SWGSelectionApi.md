# SWGSelectionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selectionsGet**](SWGSelectionApi.md#selectionsget) | **GET** /selections | Ek Özellik Listesi Alma
[**selectionsIdDelete**](SWGSelectionApi.md#selectionsiddelete) | **DELETE** /selections/{id} | Ek Özellik Silme
[**selectionsIdGet**](SWGSelectionApi.md#selectionsidget) | **GET** /selections/{id} | Ek Özellik Alma
[**selectionsIdPut**](SWGSelectionApi.md#selectionsidput) | **PUT** /selections/{id} | Ek Özellik Güncelleme
[**selectionsPost**](SWGSelectionApi.md#selectionspost) | **POST** /selections | Ek Özellik Oluşturma


# **selectionsGet**
```objc
-(NSURLSessionTask*) selectionsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    title: (NSString*) title
    selectionGroup: (NSNumber*) selectionGroup
        completionHandler: (void (^)(SWGSelection* output, NSError* error)) handler;
```

Ek Özellik Listesi Alma

Ek Özellik listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* title = @"title_example"; // Ek Özellik başlığı (optional)
NSNumber* selectionGroup = @56; // Ek Özellik Grubu id (optional)

SWGSelectionApi*apiInstance = [[SWGSelectionApi alloc] init];

// Ek Özellik Listesi Alma
[apiInstance selectionsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              title:title
              selectionGroup:selectionGroup
          completionHandler: ^(SWGSelection* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSelectionApi->selectionsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **title** | **NSString***| Ek Özellik başlığı | [optional] 
 **selectionGroup** | **NSNumber***| Ek Özellik Grubu id | [optional] 

### Return type

[**SWGSelection***](SWGSelection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selectionsIdDelete**
```objc
-(NSURLSessionTask*) selectionsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Ek Özellik Silme

Kalıcı olarak ilgili Ek Özelliği siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ek Özellik nesnesinin id değeri

SWGSelectionApi*apiInstance = [[SWGSelectionApi alloc] init];

// Ek Özellik Silme
[apiInstance selectionsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGSelectionApi->selectionsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ek Özellik nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selectionsIdGet**
```objc
-(NSURLSessionTask*) selectionsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGSelection* output, NSError* error)) handler;
```

Ek Özellik Alma

İlgili Ek Özelliği getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ek Özellik nesnesinin id değeri

SWGSelectionApi*apiInstance = [[SWGSelectionApi alloc] init];

// Ek Özellik Alma
[apiInstance selectionsIdGetWithId:_id
          completionHandler: ^(SWGSelection* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSelectionApi->selectionsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ek Özellik nesnesinin id değeri | 

### Return type

[**SWGSelection***](SWGSelection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selectionsIdPut**
```objc
-(NSURLSessionTask*) selectionsIdPutWithId: (NSNumber*) _id
    selection: (SWGSelection*) selection
        completionHandler: (void (^)(SWGSelection* output, NSError* error)) handler;
```

Ek Özellik Güncelleme

İlgili Ek Özelliği günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ek Özellik nesnesinin id değeri
SWGSelection* selection = [[SWGSelection alloc] init]; //  nesnesi

SWGSelectionApi*apiInstance = [[SWGSelectionApi alloc] init];

// Ek Özellik Güncelleme
[apiInstance selectionsIdPutWithId:_id
              selection:selection
          completionHandler: ^(SWGSelection* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSelectionApi->selectionsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ek Özellik nesnesinin id değeri | 
 **selection** | [**SWGSelection***](SWGSelection.md)|  nesnesi | 

### Return type

[**SWGSelection***](SWGSelection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selectionsPost**
```objc
-(NSURLSessionTask*) selectionsPostWithSelection: (SWGSelection*) selection
        completionHandler: (void (^)(SWGSelection* output, NSError* error)) handler;
```

Ek Özellik Oluşturma

Yeni bir Ek Özellik oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGSelection* selection = [[SWGSelection alloc] init]; //  nesnesi

SWGSelectionApi*apiInstance = [[SWGSelectionApi alloc] init];

// Ek Özellik Oluşturma
[apiInstance selectionsPostWithSelection:selection
          completionHandler: ^(SWGSelection* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSelectionApi->selectionsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selection** | [**SWGSelection***](SWGSelection.md)|  nesnesi | 

### Return type

[**SWGSelection***](SWGSelection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

