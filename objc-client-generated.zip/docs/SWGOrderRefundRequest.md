# SWGOrderRefundRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Sipariş iptal talebi nesnesi kimlik değeri. | [optional] 
**code** | **NSString*** | Sipariş iptal talebi için oluşturulan benzersiz kod değeri. | 
**status** | **NSString*** | Sipariş iptal talebi için durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı.&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor.&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi.&lt;br&gt;&lt;/div&gt; | 
**fee** | **NSNumber*** | Müşteriye ödenecek miktar bilgisi. | 
**cancellationReason** | **NSString*** | Sipariş iptal talebinin oluşturulması sebebinin detaylı açıklaması. | [optional] 
**createdAt** | **NSDate*** | Sipariş iptal talebi nesnesinin oluşturulma zamanı. | 
**updatedAt** | **NSDate*** | Sipariş iptal talebi nesnesinin güncellenme zamanı. | 
**member** | [**SWGMember***](SWGMember.md) | Üye nesnesi. | [optional] 
**order** | [**SWGOrder***](SWGOrder.md) | Sipariş nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


