# SWGOrderDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Sipariş detayı nesnesi kimlik değeri. | [optional] 
**varKey** | **NSString*** | Sipariş detayı nesnesi için değişken anahtarı. | 
**varValue** | **NSString*** | Sipariş detayı nesnesi için değişken değeri. | 
**order** | [**SWGOrder***](SWGOrder.md) | Sipariş nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


