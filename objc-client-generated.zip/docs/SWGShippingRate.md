# SWGShippingRate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Kargo oranı nesnesi kimlik değeri. | [optional] 
**volumetricWeightStart** | **NSNumber*** | İlgili kargo firması, ilgili bölge ve ilgili orana ait minimum desi değeri. | 
**volumetricWeightEnd** | **NSNumber*** | İlgili kargo firması, ilgili bölge ve ilgili orana ait maximum desi değeri. | 
**rate** | **NSNumber*** | Seçili bölge ve kargo firması için kargo oranı. | 
**region** | [**SWGRegion***](SWGRegion.md) | Bölge nesnesi. | [optional] 
**shippingCompany** | [**SWGShippingCompany***](SWGShippingCompany.md) | Kargo firması nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


