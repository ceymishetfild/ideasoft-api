# SWGExtraInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extraInfosGet**](SWGExtraInfoApi.md#extrainfosget) | **GET** /extra_infos | Ek Bilgi Listesi Alma
[**extraInfosIdDelete**](SWGExtraInfoApi.md#extrainfosiddelete) | **DELETE** /extra_infos/{id} | Ek Bilgi Silme
[**extraInfosIdGet**](SWGExtraInfoApi.md#extrainfosidget) | **GET** /extra_infos/{id} | Ek Bilgi Alma
[**extraInfosIdPut**](SWGExtraInfoApi.md#extrainfosidput) | **PUT** /extra_infos/{id} | Ek Bilgi Güncelleme
[**extraInfosPost**](SWGExtraInfoApi.md#extrainfospost) | **POST** /extra_infos | Ek Bilgi Oluşturma


# **extraInfosGet**
```objc
-(NSURLSessionTask*) extraInfosGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    name: (NSString*) name
        completionHandler: (void (^)(SWGExtraInfo* output, NSError* error)) handler;
```

Ek Bilgi Listesi Alma

Ek Bilgi listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* name = @"name_example"; // Ek Bilgi adı (optional)

SWGExtraInfoApi*apiInstance = [[SWGExtraInfoApi alloc] init];

// Ek Bilgi Listesi Alma
[apiInstance extraInfosGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              name:name
          completionHandler: ^(SWGExtraInfo* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGExtraInfoApi->extraInfosGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **NSString***| Ek Bilgi adı | [optional] 

### Return type

[**SWGExtraInfo***](SWGExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extraInfosIdDelete**
```objc
-(NSURLSessionTask*) extraInfosIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Ek Bilgi Silme

Kalıcı olarak ilgili Ek Bilgiyi siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ek Bilgi nesnesinin id değeri

SWGExtraInfoApi*apiInstance = [[SWGExtraInfoApi alloc] init];

// Ek Bilgi Silme
[apiInstance extraInfosIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGExtraInfoApi->extraInfosIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ek Bilgi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extraInfosIdGet**
```objc
-(NSURLSessionTask*) extraInfosIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGExtraInfo* output, NSError* error)) handler;
```

Ek Bilgi Alma

İlgili Ek Bilgiyi getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ek Bilgi nesnesinin id değeri

SWGExtraInfoApi*apiInstance = [[SWGExtraInfoApi alloc] init];

// Ek Bilgi Alma
[apiInstance extraInfosIdGetWithId:_id
          completionHandler: ^(SWGExtraInfo* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGExtraInfoApi->extraInfosIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ek Bilgi nesnesinin id değeri | 

### Return type

[**SWGExtraInfo***](SWGExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extraInfosIdPut**
```objc
-(NSURLSessionTask*) extraInfosIdPutWithId: (NSNumber*) _id
    extraInfo: (SWGExtraInfo*) extraInfo
        completionHandler: (void (^)(SWGExtraInfo* output, NSError* error)) handler;
```

Ek Bilgi Güncelleme

İlgili Ek Bilgiyi günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ek Bilgi nesnesinin id değeri
SWGExtraInfo* extraInfo = [[SWGExtraInfo alloc] init]; //  nesnesi

SWGExtraInfoApi*apiInstance = [[SWGExtraInfoApi alloc] init];

// Ek Bilgi Güncelleme
[apiInstance extraInfosIdPutWithId:_id
              extraInfo:extraInfo
          completionHandler: ^(SWGExtraInfo* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGExtraInfoApi->extraInfosIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ek Bilgi nesnesinin id değeri | 
 **extraInfo** | [**SWGExtraInfo***](SWGExtraInfo.md)|  nesnesi | 

### Return type

[**SWGExtraInfo***](SWGExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extraInfosPost**
```objc
-(NSURLSessionTask*) extraInfosPostWithExtraInfo: (SWGExtraInfo*) extraInfo
        completionHandler: (void (^)(SWGExtraInfo* output, NSError* error)) handler;
```

Ek Bilgi Oluşturma

Yeni bir Ek Bilgi oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGExtraInfo* extraInfo = [[SWGExtraInfo alloc] init]; //  nesnesi

SWGExtraInfoApi*apiInstance = [[SWGExtraInfoApi alloc] init];

// Ek Bilgi Oluşturma
[apiInstance extraInfosPostWithExtraInfo:extraInfo
          completionHandler: ^(SWGExtraInfo* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGExtraInfoApi->extraInfosPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extraInfo** | [**SWGExtraInfo***](SWGExtraInfo.md)|  nesnesi | 

### Return type

[**SWGExtraInfo***](SWGExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

