# SWGCart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Sepet nesnesi kimlik değeri. | [optional] 
**sessionId** | **NSString*** | Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri. | 
**locked** | **NSString*** | Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz. | [optional] 
**createdAt** | **NSDate*** | Sepet nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **NSDate*** | Sepet nesnesinin güncellenme zamanı. | [optional] 
**chosenPromotion** | [**SWGShopCampaigns***](SWGShopCampaigns.md) | Promosyon nesnesi. | [optional] 
**member** | [**SWGMember***](SWGMember.md) | Üye nesnesi. | [optional] 
**chosenToken** | [**SWGShopTokens***](SWGShopTokens.md) | Hediye çeki nesnesi. | [optional] 
**items** | [**NSArray&lt;SWGCartItem&gt;***](SWGCartItem.md) | Sepet kalemi nesnelerini barındıran liste. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


