# SWGShipment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Teslimat nesnesi kimlik değeri. | [optional] 
**barcode** | **NSString*** | Teslimat barkodu. | [optional] 
**waybillNo** | **NSString*** | Teslimat fatura numarası. | [optional] 
**invoiceKey** | **NSString*** | Teslimat irsaliye makbuzu numarası. | [optional] 
**cargoOffice** | **NSString*** | Teslimatın kargo şubesi | [optional] 
**code** | **NSString*** | Teslimat kodu. Kargo takip kodu. | [optional] 
**deliveryType** | **NSString*** | Teslimat tipi | [optional] 
**invoiceIncluded** | **NSString*** | Faturanın pakete dahillik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Dahil.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Dahil değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**payAtDoorAmount** | **NSNumber*** | Kapıda ödeme hizmeti bedeli. | [optional] 
**createdAt** | **NSDate*** | Teslimat nesnesinin oluşturulma zamanı. | [optional] 
**status** | **NSNumber*** | Teslimat nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**order** | [**SWGOrder***](SWGOrder.md) | Sipariş nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


