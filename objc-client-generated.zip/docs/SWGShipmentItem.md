# SWGShipmentItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Teslimat Kalemi nesnesi kimlik değeri. | [optional] 
**rootProductId** | **NSNumber*** | Ana ürünün id değeri. | [optional] 
**amount** | **NSNumber*** | Ürünün stok tipi cinsinden miktarı. | 
**price** | **NSNumber*** | Ürünün fiyatı. | 
**productLabel** | **NSString*** | Ürün başlığı. | [optional] 
**currency** | **NSString*** | Ürünün kur bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;USD&lt;/code&gt; : Amerikan Doları&lt;br&gt;&lt;code&gt;EUR&lt;/code&gt; : Euro&lt;br&gt;&lt;code&gt;TL&lt;/code&gt; : Türk Lirası&lt;br&gt;&lt;code&gt;GBP&lt;/code&gt; : İngiliz Sterlini&lt;br&gt;&lt;code&gt;JPY&lt;/code&gt; : Japon Yeni&lt;br&gt;&lt;code&gt;CNY&lt;/code&gt; : Çin Yuanı&lt;br&gt;&lt;code&gt;GR&lt;/code&gt; : Gram Altın&lt;br&gt;&lt;code&gt;CHF&lt;/code&gt; : İsviçre Frangı&lt;br&gt;&lt;/div&gt; | 
**tax** | **NSNumber*** | Ürünün vergi değeri. | [optional] 
**dm3** | **NSNumber*** | Ürünün desi bilgisi. | 
**createdAt** | **NSDate*** | Teslimat Kalemi nesnesinin oluşturulma zamanı. | [optional] 
**status** | **NSNumber*** | Teslimat Kalemi nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**updatedAt** | **NSDate*** | Teslimat Kalemi nesnesinin güncellenme zamanı. | [optional] 
**orderItem** | [**SWGOrderItem***](SWGOrderItem.md) | Sipariş kalemi nesnesi. | 
**product** | [**SWGProduct***](SWGProduct.md) | Ürün nesnesi. | [optional] 
**shipment** | [**SWGShipment***](SWGShipment.md) | Teslimat nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


