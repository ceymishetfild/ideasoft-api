# SWGDistributorApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**distributorsGet**](SWGDistributorApi.md#distributorsget) | **GET** /distributors | Distribütör Listesi Alma
[**distributorsIdDelete**](SWGDistributorApi.md#distributorsiddelete) | **DELETE** /distributors/{id} | Distribütör Silme
[**distributorsIdGet**](SWGDistributorApi.md#distributorsidget) | **GET** /distributors/{id} | Distribütör Alma
[**distributorsIdPut**](SWGDistributorApi.md#distributorsidput) | **PUT** /distributors/{id} | Distribütör Güncelleme
[**distributorsPost**](SWGDistributorApi.md#distributorspost) | **POST** /distributors | Distribütör Oluşturma


# **distributorsGet**
```objc
-(NSURLSessionTask*) distributorsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    name: (NSString*) name
    email: (NSString*) email
    phone: (NSString*) phone
    contactPerson: (NSString*) contactPerson
        completionHandler: (void (^)(SWGDistributor* output, NSError* error)) handler;
```

Distribütör Listesi Alma

Distribütör listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* name = @"name_example"; // Distribütör adı. (optional)
NSString* email = @"email_example"; // Distribütör email adresi (optional)
NSString* phone = @"phone_example"; // Distribütör telefonu (optional)
NSString* contactPerson = @"contactPerson_example"; // Distribütör sorumlu kişi (optional)

SWGDistributorApi*apiInstance = [[SWGDistributorApi alloc] init];

// Distribütör Listesi Alma
[apiInstance distributorsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              name:name
              email:email
              phone:phone
              contactPerson:contactPerson
          completionHandler: ^(SWGDistributor* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGDistributorApi->distributorsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **NSString***| Distribütör adı. | [optional] 
 **email** | **NSString***| Distribütör email adresi | [optional] 
 **phone** | **NSString***| Distribütör telefonu | [optional] 
 **contactPerson** | **NSString***| Distribütör sorumlu kişi | [optional] 

### Return type

[**SWGDistributor***](SWGDistributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributorsIdDelete**
```objc
-(NSURLSessionTask*) distributorsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Distribütör Silme

Kalıcı olarak ilgili Distribütörü siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Distribütör nesnesinin id değeri

SWGDistributorApi*apiInstance = [[SWGDistributorApi alloc] init];

// Distribütör Silme
[apiInstance distributorsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGDistributorApi->distributorsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Distribütör nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributorsIdGet**
```objc
-(NSURLSessionTask*) distributorsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGDistributor* output, NSError* error)) handler;
```

Distribütör Alma

İlgili Distribütörü getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Distribütör nesnesinin id değeri

SWGDistributorApi*apiInstance = [[SWGDistributorApi alloc] init];

// Distribütör Alma
[apiInstance distributorsIdGetWithId:_id
          completionHandler: ^(SWGDistributor* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGDistributorApi->distributorsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Distribütör nesnesinin id değeri | 

### Return type

[**SWGDistributor***](SWGDistributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributorsIdPut**
```objc
-(NSURLSessionTask*) distributorsIdPutWithId: (NSNumber*) _id
    distributor: (SWGDistributor*) distributor
        completionHandler: (void (^)(SWGDistributor* output, NSError* error)) handler;
```

Distribütör Güncelleme

İlgili Distribütörü günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Distribütör nesnesinin id değeri
SWGDistributor* distributor = [[SWGDistributor alloc] init]; //  nesnesi

SWGDistributorApi*apiInstance = [[SWGDistributorApi alloc] init];

// Distribütör Güncelleme
[apiInstance distributorsIdPutWithId:_id
              distributor:distributor
          completionHandler: ^(SWGDistributor* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGDistributorApi->distributorsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Distribütör nesnesinin id değeri | 
 **distributor** | [**SWGDistributor***](SWGDistributor.md)|  nesnesi | 

### Return type

[**SWGDistributor***](SWGDistributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributorsPost**
```objc
-(NSURLSessionTask*) distributorsPostWithDistributor: (SWGDistributor*) distributor
        completionHandler: (void (^)(SWGDistributor* output, NSError* error)) handler;
```

Distribütör Oluşturma

Yeni bir Distribütör oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGDistributor* distributor = [[SWGDistributor alloc] init]; //  nesnesi

SWGDistributorApi*apiInstance = [[SWGDistributorApi alloc] init];

// Distribütör Oluşturma
[apiInstance distributorsPostWithDistributor:distributor
          completionHandler: ^(SWGDistributor* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGDistributorApi->distributorsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **distributor** | [**SWGDistributor***](SWGDistributor.md)|  nesnesi | 

### Return type

[**SWGDistributor***](SWGDistributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

