# SWGLocation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Şehir nesnesi kimlik değeri. | [optional] 
**name** | **NSString*** | Şehir nesnesi için isim değeri. | 
**status** | **NSString*** | Şehir nesnesinin aktiflik durumunu belirten değer. | 
**predefined** | **NSString*** | Şehir nesnesinin öntanımlı olup olmadığını belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Öntanımlı şehir.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yeni eklenmiş şehir.&lt;br&gt;&lt;/div&gt; | [optional] 
**country** | [**SWGCountry***](SWGCountry.md) | Ülke nesnesi. | [optional] 
**region** | [**SWGRegion***](SWGRegion.md) | Bölge nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


