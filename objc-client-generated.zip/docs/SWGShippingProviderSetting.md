# SWGShippingProviderSetting

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Teslimat hizmeti sağlayıcısı ayarı nesnesi kimlik değeri. | [optional] 
**varKey** | **NSString*** | Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken anahtarı. | 
**varValue** | **NSString*** | Teslimat hizmeti sağlayıcısı ayarı nesnesi için değişken değeri. | 
**shippingProvider** | [**SWGShippingProvider***](SWGShippingProvider.md) | Teslimat hizmeti sağlayıcısı nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


