# SWGCartItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Sepet kalemi nesnesi kimlik değeri. | [optional] 
**parentProductId** | **NSNumber*** | Ana ürünün benzersiz rakamsal kimlik değeri. | [optional] 
**quantity** | **NSNumber*** | Sepetteki kalem adedi. | 
**categoryId** | **NSNumber*** | Sepetteki kaleme ait kategorinin benzersiz kimlik değeri. | [optional] 
**createdAt** | **NSDate*** | Sepet kalemi nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **NSDate*** | Sepet kalemi nesnesinin güncellenme zamanı. | [optional] 
**cart** | [**SWGCart***](SWGCart.md) | Sepet nesnesi. | 
**product** | [**SWGProduct***](SWGProduct.md) | Ürün nesnesi. | 
**attributes** | [**NSArray&lt;SWGCartItemAttribute&gt;***](SWGCartItemAttribute.md) | Sepet kalemi özelliği barındıran liste. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


