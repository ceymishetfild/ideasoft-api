# SWGPreOrderInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**preOrderInfosGet**](SWGPreOrderInfoApi.md#preorderinfosget) | **GET** /pre_order_infos | Sipariş Öncesi Bilgisi Listesi Alma
[**preOrderInfosIdDelete**](SWGPreOrderInfoApi.md#preorderinfosiddelete) | **DELETE** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Silme
[**preOrderInfosIdGet**](SWGPreOrderInfoApi.md#preorderinfosidget) | **GET** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Alma
[**preOrderInfosIdPut**](SWGPreOrderInfoApi.md#preorderinfosidput) | **PUT** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Güncelleme
[**preOrderInfosPost**](SWGPreOrderInfoApi.md#preorderinfospost) | **POST** /pre_order_infos | Sipariş Öncesi Bilgisi Oluşturma


# **preOrderInfosGet**
```objc
-(NSURLSessionTask*) preOrderInfosGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    sessionId: (NSString*) sessionId
    startDate: (NSDate*) startDate
    endDate: (NSString*) endDate
    startUpdatedAt: (NSDate*) startUpdatedAt
    endUpdatedAt: (NSString*) endUpdatedAt
        completionHandler: (void (^)(SWGPreOrderInfo* output, NSError* error)) handler;
```

Sipariş Öncesi Bilgisi Listesi Alma

Sipariş Öncesi Bilgisi listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* sessionId = @"sessionId_example"; // Sipariş Öncesi Bilgisi session id. (optional)
NSDate* startDate = @"2013-10-20"; // createdAt değeri için başlangıç tarihi (optional)
NSString* endDate = @"endDate_example"; // createdAt değeri için bitiş tarihi (optional)
NSDate* startUpdatedAt = @"2013-10-20"; // updatedAt değeri için başlangıç tarihi (optional)
NSString* endUpdatedAt = @"endUpdatedAt_example"; // updatedAt değeri için bitiş tarihi (optional)

SWGPreOrderInfoApi*apiInstance = [[SWGPreOrderInfoApi alloc] init];

// Sipariş Öncesi Bilgisi Listesi Alma
[apiInstance preOrderInfosGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              sessionId:sessionId
              startDate:startDate
              endDate:endDate
              startUpdatedAt:startUpdatedAt
              endUpdatedAt:endUpdatedAt
          completionHandler: ^(SWGPreOrderInfo* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGPreOrderInfoApi->preOrderInfosGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **sessionId** | **NSString***| Sipariş Öncesi Bilgisi session id. | [optional] 
 **startDate** | **NSDate***| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **NSString***| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **NSDate***| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **NSString***| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**SWGPreOrderInfo***](SWGPreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **preOrderInfosIdDelete**
```objc
-(NSURLSessionTask*) preOrderInfosIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Sipariş Öncesi Bilgisi Silme

Kalıcı olarak ilgili Sipariş Öncesi Bilgisini siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Sipariş Öncesi Bilgisi nesnesinin id değeri

SWGPreOrderInfoApi*apiInstance = [[SWGPreOrderInfoApi alloc] init];

// Sipariş Öncesi Bilgisi Silme
[apiInstance preOrderInfosIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGPreOrderInfoApi->preOrderInfosIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Sipariş Öncesi Bilgisi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **preOrderInfosIdGet**
```objc
-(NSURLSessionTask*) preOrderInfosIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGPreOrderInfo* output, NSError* error)) handler;
```

Sipariş Öncesi Bilgisi Alma

İlgili Sipariş Öncesi Bilgisini getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Sipariş Öncesi Bilgisi nesnesinin id değeri

SWGPreOrderInfoApi*apiInstance = [[SWGPreOrderInfoApi alloc] init];

// Sipariş Öncesi Bilgisi Alma
[apiInstance preOrderInfosIdGetWithId:_id
          completionHandler: ^(SWGPreOrderInfo* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGPreOrderInfoApi->preOrderInfosIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Sipariş Öncesi Bilgisi nesnesinin id değeri | 

### Return type

[**SWGPreOrderInfo***](SWGPreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **preOrderInfosIdPut**
```objc
-(NSURLSessionTask*) preOrderInfosIdPutWithId: (NSNumber*) _id
    preOrderInfo: (SWGPreOrderInfo*) preOrderInfo
        completionHandler: (void (^)(SWGPreOrderInfo* output, NSError* error)) handler;
```

Sipariş Öncesi Bilgisi Güncelleme

İlgili Sipariş Öncesi Bilgisini günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Sipariş Öncesi Bilgisi nesnesinin id değeri
SWGPreOrderInfo* preOrderInfo = [[SWGPreOrderInfo alloc] init]; //  nesnesi

SWGPreOrderInfoApi*apiInstance = [[SWGPreOrderInfoApi alloc] init];

// Sipariş Öncesi Bilgisi Güncelleme
[apiInstance preOrderInfosIdPutWithId:_id
              preOrderInfo:preOrderInfo
          completionHandler: ^(SWGPreOrderInfo* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGPreOrderInfoApi->preOrderInfosIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Sipariş Öncesi Bilgisi nesnesinin id değeri | 
 **preOrderInfo** | [**SWGPreOrderInfo***](SWGPreOrderInfo.md)|  nesnesi | 

### Return type

[**SWGPreOrderInfo***](SWGPreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **preOrderInfosPost**
```objc
-(NSURLSessionTask*) preOrderInfosPostWithPreOrderInfo: (SWGPreOrderInfo*) preOrderInfo
        completionHandler: (void (^)(SWGPreOrderInfo* output, NSError* error)) handler;
```

Sipariş Öncesi Bilgisi Oluşturma

Yeni bir Sipariş Öncesi Bilgisi oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGPreOrderInfo* preOrderInfo = [[SWGPreOrderInfo alloc] init]; //  nesnesi

SWGPreOrderInfoApi*apiInstance = [[SWGPreOrderInfoApi alloc] init];

// Sipariş Öncesi Bilgisi Oluşturma
[apiInstance preOrderInfosPostWithPreOrderInfo:preOrderInfo
          completionHandler: ^(SWGPreOrderInfo* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGPreOrderInfoApi->preOrderInfosPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **preOrderInfo** | [**SWGPreOrderInfo***](SWGPreOrderInfo.md)|  nesnesi | 

### Return type

[**SWGPreOrderInfo***](SWGPreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

