# SWGCartApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cartsIdDelete**](SWGCartApi.md#cartsiddelete) | **DELETE** /carts/{id} | Sepet Silme
[**cartsIdGet**](SWGCartApi.md#cartsidget) | **GET** /carts/{id} | Sepet Alma
[**cartsPost**](SWGCartApi.md#cartspost) | **POST** /carts | Sepet Oluşturma


# **cartsIdDelete**
```objc
-(NSURLSessionTask*) cartsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Sepet Silme

Kalıcı olarak ilgili Sepeti siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Sepet nesnesinin id değeri

SWGCartApi*apiInstance = [[SWGCartApi alloc] init];

// Sepet Silme
[apiInstance cartsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGCartApi->cartsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Sepet nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cartsIdGet**
```objc
-(NSURLSessionTask*) cartsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGCart* output, NSError* error)) handler;
```

Sepet Alma

İlgili Sepet getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Sepet nesnesinin id değeri

SWGCartApi*apiInstance = [[SWGCartApi alloc] init];

// Sepet Alma
[apiInstance cartsIdGetWithId:_id
          completionHandler: ^(SWGCart* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGCartApi->cartsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Sepet nesnesinin id değeri | 

### Return type

[**SWGCart***](SWGCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cartsPost**
```objc
-(NSURLSessionTask*) cartsPostWithCart: (SWGCart*) cart
        completionHandler: (void (^)(SWGCart* output, NSError* error)) handler;
```

Sepet Oluşturma

Yeni bir Sepet oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGCart* cart = [[SWGCart alloc] init]; //  nesnesi

SWGCartApi*apiInstance = [[SWGCartApi alloc] init];

// Sepet Oluşturma
[apiInstance cartsPostWithCart:cart
          completionHandler: ^(SWGCart* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGCartApi->cartsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart** | [**SWGCart***](SWGCart.md)|  nesnesi | 

### Return type

[**SWGCart***](SWGCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

