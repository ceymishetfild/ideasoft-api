# SWGProductComment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Ürün yorumu nesnesi kimlik değeri. | [optional] 
**title** | **NSString*** | Ürün yorumu başlığı. | 
**content** | **NSString*** | Ürün yorumu içeriği. | 
**status** | **NSNumber*** | Ürün yorumu durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**rank** | **NSNumber*** | Ürün yorumunda ürüne verilen puan.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : 1 puan.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : 2 puan.&lt;br&gt;&lt;code&gt;3&lt;/code&gt; : 3 puan.&lt;br&gt;&lt;code&gt;4&lt;/code&gt; : 4 puan.&lt;br&gt;&lt;code&gt;5&lt;/code&gt; : 5 puan.&lt;br&gt;&lt;/div&gt; | 
**isAnonymous** | **NSNumber*** | Ürün yorumu yapan kişinin anonim olup olmadığı bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Anonim.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Anonim değil.&lt;br&gt;&lt;/div&gt; | 
**createdAt** | **NSDate*** | Ürün yorumu nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **NSDate*** | Ürün yorumu nesnesinin güncellenme zamanı. | [optional] 
**member** | [**SWGMember***](SWGMember.md) | Yorumu yapan üye. | [optional] 
**product** | [**SWGProduct***](SWGProduct.md) | Yorum yapılan ürün. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


