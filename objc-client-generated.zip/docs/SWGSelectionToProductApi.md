# SWGSelectionToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selectionToProductsGet**](SWGSelectionToProductApi.md#selectiontoproductsget) | **GET** /selection_to_products | Ek Özellik Ürün Bağı Listesi Alma
[**selectionToProductsIdDelete**](SWGSelectionToProductApi.md#selectiontoproductsiddelete) | **DELETE** /selection_to_products/{id} | Ek Özellik Ürün Bağı Silme
[**selectionToProductsIdGet**](SWGSelectionToProductApi.md#selectiontoproductsidget) | **GET** /selection_to_products/{id} | Ek Özellik Ürün Bağı Alma
[**selectionToProductsIdPut**](SWGSelectionToProductApi.md#selectiontoproductsidput) | **PUT** /selection_to_products/{id} | Ek Özellik Ürün Bağı Güncelleme
[**selectionToProductsPost**](SWGSelectionToProductApi.md#selectiontoproductspost) | **POST** /selection_to_products | Ek Özellik Ürün Bağı Oluşturma


# **selectionToProductsGet**
```objc
-(NSURLSessionTask*) selectionToProductsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    selection: (NSNumber*) selection
    product: (NSNumber*) product
        completionHandler: (void (^)(SWGSelectionToProduct* output, NSError* error)) handler;
```

Ek Özellik Ürün Bağı Listesi Alma

Ek Özellik Ürün Bağı listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSNumber* selection = @56; // Ek Özellik id (optional)
NSNumber* product = @56; // Ürün id (optional)

SWGSelectionToProductApi*apiInstance = [[SWGSelectionToProductApi alloc] init];

// Ek Özellik Ürün Bağı Listesi Alma
[apiInstance selectionToProductsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              selection:selection
              product:product
          completionHandler: ^(SWGSelectionToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSelectionToProductApi->selectionToProductsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **selection** | **NSNumber***| Ek Özellik id | [optional] 
 **product** | **NSNumber***| Ürün id | [optional] 

### Return type

[**SWGSelectionToProduct***](SWGSelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selectionToProductsIdDelete**
```objc
-(NSURLSessionTask*) selectionToProductsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Ek Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ek Özellik Ürün Bağını siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ek Özellik Ürün Bağı nesnesinin id değeri

SWGSelectionToProductApi*apiInstance = [[SWGSelectionToProductApi alloc] init];

// Ek Özellik Ürün Bağı Silme
[apiInstance selectionToProductsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGSelectionToProductApi->selectionToProductsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ek Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selectionToProductsIdGet**
```objc
-(NSURLSessionTask*) selectionToProductsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGSelectionToProduct* output, NSError* error)) handler;
```

Ek Özellik Ürün Bağı Alma

İlgili Ek Özellik Ürün Bağını getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ek Özellik Ürün Bağı nesnesinin id değeri

SWGSelectionToProductApi*apiInstance = [[SWGSelectionToProductApi alloc] init];

// Ek Özellik Ürün Bağı Alma
[apiInstance selectionToProductsIdGetWithId:_id
          completionHandler: ^(SWGSelectionToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSelectionToProductApi->selectionToProductsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ek Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

[**SWGSelectionToProduct***](SWGSelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selectionToProductsIdPut**
```objc
-(NSURLSessionTask*) selectionToProductsIdPutWithId: (NSNumber*) _id
    selectionToProduct: (SWGSelectionToProduct*) selectionToProduct
        completionHandler: (void (^)(SWGSelectionToProduct* output, NSError* error)) handler;
```

Ek Özellik Ürün Bağı Güncelleme

İlgili Ek Özellik Ürün Bağını günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ek Özellik Ürün Bağı nesnesinin id değeri
SWGSelectionToProduct* selectionToProduct = [[SWGSelectionToProduct alloc] init]; //  nesnesi

SWGSelectionToProductApi*apiInstance = [[SWGSelectionToProductApi alloc] init];

// Ek Özellik Ürün Bağı Güncelleme
[apiInstance selectionToProductsIdPutWithId:_id
              selectionToProduct:selectionToProduct
          completionHandler: ^(SWGSelectionToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSelectionToProductApi->selectionToProductsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ek Özellik Ürün Bağı nesnesinin id değeri | 
 **selectionToProduct** | [**SWGSelectionToProduct***](SWGSelectionToProduct.md)|  nesnesi | 

### Return type

[**SWGSelectionToProduct***](SWGSelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selectionToProductsPost**
```objc
-(NSURLSessionTask*) selectionToProductsPostWithSelectionToProduct: (SWGSelectionToProduct*) selectionToProduct
        completionHandler: (void (^)(SWGSelectionToProduct* output, NSError* error)) handler;
```

Ek Özellik Ürün Bağı Oluşturma

Yeni bir Ek Özellik Ürün Bağı oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGSelectionToProduct* selectionToProduct = [[SWGSelectionToProduct alloc] init]; //  nesnesi

SWGSelectionToProductApi*apiInstance = [[SWGSelectionToProductApi alloc] init];

// Ek Özellik Ürün Bağı Oluşturma
[apiInstance selectionToProductsPostWithSelectionToProduct:selectionToProduct
          completionHandler: ^(SWGSelectionToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSelectionToProductApi->selectionToProductsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selectionToProduct** | [**SWGSelectionToProduct***](SWGSelectionToProduct.md)|  nesnesi | 

### Return type

[**SWGSelectionToProduct***](SWGSelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

