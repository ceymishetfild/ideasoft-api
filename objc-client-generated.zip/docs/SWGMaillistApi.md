# SWGMaillistApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**maillistsGet**](SWGMaillistApi.md#maillistsget) | **GET** /maillists | Mail Listesi Listesi Alma
[**maillistsIdDelete**](SWGMaillistApi.md#maillistsiddelete) | **DELETE** /maillists/{id} | Mail Listesi Silme
[**maillistsIdGet**](SWGMaillistApi.md#maillistsidget) | **GET** /maillists/{id} | Mail Listesi Alma
[**maillistsIdPut**](SWGMaillistApi.md#maillistsidput) | **PUT** /maillists/{id} | Mail Listesi Güncelleme
[**maillistsPost**](SWGMaillistApi.md#maillistspost) | **POST** /maillists | Mail Listesi Oluşturma


# **maillistsGet**
```objc
-(NSURLSessionTask*) maillistsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    name: (NSString*) name
    email: (NSString*) email
    maillistGroup: (NSNumber*) maillistGroup
    startDate: (NSDate*) startDate
    endDate: (NSString*) endDate
    startUpdatedAt: (NSDate*) startUpdatedAt
    endUpdatedAt: (NSString*) endUpdatedAt
        completionHandler: (void (^)(SWGMaillist* output, NSError* error)) handler;
```

Mail Listesi Listesi Alma

Mail Listesi listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* name = @"name_example"; // Mail Listesi adı. (optional)
NSString* email = @"email_example"; // Mail Listesi e-mail. (optional)
NSNumber* maillistGroup = @56; // Mail Listesi Grubu id (optional)
NSDate* startDate = @"2013-10-20"; // createdAt değeri için başlangıç tarihi (optional)
NSString* endDate = @"endDate_example"; // createdAt değeri için bitiş tarihi (optional)
NSDate* startUpdatedAt = @"2013-10-20"; // updatedAt değeri için başlangıç tarihi (optional)
NSString* endUpdatedAt = @"endUpdatedAt_example"; // updatedAt değeri için bitiş tarihi (optional)

SWGMaillistApi*apiInstance = [[SWGMaillistApi alloc] init];

// Mail Listesi Listesi Alma
[apiInstance maillistsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              name:name
              email:email
              maillistGroup:maillistGroup
              startDate:startDate
              endDate:endDate
              startUpdatedAt:startUpdatedAt
              endUpdatedAt:endUpdatedAt
          completionHandler: ^(SWGMaillist* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMaillistApi->maillistsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **NSString***| Mail Listesi adı. | [optional] 
 **email** | **NSString***| Mail Listesi e-mail. | [optional] 
 **maillistGroup** | **NSNumber***| Mail Listesi Grubu id | [optional] 
 **startDate** | **NSDate***| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **NSString***| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **NSDate***| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **NSString***| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**SWGMaillist***](SWGMaillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillistsIdDelete**
```objc
-(NSURLSessionTask*) maillistsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Mail Listesi Silme

Kalıcı olarak ilgili Mail Listesini siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Mail Listesi nesnesinin id değeri

SWGMaillistApi*apiInstance = [[SWGMaillistApi alloc] init];

// Mail Listesi Silme
[apiInstance maillistsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGMaillistApi->maillistsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Mail Listesi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillistsIdGet**
```objc
-(NSURLSessionTask*) maillistsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGMaillist* output, NSError* error)) handler;
```

Mail Listesi Alma

İlgili Mail Listesini getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Mail Listesi nesnesinin id değeri

SWGMaillistApi*apiInstance = [[SWGMaillistApi alloc] init];

// Mail Listesi Alma
[apiInstance maillistsIdGetWithId:_id
          completionHandler: ^(SWGMaillist* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMaillistApi->maillistsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Mail Listesi nesnesinin id değeri | 

### Return type

[**SWGMaillist***](SWGMaillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillistsIdPut**
```objc
-(NSURLSessionTask*) maillistsIdPutWithId: (NSNumber*) _id
    maillist: (SWGMaillist*) maillist
        completionHandler: (void (^)(SWGMaillist* output, NSError* error)) handler;
```

Mail Listesi Güncelleme

İlgili Mail Listesini günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Mail Listesi nesnesinin id değeri
SWGMaillist* maillist = [[SWGMaillist alloc] init]; //  nesnesi

SWGMaillistApi*apiInstance = [[SWGMaillistApi alloc] init];

// Mail Listesi Güncelleme
[apiInstance maillistsIdPutWithId:_id
              maillist:maillist
          completionHandler: ^(SWGMaillist* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMaillistApi->maillistsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Mail Listesi nesnesinin id değeri | 
 **maillist** | [**SWGMaillist***](SWGMaillist.md)|  nesnesi | 

### Return type

[**SWGMaillist***](SWGMaillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillistsPost**
```objc
-(NSURLSessionTask*) maillistsPostWithMaillist: (SWGMaillist*) maillist
        completionHandler: (void (^)(SWGMaillist* output, NSError* error)) handler;
```

Mail Listesi Oluşturma

Yeni bir Mail Listesini oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGMaillist* maillist = [[SWGMaillist alloc] init]; //  nesnesi

SWGMaillistApi*apiInstance = [[SWGMaillistApi alloc] init];

// Mail Listesi Oluşturma
[apiInstance maillistsPostWithMaillist:maillist
          completionHandler: ^(SWGMaillist* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMaillistApi->maillistsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **maillist** | [**SWGMaillist***](SWGMaillist.md)|  nesnesi | 

### Return type

[**SWGMaillist***](SWGMaillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

