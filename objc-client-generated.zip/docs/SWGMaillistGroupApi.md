# SWGMaillistGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**maillistGroupsGet**](SWGMaillistGroupApi.md#maillistgroupsget) | **GET** /maillist_groups | Mail Listesi Grubu Listesi Alma
[**maillistGroupsIdDelete**](SWGMaillistGroupApi.md#maillistgroupsiddelete) | **DELETE** /maillist_groups/{id} | Mail Listesi Grubu Silme
[**maillistGroupsIdGet**](SWGMaillistGroupApi.md#maillistgroupsidget) | **GET** /maillist_groups/{id} | Mail Listesi Grubu Alma
[**maillistGroupsIdPut**](SWGMaillistGroupApi.md#maillistgroupsidput) | **PUT** /maillist_groups/{id} | Mail Listesi Grubu Güncelleme
[**maillistGroupsPost**](SWGMaillistGroupApi.md#maillistgroupspost) | **POST** /maillist_groups | Mail Listesi Grubu Oluşturma


# **maillistGroupsGet**
```objc
-(NSURLSessionTask*) maillistGroupsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    name: (NSString*) name
        completionHandler: (void (^)(SWGMaillistGroup* output, NSError* error)) handler;
```

Mail Listesi Grubu Listesi Alma

Mail Listesi Grubu listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* name = @"name_example"; // Mail Listesi Grubu adı (optional)

SWGMaillistGroupApi*apiInstance = [[SWGMaillistGroupApi alloc] init];

// Mail Listesi Grubu Listesi Alma
[apiInstance maillistGroupsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              name:name
          completionHandler: ^(SWGMaillistGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMaillistGroupApi->maillistGroupsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **NSString***| Mail Listesi Grubu adı | [optional] 

### Return type

[**SWGMaillistGroup***](SWGMaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillistGroupsIdDelete**
```objc
-(NSURLSessionTask*) maillistGroupsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Mail Listesi Grubu Silme

Kalıcı olarak ilgili Mail Listesi Grubunu siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Mail Listesi Grubu nesnesinin id değeri

SWGMaillistGroupApi*apiInstance = [[SWGMaillistGroupApi alloc] init];

// Mail Listesi Grubu Silme
[apiInstance maillistGroupsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGMaillistGroupApi->maillistGroupsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Mail Listesi Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillistGroupsIdGet**
```objc
-(NSURLSessionTask*) maillistGroupsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGMaillistGroup* output, NSError* error)) handler;
```

Mail Listesi Grubu Alma

İlgili Mail Listesi Grubunu getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Mail Listesi Grubu nesnesinin id değeri

SWGMaillistGroupApi*apiInstance = [[SWGMaillistGroupApi alloc] init];

// Mail Listesi Grubu Alma
[apiInstance maillistGroupsIdGetWithId:_id
          completionHandler: ^(SWGMaillistGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMaillistGroupApi->maillistGroupsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Mail Listesi Grubu nesnesinin id değeri | 

### Return type

[**SWGMaillistGroup***](SWGMaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillistGroupsIdPut**
```objc
-(NSURLSessionTask*) maillistGroupsIdPutWithId: (NSNumber*) _id
    maillistGroup: (SWGMaillistGroup*) maillistGroup
        completionHandler: (void (^)(SWGMaillistGroup* output, NSError* error)) handler;
```

Mail Listesi Grubu Güncelleme

İlgili Mail Listesi Grubunu günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Mail Listesi Grubu nesnesinin id değeri
SWGMaillistGroup* maillistGroup = [[SWGMaillistGroup alloc] init]; //  nesnesi

SWGMaillistGroupApi*apiInstance = [[SWGMaillistGroupApi alloc] init];

// Mail Listesi Grubu Güncelleme
[apiInstance maillistGroupsIdPutWithId:_id
              maillistGroup:maillistGroup
          completionHandler: ^(SWGMaillistGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMaillistGroupApi->maillistGroupsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Mail Listesi Grubu nesnesinin id değeri | 
 **maillistGroup** | [**SWGMaillistGroup***](SWGMaillistGroup.md)|  nesnesi | 

### Return type

[**SWGMaillistGroup***](SWGMaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillistGroupsPost**
```objc
-(NSURLSessionTask*) maillistGroupsPostWithMaillistGroup: (SWGMaillistGroup*) maillistGroup
        completionHandler: (void (^)(SWGMaillistGroup* output, NSError* error)) handler;
```

Mail Listesi Grubu Oluşturma

Yeni bir Mail Listesi Grubu oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGMaillistGroup* maillistGroup = [[SWGMaillistGroup alloc] init]; //  nesnesi

SWGMaillistGroupApi*apiInstance = [[SWGMaillistGroupApi alloc] init];

// Mail Listesi Grubu Oluşturma
[apiInstance maillistGroupsPostWithMaillistGroup:maillistGroup
          completionHandler: ^(SWGMaillistGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMaillistGroupApi->maillistGroupsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **maillistGroup** | [**SWGMaillistGroup***](SWGMaillistGroup.md)|  nesnesi | 

### Return type

[**SWGMaillistGroup***](SWGMaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

