# SWGTag

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | SEO+ etiketi nesnesi kimlik değeri. | [optional] 
**name** | **NSString*** | SEO+ etiketi nesnesi için isim değeri. | 
**count** | **NSNumber*** | SEO+ etiketinin kaç kez kullanıldığı bilgisi. | [optional] 
**pageTitle** | **NSString*** | SEO+ etiketi nesnesinin etiket başlığı. | [optional] 
**metaDescription** | **NSString*** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] 
**metaKeywords** | **NSString*** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


