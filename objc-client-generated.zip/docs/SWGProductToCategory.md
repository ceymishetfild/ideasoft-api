# SWGProductToCategory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Ürün kategori bağı nesnesi kimlik değeri. | [optional] 
**sortOrder** | **NSNumber*** | Ürün kategori bağının sıralama değeri. Özel sıra belirtmek istemiyorsanız 9999 olarak iletebilirsiniz. | [optional] 
**product** | [**SWGProduct***](SWGProduct.md) | Ürün nesnesi. | 
**category** | [**SWGCategory***](SWGCategory.md) | Kategori nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


