# SWGShippingRateApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shippingRatesGet**](SWGShippingRateApi.md#shippingratesget) | **GET** /shipping_rates | Kargo Oranı Listesi Alma
[**shippingRatesIdDelete**](SWGShippingRateApi.md#shippingratesiddelete) | **DELETE** /shipping_rates/{id} | Kargo Oranı Silme
[**shippingRatesIdGet**](SWGShippingRateApi.md#shippingratesidget) | **GET** /shipping_rates/{id} | Kargo Oranı Alma
[**shippingRatesIdPut**](SWGShippingRateApi.md#shippingratesidput) | **PUT** /shipping_rates/{id} | Kargo Oranı Güncelleme
[**shippingRatesPost**](SWGShippingRateApi.md#shippingratespost) | **POST** /shipping_rates | Kargo Oranı Oluşturma


# **shippingRatesGet**
```objc
-(NSURLSessionTask*) shippingRatesGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    shippingCompany: (NSNumber*) shippingCompany
    region: (NSNumber*) region
        completionHandler: (void (^)(SWGShippingRate* output, NSError* error)) handler;
```

Kargo Oranı Listesi Alma

Kargo Oranı listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSNumber* shippingCompany = @56; // Kargo firması id (optional)
NSNumber* region = @56; // Bölge id (optional)

SWGShippingRateApi*apiInstance = [[SWGShippingRateApi alloc] init];

// Kargo Oranı Listesi Alma
[apiInstance shippingRatesGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              shippingCompany:shippingCompany
              region:region
          completionHandler: ^(SWGShippingRate* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGShippingRateApi->shippingRatesGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **shippingCompany** | **NSNumber***| Kargo firması id | [optional] 
 **region** | **NSNumber***| Bölge id | [optional] 

### Return type

[**SWGShippingRate***](SWGShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shippingRatesIdDelete**
```objc
-(NSURLSessionTask*) shippingRatesIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Kargo Oranı Silme

Kalıcı olarak ilgili Kargo Oranını siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Kargo Oranı nesnesinin id değeri

SWGShippingRateApi*apiInstance = [[SWGShippingRateApi alloc] init];

// Kargo Oranı Silme
[apiInstance shippingRatesIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGShippingRateApi->shippingRatesIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Kargo Oranı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shippingRatesIdGet**
```objc
-(NSURLSessionTask*) shippingRatesIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGShippingRate* output, NSError* error)) handler;
```

Kargo Oranı Alma

İlgili Kargo Oranını getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Kargo Oranı nesnesinin id değeri

SWGShippingRateApi*apiInstance = [[SWGShippingRateApi alloc] init];

// Kargo Oranı Alma
[apiInstance shippingRatesIdGetWithId:_id
          completionHandler: ^(SWGShippingRate* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGShippingRateApi->shippingRatesIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Kargo Oranı nesnesinin id değeri | 

### Return type

[**SWGShippingRate***](SWGShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shippingRatesIdPut**
```objc
-(NSURLSessionTask*) shippingRatesIdPutWithId: (NSNumber*) _id
    shippingRate: (SWGShippingRate*) shippingRate
        completionHandler: (void (^)(SWGShippingRate* output, NSError* error)) handler;
```

Kargo Oranı Güncelleme

İlgili Kargo Oranını günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Kargo Oranı nesnesinin id değeri
SWGShippingRate* shippingRate = [[SWGShippingRate alloc] init]; //  nesnesi

SWGShippingRateApi*apiInstance = [[SWGShippingRateApi alloc] init];

// Kargo Oranı Güncelleme
[apiInstance shippingRatesIdPutWithId:_id
              shippingRate:shippingRate
          completionHandler: ^(SWGShippingRate* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGShippingRateApi->shippingRatesIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Kargo Oranı nesnesinin id değeri | 
 **shippingRate** | [**SWGShippingRate***](SWGShippingRate.md)|  nesnesi | 

### Return type

[**SWGShippingRate***](SWGShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shippingRatesPost**
```objc
-(NSURLSessionTask*) shippingRatesPostWithShippingRate: (SWGShippingRate*) shippingRate
        completionHandler: (void (^)(SWGShippingRate* output, NSError* error)) handler;
```

Kargo Oranı Oluşturma

Yeni bir Kargo Oranı oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGShippingRate* shippingRate = [[SWGShippingRate alloc] init]; //  nesnesi

SWGShippingRateApi*apiInstance = [[SWGShippingRateApi alloc] init];

// Kargo Oranı Oluşturma
[apiInstance shippingRatesPostWithShippingRate:shippingRate
          completionHandler: ^(SWGShippingRate* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGShippingRateApi->shippingRatesPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shippingRate** | [**SWGShippingRate***](SWGShippingRate.md)|  nesnesi | 

### Return type

[**SWGShippingRate***](SWGShippingRate.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

