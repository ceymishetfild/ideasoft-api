# SWGSpecValueApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specValuesGet**](SWGSpecValueApi.md#specvaluesget) | **GET** /spec_values | Ürün Özellik Değeri Listesi Alma
[**specValuesIdDelete**](SWGSpecValueApi.md#specvaluesiddelete) | **DELETE** /spec_values/{id} | Ürün Özellik Değeri Silme
[**specValuesIdGet**](SWGSpecValueApi.md#specvaluesidget) | **GET** /spec_values/{id} | Ürün Özellik Değeri Alma
[**specValuesIdPut**](SWGSpecValueApi.md#specvaluesidput) | **PUT** /spec_values/{id} | Ürün Özellik Değeri Güncelleme
[**specValuesPost**](SWGSpecValueApi.md#specvaluespost) | **POST** /spec_values | Ürün Özellik Değeri Oluşturma


# **specValuesGet**
```objc
-(NSURLSessionTask*) specValuesGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    name: (NSString*) name
    specName: (NSNumber*) specName
    specValue: (NSNumber*) specValue
        completionHandler: (void (^)(SWGSpecValue* output, NSError* error)) handler;
```

Ürün Özellik Değeri Listesi Alma

Ürün Özellik Değeri listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* name = @"name_example"; // Ürün özellik adı (optional)
NSNumber* specName = @56; // Ürün özellik id (optional)
NSNumber* specValue = @56; // Ürün özellik değeri id (optional)

SWGSpecValueApi*apiInstance = [[SWGSpecValueApi alloc] init];

// Ürün Özellik Değeri Listesi Alma
[apiInstance specValuesGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              name:name
              specName:specName
              specValue:specValue
          completionHandler: ^(SWGSpecValue* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecValueApi->specValuesGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **NSString***| Ürün özellik adı | [optional] 
 **specName** | **NSNumber***| Ürün özellik id | [optional] 
 **specValue** | **NSNumber***| Ürün özellik değeri id | [optional] 

### Return type

[**SWGSpecValue***](SWGSpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specValuesIdDelete**
```objc
-(NSURLSessionTask*) specValuesIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Ürün Özellik Değeri Silme

Kalıcı olarak ilgili Ürün Özellik Değerini siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Özellik Değeri nesnesinin id değeri

SWGSpecValueApi*apiInstance = [[SWGSpecValueApi alloc] init];

// Ürün Özellik Değeri Silme
[apiInstance specValuesIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGSpecValueApi->specValuesIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Özellik Değeri nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specValuesIdGet**
```objc
-(NSURLSessionTask*) specValuesIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGSpecValue* output, NSError* error)) handler;
```

Ürün Özellik Değeri Alma

İlgili Ürün Özellik Değerini getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Özellik Değeri nesnesinin id değeri

SWGSpecValueApi*apiInstance = [[SWGSpecValueApi alloc] init];

// Ürün Özellik Değeri Alma
[apiInstance specValuesIdGetWithId:_id
          completionHandler: ^(SWGSpecValue* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecValueApi->specValuesIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Özellik Değeri nesnesinin id değeri | 

### Return type

[**SWGSpecValue***](SWGSpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specValuesIdPut**
```objc
-(NSURLSessionTask*) specValuesIdPutWithId: (NSNumber*) _id
    specValue: (SWGSpecValue*) specValue
        completionHandler: (void (^)(SWGSpecValue* output, NSError* error)) handler;
```

Ürün Özellik Değeri Güncelleme

İlgili Ürün Özellik Değerini günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Özellik Değeri nesnesinin id değeri
SWGSpecValue* specValue = [[SWGSpecValue alloc] init]; //  nesnesi

SWGSpecValueApi*apiInstance = [[SWGSpecValueApi alloc] init];

// Ürün Özellik Değeri Güncelleme
[apiInstance specValuesIdPutWithId:_id
              specValue:specValue
          completionHandler: ^(SWGSpecValue* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecValueApi->specValuesIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Özellik Değeri nesnesinin id değeri | 
 **specValue** | [**SWGSpecValue***](SWGSpecValue.md)|  nesnesi | 

### Return type

[**SWGSpecValue***](SWGSpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specValuesPost**
```objc
-(NSURLSessionTask*) specValuesPostWithSpecValue: (SWGSpecValue*) specValue
        completionHandler: (void (^)(SWGSpecValue* output, NSError* error)) handler;
```

Ürün Özellik Değeri Oluşturma

Yeni bir Ürün Özellik Değeri oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGSpecValue* specValue = [[SWGSpecValue alloc] init]; //  nesnesi

SWGSpecValueApi*apiInstance = [[SWGSpecValueApi alloc] init];

// Ürün Özellik Değeri Oluşturma
[apiInstance specValuesPostWithSpecValue:specValue
          completionHandler: ^(SWGSpecValue* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecValueApi->specValuesPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specValue** | [**SWGSpecValue***](SWGSpecValue.md)|  nesnesi | 

### Return type

[**SWGSpecValue***](SWGSpecValue.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

