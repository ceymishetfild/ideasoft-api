# SWGPaymentProvider

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Ödeme altyapısı sağlayıcısı nesnesi kimlik değeri. | [optional] 
**code** | **NSString*** | Ödeme altyapısı sağlayıcısı için ön tanımlanmış kod değeri. | 
**name** | **NSString*** | Ödeme altyapısı sağlayıcısı için isim değeri. | 
**status** | **NSString*** | Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer. | 
**paymentType** | [**SWGPaymentType***](SWGPaymentType.md) | Ödeme tipi nesnesi. | 
**settings** | [**NSArray&lt;SWGPaymentProviderSetting&gt;***](SWGPaymentProviderSetting.md) | Ödeme altyapısı sağlayıcısı ayarları | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


