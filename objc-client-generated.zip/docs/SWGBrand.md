# SWGBrand

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Marka nesnesi kimlik değeri. | [optional] 
**name** | **NSString*** | Marka nesnesi için isim değeri. | 
**slug** | **NSString*** | Slug değeri ilgili nesnenin Url değeridir. | [optional] 
**sortOrder** | **NSNumber*** | Marka nesnesi için sıralama değeri. | [optional] 
**status** | **NSString*** | Marka nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**distributor** | **NSString*** | Markanın tedarikçisi. | [optional] 
**imageFile** | **NSString*** | Marka nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF | [optional] 
**showcaseContent** | **NSString*** | Marka nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir. | [optional] 
**displayShowcaseContent** | **NSString*** | Marka nesnesi üst içerik metninin gösterim durumu. | [optional] 
**metaKeywords** | **NSString*** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] 
**metaDescription** | **NSString*** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] 
**pageTitle** | **NSString*** | Marka nesnesinin etiket başlığı. | [optional] 
**attachment** | **NSString*** | Marka nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. | [optional] 
**createdAt** | **NSDate*** | Marka nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **NSDate*** | Marka nesnesinin güncellenme zamanı. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


