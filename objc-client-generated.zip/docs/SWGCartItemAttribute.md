# SWGCartItemAttribute

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Sepet kalemi özelliği nesnesi kimlik değeri. | [optional] 
**name** | **NSString*** | Sepet kalemi özelliği nesnesinin isim değeri. Örneğin, sepet kalemi kalem ise bu değer renk olabilir. | [optional] 
**value** | **NSString*** | Sepet kalemi özelliği nesnesinin değeri. Örneğin, sepet kalemi kalem, isim değeri renk ise bu değer kırmızı olabilir. | [optional] 
**createdAt** | **NSDate*** | Sepet kalemi özelliği nesnesinin oluşturulma zamanı. | [optional] 
**cartItem** | [**SWGCartItem***](SWGCartItem.md) | Sepet kalemi nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


