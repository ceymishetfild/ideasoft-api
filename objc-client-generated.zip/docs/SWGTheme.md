# SWGTheme

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Tema nesnesi kimlik değeri. | [optional] 
**platform** | **NSString*** | Temanın kullanılacağı platform.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü.&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil.&lt;br&gt;&lt;/div&gt; | 
**type** | **NSString*** | Tema tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;self&lt;/code&gt; : Kişisel Tema.&lt;br&gt;&lt;code&gt;standard&lt;/code&gt; : Standart Tema.&lt;br&gt;&lt;/div&gt; | [optional] 
**name** | **NSString*** | Tema adı. | 
**preset** | **NSString*** | Temanın rengi. | [optional] 
**directoryName** | **NSString*** | Temanın dizini. | [optional] 
**status** | **NSString*** | Temanın durumu. | 
**revision** | **NSNumber*** | Temanın revisionı. | [optional] 
**createdAt** | **NSDate*** | Tema nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **NSDate*** | Tema nesnesinin güncellenme zamanı. | [optional] 
**attachment** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


