# SWGExtraInfoToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Ek bilgi ürün bağı nesnesi kimlik değeri. | [optional] 
**value** | **NSString*** | Ek bilgi ürün bağı değeridir. Ek bilgi renk ise bu değer kırmızı olabilir. | 
**extraInfo** | [**SWGExtraInfo***](SWGExtraInfo.md) | Ek bilgi nesnesi. | 
**product** | [**SWGProduct***](SWGProduct.md) | Ürün nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


