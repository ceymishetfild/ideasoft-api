# SWGOptionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**optionGroupsGet**](SWGOptionGroupApi.md#optiongroupsget) | **GET** /option_groups | Varyant Grubu Listesi Alma
[**optionGroupsIdDelete**](SWGOptionGroupApi.md#optiongroupsiddelete) | **DELETE** /option_groups/{id} | Varyant Grubu Silme
[**optionGroupsIdGet**](SWGOptionGroupApi.md#optiongroupsidget) | **GET** /option_groups/{id} | Varyant Grubu Alma
[**optionGroupsIdPut**](SWGOptionGroupApi.md#optiongroupsidput) | **PUT** /option_groups/{id} | Varyant Grubu Güncelleme
[**optionGroupsPost**](SWGOptionGroupApi.md#optiongroupspost) | **POST** /option_groups | Varyant Grubu Oluşturma


# **optionGroupsGet**
```objc
-(NSURLSessionTask*) optionGroupsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    title: (NSString*) title
        completionHandler: (void (^)(SWGOptionGroup* output, NSError* error)) handler;
```

Varyant Grubu Listesi Alma

Varyant Grubu listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* title = @"title_example"; // Varyant Grubu başlığı. (optional)

SWGOptionGroupApi*apiInstance = [[SWGOptionGroupApi alloc] init];

// Varyant Grubu Listesi Alma
[apiInstance optionGroupsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              title:title
          completionHandler: ^(SWGOptionGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOptionGroupApi->optionGroupsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **title** | **NSString***| Varyant Grubu başlığı. | [optional] 

### Return type

[**SWGOptionGroup***](SWGOptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **optionGroupsIdDelete**
```objc
-(NSURLSessionTask*) optionGroupsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Varyant Grubu Silme

Kalıcı olarak ilgili Varyant Grubunu siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Varyant Grubu nesnesinin id değeri

SWGOptionGroupApi*apiInstance = [[SWGOptionGroupApi alloc] init];

// Varyant Grubu Silme
[apiInstance optionGroupsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGOptionGroupApi->optionGroupsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Varyant Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **optionGroupsIdGet**
```objc
-(NSURLSessionTask*) optionGroupsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGOptionGroup* output, NSError* error)) handler;
```

Varyant Grubu Alma

İlgili Varyant Grubunu getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Varyant Grubu nesnesinin id değeri

SWGOptionGroupApi*apiInstance = [[SWGOptionGroupApi alloc] init];

// Varyant Grubu Alma
[apiInstance optionGroupsIdGetWithId:_id
          completionHandler: ^(SWGOptionGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOptionGroupApi->optionGroupsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Varyant Grubu nesnesinin id değeri | 

### Return type

[**SWGOptionGroup***](SWGOptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **optionGroupsIdPut**
```objc
-(NSURLSessionTask*) optionGroupsIdPutWithId: (NSNumber*) _id
    optionGroup: (SWGOptionGroup*) optionGroup
        completionHandler: (void (^)(SWGOptionGroup* output, NSError* error)) handler;
```

Varyant Grubu Güncelleme

İlgili Varyant Grubunu günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Varyant Grubu nesnesinin id değeri
SWGOptionGroup* optionGroup = [[SWGOptionGroup alloc] init]; //  nesnesi

SWGOptionGroupApi*apiInstance = [[SWGOptionGroupApi alloc] init];

// Varyant Grubu Güncelleme
[apiInstance optionGroupsIdPutWithId:_id
              optionGroup:optionGroup
          completionHandler: ^(SWGOptionGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOptionGroupApi->optionGroupsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Varyant Grubu nesnesinin id değeri | 
 **optionGroup** | [**SWGOptionGroup***](SWGOptionGroup.md)|  nesnesi | 

### Return type

[**SWGOptionGroup***](SWGOptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **optionGroupsPost**
```objc
-(NSURLSessionTask*) optionGroupsPostWithOptionGroup: (SWGOptionGroup*) optionGroup
        completionHandler: (void (^)(SWGOptionGroup* output, NSError* error)) handler;
```

Varyant Grubu Oluşturma

Yeni bir Varyant Grubu oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGOptionGroup* optionGroup = [[SWGOptionGroup alloc] init]; //  nesnesi

SWGOptionGroupApi*apiInstance = [[SWGOptionGroupApi alloc] init];

// Varyant Grubu Oluşturma
[apiInstance optionGroupsPostWithOptionGroup:optionGroup
          completionHandler: ^(SWGOptionGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOptionGroupApi->optionGroupsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **optionGroup** | [**SWGOptionGroup***](SWGOptionGroup.md)|  nesnesi | 

### Return type

[**SWGOptionGroup***](SWGOptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

