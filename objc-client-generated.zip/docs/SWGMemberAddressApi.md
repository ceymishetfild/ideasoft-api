# SWGMemberAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**memberAddressesGet**](SWGMemberAddressApi.md#memberaddressesget) | **GET** /member_addresses | Üye Adresi Listeleme
[**memberAddressesIdDelete**](SWGMemberAddressApi.md#memberaddressesiddelete) | **DELETE** /member_addresses/{id} | Üye Adresi Silme
[**memberAddressesIdGet**](SWGMemberAddressApi.md#memberaddressesidget) | **GET** /member_addresses/{id} | Üye Adresi Alma
[**memberAddressesIdPut**](SWGMemberAddressApi.md#memberaddressesidput) | **PUT** /member_addresses/{id} | Üye Adresi Güncelleme
[**memberAddressesPost**](SWGMemberAddressApi.md#memberaddressespost) | **POST** /member_addresses | Üye Adresi Oluşturma


# **memberAddressesGet**
```objc
-(NSURLSessionTask*) memberAddressesGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    member: (NSNumber*) member
    startDate: (NSDate*) startDate
    endDate: (NSString*) endDate
        completionHandler: (void (^)(SWGMemberAddress* output, NSError* error)) handler;
```

Üye Adresi Listeleme

Üye Adresi listesi verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSNumber* member = @56; // Üye id (optional)
NSDate* startDate = @"2013-10-20"; // createdAt değeri için başlangıç tarihi (optional)
NSString* endDate = @"endDate_example"; // createdAt değeri için bitiş tarihi (optional)

SWGMemberAddressApi*apiInstance = [[SWGMemberAddressApi alloc] init];

// Üye Adresi Listeleme
[apiInstance memberAddressesGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              member:member
              startDate:startDate
              endDate:endDate
          completionHandler: ^(SWGMemberAddress* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMemberAddressApi->memberAddressesGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **member** | **NSNumber***| Üye id | [optional] 
 **startDate** | **NSDate***| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **NSString***| createdAt değeri için bitiş tarihi | [optional] 

### Return type

[**SWGMemberAddress***](SWGMemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **memberAddressesIdDelete**
```objc
-(NSURLSessionTask*) memberAddressesIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Üye Adresi Silme

Kalıcı olarak ilgili Üye Adresini siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Üye Adresi nesnesinin id değeri

SWGMemberAddressApi*apiInstance = [[SWGMemberAddressApi alloc] init];

// Üye Adresi Silme
[apiInstance memberAddressesIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGMemberAddressApi->memberAddressesIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Üye Adresi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **memberAddressesIdGet**
```objc
-(NSURLSessionTask*) memberAddressesIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGMemberAddress* output, NSError* error)) handler;
```

Üye Adresi Alma

İlgili Üye Adresini getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Üye Adresi nesnesinin id değeri

SWGMemberAddressApi*apiInstance = [[SWGMemberAddressApi alloc] init];

// Üye Adresi Alma
[apiInstance memberAddressesIdGetWithId:_id
          completionHandler: ^(SWGMemberAddress* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMemberAddressApi->memberAddressesIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Üye Adresi nesnesinin id değeri | 

### Return type

[**SWGMemberAddress***](SWGMemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **memberAddressesIdPut**
```objc
-(NSURLSessionTask*) memberAddressesIdPutWithId: (NSNumber*) _id
    memberAddress: (SWGMemberAddress*) memberAddress
        completionHandler: (void (^)(SWGMemberAddress* output, NSError* error)) handler;
```

Üye Adresi Güncelleme

İlgili Üye Adresini günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Üye Adresi nesnesinin id değeri
SWGMemberAddress* memberAddress = [[SWGMemberAddress alloc] init]; //  nesnesi

SWGMemberAddressApi*apiInstance = [[SWGMemberAddressApi alloc] init];

// Üye Adresi Güncelleme
[apiInstance memberAddressesIdPutWithId:_id
              memberAddress:memberAddress
          completionHandler: ^(SWGMemberAddress* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMemberAddressApi->memberAddressesIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Üye Adresi nesnesinin id değeri | 
 **memberAddress** | [**SWGMemberAddress***](SWGMemberAddress.md)|  nesnesi | 

### Return type

[**SWGMemberAddress***](SWGMemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **memberAddressesPost**
```objc
-(NSURLSessionTask*) memberAddressesPostWithMemberAddress: (SWGMemberAddress*) memberAddress
        completionHandler: (void (^)(SWGMemberAddress* output, NSError* error)) handler;
```

Üye Adresi Oluşturma

Yeni bir Üye Adresi oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGMemberAddress* memberAddress = [[SWGMemberAddress alloc] init]; //  nesnesi

SWGMemberAddressApi*apiInstance = [[SWGMemberAddressApi alloc] init];

// Üye Adresi Oluşturma
[apiInstance memberAddressesPostWithMemberAddress:memberAddress
          completionHandler: ^(SWGMemberAddress* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGMemberAddressApi->memberAddressesPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **memberAddress** | [**SWGMemberAddress***](SWGMemberAddress.md)|  nesnesi | 

### Return type

[**SWGMemberAddress***](SWGMemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

