# SWGAsset

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **NSString*** | Tema Dosyası nesnesi anahtar değeri. | [optional] 
**contentType** | **NSString*** | Tema Dosyası içerik tipi. Geçerli bir MIME Content-Type verilmelidir. | [optional] 
**attachment** | **NSString*** | Tema Dosyası içeriği. | [optional] 
**createdAt** | **NSDate*** | Tema Dosyası nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **NSDate*** | Tema Dosyası nesnesinin güncellenme zamanı. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


