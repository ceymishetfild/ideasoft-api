# SWGCurrentAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Cari hesap nesnesi kimlik değeri. | [optional] 
**code** | **NSString*** | Cari hesap için düzenlenebilir bir kod değeri. | [optional] 
**title** | **NSString*** | Cari hesap nesnesinin başlığı. | 
**balance** | **NSNumber*** | Cari hesabın bakiyesi. | [optional] 
**riskLimit** | **NSNumber*** | Cari hesap için belirlenmiş risk limiti. | [optional] 
**createdAt** | **NSDate*** | Cari hesap nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **NSDate*** | Cari hesap nesnesinin güncellenme zamanı. | [optional] 
**member** | [**SWGMember***](SWGMember.md) | Üye nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


