# SWGTownGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**townGroupsGet**](SWGTownGroupApi.md#towngroupsget) | **GET** /town_groups | İlçe Grubu Listesi Alma
[**townGroupsIdDelete**](SWGTownGroupApi.md#towngroupsiddelete) | **DELETE** /town_groups/{id} | İlçe Grubu Silme
[**townGroupsIdGet**](SWGTownGroupApi.md#towngroupsidget) | **GET** /town_groups/{id} | İlçe Grubu Alma
[**townGroupsIdPut**](SWGTownGroupApi.md#towngroupsidput) | **PUT** /town_groups/{id} | İlçe Grubu Güncelleme
[**townGroupsPost**](SWGTownGroupApi.md#towngroupspost) | **POST** /town_groups | İlçe Grubu Oluşturma


# **townGroupsGet**
```objc
-(NSURLSessionTask*) townGroupsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    name: (NSString*) name
        completionHandler: (void (^)(SWGTownGroup* output, NSError* error)) handler;
```

İlçe Grubu Listesi Alma

İlçe Grubu listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* name = @"name_example"; // İlçe Grubu adı (optional)

SWGTownGroupApi*apiInstance = [[SWGTownGroupApi alloc] init];

// İlçe Grubu Listesi Alma
[apiInstance townGroupsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              name:name
          completionHandler: ^(SWGTownGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGTownGroupApi->townGroupsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **NSString***| İlçe Grubu adı | [optional] 

### Return type

[**SWGTownGroup***](SWGTownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **townGroupsIdDelete**
```objc
-(NSURLSessionTask*) townGroupsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

İlçe Grubu Silme

Kalıcı olarak ilgili İlçe Grubunu siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // İlçe Grubu nesnesinin id değeri

SWGTownGroupApi*apiInstance = [[SWGTownGroupApi alloc] init];

// İlçe Grubu Silme
[apiInstance townGroupsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGTownGroupApi->townGroupsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| İlçe Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **townGroupsIdGet**
```objc
-(NSURLSessionTask*) townGroupsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGTownGroup* output, NSError* error)) handler;
```

İlçe Grubu Alma

İlgili İlçe Grubunu getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // İlçe Grubu nesnesinin id değeri

SWGTownGroupApi*apiInstance = [[SWGTownGroupApi alloc] init];

// İlçe Grubu Alma
[apiInstance townGroupsIdGetWithId:_id
          completionHandler: ^(SWGTownGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGTownGroupApi->townGroupsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| İlçe Grubu nesnesinin id değeri | 

### Return type

[**SWGTownGroup***](SWGTownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **townGroupsIdPut**
```objc
-(NSURLSessionTask*) townGroupsIdPutWithId: (NSNumber*) _id
    townGroup: (SWGTownGroup*) townGroup
        completionHandler: (void (^)(SWGTownGroup* output, NSError* error)) handler;
```

İlçe Grubu Güncelleme

İlgili İlçe Grubunu günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // İlçe Grubu nesnesinin id değeri
SWGTownGroup* townGroup = [[SWGTownGroup alloc] init]; //  nesnesi

SWGTownGroupApi*apiInstance = [[SWGTownGroupApi alloc] init];

// İlçe Grubu Güncelleme
[apiInstance townGroupsIdPutWithId:_id
              townGroup:townGroup
          completionHandler: ^(SWGTownGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGTownGroupApi->townGroupsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| İlçe Grubu nesnesinin id değeri | 
 **townGroup** | [**SWGTownGroup***](SWGTownGroup.md)|  nesnesi | 

### Return type

[**SWGTownGroup***](SWGTownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **townGroupsPost**
```objc
-(NSURLSessionTask*) townGroupsPostWithTownGroup: (SWGTownGroup*) townGroup
        completionHandler: (void (^)(SWGTownGroup* output, NSError* error)) handler;
```

İlçe Grubu Oluşturma

Yeni bir İlçe Grubu oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGTownGroup* townGroup = [[SWGTownGroup alloc] init]; //  nesnesi

SWGTownGroupApi*apiInstance = [[SWGTownGroupApi alloc] init];

// İlçe Grubu Oluşturma
[apiInstance townGroupsPostWithTownGroup:townGroup
          completionHandler: ^(SWGTownGroup* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGTownGroupApi->townGroupsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **townGroup** | [**SWGTownGroup***](SWGTownGroup.md)|  nesnesi | 

### Return type

[**SWGTownGroup***](SWGTownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

