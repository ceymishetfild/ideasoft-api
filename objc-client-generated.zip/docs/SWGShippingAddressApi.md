# SWGShippingAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shippingAddressesGet**](SWGShippingAddressApi.md#shippingaddressesget) | **GET** /shipping_addresses | Teslimat Adresi Listesi Alma
[**shippingAddressesIdGet**](SWGShippingAddressApi.md#shippingaddressesidget) | **GET** /shipping_addresses/{id} | Teslimat Adresi Alma
[**shippingAddressesIdPut**](SWGShippingAddressApi.md#shippingaddressesidput) | **PUT** /shipping_addresses/{id} | Teslimat Adresi Güncelleme
[**shippingAddressesPost**](SWGShippingAddressApi.md#shippingaddressespost) | **POST** /shipping_addresses | Teslimat Adresi Oluşturma


# **shippingAddressesGet**
```objc
-(NSURLSessionTask*) shippingAddressesGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    order: (NSNumber*) order
    startDate: (NSDate*) startDate
    endDate: (NSString*) endDate
    startUpdatedAt: (NSDate*) startUpdatedAt
    endUpdatedAt: (NSString*) endUpdatedAt
        completionHandler: (void (^)(SWGShippingAddress* output, NSError* error)) handler;
```

Teslimat Adresi Listesi Alma

Teslimat Adresi listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSNumber* order = @56; // Sipariş id (optional)
NSDate* startDate = @"2013-10-20"; // createdAt değeri için başlangıç tarihi (optional)
NSString* endDate = @"endDate_example"; // createdAt değeri için bitiş tarihi (optional)
NSDate* startUpdatedAt = @"2013-10-20"; // updatedAt değeri için başlangıç tarihi (optional)
NSString* endUpdatedAt = @"endUpdatedAt_example"; // updatedAt değeri için bitiş tarihi (optional)

SWGShippingAddressApi*apiInstance = [[SWGShippingAddressApi alloc] init];

// Teslimat Adresi Listesi Alma
[apiInstance shippingAddressesGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              order:order
              startDate:startDate
              endDate:endDate
              startUpdatedAt:startUpdatedAt
              endUpdatedAt:endUpdatedAt
          completionHandler: ^(SWGShippingAddress* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGShippingAddressApi->shippingAddressesGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **order** | **NSNumber***| Sipariş id | [optional] 
 **startDate** | **NSDate***| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **NSString***| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **NSDate***| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **NSString***| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**SWGShippingAddress***](SWGShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shippingAddressesIdGet**
```objc
-(NSURLSessionTask*) shippingAddressesIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGShippingAddress* output, NSError* error)) handler;
```

Teslimat Adresi Alma

İlgili Teslimat Adresi getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Teslimat Adresi nesnesinin id değeri

SWGShippingAddressApi*apiInstance = [[SWGShippingAddressApi alloc] init];

// Teslimat Adresi Alma
[apiInstance shippingAddressesIdGetWithId:_id
          completionHandler: ^(SWGShippingAddress* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGShippingAddressApi->shippingAddressesIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Teslimat Adresi nesnesinin id değeri | 

### Return type

[**SWGShippingAddress***](SWGShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shippingAddressesIdPut**
```objc
-(NSURLSessionTask*) shippingAddressesIdPutWithId: (NSNumber*) _id
    shippingAddress: (SWGShippingAddress*) shippingAddress
        completionHandler: (void (^)(SWGShippingAddress* output, NSError* error)) handler;
```

Teslimat Adresi Güncelleme

İlgili Teslimat Adresi günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Teslimat Adresi nesnesinin id değeri
SWGShippingAddress* shippingAddress = [[SWGShippingAddress alloc] init]; //  nesnesi

SWGShippingAddressApi*apiInstance = [[SWGShippingAddressApi alloc] init];

// Teslimat Adresi Güncelleme
[apiInstance shippingAddressesIdPutWithId:_id
              shippingAddress:shippingAddress
          completionHandler: ^(SWGShippingAddress* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGShippingAddressApi->shippingAddressesIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Teslimat Adresi nesnesinin id değeri | 
 **shippingAddress** | [**SWGShippingAddress***](SWGShippingAddress.md)|  nesnesi | 

### Return type

[**SWGShippingAddress***](SWGShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shippingAddressesPost**
```objc
-(NSURLSessionTask*) shippingAddressesPostWithShippingAddress: (SWGShippingAddress*) shippingAddress
        completionHandler: (void (^)(SWGShippingAddress* output, NSError* error)) handler;
```

Teslimat Adresi Oluşturma

Yeni bir Teslimat Adresi oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGShippingAddress* shippingAddress = [[SWGShippingAddress alloc] init]; //  nesnesi

SWGShippingAddressApi*apiInstance = [[SWGShippingAddressApi alloc] init];

// Teslimat Adresi Oluşturma
[apiInstance shippingAddressesPostWithShippingAddress:shippingAddress
          completionHandler: ^(SWGShippingAddress* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGShippingAddressApi->shippingAddressesPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shippingAddress** | [**SWGShippingAddress***](SWGShippingAddress.md)|  nesnesi | 

### Return type

[**SWGShippingAddress***](SWGShippingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

