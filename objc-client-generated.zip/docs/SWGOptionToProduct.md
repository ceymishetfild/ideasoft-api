# SWGOptionToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Varyant ürün bağı nesnesi kimlik değeri. | [optional] 
**parentProductId** | **NSNumber*** | Ana ürünün benzersiz kimlik değeri. | 
**optionGroup** | [**SWGOptionGroup***](SWGOptionGroup.md) | Varyant grubu nesnesi. | 
**option** | [**SWGOptions***](SWGOptions.md) | Varyant nesnesi. | 
**product** | [**SWGProduct***](SWGProduct.md) | Ürün nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


