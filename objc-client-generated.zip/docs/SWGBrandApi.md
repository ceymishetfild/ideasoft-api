# SWGBrandApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**brandsGet**](SWGBrandApi.md#brandsget) | **GET** /brands | Marka Listesi Alma
[**brandsIdDelete**](SWGBrandApi.md#brandsiddelete) | **DELETE** /brands/{id} | Marka Silme
[**brandsIdGet**](SWGBrandApi.md#brandsidget) | **GET** /brands/{id} | Marka Alma
[**brandsIdPut**](SWGBrandApi.md#brandsidput) | **PUT** /brands/{id} | Marka Güncelleme
[**brandsPost**](SWGBrandApi.md#brandspost) | **POST** /brands | Marka Oluşturma


# **brandsGet**
```objc
-(NSURLSessionTask*) brandsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    name: (NSString*) name
    status: (NSString*) status
    distributor: (NSString*) distributor
    startDate: (NSDate*) startDate
    endDate: (NSString*) endDate
    startUpdatedAt: (NSDate*) startUpdatedAt
    endUpdatedAt: (NSString*) endUpdatedAt
    q: (NSArray<NSString*>*) q
        completionHandler: (void (^)(SWGBrand* output, NSError* error)) handler;
```

Marka Listesi Alma

Marka listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* name = @"name_example"; // Marka adı. (optional)
NSString* status = @"status_example"; // Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif (optional)
NSString* distributor = @"distributor_example"; // Marka distribörü (optional)
NSDate* startDate = @"2013-10-20"; // createdAt değeri için başlangıç tarihi (optional)
NSString* endDate = @"endDate_example"; // createdAt değeri için bitiş tarihi (optional)
NSDate* startUpdatedAt = @"2013-10-20"; // updatedAt değeri için başlangıç tarihi (optional)
NSString* endUpdatedAt = @"endUpdatedAt_example"; // updatedAt değeri için bitiş tarihi (optional)
NSArray<NSString*>* q = @[@"q_example"]; // Marka arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;] (optional)

SWGBrandApi*apiInstance = [[SWGBrandApi alloc] init];

// Marka Listesi Alma
[apiInstance brandsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              name:name
              status:status
              distributor:distributor
              startDate:startDate
              endDate:endDate
              startUpdatedAt:startUpdatedAt
              endUpdatedAt:endUpdatedAt
              q:q
          completionHandler: ^(SWGBrand* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGBrandApi->brandsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **NSString***| Marka adı. | [optional] 
 **status** | **NSString***| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **distributor** | **NSString***| Marka distribörü | [optional] 
 **startDate** | **NSDate***| createdAt değeri için başlangıç tarihi | [optional] 
 **endDate** | **NSString***| createdAt değeri için bitiş tarihi | [optional] 
 **startUpdatedAt** | **NSDate***| updatedAt değeri için başlangıç tarihi | [optional] 
 **endUpdatedAt** | **NSString***| updatedAt değeri için bitiş tarihi | [optional] 
 **q** | [**NSArray&lt;NSString*&gt;***](NSString*.md)| Marka arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 

### Return type

[**SWGBrand***](SWGBrand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **brandsIdDelete**
```objc
-(NSURLSessionTask*) brandsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Marka Silme

Kalıcı olarak ilgili Markayı siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Marka nesnesinin id değeri

SWGBrandApi*apiInstance = [[SWGBrandApi alloc] init];

// Marka Silme
[apiInstance brandsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGBrandApi->brandsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Marka nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **brandsIdGet**
```objc
-(NSURLSessionTask*) brandsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGBrand* output, NSError* error)) handler;
```

Marka Alma

İlgili Markayı getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Marka nesnesinin id değeri

SWGBrandApi*apiInstance = [[SWGBrandApi alloc] init];

// Marka Alma
[apiInstance brandsIdGetWithId:_id
          completionHandler: ^(SWGBrand* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGBrandApi->brandsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Marka nesnesinin id değeri | 

### Return type

[**SWGBrand***](SWGBrand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **brandsIdPut**
```objc
-(NSURLSessionTask*) brandsIdPutWithId: (NSNumber*) _id
    brand: (SWGBrand*) brand
        completionHandler: (void (^)(SWGBrand* output, NSError* error)) handler;
```

Marka Güncelleme

İlgili Markayı günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Marka nesnesinin id değeri
SWGBrand* brand = [[SWGBrand alloc] init]; //  nesnesi

SWGBrandApi*apiInstance = [[SWGBrandApi alloc] init];

// Marka Güncelleme
[apiInstance brandsIdPutWithId:_id
              brand:brand
          completionHandler: ^(SWGBrand* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGBrandApi->brandsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Marka nesnesinin id değeri | 
 **brand** | [**SWGBrand***](SWGBrand.md)|  nesnesi | 

### Return type

[**SWGBrand***](SWGBrand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **brandsPost**
```objc
-(NSURLSessionTask*) brandsPostWithBrand: (SWGBrand*) brand
        completionHandler: (void (^)(SWGBrand* output, NSError* error)) handler;
```

Marka Oluşturma

Yeni bir Marka oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGBrand* brand = [[SWGBrand alloc] init]; //  nesnesi

SWGBrandApi*apiInstance = [[SWGBrandApi alloc] init];

// Marka Oluşturma
[apiInstance brandsPostWithBrand:brand
          completionHandler: ^(SWGBrand* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGBrandApi->brandsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **brand** | [**SWGBrand***](SWGBrand.md)|  nesnesi | 

### Return type

[**SWGBrand***](SWGBrand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

