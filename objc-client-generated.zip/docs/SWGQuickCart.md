# SWGQuickCart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Hızlı satın al bağlantısı nesnesi kimlik değeri. | [optional] 
**name** | **NSString*** | Hızlı satın al bağlantısı nesnesi için isim değeri. | 
**url** | **NSString*** | Hızlı satın al bağlantısı url&#39;si. | 
**shortUrl** | **NSString*** | Hızlı satın al bağlantısı için kısaltılmış url. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


