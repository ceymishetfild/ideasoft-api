# SWGExtraInfoToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extraInfoToProductsGet**](SWGExtraInfoToProductApi.md#extrainfotoproductsget) | **GET** /extra_info_to_products | Ek Bilgi Ürün Bağı Listesi Alma
[**extraInfoToProductsIdDelete**](SWGExtraInfoToProductApi.md#extrainfotoproductsiddelete) | **DELETE** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Silme
[**extraInfoToProductsIdGet**](SWGExtraInfoToProductApi.md#extrainfotoproductsidget) | **GET** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Alma
[**extraInfoToProductsIdPut**](SWGExtraInfoToProductApi.md#extrainfotoproductsidput) | **PUT** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Güncelleme
[**extraInfoToProductsPost**](SWGExtraInfoToProductApi.md#extrainfotoproductspost) | **POST** /extra_info_to_products | Ek Bilgi Ürün Bağı Oluşturma


# **extraInfoToProductsGet**
```objc
-(NSURLSessionTask*) extraInfoToProductsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    extraInfo: (NSNumber*) extraInfo
    product: (NSNumber*) product
        completionHandler: (void (^)(SWGExtraInfoToProduct* output, NSError* error)) handler;
```

Ek Bilgi Ürün Bağı Listesi Alma

Ek Bilgi Ürün Bağı listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSNumber* extraInfo = @56; // Ek bilgi id (optional)
NSNumber* product = @56; // Ürün id (optional)

SWGExtraInfoToProductApi*apiInstance = [[SWGExtraInfoToProductApi alloc] init];

// Ek Bilgi Ürün Bağı Listesi Alma
[apiInstance extraInfoToProductsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              extraInfo:extraInfo
              product:product
          completionHandler: ^(SWGExtraInfoToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGExtraInfoToProductApi->extraInfoToProductsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **extraInfo** | **NSNumber***| Ek bilgi id | [optional] 
 **product** | **NSNumber***| Ürün id | [optional] 

### Return type

[**SWGExtraInfoToProduct***](SWGExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extraInfoToProductsIdDelete**
```objc
-(NSURLSessionTask*) extraInfoToProductsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Ek Bilgi Ürün Bağı Silme

Kalıcı olarak ilgili Ek Bilgi Ürün Bağını siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ek Bilgi Ürün Bağı nesnesinin id değeri

SWGExtraInfoToProductApi*apiInstance = [[SWGExtraInfoToProductApi alloc] init];

// Ek Bilgi Ürün Bağı Silme
[apiInstance extraInfoToProductsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGExtraInfoToProductApi->extraInfoToProductsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ek Bilgi Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extraInfoToProductsIdGet**
```objc
-(NSURLSessionTask*) extraInfoToProductsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGExtraInfoToProduct* output, NSError* error)) handler;
```

Ek Bilgi Ürün Bağı Alma

İlgili Ek Bilgi Ürün Bağını getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ek Bilgi Ürün Bağı nesnesinin id değeri

SWGExtraInfoToProductApi*apiInstance = [[SWGExtraInfoToProductApi alloc] init];

// Ek Bilgi Ürün Bağı Alma
[apiInstance extraInfoToProductsIdGetWithId:_id
          completionHandler: ^(SWGExtraInfoToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGExtraInfoToProductApi->extraInfoToProductsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ek Bilgi Ürün Bağı nesnesinin id değeri | 

### Return type

[**SWGExtraInfoToProduct***](SWGExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extraInfoToProductsIdPut**
```objc
-(NSURLSessionTask*) extraInfoToProductsIdPutWithId: (NSNumber*) _id
    extraInfoToProduct: (SWGExtraInfoToProduct*) extraInfoToProduct
        completionHandler: (void (^)(SWGExtraInfoToProduct* output, NSError* error)) handler;
```

Ek Bilgi Ürün Bağı Güncelleme

İlgili Ek Bilgi Ürün Bağını günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ek Bilgi Ürün Bağı nesnesinin id değeri
SWGExtraInfoToProduct* extraInfoToProduct = [[SWGExtraInfoToProduct alloc] init]; //  nesnesi

SWGExtraInfoToProductApi*apiInstance = [[SWGExtraInfoToProductApi alloc] init];

// Ek Bilgi Ürün Bağı Güncelleme
[apiInstance extraInfoToProductsIdPutWithId:_id
              extraInfoToProduct:extraInfoToProduct
          completionHandler: ^(SWGExtraInfoToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGExtraInfoToProductApi->extraInfoToProductsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ek Bilgi Ürün Bağı nesnesinin id değeri | 
 **extraInfoToProduct** | [**SWGExtraInfoToProduct***](SWGExtraInfoToProduct.md)|  nesnesi | 

### Return type

[**SWGExtraInfoToProduct***](SWGExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extraInfoToProductsPost**
```objc
-(NSURLSessionTask*) extraInfoToProductsPostWithExtraInfoToProduct: (SWGExtraInfoToProduct*) extraInfoToProduct
        completionHandler: (void (^)(SWGExtraInfoToProduct* output, NSError* error)) handler;
```

Ek Bilgi Ürün Bağı Oluşturma

Yeni bir Ek Bilgi Ürün Bağı oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGExtraInfoToProduct* extraInfoToProduct = [[SWGExtraInfoToProduct alloc] init]; //  nesnesi

SWGExtraInfoToProductApi*apiInstance = [[SWGExtraInfoToProductApi alloc] init];

// Ek Bilgi Ürün Bağı Oluşturma
[apiInstance extraInfoToProductsPostWithExtraInfoToProduct:extraInfoToProduct
          completionHandler: ^(SWGExtraInfoToProduct* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGExtraInfoToProductApi->extraInfoToProductsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extraInfoToProduct** | [**SWGExtraInfoToProduct***](SWGExtraInfoToProduct.md)|  nesnesi | 

### Return type

[**SWGExtraInfoToProduct***](SWGExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

