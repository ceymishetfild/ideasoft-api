# SWGOrderItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Sipariş kalemi nesnesi kimlik değeri. | [optional] 
**productName** | **NSString*** | Ürünün adı. | 
**productSku** | **NSString*** | Ürünün stok kodu. | 
**productBarcode** | **NSString*** | Ürünün barkodu. | [optional] 
**productPrice** | **NSNumber*** | Ürünün fiyatı. | 
**productCurrency** | **NSString*** | Ürünün kuru. | 
**productQuantity** | **NSNumber*** | Ürünün stok tipi cinsinden miktarı. | 
**productTax** | **NSNumber*** | Ürünün vergisi | 
**productDiscount** | **NSNumber*** | Ürünün standart indirim değeri. | 
**productMoneyOrderDiscount** | **NSNumber*** | Ürünün havale indirim değeri. | 
**productWeight** | **NSNumber*** | Ürünün ağırlığı. | 
**productStockTypeLabel** | **NSString*** | Ürünün stok tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Adet&lt;/code&gt; : Stok tipi birimi Adet&lt;br&gt;&lt;code&gt;cm&lt;/code&gt; : Stok tipi birimi Santimetre&lt;br&gt;&lt;code&gt;Düzine&lt;/code&gt; : Stok tipi birimi Düzine&lt;br&gt;&lt;code&gt;gram&lt;/code&gt; : Stok tipi birimi Gram&lt;br&gt;&lt;code&gt;kg&lt;/code&gt; : Stok tipi birimi Kilogram&lt;br&gt;&lt;code&gt;Kişi&lt;/code&gt; : Stok tipi birimi Kişi&lt;br&gt;&lt;code&gt;Paket&lt;/code&gt; : Stok tipi birimi Paket&lt;br&gt;&lt;code&gt;metre&lt;/code&gt; : Stok tipi birimi Metre&lt;br&gt;&lt;code&gt;m2&lt;/code&gt; : Stok tipi birimi Metre kare&lt;br&gt;&lt;code&gt;Çift&lt;/code&gt; : Stok tipi birimi Çift&lt;br&gt;&lt;/div&gt; | 
**isProductPromotioned** | **NSString*** | Ürünün promosyon olup olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;0&lt;/code&gt; : Ürün promosyon değil.&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Ürün promosyon.&lt;br&gt;&lt;/div&gt; | [optional] 
**discount** | **NSNumber*** | Ürünün hediye çeki indirim değeri. | 
**order** | [**SWGOrder***](SWGOrder.md) | Sipariş nesnesi. | [optional] 
**product** | [**SWGProduct***](SWGProduct.md) | Ürün nesnesi. | [optional] 
**orderItemSubscription** | [**SWGOrderItemSubscription***](SWGOrderItemSubscription.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


