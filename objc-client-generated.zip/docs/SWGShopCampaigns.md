# SWGShopCampaigns

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Promosyon nesnesi kimlik değeri. | [optional] 
**label** | **NSString*** | Promosyon adı. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


