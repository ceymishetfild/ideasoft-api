# SWGSpecNameApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**specNamesGet**](SWGSpecNameApi.md#specnamesget) | **GET** /spec_names | Ürün Özelliği Listesi Alma
[**specNamesIdDelete**](SWGSpecNameApi.md#specnamesiddelete) | **DELETE** /spec_names/{id} | Ürün Özelliği Silme
[**specNamesIdGet**](SWGSpecNameApi.md#specnamesidget) | **GET** /spec_names/{id} | Ürün Özelliği Alma
[**specNamesIdPut**](SWGSpecNameApi.md#specnamesidput) | **PUT** /spec_names/{id} | Ürün Özelliği Güncelleme
[**specNamesPost**](SWGSpecNameApi.md#specnamespost) | **POST** /spec_names | Ürün Özelliği Oluşturma


# **specNamesGet**
```objc
-(NSURLSessionTask*) specNamesGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    name: (NSString*) name
    specGroup: (NSNumber*) specGroup
    choiceType: (NSString*) choiceType
        completionHandler: (void (^)(SWGSpecName* output, NSError* error)) handler;
```

Ürün Özelliği Listesi Alma

Ürün Özelliği listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* name = @"name_example"; // Ürün Özelliği adı (optional)
NSNumber* specGroup = @56; // Ürün özellik grubu id (optional)
NSString* choiceType = @"choiceType_example"; // Status şu değerleri alabilir: <br><code>singular</code> : Tekil<br><code>plural</code> : Çoğul (optional)

SWGSpecNameApi*apiInstance = [[SWGSpecNameApi alloc] init];

// Ürün Özelliği Listesi Alma
[apiInstance specNamesGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              name:name
              specGroup:specGroup
              choiceType:choiceType
          completionHandler: ^(SWGSpecName* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecNameApi->specNamesGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **NSString***| Ürün Özelliği adı | [optional] 
 **specGroup** | **NSNumber***| Ürün özellik grubu id | [optional] 
 **choiceType** | **NSString***| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul | [optional] 

### Return type

[**SWGSpecName***](SWGSpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specNamesIdDelete**
```objc
-(NSURLSessionTask*) specNamesIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Ürün Özelliği Silme

Kalıcı olarak ilgili Ürün Özelliğini siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Özellik nesnesinin id değeri

SWGSpecNameApi*apiInstance = [[SWGSpecNameApi alloc] init];

// Ürün Özelliği Silme
[apiInstance specNamesIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGSpecNameApi->specNamesIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Özellik nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specNamesIdGet**
```objc
-(NSURLSessionTask*) specNamesIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGSpecName* output, NSError* error)) handler;
```

Ürün Özelliği Alma

İlgili Ürün Özelliğini getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Özellik nesnesinin id değeri

SWGSpecNameApi*apiInstance = [[SWGSpecNameApi alloc] init];

// Ürün Özelliği Alma
[apiInstance specNamesIdGetWithId:_id
          completionHandler: ^(SWGSpecName* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecNameApi->specNamesIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Özellik nesnesinin id değeri | 

### Return type

[**SWGSpecName***](SWGSpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specNamesIdPut**
```objc
-(NSURLSessionTask*) specNamesIdPutWithId: (NSNumber*) _id
    specName: (SWGSpecName*) specName
        completionHandler: (void (^)(SWGSpecName* output, NSError* error)) handler;
```

Ürün Özelliği Güncelleme

İlgili Ürün Özelliğini günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Özellik nesnesinin id değeri
SWGSpecName* specName = [[SWGSpecName alloc] init]; //  nesnesi

SWGSpecNameApi*apiInstance = [[SWGSpecNameApi alloc] init];

// Ürün Özelliği Güncelleme
[apiInstance specNamesIdPutWithId:_id
              specName:specName
          completionHandler: ^(SWGSpecName* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecNameApi->specNamesIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Özellik nesnesinin id değeri | 
 **specName** | [**SWGSpecName***](SWGSpecName.md)|  nesnesi | 

### Return type

[**SWGSpecName***](SWGSpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **specNamesPost**
```objc
-(NSURLSessionTask*) specNamesPostWithSpecName: (SWGSpecName*) specName
        completionHandler: (void (^)(SWGSpecName* output, NSError* error)) handler;
```

Ürün Özelliği Oluşturma

Yeni bir Ürün Özelliği oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGSpecName* specName = [[SWGSpecName alloc] init]; //  nesnesi

SWGSpecNameApi*apiInstance = [[SWGSpecNameApi alloc] init];

// Ürün Özelliği Oluşturma
[apiInstance specNamesPostWithSpecName:specName
          completionHandler: ^(SWGSpecName* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGSpecNameApi->specNamesPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **specName** | [**SWGSpecName***](SWGSpecName.md)|  nesnesi | 

### Return type

[**SWGSpecName***](SWGSpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

