# SWGPreOrderInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Sipariş öncesi bilgisi nesnesi kimlik değeri. | [optional] 
**sessionId** | **NSString*** | Üyenin son giriş yapma durumunu belirten benzersiz kimlik değeri. | 
**customerFirstname** | **NSString*** | Müşterinin ismi. | [optional] 
**customerSurname** | **NSString*** | Müşterinin soy ismi. | [optional] 
**customerEmail** | **NSString*** | Müşterinin e-mail adresi. | [optional] 
**shippingFirstname** | **NSString*** | Teslimat yapılacak kişinin ismi. | 
**shippingSurname** | **NSString*** | Teslimat yapılacak kişinin soy ismi. | 
**shippingAddress** | **NSString*** | Teslimat adresi bilgileri. | 
**shippingPhoneNumber** | **NSString*** | Teslimat yapılacak kişinin telefon numarası. | 
**shippingMobilePhoneNumber** | **NSString*** | Teslimat yapılacak kişinin mobil telefon numarası. | 
**shippingLocationName** | **NSString*** | Teslimat şehri. | 
**shippingTown** | **NSString*** | Teslimat ilçesi. | 
**differentBillingAddress** | **NSString*** | Teslimat adresinden farklı bir fatura adresi oluğ olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Var&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yok&lt;br&gt;&lt;/div&gt; | [optional] 
**billingFirstname** | **NSString*** | Fatura kesilen kişinin ismi. | 
**billingSurname** | **NSString*** | Fatura kesilen kişinin soy ismi. | 
**billingAddress** | **NSString*** | Fatura adresi bilgileri. | 
**billingPhoneNumber** | **NSString*** | Fatura kesilen kişinin telefon numarası. | 
**billingMobilePhoneNumber** | **NSString*** | Fatura kesilen kişinin mobil telefon numarası. | 
**billingLocationName** | **NSString*** | Fatura adresi şehri | 
**billingTown** | **NSString*** | Fatura adresi ilçesi. | 
**billingInvoiceType** | **NSString*** | Fatura tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;individual&lt;/code&gt; : Bireysel&lt;br&gt;&lt;code&gt;corporate&lt;/code&gt; : Kurumsal&lt;br&gt;&lt;/div&gt; | 
**billingIdentityRegistrationNumber** | **NSString*** | Fatura kesilen kişinin TC kimlik numarası. | [optional] 
**billingTaxOffice** | **NSString*** | Fatura kesilen kişi/kurumun vergi dairesi. | [optional] 
**billingTaxNo** | **NSString*** | Fatura kesilen kişi/kurum vergi numarası. | [optional] 
**isEinvoiceUser** | **NSString*** | Yöneticinin(admin) e-fatura kullanıp kullanmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] 
**useGiftPackage** | **NSString*** | Müşterinin hediye paketi isteyip istemediği bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Evet&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hayır&lt;br&gt;&lt;/div&gt; | [optional] 
**giftNote** | **NSString*** | Hediye notu bilgisi. | [optional] 
**imageFile** | **NSString*** | Sipariş öncesi bilgisi nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .jpg, .jpeg, .png, .gif | [optional] 
**deliveryDate** | **NSDate*** | Müşterinin teslimatın gerçekleşmisini istediği tarih. | [optional] 
**deliveryTime** | **NSString*** | API bu değeri otomatik oluşturur. | [optional] 
**createdAt** | **NSDate*** | Sipariş öncesi bilgisi nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **NSDate*** | Sipariş öncesi bilgisi nesnesinin güncellenme zamanı. | [optional] 
**billingCountry** | [**SWGCountry***](SWGCountry.md) | Ülke nesnesi. | 
**billingLocation** | [**SWGLocation***](SWGLocation.md) | Şehir nesnesi. | 
**shippingCompany** | [**SWGShippingCompany***](SWGShippingCompany.md) | Kargo firması nesnesi. | 
**shippingCountry** | [**SWGCountry***](SWGCountry.md) | Ülke nesnesi. | 
**shippingLocation** | [**SWGLocation***](SWGLocation.md) | Şehir nesnesi. | 
**memberShippingAddress** | [**SWGMemberAddress***](SWGMemberAddress.md) | Üye adresi nesnesi. | [optional] 
**memberBillingAddress** | [**SWGMemberAddress***](SWGMemberAddress.md) | Üye adresi nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


