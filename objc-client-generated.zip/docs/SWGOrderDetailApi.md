# SWGOrderDetailApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**orderDetailsGet**](SWGOrderDetailApi.md#orderdetailsget) | **GET** /order_details | Sipariş Detayı Listesi Alma
[**orderDetailsIdDelete**](SWGOrderDetailApi.md#orderdetailsiddelete) | **DELETE** /order_details/{id} | Sipariş Detayı Silme
[**orderDetailsIdGet**](SWGOrderDetailApi.md#orderdetailsidget) | **GET** /order_details/{id} | Sipariş Detayı Alma
[**orderDetailsIdPut**](SWGOrderDetailApi.md#orderdetailsidput) | **PUT** /order_details/{id} | Sipariş Detayı Güncelleme
[**orderDetailsPost**](SWGOrderDetailApi.md#orderdetailspost) | **POST** /order_details | Sipariş Detayı Oluşturma


# **orderDetailsGet**
```objc
-(NSURLSessionTask*) orderDetailsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    order: (NSNumber*) order
        completionHandler: (void (^)(SWGOrderDetail* output, NSError* error)) handler;
```

Sipariş Detayı Listesi Alma

Sipariş Detayı listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSNumber* order = @56; // Sipariş id (optional)

SWGOrderDetailApi*apiInstance = [[SWGOrderDetailApi alloc] init];

// Sipariş Detayı Listesi Alma
[apiInstance orderDetailsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              order:order
          completionHandler: ^(SWGOrderDetail* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOrderDetailApi->orderDetailsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **order** | **NSNumber***| Sipariş id | [optional] 

### Return type

[**SWGOrderDetail***](SWGOrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **orderDetailsIdDelete**
```objc
-(NSURLSessionTask*) orderDetailsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Sipariş Detayı Silme

Kalıcı olarak ilgili Sipariş Detayı siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Sipariş Detayı nesnesinin id değeri

SWGOrderDetailApi*apiInstance = [[SWGOrderDetailApi alloc] init];

// Sipariş Detayı Silme
[apiInstance orderDetailsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGOrderDetailApi->orderDetailsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Sipariş Detayı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **orderDetailsIdGet**
```objc
-(NSURLSessionTask*) orderDetailsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGOrderDetail* output, NSError* error)) handler;
```

Sipariş Detayı Alma

İlgili Sipariş Detayı getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Sipariş Detayı nesnesinin id değeri

SWGOrderDetailApi*apiInstance = [[SWGOrderDetailApi alloc] init];

// Sipariş Detayı Alma
[apiInstance orderDetailsIdGetWithId:_id
          completionHandler: ^(SWGOrderDetail* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOrderDetailApi->orderDetailsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Sipariş Detayı nesnesinin id değeri | 

### Return type

[**SWGOrderDetail***](SWGOrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **orderDetailsIdPut**
```objc
-(NSURLSessionTask*) orderDetailsIdPutWithId: (NSNumber*) _id
    orderDetail: (SWGOrderDetail*) orderDetail
        completionHandler: (void (^)(SWGOrderDetail* output, NSError* error)) handler;
```

Sipariş Detayı Güncelleme

İlgili Sipariş Detayı günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Sipariş Detayı nesnesinin id değeri
SWGOrderDetail* orderDetail = [[SWGOrderDetail alloc] init]; //  nesnesi

SWGOrderDetailApi*apiInstance = [[SWGOrderDetailApi alloc] init];

// Sipariş Detayı Güncelleme
[apiInstance orderDetailsIdPutWithId:_id
              orderDetail:orderDetail
          completionHandler: ^(SWGOrderDetail* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOrderDetailApi->orderDetailsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Sipariş Detayı nesnesinin id değeri | 
 **orderDetail** | [**SWGOrderDetail***](SWGOrderDetail.md)|  nesnesi | 

### Return type

[**SWGOrderDetail***](SWGOrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **orderDetailsPost**
```objc
-(NSURLSessionTask*) orderDetailsPostWithOrderDetail: (SWGOrderDetail*) orderDetail
        completionHandler: (void (^)(SWGOrderDetail* output, NSError* error)) handler;
```

Sipariş Detayı Oluşturma

Yeni bir Sipariş Detayı oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGOrderDetail* orderDetail = [[SWGOrderDetail alloc] init]; //  nesnesi

SWGOrderDetailApi*apiInstance = [[SWGOrderDetailApi alloc] init];

// Sipariş Detayı Oluşturma
[apiInstance orderDetailsPostWithOrderDetail:orderDetail
          completionHandler: ^(SWGOrderDetail* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGOrderDetailApi->orderDetailsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **orderDetail** | [**SWGOrderDetail***](SWGOrderDetail.md)|  nesnesi | 

### Return type

[**SWGOrderDetail***](SWGOrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

