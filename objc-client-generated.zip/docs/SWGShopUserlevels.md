# SWGShopUserlevels

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Yönetici grubu nesnesinin benzersiz rakamsal kimlik değeri. | [optional] 
**label** | **NSString*** | Yönetici grubu ismi. | [optional] 
**roles** | **NSString*** | Yönetici grubunun sahip olduğu roller. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


