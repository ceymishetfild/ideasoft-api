# SWGProductImageApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**productImagesGet**](SWGProductImageApi.md#productimagesget) | **GET** /product_images | Ürün Resim Listesi Alma
[**productImagesIdDelete**](SWGProductImageApi.md#productimagesiddelete) | **DELETE** /product_images/{id} | Ürün Resim Silme
[**productImagesIdGet**](SWGProductImageApi.md#productimagesidget) | **GET** /product_images/{id} | Ürün Resim Alma
[**productImagesPost**](SWGProductImageApi.md#productimagespost) | **POST** /product_images | Ürün Resim Oluşturma


# **productImagesGet**
```objc
-(NSURLSessionTask*) productImagesGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    fileName: (NSString*) fileName
    product: (NSNumber*) product
        completionHandler: (void (^)(SWGProductImage* output, NSError* error)) handler;
```

Ürün Resim Listesi Alma

Ürün Resim listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* fileName = @"fileName_example"; // Ürün Resim dosya adı (optional)
NSNumber* product = @56; // Ürün id (optional)

SWGProductImageApi*apiInstance = [[SWGProductImageApi alloc] init];

// Ürün Resim Listesi Alma
[apiInstance productImagesGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              fileName:fileName
              product:product
          completionHandler: ^(SWGProductImage* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductImageApi->productImagesGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **fileName** | **NSString***| Ürün Resim dosya adı | [optional] 
 **product** | **NSNumber***| Ürün id | [optional] 

### Return type

[**SWGProductImage***](SWGProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productImagesIdDelete**
```objc
-(NSURLSessionTask*) productImagesIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

Ürün Resim Silme

Kalıcı olarak ilgili Ürün Resmini siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Resmi nesnesinin id değeri

SWGProductImageApi*apiInstance = [[SWGProductImageApi alloc] init];

// Ürün Resim Silme
[apiInstance productImagesIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGProductImageApi->productImagesIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Resmi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productImagesIdGet**
```objc
-(NSURLSessionTask*) productImagesIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGProductImage* output, NSError* error)) handler;
```

Ürün Resim Alma

İlgili Ürün Resmini getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // Ürün Resmi nesnesinin id değeri

SWGProductImageApi*apiInstance = [[SWGProductImageApi alloc] init];

// Ürün Resim Alma
[apiInstance productImagesIdGetWithId:_id
          completionHandler: ^(SWGProductImage* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductImageApi->productImagesIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| Ürün Resmi nesnesinin id değeri | 

### Return type

[**SWGProductImage***](SWGProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **productImagesPost**
```objc
-(NSURLSessionTask*) productImagesPostWithProductImage: (SWGProductImage*) productImage
        completionHandler: (void (^)(SWGProductImage* output, NSError* error)) handler;
```

Ürün Resim Oluşturma

Yeni bir Ürün Resim oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGProductImage* productImage = [[SWGProductImage alloc] init]; //  nesnesi

SWGProductImageApi*apiInstance = [[SWGProductImageApi alloc] init];

// Ürün Resim Oluşturma
[apiInstance productImagesPostWithProductImage:productImage
          completionHandler: ^(SWGProductImage* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGProductImageApi->productImagesPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productImage** | [**SWGProductImage***](SWGProductImage.md)|  nesnesi | 

### Return type

[**SWGProductImage***](SWGProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

