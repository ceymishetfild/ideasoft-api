# SWGError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **NSNumber*** | HTTP Hata kodu. | [optional] 
**errorMessage** | **NSString*** | Hata mesajı. Hata mesajları İngilizce dilindedir. | [optional] 
**errorCode** | **NSNumber*** | Hata kodu. Eğer ek bir hata kodu varsa bu alanda belirtilir. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


