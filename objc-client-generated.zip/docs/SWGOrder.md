# SWGOrder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_id** | **NSNumber*** | Sipariş nesnesi kimlik değeri. | [optional] 
**customerFirstname** | **NSString*** | Müşterinin ismi. | 
**customerSurname** | **NSString*** | Müşterinin soy ismi. | 
**customerEmail** | **NSString*** | Müşterinin e-mail adresi. | 
**customerPhone** | **NSString*** | Müşterinin telefon numarası. | 
**paymentTypeName** | **NSString*** | Siparişin ödeme tipi. | 
**paymentProviderCode** | **NSString*** | Siparişin ödeme altyapısı sağlayıcısının kodu. Ön tanımlıdır. API otomatik oluşturur. | 
**paymentProviderName** | **NSString*** | Siparişin ödeme altyapısı sağlayıcısının adı. Ön tanımlıdır. API otomatik oluşturur. | 
**paymentGatewayCode** | **NSString*** | Siparişin ödeme kanalının kodu. Ön tanımlıdır. API otomatik oluşturur. | 
**paymentGatewayName** | **NSString*** | Siparişin ödeme kanalının adı. Ön tanımlıdır. API otomatik oluşturur. | 
**bankName** | **NSString*** | Siparişin banka adı. Ön tanımlıdır. API otomatik oluşturur. | [optional] 
**clientIp** | **NSString*** | Müşterinin IP adresi. | 
**userAgent** | **NSString*** | Siparişin gerçekleştiği tarayıcı bilgisi. | [optional] 
**currency** | **NSString*** | Kur bilgisi. | 
**currencyRates** | **NSString*** | Kur oranları. | 
**amount** | **NSNumber*** | Siparişin vergi hariç fiyatı. | 
**couponDiscount** | **NSNumber*** | Siparişte kullanılan hediye çeki indirimi tutarı. | 
**taxAmount** | **NSNumber*** | Siparişin vergi tutarı. | 
**promotionDiscount** | **NSNumber*** | Siparişte kullanılan promosyon indirimi tutarı. | 
**generalAmount** | **NSNumber*** | Siparişin genel fiyat tutarı. orderAmount, couponDiscount, taxAmount, promotionDiscount, shippingAmount, additionalServiceAmount tutarlarının toplamı. | 
**shippingAmount** | **NSNumber*** | Siparişin teslimat ücreti. | 
**additionalServiceAmount** | **NSNumber*** | Siparişin ek hizmet bedeli ücreti. | 
**finalAmount** | **NSNumber*** | Siparişin son ödeme tutarı. generalAmount değerinin üzerine taksitten kaynaklı vade farkı bedeli eklenmiş hali. | 
**sumOfGainedPoints** | **NSNumber*** | Siparişten kazanılan puan tutarı. | [optional] 
**installment** | **NSNumber*** | Siparişin taksit adeti. | [optional] 
**installmentRate** | **NSNumber*** | Siparişin taksit oranı. | [optional] 
**extraInstallment** | **NSNumber*** | Siparişin ek taksit adeti. | [optional] 
**transactionId** | **NSString*** | Siparişin numarası. | [optional] 
**hasUserNote** | **NSString*** | Siparişin müşteri notuna sahiplik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sipariş müşteri notuna sahip.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sipariş müşteri notuna sahip değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**status** | **NSString*** | Sipariş durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;/div&gt; | 
**paymentStatus** | **NSString*** | Ödeme durumu bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;success&lt;/code&gt; : Başarılı&lt;br&gt;&lt;/div&gt; | 
**errorMessage** | **NSString*** | Siparişin hata mesajı. | [optional] 
**deviceType** | **NSString*** | Siparişin gerçekleştiği cihaz bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil&lt;br&gt;&lt;code&gt;tablet&lt;/code&gt; : Tablet&lt;br&gt;&lt;/div&gt; | 
**referrer** | **NSString*** | Siparişe yönlendiren web-sitesi adresi. Yönlendirmeyi yapan web-sitesinin tam URL bilgisini de içerir. API otomatik oluşturur. | [optional] 
**invoicePrintCount** | **NSNumber*** | Sipariş için alınan fatura çıktısı adedi. | [optional] 
**useGiftPackage** | **NSString*** | Hediye paketi istenilmesi durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hediye paketi istiyorum&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hediye paketi istemiyorum&lt;br&gt;&lt;/div&gt; | [optional] 
**giftNote** | **NSString*** | Hediye notu. | [optional] 
**memberGroupName** | **NSString*** | Üye grubu adı. | [optional] 
**usePromotion** | **NSString*** | Promosyon kullanılma durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Promosyon kullan&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Promosyon kullanma&lt;br&gt;&lt;/div&gt; | [optional] 
**shippingProviderCode** | **NSString*** | Siparişin teslimat hizmeti sağlayıcısı kodu. Ön tanımlıdır. API otomatik oluşturur. | [optional] 
**shippingProviderName** | **NSString*** | Siparişin teslimat hizmeti sağlayıcısı adı. Ön tanımlıdır. | [optional] 
**shippingCompanyName** | **NSString*** | Siparişin kargo firması adı. Ön tanımlıdır. | [optional] 
**shippingPaymentType** | **NSString*** | Siparişin kargo ödeme tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı Ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici Ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için geçerli değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**shippingTrackingCode** | **NSString*** | Siparişin kargo takip kodu. | [optional] 
**source** | **NSString*** | Siparişin kaynak bilgisi. Siparişin kaynak yazılımını belirtir. | 
**createdAt** | **NSDate*** | Sipariş nesnesinin oluşturulma zamanı. | [optional] 
**updatedAt** | **NSDate*** | Sipariş nesnesinin güncellenme zamanı. | [optional] 
**maillist** | [**SWGMaillist***](SWGMaillist.md) | Mail listesi nesnesi. | [optional] 
**member** | [**SWGMember***](SWGMember.md) | Üye nesnesi. | [optional] 
**orderDetails** | [**NSArray&lt;SWGOrderDetail&gt;***](SWGOrderDetail.md) | Sipariş detayları. | [optional] 
**orderItems** | [**NSArray&lt;SWGOrderItem&gt;***](SWGOrderItem.md) | Sipariş kalemleri. | [optional] 
**shippingAddress** | [**SWGShippingAddress***](SWGShippingAddress.md) | Teslimat adresi nesnesi. | [optional] 
**billingAddress** | [**SWGBillingAddress***](SWGBillingAddress.md) | Fatura adresi nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


