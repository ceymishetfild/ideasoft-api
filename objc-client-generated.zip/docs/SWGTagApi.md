# SWGTagApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**tagsGet**](SWGTagApi.md#tagsget) | **GET** /tags | SEO+ Etiketi Listesi Alma
[**tagsIdDelete**](SWGTagApi.md#tagsiddelete) | **DELETE** /tags/{id} | SEO+ Etiketi Silme
[**tagsIdGet**](SWGTagApi.md#tagsidget) | **GET** /tags/{id} | SEO+ Etiketi Alma
[**tagsIdPut**](SWGTagApi.md#tagsidput) | **PUT** /tags/{id} | SEO+ Etiketi Güncelleme
[**tagsPost**](SWGTagApi.md#tagspost) | **POST** /tags | SEO+ Etiketi Oluşturma


# **tagsGet**
```objc
-(NSURLSessionTask*) tagsGetWithSort: (NSString*) sort
    limit: (NSNumber*) limit
    page: (NSNumber*) page
    sinceId: (NSNumber*) sinceId
    ids: (NSString*) ids
    name: (NSString*) name
        completionHandler: (void (^)(SWGTag* output, NSError* error)) handler;
```

SEO+ Etiketi Listesi Alma

SEO+ Etiketi listesini verir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSString* sort = @"sort_example"; // Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> (optional)
NSNumber* limit = @20; // Bir sayfada gelecek sonuç adedi (optional) (default to 20)
NSNumber* page = @1; // Hangi sayfadan başlanacağı (optional) (default to 1)
NSNumber* sinceId = @56; // Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
NSString* ids = @"ids_example"; // Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
NSString* name = @"name_example"; // SEO+ Etiketi adı (optional)

SWGTagApi*apiInstance = [[SWGTagApi alloc] init];

// SEO+ Etiketi Listesi Alma
[apiInstance tagsGetWithSort:sort
              limit:limit
              page:page
              sinceId:sinceId
              ids:ids
              name:name
          completionHandler: ^(SWGTag* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGTagApi->tagsGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **NSString***| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **NSNumber***| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **NSNumber***| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **sinceId** | **NSNumber***| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **NSString***| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **NSString***| SEO+ Etiketi adı | [optional] 

### Return type

[**SWGTag***](SWGTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **tagsIdDelete**
```objc
-(NSURLSessionTask*) tagsIdDeleteWithId: (NSNumber*) _id
        completionHandler: (void (^)(NSError* error)) handler;
```

SEO+ Etiketi Silme

Kalıcı olarak ilgili SEO+ Etiketini siler.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // SEO+ Etiketi nesnesinin id değeri

SWGTagApi*apiInstance = [[SWGTagApi alloc] init];

// SEO+ Etiketi Silme
[apiInstance tagsIdDeleteWithId:_id
          completionHandler: ^(NSError* error) {
                        if (error) {
                            NSLog(@"Error calling SWGTagApi->tagsIdDelete: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| SEO+ Etiketi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **tagsIdGet**
```objc
-(NSURLSessionTask*) tagsIdGetWithId: (NSNumber*) _id
        completionHandler: (void (^)(SWGTag* output, NSError* error)) handler;
```

SEO+ Etiketi Alma

İlgili SEO+ Etiketini getirir.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // SEO+ Etiketi nesnesinin id değeri

SWGTagApi*apiInstance = [[SWGTagApi alloc] init];

// SEO+ Etiketi Alma
[apiInstance tagsIdGetWithId:_id
          completionHandler: ^(SWGTag* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGTagApi->tagsIdGet: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| SEO+ Etiketi nesnesinin id değeri | 

### Return type

[**SWGTag***](SWGTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **tagsIdPut**
```objc
-(NSURLSessionTask*) tagsIdPutWithId: (NSNumber*) _id
    tag: (SWGTag*) tag
        completionHandler: (void (^)(SWGTag* output, NSError* error)) handler;
```

SEO+ Etiketi Güncelleme

İlgili SEO+ Etiketini günceller.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


NSNumber* _id = @56; // SEO+ Etiketi nesnesinin id değeri
SWGTag* tag = [[SWGTag alloc] init]; //  nesnesi

SWGTagApi*apiInstance = [[SWGTagApi alloc] init];

// SEO+ Etiketi Güncelleme
[apiInstance tagsIdPutWithId:_id
              tag:tag
          completionHandler: ^(SWGTag* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGTagApi->tagsIdPut: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **_id** | **NSNumber***| SEO+ Etiketi nesnesinin id değeri | 
 **tag** | [**SWGTag***](SWGTag.md)|  nesnesi | 

### Return type

[**SWGTag***](SWGTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **tagsPost**
```objc
-(NSURLSessionTask*) tagsPostWithTag: (SWGTag*) tag
        completionHandler: (void (^)(SWGTag* output, NSError* error)) handler;
```

SEO+ Etiketi Oluşturma

Yeni bir SEO+ Etiketi oluşturur.

### Example 
```objc
SWGDefaultConfiguration *apiConfig = [SWGDefaultConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: OAuth2)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


SWGTag* tag = [[SWGTag alloc] init]; //  nesnesi

SWGTagApi*apiInstance = [[SWGTagApi alloc] init];

// SEO+ Etiketi Oluşturma
[apiInstance tagsPostWithTag:tag
          completionHandler: ^(SWGTag* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling SWGTagApi->tagsPost: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tag** | [**SWGTag***](SWGTag.md)|  nesnesi | 

### Return type

[**SWGTag***](SWGTag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

