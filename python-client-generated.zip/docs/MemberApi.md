# swagger_client.MemberApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**members_charts_get**](MemberApi.md#members_charts_get) | **GET** /members/charts | Üye Grafik Aksiyonu
[**members_combined_get**](MemberApi.md#members_combined_get) | **GET** /members/combined | Üye Birleşik Aksiyonu
[**members_get**](MemberApi.md#members_get) | **GET** /members | Üye Listesi Alma
[**members_id_delete**](MemberApi.md#members_id_delete) | **DELETE** /members/{id} | Üye Silme
[**members_id_get**](MemberApi.md#members_id_get) | **GET** /members/{id} | Üye Alma
[**members_id_put**](MemberApi.md#members_id_put) | **PUT** /members/{id} | Üye Güncelleme
[**members_post**](MemberApi.md#members_post) | **POST** /members | Üye Oluşturma


# **members_charts_get**
> Member members_charts_get(time_frame, start_date)

Üye Grafik Aksiyonu

Zaman bazında üye genel istatistiklerini getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberApi(swagger_client.ApiClient(configuration))
time_frame = 'time_frame_example' # str | Şu değerleri olabilir: full, year, month or week
start_date = 'start_date_example' # str | Zaman aralığının başlangıcı

try:
    # Üye Grafik Aksiyonu
    api_response = api_instance.members_charts_get(time_frame, start_date)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MemberApi->members_charts_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **time_frame** | **str**| Şu değerleri olabilir: full, year, month or week | 
 **start_date** | **str**| Zaman aralığının başlangıcı | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **members_combined_get**
> Member members_combined_get()

Üye Birleşik Aksiyonu

Bugün, aylık, yıllık ve toplam üye oturum açma istatistiklerini totalCount cinsinden getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberApi(swagger_client.ApiClient(configuration))

try:
    # Üye Birleşik Aksiyonu
    api_response = api_instance.members_combined_get()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MemberApi->members_combined_get: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **members_get**
> Member members_get(sort=sort, limit=limit, page=page, since_id=since_id, firstname=firstname, surname=surname, email=email, password=password, gender=gender, mobile_phone_number=mobile_phone_number, phone_number=phone_number, member_group=member_group, location=location, country=country, referred_member=referred_member, q=q, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)

Üye Listesi Alma

Üye listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
firstname = 'firstname_example' # str | Adı (optional)
surname = 'surname_example' # str | Soyadı (optional)
email = 'email_example' # str | e-mail adresi (optional)
password = 'password_example' # str | Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri (optional)
gender = 'gender_example' # str | Cinsiyet şu değerleri alabilir: <br><code>male</code> : Erkek<br><code>female</code> : Kadın (optional)
mobile_phone_number = 'mobile_phone_number_example' # str | Üye mobil telefon numarası (optional)
phone_number = 'phone_number_example' # str | Üye telefon numarası (optional)
member_group = 56 # int | Üye Grubu id (optional)
location = 56 # int | Şehir id (optional)
country = 56 # int | Ülke id (optional)
referred_member = 56 # int | Tavsiye Üye id (optional)
q = ['q_example'] # list[str] | Üye arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;] (optional)
start_date = '2013-10-20' # date | createdAt değeri için başlangıç tarihi (optional)
end_date = 'end_date_example' # str | createdAt değeri için bitiş tarihi (optional)
start_updated_at = '2013-10-20' # date | updatedAt değeri için başlangıç tarihi (optional)
end_updated_at = 'end_updated_at_example' # str | updatedAt değeri için bitiş tarihi (optional)

try:
    # Üye Listesi Alma
    api_response = api_instance.members_get(sort=sort, limit=limit, page=page, since_id=since_id, firstname=firstname, surname=surname, email=email, password=password, gender=gender, mobile_phone_number=mobile_phone_number, phone_number=phone_number, member_group=member_group, location=location, country=country, referred_member=referred_member, q=q, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MemberApi->members_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **firstname** | **str**| Adı | [optional] 
 **surname** | **str**| Soyadı | [optional] 
 **email** | **str**| e-mail adresi | [optional] 
 **password** | **str**| Üyenin önce MD5 sonra SHA256 ile şifrelenmiş şifre değeri | [optional] 
 **gender** | **str**| Cinsiyet şu değerleri alabilir: &lt;br&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın | [optional] 
 **mobile_phone_number** | **str**| Üye mobil telefon numarası | [optional] 
 **phone_number** | **str**| Üye telefon numarası | [optional] 
 **member_group** | **int**| Üye Grubu id | [optional] 
 **location** | **int**| Şehir id | [optional] 
 **country** | **int**| Ülke id | [optional] 
 **referred_member** | **int**| Tavsiye Üye id | [optional] 
 **q** | [**list[str]**](str.md)| Üye arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 
 **start_date** | **date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **str**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **str**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **members_id_delete**
> members_id_delete(id)

Üye Silme

Kalıcı olarak ilgili Üyeyi siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberApi(swagger_client.ApiClient(configuration))
id = 56 # int | Üye nesnesinin id değeri

try:
    # Üye Silme
    api_instance.members_id_delete(id)
except ApiException as e:
    print("Exception when calling MemberApi->members_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **members_id_get**
> Member members_id_get(id)

Üye Alma

İlgili Üyeyi getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberApi(swagger_client.ApiClient(configuration))
id = 56 # int | Üye nesnesinin id değeri

try:
    # Üye Alma
    api_response = api_instance.members_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MemberApi->members_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye nesnesinin id değeri | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **members_id_put**
> Member members_id_put(id, member)

Üye Güncelleme

İlgili Üyeyi günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberApi(swagger_client.ApiClient(configuration))
id = 56 # int | Üye nesnesinin id değeri
member = swagger_client.Member() # Member | Member nesnesi

try:
    # Üye Güncelleme
    api_response = api_instance.members_id_put(id, member)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MemberApi->members_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye nesnesinin id değeri | 
 **member** | [**Member**](Member.md)| Member nesnesi | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **members_post**
> Member members_post(member)

Üye Oluşturma

Yeni bir Üye oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberApi(swagger_client.ApiClient(configuration))
member = swagger_client.Member() # Member | Member nesnesi

try:
    # Üye Oluşturma
    api_response = api_instance.members_post(member)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MemberApi->members_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member** | [**Member**](Member.md)| Member nesnesi | 

### Return type

[**Member**](Member.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

