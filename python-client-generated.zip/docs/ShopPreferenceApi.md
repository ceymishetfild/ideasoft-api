# swagger_client.ShopPreferenceApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**preferences_get**](ShopPreferenceApi.md#preferences_get) | **GET** /preferences | Tanımlamalar Listesi Alma
[**preferences_id_get**](ShopPreferenceApi.md#preferences_id_get) | **GET** /preferences/{id} | Tanımlamalar Alma
[**preferences_id_put**](ShopPreferenceApi.md#preferences_id_put) | **PUT** /preferences/{id} | Tanımlamalar Güncelleme


# **preferences_get**
> ShopPreference preferences_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, var_key=var_key)

Tanımlamalar Listesi Alma

Tanımlamalar listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ShopPreferenceApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 100 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 100)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
var_key = 'var_key_example' # str | Tanımlama varKey değeri (optional)

try:
    # Tanımlamalar Listesi Alma
    api_response = api_instance.preferences_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, var_key=var_key)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ShopPreferenceApi->preferences_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 100]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **var_key** | **str**| Tanımlama varKey değeri | [optional] 

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **preferences_id_get**
> ShopPreference preferences_id_get(id)

Tanımlamalar Alma

İlgili Tanımlamayı getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ShopPreferenceApi(swagger_client.ApiClient(configuration))
id = 56 # int | Tanımlama nesnesinin id değeri

try:
    # Tanımlamalar Alma
    api_response = api_instance.preferences_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ShopPreferenceApi->preferences_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tanımlama nesnesinin id değeri | 

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **preferences_id_put**
> ShopPreference preferences_id_put(id, shop_preference)

Tanımlamalar Güncelleme

İlgili Tanımlamayı günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ShopPreferenceApi(swagger_client.ApiClient(configuration))
id = 56 # int | Tanımlama nesnesinin id değeri
shop_preference = swagger_client.ShopPreference() # ShopPreference |  nesnesi

try:
    # Tanımlamalar Güncelleme
    api_response = api_instance.preferences_id_put(id, shop_preference)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ShopPreferenceApi->preferences_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tanımlama nesnesinin id değeri | 
 **shop_preference** | [**ShopPreference**](ShopPreference.md)|  nesnesi | 

### Return type

[**ShopPreference**](ShopPreference.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

