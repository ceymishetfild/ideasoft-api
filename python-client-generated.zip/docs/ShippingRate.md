# ShippingRate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Kargo oranı nesnesi kimlik değeri. | [optional] 
**volumetric_weight_start** | **int** | İlgili kargo firması, ilgili bölge ve ilgili orana ait minimum desi değeri. | 
**volumetric_weight_end** | **int** | İlgili kargo firması, ilgili bölge ve ilgili orana ait maximum desi değeri. | 
**rate** | **float** | Seçili bölge ve kargo firması için kargo oranı. | 
**region** | [**Region**](Region.md) |  | [optional] 
**shipping_company** | [**ShippingCompany**](ShippingCompany.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


