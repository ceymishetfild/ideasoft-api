# swagger_client.ProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**products_get**](ProductApi.md#products_get) | **GET** /products | Ürün Listesi Alma
[**products_id_delete**](ProductApi.md#products_id_delete) | **DELETE** /products/{id} | Ürün Silme
[**products_id_get**](ProductApi.md#products_id_get) | **GET** /products/{id} | Ürün Alma
[**products_id_put**](ProductApi.md#products_id_put) | **PUT** /products/{id} | Ürün Güncelleme
[**products_post**](ProductApi.md#products_post) | **POST** /products | Ürün Oluşturma


# **products_get**
> Product products_get(sort=sort, limit=limit, page=page, since_id=since_id, parent=parent, brand=brand, sku=sku, name=name, distributor=distributor, q=q, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)

Ürün Listesi Alma

Ürün listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
parent = 'parent_example' # str | Ürün id (optional)
brand = 56 # int | Marka id (optional)
sku = 'sku_example' # str | Ürün stok kodu. (optional)
name = 'name_example' # str | Ürün adı. (optional)
distributor = 'distributor_example' # str | Ürün distribütör. (optional)
q = ['q_example'] # list[str] | Ürün arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;] (optional)
start_date = '2013-10-20' # date | createdAt değeri için başlangıç tarihi (optional)
end_date = 'end_date_example' # str | createdAt değeri için bitiş tarihi (optional)
start_updated_at = '2013-10-20' # date | updatedAt değeri için başlangıç tarihi (optional)
end_updated_at = 'end_updated_at_example' # str | updatedAt değeri için bitiş tarihi (optional)

try:
    # Ürün Listesi Alma
    api_response = api_instance.products_get(sort=sort, limit=limit, page=page, since_id=since_id, parent=parent, brand=brand, sku=sku, name=name, distributor=distributor, q=q, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductApi->products_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **parent** | **str**| Ürün id | [optional] 
 **brand** | **int**| Marka id | [optional] 
 **sku** | **str**| Ürün stok kodu. | [optional] 
 **name** | **str**| Ürün adı. | [optional] 
 **distributor** | **str**| Ürün distribütör. | [optional] 
 **q** | [**list[str]**](str.md)| Ürün arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 
 **start_date** | **date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **str**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **str**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **products_id_delete**
> products_id_delete(id)

Ürün Silme

Kalıcı olarak ilgili Ürünü siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün nesnesinin id değeri

try:
    # Ürün Silme
    api_instance.products_id_delete(id)
except ApiException as e:
    print("Exception when calling ProductApi->products_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **products_id_get**
> Product products_id_get(id)

Ürün Alma

İlgili Ürünü getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün nesnesinin id değeri

try:
    # Ürün Alma
    api_response = api_instance.products_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductApi->products_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün nesnesinin id değeri | 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **products_id_put**
> Product products_id_put(id, product)

Ürün Güncelleme

İlgili Ürünü günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün nesnesinin id değeri
product = swagger_client.Product() # Product | Product nesnesi

try:
    # Ürün Güncelleme
    api_response = api_instance.products_id_put(id, product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductApi->products_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün nesnesinin id değeri | 
 **product** | [**Product**](Product.md)| Product nesnesi | 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **products_post**
> Product products_post(product)

Ürün Oluşturma

Yeni bir Ürün oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductApi(swagger_client.ApiClient(configuration))
product = swagger_client.Product() # Product | Product nesnesi

try:
    # Ürün Oluşturma
    api_response = api_instance.products_post(product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductApi->products_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product** | [**Product**](Product.md)| Product nesnesi | 

### Return type

[**Product**](Product.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

