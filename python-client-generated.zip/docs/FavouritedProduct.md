# FavouritedProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Favori ürün nesnesi kimlik değeri. | [optional] 
**member** | [**Member**](Member.md) | Üye nesnesi. | 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


