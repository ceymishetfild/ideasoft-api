# swagger_client.OptionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**option_groups_get**](OptionGroupApi.md#option_groups_get) | **GET** /option_groups | Varyant Grubu Listesi Alma
[**option_groups_id_delete**](OptionGroupApi.md#option_groups_id_delete) | **DELETE** /option_groups/{id} | Varyant Grubu Silme
[**option_groups_id_get**](OptionGroupApi.md#option_groups_id_get) | **GET** /option_groups/{id} | Varyant Grubu Alma
[**option_groups_id_put**](OptionGroupApi.md#option_groups_id_put) | **PUT** /option_groups/{id} | Varyant Grubu Güncelleme
[**option_groups_post**](OptionGroupApi.md#option_groups_post) | **POST** /option_groups | Varyant Grubu Oluşturma


# **option_groups_get**
> OptionGroup option_groups_get(sort=sort, limit=limit, page=page, since_id=since_id, title=title)

Varyant Grubu Listesi Alma

Varyant Grubu listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OptionGroupApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
title = 'title_example' # str | Varyant Grubu başlığı. (optional)

try:
    # Varyant Grubu Listesi Alma
    api_response = api_instance.option_groups_get(sort=sort, limit=limit, page=page, since_id=since_id, title=title)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OptionGroupApi->option_groups_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **title** | **str**| Varyant Grubu başlığı. | [optional] 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **option_groups_id_delete**
> option_groups_id_delete(id)

Varyant Grubu Silme

Kalıcı olarak ilgili Varyant Grubunu siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OptionGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | Varyant Grubu nesnesinin id değeri

try:
    # Varyant Grubu Silme
    api_instance.option_groups_id_delete(id)
except ApiException as e:
    print("Exception when calling OptionGroupApi->option_groups_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **option_groups_id_get**
> OptionGroup option_groups_id_get(id)

Varyant Grubu Alma

İlgili Varyant Grubunu getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OptionGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | Varyant Grubu nesnesinin id değeri

try:
    # Varyant Grubu Alma
    api_response = api_instance.option_groups_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OptionGroupApi->option_groups_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant Grubu nesnesinin id değeri | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **option_groups_id_put**
> OptionGroup option_groups_id_put(id, option_group)

Varyant Grubu Güncelleme

İlgili Varyant Grubunu günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OptionGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | Varyant Grubu nesnesinin id değeri
option_group = swagger_client.OptionGroup() # OptionGroup | OptionGroup nesnesi

try:
    # Varyant Grubu Güncelleme
    api_response = api_instance.option_groups_id_put(id, option_group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OptionGroupApi->option_groups_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Varyant Grubu nesnesinin id değeri | 
 **option_group** | [**OptionGroup**](OptionGroup.md)| OptionGroup nesnesi | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **option_groups_post**
> OptionGroup option_groups_post(option_group)

Varyant Grubu Oluşturma

Yeni bir Varyant Grubu oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OptionGroupApi(swagger_client.ApiClient(configuration))
option_group = swagger_client.OptionGroup() # OptionGroup | OptionGroup nesnesi

try:
    # Varyant Grubu Oluşturma
    api_response = api_instance.option_groups_post(option_group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OptionGroupApi->option_groups_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **option_group** | [**OptionGroup**](OptionGroup.md)| OptionGroup nesnesi | 

### Return type

[**OptionGroup**](OptionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

