# swagger_client.TownApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**towns_get**](TownApi.md#towns_get) | **GET** /towns | İlçe Listesi Alma
[**towns_id_delete**](TownApi.md#towns_id_delete) | **DELETE** /towns/{id} | İlçe Silme
[**towns_id_get**](TownApi.md#towns_id_get) | **GET** /towns/{id} | İlçe Alma
[**towns_id_put**](TownApi.md#towns_id_put) | **PUT** /towns/{id} | İlçe Güncelleme
[**towns_post**](TownApi.md#towns_post) | **POST** /towns | İlçe Oluşturma


# **towns_get**
> Town towns_get(sort=sort, limit=limit, page=page, since_id=since_id, location=location, town_group=town_group, name=name, status=status)

İlçe Listesi Alma

İlçe listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.TownApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
location = 56 # int | Şehir id (optional)
town_group = 56 # int | İlçe grubu id (optional)
name = 'name_example' # str | İlçe adı. (optional)
status = 'status_example' # str | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif (optional)

try:
    # İlçe Listesi Alma
    api_response = api_instance.towns_get(sort=sort, limit=limit, page=page, since_id=since_id, location=location, town_group=town_group, name=name, status=status)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TownApi->towns_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **location** | **int**| Şehir id | [optional] 
 **town_group** | **int**| İlçe grubu id | [optional] 
 **name** | **str**| İlçe adı. | [optional] 
 **status** | **str**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **towns_id_delete**
> towns_id_delete(id)

İlçe Silme

Kalıcı olarak ilgili İlçeyi siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.TownApi(swagger_client.ApiClient(configuration))
id = 56 # int | İlçe nesnesinin id değeri

try:
    # İlçe Silme
    api_instance.towns_id_delete(id)
except ApiException as e:
    print("Exception when calling TownApi->towns_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **towns_id_get**
> Town towns_id_get(id)

İlçe Alma

İlgili İlçeyi getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.TownApi(swagger_client.ApiClient(configuration))
id = 56 # int | İlçe nesnesinin id değeri

try:
    # İlçe Alma
    api_response = api_instance.towns_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TownApi->towns_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe nesnesinin id değeri | 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **towns_id_put**
> Town towns_id_put(id, town)

İlçe Güncelleme

İlgili İlçeyi günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.TownApi(swagger_client.ApiClient(configuration))
id = 56 # int | İlçe nesnesinin id değeri
town = swagger_client.Town() # Town | Town nesnesi

try:
    # İlçe Güncelleme
    api_response = api_instance.towns_id_put(id, town)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TownApi->towns_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe nesnesinin id değeri | 
 **town** | [**Town**](Town.md)| Town nesnesi | 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **towns_post**
> Town towns_post(town)

İlçe Oluşturma

Yeni bir İlçe oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.TownApi(swagger_client.ApiClient(configuration))
town = swagger_client.Town() # Town | Town nesnesi

try:
    # İlçe Oluşturma
    api_response = api_instance.towns_post(town)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TownApi->towns_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **town** | [**Town**](Town.md)| Town nesnesi | 

### Return type

[**Town**](Town.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

