# swagger_client.OrderUserNoteApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**order_user_notes_get**](OrderUserNoteApi.md#order_user_notes_get) | **GET** /order_user_notes | Sipariş Yönetici Notu Listesi Alma
[**order_user_notes_id_delete**](OrderUserNoteApi.md#order_user_notes_id_delete) | **DELETE** /order_user_notes/{id} | Sipariş Yönetici Notu Silme
[**order_user_notes_id_get**](OrderUserNoteApi.md#order_user_notes_id_get) | **GET** /order_user_notes/{id} | Sipariş Yönetici Notu Alma
[**order_user_notes_id_put**](OrderUserNoteApi.md#order_user_notes_id_put) | **PUT** /order_user_notes/{id} | Sipariş Yönetici Notu Güncelleme
[**order_user_notes_post**](OrderUserNoteApi.md#order_user_notes_post) | **POST** /order_user_notes | Sipariş Yönetici Notu Oluşturma


# **order_user_notes_get**
> OrderUserNote order_user_notes_get(sort=sort, limit=limit, page=page, since_id=since_id, order=order, user_email=user_email, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)

Sipariş Yönetici Notu Listesi Alma

Sipariş Yönetici Notu listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderUserNoteApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
order = 56 # int | Sipariş id (optional)
user_email = 'user_email_example' # str | Yönetici e-mail (optional)
start_date = '2013-10-20' # date | createdAt değeri için başlangıç tarihi (optional)
end_date = 'end_date_example' # str | createdAt değeri için bitiş tarihi (optional)
start_updated_at = '2013-10-20' # date | updatedAt değeri için başlangıç tarihi (optional)
end_updated_at = 'end_updated_at_example' # str | updatedAt değeri için bitiş tarihi (optional)

try:
    # Sipariş Yönetici Notu Listesi Alma
    api_response = api_instance.order_user_notes_get(sort=sort, limit=limit, page=page, since_id=since_id, order=order, user_email=user_email, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderUserNoteApi->order_user_notes_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **int**| Sipariş id | [optional] 
 **user_email** | **str**| Yönetici e-mail | [optional] 
 **start_date** | **date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **str**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **str**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_user_notes_id_delete**
> order_user_notes_id_delete(id)

Sipariş Yönetici Notu Silme

Kalıcı olarak ilgili Sipariş Yönetici Notunu siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderUserNoteApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sipariş Yönetici Notu nesnesinin id değeri

try:
    # Sipariş Yönetici Notu Silme
    api_instance.order_user_notes_id_delete(id)
except ApiException as e:
    print("Exception when calling OrderUserNoteApi->order_user_notes_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Yönetici Notu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_user_notes_id_get**
> OrderUserNote order_user_notes_id_get(id)

Sipariş Yönetici Notu Alma

İlgili Sipariş Yönetici Notunu getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderUserNoteApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sipariş Yönetici Notu nesnesinin id değeri

try:
    # Sipariş Yönetici Notu Alma
    api_response = api_instance.order_user_notes_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderUserNoteApi->order_user_notes_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Yönetici Notu nesnesinin id değeri | 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_user_notes_id_put**
> OrderUserNote order_user_notes_id_put(id, order_user_note)

Sipariş Yönetici Notu Güncelleme

İlgili Sipariş Yönetici Notunu günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderUserNoteApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sipariş Yönetici Notu nesnesinin id değeri
order_user_note = swagger_client.OrderUserNote() # OrderUserNote | OrderUserNote nesnesi

try:
    # Sipariş Yönetici Notu Güncelleme
    api_response = api_instance.order_user_notes_id_put(id, order_user_note)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderUserNoteApi->order_user_notes_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Yönetici Notu nesnesinin id değeri | 
 **order_user_note** | [**OrderUserNote**](OrderUserNote.md)| OrderUserNote nesnesi | 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_user_notes_post**
> OrderUserNote order_user_notes_post(order_user_note)

Sipariş Yönetici Notu Oluşturma

Yeni bir Sipariş Yönetici Notu oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderUserNoteApi(swagger_client.ApiClient(configuration))
order_user_note = swagger_client.OrderUserNote() # OrderUserNote | OrderUserNote nesnesi

try:
    # Sipariş Yönetici Notu Oluşturma
    api_response = api_instance.order_user_notes_post(order_user_note)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderUserNoteApi->order_user_notes_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_user_note** | [**OrderUserNote**](OrderUserNote.md)| OrderUserNote nesnesi | 

### Return type

[**OrderUserNote**](OrderUserNote.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

