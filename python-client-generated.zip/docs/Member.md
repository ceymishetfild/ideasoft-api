# Member

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Üye nesnesi kimlik değeri. | [optional] 
**firstname** | **str** | Üyenin ismi. | 
**surname** | **str** | Üyenin soy ismi. | 
**email** | **str** | Üyenin e-mail adresi. | 
**gender** | **str** | Üyenin cinsiyet bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;male&lt;/code&gt; : Erkek&lt;br&gt;&lt;code&gt;female&lt;/code&gt; : Kadın&lt;br&gt;&lt;/div&gt; | [optional] 
**birth_date** | **datetime** | Üyenin doğum tarihi. | [optional] 
**phone_number** | **str** | Üyenin telefon numarası. | [optional] 
**mobile_phone_number** | **str** | Üyenin mobil telefon numarası. | [optional] 
**other_location** | **str** | Üyenin diğer şehir bilgileri. | [optional] 
**address** | **str** | Üyenin adres bilgileri. | [optional] 
**tax_number** | **str** | Üyenin vergi numarası. | [optional] 
**tc_id** | **str** | Üyenin TC kimlik numarası. | [optional] 
**status** | **str** | Üyenin durum bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;queue&lt;/code&gt; : Sırada&lt;br&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;suspended&lt;/code&gt; : Askıda&lt;br&gt;&lt;/div&gt; | 
**last_login_date** | **datetime** | Üyenin son giriş yaptığı tarih. | [optional] 
**created_at** | **datetime** | Üye nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **datetime** | Üye nesnesinin güncellenme zamanı. | [optional] 
**zip_code** | **str** | Üyenin posta kodu. | [optional] 
**commercial_name** | **str** | Üyenin kurumsal adı. | [optional] 
**tax_office** | **str** | Üyenin vergi dairesi. | [optional] 
**last_mail_sent_date** | **datetime** | Üyeye gönderilen son e-mail tarihi. | [optional] 
**last_ip** | **str** | Üyenin en son giriş yaptığı IP adresi. | [optional] 
**gained_point_amount** | **float** | Üyenin kazandığı puan tutarı. | [optional] 
**spent_point_amount** | **float** | Üyenin harcadığı puan tutarı. | [optional] 
**allowed_to_campaigns** | **str** | Üyenin kampanyalara katılım için izin durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Kampanyalar için izinli.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Kampanyalar için izinsiz.&lt;br&gt;&lt;/div&gt; | [optional] 
**referred_member_gained_point_amount** | **float** | Üyenin tavsiye ettiği kişilerden dolayı kazandığı puan. | [optional] 
**district** | **str** | Üyenin ilçesi. | [optional] 
**device_type** | **str** | Üyenin kullandığı cihaz tipi. | 
**device_info** | **str** | Üyenin kullandığı cihaz bilgisi. | [optional] 
**country** | [**Country**](Country.md) | Ülke nesnesi. | [optional] 
**location** | [**Location**](Location.md) | Şehir nesnesi. | [optional] 
**member_group** | [**MemberGroup**](MemberGroup.md) | Üye grubu nesnesi. | [optional] 
**referred_member** | [**Member**](Member.md) | Üyeyi tavsiye eden üye nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


