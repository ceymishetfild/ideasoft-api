# Distributor

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Distributor nesnesi kimlik değeri. | [optional] 
**name** | **str** | Distributor nesnesi için isim değeri. | 
**email** | **str** | E-mail adresi. | [optional] 
**phone** | **str** | Telefon numarası. | [optional] 
**contact_person** | **str** | İletişim kişisi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


