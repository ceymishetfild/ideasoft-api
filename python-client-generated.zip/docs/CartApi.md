# swagger_client.CartApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**carts_id_delete**](CartApi.md#carts_id_delete) | **DELETE** /carts/{id} | Sepet Silme
[**carts_id_get**](CartApi.md#carts_id_get) | **GET** /carts/{id} | Sepet Alma
[**carts_post**](CartApi.md#carts_post) | **POST** /carts | Sepet Oluşturma


# **carts_id_delete**
> carts_id_delete(id)

Sepet Silme

Kalıcı olarak ilgili Sepeti siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.CartApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sepet nesnesinin id değeri

try:
    # Sepet Silme
    api_instance.carts_id_delete(id)
except ApiException as e:
    print("Exception when calling CartApi->carts_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sepet nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **carts_id_get**
> Cart carts_id_get(id)

Sepet Alma

İlgili Sepet getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.CartApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sepet nesnesinin id değeri

try:
    # Sepet Alma
    api_response = api_instance.carts_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CartApi->carts_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sepet nesnesinin id değeri | 

### Return type

[**Cart**](Cart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **carts_post**
> Cart carts_post(cart)

Sepet Oluşturma

Yeni bir Sepet oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.CartApi(swagger_client.ApiClient(configuration))
cart = swagger_client.Cart() # Cart |  nesnesi

try:
    # Sepet Oluşturma
    api_response = api_instance.carts_post(cart)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CartApi->carts_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart** | [**Cart**](Cart.md)|  nesnesi | 

### Return type

[**Cart**](Cart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

