# swagger_client.SpecToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**spec_to_products_get**](SpecToProductApi.md#spec_to_products_get) | **GET** /spec_to_products | Ürün Özellik Ürün Bağı Listesi Alma
[**spec_to_products_id_delete**](SpecToProductApi.md#spec_to_products_id_delete) | **DELETE** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Silme
[**spec_to_products_id_get**](SpecToProductApi.md#spec_to_products_id_get) | **GET** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Alma
[**spec_to_products_id_put**](SpecToProductApi.md#spec_to_products_id_put) | **PUT** /spec_to_products/{id} | Ürün Özellik Ürün Bağı Güncelleme
[**spec_to_products_post**](SpecToProductApi.md#spec_to_products_post) | **POST** /spec_to_products | Ürün Özellik Ürün Bağı Oluşturma


# **spec_to_products_get**
> SpecToProduct spec_to_products_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, product=product, spec_group=spec_group, spec_name=spec_name, spec_value=spec_value)

Ürün Özellik Ürün Bağı Listesi Alma

Ürün Özellik Ürün Bağı listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SpecToProductApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
product = 56 # int | Ürün id (optional)
spec_group = 56 # int | Ürün özellik grubu id (optional)
spec_name = 56 # int | Ürün özellik id (optional)
spec_value = 56 # int | Ürün özellik değeri id (optional)

try:
    # Ürün Özellik Ürün Bağı Listesi Alma
    api_response = api_instance.spec_to_products_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, product=product, spec_group=spec_group, spec_name=spec_name, spec_value=spec_value)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SpecToProductApi->spec_to_products_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **product** | **int**| Ürün id | [optional] 
 **spec_group** | **int**| Ürün özellik grubu id | [optional] 
 **spec_name** | **int**| Ürün özellik id | [optional] 
 **spec_value** | **int**| Ürün özellik değeri id | [optional] 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_to_products_id_delete**
> spec_to_products_id_delete(id)

Ürün Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ürün Özellik Ürün Bağını siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SpecToProductApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Özellik Ürün Bağı nesnesinin id değeri

try:
    # Ürün Özellik Ürün Bağı Silme
    api_instance.spec_to_products_id_delete(id)
except ApiException as e:
    print("Exception when calling SpecToProductApi->spec_to_products_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_to_products_id_get**
> SpecToProduct spec_to_products_id_get(id)

Ürün Özellik Ürün Bağı Alma

İlgili Ürün Özellik Ürün Bağını getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SpecToProductApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Özellik Ürün Bağı nesnesinin id değeri

try:
    # Ürün Özellik Ürün Bağı Alma
    api_response = api_instance.spec_to_products_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SpecToProductApi->spec_to_products_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_to_products_id_put**
> SpecToProduct spec_to_products_id_put(id, spec_to_product)

Ürün Özellik Ürün Bağı Güncelleme

İlgili Ürün Özellik Ürün Bağını günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SpecToProductApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Özellik Ürün Bağı nesnesinin id değeri
spec_to_product = swagger_client.SpecToProduct() # SpecToProduct |  nesnesi

try:
    # Ürün Özellik Ürün Bağı Güncelleme
    api_response = api_instance.spec_to_products_id_put(id, spec_to_product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SpecToProductApi->spec_to_products_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Ürün Bağı nesnesinin id değeri | 
 **spec_to_product** | [**SpecToProduct**](SpecToProduct.md)|  nesnesi | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_to_products_post**
> SpecToProduct spec_to_products_post(spec_to_product)

Ürün Özellik Ürün Bağı Oluşturma

Yeni bir Ürün Özellik Ürün Bağı oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SpecToProductApi(swagger_client.ApiClient(configuration))
spec_to_product = swagger_client.SpecToProduct() # SpecToProduct |  nesnesi

try:
    # Ürün Özellik Ürün Bağı Oluşturma
    api_response = api_instance.spec_to_products_post(spec_to_product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SpecToProductApi->spec_to_products_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **spec_to_product** | [**SpecToProduct**](SpecToProduct.md)|  nesnesi | 

### Return type

[**SpecToProduct**](SpecToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

