# Theme

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Tema nesnesi kimlik değeri. | [optional] 
**platform** | **str** | Temanın kullanılacağı platform.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü.&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil.&lt;br&gt;&lt;/div&gt; | 
**type** | **str** | Tema tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;self&lt;/code&gt; : Kişisel Tema.&lt;br&gt;&lt;code&gt;standard&lt;/code&gt; : Standart Tema.&lt;br&gt;&lt;/div&gt; | [optional] 
**name** | **str** | Tema adı. | 
**preset** | **str** | Temanın rengi. | [optional] 
**directory_name** | **str** | Temanın dizini. | [optional] 
**status** | **str** | Temanın durumu. | 
**revision** | **int** | Temanın revisionı. | [optional] 
**created_at** | **datetime** | Tema nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **datetime** | Tema nesnesinin güncellenme zamanı. | [optional] 
**attachment** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


