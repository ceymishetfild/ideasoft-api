# swagger_client.DistributorApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**distributors_get**](DistributorApi.md#distributors_get) | **GET** /distributors | Distribütör Listesi Alma
[**distributors_id_delete**](DistributorApi.md#distributors_id_delete) | **DELETE** /distributors/{id} | Distribütör Silme
[**distributors_id_get**](DistributorApi.md#distributors_id_get) | **GET** /distributors/{id} | Distribütör Alma
[**distributors_id_put**](DistributorApi.md#distributors_id_put) | **PUT** /distributors/{id} | Distribütör Güncelleme
[**distributors_post**](DistributorApi.md#distributors_post) | **POST** /distributors | Distribütör Oluşturma


# **distributors_get**
> Distributor distributors_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, name=name, email=email, phone=phone, contact_person=contact_person)

Distribütör Listesi Alma

Distribütör listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DistributorApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
name = 'name_example' # str | Distribütör adı. (optional)
email = 'email_example' # str | Distribütör email adresi (optional)
phone = 'phone_example' # str | Distribütör telefonu (optional)
contact_person = 'contact_person_example' # str | Distribütör sorumlu kişi (optional)

try:
    # Distribütör Listesi Alma
    api_response = api_instance.distributors_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, name=name, email=email, phone=phone, contact_person=contact_person)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DistributorApi->distributors_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **str**| Distribütör adı. | [optional] 
 **email** | **str**| Distribütör email adresi | [optional] 
 **phone** | **str**| Distribütör telefonu | [optional] 
 **contact_person** | **str**| Distribütör sorumlu kişi | [optional] 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributors_id_delete**
> distributors_id_delete(id)

Distribütör Silme

Kalıcı olarak ilgili Distribütörü siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DistributorApi(swagger_client.ApiClient(configuration))
id = 56 # int | Distribütör nesnesinin id değeri

try:
    # Distribütör Silme
    api_instance.distributors_id_delete(id)
except ApiException as e:
    print("Exception when calling DistributorApi->distributors_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Distribütör nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributors_id_get**
> Distributor distributors_id_get(id)

Distribütör Alma

İlgili Distribütörü getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DistributorApi(swagger_client.ApiClient(configuration))
id = 56 # int | Distribütör nesnesinin id değeri

try:
    # Distribütör Alma
    api_response = api_instance.distributors_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DistributorApi->distributors_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Distribütör nesnesinin id değeri | 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributors_id_put**
> Distributor distributors_id_put(id, distributor)

Distribütör Güncelleme

İlgili Distribütörü günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DistributorApi(swagger_client.ApiClient(configuration))
id = 56 # int | Distribütör nesnesinin id değeri
distributor = swagger_client.Distributor() # Distributor |  nesnesi

try:
    # Distribütör Güncelleme
    api_response = api_instance.distributors_id_put(id, distributor)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DistributorApi->distributors_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Distribütör nesnesinin id değeri | 
 **distributor** | [**Distributor**](Distributor.md)|  nesnesi | 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributors_post**
> Distributor distributors_post(distributor)

Distribütör Oluşturma

Yeni bir Distribütör oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DistributorApi(swagger_client.ApiClient(configuration))
distributor = swagger_client.Distributor() # Distributor |  nesnesi

try:
    # Distribütör Oluşturma
    api_response = api_instance.distributors_post(distributor)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DistributorApi->distributors_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **distributor** | [**Distributor**](Distributor.md)|  nesnesi | 

### Return type

[**Distributor**](Distributor.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

