# swagger_client.PreOrderInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**pre_order_infos_get**](PreOrderInfoApi.md#pre_order_infos_get) | **GET** /pre_order_infos | Sipariş Öncesi Bilgisi Listesi Alma
[**pre_order_infos_id_delete**](PreOrderInfoApi.md#pre_order_infos_id_delete) | **DELETE** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Silme
[**pre_order_infos_id_get**](PreOrderInfoApi.md#pre_order_infos_id_get) | **GET** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Alma
[**pre_order_infos_id_put**](PreOrderInfoApi.md#pre_order_infos_id_put) | **PUT** /pre_order_infos/{id} | Sipariş Öncesi Bilgisi Güncelleme
[**pre_order_infos_post**](PreOrderInfoApi.md#pre_order_infos_post) | **POST** /pre_order_infos | Sipariş Öncesi Bilgisi Oluşturma


# **pre_order_infos_get**
> PreOrderInfo pre_order_infos_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, session_id=session_id, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)

Sipariş Öncesi Bilgisi Listesi Alma

Sipariş Öncesi Bilgisi listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.PreOrderInfoApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
session_id = 'session_id_example' # str | Sipariş Öncesi Bilgisi session id. (optional)
start_date = '2013-10-20' # date | createdAt değeri için başlangıç tarihi (optional)
end_date = 'end_date_example' # str | createdAt değeri için bitiş tarihi (optional)
start_updated_at = '2013-10-20' # date | updatedAt değeri için başlangıç tarihi (optional)
end_updated_at = 'end_updated_at_example' # str | updatedAt değeri için bitiş tarihi (optional)

try:
    # Sipariş Öncesi Bilgisi Listesi Alma
    api_response = api_instance.pre_order_infos_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, session_id=session_id, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PreOrderInfoApi->pre_order_infos_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **session_id** | **str**| Sipariş Öncesi Bilgisi session id. | [optional] 
 **start_date** | **date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **str**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **str**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **pre_order_infos_id_delete**
> pre_order_infos_id_delete(id)

Sipariş Öncesi Bilgisi Silme

Kalıcı olarak ilgili Sipariş Öncesi Bilgisini siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.PreOrderInfoApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sipariş Öncesi Bilgisi nesnesinin id değeri

try:
    # Sipariş Öncesi Bilgisi Silme
    api_instance.pre_order_infos_id_delete(id)
except ApiException as e:
    print("Exception when calling PreOrderInfoApi->pre_order_infos_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **pre_order_infos_id_get**
> PreOrderInfo pre_order_infos_id_get(id)

Sipariş Öncesi Bilgisi Alma

İlgili Sipariş Öncesi Bilgisini getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.PreOrderInfoApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sipariş Öncesi Bilgisi nesnesinin id değeri

try:
    # Sipariş Öncesi Bilgisi Alma
    api_response = api_instance.pre_order_infos_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PreOrderInfoApi->pre_order_infos_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **pre_order_infos_id_put**
> PreOrderInfo pre_order_infos_id_put(id, pre_order_info)

Sipariş Öncesi Bilgisi Güncelleme

İlgili Sipariş Öncesi Bilgisini günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.PreOrderInfoApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sipariş Öncesi Bilgisi nesnesinin id değeri
pre_order_info = swagger_client.PreOrderInfo() # PreOrderInfo |  nesnesi

try:
    # Sipariş Öncesi Bilgisi Güncelleme
    api_response = api_instance.pre_order_infos_id_put(id, pre_order_info)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PreOrderInfoApi->pre_order_infos_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Öncesi Bilgisi nesnesinin id değeri | 
 **pre_order_info** | [**PreOrderInfo**](PreOrderInfo.md)|  nesnesi | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **pre_order_infos_post**
> PreOrderInfo pre_order_infos_post(pre_order_info)

Sipariş Öncesi Bilgisi Oluşturma

Yeni bir Sipariş Öncesi Bilgisi oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.PreOrderInfoApi(swagger_client.ApiClient(configuration))
pre_order_info = swagger_client.PreOrderInfo() # PreOrderInfo |  nesnesi

try:
    # Sipariş Öncesi Bilgisi Oluşturma
    api_response = api_instance.pre_order_infos_post(pre_order_info)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PreOrderInfoApi->pre_order_infos_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pre_order_info** | [**PreOrderInfo**](PreOrderInfo.md)|  nesnesi | 

### Return type

[**PreOrderInfo**](PreOrderInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

