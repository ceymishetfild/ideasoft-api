# swagger_client.MemberAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**member_addresses_get**](MemberAddressApi.md#member_addresses_get) | **GET** /member_addresses | Üye Adresi Listeleme
[**member_addresses_id_delete**](MemberAddressApi.md#member_addresses_id_delete) | **DELETE** /member_addresses/{id} | Üye Adresi Silme
[**member_addresses_id_get**](MemberAddressApi.md#member_addresses_id_get) | **GET** /member_addresses/{id} | Üye Adresi Alma
[**member_addresses_id_put**](MemberAddressApi.md#member_addresses_id_put) | **PUT** /member_addresses/{id} | Üye Adresi Güncelleme
[**member_addresses_post**](MemberAddressApi.md#member_addresses_post) | **POST** /member_addresses | Üye Adresi Oluşturma


# **member_addresses_get**
> MemberAddress member_addresses_get(sort=sort, limit=limit, page=page, since_id=since_id, member=member, start_date=start_date, end_date=end_date)

Üye Adresi Listeleme

Üye Adresi listesi verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberAddressApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir (optional)
member = 56 # int | Üye id (optional)
start_date = '2013-10-20' # date | createdAt değeri için başlangıç tarihi (optional)
end_date = 'end_date_example' # str | createdAt değeri için bitiş tarihi (optional)

try:
    # Üye Adresi Listeleme
    api_response = api_instance.member_addresses_get(sort=sort, limit=limit, page=page, since_id=since_id, member=member, start_date=start_date, end_date=end_date)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MemberAddressApi->member_addresses_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional] 
 **member** | **int**| Üye id | [optional] 
 **start_date** | **date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **str**| createdAt değeri için bitiş tarihi | [optional] 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_addresses_id_delete**
> member_addresses_id_delete(id)

Üye Adresi Silme

Kalıcı olarak ilgili Üye Adresini siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberAddressApi(swagger_client.ApiClient(configuration))
id = 56 # int | Üye Adresi nesnesinin id değeri

try:
    # Üye Adresi Silme
    api_instance.member_addresses_id_delete(id)
except ApiException as e:
    print("Exception when calling MemberAddressApi->member_addresses_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Adresi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_addresses_id_get**
> MemberAddress member_addresses_id_get(id)

Üye Adresi Alma

İlgili Üye Adresini getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberAddressApi(swagger_client.ApiClient(configuration))
id = 56 # int | Üye Adresi nesnesinin id değeri

try:
    # Üye Adresi Alma
    api_response = api_instance.member_addresses_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MemberAddressApi->member_addresses_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Adresi nesnesinin id değeri | 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_addresses_id_put**
> MemberAddress member_addresses_id_put(id, member_address)

Üye Adresi Güncelleme

İlgili Üye Adresini günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberAddressApi(swagger_client.ApiClient(configuration))
id = 56 # int | Üye Adresi nesnesinin id değeri
member_address = swagger_client.MemberAddress() # MemberAddress | MemberAddress nesnesi

try:
    # Üye Adresi Güncelleme
    api_response = api_instance.member_addresses_id_put(id, member_address)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MemberAddressApi->member_addresses_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Adresi nesnesinin id değeri | 
 **member_address** | [**MemberAddress**](MemberAddress.md)| MemberAddress nesnesi | 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_addresses_post**
> MemberAddress member_addresses_post(member_address)

Üye Adresi Oluşturma

Yeni bir Üye Adresi oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberAddressApi(swagger_client.ApiClient(configuration))
member_address = swagger_client.MemberAddress() # MemberAddress | MemberAddress nesnesi

try:
    # Üye Adresi Oluşturma
    api_response = api_instance.member_addresses_post(member_address)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MemberAddressApi->member_addresses_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member_address** | [**MemberAddress**](MemberAddress.md)| MemberAddress nesnesi | 

### Return type

[**MemberAddress**](MemberAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

