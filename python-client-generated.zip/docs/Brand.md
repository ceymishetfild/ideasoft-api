# Brand

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Marka nesnesi kimlik değeri. | [optional] 
**name** | **str** | Marka nesnesi için isim değeri. | 
**slug** | **str** | Slug değeri ilgili nesnenin Url değeridir. | [optional] 
**sort_order** | **int** | Marka nesnesi için sıralama değeri. | [optional] 
**status** | **str** | Marka nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**distributor** | **str** | Markanın tedarikçisi. | [optional] 
**image_file** | **str** | Marka nesnesinin görselinin dosya adı. Geçerli dosya tipleri: .JPG, .PNG, .GIF | [optional] 
**showcase_content** | **str** | Marka nesnesinin üst içeriği. Admin paneli üzerinden düzenlenebilir. | [optional] 
**display_showcase_content** | **str** | Marka nesnesi üst içerik metninin gösterim durumu. | [optional] 
**meta_keywords** | **str** | Arama motorları tarafından tespit edilebilecek anahtar kelimeler. | [optional] 
**meta_description** | **str** | Arama motorları tarafından tespit edilebilecek açıklama yazısı. | [optional] 
**page_title** | **str** | Marka nesnesinin etiket başlığı. | [optional] 
**attachment** | **str** | Marka nesnesinin görselinin base64 formatına çevrilmiş resim kodu. PUT ve POST istekleri gerçekleştirlirken başında data:image/jpeg;base64, ibaresi bulunmak zorundadır. GET isteği esnasında bu değer görüntülenmeyecektir. | [optional] 
**created_at** | **datetime** | Marka nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **datetime** | Marka nesnesinin güncellenme zamanı. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


