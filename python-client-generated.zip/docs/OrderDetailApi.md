# swagger_client.OrderDetailApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**order_details_get**](OrderDetailApi.md#order_details_get) | **GET** /order_details | Sipariş Detayı Listesi Alma
[**order_details_id_delete**](OrderDetailApi.md#order_details_id_delete) | **DELETE** /order_details/{id} | Sipariş Detayı Silme
[**order_details_id_get**](OrderDetailApi.md#order_details_id_get) | **GET** /order_details/{id} | Sipariş Detayı Alma
[**order_details_id_put**](OrderDetailApi.md#order_details_id_put) | **PUT** /order_details/{id} | Sipariş Detayı Güncelleme
[**order_details_post**](OrderDetailApi.md#order_details_post) | **POST** /order_details | Sipariş Detayı Oluşturma


# **order_details_get**
> OrderDetail order_details_get(sort=sort, limit=limit, page=page, since_id=since_id, order=order)

Sipariş Detayı Listesi Alma

Sipariş Detayı listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderDetailApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
order = 56 # int | Sipariş id (optional)

try:
    # Sipariş Detayı Listesi Alma
    api_response = api_instance.order_details_get(sort=sort, limit=limit, page=page, since_id=since_id, order=order)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderDetailApi->order_details_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **int**| Sipariş id | [optional] 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_details_id_delete**
> order_details_id_delete(id)

Sipariş Detayı Silme

Kalıcı olarak ilgili Sipariş Detayı siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderDetailApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sipariş Detayı nesnesinin id değeri

try:
    # Sipariş Detayı Silme
    api_instance.order_details_id_delete(id)
except ApiException as e:
    print("Exception when calling OrderDetailApi->order_details_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Detayı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_details_id_get**
> OrderDetail order_details_id_get(id)

Sipariş Detayı Alma

İlgili Sipariş Detayı getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderDetailApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sipariş Detayı nesnesinin id değeri

try:
    # Sipariş Detayı Alma
    api_response = api_instance.order_details_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderDetailApi->order_details_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Detayı nesnesinin id değeri | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_details_id_put**
> OrderDetail order_details_id_put(id, order_detail)

Sipariş Detayı Güncelleme

İlgili Sipariş Detayı günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderDetailApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sipariş Detayı nesnesinin id değeri
order_detail = swagger_client.OrderDetail() # OrderDetail | OrderDetail nesnesi

try:
    # Sipariş Detayı Güncelleme
    api_response = api_instance.order_details_id_put(id, order_detail)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderDetailApi->order_details_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş Detayı nesnesinin id değeri | 
 **order_detail** | [**OrderDetail**](OrderDetail.md)| OrderDetail nesnesi | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_details_post**
> OrderDetail order_details_post(order_detail)

Sipariş Detayı Oluşturma

Yeni bir Sipariş Detayı oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderDetailApi(swagger_client.ApiClient(configuration))
order_detail = swagger_client.OrderDetail() # OrderDetail | OrderDetail nesnesi

try:
    # Sipariş Detayı Oluşturma
    api_response = api_instance.order_details_post(order_detail)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderDetailApi->order_details_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_detail** | [**OrderDetail**](OrderDetail.md)| OrderDetail nesnesi | 

### Return type

[**OrderDetail**](OrderDetail.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

