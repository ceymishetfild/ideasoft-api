# Location

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Şehir nesnesi kimlik değeri. | [optional] 
**name** | **str** | Şehir nesnesi için isim değeri. | 
**status** | **str** | Şehir nesnesinin aktiflik durumunu belirten değer. | 
**predefined** | **str** | Şehir nesnesinin öntanımlı olup olmadığını belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Öntanımlı şehir.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Yeni eklenmiş şehir.&lt;br&gt;&lt;/div&gt; | [optional] 
**country** | [**Country**](Country.md) | Ülke nesnesi. | [optional] 
**region** | [**Region**](Region.md) | Bölge nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


