# swagger_client.ThemeApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**themes_get**](ThemeApi.md#themes_get) | **GET** /themes | Tema Listesi Alma
[**themes_id_assets_get**](ThemeApi.md#themes_id_assets_get) | **GET** /themes/{id}/assets | Tema Dosyası Listesi Alma
[**themes_id_assetskeykey_delete**](ThemeApi.md#themes_id_assetskeykey_delete) | **DELETE** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Silme
[**themes_id_assetskeykey_get**](ThemeApi.md#themes_id_assetskeykey_get) | **GET** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Alma
[**themes_id_assetskeykey_put**](ThemeApi.md#themes_id_assetskeykey_put) | **PUT** /themes/{id}/assets?key&#x3D;{key} | Tema Dosyası Güncelleme
[**themes_id_delete**](ThemeApi.md#themes_id_delete) | **DELETE** /themes/{id} | Tema Silme
[**themes_id_get**](ThemeApi.md#themes_id_get) | **GET** /themes/{id} | Tema Alma
[**themes_id_put**](ThemeApi.md#themes_id_put) | **PUT** /themes/{id} | Tema Güncelleme
[**themes_post**](ThemeApi.md#themes_post) | **POST** /themes | Tema Oluşturma


# **themes_get**
> Theme themes_get(sort=sort, limit=limit, page=page, since_id=since_id, status=status, platform=platform, type=type)

Tema Listesi Alma

Tema listesi verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ThemeApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir (optional)
status = 56 # int | Tema durumu (optional)
platform = 'platform_example' # str | Tema platformu (optional)
type = 'type_example' # str | Tema tipi (optional)

try:
    # Tema Listesi Alma
    api_response = api_instance.themes_get(sort=sort, limit=limit, page=page, since_id=since_id, status=status, platform=platform, type=type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ThemeApi->themes_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional] 
 **status** | **int**| Tema durumu | [optional] 
 **platform** | **str**| Tema platformu | [optional] 
 **type** | **str**| Tema tipi | [optional] 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_id_assets_get**
> Asset themes_id_assets_get(id, key=key)

Tema Dosyası Listesi Alma

Tema Dosyası listesi verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ThemeApi(swagger_client.ApiClient(configuration))
id = 56 # int | Tema nesnesinin id değeri
key = 'key_example' # str | Tema Dosyası nesnesi anahtar değeri. (optional)

try:
    # Tema Dosyası Listesi Alma
    api_response = api_instance.themes_id_assets_get(id, key=key)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ThemeApi->themes_id_assets_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri | 
 **key** | **str**| Tema Dosyası nesnesi anahtar değeri. | [optional] 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_id_assetskeykey_delete**
> themes_id_assetskeykey_delete(id, key)

Tema Dosyası Silme

Kalıcı olarak ilgili Tema Dosyasını siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ThemeApi(swagger_client.ApiClient(configuration))
id = 56 # int | Tema nesnesinin id değeri
key = 'key_example' # str | Tema Dosyası nesnesi anahtar değeri.

try:
    # Tema Dosyası Silme
    api_instance.themes_id_assetskeykey_delete(id, key)
except ApiException as e:
    print("Exception when calling ThemeApi->themes_id_assetskeykey_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri | 
 **key** | **str**| Tema Dosyası nesnesi anahtar değeri. | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_id_assetskeykey_get**
> Asset themes_id_assetskeykey_get(id, key)

Tema Dosyası Alma

İlgili Tema Dosyasını getirir. Bunun için key sorgu parametresi zorunludur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ThemeApi(swagger_client.ApiClient(configuration))
id = 56 # int | Tema nesnesinin id değeri
key = 'key_example' # str | Tema Dosyası nesnesi anahtar değeri.

try:
    # Tema Dosyası Alma
    api_response = api_instance.themes_id_assetskeykey_get(id, key)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ThemeApi->themes_id_assetskeykey_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri | 
 **key** | **str**| Tema Dosyası nesnesi anahtar değeri. | 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_id_assetskeykey_put**
> Asset themes_id_assetskeykey_put(id, theme, asset)

Tema Dosyası Güncelleme

Bu operasyon eğer ilgili dosya sistemde yoksa ekler. İlgili klasör yoksa oluşturur. Eğer ilgili dosya varsa içeriğini günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ThemeApi(swagger_client.ApiClient(configuration))
id = 56 # int | Tema nesnesinin id değeri
theme = swagger_client.Theme() # Theme | Theme nesnesi
asset = swagger_client.Asset() # Asset | Asset nesnesi

try:
    # Tema Dosyası Güncelleme
    api_response = api_instance.themes_id_assetskeykey_put(id, theme, asset)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ThemeApi->themes_id_assetskeykey_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri | 
 **theme** | [**Theme**](Theme.md)| Theme nesnesi | 
 **asset** | [**Asset**](Asset.md)| Asset nesnesi | 

### Return type

[**Asset**](Asset.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_id_delete**
> themes_id_delete(id)

Tema Silme

Kalıcı olarak ilgili Temayı siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ThemeApi(swagger_client.ApiClient(configuration))
id = 56 # int | Tema nesnesinin id değeri

try:
    # Tema Silme
    api_instance.themes_id_delete(id)
except ApiException as e:
    print("Exception when calling ThemeApi->themes_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_id_get**
> Theme themes_id_get(id)

Tema Alma

İlgili Temayı getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ThemeApi(swagger_client.ApiClient(configuration))
id = 56 # int | Tema nesnesinin id değeri

try:
    # Tema Alma
    api_response = api_instance.themes_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ThemeApi->themes_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_id_put**
> Theme themes_id_put(id, theme)

Tema Güncelleme

İlgili Temayı günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ThemeApi(swagger_client.ApiClient(configuration))
id = 56 # int | Tema nesnesinin id değeri
theme = swagger_client.Theme() # Theme | Theme nesnesi

try:
    # Tema Güncelleme
    api_response = api_instance.themes_id_put(id, theme)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ThemeApi->themes_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Tema nesnesinin id değeri | 
 **theme** | [**Theme**](Theme.md)| Theme nesnesi | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **themes_post**
> Theme themes_post(theme)

Tema Oluşturma

Yeni bir tema oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ThemeApi(swagger_client.ApiClient(configuration))
theme = swagger_client.Theme() # Theme | Theme nesnesi

try:
    # Tema Oluşturma
    api_response = api_instance.themes_post(theme)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ThemeApi->themes_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **theme** | [**Theme**](Theme.md)| Theme nesnesi | 

### Return type

[**Theme**](Theme.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

