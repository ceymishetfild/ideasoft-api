# ProductProtection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Entegrasyon seçeneği nesnesi kimlik değeri. | [optional] 
**is_price_protected** | **str** | Ürün fiyatının korumalı olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Korumalı.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Korumasız.&lt;br&gt;&lt;/div&gt; | [optional] 
**is_stock_protected** | **str** | Ürün stoğunun korumalı olup olmadığı bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Korumalı.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Korumasız.&lt;br&gt;&lt;/div&gt; | [optional] 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


