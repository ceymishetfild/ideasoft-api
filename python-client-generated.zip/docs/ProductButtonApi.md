# swagger_client.ProductButtonApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_buttons_get**](ProductButtonApi.md#product_buttons_get) | **GET** /product_buttons | Ürün ve Stok Butonu Listesi Alma
[**product_buttons_id_delete**](ProductButtonApi.md#product_buttons_id_delete) | **DELETE** /product_buttons/{id} | Ürün ve Stok Butonu Silme
[**product_buttons_id_get**](ProductButtonApi.md#product_buttons_id_get) | **GET** /product_buttons/{id} | Ürün ve Stok Butonu Alma
[**product_buttons_id_put**](ProductButtonApi.md#product_buttons_id_put) | **PUT** /product_buttons/{id} | Ürün ve Stok Butonu Güncelleme
[**product_buttons_post**](ProductButtonApi.md#product_buttons_post) | **POST** /product_buttons | Ürün ve Stok Butonu Oluşturma


# **product_buttons_get**
> ProductButton product_buttons_get(sort=sort, limit=limit, page=page, since_id=since_id, fast_shipping=fast_shipping, same_day_shipping=same_day_shipping, three_days_delivery=three_days_delivery, five_days_delivery=five_days_delivery, seven_days_delivery=seven_days_delivery, free_shipping=free_shipping, delivery_from_stock=delivery_from_stock, pre_ordered_product=pre_ordered_product, ask_stock=ask_stock, campaigned_product=campaigned_product, product=product)

Ürün ve Stok Butonu Listesi Alma

Ürün ve Stok Butonu listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductButtonApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
fast_shipping = 56 # int | Hızlı Gönderi butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
same_day_shipping = 56 # int | Aynı Gün Kargo butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
three_days_delivery = 56 # int | 3 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
five_days_delivery = 56 # int | 5 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
seven_days_delivery = 56 # int | 7 Günde Teslimat butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
free_shipping = 56 # int | Kargo Bedava butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
delivery_from_stock = 56 # int | Stoktan Teslim butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
pre_ordered_product = 56 # int | Ön Siparişli Ürün butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
ask_stock = 56 # int | Stok Sorunuz butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
campaigned_product = 56 # int | Kampanyalı Ürün butonuna sahip ürünler<code>0</code><br><code>1</code> (optional)
product = 56 # int | Ürün id (optional)

try:
    # Ürün ve Stok Butonu Listesi Alma
    api_response = api_instance.product_buttons_get(sort=sort, limit=limit, page=page, since_id=since_id, fast_shipping=fast_shipping, same_day_shipping=same_day_shipping, three_days_delivery=three_days_delivery, five_days_delivery=five_days_delivery, seven_days_delivery=seven_days_delivery, free_shipping=free_shipping, delivery_from_stock=delivery_from_stock, pre_ordered_product=pre_ordered_product, ask_stock=ask_stock, campaigned_product=campaigned_product, product=product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductButtonApi->product_buttons_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **fast_shipping** | **int**| Hızlı Gönderi butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **same_day_shipping** | **int**| Aynı Gün Kargo butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **three_days_delivery** | **int**| 3 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **five_days_delivery** | **int**| 5 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **seven_days_delivery** | **int**| 7 Günde Teslimat butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **free_shipping** | **int**| Kargo Bedava butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **delivery_from_stock** | **int**| Stoktan Teslim butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **pre_ordered_product** | **int**| Ön Siparişli Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **ask_stock** | **int**| Stok Sorunuz butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **campaigned_product** | **int**| Kampanyalı Ürün butonuna sahip ürünler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **product** | **int**| Ürün id | [optional] 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_buttons_id_delete**
> product_buttons_id_delete(id)

Ürün ve Stok Butonu Silme

Kalıcı olarak ilgili Ürün ve Stok Butonunu siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductButtonApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün ve Stok Butonu nesnesinin id değeri

try:
    # Ürün ve Stok Butonu Silme
    api_instance.product_buttons_id_delete(id)
except ApiException as e:
    print("Exception when calling ProductButtonApi->product_buttons_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_buttons_id_get**
> ProductButton product_buttons_id_get(id)

Ürün ve Stok Butonu Alma

İlgili Ürün ve Stok Butonunu getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductButtonApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün ve Stok Butonu nesnesinin id değeri

try:
    # Ürün ve Stok Butonu Alma
    api_response = api_instance.product_buttons_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductButtonApi->product_buttons_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün ve Stok Butonu nesnesinin id değeri | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_buttons_id_put**
> ProductButton product_buttons_id_put(id, product_button)

Ürün ve Stok Butonu Güncelleme

İlgili Ürün ve Stok Butonunu günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductButtonApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün ve Stok Butonu nesnesinin id değeri
product_button = swagger_client.ProductButton() # ProductButton | ProductButton nesnesi

try:
    # Ürün ve Stok Butonu Güncelleme
    api_response = api_instance.product_buttons_id_put(id, product_button)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductButtonApi->product_buttons_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün ve Stok Butonu nesnesinin id değeri | 
 **product_button** | [**ProductButton**](ProductButton.md)| ProductButton nesnesi | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_buttons_post**
> ProductButton product_buttons_post(product_button)

Ürün ve Stok Butonu Oluşturma

Yeni bir Ürün ve Stok Butonu oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductButtonApi(swagger_client.ApiClient(configuration))
product_button = swagger_client.ProductButton() # ProductButton | ProductButton nesnesi

try:
    # Ürün ve Stok Butonu Oluşturma
    api_response = api_instance.product_buttons_post(product_button)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductButtonApi->product_buttons_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_button** | [**ProductButton**](ProductButton.md)| ProductButton nesnesi | 

### Return type

[**ProductButton**](ProductButton.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

