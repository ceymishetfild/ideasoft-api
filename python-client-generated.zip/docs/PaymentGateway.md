# PaymentGateway

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ödeme kanalı nesnesi kimlik değeri. | [optional] 
**code** | **str** | Ödeme kanalı için ön tanımlanmış kod değeri. | 
**name** | **str** | Ödeme kanalı nesnesi için isim değeri. | 
**status** | **str** | Ödeme kanalının aktiflik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;active&lt;/code&gt; : Aktif&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif&lt;br&gt;&lt;/div&gt; | 
**sort_order** | **int** | Ödeme kanalı nesnesi için sıralama değeri. | [optional] 
**payment_provider** | [**PaymentProvider**](PaymentProvider.md) |  | [optional] 
**settings** | [**list[PaymentGatewaySetting]**](PaymentGatewaySetting.md) | Ödeme kanalı ayarları. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


