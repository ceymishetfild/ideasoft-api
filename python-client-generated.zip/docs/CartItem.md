# CartItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sepet kalemi nesnesi kimlik değeri. | [optional] 
**parent_product_id** | **int** | Ana ürünün benzersiz rakamsal kimlik değeri. | [optional] 
**quantity** | **float** | Sepetteki kalem adedi. | 
**category_id** | **int** | Sepetteki kaleme ait kategorinin benzersiz kimlik değeri. | [optional] 
**created_at** | **datetime** | Sepet kalemi nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **datetime** | Sepet kalemi nesnesinin güncellenme zamanı. | [optional] 
**cart** | [**Cart**](Cart.md) | Sepet nesnesi. | 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 
**attributes** | [**list[CartItemAttribute]**](CartItemAttribute.md) | Sepet kalemi özelliği barındıran liste. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


