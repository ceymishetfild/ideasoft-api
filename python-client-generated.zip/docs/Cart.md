# Cart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sepet nesnesi kimlik değeri. | [optional] 
**session_id** | **str** | Sepetin son durumunu belirten ilgili nesnenin benzersiz kimlik değeri. | 
**locked** | **str** | Sepetin kilitli olup olmama durumunu belirten değer. Kilitli sepetler üzerinde işlem yapılamaz. | [optional] 
**created_at** | **datetime** | Sepet nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **datetime** | Sepet nesnesinin güncellenme zamanı. | [optional] 
**chosen_promotion** | [**ShopCampaigns**](ShopCampaigns.md) | Promosyon nesnesi. | [optional] 
**member** | [**Member**](Member.md) | Üye nesnesi. | [optional] 
**chosen_token** | [**ShopTokens**](ShopTokens.md) | Hediye çeki nesnesi. | [optional] 
**items** | [**list[CartItem]**](CartItem.md) | Sepet kalemi nesnelerini barındıran liste. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


