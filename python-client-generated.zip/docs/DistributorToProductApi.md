# swagger_client.DistributorToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**distributor_to_products_get**](DistributorToProductApi.md#distributor_to_products_get) | **GET** /distributor_to_products | Distribütör Ürün Bağı Listesi Alma
[**distributor_to_products_id_delete**](DistributorToProductApi.md#distributor_to_products_id_delete) | **DELETE** /distributor_to_products/{id} | Distribütör Ürün Bağı Silme
[**distributor_to_products_id_get**](DistributorToProductApi.md#distributor_to_products_id_get) | **GET** /distributor_to_products/{id} | Distribütör Ürün Bağı Alma
[**distributor_to_products_id_put**](DistributorToProductApi.md#distributor_to_products_id_put) | **PUT** /distributor_to_products/{id} | Distribütör Ürün Bağı Güncelleme
[**distributor_to_products_post**](DistributorToProductApi.md#distributor_to_products_post) | **POST** /distributor_to_products | Distribütör Ürün Bağı Oluşturma


# **distributor_to_products_get**
> DistributorToProduct distributor_to_products_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, distributor=distributor, product=product)

Distribütör Ürün Bağı Listesi Alma

Distribütör Ürün Bağı listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DistributorToProductApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
distributor = 56 # int | Distribütör id (optional)
product = 56 # int | Ürün id (optional)

try:
    # Distribütör Ürün Bağı Listesi Alma
    api_response = api_instance.distributor_to_products_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, distributor=distributor, product=product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DistributorToProductApi->distributor_to_products_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **distributor** | **int**| Distribütör id | [optional] 
 **product** | **int**| Ürün id | [optional] 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributor_to_products_id_delete**
> distributor_to_products_id_delete(id)

Distribütör Ürün Bağı Silme

Kalıcı olarak ilgili Distribütör Ürün Bağını siler

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DistributorToProductApi(swagger_client.ApiClient(configuration))
id = 56 # int | Distribütör Ürün Bağı nesnesinin id değeri

try:
    # Distribütör Ürün Bağı Silme
    api_instance.distributor_to_products_id_delete(id)
except ApiException as e:
    print("Exception when calling DistributorToProductApi->distributor_to_products_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Distribütör Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributor_to_products_id_get**
> DistributorToProduct distributor_to_products_id_get(id)

Distribütör Ürün Bağı Alma

İlgili Distribütör Ürün Bağını getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DistributorToProductApi(swagger_client.ApiClient(configuration))
id = 56 # int | Distribütör Ürün Bağı nesnesinin id değeri

try:
    # Distribütör Ürün Bağı Alma
    api_response = api_instance.distributor_to_products_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DistributorToProductApi->distributor_to_products_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Distribütör Ürün Bağı nesnesinin id değeri | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributor_to_products_id_put**
> DistributorToProduct distributor_to_products_id_put(id, distributor_to_product)

Distribütör Ürün Bağı Güncelleme

İlgili Distribütör Ürün Bağını günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DistributorToProductApi(swagger_client.ApiClient(configuration))
id = 56 # int | Distribütör Ürün Bağı nesnesinin id değeri
distributor_to_product = swagger_client.DistributorToProduct() # DistributorToProduct |  nesnesi

try:
    # Distribütör Ürün Bağı Güncelleme
    api_response = api_instance.distributor_to_products_id_put(id, distributor_to_product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DistributorToProductApi->distributor_to_products_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Distribütör Ürün Bağı nesnesinin id değeri | 
 **distributor_to_product** | [**DistributorToProduct**](DistributorToProduct.md)|  nesnesi | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **distributor_to_products_post**
> DistributorToProduct distributor_to_products_post(distributor_to_product)

Distribütör Ürün Bağı Oluşturma

Yeni bir Distribütör Ürün Bağı oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.DistributorToProductApi(swagger_client.ApiClient(configuration))
distributor_to_product = swagger_client.DistributorToProduct() # DistributorToProduct |  nesnesi

try:
    # Distribütör Ürün Bağı Oluşturma
    api_response = api_instance.distributor_to_products_post(distributor_to_product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DistributorToProductApi->distributor_to_products_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **distributor_to_product** | [**DistributorToProduct**](DistributorToProduct.md)|  nesnesi | 

### Return type

[**DistributorToProduct**](DistributorToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

