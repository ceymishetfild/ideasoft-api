# swagger_client.LocationApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**locations_get**](LocationApi.md#locations_get) | **GET** /locations | Şehir Listesi Alma
[**locations_id_get**](LocationApi.md#locations_id_get) | **GET** /locations/{id} | Şehir Alma


# **locations_get**
> Location locations_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name, country=country, region=region)

Şehir Listesi Alma

Şehir listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.LocationApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
name = 'name_example' # str | Şehir adı (optional)
country = 56 # int | Ülke id (optional)
region = 56 # int | Bölge id (optional)

try:
    # Şehir Listesi Alma
    api_response = api_instance.locations_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name, country=country, region=region)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling LocationApi->locations_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **str**| Şehir adı | [optional] 
 **country** | **int**| Ülke id | [optional] 
 **region** | **int**| Bölge id | [optional] 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **locations_id_get**
> Location locations_id_get(id)

Şehir Alma

İlgili Şehir getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.LocationApi(swagger_client.ApiClient(configuration))
id = 56 # int | Şehir nesnesinin id değeri

try:
    # Şehir Alma
    api_response = api_instance.locations_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling LocationApi->locations_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Şehir nesnesinin id değeri | 

### Return type

[**Location**](Location.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

