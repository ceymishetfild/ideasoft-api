# PaymentProviderSetting

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ödeme altyapısı sağlayıcısı ayarı nesnesi kimlik değeri. | [optional] 
**var_key** | **str** | Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken anahtarı. | 
**var_value** | **str** | Ödeme altyapısı sağlayıcısı ayarı nesnesi için değişken değeri. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


