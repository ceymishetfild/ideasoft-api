# ShippingProvider

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Teslimat hizmeti sağlayıcısı nesnesi kimlik değeri. | [optional] 
**code** | **str** | Teslimat hizmeti sağlayıcısı kodu. Benzersiz olmalıdır. | 
**name** | **str** | Teslimat hizmeti sağlayıcısı nesnesi için isim değeri. | 
**tracking_url** | **str** | Kargo takip url. | 
**tracking_form_method** | **str** | Kargo takip formu almak için kullanılacak method.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;get&lt;/code&gt; : GET methodu.&lt;br&gt;&lt;code&gt;post&lt;/code&gt; : POST methodu.&lt;br&gt;&lt;/div&gt; | [optional] 
**payload** | **str** | İlgili kargo takip formu almak için kullanılacak yük. | [optional] 
**settings** | [**list[ShippingProviderSetting]**](ShippingProviderSetting.md) | Teslimat hizmeti sağlayıcısı için ayarlar. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


