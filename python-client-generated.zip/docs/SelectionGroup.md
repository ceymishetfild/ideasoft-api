# SelectionGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ek özellik grubu nesnesi kimlik değeri. | [optional] 
**title** | **str** | Ek özellik grubu nesnesinin başlığı. | 
**sort_order** | **int** | Ek özellik grubu nesnesi için sıralama değeri. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


