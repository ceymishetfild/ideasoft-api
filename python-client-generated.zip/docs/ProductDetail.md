# ProductDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ürün detayı nesnesi kimlik değeri. | [optional] 
**sku** | **str** | Ürünün stok kodu. | [optional] 
**details** | **str** | Detay bilgisi. | [optional] 
**extra_details** | **str** | Ürün ekstra detaylı bilgi. | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


