# swagger_client.BillingAddressApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**billing_addresses_get**](BillingAddressApi.md#billing_addresses_get) | **GET** /billing_addresses | Fatura Adresi Listesi Alma
[**billing_addresses_id_get**](BillingAddressApi.md#billing_addresses_id_get) | **GET** /billing_addresses/{id} | Fatura Adresi Alma
[**billing_addresses_id_put**](BillingAddressApi.md#billing_addresses_id_put) | **PUT** /billing_addresses/{id} | Fatura Adresi Güncelleme
[**billing_addresses_post**](BillingAddressApi.md#billing_addresses_post) | **POST** /billing_addresses | Fatura Adresi Oluşturma


# **billing_addresses_get**
> BillingAddress billing_addresses_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, order=order, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)

Fatura Adresi Listesi Alma

Fatura Adresi listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BillingAddressApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
order = 56 # int | Sipariş id (optional)
start_date = '2013-10-20' # date | createdAt değeri için başlangıç tarihi (optional)
end_date = 'end_date_example' # str | createdAt değeri için bitiş tarihi (optional)
start_updated_at = '2013-10-20' # date | updatedAt değeri için başlangıç tarihi (optional)
end_updated_at = 'end_updated_at_example' # str | updatedAt değeri için bitiş tarihi (optional)

try:
    # Fatura Adresi Listesi Alma
    api_response = api_instance.billing_addresses_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, order=order, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BillingAddressApi->billing_addresses_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **order** | **int**| Sipariş id | [optional] 
 **start_date** | **date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **str**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **str**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **billing_addresses_id_get**
> BillingAddress billing_addresses_id_get(id)

Fatura Adresi Alma

İlgili Fatura Adresini getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BillingAddressApi(swagger_client.ApiClient(configuration))
id = 56 # int | Fatura Adresi nesnesinin id değeri

try:
    # Fatura Adresi Alma
    api_response = api_instance.billing_addresses_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BillingAddressApi->billing_addresses_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Fatura Adresi nesnesinin id değeri | 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **billing_addresses_id_put**
> BillingAddress billing_addresses_id_put(id, billing_address)

Fatura Adresi Güncelleme

İlgili Fatura Adresini günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BillingAddressApi(swagger_client.ApiClient(configuration))
id = 56 # int | Fatura Adresi nesnesinin id değeri
billing_address = swagger_client.BillingAddress() # BillingAddress |  nesnesi

try:
    # Fatura Adresi Güncelleme
    api_response = api_instance.billing_addresses_id_put(id, billing_address)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BillingAddressApi->billing_addresses_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Fatura Adresi nesnesinin id değeri | 
 **billing_address** | [**BillingAddress**](BillingAddress.md)|  nesnesi | 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **billing_addresses_post**
> BillingAddress billing_addresses_post(billing_address)

Fatura Adresi Oluşturma

Yeni bir Fatura Adresi oluşturur. Fatura Adresi oluşturabilmek için geçerli bir önceden tanımlanmış Sipariş id değerine ihtiyaç vardır.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BillingAddressApi(swagger_client.ApiClient(configuration))
billing_address = swagger_client.BillingAddress() # BillingAddress |  nesnesi

try:
    # Fatura Adresi Oluşturma
    api_response = api_instance.billing_addresses_post(billing_address)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BillingAddressApi->billing_addresses_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **billing_address** | [**BillingAddress**](BillingAddress.md)|  nesnesi | 

### Return type

[**BillingAddress**](BillingAddress.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

