# Shipment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Teslimat nesnesi kimlik değeri. | [optional] 
**barcode** | **str** | Teslimat barkodu. | [optional] 
**waybill_no** | **str** | Teslimat fatura numarası. | [optional] 
**invoice_key** | **str** | Teslimat irsaliye makbuzu numarası. | [optional] 
**cargo_office** | **str** | Teslimatın kargo şubesi | [optional] 
**code** | **str** | Teslimat kodu. Kargo takip kodu. | [optional] 
**delivery_type** | **str** | Teslimat tipi | [optional] 
**invoice_included** | **str** | Faturanın pakete dahillik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Dahil.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Dahil değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**pay_at_door_amount** | **float** | Kapıda ödeme hizmeti bedeli. | [optional] 
**created_at** | **datetime** | Teslimat nesnesinin oluşturulma zamanı. | [optional] 
**status** | **int** | Teslimat nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**order** | [**Order**](Order.md) | Sipariş nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


