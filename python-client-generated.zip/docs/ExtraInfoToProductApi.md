# swagger_client.ExtraInfoToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extra_info_to_products_get**](ExtraInfoToProductApi.md#extra_info_to_products_get) | **GET** /extra_info_to_products | Ek Bilgi Ürün Bağı Listesi Alma
[**extra_info_to_products_id_delete**](ExtraInfoToProductApi.md#extra_info_to_products_id_delete) | **DELETE** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Silme
[**extra_info_to_products_id_get**](ExtraInfoToProductApi.md#extra_info_to_products_id_get) | **GET** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Alma
[**extra_info_to_products_id_put**](ExtraInfoToProductApi.md#extra_info_to_products_id_put) | **PUT** /extra_info_to_products/{id} | Ek Bilgi Ürün Bağı Güncelleme
[**extra_info_to_products_post**](ExtraInfoToProductApi.md#extra_info_to_products_post) | **POST** /extra_info_to_products | Ek Bilgi Ürün Bağı Oluşturma


# **extra_info_to_products_get**
> ExtraInfoToProduct extra_info_to_products_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, extra_info=extra_info, product=product)

Ek Bilgi Ürün Bağı Listesi Alma

Ek Bilgi Ürün Bağı listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ExtraInfoToProductApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
extra_info = 56 # int | Ek bilgi id (optional)
product = 56 # int | Ürün id (optional)

try:
    # Ek Bilgi Ürün Bağı Listesi Alma
    api_response = api_instance.extra_info_to_products_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, extra_info=extra_info, product=product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ExtraInfoToProductApi->extra_info_to_products_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **extra_info** | **int**| Ek bilgi id | [optional] 
 **product** | **int**| Ürün id | [optional] 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_info_to_products_id_delete**
> extra_info_to_products_id_delete(id)

Ek Bilgi Ürün Bağı Silme

Kalıcı olarak ilgili Ek Bilgi Ürün Bağını siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ExtraInfoToProductApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ek Bilgi Ürün Bağı nesnesinin id değeri

try:
    # Ek Bilgi Ürün Bağı Silme
    api_instance.extra_info_to_products_id_delete(id)
except ApiException as e:
    print("Exception when calling ExtraInfoToProductApi->extra_info_to_products_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_info_to_products_id_get**
> ExtraInfoToProduct extra_info_to_products_id_get(id)

Ek Bilgi Ürün Bağı Alma

İlgili Ek Bilgi Ürün Bağını getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ExtraInfoToProductApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ek Bilgi Ürün Bağı nesnesinin id değeri

try:
    # Ek Bilgi Ürün Bağı Alma
    api_response = api_instance.extra_info_to_products_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ExtraInfoToProductApi->extra_info_to_products_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_info_to_products_id_put**
> ExtraInfoToProduct extra_info_to_products_id_put(id, extra_info_to_product)

Ek Bilgi Ürün Bağı Güncelleme

İlgili Ek Bilgi Ürün Bağını günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ExtraInfoToProductApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ek Bilgi Ürün Bağı nesnesinin id değeri
extra_info_to_product = swagger_client.ExtraInfoToProduct() # ExtraInfoToProduct |  nesnesi

try:
    # Ek Bilgi Ürün Bağı Güncelleme
    api_response = api_instance.extra_info_to_products_id_put(id, extra_info_to_product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ExtraInfoToProductApi->extra_info_to_products_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi Ürün Bağı nesnesinin id değeri | 
 **extra_info_to_product** | [**ExtraInfoToProduct**](ExtraInfoToProduct.md)|  nesnesi | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_info_to_products_post**
> ExtraInfoToProduct extra_info_to_products_post(extra_info_to_product)

Ek Bilgi Ürün Bağı Oluşturma

Yeni bir Ek Bilgi Ürün Bağı oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ExtraInfoToProductApi(swagger_client.ApiClient(configuration))
extra_info_to_product = swagger_client.ExtraInfoToProduct() # ExtraInfoToProduct |  nesnesi

try:
    # Ek Bilgi Ürün Bağı Oluşturma
    api_response = api_instance.extra_info_to_products_post(extra_info_to_product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ExtraInfoToProductApi->extra_info_to_products_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extra_info_to_product** | [**ExtraInfoToProduct**](ExtraInfoToProduct.md)|  nesnesi | 

### Return type

[**ExtraInfoToProduct**](ExtraInfoToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

