# swagger_client.OrderRefundRequestItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**order_refund_request_items_get**](OrderRefundRequestItemApi.md#order_refund_request_items_get) | **GET** /order_refund_request_items | Sipariş İptal Talebi Kalemi Listesi Alma
[**order_refund_request_items_id_delete**](OrderRefundRequestItemApi.md#order_refund_request_items_id_delete) | **DELETE** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Silme
[**order_refund_request_items_id_get**](OrderRefundRequestItemApi.md#order_refund_request_items_id_get) | **GET** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Alma
[**order_refund_request_items_id_put**](OrderRefundRequestItemApi.md#order_refund_request_items_id_put) | **PUT** /order_refund_request_items/{id} | Sipariş İptal Talebi Kalemi Güncelleme
[**order_refund_request_items_post**](OrderRefundRequestItemApi.md#order_refund_request_items_post) | **POST** /order_refund_request_items | Sipariş İptal Talebi Kalemi Oluşturma


# **order_refund_request_items_get**
> OrderRefundRequestItem order_refund_request_items_get(sort=sort, limit=limit, page=page, since_id=since_id, order_refund_request=order_refund_request, order_item=order_item, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)

Sipariş İptal Talebi Kalemi Listesi Alma

Sipariş İptal Talebi Kalemi listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderRefundRequestItemApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
order_refund_request = 56 # int | Sipariş iptal talebi id (optional)
order_item = 56 # int | Sipariş ürünü id (optional)
start_date = '2013-10-20' # date | createdAt değeri için başlangıç tarihi (optional)
end_date = 'end_date_example' # str | createdAt değeri için bitiş tarihi (optional)
start_updated_at = '2013-10-20' # date | updatedAt değeri için başlangıç tarihi (optional)
end_updated_at = 'end_updated_at_example' # str | updatedAt değeri için bitiş tarihi (optional)

try:
    # Sipariş İptal Talebi Kalemi Listesi Alma
    api_response = api_instance.order_refund_request_items_get(sort=sort, limit=limit, page=page, since_id=since_id, order_refund_request=order_refund_request, order_item=order_item, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderRefundRequestItemApi->order_refund_request_items_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order_refund_request** | **int**| Sipariş iptal talebi id | [optional] 
 **order_item** | **int**| Sipariş ürünü id | [optional] 
 **start_date** | **date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **str**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **str**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_refund_request_items_id_delete**
> order_refund_request_items_id_delete(id)

Sipariş İptal Talebi Kalemi Silme

Kalıcı olarak ilgili Sipariş İptal Talebi Kalemini siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderRefundRequestItemApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sipariş İptal Talebi Kalemi nesnesinin id değeri

try:
    # Sipariş İptal Talebi Kalemi Silme
    api_instance.order_refund_request_items_id_delete(id)
except ApiException as e:
    print("Exception when calling OrderRefundRequestItemApi->order_refund_request_items_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş İptal Talebi Kalemi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_refund_request_items_id_get**
> OrderRefundRequestItem order_refund_request_items_id_get(id)

Sipariş İptal Talebi Kalemi Alma

İlgili Sipariş İptal Talebi Kalemini getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderRefundRequestItemApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sipariş İptal Talebi Kalemi nesnesinin id değeri

try:
    # Sipariş İptal Talebi Kalemi Alma
    api_response = api_instance.order_refund_request_items_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderRefundRequestItemApi->order_refund_request_items_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş İptal Talebi Kalemi nesnesinin id değeri | 

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_refund_request_items_id_put**
> OrderRefundRequestItem order_refund_request_items_id_put(id, order_refund_request_item)

Sipariş İptal Talebi Kalemi Güncelleme

İlgili Sipariş İptal Talebi Kalemini günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderRefundRequestItemApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sipariş İptal Talebi Kalemi nesnesinin id değeri
order_refund_request_item = swagger_client.OrderRefundRequestItem() # OrderRefundRequestItem | OrderRefundRequestItem nesnesi

try:
    # Sipariş İptal Talebi Kalemi Güncelleme
    api_response = api_instance.order_refund_request_items_id_put(id, order_refund_request_item)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderRefundRequestItemApi->order_refund_request_items_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş İptal Talebi Kalemi nesnesinin id değeri | 
 **order_refund_request_item** | [**OrderRefundRequestItem**](OrderRefundRequestItem.md)| OrderRefundRequestItem nesnesi | 

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_refund_request_items_post**
> OrderRefundRequestItem order_refund_request_items_post(order_refund_request_item)

Sipariş İptal Talebi Kalemi Oluşturma

Yeni bir Sipariş İptal Talebi Kalemi oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderRefundRequestItemApi(swagger_client.ApiClient(configuration))
order_refund_request_item = swagger_client.OrderRefundRequestItem() # OrderRefundRequestItem | OrderRefundRequestItem nesnesi

try:
    # Sipariş İptal Talebi Kalemi Oluşturma
    api_response = api_instance.order_refund_request_items_post(order_refund_request_item)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderRefundRequestItemApi->order_refund_request_items_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_refund_request_item** | [**OrderRefundRequestItem**](OrderRefundRequestItem.md)| OrderRefundRequestItem nesnesi | 

### Return type

[**OrderRefundRequestItem**](OrderRefundRequestItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

