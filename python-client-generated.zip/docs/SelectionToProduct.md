# SelectionToProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ek özellik ürün bağı nesnesi kimlik değeri. | [optional] 
**selection** | [**Selection**](Selection.md) | Ek özellik nesnesi. | 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


