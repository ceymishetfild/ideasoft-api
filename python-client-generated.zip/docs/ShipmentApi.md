# swagger_client.ShipmentApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**shipments_get**](ShipmentApi.md#shipments_get) | **GET** /shipments | Teslimat Listesi Alma
[**shipments_id_delete**](ShipmentApi.md#shipments_id_delete) | **DELETE** /shipments/{id} | Teslimat Silme
[**shipments_id_get**](ShipmentApi.md#shipments_id_get) | **GET** /shipments/{id} | Teslimat Alma
[**shipments_id_put**](ShipmentApi.md#shipments_id_put) | **PUT** /shipments/{id} | Teslimat Güncelleme
[**shipments_post**](ShipmentApi.md#shipments_post) | **POST** /shipments | Teslimat Oluşturma


# **shipments_get**
> Shipment shipments_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, code=code, invoice_key=invoice_key, barcode=barcode, order=order, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)

Teslimat Listesi Alma

Teslimat listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ShipmentApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
code = 'code_example' # str | Teslimat kodu (optional)
invoice_key = 'invoice_key_example' # str | Teslimat fatura anahtarı (optional)
barcode = 'barcode_example' # str | Teslimat barkodu (optional)
order = 56 # int | Sipariş id (optional)
start_date = '2013-10-20' # date | createdAt değeri için başlangıç tarihi (optional)
end_date = 'end_date_example' # str | createdAt değeri için bitiş tarihi (optional)
start_updated_at = '2013-10-20' # date | updatedAt değeri için başlangıç tarihi (optional)
end_updated_at = 'end_updated_at_example' # str | updatedAt değeri için bitiş tarihi (optional)

try:
    # Teslimat Listesi Alma
    api_response = api_instance.shipments_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, code=code, invoice_key=invoice_key, barcode=barcode, order=order, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ShipmentApi->shipments_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **code** | **str**| Teslimat kodu | [optional] 
 **invoice_key** | **str**| Teslimat fatura anahtarı | [optional] 
 **barcode** | **str**| Teslimat barkodu | [optional] 
 **order** | **int**| Sipariş id | [optional] 
 **start_date** | **date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **str**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **str**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipments_id_delete**
> shipments_id_delete(id)

Teslimat Silme

Kalıcı olarak ilgili Teslimatı siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ShipmentApi(swagger_client.ApiClient(configuration))
id = 56 # int | Teslimat nesnesinin id değeri

try:
    # Teslimat Silme
    api_instance.shipments_id_delete(id)
except ApiException as e:
    print("Exception when calling ShipmentApi->shipments_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Teslimat nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipments_id_get**
> Shipment shipments_id_get(id)

Teslimat Alma

İlgili Teslimatı getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ShipmentApi(swagger_client.ApiClient(configuration))
id = 56 # int | Teslimat nesnesinin id değeri

try:
    # Teslimat Alma
    api_response = api_instance.shipments_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ShipmentApi->shipments_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Teslimat nesnesinin id değeri | 

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipments_id_put**
> Shipment shipments_id_put(id, shipment)

Teslimat Güncelleme

İlgili Teslimatı günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ShipmentApi(swagger_client.ApiClient(configuration))
id = 56 # int | Teslimat nesnesinin id değeri
shipment = swagger_client.Shipment() # Shipment |  nesnesi

try:
    # Teslimat Güncelleme
    api_response = api_instance.shipments_id_put(id, shipment)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ShipmentApi->shipments_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Teslimat nesnesinin id değeri | 
 **shipment** | [**Shipment**](Shipment.md)|  nesnesi | 

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **shipments_post**
> Shipment shipments_post(shipment)

Teslimat Oluşturma

Yeni bir Teslimat oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ShipmentApi(swagger_client.ApiClient(configuration))
shipment = swagger_client.Shipment() # Shipment |  nesnesi

try:
    # Teslimat Oluşturma
    api_response = api_instance.shipments_post(shipment)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ShipmentApi->shipments_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **shipment** | [**Shipment**](Shipment.md)|  nesnesi | 

### Return type

[**Shipment**](Shipment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

