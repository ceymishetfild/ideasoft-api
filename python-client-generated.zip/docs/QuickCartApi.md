# swagger_client.QuickCartApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**quick_carts_get**](QuickCartApi.md#quick_carts_get) | **GET** /quick_carts | Hızlı Satın Al Bağlantısı Alma
[**quick_carts_id_delete**](QuickCartApi.md#quick_carts_id_delete) | **DELETE** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Silme
[**quick_carts_id_get**](QuickCartApi.md#quick_carts_id_get) | **GET** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Alma
[**quick_carts_id_put**](QuickCartApi.md#quick_carts_id_put) | **PUT** /quick_carts/{id} | Hızlı Satın Al Bağlantısı Güncelleme
[**quick_carts_post**](QuickCartApi.md#quick_carts_post) | **POST** /quick_carts | Hızlı Satın Al Bağlantısı Oluşturma


# **quick_carts_get**
> QuickCart quick_carts_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, name=name)

Hızlı Satın Al Bağlantısı Alma

Hızlı Satın Al Bağlantısı döndürür.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.QuickCartApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
name = 'name_example' # str | Hızlı Satın Al Bağlantısı adı (optional)

try:
    # Hızlı Satın Al Bağlantısı Alma
    api_response = api_instance.quick_carts_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, name=name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling QuickCartApi->quick_carts_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **str**| Hızlı Satın Al Bağlantısı adı | [optional] 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **quick_carts_id_delete**
> quick_carts_id_delete(id)

Hızlı Satın Al Bağlantısı Silme

Kalıcı olarak ilgili Hızlı Satın Al Bağlantısını siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.QuickCartApi(swagger_client.ApiClient(configuration))
id = 56 # int | Hızlı Satın Al nesnesinin id değeri

try:
    # Hızlı Satın Al Bağlantısı Silme
    api_instance.quick_carts_id_delete(id)
except ApiException as e:
    print("Exception when calling QuickCartApi->quick_carts_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Hızlı Satın Al nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **quick_carts_id_get**
> QuickCart quick_carts_id_get(id)

Hızlı Satın Al Bağlantısı Alma

İlgili Hızlı Satın Al Bağlantısını getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.QuickCartApi(swagger_client.ApiClient(configuration))
id = 56 # int | Hızlı Satın Al nesnesinin id değeri

try:
    # Hızlı Satın Al Bağlantısı Alma
    api_response = api_instance.quick_carts_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling QuickCartApi->quick_carts_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Hızlı Satın Al nesnesinin id değeri | 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **quick_carts_id_put**
> QuickCart quick_carts_id_put(id, quick_cart)

Hızlı Satın Al Bağlantısı Güncelleme

İlgili Hızlı Satın Al Bağlantısını günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.QuickCartApi(swagger_client.ApiClient(configuration))
id = 56 # int | Hızlı Satın Al nesnesinin id değeri
quick_cart = swagger_client.QuickCart() # QuickCart |  nesnesi

try:
    # Hızlı Satın Al Bağlantısı Güncelleme
    api_response = api_instance.quick_carts_id_put(id, quick_cart)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling QuickCartApi->quick_carts_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Hızlı Satın Al nesnesinin id değeri | 
 **quick_cart** | [**QuickCart**](QuickCart.md)|  nesnesi | 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **quick_carts_post**
> QuickCart quick_carts_post(quick_cart)

Hızlı Satın Al Bağlantısı Oluşturma

Yeni bir Hızlı Satın Al Bağlantısı oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.QuickCartApi(swagger_client.ApiClient(configuration))
quick_cart = swagger_client.QuickCart() # QuickCart |  nesnesi

try:
    # Hızlı Satın Al Bağlantısı Oluşturma
    api_response = api_instance.quick_carts_post(quick_cart)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling QuickCartApi->quick_carts_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **quick_cart** | [**QuickCart**](QuickCart.md)|  nesnesi | 

### Return type

[**QuickCart**](QuickCart.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

