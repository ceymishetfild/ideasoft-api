# OrderDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sipariş detayı nesnesi kimlik değeri. | [optional] 
**var_key** | **str** | Sipariş detayı nesnesi için değişken anahtarı. | 
**var_value** | **str** | Sipariş detayı nesnesi için değişken değeri. | 
**order** | [**Order**](Order.md) | Sipariş nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


