# OrderUserNote

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sipariş yönetici notu nesnesi kimlik değeri. | [optional] 
**user_email** | **str** | Yöneticinin(admin) e-mail adresi. | 
**user_firstname** | **str** | Yöneticinin(admin) ismi. | [optional] 
**user_surname** | **str** | Yöneticinin(admin) soy ismi. | [optional] 
**note** | **str** | Yöneticinin(admin) sipariş için girdiği not. | 
**created_at** | **datetime** | Sipariş yönetici notu nesnesinin oluşturulma zamanı. | 
**updated_at** | **datetime** | Sipariş yönetici notu nesnesinin güncellenme zamanı. | 
**order** | [**Order**](Order.md) | Sipariş nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


