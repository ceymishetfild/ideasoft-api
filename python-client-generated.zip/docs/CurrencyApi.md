# swagger_client.CurrencyApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**currencies_get**](CurrencyApi.md#currencies_get) | **GET** /currencies | Kur Listesi Alma
[**currencies_id_get**](CurrencyApi.md#currencies_id_get) | **GET** /currencies/{id} | Kur Alma
[**currencies_id_put**](CurrencyApi.md#currencies_id_put) | **PUT** /currencies/{id} | Kur Güncelleme


# **currencies_get**
> Currency currencies_get(sort=sort, limit=limit, page=page, since_id=since_id, label=label, abbr=abbr, status=status)

Kur Listesi Alma

Kur listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.CurrencyApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
label = 'label_example' # str | Kur etiketi (optional)
abbr = 'abbr_example' # str | Kur kısaltması (optional)
status = 56 # int | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif (optional)

try:
    # Kur Listesi Alma
    api_response = api_instance.currencies_get(sort=sort, limit=limit, page=page, since_id=since_id, label=label, abbr=abbr, status=status)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CurrencyApi->currencies_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **label** | **str**| Kur etiketi | [optional] 
 **abbr** | **str**| Kur kısaltması | [optional] 
 **status** | **int**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 

### Return type

[**Currency**](Currency.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **currencies_id_get**
> Currency currencies_id_get(id)

Kur Alma

İlgili Kur getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.CurrencyApi(swagger_client.ApiClient(configuration))
id = 56 # int | Kur nesnesinin id değeri

try:
    # Kur Alma
    api_response = api_instance.currencies_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CurrencyApi->currencies_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kur nesnesinin id değeri | 

### Return type

[**Currency**](Currency.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **currencies_id_put**
> Currency currencies_id_put(id, currency)

Kur Güncelleme

İlgili Kur günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.CurrencyApi(swagger_client.ApiClient(configuration))
id = 56 # int | Kur nesnesinin id değeri
currency = swagger_client.Currency() # Currency | Currency nesnesi

try:
    # Kur Güncelleme
    api_response = api_instance.currencies_id_put(id, currency)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CurrencyApi->currencies_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Kur nesnesinin id değeri | 
 **currency** | [**Currency**](Currency.md)| Currency nesnesi | 

### Return type

[**Currency**](Currency.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

