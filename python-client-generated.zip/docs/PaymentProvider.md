# PaymentProvider

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ödeme altyapısı sağlayıcısı nesnesi kimlik değeri. | [optional] 
**code** | **str** | Ödeme altyapısı sağlayıcısı için ön tanımlanmış kod değeri. | 
**name** | **str** | Ödeme altyapısı sağlayıcısı için isim değeri. | 
**status** | **str** | Ödeme altyapısı sağlayıcısının aktiflik durumunu belirten değer. | 
**payment_type** | [**PaymentType**](PaymentType.md) |  | [optional] 
**settings** | [**list[PaymentProviderSetting]**](PaymentProviderSetting.md) | Ödeme altyapısı sağlayıcısı ayarları | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


