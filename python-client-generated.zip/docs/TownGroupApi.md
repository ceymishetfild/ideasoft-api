# swagger_client.TownGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**town_groups_get**](TownGroupApi.md#town_groups_get) | **GET** /town_groups | İlçe Grubu Listesi Alma
[**town_groups_id_delete**](TownGroupApi.md#town_groups_id_delete) | **DELETE** /town_groups/{id} | İlçe Grubu Silme
[**town_groups_id_get**](TownGroupApi.md#town_groups_id_get) | **GET** /town_groups/{id} | İlçe Grubu Alma
[**town_groups_id_put**](TownGroupApi.md#town_groups_id_put) | **PUT** /town_groups/{id} | İlçe Grubu Güncelleme
[**town_groups_post**](TownGroupApi.md#town_groups_post) | **POST** /town_groups | İlçe Grubu Oluşturma


# **town_groups_get**
> TownGroup town_groups_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name)

İlçe Grubu Listesi Alma

İlçe Grubu listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.TownGroupApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
name = 'name_example' # str | İlçe Grubu adı (optional)

try:
    # İlçe Grubu Listesi Alma
    api_response = api_instance.town_groups_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TownGroupApi->town_groups_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **str**| İlçe Grubu adı | [optional] 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **town_groups_id_delete**
> town_groups_id_delete(id)

İlçe Grubu Silme

Kalıcı olarak ilgili İlçe Grubunu siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.TownGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | İlçe Grubu nesnesinin id değeri

try:
    # İlçe Grubu Silme
    api_instance.town_groups_id_delete(id)
except ApiException as e:
    print("Exception when calling TownGroupApi->town_groups_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **town_groups_id_get**
> TownGroup town_groups_id_get(id)

İlçe Grubu Alma

İlgili İlçe Grubunu getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.TownGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | İlçe Grubu nesnesinin id değeri

try:
    # İlçe Grubu Alma
    api_response = api_instance.town_groups_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TownGroupApi->town_groups_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe Grubu nesnesinin id değeri | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **town_groups_id_put**
> TownGroup town_groups_id_put(id, town_group)

İlçe Grubu Güncelleme

İlgili İlçe Grubunu günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.TownGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | İlçe Grubu nesnesinin id değeri
town_group = swagger_client.TownGroup() # TownGroup | TownGroup nesnesi

try:
    # İlçe Grubu Güncelleme
    api_response = api_instance.town_groups_id_put(id, town_group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TownGroupApi->town_groups_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| İlçe Grubu nesnesinin id değeri | 
 **town_group** | [**TownGroup**](TownGroup.md)| TownGroup nesnesi | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **town_groups_post**
> TownGroup town_groups_post(town_group)

İlçe Grubu Oluşturma

Yeni bir İlçe Grubu oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.TownGroupApi(swagger_client.ApiClient(configuration))
town_group = swagger_client.TownGroup() # TownGroup | TownGroup nesnesi

try:
    # İlçe Grubu Oluşturma
    api_response = api_instance.town_groups_post(town_group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TownGroupApi->town_groups_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **town_group** | [**TownGroup**](TownGroup.md)| TownGroup nesnesi | 

### Return type

[**TownGroup**](TownGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

