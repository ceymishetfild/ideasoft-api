# swagger_client.SelectionGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selection_groups_get**](SelectionGroupApi.md#selection_groups_get) | **GET** /selection_groups | Ek Özellik Grubu Listesi Alma
[**selection_groups_id_delete**](SelectionGroupApi.md#selection_groups_id_delete) | **DELETE** /selection_groups/{id} | Ek Özellik Grubu Silme
[**selection_groups_id_get**](SelectionGroupApi.md#selection_groups_id_get) | **GET** /selection_groups/{id} | Ek Özellik Grubu Alma
[**selection_groups_id_put**](SelectionGroupApi.md#selection_groups_id_put) | **PUT** /selection_groups/{id} | Ek Özellik Grubu Güncelleme
[**selection_groups_post**](SelectionGroupApi.md#selection_groups_post) | **POST** /selection_groups | Ek Özellik Grubu Oluşturma


# **selection_groups_get**
> SelectionGroup selection_groups_get(sort=sort, limit=limit, page=page, since_id=since_id, title=title)

Ek Özellik Grubu Listesi Alma

Ek Özellik Grubu listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SelectionGroupApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
title = 'title_example' # str | Ek Özellik Grubu başlığı (optional)

try:
    # Ek Özellik Grubu Listesi Alma
    api_response = api_instance.selection_groups_get(sort=sort, limit=limit, page=page, since_id=since_id, title=title)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SelectionGroupApi->selection_groups_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **title** | **str**| Ek Özellik Grubu başlığı | [optional] 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selection_groups_id_delete**
> selection_groups_id_delete(id)

Ek Özellik Grubu Silme

Kalıcı olarak ilgili Ek Özellik Grubunu siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SelectionGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ek Özellik Grubu nesnesinin id değeri

try:
    # Ek Özellik Grubu Silme
    api_instance.selection_groups_id_delete(id)
except ApiException as e:
    print("Exception when calling SelectionGroupApi->selection_groups_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selection_groups_id_get**
> SelectionGroup selection_groups_id_get(id)

Ek Özellik Grubu Alma

İlgili Ek Özellik Grubunu getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SelectionGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ek Özellik Grubu nesnesinin id değeri

try:
    # Ek Özellik Grubu Alma
    api_response = api_instance.selection_groups_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SelectionGroupApi->selection_groups_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik Grubu nesnesinin id değeri | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selection_groups_id_put**
> SelectionGroup selection_groups_id_put(id, selection_group)

Ek Özellik Grubu Güncelleme

İlgili Ek Özellik Grubunu günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SelectionGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ek Özellik Grubu nesnesinin id değeri
selection_group = swagger_client.SelectionGroup() # SelectionGroup | SelectionGroup nesnesi

try:
    # Ek Özellik Grubu Güncelleme
    api_response = api_instance.selection_groups_id_put(id, selection_group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SelectionGroupApi->selection_groups_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik Grubu nesnesinin id değeri | 
 **selection_group** | [**SelectionGroup**](SelectionGroup.md)| SelectionGroup nesnesi | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selection_groups_post**
> SelectionGroup selection_groups_post(selection_group)

Ek Özellik Grubu Oluşturma

Yeni bir Ek Özellik Grubu oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SelectionGroupApi(swagger_client.ApiClient(configuration))
selection_group = swagger_client.SelectionGroup() # SelectionGroup | SelectionGroup nesnesi

try:
    # Ek Özellik Grubu Oluşturma
    api_response = api_instance.selection_groups_post(selection_group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SelectionGroupApi->selection_groups_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selection_group** | [**SelectionGroup**](SelectionGroup.md)| SelectionGroup nesnesi | 

### Return type

[**SelectionGroup**](SelectionGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

