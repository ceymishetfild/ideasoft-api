# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Yönetici nesnesi kimlik değeri. | [optional] 
**firstname** | **str** | Yöneticinin ismi. | [optional] 
**surname** | **str** | Yöneticinin soy ismi. | [optional] 
**email** | **str** | Yöneticinin e-mail adresi. | 
**username** | **str** | Yöneticinin kullanıcı adı. | 
**phone_number** | **str** | Yöneticinin telefon numarası. | [optional] 
**status** | **int** | Yöneticinin aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;code&gt;2&lt;/code&gt; : Askıya alınmış.&lt;br&gt;&lt;/div&gt; | 
**is_owner** | **str** | Yöneticinin site sahibi olma durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Site sahibi.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Site sahibi değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**membergroups** | [**list[MemberGroup]**](MemberGroup.md) | İlgili üye grubu. | [optional] 
**sms_approved** | **str** | Yöneticinin SMS verifikasyonu yapılma bilgisini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : SMS verifikasyon yapılmış.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : SMS verifikasyon yapılmamış.&lt;br&gt;&lt;/div&gt; | [optional] 
**userlevel** | [**ShopUserlevels**](ShopUserlevels.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


