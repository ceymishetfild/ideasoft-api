# swagger_client.BrandApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**brands_get**](BrandApi.md#brands_get) | **GET** /brands | Marka Listesi Alma
[**brands_id_delete**](BrandApi.md#brands_id_delete) | **DELETE** /brands/{id} | Marka Silme
[**brands_id_get**](BrandApi.md#brands_id_get) | **GET** /brands/{id} | Marka Alma
[**brands_id_put**](BrandApi.md#brands_id_put) | **PUT** /brands/{id} | Marka Güncelleme
[**brands_post**](BrandApi.md#brands_post) | **POST** /brands | Marka Oluşturma


# **brands_get**
> Brand brands_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name, status=status, distributor=distributor, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at, q=q)

Marka Listesi Alma

Marka listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BrandApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
name = 'name_example' # str | Marka adı. (optional)
status = 56 # int | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif (optional)
distributor = 'distributor_example' # str | Marka distribörü (optional)
start_date = '2013-10-20' # date | createdAt değeri için başlangıç tarihi (optional)
end_date = 'end_date_example' # str | createdAt değeri için bitiş tarihi (optional)
start_updated_at = '2013-10-20' # date | updatedAt değeri için başlangıç tarihi (optional)
end_updated_at = 'end_updated_at_example' # str | updatedAt değeri için bitiş tarihi (optional)
q = ['q_example'] # list[str] | Marka arama filtresi. Kullanımı: q[&lt;geçerli-query-parametresi&gt;] (optional)

try:
    # Marka Listesi Alma
    api_response = api_instance.brands_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name, status=status, distributor=distributor, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at, q=q)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BrandApi->brands_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **str**| Marka adı. | [optional] 
 **status** | **int**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **distributor** | **str**| Marka distribörü | [optional] 
 **start_date** | **date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **str**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **str**| updatedAt değeri için bitiş tarihi | [optional] 
 **q** | [**list[str]**](str.md)| Marka arama filtresi. Kullanımı: q[&amp;lt;geçerli-query-parametresi&amp;gt;] | [optional] 

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **brands_id_delete**
> brands_id_delete(id)

Marka Silme

Kalıcı olarak ilgili Markayı siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BrandApi(swagger_client.ApiClient(configuration))
id = 56 # int | Marka nesnesinin id değeri

try:
    # Marka Silme
    api_instance.brands_id_delete(id)
except ApiException as e:
    print("Exception when calling BrandApi->brands_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Marka nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **brands_id_get**
> Brand brands_id_get(id)

Marka Alma

İlgili Markayı getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BrandApi(swagger_client.ApiClient(configuration))
id = 56 # int | Marka nesnesinin id değeri

try:
    # Marka Alma
    api_response = api_instance.brands_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BrandApi->brands_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Marka nesnesinin id değeri | 

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **brands_id_put**
> Brand brands_id_put(id, brand)

Marka Güncelleme

İlgili Markayı günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BrandApi(swagger_client.ApiClient(configuration))
id = 56 # int | Marka nesnesinin id değeri
brand = swagger_client.Brand() # Brand | Brand nesnesi

try:
    # Marka Güncelleme
    api_response = api_instance.brands_id_put(id, brand)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BrandApi->brands_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Marka nesnesinin id değeri | 
 **brand** | [**Brand**](Brand.md)| Brand nesnesi | 

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **brands_post**
> Brand brands_post(brand)

Marka Oluşturma

Yeni bir Marka oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.BrandApi(swagger_client.ApiClient(configuration))
brand = swagger_client.Brand() # Brand | Brand nesnesi

try:
    # Marka Oluşturma
    api_response = api_instance.brands_post(brand)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling BrandApi->brands_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **brand** | [**Brand**](Brand.md)| Brand nesnesi | 

### Return type

[**Brand**](Brand.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

