# swagger_client.SpecGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**spec_groups_get**](SpecGroupApi.md#spec_groups_get) | **GET** /spec_groups | Ürün Özellik Grubu Listesi Alma
[**spec_groups_id_delete**](SpecGroupApi.md#spec_groups_id_delete) | **DELETE** /spec_groups/{id} | Ürün Özellik Grubu Silme
[**spec_groups_id_get**](SpecGroupApi.md#spec_groups_id_get) | **GET** /spec_groups/{id} | Ürün Özellik Grubu Alma
[**spec_groups_id_put**](SpecGroupApi.md#spec_groups_id_put) | **PUT** /spec_groups/{id} | Ürün Özellik Grubu Güncelleme
[**spec_groups_post**](SpecGroupApi.md#spec_groups_post) | **POST** /spec_groups | Ürün Özellik Grubu Oluşturma


# **spec_groups_get**
> SpecGroup spec_groups_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name)

Ürün Özellik Grubu Listesi Alma

Ürün Özellik Grubu listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SpecGroupApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
name = 'name_example' # str | Ürün Özellik Grubu adı (optional)

try:
    # Ürün Özellik Grubu Listesi Alma
    api_response = api_instance.spec_groups_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SpecGroupApi->spec_groups_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **str**| Ürün Özellik Grubu adı | [optional] 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_groups_id_delete**
> spec_groups_id_delete(id)

Ürün Özellik Grubu Silme

Kalıcı olarak ilgili Ürün Özellik Grubunu siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SpecGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Özellik Grubu nesnesinin id değeri

try:
    # Ürün Özellik Grubu Silme
    api_instance.spec_groups_id_delete(id)
except ApiException as e:
    print("Exception when calling SpecGroupApi->spec_groups_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_groups_id_get**
> SpecGroup spec_groups_id_get(id)

Ürün Özellik Grubu Alma

İlgili Ürün Özellik Grubunu getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SpecGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Özellik Grubu nesnesinin id değeri

try:
    # Ürün Özellik Grubu Alma
    api_response = api_instance.spec_groups_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SpecGroupApi->spec_groups_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Grubu nesnesinin id değeri | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_groups_id_put**
> SpecGroup spec_groups_id_put(id, spec_group)

Ürün Özellik Grubu Güncelleme

İlgili Ürün Özellik Grubunu günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SpecGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Özellik Grubu nesnesinin id değeri
spec_group = swagger_client.SpecGroup() # SpecGroup | SpecGroup nesnesi

try:
    # Ürün Özellik Grubu Güncelleme
    api_response = api_instance.spec_groups_id_put(id, spec_group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SpecGroupApi->spec_groups_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik Grubu nesnesinin id değeri | 
 **spec_group** | [**SpecGroup**](SpecGroup.md)| SpecGroup nesnesi | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_groups_post**
> SpecGroup spec_groups_post(spec_group)

Ürün Özellik Grubu Oluşturma

Yeni bir Ürün Özellik Grubu oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SpecGroupApi(swagger_client.ApiClient(configuration))
spec_group = swagger_client.SpecGroup() # SpecGroup | SpecGroup nesnesi

try:
    # Ürün Özellik Grubu Oluşturma
    api_response = api_instance.spec_groups_post(spec_group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SpecGroupApi->spec_groups_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **spec_group** | [**SpecGroup**](SpecGroup.md)| SpecGroup nesnesi | 

### Return type

[**SpecGroup**](SpecGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

