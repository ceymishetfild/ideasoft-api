# swagger_client.MaillistGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**maillist_groups_get**](MaillistGroupApi.md#maillist_groups_get) | **GET** /maillist_groups | Mail Listesi Grubu Listesi Alma
[**maillist_groups_id_delete**](MaillistGroupApi.md#maillist_groups_id_delete) | **DELETE** /maillist_groups/{id} | Mail Listesi Grubu Silme
[**maillist_groups_id_get**](MaillistGroupApi.md#maillist_groups_id_get) | **GET** /maillist_groups/{id} | Mail Listesi Grubu Alma
[**maillist_groups_id_put**](MaillistGroupApi.md#maillist_groups_id_put) | **PUT** /maillist_groups/{id} | Mail Listesi Grubu Güncelleme
[**maillist_groups_post**](MaillistGroupApi.md#maillist_groups_post) | **POST** /maillist_groups | Mail Listesi Grubu Oluşturma


# **maillist_groups_get**
> MaillistGroup maillist_groups_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, name=name)

Mail Listesi Grubu Listesi Alma

Mail Listesi Grubu listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MaillistGroupApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
name = 'name_example' # str | Mail Listesi Grubu adı (optional)

try:
    # Mail Listesi Grubu Listesi Alma
    api_response = api_instance.maillist_groups_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, name=name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MaillistGroupApi->maillist_groups_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **str**| Mail Listesi Grubu adı | [optional] 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillist_groups_id_delete**
> maillist_groups_id_delete(id)

Mail Listesi Grubu Silme

Kalıcı olarak ilgili Mail Listesi Grubunu siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MaillistGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | Mail Listesi Grubu nesnesinin id değeri

try:
    # Mail Listesi Grubu Silme
    api_instance.maillist_groups_id_delete(id)
except ApiException as e:
    print("Exception when calling MaillistGroupApi->maillist_groups_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillist_groups_id_get**
> MaillistGroup maillist_groups_id_get(id)

Mail Listesi Grubu Alma

İlgili Mail Listesi Grubunu getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MaillistGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | Mail Listesi Grubu nesnesinin id değeri

try:
    # Mail Listesi Grubu Alma
    api_response = api_instance.maillist_groups_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MaillistGroupApi->maillist_groups_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi Grubu nesnesinin id değeri | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillist_groups_id_put**
> MaillistGroup maillist_groups_id_put(id, maillist_group)

Mail Listesi Grubu Güncelleme

İlgili Mail Listesi Grubunu günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MaillistGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | Mail Listesi Grubu nesnesinin id değeri
maillist_group = swagger_client.MaillistGroup() # MaillistGroup |  nesnesi

try:
    # Mail Listesi Grubu Güncelleme
    api_response = api_instance.maillist_groups_id_put(id, maillist_group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MaillistGroupApi->maillist_groups_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi Grubu nesnesinin id değeri | 
 **maillist_group** | [**MaillistGroup**](MaillistGroup.md)|  nesnesi | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillist_groups_post**
> MaillistGroup maillist_groups_post(maillist_group)

Mail Listesi Grubu Oluşturma

Yeni bir Mail Listesi Grubu oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MaillistGroupApi(swagger_client.ApiClient(configuration))
maillist_group = swagger_client.MaillistGroup() # MaillistGroup |  nesnesi

try:
    # Mail Listesi Grubu Oluşturma
    api_response = api_instance.maillist_groups_post(maillist_group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MaillistGroupApi->maillist_groups_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **maillist_group** | [**MaillistGroup**](MaillistGroup.md)|  nesnesi | 

### Return type

[**MaillistGroup**](MaillistGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

