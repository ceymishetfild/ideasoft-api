# PaymentGatewaySetting

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ödeme kanalı ayarı nesnesi kimlik değeri. | [optional] 
**var_key** | **str** | Ödeme kanalı ayarı nesnesi için değişken anahtarı. | 
**var_value** | **str** | Ödeme kanalı ayarı nesnesi için değişken değeri. | 
**payment_gateway** | [**PaymentGateway**](PaymentGateway.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


