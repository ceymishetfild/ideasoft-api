# swagger_client.ProductToCategoryApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_to_categories_get**](ProductToCategoryApi.md#product_to_categories_get) | **GET** /product_to_categories | Ürün Kategori Bağı Listesi Alma
[**product_to_categories_id_delete**](ProductToCategoryApi.md#product_to_categories_id_delete) | **DELETE** /product_to_categories/{id} | Ürün Kategori Bağı Silme
[**product_to_categories_id_get**](ProductToCategoryApi.md#product_to_categories_id_get) | **GET** /product_to_categories/{id} | Ürün Kategori Bağı Alma
[**product_to_categories_id_put**](ProductToCategoryApi.md#product_to_categories_id_put) | **PUT** /product_to_categories/{id} | Ürün Kategori Bağı Güncelleme
[**product_to_categories_post**](ProductToCategoryApi.md#product_to_categories_post) | **POST** /product_to_categories | Ürün Kategori Bağı Oluşturma


# **product_to_categories_get**
> ProductToCategory product_to_categories_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, product=product, category=category)

Ürün Kategori Bağı Listesi Alma

Ürün Kategori Bağı listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductToCategoryApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
product = 56 # int | Ürün id (optional)
category = 56 # int | Kategori id (optional)

try:
    # Ürün Kategori Bağı Listesi Alma
    api_response = api_instance.product_to_categories_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, product=product, category=category)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductToCategoryApi->product_to_categories_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **product** | **int**| Ürün id | [optional] 
 **category** | **int**| Kategori id | [optional] 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_to_categories_id_delete**
> product_to_categories_id_delete(id)

Ürün Kategori Bağı Silme

Kalıcı olarak ilgili Ürün Kategori Bağını siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductToCategoryApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Kategori Bağı nesnesinin id değeri

try:
    # Ürün Kategori Bağı Silme
    api_instance.product_to_categories_id_delete(id)
except ApiException as e:
    print("Exception when calling ProductToCategoryApi->product_to_categories_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Kategori Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_to_categories_id_get**
> ProductToCategory product_to_categories_id_get(id)

Ürün Kategori Bağı Alma

İlgili Ürün Kategori Bağını getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductToCategoryApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Kategori Bağı nesnesinin id değeri

try:
    # Ürün Kategori Bağı Alma
    api_response = api_instance.product_to_categories_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductToCategoryApi->product_to_categories_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Kategori Bağı nesnesinin id değeri | 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_to_categories_id_put**
> ProductToCategory product_to_categories_id_put(id, product_to_category)

Ürün Kategori Bağı Güncelleme

İlgili Ürün Kategori Bağını günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductToCategoryApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Kategori Bağı nesnesinin id değeri
product_to_category = swagger_client.ProductToCategory() # ProductToCategory |  nesnesi

try:
    # Ürün Kategori Bağı Güncelleme
    api_response = api_instance.product_to_categories_id_put(id, product_to_category)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductToCategoryApi->product_to_categories_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Kategori Bağı nesnesinin id değeri | 
 **product_to_category** | [**ProductToCategory**](ProductToCategory.md)|  nesnesi | 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_to_categories_post**
> ProductToCategory product_to_categories_post(product_to_category)

Ürün Kategori Bağı Oluşturma

Yeni bir Ürün Kategori Bağı oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductToCategoryApi(swagger_client.ApiClient(configuration))
product_to_category = swagger_client.ProductToCategory() # ProductToCategory |  nesnesi

try:
    # Ürün Kategori Bağı Oluşturma
    api_response = api_instance.product_to_categories_post(product_to_category)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductToCategoryApi->product_to_categories_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_to_category** | [**ProductToCategory**](ProductToCategory.md)|  nesnesi | 

### Return type

[**ProductToCategory**](ProductToCategory.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

