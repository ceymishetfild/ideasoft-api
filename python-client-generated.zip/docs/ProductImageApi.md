# swagger_client.ProductImageApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_images_get**](ProductImageApi.md#product_images_get) | **GET** /product_images | Ürün Resim Listesi Alma
[**product_images_id_delete**](ProductImageApi.md#product_images_id_delete) | **DELETE** /product_images/{id} | Ürün Resim Silme
[**product_images_id_get**](ProductImageApi.md#product_images_id_get) | **GET** /product_images/{id} | Ürün Resim Alma
[**product_images_post**](ProductImageApi.md#product_images_post) | **POST** /product_images | Ürün Resim Oluşturma


# **product_images_get**
> ProductImage product_images_get(sort=sort, limit=limit, page=page, since_id=since_id, file_name=file_name, product=product)

Ürün Resim Listesi Alma

Ürün Resim listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductImageApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
file_name = 'file_name_example' # str | Ürün Resim dosya adı (optional)
product = 56 # int | Ürün id (optional)

try:
    # Ürün Resim Listesi Alma
    api_response = api_instance.product_images_get(sort=sort, limit=limit, page=page, since_id=since_id, file_name=file_name, product=product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductImageApi->product_images_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **file_name** | **str**| Ürün Resim dosya adı | [optional] 
 **product** | **int**| Ürün id | [optional] 

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_images_id_delete**
> product_images_id_delete(id)

Ürün Resim Silme

Kalıcı olarak ilgili Ürün Resmini siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductImageApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Resmi nesnesinin id değeri

try:
    # Ürün Resim Silme
    api_instance.product_images_id_delete(id)
except ApiException as e:
    print("Exception when calling ProductImageApi->product_images_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Resmi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_images_id_get**
> ProductImage product_images_id_get(id)

Ürün Resim Alma

İlgili Ürün Resmini getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductImageApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Resmi nesnesinin id değeri

try:
    # Ürün Resim Alma
    api_response = api_instance.product_images_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductImageApi->product_images_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Resmi nesnesinin id değeri | 

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_images_post**
> ProductImage product_images_post(product_image)

Ürün Resim Oluşturma

Yeni bir Ürün Resim oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductImageApi(swagger_client.ApiClient(configuration))
product_image = swagger_client.ProductImage() # ProductImage | ProductImage nesnesi

try:
    # Ürün Resim Oluşturma
    api_response = api_instance.product_images_post(product_image)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductImageApi->product_images_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_image** | [**ProductImage**](ProductImage.md)| ProductImage nesnesi | 

### Return type

[**ProductImage**](ProductImage.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

