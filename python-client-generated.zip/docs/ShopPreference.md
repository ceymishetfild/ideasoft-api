# ShopPreference

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Tanımlama nesnesi kimlik değeri. | [optional] 
**var_key** | **str** | Tanımlama nesnesi için değişken anahtarı. | [optional] 
**var_value** | **str** | Tanımlama nesnesi için değişken değeri. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


