# swagger_client.ExtraInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extra_infos_get**](ExtraInfoApi.md#extra_infos_get) | **GET** /extra_infos | Ek Bilgi Listesi Alma
[**extra_infos_id_delete**](ExtraInfoApi.md#extra_infos_id_delete) | **DELETE** /extra_infos/{id} | Ek Bilgi Silme
[**extra_infos_id_get**](ExtraInfoApi.md#extra_infos_id_get) | **GET** /extra_infos/{id} | Ek Bilgi Alma
[**extra_infos_id_put**](ExtraInfoApi.md#extra_infos_id_put) | **PUT** /extra_infos/{id} | Ek Bilgi Güncelleme
[**extra_infos_post**](ExtraInfoApi.md#extra_infos_post) | **POST** /extra_infos | Ek Bilgi Oluşturma


# **extra_infos_get**
> ExtraInfo extra_infos_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name)

Ek Bilgi Listesi Alma

Ek Bilgi listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ExtraInfoApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
name = 'name_example' # str | Ek Bilgi adı (optional)

try:
    # Ek Bilgi Listesi Alma
    api_response = api_instance.extra_infos_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ExtraInfoApi->extra_infos_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **str**| Ek Bilgi adı | [optional] 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_infos_id_delete**
> extra_infos_id_delete(id)

Ek Bilgi Silme

Kalıcı olarak ilgili Ek Bilgiyi siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ExtraInfoApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ek Bilgi nesnesinin id değeri

try:
    # Ek Bilgi Silme
    api_instance.extra_infos_id_delete(id)
except ApiException as e:
    print("Exception when calling ExtraInfoApi->extra_infos_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_infos_id_get**
> ExtraInfo extra_infos_id_get(id)

Ek Bilgi Alma

İlgili Ek Bilgiyi getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ExtraInfoApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ek Bilgi nesnesinin id değeri

try:
    # Ek Bilgi Alma
    api_response = api_instance.extra_infos_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ExtraInfoApi->extra_infos_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi nesnesinin id değeri | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_infos_id_put**
> ExtraInfo extra_infos_id_put(id, extra_info)

Ek Bilgi Güncelleme

İlgili Ek Bilgiyi günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ExtraInfoApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ek Bilgi nesnesinin id değeri
extra_info = swagger_client.ExtraInfo() # ExtraInfo | ExtraInfo nesnesi

try:
    # Ek Bilgi Güncelleme
    api_response = api_instance.extra_infos_id_put(id, extra_info)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ExtraInfoApi->extra_infos_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Bilgi nesnesinin id değeri | 
 **extra_info** | [**ExtraInfo**](ExtraInfo.md)| ExtraInfo nesnesi | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **extra_infos_post**
> ExtraInfo extra_infos_post(extra_info)

Ek Bilgi Oluşturma

Yeni bir Ek Bilgi oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ExtraInfoApi(swagger_client.ApiClient(configuration))
extra_info = swagger_client.ExtraInfo() # ExtraInfo | ExtraInfo nesnesi

try:
    # Ek Bilgi Oluşturma
    api_response = api_instance.extra_infos_post(extra_info)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ExtraInfoApi->extra_infos_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extra_info** | [**ExtraInfo**](ExtraInfo.md)| ExtraInfo nesnesi | 

### Return type

[**ExtraInfo**](ExtraInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

