# swagger_client.MaillistApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**maillists_get**](MaillistApi.md#maillists_get) | **GET** /maillists | Mail Listesi Listesi Alma
[**maillists_id_delete**](MaillistApi.md#maillists_id_delete) | **DELETE** /maillists/{id} | Mail Listesi Silme
[**maillists_id_get**](MaillistApi.md#maillists_id_get) | **GET** /maillists/{id} | Mail Listesi Alma
[**maillists_id_put**](MaillistApi.md#maillists_id_put) | **PUT** /maillists/{id} | Mail Listesi Güncelleme
[**maillists_post**](MaillistApi.md#maillists_post) | **POST** /maillists | Mail Listesi Oluşturma


# **maillists_get**
> Maillist maillists_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, name=name, email=email, maillist_group=maillist_group, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)

Mail Listesi Listesi Alma

Mail Listesi listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MaillistApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
name = 'name_example' # str | Mail Listesi adı. (optional)
email = 'email_example' # str | Mail Listesi e-mail. (optional)
maillist_group = 56 # int | Mail Listesi Grubu id (optional)
start_date = '2013-10-20' # date | createdAt değeri için başlangıç tarihi (optional)
end_date = 'end_date_example' # str | createdAt değeri için bitiş tarihi (optional)
start_updated_at = '2013-10-20' # date | updatedAt değeri için başlangıç tarihi (optional)
end_updated_at = 'end_updated_at_example' # str | updatedAt değeri için bitiş tarihi (optional)

try:
    # Mail Listesi Listesi Alma
    api_response = api_instance.maillists_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, name=name, email=email, maillist_group=maillist_group, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MaillistApi->maillists_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **name** | **str**| Mail Listesi adı. | [optional] 
 **email** | **str**| Mail Listesi e-mail. | [optional] 
 **maillist_group** | **int**| Mail Listesi Grubu id | [optional] 
 **start_date** | **date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **str**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **str**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillists_id_delete**
> maillists_id_delete(id)

Mail Listesi Silme

Kalıcı olarak ilgili Mail Listesini siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MaillistApi(swagger_client.ApiClient(configuration))
id = 56 # int | Mail Listesi nesnesinin id değeri

try:
    # Mail Listesi Silme
    api_instance.maillists_id_delete(id)
except ApiException as e:
    print("Exception when calling MaillistApi->maillists_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillists_id_get**
> Maillist maillists_id_get(id)

Mail Listesi Alma

İlgili Mail Listesini getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MaillistApi(swagger_client.ApiClient(configuration))
id = 56 # int | Mail Listesi nesnesinin id değeri

try:
    # Mail Listesi Alma
    api_response = api_instance.maillists_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MaillistApi->maillists_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi nesnesinin id değeri | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillists_id_put**
> Maillist maillists_id_put(id, maillist)

Mail Listesi Güncelleme

İlgili Mail Listesini günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MaillistApi(swagger_client.ApiClient(configuration))
id = 56 # int | Mail Listesi nesnesinin id değeri
maillist = swagger_client.Maillist() # Maillist |  nesnesi

try:
    # Mail Listesi Güncelleme
    api_response = api_instance.maillists_id_put(id, maillist)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MaillistApi->maillists_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Mail Listesi nesnesinin id değeri | 
 **maillist** | [**Maillist**](Maillist.md)|  nesnesi | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **maillists_post**
> Maillist maillists_post(maillist)

Mail Listesi Oluşturma

Yeni bir Mail Listesini oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MaillistApi(swagger_client.ApiClient(configuration))
maillist = swagger_client.Maillist() # Maillist |  nesnesi

try:
    # Mail Listesi Oluşturma
    api_response = api_instance.maillists_post(maillist)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MaillistApi->maillists_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **maillist** | [**Maillist**](Maillist.md)|  nesnesi | 

### Return type

[**Maillist**](Maillist.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

