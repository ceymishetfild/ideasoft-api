# swagger_client.CartItemApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cart_items_id_delete**](CartItemApi.md#cart_items_id_delete) | **DELETE** /cart_items/{id} | Sepet Kalemi Silme
[**cart_items_id_put**](CartItemApi.md#cart_items_id_put) | **PUT** /cart_items/{id} | Sepet Kalemi Güncelleme
[**cart_items_post**](CartItemApi.md#cart_items_post) | **POST** /cart_items | Sepet Kalemi Oluşturma


# **cart_items_id_delete**
> cart_items_id_delete(id)

Sepet Kalemi Silme

Kalıcı olarak ilgili Sepet Kalemini siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.CartItemApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sepet Kalemi nesnesinin id değeri

try:
    # Sepet Kalemi Silme
    api_instance.cart_items_id_delete(id)
except ApiException as e:
    print("Exception when calling CartItemApi->cart_items_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sepet Kalemi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cart_items_id_put**
> CartItem cart_items_id_put(id)

Sepet Kalemi Güncelleme

İlgili Sepet Kalemini günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.CartItemApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sepet Kalemi nesnesinin id değeri

try:
    # Sepet Kalemi Güncelleme
    api_response = api_instance.cart_items_id_put(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CartItemApi->cart_items_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sepet Kalemi nesnesinin id değeri | 

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cart_items_post**
> CartItem cart_items_post(cart_item)

Sepet Kalemi Oluşturma

Yeni bir Sepet Kalemi oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.CartItemApi(swagger_client.ApiClient(configuration))
cart_item = swagger_client.CartItem() # CartItem |  nesnesi

try:
    # Sepet Kalemi Oluşturma
    api_response = api_instance.cart_items_post(cart_item)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CartItemApi->cart_items_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_item** | [**CartItem**](CartItem.md)|  nesnesi | 

### Return type

[**CartItem**](CartItem.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

