# swagger_client.PaymentGatewayApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**payment_gateways_get**](PaymentGatewayApi.md#payment_gateways_get) | **GET** /payment_gateways | Ödeme Kanalı Listesi Alma
[**payment_gateways_id_get**](PaymentGatewayApi.md#payment_gateways_id_get) | **GET** /payment_gateways/{id} | Ödeme Kanalı Alma


# **payment_gateways_get**
> PaymentGateway payment_gateways_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, code=code, name=name)

Ödeme Kanalı Listesi Alma

Ödeme Kanalı listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.PaymentGatewayApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
code = 'code_example' # str | Ödeme kanalı notu (optional)
name = 'name_example' # str | Ödeme kanalı adı (optional)

try:
    # Ödeme Kanalı Listesi Alma
    api_response = api_instance.payment_gateways_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, code=code, name=name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PaymentGatewayApi->payment_gateways_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **code** | **str**| Ödeme kanalı notu | [optional] 
 **name** | **str**| Ödeme kanalı adı | [optional] 

### Return type

[**PaymentGateway**](PaymentGateway.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **payment_gateways_id_get**
> PaymentGateway payment_gateways_id_get(id)

Ödeme Kanalı Alma

İlgili Ödeme Kanalını getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.PaymentGatewayApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ödeme Kanalı nesnesinin id değeri

try:
    # Ödeme Kanalı Alma
    api_response = api_instance.payment_gateways_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PaymentGatewayApi->payment_gateways_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ödeme Kanalı nesnesinin id değeri | 

### Return type

[**PaymentGateway**](PaymentGateway.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

