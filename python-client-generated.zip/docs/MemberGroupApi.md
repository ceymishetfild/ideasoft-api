# swagger_client.MemberGroupApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**member_groups_get**](MemberGroupApi.md#member_groups_get) | **GET** /member_groups | Üye Grubu Listesi Alma
[**member_groups_id_delete**](MemberGroupApi.md#member_groups_id_delete) | **DELETE** /member_groups/{id} | Üye Grubu Silme
[**member_groups_id_get**](MemberGroupApi.md#member_groups_id_get) | **GET** /member_groups/{id} | Üye Grubu Alma
[**member_groups_id_put**](MemberGroupApi.md#member_groups_id_put) | **PUT** /member_groups/{id} | Üye Grubu Güncelleme
[**member_groups_post**](MemberGroupApi.md#member_groups_post) | **POST** /member_groups | Üye Grubu Oluşturma


# **member_groups_get**
> MemberGroup member_groups_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name)

Üye Grubu Listesi Alma

Üye Grubu listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberGroupApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
name = 'name_example' # str | Üye Grubu adı (optional)

try:
    # Üye Grubu Listesi Alma
    api_response = api_instance.member_groups_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MemberGroupApi->member_groups_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **str**| Üye Grubu adı | [optional] 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_groups_id_delete**
> member_groups_id_delete(id)

Üye Grubu Silme

Kalıcı olarak ilgili Üye Grubunu siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | Üye Grubu nesnesinin id değeri

try:
    # Üye Grubu Silme
    api_instance.member_groups_id_delete(id)
except ApiException as e:
    print("Exception when calling MemberGroupApi->member_groups_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Grubu nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_groups_id_get**
> MemberGroup member_groups_id_get(id)

Üye Grubu Alma

İlgili Üye Grubunu getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | Üye Grubu nesnesinin id değeri

try:
    # Üye Grubu Alma
    api_response = api_instance.member_groups_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MemberGroupApi->member_groups_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Grubu nesnesinin id değeri | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_groups_id_put**
> MemberGroup member_groups_id_put(id, member_group)

Üye Grubu Güncelleme

İlgili Üye Grubunu günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberGroupApi(swagger_client.ApiClient(configuration))
id = 56 # int | Üye Grubu nesnesinin id değeri
member_group = swagger_client.MemberGroup() # MemberGroup | MemberGroup nesnesi

try:
    # Üye Grubu Güncelleme
    api_response = api_instance.member_groups_id_put(id, member_group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MemberGroupApi->member_groups_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Üye Grubu nesnesinin id değeri | 
 **member_group** | [**MemberGroup**](MemberGroup.md)| MemberGroup nesnesi | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **member_groups_post**
> MemberGroup member_groups_post(member_group)

Üye Grubu Oluşturma

Yeni bir Üye Grubu oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.MemberGroupApi(swagger_client.ApiClient(configuration))
member_group = swagger_client.MemberGroup() # MemberGroup | MemberGroup nesnesi

try:
    # Üye Grubu Oluşturma
    api_response = api_instance.member_groups_post(member_group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MemberGroupApi->member_groups_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **member_group** | [**MemberGroup**](MemberGroup.md)| MemberGroup nesnesi | 

### Return type

[**MemberGroup**](MemberGroup.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

