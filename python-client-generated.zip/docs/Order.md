# Order

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sipariş nesnesi kimlik değeri. | [optional] 
**customer_firstname** | **str** | Müşterinin ismi. | 
**customer_surname** | **str** | Müşterinin soy ismi. | 
**customer_email** | **str** | Müşterinin e-mail adresi. | 
**customer_phone** | **str** | Müşterinin telefon numarası. | 
**payment_type_name** | **str** | Siparişin ödeme tipi. | 
**payment_provider_code** | **str** | Siparişin ödeme altyapısı sağlayıcısının kodu. Ön tanımlıdır. API otomatik oluşturur. | 
**payment_provider_name** | **str** | Siparişin ödeme altyapısı sağlayıcısının adı. Ön tanımlıdır. API otomatik oluşturur. | 
**payment_gateway_code** | **str** | Siparişin ödeme kanalının kodu. Ön tanımlıdır. API otomatik oluşturur. | 
**payment_gateway_name** | **str** | Siparişin ödeme kanalının adı. Ön tanımlıdır. API otomatik oluşturur. | 
**bank_name** | **str** | Siparişin banka adı. Ön tanımlıdır. API otomatik oluşturur. | [optional] 
**client_ip** | **str** | Müşterinin IP adresi. | 
**user_agent** | **str** | Siparişin gerçekleştiği tarayıcı bilgisi. | [optional] 
**currency** | **str** | Kur bilgisi. | 
**currency_rates** | **str** | Kur oranları. | 
**amount** | **float** | Siparişin vergi hariç fiyatı. | 
**coupon_discount** | **float** | Siparişte kullanılan hediye çeki indirimi tutarı. | 
**tax_amount** | **float** | Siparişin vergi tutarı. | 
**promotion_discount** | **float** | Siparişte kullanılan promosyon indirimi tutarı. | 
**general_amount** | **float** | Siparişin genel fiyat tutarı. orderAmount, couponDiscount, taxAmount, promotionDiscount, shippingAmount, additionalServiceAmount tutarlarının toplamı. | 
**shipping_amount** | **float** | Siparişin teslimat ücreti. | 
**additional_service_amount** | **float** | Siparişin ek hizmet bedeli ücreti. | 
**final_amount** | **float** | Siparişin son ödeme tutarı. generalAmount değerinin üzerine taksitten kaynaklı vade farkı bedeli eklenmiş hali. | 
**sum_of_gained_points** | **float** | Siparişten kazanılan puan tutarı. | [optional] 
**installment** | **int** | Siparişin taksit adeti. | [optional] 
**installment_rate** | **float** | Siparişin taksit oranı. | [optional] 
**extra_installment** | **int** | Siparişin ek taksit adeti. | [optional] 
**transaction_id** | **str** | Siparişin numarası. | [optional] 
**has_user_note** | **str** | Siparişin müşteri notuna sahiplik durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Sipariş müşteri notuna sahip.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Sipariş müşteri notuna sahip değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**status** | **str** | Sipariş durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;/div&gt; | 
**payment_status** | **str** | Ödeme durumu bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;success&lt;/code&gt; : Başarılı&lt;br&gt;&lt;/div&gt; | 
**error_message** | **str** | Siparişin hata mesajı. | [optional] 
**device_type** | **str** | Siparişin gerçekleştiği cihaz bilgisi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;desktop&lt;/code&gt; : Masaüstü&lt;br&gt;&lt;code&gt;mobile&lt;/code&gt; : Mobil&lt;br&gt;&lt;code&gt;tablet&lt;/code&gt; : Tablet&lt;br&gt;&lt;/div&gt; | 
**referrer** | **str** | Siparişe yönlendiren web-sitesi adresi. Yönlendirmeyi yapan web-sitesinin tam URL bilgisini de içerir. API otomatik oluşturur. | [optional] 
**invoice_print_count** | **int** | Sipariş için alınan fatura çıktısı adedi. | [optional] 
**use_gift_package** | **str** | Hediye paketi istenilmesi durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Hediye paketi istiyorum&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Hediye paketi istemiyorum&lt;br&gt;&lt;/div&gt; | [optional] 
**gift_note** | **str** | Hediye notu. | [optional] 
**member_group_name** | **str** | Üye grubu adı. | [optional] 
**use_promotion** | **str** | Promosyon kullanılma durumu.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Promosyon kullan&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Promosyon kullanma&lt;br&gt;&lt;/div&gt; | [optional] 
**shipping_provider_code** | **str** | Siparişin teslimat hizmeti sağlayıcısı kodu. Ön tanımlıdır. API otomatik oluşturur. | [optional] 
**shipping_provider_name** | **str** | Siparişin teslimat hizmeti sağlayıcısı adı. Ön tanımlıdır. | [optional] 
**shipping_company_name** | **str** | Siparişin kargo firması adı. Ön tanımlıdır. | [optional] 
**shipping_payment_type** | **str** | Siparişin kargo ödeme tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı Ödemeli&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici Ödemeli&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için geçerli değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**shipping_tracking_code** | **str** | Siparişin kargo takip kodu. | [optional] 
**source** | **str** | Siparişin kaynak bilgisi. Siparişin kaynak yazılımını belirtir. | 
**created_at** | **datetime** | Sipariş nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **datetime** | Sipariş nesnesinin güncellenme zamanı. | [optional] 
**maillist** | [**Maillist**](Maillist.md) |  | [optional] 
**member** | [**Member**](Member.md) |  | [optional] 
**order_details** | [**list[OrderDetail]**](OrderDetail.md) | Sipariş detayları. | [optional] 
**order_items** | [**list[OrderItem]**](OrderItem.md) | Sipariş kalemleri. | [optional] 
**shipping_address** | [**ShippingAddress**](ShippingAddress.md) |  | [optional] 
**billing_address** | [**BillingAddress**](BillingAddress.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


