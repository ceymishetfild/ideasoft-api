# OrderItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sipariş kalemi nesnesi kimlik değeri. | [optional] 
**product_name** | **str** | Ürünün adı. | 
**product_sku** | **str** | Ürünün stok kodu. | 
**product_barcode** | **str** | Ürünün barkodu. | [optional] 
**product_price** | **float** | Ürünün fiyatı. | 
**product_currency** | **str** | Ürünün kuru. | 
**product_quantity** | **float** | Ürünün stok tipi cinsinden miktarı. | 
**product_tax** | **int** | Ürünün vergisi | 
**product_discount** | **float** | Ürünün standart indirim değeri. | 
**product_money_order_discount** | **float** | Ürünün havale indirim değeri. | 
**product_weight** | **float** | Ürünün ağırlığı. | 
**product_stock_type_label** | **str** | Ürünün stok tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;Adet&lt;/code&gt; : Stok tipi birimi Adet&lt;br&gt;&lt;code&gt;cm&lt;/code&gt; : Stok tipi birimi Santimetre&lt;br&gt;&lt;code&gt;Düzine&lt;/code&gt; : Stok tipi birimi Düzine&lt;br&gt;&lt;code&gt;gram&lt;/code&gt; : Stok tipi birimi Gram&lt;br&gt;&lt;code&gt;kg&lt;/code&gt; : Stok tipi birimi Kilogram&lt;br&gt;&lt;code&gt;Kişi&lt;/code&gt; : Stok tipi birimi Kişi&lt;br&gt;&lt;code&gt;Paket&lt;/code&gt; : Stok tipi birimi Paket&lt;br&gt;&lt;code&gt;metre&lt;/code&gt; : Stok tipi birimi Metre&lt;br&gt;&lt;code&gt;m2&lt;/code&gt; : Stok tipi birimi Metre kare&lt;br&gt;&lt;code&gt;Çift&lt;/code&gt; : Stok tipi birimi Çift&lt;br&gt;&lt;/div&gt; | 
**is_product_promotioned** | **str** | Ürünün promosyon olup olmadığını belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;0&lt;/code&gt; : Ürün promosyon değil.&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Ürün promosyon.&lt;br&gt;&lt;/div&gt; | [optional] 
**discount** | **float** | Ürünün hediye çeki indirim değeri. | 
**order** | [**Order**](Order.md) | Sipariş nesnesi. | [optional] 
**product** | [**Product**](Product.md) | Ürün nesnesi. | [optional] 
**order_item_subscription** | [**OrderItemSubscription**](OrderItemSubscription.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


