# OrderAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Sipariş adresi nesnesi kimlik değeri. | [optional] 
**firstname** | **str** | Müşterinin ismi. | 
**surname** | **str** | Müşterinin soy ismi. | 
**country** | **str** | Müşterinin ülke bilgisi. | 
**location** | **str** | Müşterinin şehir bilgisi. | 
**sub_location** | **str** | Müşterinin ilçe bilgisi. | [optional] 
**address** | **str** | Müşterinin adres bilgisi. | 
**phone_number** | **str** | Müşterinin telefon numarası. | 
**mobile_phone_number** | **str** | Müşterinin mobil telefon numarası. | [optional] 
**order** | [**Order**](Order.md) | Sipariş nesnesi. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


