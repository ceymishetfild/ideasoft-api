# ProductToCategory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ürün kategori bağı nesnesi kimlik değeri. | [optional] 
**sort_order** | **int** | Ürün kategori bağının sıralama değeri. Özel sıra belirtmek istemiyorsanız 9999 olarak iletebilirsiniz. | [optional] 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 
**category** | [**Category**](Category.md) | Kategori nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


