# swagger_client.ProductSpecialInfoApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_special_infos_get**](ProductSpecialInfoApi.md#product_special_infos_get) | **GET** /product_special_infos | Ürün Özel Bilgi Alanı Listesi Alma
[**product_special_infos_id_delete**](ProductSpecialInfoApi.md#product_special_infos_id_delete) | **DELETE** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**product_special_infos_id_get**](ProductSpecialInfoApi.md#product_special_infos_id_get) | **GET** /product_special_infos/{id} | Ürün Özel Bilgi Alanı
[**product_special_infos_id_put**](ProductSpecialInfoApi.md#product_special_infos_id_put) | **PUT** /product_special_infos/{id} | Ürün Özel Bilgi Alanı Güncelleme
[**product_special_infos_post**](ProductSpecialInfoApi.md#product_special_infos_post) | **POST** /product_special_infos | Ürün Özel Bilgi Alanı Oluşturma


# **product_special_infos_get**
> ProductSpecialInfo product_special_infos_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, title=title, status=status, product=product)

Ürün Özel Bilgi Alanı Listesi Alma

Ürün Özel Bilgi Alanı listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductSpecialInfoApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
title = 'title_example' # str | Ürün Özel Bilgi Alanı başlığı (optional)
status = 'status_example' # str | Status şu değerleri alabilir: <br><code>0</code> : Pasif<br><code>1</code> : Aktif (optional)
product = 56 # int | Ürün id (optional)

try:
    # Ürün Özel Bilgi Alanı Listesi Alma
    api_response = api_instance.product_special_infos_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, title=title, status=status, product=product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductSpecialInfoApi->product_special_infos_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **title** | **str**| Ürün Özel Bilgi Alanı başlığı | [optional] 
 **status** | **str**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif&lt;br&gt;&lt;code&gt;1&lt;/code&gt; : Aktif | [optional] 
 **product** | **int**| Ürün id | [optional] 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_special_infos_id_delete**
> product_special_infos_id_delete(id)

Ürün Özel Bilgi Alanı

Kalıcı olarak ilgili Ürün Özel Bilgi Alanını siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductSpecialInfoApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Özel Bilgi Alanı nesnesinin id değeri

try:
    # Ürün Özel Bilgi Alanı
    api_instance.product_special_infos_id_delete(id)
except ApiException as e:
    print("Exception when calling ProductSpecialInfoApi->product_special_infos_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_special_infos_id_get**
> ProductSpecialInfo product_special_infos_id_get(id)

Ürün Özel Bilgi Alanı

İlgili Ürün Özel Bilgi Alanını getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductSpecialInfoApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Özel Bilgi Alanı nesnesinin id değeri

try:
    # Ürün Özel Bilgi Alanı
    api_response = api_instance.product_special_infos_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductSpecialInfoApi->product_special_infos_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_special_infos_id_put**
> ProductSpecialInfo product_special_infos_id_put(id, product_special_info)

Ürün Özel Bilgi Alanı Güncelleme

İlgili Ürün Özel Bilgi Alanını günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductSpecialInfoApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Özel Bilgi Alanı nesnesinin id değeri
product_special_info = swagger_client.ProductSpecialInfo() # ProductSpecialInfo |  nesnesi

try:
    # Ürün Özel Bilgi Alanı Güncelleme
    api_response = api_instance.product_special_infos_id_put(id, product_special_info)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductSpecialInfoApi->product_special_infos_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özel Bilgi Alanı nesnesinin id değeri | 
 **product_special_info** | [**ProductSpecialInfo**](ProductSpecialInfo.md)|  nesnesi | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_special_infos_post**
> ProductSpecialInfo product_special_infos_post(product_special_info)

Ürün Özel Bilgi Alanı Oluşturma

Yeni bir Ürün Özel Bilgi Alanı oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductSpecialInfoApi(swagger_client.ApiClient(configuration))
product_special_info = swagger_client.ProductSpecialInfo() # ProductSpecialInfo |  nesnesi

try:
    # Ürün Özel Bilgi Alanı Oluşturma
    api_response = api_instance.product_special_infos_post(product_special_info)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductSpecialInfoApi->product_special_infos_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_special_info** | [**ProductSpecialInfo**](ProductSpecialInfo.md)|  nesnesi | 

### Return type

[**ProductSpecialInfo**](ProductSpecialInfo.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

