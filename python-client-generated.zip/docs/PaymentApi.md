# swagger_client.PaymentApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**payments_get**](PaymentApi.md#payments_get) | **GET** /payments | Ödeme Listesi Alma
[**payments_id_delete**](PaymentApi.md#payments_id_delete) | **DELETE** /payments/{id} | Ödeme Silme
[**payments_id_get**](PaymentApi.md#payments_id_get) | **GET** /payments/{id} | Ödeme Alma
[**payments_id_put**](PaymentApi.md#payments_id_put) | **PUT** /payments/{id} | Ödeme Güncelleme
[**payments_post**](PaymentApi.md#payments_post) | **POST** /payments | Ödeme Oluşturma


# **payments_get**
> Payment payments_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, transaction_id=transaction_id, member_email=member_email, member=member, status=status, payment_type_name=payment_type_name, start_date=start_date, end_date=end_date)

Ödeme Listesi Alma

Ödeme listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.PaymentApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
transaction_id = 'transaction_id_example' # str | İşlem id. (optional)
member_email = 'member_email_example' # str | Müşteri e-mail. (optional)
member = 56 # int | Üye id (optional)
status = 'status_example' # str | Status şu değerleri alabilir: <br><code>waiting_for_approval</code> : Onay Bekliyor<br><code>approved</code> : Onaylandı<br><code>fulfilled</code> : Kargoya Verildi<br><code>cancelled</code> : İptal Edildi<br><code>delivered</code> : Teslim Edildi<br><code>on_accumulation</code> : Tedarik Sürecinde<br><code>waiting_for_payment</code> : Ödeme Bekleniyor<br><code>being_prepared</code> : Hazırlanıyor<br><code>refunded</code> : İade Edildi<br><code>personal_status_1</code> : Kişisel Sipariş Durumu 1<br><code>personal_status_2</code> : Kişisel Sipariş Durumu 2<br><code>personal_status_3</code> : Kişisel Sipariş Durumu 3<br><code>deleted</code> : Silindi<br><code>failed</code> : Hatalı Ödemeler<br><code>in_transaction</code> : Sonuçlanmamış Ödemeler (optional)
payment_type_name = 'payment_type_name_example' # str | Ödeme tipi adı şu değerleri alabilir: <br><code>Havale</code><br><code>Özel Ödeme Sistemi</code><br><code>Kredi Kartı</code><br><code>Paypal</code><br><code>GarantiPay</code><br><code>Mail Order</code><br><code>BKM Express</code><br><code>Kapıda Ödeme Nakit</code><br><code>Kapıda Ödeme Kredi Kartı</code> (optional)
start_date = '2013-10-20' # date | createdAt değeri için başlangıç tarihi (optional)
end_date = 'end_date_example' # str | createdAt değeri için bitiş tarihi (optional)

try:
    # Ödeme Listesi Alma
    api_response = api_instance.payments_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, transaction_id=transaction_id, member_email=member_email, member=member, status=status, payment_type_name=payment_type_name, start_date=start_date, end_date=end_date)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PaymentApi->payments_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **transaction_id** | **str**| İşlem id. | [optional] 
 **member_email** | **str**| Müşteri e-mail. | [optional] 
 **member** | **int**| Üye id | [optional] 
 **status** | **str**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay Bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;fulfilled&lt;/code&gt; : Kargoya Verildi&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal Edildi&lt;br&gt;&lt;code&gt;delivered&lt;/code&gt; : Teslim Edildi&lt;br&gt;&lt;code&gt;on_accumulation&lt;/code&gt; : Tedarik Sürecinde&lt;br&gt;&lt;code&gt;waiting_for_payment&lt;/code&gt; : Ödeme Bekleniyor&lt;br&gt;&lt;code&gt;being_prepared&lt;/code&gt; : Hazırlanıyor&lt;br&gt;&lt;code&gt;refunded&lt;/code&gt; : İade Edildi&lt;br&gt;&lt;code&gt;personal_status_1&lt;/code&gt; : Kişisel Sipariş Durumu 1&lt;br&gt;&lt;code&gt;personal_status_2&lt;/code&gt; : Kişisel Sipariş Durumu 2&lt;br&gt;&lt;code&gt;personal_status_3&lt;/code&gt; : Kişisel Sipariş Durumu 3&lt;br&gt;&lt;code&gt;deleted&lt;/code&gt; : Silindi&lt;br&gt;&lt;code&gt;failed&lt;/code&gt; : Hatalı Ödemeler&lt;br&gt;&lt;code&gt;in_transaction&lt;/code&gt; : Sonuçlanmamış Ödemeler | [optional] 
 **payment_type_name** | **str**| Ödeme tipi adı şu değerleri alabilir: &lt;br&gt;&lt;code&gt;Havale&lt;/code&gt;&lt;br&gt;&lt;code&gt;Özel Ödeme Sistemi&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kredi Kartı&lt;/code&gt;&lt;br&gt;&lt;code&gt;Paypal&lt;/code&gt;&lt;br&gt;&lt;code&gt;GarantiPay&lt;/code&gt;&lt;br&gt;&lt;code&gt;Mail Order&lt;/code&gt;&lt;br&gt;&lt;code&gt;BKM Express&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kapıda Ödeme Nakit&lt;/code&gt;&lt;br&gt;&lt;code&gt;Kapıda Ödeme Kredi Kartı&lt;/code&gt; | [optional] 
 **start_date** | **date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **str**| createdAt değeri için bitiş tarihi | [optional] 

### Return type

[**Payment**](Payment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **payments_id_delete**
> payments_id_delete(id)

Ödeme Silme

Kalıcı olarak ilgili Ödemeyi siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.PaymentApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ödeme nesnesinin id değeri

try:
    # Ödeme Silme
    api_instance.payments_id_delete(id)
except ApiException as e:
    print("Exception when calling PaymentApi->payments_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ödeme nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **payments_id_get**
> Payment payments_id_get(id)

Ödeme Alma

İlgili Ödemeyi getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.PaymentApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ödeme nesnesinin id değeri

try:
    # Ödeme Alma
    api_response = api_instance.payments_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PaymentApi->payments_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ödeme nesnesinin id değeri | 

### Return type

[**Payment**](Payment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **payments_id_put**
> Payment payments_id_put(id, payment)

Ödeme Güncelleme

İlgili Ödemeyi günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.PaymentApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ödeme nesnesinin id değeri
payment = swagger_client.Payment() # Payment |  nesnesi

try:
    # Ödeme Güncelleme
    api_response = api_instance.payments_id_put(id, payment)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PaymentApi->payments_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ödeme nesnesinin id değeri | 
 **payment** | [**Payment**](Payment.md)|  nesnesi | 

### Return type

[**Payment**](Payment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **payments_post**
> Payment payments_post(payment)

Ödeme Oluşturma

Yeni bir Ödeme oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.PaymentApi(swagger_client.ApiClient(configuration))
payment = swagger_client.Payment() # Payment |  nesnesi

try:
    # Ödeme Oluşturma
    api_response = api_instance.payments_post(payment)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PaymentApi->payments_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **payment** | [**Payment**](Payment.md)|  nesnesi | 

### Return type

[**Payment**](Payment.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

