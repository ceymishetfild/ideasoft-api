# swagger_client.SelectionToProductApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selection_to_products_get**](SelectionToProductApi.md#selection_to_products_get) | **GET** /selection_to_products | Ek Özellik Ürün Bağı Listesi Alma
[**selection_to_products_id_delete**](SelectionToProductApi.md#selection_to_products_id_delete) | **DELETE** /selection_to_products/{id} | Ek Özellik Ürün Bağı Silme
[**selection_to_products_id_get**](SelectionToProductApi.md#selection_to_products_id_get) | **GET** /selection_to_products/{id} | Ek Özellik Ürün Bağı Alma
[**selection_to_products_id_put**](SelectionToProductApi.md#selection_to_products_id_put) | **PUT** /selection_to_products/{id} | Ek Özellik Ürün Bağı Güncelleme
[**selection_to_products_post**](SelectionToProductApi.md#selection_to_products_post) | **POST** /selection_to_products | Ek Özellik Ürün Bağı Oluşturma


# **selection_to_products_get**
> SelectionToProduct selection_to_products_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, selection=selection, product=product)

Ek Özellik Ürün Bağı Listesi Alma

Ek Özellik Ürün Bağı listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SelectionToProductApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
ids = 'ids_example' # str | Çoklu listeleme için virgülle ayrılmış id değerleri. <code>ids=1,2,3,4</code>  (optional)
selection = 56 # int | Ek Özellik id (optional)
product = 56 # int | Ürün id (optional)

try:
    # Ek Özellik Ürün Bağı Listesi Alma
    api_response = api_instance.selection_to_products_get(sort=sort, limit=limit, page=page, since_id=since_id, ids=ids, selection=selection, product=product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SelectionToProductApi->selection_to_products_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **ids** | **str**| Çoklu listeleme için virgülle ayrılmış id değerleri. &lt;code&gt;ids&#x3D;1,2,3,4&lt;/code&gt;  | [optional] 
 **selection** | **int**| Ek Özellik id | [optional] 
 **product** | **int**| Ürün id | [optional] 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selection_to_products_id_delete**
> selection_to_products_id_delete(id)

Ek Özellik Ürün Bağı Silme

Kalıcı olarak ilgili Ek Özellik Ürün Bağını siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SelectionToProductApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ek Özellik Ürün Bağı nesnesinin id değeri

try:
    # Ek Özellik Ürün Bağı Silme
    api_instance.selection_to_products_id_delete(id)
except ApiException as e:
    print("Exception when calling SelectionToProductApi->selection_to_products_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selection_to_products_id_get**
> SelectionToProduct selection_to_products_id_get(id)

Ek Özellik Ürün Bağı Alma

İlgili Ek Özellik Ürün Bağını getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SelectionToProductApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ek Özellik Ürün Bağı nesnesinin id değeri

try:
    # Ek Özellik Ürün Bağı Alma
    api_response = api_instance.selection_to_products_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SelectionToProductApi->selection_to_products_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik Ürün Bağı nesnesinin id değeri | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selection_to_products_id_put**
> SelectionToProduct selection_to_products_id_put(id, selection_to_product)

Ek Özellik Ürün Bağı Güncelleme

İlgili Ek Özellik Ürün Bağını günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SelectionToProductApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ek Özellik Ürün Bağı nesnesinin id değeri
selection_to_product = swagger_client.SelectionToProduct() # SelectionToProduct |  nesnesi

try:
    # Ek Özellik Ürün Bağı Güncelleme
    api_response = api_instance.selection_to_products_id_put(id, selection_to_product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SelectionToProductApi->selection_to_products_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik Ürün Bağı nesnesinin id değeri | 
 **selection_to_product** | [**SelectionToProduct**](SelectionToProduct.md)|  nesnesi | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selection_to_products_post**
> SelectionToProduct selection_to_products_post(selection_to_product)

Ek Özellik Ürün Bağı Oluşturma

Yeni bir Ek Özellik Ürün Bağı oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SelectionToProductApi(swagger_client.ApiClient(configuration))
selection_to_product = swagger_client.SelectionToProduct() # SelectionToProduct |  nesnesi

try:
    # Ek Özellik Ürün Bağı Oluşturma
    api_response = api_instance.selection_to_products_post(selection_to_product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SelectionToProductApi->selection_to_products_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selection_to_product** | [**SelectionToProduct**](SelectionToProduct.md)|  nesnesi | 

### Return type

[**SelectionToProduct**](SelectionToProduct.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

