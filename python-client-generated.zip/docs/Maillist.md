# Maillist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Mail listesi nesnesi kimlik değeri. | [optional] 
**name** | **str** | Mail listesi nesnesi için isim değeri. | 
**email** | **str** | Ziyaretçi veya üyenin mail adresi. | 
**last_mail_sent_date** | **datetime** | En son e-mail gönderilen zaman. | [optional] 
**creator_ip_address** | **str** | Mail listesi nesnesini oluşturan kişinin IP adresi. | [optional] 
**created_at** | **datetime** | Mail listesi nesnesinin oluşturulma zamanı. | 
**updated_at** | **datetime** | Mail listesi nesnesinin güncellenme zamanı. | 
**maillist_group** | [**MaillistGroup**](MaillistGroup.md) | Mail listesi grubu nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


