# swagger_client.SpecNameApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**spec_names_get**](SpecNameApi.md#spec_names_get) | **GET** /spec_names | Ürün Özelliği Listesi Alma
[**spec_names_id_delete**](SpecNameApi.md#spec_names_id_delete) | **DELETE** /spec_names/{id} | Ürün Özelliği Silme
[**spec_names_id_get**](SpecNameApi.md#spec_names_id_get) | **GET** /spec_names/{id} | Ürün Özelliği Alma
[**spec_names_id_put**](SpecNameApi.md#spec_names_id_put) | **PUT** /spec_names/{id} | Ürün Özelliği Güncelleme
[**spec_names_post**](SpecNameApi.md#spec_names_post) | **POST** /spec_names | Ürün Özelliği Oluşturma


# **spec_names_get**
> SpecName spec_names_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name, spec_group=spec_group, choice_type=choice_type)

Ürün Özelliği Listesi Alma

Ürün Özelliği listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SpecNameApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
name = 'name_example' # str | Ürün Özelliği adı (optional)
spec_group = 56 # int | Ürün özellik grubu id (optional)
choice_type = 'choice_type_example' # str | Status şu değerleri alabilir: <br><code>singular</code> : Tekil<br><code>plural</code> : Çoğul (optional)

try:
    # Ürün Özelliği Listesi Alma
    api_response = api_instance.spec_names_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name, spec_group=spec_group, choice_type=choice_type)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SpecNameApi->spec_names_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **name** | **str**| Ürün Özelliği adı | [optional] 
 **spec_group** | **int**| Ürün özellik grubu id | [optional] 
 **choice_type** | **str**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul | [optional] 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_names_id_delete**
> spec_names_id_delete(id)

Ürün Özelliği Silme

Kalıcı olarak ilgili Ürün Özelliğini siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SpecNameApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Özellik nesnesinin id değeri

try:
    # Ürün Özelliği Silme
    api_instance.spec_names_id_delete(id)
except ApiException as e:
    print("Exception when calling SpecNameApi->spec_names_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_names_id_get**
> SpecName spec_names_id_get(id)

Ürün Özelliği Alma

İlgili Ürün Özelliğini getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SpecNameApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Özellik nesnesinin id değeri

try:
    # Ürün Özelliği Alma
    api_response = api_instance.spec_names_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SpecNameApi->spec_names_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik nesnesinin id değeri | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_names_id_put**
> SpecName spec_names_id_put(id, spec_name)

Ürün Özelliği Güncelleme

İlgili Ürün Özelliğini günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SpecNameApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ürün Özellik nesnesinin id değeri
spec_name = swagger_client.SpecName() # SpecName | SpecName nesnesi

try:
    # Ürün Özelliği Güncelleme
    api_response = api_instance.spec_names_id_put(id, spec_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SpecNameApi->spec_names_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ürün Özellik nesnesinin id değeri | 
 **spec_name** | [**SpecName**](SpecName.md)| SpecName nesnesi | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **spec_names_post**
> SpecName spec_names_post(spec_name)

Ürün Özelliği Oluşturma

Yeni bir Ürün Özelliği oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SpecNameApi(swagger_client.ApiClient(configuration))
spec_name = swagger_client.SpecName() # SpecName | SpecName nesnesi

try:
    # Ürün Özelliği Oluşturma
    api_response = api_instance.spec_names_post(spec_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SpecNameApi->spec_names_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **spec_name** | [**SpecName**](SpecName.md)| SpecName nesnesi | 

### Return type

[**SpecName**](SpecName.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

