# ShippingCompany

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Kargo firması nesnesi kimlik değeri. | [optional] 
**name** | **str** | Kargo firması nesnesi için isim değeri. | 
**status** | **str** | Kargo firması nesnesinin aktiflik durumunu belirten değer.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;active&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;passive&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**extra_price** | **float** | Kargo firması için sabit ücret. Sabit bir kargo ücreti uygulayacaksanız her sipariş için sabit kargo ücreti girebilirsiniz. Desi bilgilerini kaydetmeniz durumunda desi toplamlarının üzerine sabit ücret eklenecektir. | [optional] 
**extra_volumetric_weight_price** | **float** | Kargo firması için girmiş olduğunuz desi bilgileri 50 Desiye kadar girilebilmektedir. 50&#39;nin üzeri veya girmiş olduğunuz desi miktarının üzerine her +1 desi için eklenecek olan kargo ücreti. | [optional] 
**free_shipment_order_price** | **float** | Alışveriş sepeti toplamı belirlediğiniz Ücretsiz kargo limitini geçtiğinde müşterileriniz ücretsiz kargo hizmetinden faydalanabilirler.(Örn: X Lira üzeri ücretsiz Kargo!) | [optional] 
**free_shipment_volumetric_weight_limit** | **float** | Ücretsiz kargo miktarı için maksimum ücretsiz desi miktarıdır. Alışveriş sırasındaki desi miktarı ücretsiz desi miktarından fazlaysa, + Desi miktarını sipariş sırasında sistem müşteriden tahsil eder.(Örn: X TL üzeri ücretsiz kargo! Fakat X desiye kadar)Üzeri müşteriden tahsil edilir. | [optional] 
**sort_order** | **int** | Kargo firması nesnesi için sıralama değeri. | [optional] 
**company_code** | **str** | API tarafından otomatik oluşturulan kargo firması kodu. | [optional] 
**payment_type** | **str** | Kargo firması için ödeme tipi.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;cash_on_delivery&lt;/code&gt; : Alıcı ödemeli.&lt;br&gt;&lt;code&gt;standart_delivery&lt;/code&gt; : Gönderici ödemeli.&lt;br&gt;&lt;code&gt;not_applicable&lt;/code&gt; : Bu alan için uygulanabilir değil.&lt;br&gt;&lt;/div&gt; | [optional] 
**shipping_provider** | [**ShippingProvider**](ShippingProvider.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


