# ProductToTag

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ürün SEO+ etiketi bağı nesnesi kimlik değeri. | [optional] 
**product** | [**Product**](Product.md) | Ürün nesnesi. | 
**tag** | [**Tag**](Tag.md) | SEO+ etiketi nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


