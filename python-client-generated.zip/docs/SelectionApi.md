# swagger_client.SelectionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**selections_get**](SelectionApi.md#selections_get) | **GET** /selections | Ek Özellik Listesi Alma
[**selections_id_delete**](SelectionApi.md#selections_id_delete) | **DELETE** /selections/{id} | Ek Özellik Silme
[**selections_id_get**](SelectionApi.md#selections_id_get) | **GET** /selections/{id} | Ek Özellik Alma
[**selections_id_put**](SelectionApi.md#selections_id_put) | **PUT** /selections/{id} | Ek Özellik Güncelleme
[**selections_post**](SelectionApi.md#selections_post) | **POST** /selections | Ek Özellik Oluşturma


# **selections_get**
> Selection selections_get(sort=sort, limit=limit, page=page, since_id=since_id, title=title, selection_group=selection_group)

Ek Özellik Listesi Alma

Ek Özellik listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SelectionApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
title = 'title_example' # str | Ek Özellik başlığı (optional)
selection_group = 56 # int | Ek Özellik Grubu id (optional)

try:
    # Ek Özellik Listesi Alma
    api_response = api_instance.selections_get(sort=sort, limit=limit, page=page, since_id=since_id, title=title, selection_group=selection_group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SelectionApi->selections_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **title** | **str**| Ek Özellik başlığı | [optional] 
 **selection_group** | **int**| Ek Özellik Grubu id | [optional] 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selections_id_delete**
> selections_id_delete(id)

Ek Özellik Silme

Kalıcı olarak ilgili Ek Özelliği siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SelectionApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ek Özellik nesnesinin id değeri

try:
    # Ek Özellik Silme
    api_instance.selections_id_delete(id)
except ApiException as e:
    print("Exception when calling SelectionApi->selections_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selections_id_get**
> Selection selections_id_get(id)

Ek Özellik Alma

İlgili Ek Özelliği getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SelectionApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ek Özellik nesnesinin id değeri

try:
    # Ek Özellik Alma
    api_response = api_instance.selections_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SelectionApi->selections_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik nesnesinin id değeri | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selections_id_put**
> Selection selections_id_put(id, selection)

Ek Özellik Güncelleme

İlgili Ek Özelliği günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SelectionApi(swagger_client.ApiClient(configuration))
id = 56 # int | Ek Özellik nesnesinin id değeri
selection = swagger_client.Selection() # Selection | Selection nesnesi

try:
    # Ek Özellik Güncelleme
    api_response = api_instance.selections_id_put(id, selection)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SelectionApi->selections_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Ek Özellik nesnesinin id değeri | 
 **selection** | [**Selection**](Selection.md)| Selection nesnesi | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **selections_post**
> Selection selections_post(selection)

Ek Özellik Oluşturma

Yeni bir Ek Özellik oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.SelectionApi(swagger_client.ApiClient(configuration))
selection = swagger_client.Selection() # Selection | Selection nesnesi

try:
    # Ek Özellik Oluşturma
    api_response = api_instance.selections_post(selection)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SelectionApi->selections_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **selection** | [**Selection**](Selection.md)| Selection nesnesi | 

### Return type

[**Selection**](Selection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

