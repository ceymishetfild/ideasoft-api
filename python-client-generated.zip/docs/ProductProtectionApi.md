# swagger_client.ProductProtectionApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**product_protections_get**](ProductProtectionApi.md#product_protections_get) | **GET** /product_protections | Entegrasyon Seçeneği Listesi Alma
[**product_protections_id_delete**](ProductProtectionApi.md#product_protections_id_delete) | **DELETE** /product_protections/{id} | Entegrasyon Seçeneği Silme
[**product_protections_id_get**](ProductProtectionApi.md#product_protections_id_get) | **GET** /product_protections/{id} | Entegrasyon Seçeneği Alma
[**product_protections_id_put**](ProductProtectionApi.md#product_protections_id_put) | **PUT** /product_protections/{id} | Entegrasyon Seçeneği Güncelleme
[**product_protections_post**](ProductProtectionApi.md#product_protections_post) | **POST** /product_protections | Entegrasyon Seçeneği Oluşturma


# **product_protections_get**
> ProductProtection product_protections_get(sort=sort, limit=limit, page=page, since_id=since_id, is_price_protected=is_price_protected, is_stock_protected=is_stock_protected, product=product)

Entegrasyon Seçeneği Listesi Alma

Entegrasyon Seçeneği listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductProtectionApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
is_price_protected = 56 # int | Fiyat korumalı ürünleri listeler<code>0</code><br><code>1</code> (optional)
is_stock_protected = 56 # int | Stok korumalı ürünleri listeler<code>0</code><br><code>1</code> (optional)
product = 56 # int | Ürün id (optional)

try:
    # Entegrasyon Seçeneği Listesi Alma
    api_response = api_instance.product_protections_get(sort=sort, limit=limit, page=page, since_id=since_id, is_price_protected=is_price_protected, is_stock_protected=is_stock_protected, product=product)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductProtectionApi->product_protections_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **is_price_protected** | **int**| Fiyat korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **is_stock_protected** | **int**| Stok korumalı ürünleri listeler&lt;code&gt;0&lt;/code&gt;&lt;br&gt;&lt;code&gt;1&lt;/code&gt; | [optional] 
 **product** | **int**| Ürün id | [optional] 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_protections_id_delete**
> product_protections_id_delete(id)

Entegrasyon Seçeneği Silme

Kalıcı olarak ilgili Entegrasyon Seçeneğini siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductProtectionApi(swagger_client.ApiClient(configuration))
id = 56 # int | Entegrasyon Seçeneği nesnesinin id değeri

try:
    # Entegrasyon Seçeneği Silme
    api_instance.product_protections_id_delete(id)
except ApiException as e:
    print("Exception when calling ProductProtectionApi->product_protections_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Entegrasyon Seçeneği nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_protections_id_get**
> ProductProtection product_protections_id_get(id)

Entegrasyon Seçeneği Alma

İlgili Entegrasyon Seçeneğini getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductProtectionApi(swagger_client.ApiClient(configuration))
id = 56 # int | Entegrasyon Seçeneği nesnesinin id değeri

try:
    # Entegrasyon Seçeneği Alma
    api_response = api_instance.product_protections_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductProtectionApi->product_protections_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Entegrasyon Seçeneği nesnesinin id değeri | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_protections_id_put**
> ProductProtection product_protections_id_put(id, product_protection)

Entegrasyon Seçeneği Güncelleme

İlgili Entegrasyon Seçeneğini günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductProtectionApi(swagger_client.ApiClient(configuration))
id = 56 # int | Entegrasyon Seçeneği nesnesinin id değeri
product_protection = swagger_client.ProductProtection() # ProductProtection | ProductProtection nesnesi

try:
    # Entegrasyon Seçeneği Güncelleme
    api_response = api_instance.product_protections_id_put(id, product_protection)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductProtectionApi->product_protections_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Entegrasyon Seçeneği nesnesinin id değeri | 
 **product_protection** | [**ProductProtection**](ProductProtection.md)| ProductProtection nesnesi | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **product_protections_post**
> ProductProtection product_protections_post(product_protection)

Entegrasyon Seçeneği Oluşturma

Yeni bir Entegrasyon Seçeneği oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ProductProtectionApi(swagger_client.ApiClient(configuration))
product_protection = swagger_client.ProductProtection() # ProductProtection | ProductProtection nesnesi

try:
    # Entegrasyon Seçeneği Oluşturma
    api_response = api_instance.product_protections_post(product_protection)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductProtectionApi->product_protections_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_protection** | [**ProductProtection**](ProductProtection.md)| ProductProtection nesnesi | 

### Return type

[**ProductProtection**](ProductProtection.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

