# swagger_client.OrderRefundRequestApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**order_refund_requests_get**](OrderRefundRequestApi.md#order_refund_requests_get) | **GET** /order_refund_requests | Sipariş İptal Talebi Listesi Alma
[**order_refund_requests_id_delete**](OrderRefundRequestApi.md#order_refund_requests_id_delete) | **DELETE** /order_refund_requests/{id} | Sipariş İptal Talebi Silme
[**order_refund_requests_id_get**](OrderRefundRequestApi.md#order_refund_requests_id_get) | **GET** /order_refund_requests/{id} | Sipariş İptal Talebi Alma
[**order_refund_requests_id_put**](OrderRefundRequestApi.md#order_refund_requests_id_put) | **PUT** /order_refund_requests/{id} | Sipariş İptal Talebi Güncelleme
[**order_refund_requests_post**](OrderRefundRequestApi.md#order_refund_requests_post) | **POST** /order_refund_requests | Sipariş İptal Talebi Oluşturma


# **order_refund_requests_get**
> OrderRefundRequest order_refund_requests_get(sort=sort, limit=limit, page=page, since_id=since_id, order=order, member=member, code=code, status=status, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)

Sipariş İptal Talebi Listesi Alma

Sipariş İptal Talebi listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderRefundRequestApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code>  (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir  (optional)
order = 56 # int | Sipariş id (optional)
member = 56 # int | Üye id (optional)
code = 'code_example' # str | Sipariş İptal Talebi kodu (optional)
status = 'status_example' # str | Status şu değerleri alabilir: <br><code>waiting_for_approval</code> : Onay bekliyor<br><code>approved</code> : Onaylandı<br><code>cancelled</code> : İptal edildi (optional)
start_date = '2013-10-20' # date | createdAt değeri için başlangıç tarihi (optional)
end_date = 'end_date_example' # str | createdAt değeri için bitiş tarihi (optional)
start_updated_at = '2013-10-20' # date | updatedAt değeri için başlangıç tarihi (optional)
end_updated_at = 'end_updated_at_example' # str | updatedAt değeri için bitiş tarihi (optional)

try:
    # Sipariş İptal Talebi Listesi Alma
    api_response = api_instance.order_refund_requests_get(sort=sort, limit=limit, page=page, since_id=since_id, order=order, member=member, code=code, status=status, start_date=start_date, end_date=end_date, start_updated_at=start_updated_at, end_updated_at=end_updated_at)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderRefundRequestApi->order_refund_requests_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt;  | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir  | [optional] 
 **order** | **int**| Sipariş id | [optional] 
 **member** | **int**| Üye id | [optional] 
 **code** | **str**| Sipariş İptal Talebi kodu | [optional] 
 **status** | **str**| Status şu değerleri alabilir: &lt;br&gt;&lt;code&gt;waiting_for_approval&lt;/code&gt; : Onay bekliyor&lt;br&gt;&lt;code&gt;approved&lt;/code&gt; : Onaylandı&lt;br&gt;&lt;code&gt;cancelled&lt;/code&gt; : İptal edildi | [optional] 
 **start_date** | **date**| createdAt değeri için başlangıç tarihi | [optional] 
 **end_date** | **str**| createdAt değeri için bitiş tarihi | [optional] 
 **start_updated_at** | **date**| updatedAt değeri için başlangıç tarihi | [optional] 
 **end_updated_at** | **str**| updatedAt değeri için bitiş tarihi | [optional] 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_refund_requests_id_delete**
> order_refund_requests_id_delete(id)

Sipariş İptal Talebi Silme

Kalıcı olarak ilgili Sipariş İptal Talebini siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderRefundRequestApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sipariş İptal Talebi nesnesinin id değeri

try:
    # Sipariş İptal Talebi Silme
    api_instance.order_refund_requests_id_delete(id)
except ApiException as e:
    print("Exception when calling OrderRefundRequestApi->order_refund_requests_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş İptal Talebi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_refund_requests_id_get**
> OrderRefundRequest order_refund_requests_id_get(id)

Sipariş İptal Talebi Alma

İlgili Sipariş İptal Talebini getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderRefundRequestApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sipariş İptal Talebi nesnesinin id değeri

try:
    # Sipariş İptal Talebi Alma
    api_response = api_instance.order_refund_requests_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderRefundRequestApi->order_refund_requests_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş İptal Talebi nesnesinin id değeri | 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_refund_requests_id_put**
> OrderRefundRequest order_refund_requests_id_put(id, order_refund_request)

Sipariş İptal Talebi Güncelleme

İlgili Sipariş İptal Talebini günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderRefundRequestApi(swagger_client.ApiClient(configuration))
id = 56 # int | Sipariş İptal Talebi nesnesinin id değeri
order_refund_request = swagger_client.OrderRefundRequest() # OrderRefundRequest | OrderRefundRequest nesnesi

try:
    # Sipariş İptal Talebi Güncelleme
    api_response = api_instance.order_refund_requests_id_put(id, order_refund_request)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderRefundRequestApi->order_refund_requests_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| Sipariş İptal Talebi nesnesinin id değeri | 
 **order_refund_request** | [**OrderRefundRequest**](OrderRefundRequest.md)| OrderRefundRequest nesnesi | 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_refund_requests_post**
> OrderRefundRequest order_refund_requests_post(order_refund_request)

Sipariş İptal Talebi Oluşturma

Yeni bir Sipariş İptal Talebi oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.OrderRefundRequestApi(swagger_client.ApiClient(configuration))
order_refund_request = swagger_client.OrderRefundRequest() # OrderRefundRequest | OrderRefundRequest nesnesi

try:
    # Sipariş İptal Talebi Oluşturma
    api_response = api_instance.order_refund_requests_post(order_refund_request)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OrderRefundRequestApi->order_refund_requests_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **order_refund_request** | [**OrderRefundRequest**](OrderRefundRequest.md)| OrderRefundRequest nesnesi | 

### Return type

[**OrderRefundRequest**](OrderRefundRequest.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

