# swagger_client.TagApi

All URIs are relative to *https://magaza-adiniz.myideasoft.com/api*

Method | HTTP request | Description
------------- | ------------- | -------------
[**tags_get**](TagApi.md#tags_get) | **GET** /tags | SEO+ Etiketi Listesi Alma
[**tags_id_delete**](TagApi.md#tags_id_delete) | **DELETE** /tags/{id} | SEO+ Etiketi Silme
[**tags_id_get**](TagApi.md#tags_id_get) | **GET** /tags/{id} | SEO+ Etiketi Alma
[**tags_id_put**](TagApi.md#tags_id_put) | **PUT** /tags/{id} | SEO+ Etiketi Güncelleme
[**tags_post**](TagApi.md#tags_post) | **POST** /tags | SEO+ Etiketi Oluşturma


# **tags_get**
> Tag tags_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name)

SEO+ Etiketi Listesi Alma

SEO+ Etiketi listesini verir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.TagApi(swagger_client.ApiClient(configuration))
sort = 'sort_example' # str | Sıralama değeri. Örnek: Artan sıra için <code>sort=id</code> azalan sıra için <code>sort=-id</code> (optional)
limit = 20 # int | Bir sayfada gelecek sonuç adedi (optional) (default to 20)
page = 1 # int | Hangi sayfadan başlanacağı (optional) (default to 1)
since_id = 56 # int | Yalnızca belirtilen id değerinden sonraki kayıtları getirir (optional)
name = 'name_example' # str | SEO+ Etiketi adı (optional)

try:
    # SEO+ Etiketi Listesi Alma
    api_response = api_instance.tags_get(sort=sort, limit=limit, page=page, since_id=since_id, name=name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TagApi->tags_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **str**| Sıralama değeri. Örnek: Artan sıra için &lt;code&gt;sort&#x3D;id&lt;/code&gt; azalan sıra için &lt;code&gt;sort&#x3D;-id&lt;/code&gt; | [optional] 
 **limit** | **int**| Bir sayfada gelecek sonuç adedi | [optional] [default to 20]
 **page** | **int**| Hangi sayfadan başlanacağı | [optional] [default to 1]
 **since_id** | **int**| Yalnızca belirtilen id değerinden sonraki kayıtları getirir | [optional] 
 **name** | **str**| SEO+ Etiketi adı | [optional] 

### Return type

[**Tag**](Tag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **tags_id_delete**
> tags_id_delete(id)

SEO+ Etiketi Silme

Kalıcı olarak ilgili SEO+ Etiketini siler.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.TagApi(swagger_client.ApiClient(configuration))
id = 56 # int | SEO+ Etiketi nesnesinin id değeri

try:
    # SEO+ Etiketi Silme
    api_instance.tags_id_delete(id)
except ApiException as e:
    print("Exception when calling TagApi->tags_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| SEO+ Etiketi nesnesinin id değeri | 

### Return type

void (empty response body)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **tags_id_get**
> Tag tags_id_get(id)

SEO+ Etiketi Alma

İlgili SEO+ Etiketini getirir.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.TagApi(swagger_client.ApiClient(configuration))
id = 56 # int | SEO+ Etiketi nesnesinin id değeri

try:
    # SEO+ Etiketi Alma
    api_response = api_instance.tags_id_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TagApi->tags_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| SEO+ Etiketi nesnesinin id değeri | 

### Return type

[**Tag**](Tag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **tags_id_put**
> Tag tags_id_put(id, tag)

SEO+ Etiketi Güncelleme

İlgili SEO+ Etiketini günceller.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.TagApi(swagger_client.ApiClient(configuration))
id = 56 # int | SEO+ Etiketi nesnesinin id değeri
tag = swagger_client.Tag() # Tag | Tag nesnesi

try:
    # SEO+ Etiketi Güncelleme
    api_response = api_instance.tags_id_put(id, tag)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TagApi->tags_id_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| SEO+ Etiketi nesnesinin id değeri | 
 **tag** | [**Tag**](Tag.md)| Tag nesnesi | 

### Return type

[**Tag**](Tag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **tags_post**
> Tag tags_post(tag)

SEO+ Etiketi Oluşturma

Yeni bir SEO+ Etiketi oluşturur.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: OAuth2
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.TagApi(swagger_client.ApiClient(configuration))
tag = swagger_client.Tag() # Tag | Tag nesnesi

try:
    # SEO+ Etiketi Oluşturma
    api_response = api_instance.tags_post(tag)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TagApi->tags_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tag** | [**Tag**](Tag.md)| Tag nesnesi | 

### Return type

[**Tag**](Tag.md)

### Authorization

[OAuth2](../README.md#OAuth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

