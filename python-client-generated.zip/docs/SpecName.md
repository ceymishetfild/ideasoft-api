# SpecName

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Ürün özelliği nesnesi kimlik değeri. | [optional] 
**name** | **str** | Ürün özelliği nesnesi için isim değeri. | 
**choice_type** | **str** | Özellik tipini belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;singular&lt;/code&gt; : Tekil&lt;br&gt;&lt;code&gt;plural&lt;/code&gt; : Çoğul&lt;br&gt;&lt;/div&gt; | 
**sort_order** | **int** | Ürün özelliği sıralama değeri. | [optional] 
**status** | **str** | Ürün özelliği aktiflik durumunu belirtir.&lt;div class&#x3D;&#39;idea_choice_list&#39;&gt;&lt;code&gt;1&lt;/code&gt; : Aktif.&lt;br&gt;&lt;code&gt;0&lt;/code&gt; : Pasif.&lt;br&gt;&lt;/div&gt; | 
**spec_group** | [**SpecGroup**](SpecGroup.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


