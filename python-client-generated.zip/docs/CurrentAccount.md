# CurrentAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Cari hesap nesnesi kimlik değeri. | [optional] 
**code** | **str** | Cari hesap için düzenlenebilir bir kod değeri. | [optional] 
**title** | **str** | Cari hesap nesnesinin başlığı. | 
**balance** | **float** | Cari hesabın bakiyesi. | [optional] 
**risk_limit** | **float** | Cari hesap için belirlenmiş risk limiti. | [optional] 
**created_at** | **datetime** | Cari hesap nesnesinin oluşturulma zamanı. | [optional] 
**updated_at** | **datetime** | Cari hesap nesnesinin güncellenme zamanı. | [optional] 
**member** | [**Member**](Member.md) | Üye nesnesi. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


